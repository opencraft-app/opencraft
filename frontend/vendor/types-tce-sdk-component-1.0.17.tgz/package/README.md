# TCE 业务SDK类型定义
> 提供了所有标准业务SDK的类型TS定义

## 初始化
git submodule update --init 
## 发布到 tnpm 中

- tnpm run build [build]
- tnpm version [更新版本号]

```sh
tnpm version major [更新大版本---出现接口不兼容的时候使用]
tnpm version minor [更新小版本---增加接口使用这个]
tnpm version patch [更新bug版本---修复接口（兼容修改）使用这个]
```
