import { ModalProps } from '@tencent/tea-component';
import { ECBasicOption } from 'echarts/types/dist/shared';
import React from 'react';
import { CSSProperties, FC, ReactNode } from 'react';

export interface DashboardLinkType {
	name: string;
	url: string;
	target: string;
}
export interface PolicyLinkType {
	name: string;
	url: string;
	target: string;
}
export type DimensionFuncion = () => string[];
export type Dimensions = string | string[] | DimensionFuncion;
export type MetricNameFunction = () => string;
export type MetricName = string | MetricNameFunction;
export interface BaseLinesType {
	label: string;
	value: number;
	color: string;
}
export interface Metric {
	baseLines?: BaseLinesType;
	metricName?: MetricName;
	metricCName?: string;
	metricCname?: string;
	dimensions?: Dimensions;
	unit?: string;
	type?: string;
	chartType?: string;
	category?: string;
	metrics?: Metric[];
	checkIfVisible?: (arg1?: any, arg2?: any) => boolean;
	supportDrillDown?: boolean;
	[key: string]: any;
}
export interface TimeTab {
	label: string;
	fromBefore: number;
	from?: Date;
	to?: Date;
}
export interface SideBarPanelProps {
	showFilterPanel?: boolean;
	dashboardLink?: DashboardLinkType;
	policyLink?: PolicyLinkType;
	hideDateTime?: boolean;
	isLargeChart?: boolean;
	title?: string;
	layout?: string;
	utcOffset?: number;
	data?: any;
	getData?: (page: number, vm: any) => void;
	onDataChange?: (args: any) => void;
	namespace: any;
	dimensions?: Dimensions;
	metrics?: Metric[];
	metricName?: () => string;
	minPeriod?: number;
	maxPeriod?: number;
	periods?: number[];
	regionId: string | number;
	pagination?: {
		range: {
			from: number;
			to: number;
		};
		index: number;
	};
	hideCompare?: boolean;
	extraTimeTabs?: TimeTab[];
	hideNav?: boolean;
	isTabLayout?: boolean;
	hideChartTabs?: boolean;
	getLegend?: (param: any) => string;
	headerExtraButton?: any;
	onClickLinePoint?: any;
	drillDown?: any;
	drillDownLayout?: string;
	chartType?: string;
	globalDimensions?: any;
	isHideAddPolicy?: any;
	policyViewName?: any;
	isChartsSeperateByInstances?: boolean;
	defaultSelectedTabIndex?: number;
}
export interface MonitorChart {
	metric: object;
	values: [
		number,
		string
	][];
}
export interface MonitorChartWithLegend extends MonitorChart {
	legend?: queryArray["legend"];
}
export interface ChartRenderProps {
	option: ECBasicOption;
	style?: CSSProperties;
	events?: Record<string, Function>;
	showLegend?: boolean;
	showVerticalLegend?: boolean;
	verticalLegendStyles: CSSProperties;
}
export type GetMonitorDataFC = (param: ChartConfig & {
	currentMetricConfig: MetricConfig;
}) => Promise<MonitorChart[]>;
export type CustomizeFunc = (param: {
	onConfigChange: (filters: Partial<ChartConfig>) => void;
}) => ReactNode;
export type CustomizedFilter = ReactNode | CustomizeFunc;
declare enum MatchSymbol {
	Equal = "=",
	NotEqual = "!=",
	NotRegEqual = "!~",
	RegEqual = "=~"
}
export interface Label {
	name: string;
	value?: string;
	matchType?: MatchSymbol;
}
export interface MetricConfig {
	metricName: string;
	metricAlias?: ReactNode;
	labels?: Label[];
	/**
	 * 可以指定聚合运算符
	 */
	aggregationOperator?: AggregationOperator;
	legendLabels?: string | string[];
	emptyText?: string;
	query?: string | queryArray[];
	unit?: string;
	precision?: number;
	render?: (param: {
		Chart: FC<ChartRenderProps>;
	}) => JSX.Element;
	valueRange?: [
		number,
		number
	];
	interval?: number;
	optionFormatter?: (options: ECBasicOption) => ECBasicOption;
}
/**
 * 同时支持多个query的， 渲染多条线
 */
export interface queryArray {
	query: string;
	legend?: (data: MonitorChartWithLegend) => string;
}
export interface Category {
	type: string;
	name?: ReactNode;
	metrics: MetricConfig[];
	dimensions?: {
		[key: string]: string | string[];
	};
}
export type Period = "now-30m" | "now-1h" | "now-24h" | "now-7d";
export interface ChartConfig {
	renderChart?: boolean;
	categories: Category[];
	height?: number;
	width?: number;
	dimensions?: {
		[key: string]: string | string[];
	};
	showLegend?: boolean;
	legendLabels?: string[];
	/**
	 * 2023.12.25 新增
	 * 是否垂直、单行展示图例
	 */
	verticalLegend?: boolean | VerticalLegendConfig;
	refreshInterval?: string;
	period?: {
		from: Period | string;
		to: Period | string;
	};
	step?: string;
	/**
	 * 自定义option的方法，可以在这里对option进行修改
	 * @param options
	 * @returns options
	 */
	optionFormatter?: (options: ECBasicOption) => ECBasicOption;
}
export interface VerticalLegendConfig {
	styles?: CSSProperties;
}
export interface MonitorChartProps {
	/**
	 * 图表配置文件，详情参数见 ChartConfig
	 */
	config: ChartConfig;
	region?: string;
	showType?: "drawer";
	createPolicyLinkConfig?: CreatePolicyLinkConfig;
	singleRow?: boolean;
	/**
	 * 图表模块ID，如 vpcGw
	 */
	chartKey?: string;
	categoryLayout?: "vertical" | "tab";
	/**
	 * 头部标题
	 */
	title?: string;
	/**
	 * 副标题
	 */
	subtitle?: string;
	/**
	 * 卡片是否显示为带边框样式
	 */
	cardBordered?: boolean;
	needPeriodFilter?: boolean;
	refresh?: boolean;
	style?: React.CSSProperties;
	className?: string;
	/**
	 * 用户自定义获取监控数据的方式
	 */
	getMonitorDataFC?: GetMonitorDataFC;
	/**
	 * 是否需要或许cwhistle单位体系
	 * 默认为true
	 * 如果为false，则不会对单位进行转换
	 */
	needCwhistleUnit?: boolean;
	/**
	 * 用户自定义头部筛选项
	 */
	customizeHeader?: CustomizedFilter;
	customizeSide?: CustomizedFilter;
	autoStep?: boolean;
	steps?: `${number}${StepDuration}`[];
	thumbnail?: ThumbnailConfig;
	/**
	 * 2023.12.27 新增
	 * 是否需要图例checkbox，默认为true
	 */
	needLegendCheckbox?: boolean;
}
export type StepDuration = "s" | "m" | "h" | "d" | "w" | "y";
export interface ThumbnailConfig extends ModalProps {
	show: boolean;
	stack: boolean;
	expandable: boolean;
	/**
	 * 缩略图宽度
	 */
	width?: number;
	/**
	 * 缩略图高度
	 */
	height?: number;
}
export interface CreatePolicyLinkConfig {
	show: boolean;
	product: string;
	module: string;
	name?: string;
}
export interface MonitorChartContextProps extends MonitorChartProps {
	showPattern?: string;
}
export interface DrawerChartProps extends MonitorChartContextProps {
	outerClickClosable?: boolean;
	onDrawerClose?(): void;
}
export interface AggregationOperator {
	operator: "sum" | "min" | "max" | "avg" | "group" | "stddev" | "stdvar" | "count" | "count_values" | "bottomk" | "topk" | "quantile" | "";
	clause?: "without" | "by" | "";
	labelList?: string[];
	parameter?: string | number;
}
export interface Unit {
	Id: string;
	CatalogId: number;
	Name: string;
	Alias: string;
	IsBase: 1 | 0;
	Operator: "*" | "/";
	Factor: string;
	RangeLeftValue: number;
	RangeRightValue: number;
	RangeValueDecimal: number;
	RangeInBase: number[];
	minValueInBase?: number;
	needFix?: boolean;
	Formatter?: string;
}
export interface UnitCatalog {
	Id: number;
	Name: string;
	Alias: string;
	Units?: Unit[];
}
declare function MonitorChart(props: MonitorChartProps): JSX.Element;
declare function showMonitorChart(el: HTMLElement, props: MonitorChartProps): void;
declare function showMonitorChartInDrawer(props: DrawerChartProps, el?: HTMLElement): void;
export interface FormattedValue {
	text: string;
	prefix?: string;
	suffix?: string;
}
declare const Monitor: {
	showMonitorChartInDrawer: typeof showMonitorChartInDrawer;
	showMonitorChart: typeof showMonitorChart;
	MonitorPanelBuilder: {
		build: (props: SideBarPanelProps, el?: HTMLElement) => void;
	};
	MonitorDetailBuilder: {
		build: (props: SideBarPanelProps, el: HTMLElement) => void;
	};
	MonitorChart: React.MemoExoticComponent<typeof MonitorChart>;
	readonly utils: {
		valueProcessor: ({ unit, unitCatalogs, value, asPrefix, needFormat, precision, }: {
			unit: string;
			value: number;
			unitCatalogs?: UnitCatalog[] | undefined;
			asPrefix?: boolean | undefined;
			needFormat?: boolean | undefined;
			precision?: number | undefined;
		}) => string | number | FormattedValue;
		getUnits: () => Promise<{
			Units: {
				minValueInBase: any;
				needFix: boolean;
				RangeInBase: any[];
				Id: string;
				CatalogId: number;
				Name: string;
				Alias: string;
				IsBase: 0 | 1;
				Operator: "*" | "/";
				Factor: string;
				RangeLeftValue: number;
				RangeRightValue: number;
				RangeValueDecimal: number;
				Formatter?: string | undefined;
			}[];
			Id: number;
			Name: string;
			Alias: string;
		}[] | undefined>;
		getDateTimeToTimestamp: (from: string, to: string) => {
			Start: number;
			End: number;
			Step: string;
		};
	};
};
export type MonitorProps = typeof Monitor;

export {
	Monitor as default,
};

export {};
