export interface IProps {
	cb: Function;
	reqData: any;
}
declare function showAuthModal({ cb, reqData }: IProps): Promise<unknown>;
export interface IPromiseStatusFun {
	resolve: (value: unknown) => void;
	reject: (reason?: any) => void;
}
export interface IShowAuthDigitalCertModalConfirmData extends IPromiseStatusFun {
	sign: string;
	uKeySn: string;
}
export interface IShowAuthDigitalCertModalProps {
	/**
	 * modal的标题
	 */
	title?: string;
	/**
	 * modal的描述信息
	 */
	description?: string;
	/**
	 * Ukey序列号[如果当前用户已经绑定了，需要传入用于检验]
	 */
	userBindSN?: string;
	/**
	 * 签名字符串【不传入签名字符串则不签名】
	 */
	signStr?: string;
	/**
	 * 确认回调
	 */
	confirm?: (data: IShowAuthDigitalCertModalConfirmData) => Promise<boolean>;
	/**
	 * 取消回调
	 */
	cancel?: (data: IPromiseStatusFun) => void;
	/**
	 * 云API请求原始入参
	 */
	reqData?: any;
}
declare function showAuthDigitalCertModal(props: IShowAuthDigitalCertModalProps): Promise<unknown>;
declare const AUTH: {
	showAuthModal: typeof showAuthModal;
	showAuthDigitalCertModal: typeof showAuthDigitalCertModal;
};
export type AuthProps = typeof AUTH;

export {
	AUTH as default,
};

export {};
