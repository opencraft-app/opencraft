export interface IProps {
  cb: Function;
  reqData: any;
}

// SecurityGroup / renderSecurityGroup
export interface Props {
  instanceId: string;
  type?: 'cvm' | 'clb' | 'eni'; // 默认cvm
  canBindDfw?: boolean; // 默认true
  mustBindDfw?: boolean; // 默认true
  isMultiple?: boolean; // 默认true
  disabledTips?: any;
  modalSortable?: boolean; // 编辑对话框是否可排序，默认false，380开始支持
}

// useBindSecurityGroupModal / openBindSGModal
export interface ModalProps {
  type: 'cvm' | 'clb' | 'eni';
  vpcId?: string; // 供ENI使用
  instanceId: string;
  onSubmit?: () => void; // 修改成功的回调
  boundSgIdList: string[]; // 已绑定的安全组id
  modalSortable?: boolean;
}

declare const Sg: {
  renderSecurityGroup: (props: Props) => JSX.Element | null;
  SecurityGroup: (props: Props) => JSX.Element | null;
  openBindSGModal: (props: ModalProps) => Promise<{
    done: boolean;
    res?: any;
  }>;
  useBindSecurityGroupModal: (props: ModalProps) => [JSX.Element, (v: boolean) => void];
};
export type SgProps = typeof Sg;

export { Sg as default };
