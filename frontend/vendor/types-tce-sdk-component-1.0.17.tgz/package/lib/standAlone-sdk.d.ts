declare function showIframeTips(): void;
declare const PROJECT: {
	showIframeTips: typeof showIframeTips;
};
export type StandAloneProps = typeof PROJECT;

export {
	PROJECT as default,
};

export {};
