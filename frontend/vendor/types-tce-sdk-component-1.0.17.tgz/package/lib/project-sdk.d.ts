declare const GroupAccount: {
	renderGroupSelect: (el: string, onChange: (value: any[]) => void, isRequired: boolean) => void;
	renderProjectSelect: (props: any) => void;
	renderProjectTreeSelect: (props: any) => void;
};
export type GroupAccountProps = typeof GroupAccount;

export {
	GroupAccount as default,
};

export {};
