import { TransformFirstLetterToLowerCase } from '@tencent/tce-sdk/lib/api';

export interface CamBreakWithDetailProps {
	/**
	 * operation 信息
	 */
	operation: string;
	/**
	 * resource 信息
	 */
	resource: string;
	/**
	 * requestId
	 */
	requestId?: string;
}
export interface CamBreakWithMessageProps {
	/**
	 * 失败信息
	 */
	message: string;
}
declare enum CamBreakTypeEnum {
	Default = 0,
	Tips = 1,
	Bubble = 2
}
export interface CamBreakType {
	type?: CamBreakTypeEnum;
}
export type CamBreakProps = CamBreakWithMessageProps | CamBreakWithDetailProps;
export type AddBreakOptions = CamBreakProps & {
	node: HTMLElement;
};
declare function addCamBreak(options: AddBreakOptions): void;
export type ShowBreakModalOptions = CamBreakProps & {
	onClose?: () => void;
};
declare function showBreakModal(options: ShowBreakModalOptions): void;
declare function addCamBreakIcon(options: AddBreakOptions): void;
declare function showBreakTips(props: CamBreakProps): void;
export interface ShowRoleGrantDialogProps {
	s_url: string;
	serviceType: string;
	roleName: string;
	policyName: string;
	functionDesc: string;
	target?: string;
}
declare function showRoleGrantDialog(options: ShowRoleGrantDialogProps): Promise<unknown>;
/**
 * GetRole接口入参定义
 */
export interface GetRoleReq {
	/**
	 * 角色 ID，用于指定角色，入参 RoleId 与 RoleName 二选一
	 */
	RoleId?: string;
	/**
	 * 角色名，用于指定角色，入参 RoleId 与 RoleName 二选一
	 */
	RoleName?: string;
}
export interface CamGetRoleRes {
	code: number;
	message?: string;
}
declare function haveRole(req: TransformFirstLetterToLowerCase<GetRoleReq>): Promise<CamGetRoleRes>;
export interface HavePoliciesParam {
	roleName: string;
	policies: string | string[];
}
export interface CamListAttachedRolePoliciesRes extends CamGetRoleRes {
	data?: {
		attachQueue: string[];
		notAttachQueue: string[];
	};
}
declare function havePolicies(req: HavePoliciesParam): Promise<CamListAttachedRolePoliciesRes>;
declare const CAM: {
	showBreakModal: typeof showBreakModal;
	addCamBreak: typeof addCamBreak;
	showBreakTips: typeof showBreakTips;
	addCamBreakIcon: typeof addCamBreakIcon;
	showRoleGrantDialog: typeof showRoleGrantDialog;
	haveRole: typeof haveRole;
	havePolicies: typeof havePolicies;
	CAMBreak: (props: CamBreakProps & CamBreakType) => JSX.Element | null;
};
export type CamProps = typeof CAM;

export {
	CAM as default,
};

export {};
