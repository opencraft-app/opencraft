export interface CallBackProps {
	diskUsage: string;
	diskSize: number;
	diskType: string;
	diskTypeLabel: string;
	diskNum: number;
}
export interface BackupPointSelectProps {
	instanceId?: string;
	backupGroupId?: string;
	zone: string;
	region: string;
	isOcloud?: boolean;
	isOperationCvm?: boolean;
	onCallChange: (backData: {
		diskData: CallBackProps[];
		backgroupId: string;
	}) => void;
	imageId: string;
}
export interface BackupProps extends BackupPointSelectProps {
	node: ReactDOM.Container;
}
declare const PROJECT: {
	showTagTable(props: BackupProps): void;
};
export type CbsProps = typeof PROJECT;

export {
	PROJECT as default,
};

export {};
