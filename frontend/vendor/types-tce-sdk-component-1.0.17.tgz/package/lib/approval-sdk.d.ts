declare function showApprovalModal(ApprovalDocID: number | string, data: any): Promise<unknown>;
declare const APPROVAL: {
	showApprovalModal: typeof showApprovalModal;
};
export type ApprovalProps = typeof APPROVAL;

export {
	APPROVAL as default,
};

export {};
