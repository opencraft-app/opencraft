[@tencent/watermarkjs](README.md) / Modules

# @tencent/watermarkjs

## Table of contents

### Modules

- [canvas](modules/canvas.md)
- [component](modules/component.md)
- [main](modules/main.md)
- [type](modules/type.md)
