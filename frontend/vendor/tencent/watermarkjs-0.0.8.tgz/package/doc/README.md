@tencent/watermarkjs / [Modules](modules.md)

# @tencent/watermarkjs
更安全的网页水印生成工具

### 特性
* 基于 Web Component，支持自定义元素标签名
* 支持 Shadow Dom，防干扰，更隐蔽
* 支持监听 DOM 变化，重新生成，防攻击

### 使用
安装：
```
tnpm install @tencent/watermarkjs
```

使用：
```js
    import Watermarkjs from '@tencent/watermarkjs'
    
    new Watermarkjs(TEXT,OPTIONS);
```

[API 文档](https://git.woa.com/fransli/watermarkjs/blob/master/doc/classes/main.default.md)
