[@tencent/watermarkjs](../README.md) / [Modules](../modules.md) / [main](../modules/main.md) / default

# Class: default

[main](../modules/main.md).default

watermarkjs 水印生成工具

## Table of contents

### Constructors

- [constructor](main.default.md#constructor)

### Properties

- [content](main.default.md#content)
- [node](main.default.md#node)
- [opts](main.default.md#opts)

### Methods

- [createNode](main.default.md#createnode)
- [init](main.default.md#init)
- [insertNode](main.default.md#insertnode)
- [mutationObserverInit](main.default.md#mutationobserverinit)
- [startObserving](main.default.md#startobserving)

## Constructors

### constructor

• **new default**(`content`, `options?`)

**`content`** 水印信息

**`options`** 配置项

#### Parameters

| Name | Type |
| :------ | :------ |
| `content` | `string` |
| `options` | `Partial`<[`IOptions`](../interfaces/type.IOptions.md)\> |

#### Defined in

src/main.ts:17

## Properties

### content

• `Private` `Readonly` **content**: `string`

#### Defined in

src/main.ts:8

___

### node

• `Private` **node**: `HTMLElement`

#### Defined in

src/main.ts:9

___

### opts

• `Private` **opts**: `Partial`<[`IOptions`](../interfaces/type.IOptions.md)\>

#### Defined in

src/main.ts:10

## Methods

### createNode

▸ `Private` **createNode**(): `HTMLElement`

#### Returns

`HTMLElement`

#### Defined in

src/main.ts:37

___

### init

▸ `Private` **init**(): `void`

初始化

#### Returns

`void`

#### Defined in

src/main.ts:28

___

### insertNode

▸ `Private` **insertNode**(): `void`

插入节点

#### Returns

`void`

#### Defined in

src/main.ts:58

___

### mutationObserverInit

▸ `Private` **mutationObserverInit**(): `MutationObserver`

初始化 DOM 观察器

#### Returns

`MutationObserver`

#### Defined in

src/main.ts:69

___

### startObserving

▸ `Private` **startObserving**(`observer`): `void`

开启 DOM 观察

#### Parameters

| Name | Type |
| :------ | :------ |
| `observer` | `MutationObserver` |

#### Returns

`void`

#### Defined in

src/main.ts:90
