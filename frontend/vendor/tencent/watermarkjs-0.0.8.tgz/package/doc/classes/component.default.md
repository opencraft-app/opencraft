[@tencent/watermarkjs](../README.md) / [Modules](../modules.md) / [component](../modules/component.md) / default

# Class: default

[component](../modules/component.md).default

## Hierarchy

- `HTMLElement`

  ↳ **`default`**

## Table of contents

### Constructors

- [constructor](component.default.md#constructor)

### Properties

- [ATTRIBUTE\_NODE](component.default.md#attribute_node)
- [CDATA\_SECTION\_NODE](component.default.md#cdata_section_node)
- [COMMENT\_NODE](component.default.md#comment_node)
- [DOCUMENT\_FRAGMENT\_NODE](component.default.md#document_fragment_node)
- [DOCUMENT\_NODE](component.default.md#document_node)
- [DOCUMENT\_POSITION\_CONTAINED\_BY](component.default.md#document_position_contained_by)
- [DOCUMENT\_POSITION\_CONTAINS](component.default.md#document_position_contains)
- [DOCUMENT\_POSITION\_DISCONNECTED](component.default.md#document_position_disconnected)
- [DOCUMENT\_POSITION\_FOLLOWING](component.default.md#document_position_following)
- [DOCUMENT\_POSITION\_IMPLEMENTATION\_SPECIFIC](component.default.md#document_position_implementation_specific)
- [DOCUMENT\_POSITION\_PRECEDING](component.default.md#document_position_preceding)
- [DOCUMENT\_TYPE\_NODE](component.default.md#document_type_node)
- [ELEMENT\_NODE](component.default.md#element_node)
- [ENTITY\_NODE](component.default.md#entity_node)
- [ENTITY\_REFERENCE\_NODE](component.default.md#entity_reference_node)
- [NOTATION\_NODE](component.default.md#notation_node)
- [PROCESSING\_INSTRUCTION\_NODE](component.default.md#processing_instruction_node)
- [TEXT\_NODE](component.default.md#text_node)
- [accessKey](component.default.md#accesskey)
- [accessKeyLabel](component.default.md#accesskeylabel)
- [ariaAtomic](component.default.md#ariaatomic)
- [ariaAutoComplete](component.default.md#ariaautocomplete)
- [ariaBusy](component.default.md#ariabusy)
- [ariaChecked](component.default.md#ariachecked)
- [ariaColCount](component.default.md#ariacolcount)
- [ariaColIndex](component.default.md#ariacolindex)
- [ariaColSpan](component.default.md#ariacolspan)
- [ariaCurrent](component.default.md#ariacurrent)
- [ariaDisabled](component.default.md#ariadisabled)
- [ariaExpanded](component.default.md#ariaexpanded)
- [ariaHasPopup](component.default.md#ariahaspopup)
- [ariaHidden](component.default.md#ariahidden)
- [ariaKeyShortcuts](component.default.md#ariakeyshortcuts)
- [ariaLabel](component.default.md#arialabel)
- [ariaLevel](component.default.md#arialevel)
- [ariaLive](component.default.md#arialive)
- [ariaModal](component.default.md#ariamodal)
- [ariaMultiLine](component.default.md#ariamultiline)
- [ariaMultiSelectable](component.default.md#ariamultiselectable)
- [ariaOrientation](component.default.md#ariaorientation)
- [ariaPlaceholder](component.default.md#ariaplaceholder)
- [ariaPosInSet](component.default.md#ariaposinset)
- [ariaPressed](component.default.md#ariapressed)
- [ariaReadOnly](component.default.md#ariareadonly)
- [ariaRequired](component.default.md#ariarequired)
- [ariaRoleDescription](component.default.md#ariaroledescription)
- [ariaRowCount](component.default.md#ariarowcount)
- [ariaRowIndex](component.default.md#ariarowindex)
- [ariaRowSpan](component.default.md#ariarowspan)
- [ariaSelected](component.default.md#ariaselected)
- [ariaSetSize](component.default.md#ariasetsize)
- [ariaSort](component.default.md#ariasort)
- [ariaValueMax](component.default.md#ariavaluemax)
- [ariaValueMin](component.default.md#ariavaluemin)
- [ariaValueNow](component.default.md#ariavaluenow)
- [ariaValueText](component.default.md#ariavaluetext)
- [assignedSlot](component.default.md#assignedslot)
- [attributes](component.default.md#attributes)
- [autocapitalize](component.default.md#autocapitalize)
- [autofocus](component.default.md#autofocus)
- [baseURI](component.default.md#baseuri)
- [childElementCount](component.default.md#childelementcount)
- [childNodes](component.default.md#childnodes)
- [children](component.default.md#children)
- [classList](component.default.md#classlist)
- [className](component.default.md#classname)
- [clientHeight](component.default.md#clientheight)
- [clientLeft](component.default.md#clientleft)
- [clientTop](component.default.md#clienttop)
- [clientWidth](component.default.md#clientwidth)
- [content](component.default.md#content)
- [contentEditable](component.default.md#contenteditable)
- [dataset](component.default.md#dataset)
- [dir](component.default.md#dir)
- [draggable](component.default.md#draggable)
- [enterKeyHint](component.default.md#enterkeyhint)
- [firstChild](component.default.md#firstchild)
- [firstElementChild](component.default.md#firstelementchild)
- [hidden](component.default.md#hidden)
- [id](component.default.md#id)
- [innerHTML](component.default.md#innerhtml)
- [innerText](component.default.md#innertext)
- [inputMode](component.default.md#inputmode)
- [isConnected](component.default.md#isconnected)
- [isContentEditable](component.default.md#iscontenteditable)
- [lang](component.default.md#lang)
- [lastChild](component.default.md#lastchild)
- [lastElementChild](component.default.md#lastelementchild)
- [localName](component.default.md#localname)
- [namespaceURI](component.default.md#namespaceuri)
- [nextElementSibling](component.default.md#nextelementsibling)
- [nextSibling](component.default.md#nextsibling)
- [nodeName](component.default.md#nodename)
- [nodeType](component.default.md#nodetype)
- [nodeValue](component.default.md#nodevalue)
- [nonce](component.default.md#nonce)
- [offsetHeight](component.default.md#offsetheight)
- [offsetLeft](component.default.md#offsetleft)
- [offsetParent](component.default.md#offsetparent)
- [offsetTop](component.default.md#offsettop)
- [offsetWidth](component.default.md#offsetwidth)
- [onabort](component.default.md#onabort)
- [onanimationcancel](component.default.md#onanimationcancel)
- [onanimationend](component.default.md#onanimationend)
- [onanimationiteration](component.default.md#onanimationiteration)
- [onanimationstart](component.default.md#onanimationstart)
- [onauxclick](component.default.md#onauxclick)
- [onblur](component.default.md#onblur)
- [oncanplay](component.default.md#oncanplay)
- [oncanplaythrough](component.default.md#oncanplaythrough)
- [onchange](component.default.md#onchange)
- [onclick](component.default.md#onclick)
- [onclose](component.default.md#onclose)
- [oncontextmenu](component.default.md#oncontextmenu)
- [oncopy](component.default.md#oncopy)
- [oncuechange](component.default.md#oncuechange)
- [oncut](component.default.md#oncut)
- [ondblclick](component.default.md#ondblclick)
- [ondrag](component.default.md#ondrag)
- [ondragend](component.default.md#ondragend)
- [ondragenter](component.default.md#ondragenter)
- [ondragleave](component.default.md#ondragleave)
- [ondragover](component.default.md#ondragover)
- [ondragstart](component.default.md#ondragstart)
- [ondrop](component.default.md#ondrop)
- [ondurationchange](component.default.md#ondurationchange)
- [onemptied](component.default.md#onemptied)
- [onended](component.default.md#onended)
- [onerror](component.default.md#onerror)
- [onfocus](component.default.md#onfocus)
- [onformdata](component.default.md#onformdata)
- [onfullscreenchange](component.default.md#onfullscreenchange)
- [onfullscreenerror](component.default.md#onfullscreenerror)
- [ongotpointercapture](component.default.md#ongotpointercapture)
- [oninput](component.default.md#oninput)
- [oninvalid](component.default.md#oninvalid)
- [onkeydown](component.default.md#onkeydown)
- [onkeypress](component.default.md#onkeypress)
- [onkeyup](component.default.md#onkeyup)
- [onload](component.default.md#onload)
- [onloadeddata](component.default.md#onloadeddata)
- [onloadedmetadata](component.default.md#onloadedmetadata)
- [onloadstart](component.default.md#onloadstart)
- [onlostpointercapture](component.default.md#onlostpointercapture)
- [onmousedown](component.default.md#onmousedown)
- [onmouseenter](component.default.md#onmouseenter)
- [onmouseleave](component.default.md#onmouseleave)
- [onmousemove](component.default.md#onmousemove)
- [onmouseout](component.default.md#onmouseout)
- [onmouseover](component.default.md#onmouseover)
- [onmouseup](component.default.md#onmouseup)
- [onpaste](component.default.md#onpaste)
- [onpause](component.default.md#onpause)
- [onplay](component.default.md#onplay)
- [onplaying](component.default.md#onplaying)
- [onpointercancel](component.default.md#onpointercancel)
- [onpointerdown](component.default.md#onpointerdown)
- [onpointerenter](component.default.md#onpointerenter)
- [onpointerleave](component.default.md#onpointerleave)
- [onpointermove](component.default.md#onpointermove)
- [onpointerout](component.default.md#onpointerout)
- [onpointerover](component.default.md#onpointerover)
- [onpointerup](component.default.md#onpointerup)
- [onprogress](component.default.md#onprogress)
- [onratechange](component.default.md#onratechange)
- [onreset](component.default.md#onreset)
- [onresize](component.default.md#onresize)
- [onscroll](component.default.md#onscroll)
- [onseeked](component.default.md#onseeked)
- [onseeking](component.default.md#onseeking)
- [onselect](component.default.md#onselect)
- [onselectionchange](component.default.md#onselectionchange)
- [onselectstart](component.default.md#onselectstart)
- [onstalled](component.default.md#onstalled)
- [onsubmit](component.default.md#onsubmit)
- [onsuspend](component.default.md#onsuspend)
- [ontimeupdate](component.default.md#ontimeupdate)
- [ontoggle](component.default.md#ontoggle)
- [ontouchcancel](component.default.md#ontouchcancel)
- [ontouchend](component.default.md#ontouchend)
- [ontouchmove](component.default.md#ontouchmove)
- [ontouchstart](component.default.md#ontouchstart)
- [ontransitioncancel](component.default.md#ontransitioncancel)
- [ontransitionend](component.default.md#ontransitionend)
- [ontransitionrun](component.default.md#ontransitionrun)
- [ontransitionstart](component.default.md#ontransitionstart)
- [onvolumechange](component.default.md#onvolumechange)
- [onwaiting](component.default.md#onwaiting)
- [onwebkitanimationend](component.default.md#onwebkitanimationend)
- [onwebkitanimationiteration](component.default.md#onwebkitanimationiteration)
- [onwebkitanimationstart](component.default.md#onwebkitanimationstart)
- [onwebkittransitionend](component.default.md#onwebkittransitionend)
- [onwheel](component.default.md#onwheel)
- [opts](component.default.md#opts)
- [outerHTML](component.default.md#outerhtml)
- [outerText](component.default.md#outertext)
- [ownerDocument](component.default.md#ownerdocument)
- [parentElement](component.default.md#parentelement)
- [parentNode](component.default.md#parentnode)
- [part](component.default.md#part)
- [prefix](component.default.md#prefix)
- [previousElementSibling](component.default.md#previouselementsibling)
- [previousSibling](component.default.md#previoussibling)
- [scrollHeight](component.default.md#scrollheight)
- [scrollLeft](component.default.md#scrollleft)
- [scrollTop](component.default.md#scrolltop)
- [scrollWidth](component.default.md#scrollwidth)
- [shadowRoot](component.default.md#shadowroot)
- [slot](component.default.md#slot)
- [spellcheck](component.default.md#spellcheck)
- [style](component.default.md#style)
- [tabIndex](component.default.md#tabindex)
- [tagName](component.default.md#tagname)
- [textContent](component.default.md#textcontent)
- [title](component.default.md#title)
- [translate](component.default.md#translate)
- [watermarkInfo](component.default.md#watermarkinfo)
- [wmShadowRoot](component.default.md#wmshadowroot)

### Methods

- [addEventListener](component.default.md#addeventlistener)
- [after](component.default.md#after)
- [animate](component.default.md#animate)
- [append](component.default.md#append)
- [appendChild](component.default.md#appendchild)
- [attachInternals](component.default.md#attachinternals)
- [attachShadow](component.default.md#attachshadow)
- [before](component.default.md#before)
- [blur](component.default.md#blur)
- [click](component.default.md#click)
- [cloneNode](component.default.md#clonenode)
- [closest](component.default.md#closest)
- [compareDocumentPosition](component.default.md#comparedocumentposition)
- [contains](component.default.md#contains)
- [dispatchEvent](component.default.md#dispatchevent)
- [focus](component.default.md#focus)
- [getAnimations](component.default.md#getanimations)
- [getAttribute](component.default.md#getattribute)
- [getAttributeNS](component.default.md#getattributens)
- [getAttributeNames](component.default.md#getattributenames)
- [getAttributeNode](component.default.md#getattributenode)
- [getAttributeNodeNS](component.default.md#getattributenodens)
- [getBoundingClientRect](component.default.md#getboundingclientrect)
- [getClientRects](component.default.md#getclientrects)
- [getElementsByClassName](component.default.md#getelementsbyclassname)
- [getElementsByTagName](component.default.md#getelementsbytagname)
- [getElementsByTagNameNS](component.default.md#getelementsbytagnamens)
- [getRootNode](component.default.md#getrootnode)
- [getWaterMarkerInfo](component.default.md#getwatermarkerinfo)
- [hasAttribute](component.default.md#hasattribute)
- [hasAttributeNS](component.default.md#hasattributens)
- [hasAttributes](component.default.md#hasattributes)
- [hasChildNodes](component.default.md#haschildnodes)
- [hasPointerCapture](component.default.md#haspointercapture)
- [insertAdjacentElement](component.default.md#insertadjacentelement)
- [insertAdjacentHTML](component.default.md#insertadjacenthtml)
- [insertAdjacentText](component.default.md#insertadjacenttext)
- [insertBefore](component.default.md#insertbefore)
- [isDefaultNamespace](component.default.md#isdefaultnamespace)
- [isEqualNode](component.default.md#isequalnode)
- [isSameNode](component.default.md#issamenode)
- [lookupNamespaceURI](component.default.md#lookupnamespaceuri)
- [lookupPrefix](component.default.md#lookupprefix)
- [matches](component.default.md#matches)
- [normalize](component.default.md#normalize)
- [prepend](component.default.md#prepend)
- [querySelector](component.default.md#queryselector)
- [querySelectorAll](component.default.md#queryselectorall)
- [releasePointerCapture](component.default.md#releasepointercapture)
- [remove](component.default.md#remove)
- [removeAttribute](component.default.md#removeattribute)
- [removeAttributeNS](component.default.md#removeattributens)
- [removeAttributeNode](component.default.md#removeattributenode)
- [removeChild](component.default.md#removechild)
- [removeEventListener](component.default.md#removeeventlistener)
- [replaceChild](component.default.md#replacechild)
- [replaceChildren](component.default.md#replacechildren)
- [replaceWith](component.default.md#replacewith)
- [requestFullscreen](component.default.md#requestfullscreen)
- [requestPointerLock](component.default.md#requestpointerlock)
- [scroll](component.default.md#scroll)
- [scrollBy](component.default.md#scrollby)
- [scrollIntoView](component.default.md#scrollintoview)
- [scrollTo](component.default.md#scrollto)
- [setAttribute](component.default.md#setattribute)
- [setAttributeNS](component.default.md#setattributens)
- [setAttributeNode](component.default.md#setattributenode)
- [setAttributeNodeNS](component.default.md#setattributenodens)
- [setPointerCapture](component.default.md#setpointercapture)
- [setShadowRoot](component.default.md#setshadowroot)
- [startObserving](component.default.md#startobserving)
- [toggleAttribute](component.default.md#toggleattribute)
- [webkitMatchesSelector](component.default.md#webkitmatchesselector)

## Constructors

### constructor

• **new default**()

#### Overrides

HTMLElement.constructor

#### Defined in

src/component.ts:13

## Properties

### ATTRIBUTE\_NODE

• `Readonly` **ATTRIBUTE\_NODE**: `number`

#### Inherited from

HTMLElement.ATTRIBUTE\_NODE

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9696

___

### CDATA\_SECTION\_NODE

• `Readonly` **CDATA\_SECTION\_NODE**: `number`

node is a CDATASection node.

#### Inherited from

HTMLElement.CDATA\_SECTION\_NODE

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9698

___

### COMMENT\_NODE

• `Readonly` **COMMENT\_NODE**: `number`

node is a Comment node.

#### Inherited from

HTMLElement.COMMENT\_NODE

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9700

___

### DOCUMENT\_FRAGMENT\_NODE

• `Readonly` **DOCUMENT\_FRAGMENT\_NODE**: `number`

node is a DocumentFragment node.

#### Inherited from

HTMLElement.DOCUMENT\_FRAGMENT\_NODE

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9702

___

### DOCUMENT\_NODE

• `Readonly` **DOCUMENT\_NODE**: `number`

node is a document.

#### Inherited from

HTMLElement.DOCUMENT\_NODE

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9704

___

### DOCUMENT\_POSITION\_CONTAINED\_BY

• `Readonly` **DOCUMENT\_POSITION\_CONTAINED\_BY**: `number`

Set when other is a descendant of node.

#### Inherited from

HTMLElement.DOCUMENT\_POSITION\_CONTAINED\_BY

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9706

___

### DOCUMENT\_POSITION\_CONTAINS

• `Readonly` **DOCUMENT\_POSITION\_CONTAINS**: `number`

Set when other is an ancestor of node.

#### Inherited from

HTMLElement.DOCUMENT\_POSITION\_CONTAINS

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9708

___

### DOCUMENT\_POSITION\_DISCONNECTED

• `Readonly` **DOCUMENT\_POSITION\_DISCONNECTED**: `number`

Set when node and other are not in the same tree.

#### Inherited from

HTMLElement.DOCUMENT\_POSITION\_DISCONNECTED

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9710

___

### DOCUMENT\_POSITION\_FOLLOWING

• `Readonly` **DOCUMENT\_POSITION\_FOLLOWING**: `number`

Set when other is following node.

#### Inherited from

HTMLElement.DOCUMENT\_POSITION\_FOLLOWING

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9712

___

### DOCUMENT\_POSITION\_IMPLEMENTATION\_SPECIFIC

• `Readonly` **DOCUMENT\_POSITION\_IMPLEMENTATION\_SPECIFIC**: `number`

#### Inherited from

HTMLElement.DOCUMENT\_POSITION\_IMPLEMENTATION\_SPECIFIC

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9713

___

### DOCUMENT\_POSITION\_PRECEDING

• `Readonly` **DOCUMENT\_POSITION\_PRECEDING**: `number`

Set when other is preceding node.

#### Inherited from

HTMLElement.DOCUMENT\_POSITION\_PRECEDING

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9715

___

### DOCUMENT\_TYPE\_NODE

• `Readonly` **DOCUMENT\_TYPE\_NODE**: `number`

node is a doctype.

#### Inherited from

HTMLElement.DOCUMENT\_TYPE\_NODE

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9717

___

### ELEMENT\_NODE

• `Readonly` **ELEMENT\_NODE**: `number`

node is an element.

#### Inherited from

HTMLElement.ELEMENT\_NODE

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9719

___

### ENTITY\_NODE

• `Readonly` **ENTITY\_NODE**: `number`

#### Inherited from

HTMLElement.ENTITY\_NODE

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9720

___

### ENTITY\_REFERENCE\_NODE

• `Readonly` **ENTITY\_REFERENCE\_NODE**: `number`

#### Inherited from

HTMLElement.ENTITY\_REFERENCE\_NODE

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9721

___

### NOTATION\_NODE

• `Readonly` **NOTATION\_NODE**: `number`

#### Inherited from

HTMLElement.NOTATION\_NODE

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9722

___

### PROCESSING\_INSTRUCTION\_NODE

• `Readonly` **PROCESSING\_INSTRUCTION\_NODE**: `number`

node is a ProcessingInstruction node.

#### Inherited from

HTMLElement.PROCESSING\_INSTRUCTION\_NODE

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9724

___

### TEXT\_NODE

• `Readonly` **TEXT\_NODE**: `number`

node is a Text node.

#### Inherited from

HTMLElement.TEXT\_NODE

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9726

___

### accessKey

• **accessKey**: `string`

#### Inherited from

HTMLElement.accessKey

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:6133

___

### accessKeyLabel

• `Readonly` **accessKeyLabel**: `string`

#### Inherited from

HTMLElement.accessKeyLabel

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:6134

___

### ariaAtomic

• **ariaAtomic**: `string`

#### Inherited from

HTMLElement.ariaAtomic

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1827

___

### ariaAutoComplete

• **ariaAutoComplete**: `string`

#### Inherited from

HTMLElement.ariaAutoComplete

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1828

___

### ariaBusy

• **ariaBusy**: `string`

#### Inherited from

HTMLElement.ariaBusy

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1829

___

### ariaChecked

• **ariaChecked**: `string`

#### Inherited from

HTMLElement.ariaChecked

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1830

___

### ariaColCount

• **ariaColCount**: `string`

#### Inherited from

HTMLElement.ariaColCount

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1831

___

### ariaColIndex

• **ariaColIndex**: `string`

#### Inherited from

HTMLElement.ariaColIndex

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1832

___

### ariaColSpan

• **ariaColSpan**: `string`

#### Inherited from

HTMLElement.ariaColSpan

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1833

___

### ariaCurrent

• **ariaCurrent**: `string`

#### Inherited from

HTMLElement.ariaCurrent

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1834

___

### ariaDisabled

• **ariaDisabled**: `string`

#### Inherited from

HTMLElement.ariaDisabled

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1835

___

### ariaExpanded

• **ariaExpanded**: `string`

#### Inherited from

HTMLElement.ariaExpanded

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1836

___

### ariaHasPopup

• **ariaHasPopup**: `string`

#### Inherited from

HTMLElement.ariaHasPopup

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1837

___

### ariaHidden

• **ariaHidden**: `string`

#### Inherited from

HTMLElement.ariaHidden

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1838

___

### ariaKeyShortcuts

• **ariaKeyShortcuts**: `string`

#### Inherited from

HTMLElement.ariaKeyShortcuts

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1839

___

### ariaLabel

• **ariaLabel**: `string`

#### Inherited from

HTMLElement.ariaLabel

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1840

___

### ariaLevel

• **ariaLevel**: `string`

#### Inherited from

HTMLElement.ariaLevel

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1841

___

### ariaLive

• **ariaLive**: `string`

#### Inherited from

HTMLElement.ariaLive

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1842

___

### ariaModal

• **ariaModal**: `string`

#### Inherited from

HTMLElement.ariaModal

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1843

___

### ariaMultiLine

• **ariaMultiLine**: `string`

#### Inherited from

HTMLElement.ariaMultiLine

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1844

___

### ariaMultiSelectable

• **ariaMultiSelectable**: `string`

#### Inherited from

HTMLElement.ariaMultiSelectable

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1845

___

### ariaOrientation

• **ariaOrientation**: `string`

#### Inherited from

HTMLElement.ariaOrientation

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1846

___

### ariaPlaceholder

• **ariaPlaceholder**: `string`

#### Inherited from

HTMLElement.ariaPlaceholder

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1847

___

### ariaPosInSet

• **ariaPosInSet**: `string`

#### Inherited from

HTMLElement.ariaPosInSet

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1848

___

### ariaPressed

• **ariaPressed**: `string`

#### Inherited from

HTMLElement.ariaPressed

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1849

___

### ariaReadOnly

• **ariaReadOnly**: `string`

#### Inherited from

HTMLElement.ariaReadOnly

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1850

___

### ariaRequired

• **ariaRequired**: `string`

#### Inherited from

HTMLElement.ariaRequired

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1851

___

### ariaRoleDescription

• **ariaRoleDescription**: `string`

#### Inherited from

HTMLElement.ariaRoleDescription

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1852

___

### ariaRowCount

• **ariaRowCount**: `string`

#### Inherited from

HTMLElement.ariaRowCount

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1853

___

### ariaRowIndex

• **ariaRowIndex**: `string`

#### Inherited from

HTMLElement.ariaRowIndex

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1854

___

### ariaRowSpan

• **ariaRowSpan**: `string`

#### Inherited from

HTMLElement.ariaRowSpan

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1855

___

### ariaSelected

• **ariaSelected**: `string`

#### Inherited from

HTMLElement.ariaSelected

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1856

___

### ariaSetSize

• **ariaSetSize**: `string`

#### Inherited from

HTMLElement.ariaSetSize

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1857

___

### ariaSort

• **ariaSort**: `string`

#### Inherited from

HTMLElement.ariaSort

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1858

___

### ariaValueMax

• **ariaValueMax**: `string`

#### Inherited from

HTMLElement.ariaValueMax

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1859

___

### ariaValueMin

• **ariaValueMin**: `string`

#### Inherited from

HTMLElement.ariaValueMin

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1860

___

### ariaValueNow

• **ariaValueNow**: `string`

#### Inherited from

HTMLElement.ariaValueNow

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1861

___

### ariaValueText

• **ariaValueText**: `string`

#### Inherited from

HTMLElement.ariaValueText

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1862

___

### assignedSlot

• `Readonly` **assignedSlot**: ``null`` \| `HTMLSlotElement`

#### Inherited from

HTMLElement.assignedSlot

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:13103

___

### attributes

• `Readonly` **attributes**: `NamedNodeMap`

#### Inherited from

HTMLElement.attributes

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4720

___

### autocapitalize

• **autocapitalize**: `string`

#### Inherited from

HTMLElement.autocapitalize

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:6135

___

### autofocus

• **autofocus**: `boolean`

#### Inherited from

HTMLElement.autofocus

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:7335

___

### baseURI

• `Readonly` **baseURI**: `string`

Returns node's node document's document base URL.

#### Inherited from

HTMLElement.baseURI

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9649

___

### childElementCount

• `Readonly` **childElementCount**: `number`

#### Inherited from

HTMLElement.childElementCount

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:10014

___

### childNodes

• `Readonly` **childNodes**: `NodeListOf`<`ChildNode`\>

Returns the children.

#### Inherited from

HTMLElement.childNodes

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9651

___

### children

• `Readonly` **children**: `HTMLCollection`

Returns the child elements.

#### Inherited from

HTMLElement.children

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:10016

___

### classList

• `Readonly` **classList**: `DOMTokenList`

Allows for manipulation of element's class content attribute as a set of whitespace-separated tokens through a DOMTokenList object.

#### Inherited from

HTMLElement.classList

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4722

___

### className

• **className**: `string`

Returns the value of element's class content attribute. Can be set to change it.

#### Inherited from

HTMLElement.className

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4724

___

### clientHeight

• `Readonly` **clientHeight**: `number`

#### Inherited from

HTMLElement.clientHeight

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4725

___

### clientLeft

• `Readonly` **clientLeft**: `number`

#### Inherited from

HTMLElement.clientLeft

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4726

___

### clientTop

• `Readonly` **clientTop**: `number`

#### Inherited from

HTMLElement.clientTop

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4727

___

### clientWidth

• `Readonly` **clientWidth**: `number`

#### Inherited from

HTMLElement.clientWidth

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4728

___

### content

• `Private` `Readonly` **content**: `string`

#### Defined in

src/component.ts:6

___

### contentEditable

• **contentEditable**: `string`

#### Inherited from

HTMLElement.contentEditable

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4839

___

### dataset

• `Readonly` **dataset**: `DOMStringMap`

#### Inherited from

HTMLElement.dataset

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:7336

___

### dir

• **dir**: `string`

#### Inherited from

HTMLElement.dir

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:6136

___

### draggable

• **draggable**: `boolean`

#### Inherited from

HTMLElement.draggable

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:6137

___

### enterKeyHint

• **enterKeyHint**: `string`

#### Inherited from

HTMLElement.enterKeyHint

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4840

___

### firstChild

• `Readonly` **firstChild**: ``null`` \| `ChildNode`

Returns the first child.

#### Inherited from

HTMLElement.firstChild

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9653

___

### firstElementChild

• `Readonly` **firstElementChild**: ``null`` \| `Element`

Returns the first child that is an element, and null otherwise.

#### Inherited from

HTMLElement.firstElementChild

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:10018

___

### hidden

• **hidden**: `boolean`

#### Inherited from

HTMLElement.hidden

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:6138

___

### id

• **id**: `string`

Returns the value of element's id content attribute. Can be set to change it.

#### Inherited from

HTMLElement.id

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4730

___

### innerHTML

• **innerHTML**: `string`

#### Inherited from

HTMLElement.innerHTML

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:8682

___

### innerText

• **innerText**: `string`

#### Inherited from

HTMLElement.innerText

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:6139

___

### inputMode

• **inputMode**: `string`

#### Inherited from

HTMLElement.inputMode

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4841

___

### isConnected

• `Readonly` **isConnected**: `boolean`

Returns true if node is connected and false otherwise.

#### Inherited from

HTMLElement.isConnected

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9655

___

### isContentEditable

• `Readonly` **isContentEditable**: `boolean`

#### Inherited from

HTMLElement.isContentEditable

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4842

___

### lang

• **lang**: `string`

#### Inherited from

HTMLElement.lang

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:6140

___

### lastChild

• `Readonly` **lastChild**: ``null`` \| `ChildNode`

Returns the last child.

#### Inherited from

HTMLElement.lastChild

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9657

___

### lastElementChild

• `Readonly` **lastElementChild**: ``null`` \| `Element`

Returns the last child that is an element, and null otherwise.

#### Inherited from

HTMLElement.lastElementChild

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:10020

___

### localName

• `Readonly` **localName**: `string`

Returns the local name.

#### Inherited from

HTMLElement.localName

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4732

___

### namespaceURI

• `Readonly` **namespaceURI**: ``null`` \| `string`

Returns the namespace.

#### Inherited from

HTMLElement.namespaceURI

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4734

___

### nextElementSibling

• `Readonly` **nextElementSibling**: ``null`` \| `Element`

Returns the first following sibling that is an element, and null otherwise.

#### Inherited from

HTMLElement.nextElementSibling

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9816

___

### nextSibling

• `Readonly` **nextSibling**: ``null`` \| `ChildNode`

Returns the next sibling.

#### Inherited from

HTMLElement.nextSibling

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9659

___

### nodeName

• `Readonly` **nodeName**: `string`

Returns a string appropriate for the type of node.

#### Inherited from

HTMLElement.nodeName

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9661

___

### nodeType

• `Readonly` **nodeType**: `number`

Returns the type of node.

#### Inherited from

HTMLElement.nodeType

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9663

___

### nodeValue

• **nodeValue**: ``null`` \| `string`

#### Inherited from

HTMLElement.nodeValue

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9664

___

### nonce

• `Optional` **nonce**: `string`

#### Inherited from

HTMLElement.nonce

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:7337

___

### offsetHeight

• `Readonly` **offsetHeight**: `number`

#### Inherited from

HTMLElement.offsetHeight

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:6141

___

### offsetLeft

• `Readonly` **offsetLeft**: `number`

#### Inherited from

HTMLElement.offsetLeft

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:6142

___

### offsetParent

• `Readonly` **offsetParent**: ``null`` \| `Element`

#### Inherited from

HTMLElement.offsetParent

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:6143

___

### offsetTop

• `Readonly` **offsetTop**: `number`

#### Inherited from

HTMLElement.offsetTop

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:6144

___

### offsetWidth

• `Readonly` **offsetWidth**: `number`

#### Inherited from

HTMLElement.offsetWidth

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:6145

___

### onabort

• **onabort**: ``null`` \| (`ev`: `UIEvent`) => `any`

Fires when the user aborts the download.

**`param`** The event.

#### Inherited from

HTMLElement.onabort

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5454

___

### onanimationcancel

• **onanimationcancel**: ``null`` \| (`ev`: `AnimationEvent`) => `any`

#### Inherited from

HTMLElement.onanimationcancel

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5455

___

### onanimationend

• **onanimationend**: ``null`` \| (`ev`: `AnimationEvent`) => `any`

#### Inherited from

HTMLElement.onanimationend

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5456

___

### onanimationiteration

• **onanimationiteration**: ``null`` \| (`ev`: `AnimationEvent`) => `any`

#### Inherited from

HTMLElement.onanimationiteration

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5457

___

### onanimationstart

• **onanimationstart**: ``null`` \| (`ev`: `AnimationEvent`) => `any`

#### Inherited from

HTMLElement.onanimationstart

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5458

___

### onauxclick

• **onauxclick**: ``null`` \| (`ev`: `MouseEvent`) => `any`

#### Inherited from

HTMLElement.onauxclick

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5459

___

### onblur

• **onblur**: ``null`` \| (`ev`: `FocusEvent`) => `any`

Fires when the object loses the input focus.

**`param`** The focus event.

#### Inherited from

HTMLElement.onblur

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5464

___

### oncanplay

• **oncanplay**: ``null`` \| (`ev`: `Event`) => `any`

Occurs when playback is possible, but would require further buffering.

**`param`** The event.

#### Inherited from

HTMLElement.oncanplay

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5469

___

### oncanplaythrough

• **oncanplaythrough**: ``null`` \| (`ev`: `Event`) => `any`

#### Inherited from

HTMLElement.oncanplaythrough

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5470

___

### onchange

• **onchange**: ``null`` \| (`ev`: `Event`) => `any`

Fires when the contents of the object or selection have changed.

**`param`** The event.

#### Inherited from

HTMLElement.onchange

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5475

___

### onclick

• **onclick**: ``null`` \| (`ev`: `MouseEvent`) => `any`

Fires when the user clicks the left mouse button on the object

**`param`** The mouse event.

#### Inherited from

HTMLElement.onclick

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5480

___

### onclose

• **onclose**: ``null`` \| (`ev`: `Event`) => `any`

#### Inherited from

HTMLElement.onclose

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5481

___

### oncontextmenu

• **oncontextmenu**: ``null`` \| (`ev`: `MouseEvent`) => `any`

Fires when the user clicks the right mouse button in the client area, opening the context menu.

**`param`** The mouse event.

#### Inherited from

HTMLElement.oncontextmenu

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5486

___

### oncopy

• **oncopy**: ``null`` \| (`ev`: `ClipboardEvent`) => `any`

#### Inherited from

HTMLElement.oncopy

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4576

___

### oncuechange

• **oncuechange**: ``null`` \| (`ev`: `Event`) => `any`

#### Inherited from

HTMLElement.oncuechange

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5487

___

### oncut

• **oncut**: ``null`` \| (`ev`: `ClipboardEvent`) => `any`

#### Inherited from

HTMLElement.oncut

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4577

___

### ondblclick

• **ondblclick**: ``null`` \| (`ev`: `MouseEvent`) => `any`

Fires when the user double-clicks the object.

**`param`** The mouse event.

#### Inherited from

HTMLElement.ondblclick

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5492

___

### ondrag

• **ondrag**: ``null`` \| (`ev`: `DragEvent`) => `any`

Fires on the source object continuously during a drag operation.

**`param`** The event.

#### Inherited from

HTMLElement.ondrag

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5497

___

### ondragend

• **ondragend**: ``null`` \| (`ev`: `DragEvent`) => `any`

Fires on the source object when the user releases the mouse at the close of a drag operation.

**`param`** The event.

#### Inherited from

HTMLElement.ondragend

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5502

___

### ondragenter

• **ondragenter**: ``null`` \| (`ev`: `DragEvent`) => `any`

Fires on the target element when the user drags the object to a valid drop target.

**`param`** The drag event.

#### Inherited from

HTMLElement.ondragenter

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5507

___

### ondragleave

• **ondragleave**: ``null`` \| (`ev`: `DragEvent`) => `any`

Fires on the target object when the user moves the mouse out of a valid drop target during a drag operation.

**`param`** The drag event.

#### Inherited from

HTMLElement.ondragleave

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5512

___

### ondragover

• **ondragover**: ``null`` \| (`ev`: `DragEvent`) => `any`

Fires on the target element continuously while the user drags the object over a valid drop target.

**`param`** The event.

#### Inherited from

HTMLElement.ondragover

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5517

___

### ondragstart

• **ondragstart**: ``null`` \| (`ev`: `DragEvent`) => `any`

Fires on the source object when the user starts to drag a text selection or selected object.

**`param`** The event.

#### Inherited from

HTMLElement.ondragstart

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5522

___

### ondrop

• **ondrop**: ``null`` \| (`ev`: `DragEvent`) => `any`

#### Inherited from

HTMLElement.ondrop

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5523

___

### ondurationchange

• **ondurationchange**: ``null`` \| (`ev`: `Event`) => `any`

Occurs when the duration attribute is updated.

**`param`** The event.

#### Inherited from

HTMLElement.ondurationchange

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5528

___

### onemptied

• **onemptied**: ``null`` \| (`ev`: `Event`) => `any`

Occurs when the media element is reset to its initial state.

**`param`** The event.

#### Inherited from

HTMLElement.onemptied

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5533

___

### onended

• **onended**: ``null`` \| (`ev`: `Event`) => `any`

Occurs when the end of playback is reached.

**`param`** The event

#### Inherited from

HTMLElement.onended

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5538

___

### onerror

• **onerror**: `OnErrorEventHandler`

Fires when an error occurs during object loading.

**`param`** The event.

#### Inherited from

HTMLElement.onerror

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5543

___

### onfocus

• **onfocus**: ``null`` \| (`ev`: `FocusEvent`) => `any`

Fires when the object receives focus.

**`param`** The event.

#### Inherited from

HTMLElement.onfocus

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5548

___

### onformdata

• **onformdata**: ``null`` \| (`ev`: `FormDataEvent`) => `any`

#### Inherited from

HTMLElement.onformdata

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5549

___

### onfullscreenchange

• **onfullscreenchange**: ``null`` \| (`ev`: `Event`) => `any`

#### Inherited from

HTMLElement.onfullscreenchange

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4735

___

### onfullscreenerror

• **onfullscreenerror**: ``null`` \| (`ev`: `Event`) => `any`

#### Inherited from

HTMLElement.onfullscreenerror

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4736

___

### ongotpointercapture

• **ongotpointercapture**: ``null`` \| (`ev`: `PointerEvent`) => `any`

#### Inherited from

HTMLElement.ongotpointercapture

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5550

___

### oninput

• **oninput**: ``null`` \| (`ev`: `Event`) => `any`

#### Inherited from

HTMLElement.oninput

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5551

___

### oninvalid

• **oninvalid**: ``null`` \| (`ev`: `Event`) => `any`

#### Inherited from

HTMLElement.oninvalid

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5552

___

### onkeydown

• **onkeydown**: ``null`` \| (`ev`: `KeyboardEvent`) => `any`

Fires when the user presses a key.

**`param`** The keyboard event

#### Inherited from

HTMLElement.onkeydown

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5557

___

### onkeypress

• **onkeypress**: ``null`` \| (`ev`: `KeyboardEvent`) => `any`

Fires when the user presses an alphanumeric key.

**`param`** The event.

**`deprecated`**

#### Inherited from

HTMLElement.onkeypress

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5563

___

### onkeyup

• **onkeyup**: ``null`` \| (`ev`: `KeyboardEvent`) => `any`

Fires when the user releases a key.

**`param`** The keyboard event

#### Inherited from

HTMLElement.onkeyup

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5568

___

### onload

• **onload**: ``null`` \| (`ev`: `Event`) => `any`

Fires immediately after the browser loads the object.

**`param`** The event.

#### Inherited from

HTMLElement.onload

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5573

___

### onloadeddata

• **onloadeddata**: ``null`` \| (`ev`: `Event`) => `any`

Occurs when media data is loaded at the current playback position.

**`param`** The event.

#### Inherited from

HTMLElement.onloadeddata

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5578

___

### onloadedmetadata

• **onloadedmetadata**: ``null`` \| (`ev`: `Event`) => `any`

Occurs when the duration and dimensions of the media have been determined.

**`param`** The event.

#### Inherited from

HTMLElement.onloadedmetadata

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5583

___

### onloadstart

• **onloadstart**: ``null`` \| (`ev`: `Event`) => `any`

Occurs when Internet Explorer begins looking for media data.

**`param`** The event.

#### Inherited from

HTMLElement.onloadstart

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5588

___

### onlostpointercapture

• **onlostpointercapture**: ``null`` \| (`ev`: `PointerEvent`) => `any`

#### Inherited from

HTMLElement.onlostpointercapture

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5589

___

### onmousedown

• **onmousedown**: ``null`` \| (`ev`: `MouseEvent`) => `any`

Fires when the user clicks the object with either mouse button.

**`param`** The mouse event.

#### Inherited from

HTMLElement.onmousedown

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5594

___

### onmouseenter

• **onmouseenter**: ``null`` \| (`ev`: `MouseEvent`) => `any`

#### Inherited from

HTMLElement.onmouseenter

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5595

___

### onmouseleave

• **onmouseleave**: ``null`` \| (`ev`: `MouseEvent`) => `any`

#### Inherited from

HTMLElement.onmouseleave

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5596

___

### onmousemove

• **onmousemove**: ``null`` \| (`ev`: `MouseEvent`) => `any`

Fires when the user moves the mouse over the object.

**`param`** The mouse event.

#### Inherited from

HTMLElement.onmousemove

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5601

___

### onmouseout

• **onmouseout**: ``null`` \| (`ev`: `MouseEvent`) => `any`

Fires when the user moves the mouse pointer outside the boundaries of the object.

**`param`** The mouse event.

#### Inherited from

HTMLElement.onmouseout

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5606

___

### onmouseover

• **onmouseover**: ``null`` \| (`ev`: `MouseEvent`) => `any`

Fires when the user moves the mouse pointer into the object.

**`param`** The mouse event.

#### Inherited from

HTMLElement.onmouseover

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5611

___

### onmouseup

• **onmouseup**: ``null`` \| (`ev`: `MouseEvent`) => `any`

Fires when the user releases a mouse button while the mouse is over the object.

**`param`** The mouse event.

#### Inherited from

HTMLElement.onmouseup

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5616

___

### onpaste

• **onpaste**: ``null`` \| (`ev`: `ClipboardEvent`) => `any`

#### Inherited from

HTMLElement.onpaste

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4578

___

### onpause

• **onpause**: ``null`` \| (`ev`: `Event`) => `any`

Occurs when playback is paused.

**`param`** The event.

#### Inherited from

HTMLElement.onpause

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5621

___

### onplay

• **onplay**: ``null`` \| (`ev`: `Event`) => `any`

Occurs when the play method is requested.

**`param`** The event.

#### Inherited from

HTMLElement.onplay

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5626

___

### onplaying

• **onplaying**: ``null`` \| (`ev`: `Event`) => `any`

Occurs when the audio or video has started playing.

**`param`** The event.

#### Inherited from

HTMLElement.onplaying

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5631

___

### onpointercancel

• **onpointercancel**: ``null`` \| (`ev`: `PointerEvent`) => `any`

#### Inherited from

HTMLElement.onpointercancel

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5632

___

### onpointerdown

• **onpointerdown**: ``null`` \| (`ev`: `PointerEvent`) => `any`

#### Inherited from

HTMLElement.onpointerdown

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5633

___

### onpointerenter

• **onpointerenter**: ``null`` \| (`ev`: `PointerEvent`) => `any`

#### Inherited from

HTMLElement.onpointerenter

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5634

___

### onpointerleave

• **onpointerleave**: ``null`` \| (`ev`: `PointerEvent`) => `any`

#### Inherited from

HTMLElement.onpointerleave

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5635

___

### onpointermove

• **onpointermove**: ``null`` \| (`ev`: `PointerEvent`) => `any`

#### Inherited from

HTMLElement.onpointermove

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5636

___

### onpointerout

• **onpointerout**: ``null`` \| (`ev`: `PointerEvent`) => `any`

#### Inherited from

HTMLElement.onpointerout

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5637

___

### onpointerover

• **onpointerover**: ``null`` \| (`ev`: `PointerEvent`) => `any`

#### Inherited from

HTMLElement.onpointerover

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5638

___

### onpointerup

• **onpointerup**: ``null`` \| (`ev`: `PointerEvent`) => `any`

#### Inherited from

HTMLElement.onpointerup

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5639

___

### onprogress

• **onprogress**: ``null`` \| (`ev`: `ProgressEvent`<`EventTarget`\>) => `any`

Occurs to indicate progress while downloading media data.

**`param`** The event.

#### Inherited from

HTMLElement.onprogress

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5644

___

### onratechange

• **onratechange**: ``null`` \| (`ev`: `Event`) => `any`

Occurs when the playback rate is increased or decreased.

**`param`** The event.

#### Inherited from

HTMLElement.onratechange

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5649

___

### onreset

• **onreset**: ``null`` \| (`ev`: `Event`) => `any`

Fires when the user resets a form.

**`param`** The event.

#### Inherited from

HTMLElement.onreset

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5654

___

### onresize

• **onresize**: ``null`` \| (`ev`: `UIEvent`) => `any`

#### Inherited from

HTMLElement.onresize

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5655

___

### onscroll

• **onscroll**: ``null`` \| (`ev`: `Event`) => `any`

Fires when the user repositions the scroll box in the scroll bar on the object.

**`param`** The event.

#### Inherited from

HTMLElement.onscroll

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5660

___

### onseeked

• **onseeked**: ``null`` \| (`ev`: `Event`) => `any`

Occurs when the seek operation ends.

**`param`** The event.

#### Inherited from

HTMLElement.onseeked

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5665

___

### onseeking

• **onseeking**: ``null`` \| (`ev`: `Event`) => `any`

Occurs when the current playback position is moved.

**`param`** The event.

#### Inherited from

HTMLElement.onseeking

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5670

___

### onselect

• **onselect**: ``null`` \| (`ev`: `Event`) => `any`

Fires when the current selection changes.

**`param`** The event.

#### Inherited from

HTMLElement.onselect

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5675

___

### onselectionchange

• **onselectionchange**: ``null`` \| (`ev`: `Event`) => `any`

#### Inherited from

HTMLElement.onselectionchange

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5676

___

### onselectstart

• **onselectstart**: ``null`` \| (`ev`: `Event`) => `any`

#### Inherited from

HTMLElement.onselectstart

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5677

___

### onstalled

• **onstalled**: ``null`` \| (`ev`: `Event`) => `any`

Occurs when the download has stopped.

**`param`** The event.

#### Inherited from

HTMLElement.onstalled

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5682

___

### onsubmit

• **onsubmit**: ``null`` \| (`ev`: `SubmitEvent`) => `any`

#### Inherited from

HTMLElement.onsubmit

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5683

___

### onsuspend

• **onsuspend**: ``null`` \| (`ev`: `Event`) => `any`

Occurs if the load operation has been intentionally halted.

**`param`** The event.

#### Inherited from

HTMLElement.onsuspend

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5688

___

### ontimeupdate

• **ontimeupdate**: ``null`` \| (`ev`: `Event`) => `any`

Occurs to indicate the current playback position.

**`param`** The event.

#### Inherited from

HTMLElement.ontimeupdate

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5693

___

### ontoggle

• **ontoggle**: ``null`` \| (`ev`: `Event`) => `any`

#### Inherited from

HTMLElement.ontoggle

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5694

___

### ontouchcancel

• `Optional` **ontouchcancel**: ``null`` \| (`ev`: `TouchEvent`) => `any`

#### Inherited from

HTMLElement.ontouchcancel

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5695

___

### ontouchend

• `Optional` **ontouchend**: ``null`` \| (`ev`: `TouchEvent`) => `any`

#### Inherited from

HTMLElement.ontouchend

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5696

___

### ontouchmove

• `Optional` **ontouchmove**: ``null`` \| (`ev`: `TouchEvent`) => `any`

#### Inherited from

HTMLElement.ontouchmove

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5697

___

### ontouchstart

• `Optional` **ontouchstart**: ``null`` \| (`ev`: `TouchEvent`) => `any`

#### Inherited from

HTMLElement.ontouchstart

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5698

___

### ontransitioncancel

• **ontransitioncancel**: ``null`` \| (`ev`: `TransitionEvent`) => `any`

#### Inherited from

HTMLElement.ontransitioncancel

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5699

___

### ontransitionend

• **ontransitionend**: ``null`` \| (`ev`: `TransitionEvent`) => `any`

#### Inherited from

HTMLElement.ontransitionend

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5700

___

### ontransitionrun

• **ontransitionrun**: ``null`` \| (`ev`: `TransitionEvent`) => `any`

#### Inherited from

HTMLElement.ontransitionrun

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5701

___

### ontransitionstart

• **ontransitionstart**: ``null`` \| (`ev`: `TransitionEvent`) => `any`

#### Inherited from

HTMLElement.ontransitionstart

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5702

___

### onvolumechange

• **onvolumechange**: ``null`` \| (`ev`: `Event`) => `any`

Occurs when the volume is changed, or playback is muted or unmuted.

**`param`** The event.

#### Inherited from

HTMLElement.onvolumechange

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5707

___

### onwaiting

• **onwaiting**: ``null`` \| (`ev`: `Event`) => `any`

Occurs when playback stops because the next frame of a video resource is not available.

**`param`** The event.

#### Inherited from

HTMLElement.onwaiting

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5712

___

### onwebkitanimationend

• **onwebkitanimationend**: ``null`` \| (`ev`: `Event`) => `any`

**`deprecated`** This is a legacy alias of `onanimationend`.

#### Inherited from

HTMLElement.onwebkitanimationend

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5714

___

### onwebkitanimationiteration

• **onwebkitanimationiteration**: ``null`` \| (`ev`: `Event`) => `any`

**`deprecated`** This is a legacy alias of `onanimationiteration`.

#### Inherited from

HTMLElement.onwebkitanimationiteration

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5716

___

### onwebkitanimationstart

• **onwebkitanimationstart**: ``null`` \| (`ev`: `Event`) => `any`

**`deprecated`** This is a legacy alias of `onanimationstart`.

#### Inherited from

HTMLElement.onwebkitanimationstart

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5718

___

### onwebkittransitionend

• **onwebkittransitionend**: ``null`` \| (`ev`: `Event`) => `any`

**`deprecated`** This is a legacy alias of `ontransitionend`.

#### Inherited from

HTMLElement.onwebkittransitionend

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5720

___

### onwheel

• **onwheel**: ``null`` \| (`ev`: `WheelEvent`) => `any`

#### Inherited from

HTMLElement.onwheel

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:5721

___

### opts

• `Private` **opts**: `Partial`<[`IOptions`](../interfaces/type.IOptions.md)\>

#### Defined in

src/component.ts:8

___

### outerHTML

• **outerHTML**: `string`

#### Inherited from

HTMLElement.outerHTML

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4737

___

### outerText

• **outerText**: `string`

#### Inherited from

HTMLElement.outerText

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:6146

___

### ownerDocument

• `Readonly` **ownerDocument**: `Document`

#### Inherited from

HTMLElement.ownerDocument

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4738

___

### parentElement

• `Readonly` **parentElement**: ``null`` \| `HTMLElement`

Returns the parent element.

#### Inherited from

HTMLElement.parentElement

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9668

___

### parentNode

• `Readonly` **parentNode**: ``null`` \| `ParentNode`

Returns the parent.

#### Inherited from

HTMLElement.parentNode

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9670

___

### part

• `Readonly` **part**: `DOMTokenList`

#### Inherited from

HTMLElement.part

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4739

___

### prefix

• `Readonly` **prefix**: ``null`` \| `string`

Returns the namespace prefix.

#### Inherited from

HTMLElement.prefix

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4741

___

### previousElementSibling

• `Readonly` **previousElementSibling**: ``null`` \| `Element`

Returns the first preceding sibling that is an element, and null otherwise.

#### Inherited from

HTMLElement.previousElementSibling

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9818

___

### previousSibling

• `Readonly` **previousSibling**: ``null`` \| `ChildNode`

Returns the previous sibling.

#### Inherited from

HTMLElement.previousSibling

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9672

___

### scrollHeight

• `Readonly` **scrollHeight**: `number`

#### Inherited from

HTMLElement.scrollHeight

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4742

___

### scrollLeft

• **scrollLeft**: `number`

#### Inherited from

HTMLElement.scrollLeft

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4743

___

### scrollTop

• **scrollTop**: `number`

#### Inherited from

HTMLElement.scrollTop

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4744

___

### scrollWidth

• `Readonly` **scrollWidth**: `number`

#### Inherited from

HTMLElement.scrollWidth

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4745

___

### shadowRoot

• `Readonly` **shadowRoot**: ``null`` \| `ShadowRoot`

Returns element's shadow root, if any, and if shadow root's mode is "open", and null otherwise.

#### Inherited from

HTMLElement.shadowRoot

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4747

___

### slot

• **slot**: `string`

Returns the value of element's slot content attribute. Can be set to change it.

#### Inherited from

HTMLElement.slot

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4749

___

### spellcheck

• **spellcheck**: `boolean`

#### Inherited from

HTMLElement.spellcheck

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:6147

___

### style

• `Readonly` **style**: `CSSStyleDeclaration`

#### Inherited from

HTMLElement.style

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4835

___

### tabIndex

• **tabIndex**: `number`

#### Inherited from

HTMLElement.tabIndex

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:7338

___

### tagName

• `Readonly` **tagName**: `string`

Returns the HTML-uppercased qualified name.

#### Inherited from

HTMLElement.tagName

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4751

___

### textContent

• **textContent**: ``null`` \| `string`

#### Inherited from

HTMLElement.textContent

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9673

___

### title

• **title**: `string`

#### Inherited from

HTMLElement.title

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:6148

___

### translate

• **translate**: `boolean`

#### Inherited from

HTMLElement.translate

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:6149

___

### watermarkInfo

• `Private` `Readonly` **watermarkInfo**: `string`

#### Defined in

src/component.ts:5

___

### wmShadowRoot

• `Private` `Readonly` **wmShadowRoot**: `ShadowRoot`

#### Defined in

src/component.ts:7

## Methods

### addEventListener

▸ **addEventListener**<`K`\>(`type`, `listener`, `options?`): `void`

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof `HTMLElementEventMap` |

#### Parameters

| Name | Type |
| :------ | :------ |
| `type` | `K` |
| `listener` | (`ev`: `HTMLElementEventMap`[`K`]) => `any` |
| `options?` | `boolean` \| `AddEventListenerOptions` |

#### Returns

`void`

#### Inherited from

HTMLElement.addEventListener

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:6152

▸ **addEventListener**(`type`, `listener`, `options?`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `type` | `string` |
| `listener` | `EventListenerOrEventListenerObject` |
| `options?` | `boolean` \| `AddEventListenerOptions` |

#### Returns

`void`

#### Inherited from

HTMLElement.addEventListener

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:6153

___

### after

▸ **after**(...`nodes`): `void`

Inserts nodes just after node, while replacing strings in nodes with equivalent Text nodes.

Throws a "HierarchyRequestError" DOMException if the constraints of the node tree are violated.

#### Parameters

| Name | Type |
| :------ | :------ |
| `...nodes` | (`string` \| `Node`)[] |

#### Returns

`void`

#### Inherited from

HTMLElement.after

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3451

___

### animate

▸ **animate**(`keyframes`, `options?`): `Animation`

#### Parameters

| Name | Type |
| :------ | :------ |
| `keyframes` | ``null`` \| `Keyframe`[] \| `PropertyIndexedKeyframes` |
| `options?` | `number` \| `KeyframeAnimationOptions` |

#### Returns

`Animation`

#### Inherited from

HTMLElement.animate

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1948

___

### append

▸ **append**(...`nodes`): `void`

Inserts nodes after the last child of node, while replacing strings in nodes with equivalent Text nodes.

Throws a "HierarchyRequestError" DOMException if the constraints of the node tree are violated.

#### Parameters

| Name | Type |
| :------ | :------ |
| `...nodes` | (`string` \| `Node`)[] |

#### Returns

`void`

#### Inherited from

HTMLElement.append

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:10026

___

### appendChild

▸ **appendChild**<`T`\>(`node`): `T`

#### Type parameters

| Name | Type |
| :------ | :------ |
| `T` | extends `Node` |

#### Parameters

| Name | Type |
| :------ | :------ |
| `node` | `T` |

#### Returns

`T`

#### Inherited from

HTMLElement.appendChild

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9674

___

### attachInternals

▸ **attachInternals**(): `ElementInternals`

#### Returns

`ElementInternals`

#### Inherited from

HTMLElement.attachInternals

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:6150

___

### attachShadow

▸ **attachShadow**(`init`): `ShadowRoot`

Creates a shadow root for element and returns it.

#### Parameters

| Name | Type |
| :------ | :------ |
| `init` | `ShadowRootInit` |

#### Returns

`ShadowRoot`

#### Inherited from

HTMLElement.attachShadow

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4753

___

### before

▸ **before**(...`nodes`): `void`

Inserts nodes just before node, while replacing strings in nodes with equivalent Text nodes.

Throws a "HierarchyRequestError" DOMException if the constraints of the node tree are violated.

#### Parameters

| Name | Type |
| :------ | :------ |
| `...nodes` | (`string` \| `Node`)[] |

#### Returns

`void`

#### Inherited from

HTMLElement.before

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3457

___

### blur

▸ **blur**(): `void`

#### Returns

`void`

#### Inherited from

HTMLElement.blur

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:7339

___

### click

▸ **click**(): `void`

#### Returns

`void`

#### Inherited from

HTMLElement.click

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:6151

___

### cloneNode

▸ **cloneNode**(`deep?`): `Node`

Returns a copy of node. If deep is true, the copy also includes the node's descendants.

#### Parameters

| Name | Type |
| :------ | :------ |
| `deep?` | `boolean` |

#### Returns

`Node`

#### Inherited from

HTMLElement.cloneNode

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9676

___

### closest

▸ **closest**<`K`\>(`selector`): ``null`` \| `HTMLElementTagNameMap`[`K`]

Returns the first (starting at element) inclusive ancestor that matches selectors, and null otherwise.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof `HTMLElementTagNameMap` |

#### Parameters

| Name | Type |
| :------ | :------ |
| `selector` | `K` |

#### Returns

``null`` \| `HTMLElementTagNameMap`[`K`]

#### Inherited from

HTMLElement.closest

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4755

▸ **closest**<`K`\>(`selector`): ``null`` \| `SVGElementTagNameMap`[`K`]

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof `SVGElementTagNameMap` |

#### Parameters

| Name | Type |
| :------ | :------ |
| `selector` | `K` |

#### Returns

``null`` \| `SVGElementTagNameMap`[`K`]

#### Inherited from

HTMLElement.closest

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4756

▸ **closest**<`E`\>(`selectors`): ``null`` \| `E`

#### Type parameters

| Name | Type |
| :------ | :------ |
| `E` | extends `Element` = `Element` |

#### Parameters

| Name | Type |
| :------ | :------ |
| `selectors` | `string` |

#### Returns

``null`` \| `E`

#### Inherited from

HTMLElement.closest

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4757

___

### compareDocumentPosition

▸ **compareDocumentPosition**(`other`): `number`

Returns a bitmask indicating the position of other relative to node.

#### Parameters

| Name | Type |
| :------ | :------ |
| `other` | `Node` |

#### Returns

`number`

#### Inherited from

HTMLElement.compareDocumentPosition

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9678

___

### contains

▸ **contains**(`other`): `boolean`

Returns true if other is an inclusive descendant of node, and false otherwise.

#### Parameters

| Name | Type |
| :------ | :------ |
| `other` | ``null`` \| `Node` |

#### Returns

`boolean`

#### Inherited from

HTMLElement.contains

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9680

___

### dispatchEvent

▸ **dispatchEvent**(`event`): `boolean`

Dispatches a synthetic event event to target and returns true if either event's cancelable attribute value is false or its preventDefault() method was not invoked, and false otherwise.

#### Parameters

| Name | Type |
| :------ | :------ |
| `event` | `Event` |

#### Returns

`boolean`

#### Inherited from

HTMLElement.dispatchEvent

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4983

___

### focus

▸ **focus**(`options?`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `options?` | `FocusOptions` |

#### Returns

`void`

#### Inherited from

HTMLElement.focus

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:7340

___

### getAnimations

▸ **getAnimations**(`options?`): `Animation`[]

#### Parameters

| Name | Type |
| :------ | :------ |
| `options?` | `GetAnimationsOptions` |

#### Returns

`Animation`[]

#### Inherited from

HTMLElement.getAnimations

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:1949

___

### getAttribute

▸ **getAttribute**(`qualifiedName`): ``null`` \| `string`

Returns element's first attribute whose qualified name is qualifiedName, and null if there is no such attribute otherwise.

#### Parameters

| Name | Type |
| :------ | :------ |
| `qualifiedName` | `string` |

#### Returns

``null`` \| `string`

#### Inherited from

HTMLElement.getAttribute

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4759

___

### getAttributeNS

▸ **getAttributeNS**(`namespace`, `localName`): ``null`` \| `string`

Returns element's attribute whose namespace is namespace and local name is localName, and null if there is no such attribute otherwise.

#### Parameters

| Name | Type |
| :------ | :------ |
| `namespace` | ``null`` \| `string` |
| `localName` | `string` |

#### Returns

``null`` \| `string`

#### Inherited from

HTMLElement.getAttributeNS

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4761

___

### getAttributeNames

▸ **getAttributeNames**(): `string`[]

Returns the qualified names of all element's attributes. Can contain duplicates.

#### Returns

`string`[]

#### Inherited from

HTMLElement.getAttributeNames

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4763

___

### getAttributeNode

▸ **getAttributeNode**(`qualifiedName`): ``null`` \| `Attr`

#### Parameters

| Name | Type |
| :------ | :------ |
| `qualifiedName` | `string` |

#### Returns

``null`` \| `Attr`

#### Inherited from

HTMLElement.getAttributeNode

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4764

___

### getAttributeNodeNS

▸ **getAttributeNodeNS**(`namespace`, `localName`): ``null`` \| `Attr`

#### Parameters

| Name | Type |
| :------ | :------ |
| `namespace` | ``null`` \| `string` |
| `localName` | `string` |

#### Returns

``null`` \| `Attr`

#### Inherited from

HTMLElement.getAttributeNodeNS

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4765

___

### getBoundingClientRect

▸ **getBoundingClientRect**(): `DOMRect`

#### Returns

`DOMRect`

#### Inherited from

HTMLElement.getBoundingClientRect

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4766

___

### getClientRects

▸ **getClientRects**(): `DOMRectList`

#### Returns

`DOMRectList`

#### Inherited from

HTMLElement.getClientRects

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4767

___

### getElementsByClassName

▸ **getElementsByClassName**(`classNames`): `HTMLCollectionOf`<`Element`\>

Returns a HTMLCollection of the elements in the object on which the method was invoked (a document or an element) that have all the classes given by classNames. The classNames argument is interpreted as a space-separated list of classes.

#### Parameters

| Name | Type |
| :------ | :------ |
| `classNames` | `string` |

#### Returns

`HTMLCollectionOf`<`Element`\>

#### Inherited from

HTMLElement.getElementsByClassName

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4769

___

### getElementsByTagName

▸ **getElementsByTagName**<`K`\>(`qualifiedName`): `HTMLCollectionOf`<`HTMLElementTagNameMap`[`K`]\>

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof `HTMLElementTagNameMap` |

#### Parameters

| Name | Type |
| :------ | :------ |
| `qualifiedName` | `K` |

#### Returns

`HTMLCollectionOf`<`HTMLElementTagNameMap`[`K`]\>

#### Inherited from

HTMLElement.getElementsByTagName

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4770

▸ **getElementsByTagName**<`K`\>(`qualifiedName`): `HTMLCollectionOf`<`SVGElementTagNameMap`[`K`]\>

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof `SVGElementTagNameMap` |

#### Parameters

| Name | Type |
| :------ | :------ |
| `qualifiedName` | `K` |

#### Returns

`HTMLCollectionOf`<`SVGElementTagNameMap`[`K`]\>

#### Inherited from

HTMLElement.getElementsByTagName

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4771

▸ **getElementsByTagName**(`qualifiedName`): `HTMLCollectionOf`<`Element`\>

#### Parameters

| Name | Type |
| :------ | :------ |
| `qualifiedName` | `string` |

#### Returns

`HTMLCollectionOf`<`Element`\>

#### Inherited from

HTMLElement.getElementsByTagName

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4772

___

### getElementsByTagNameNS

▸ **getElementsByTagNameNS**(`namespaceURI`, `localName`): `HTMLCollectionOf`<`HTMLElement`\>

#### Parameters

| Name | Type |
| :------ | :------ |
| `namespaceURI` | ``"http://www.w3.org/1999/xhtml"`` |
| `localName` | `string` |

#### Returns

`HTMLCollectionOf`<`HTMLElement`\>

#### Inherited from

HTMLElement.getElementsByTagNameNS

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4773

▸ **getElementsByTagNameNS**(`namespaceURI`, `localName`): `HTMLCollectionOf`<`SVGElement`\>

#### Parameters

| Name | Type |
| :------ | :------ |
| `namespaceURI` | ``"http://www.w3.org/2000/svg"`` |
| `localName` | `string` |

#### Returns

`HTMLCollectionOf`<`SVGElement`\>

#### Inherited from

HTMLElement.getElementsByTagNameNS

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4774

▸ **getElementsByTagNameNS**(`namespace`, `localName`): `HTMLCollectionOf`<`Element`\>

#### Parameters

| Name | Type |
| :------ | :------ |
| `namespace` | ``null`` \| `string` |
| `localName` | `string` |

#### Returns

`HTMLCollectionOf`<`Element`\>

#### Inherited from

HTMLElement.getElementsByTagNameNS

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4775

___

### getRootNode

▸ **getRootNode**(`options?`): `Node`

Returns node's root.

#### Parameters

| Name | Type |
| :------ | :------ |
| `options?` | `GetRootNodeOptions` |

#### Returns

`Node`

#### Inherited from

HTMLElement.getRootNode

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9682

___

### getWaterMarkerInfo

▸ `Private` **getWaterMarkerInfo**(): `string`

获取水印图形数据

#### Returns

`string`

#### Defined in

src/component.ts:78

___

### hasAttribute

▸ **hasAttribute**(`qualifiedName`): `boolean`

Returns true if element has an attribute whose qualified name is qualifiedName, and false otherwise.

#### Parameters

| Name | Type |
| :------ | :------ |
| `qualifiedName` | `string` |

#### Returns

`boolean`

#### Inherited from

HTMLElement.hasAttribute

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4777

___

### hasAttributeNS

▸ **hasAttributeNS**(`namespace`, `localName`): `boolean`

Returns true if element has an attribute whose namespace is namespace and local name is localName.

#### Parameters

| Name | Type |
| :------ | :------ |
| `namespace` | ``null`` \| `string` |
| `localName` | `string` |

#### Returns

`boolean`

#### Inherited from

HTMLElement.hasAttributeNS

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4779

___

### hasAttributes

▸ **hasAttributes**(): `boolean`

Returns true if element has attributes, and false otherwise.

#### Returns

`boolean`

#### Inherited from

HTMLElement.hasAttributes

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4781

___

### hasChildNodes

▸ **hasChildNodes**(): `boolean`

Returns whether node has children.

#### Returns

`boolean`

#### Inherited from

HTMLElement.hasChildNodes

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9684

___

### hasPointerCapture

▸ **hasPointerCapture**(`pointerId`): `boolean`

#### Parameters

| Name | Type |
| :------ | :------ |
| `pointerId` | `number` |

#### Returns

`boolean`

#### Inherited from

HTMLElement.hasPointerCapture

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4782

___

### insertAdjacentElement

▸ **insertAdjacentElement**(`where`, `element`): ``null`` \| `Element`

#### Parameters

| Name | Type |
| :------ | :------ |
| `where` | `InsertPosition` |
| `element` | `Element` |

#### Returns

``null`` \| `Element`

#### Inherited from

HTMLElement.insertAdjacentElement

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4783

___

### insertAdjacentHTML

▸ **insertAdjacentHTML**(`position`, `text`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `position` | `InsertPosition` |
| `text` | `string` |

#### Returns

`void`

#### Inherited from

HTMLElement.insertAdjacentHTML

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4784

___

### insertAdjacentText

▸ **insertAdjacentText**(`where`, `data`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `where` | `InsertPosition` |
| `data` | `string` |

#### Returns

`void`

#### Inherited from

HTMLElement.insertAdjacentText

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4785

___

### insertBefore

▸ **insertBefore**<`T`\>(`node`, `child`): `T`

#### Type parameters

| Name | Type |
| :------ | :------ |
| `T` | extends `Node` |

#### Parameters

| Name | Type |
| :------ | :------ |
| `node` | `T` |
| `child` | ``null`` \| `Node` |

#### Returns

`T`

#### Inherited from

HTMLElement.insertBefore

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9685

___

### isDefaultNamespace

▸ **isDefaultNamespace**(`namespace`): `boolean`

#### Parameters

| Name | Type |
| :------ | :------ |
| `namespace` | ``null`` \| `string` |

#### Returns

`boolean`

#### Inherited from

HTMLElement.isDefaultNamespace

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9686

___

### isEqualNode

▸ **isEqualNode**(`otherNode`): `boolean`

Returns whether node and otherNode have the same properties.

#### Parameters

| Name | Type |
| :------ | :------ |
| `otherNode` | ``null`` \| `Node` |

#### Returns

`boolean`

#### Inherited from

HTMLElement.isEqualNode

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9688

___

### isSameNode

▸ **isSameNode**(`otherNode`): `boolean`

#### Parameters

| Name | Type |
| :------ | :------ |
| `otherNode` | ``null`` \| `Node` |

#### Returns

`boolean`

#### Inherited from

HTMLElement.isSameNode

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9689

___

### lookupNamespaceURI

▸ **lookupNamespaceURI**(`prefix`): ``null`` \| `string`

#### Parameters

| Name | Type |
| :------ | :------ |
| `prefix` | ``null`` \| `string` |

#### Returns

``null`` \| `string`

#### Inherited from

HTMLElement.lookupNamespaceURI

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9690

___

### lookupPrefix

▸ **lookupPrefix**(`namespace`): ``null`` \| `string`

#### Parameters

| Name | Type |
| :------ | :------ |
| `namespace` | ``null`` \| `string` |

#### Returns

``null`` \| `string`

#### Inherited from

HTMLElement.lookupPrefix

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9691

___

### matches

▸ **matches**(`selectors`): `boolean`

Returns true if matching selectors against element's root yields element, and false otherwise.

#### Parameters

| Name | Type |
| :------ | :------ |
| `selectors` | `string` |

#### Returns

`boolean`

#### Inherited from

HTMLElement.matches

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4787

___

### normalize

▸ **normalize**(): `void`

Removes empty exclusive Text nodes and concatenates the data of remaining contiguous exclusive Text nodes into the first of their nodes.

#### Returns

`void`

#### Inherited from

HTMLElement.normalize

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9693

___

### prepend

▸ **prepend**(...`nodes`): `void`

Inserts nodes before the first child of node, while replacing strings in nodes with equivalent Text nodes.

Throws a "HierarchyRequestError" DOMException if the constraints of the node tree are violated.

#### Parameters

| Name | Type |
| :------ | :------ |
| `...nodes` | (`string` \| `Node`)[] |

#### Returns

`void`

#### Inherited from

HTMLElement.prepend

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:10032

___

### querySelector

▸ **querySelector**<`K`\>(`selectors`): ``null`` \| `HTMLElementTagNameMap`[`K`]

Returns the first element that is a descendant of node that matches selectors.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof `HTMLElementTagNameMap` |

#### Parameters

| Name | Type |
| :------ | :------ |
| `selectors` | `K` |

#### Returns

``null`` \| `HTMLElementTagNameMap`[`K`]

#### Inherited from

HTMLElement.querySelector

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:10034

▸ **querySelector**<`K`\>(`selectors`): ``null`` \| `SVGElementTagNameMap`[`K`]

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof `SVGElementTagNameMap` |

#### Parameters

| Name | Type |
| :------ | :------ |
| `selectors` | `K` |

#### Returns

``null`` \| `SVGElementTagNameMap`[`K`]

#### Inherited from

HTMLElement.querySelector

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:10035

▸ **querySelector**<`E`\>(`selectors`): ``null`` \| `E`

#### Type parameters

| Name | Type |
| :------ | :------ |
| `E` | extends `Element` = `Element` |

#### Parameters

| Name | Type |
| :------ | :------ |
| `selectors` | `string` |

#### Returns

``null`` \| `E`

#### Inherited from

HTMLElement.querySelector

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:10036

___

### querySelectorAll

▸ **querySelectorAll**<`K`\>(`selectors`): `NodeListOf`<`HTMLElementTagNameMap`[`K`]\>

Returns all element descendants of node that match selectors.

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof `HTMLElementTagNameMap` |

#### Parameters

| Name | Type |
| :------ | :------ |
| `selectors` | `K` |

#### Returns

`NodeListOf`<`HTMLElementTagNameMap`[`K`]\>

#### Inherited from

HTMLElement.querySelectorAll

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:10038

▸ **querySelectorAll**<`K`\>(`selectors`): `NodeListOf`<`SVGElementTagNameMap`[`K`]\>

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof `SVGElementTagNameMap` |

#### Parameters

| Name | Type |
| :------ | :------ |
| `selectors` | `K` |

#### Returns

`NodeListOf`<`SVGElementTagNameMap`[`K`]\>

#### Inherited from

HTMLElement.querySelectorAll

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:10039

▸ **querySelectorAll**<`E`\>(`selectors`): `NodeListOf`<`E`\>

#### Type parameters

| Name | Type |
| :------ | :------ |
| `E` | extends `Element` = `Element` |

#### Parameters

| Name | Type |
| :------ | :------ |
| `selectors` | `string` |

#### Returns

`NodeListOf`<`E`\>

#### Inherited from

HTMLElement.querySelectorAll

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:10040

___

### releasePointerCapture

▸ **releasePointerCapture**(`pointerId`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `pointerId` | `number` |

#### Returns

`void`

#### Inherited from

HTMLElement.releasePointerCapture

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4788

___

### remove

▸ **remove**(): `void`

Removes node.

#### Returns

`void`

#### Inherited from

HTMLElement.remove

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3459

___

### removeAttribute

▸ **removeAttribute**(`qualifiedName`): `void`

Removes element's first attribute whose qualified name is qualifiedName.

#### Parameters

| Name | Type |
| :------ | :------ |
| `qualifiedName` | `string` |

#### Returns

`void`

#### Inherited from

HTMLElement.removeAttribute

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4790

___

### removeAttributeNS

▸ **removeAttributeNS**(`namespace`, `localName`): `void`

Removes element's attribute whose namespace is namespace and local name is localName.

#### Parameters

| Name | Type |
| :------ | :------ |
| `namespace` | ``null`` \| `string` |
| `localName` | `string` |

#### Returns

`void`

#### Inherited from

HTMLElement.removeAttributeNS

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4792

___

### removeAttributeNode

▸ **removeAttributeNode**(`attr`): `Attr`

#### Parameters

| Name | Type |
| :------ | :------ |
| `attr` | `Attr` |

#### Returns

`Attr`

#### Inherited from

HTMLElement.removeAttributeNode

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4793

___

### removeChild

▸ **removeChild**<`T`\>(`child`): `T`

#### Type parameters

| Name | Type |
| :------ | :------ |
| `T` | extends `Node` |

#### Parameters

| Name | Type |
| :------ | :------ |
| `child` | `T` |

#### Returns

`T`

#### Inherited from

HTMLElement.removeChild

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9694

___

### removeEventListener

▸ **removeEventListener**<`K`\>(`type`, `listener`, `options?`): `void`

#### Type parameters

| Name | Type |
| :------ | :------ |
| `K` | extends keyof `HTMLElementEventMap` |

#### Parameters

| Name | Type |
| :------ | :------ |
| `type` | `K` |
| `listener` | (`ev`: `HTMLElementEventMap`[`K`]) => `any` |
| `options?` | `boolean` \| `EventListenerOptions` |

#### Returns

`void`

#### Inherited from

HTMLElement.removeEventListener

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:6154

▸ **removeEventListener**(`type`, `listener`, `options?`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `type` | `string` |
| `listener` | `EventListenerOrEventListenerObject` |
| `options?` | `boolean` \| `EventListenerOptions` |

#### Returns

`void`

#### Inherited from

HTMLElement.removeEventListener

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:6155

___

### replaceChild

▸ **replaceChild**<`T`\>(`node`, `child`): `T`

#### Type parameters

| Name | Type |
| :------ | :------ |
| `T` | extends `Node` |

#### Parameters

| Name | Type |
| :------ | :------ |
| `node` | `Node` |
| `child` | `T` |

#### Returns

`T`

#### Inherited from

HTMLElement.replaceChild

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:9695

___

### replaceChildren

▸ **replaceChildren**(...`nodes`): `void`

Replace all children of node with nodes, while replacing strings in nodes with equivalent Text nodes.

Throws a "HierarchyRequestError" DOMException if the constraints of the node tree are violated.

#### Parameters

| Name | Type |
| :------ | :------ |
| `...nodes` | (`string` \| `Node`)[] |

#### Returns

`void`

#### Inherited from

HTMLElement.replaceChildren

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:10046

___

### replaceWith

▸ **replaceWith**(...`nodes`): `void`

Replaces node with nodes, while replacing strings in nodes with equivalent Text nodes.

Throws a "HierarchyRequestError" DOMException if the constraints of the node tree are violated.

#### Parameters

| Name | Type |
| :------ | :------ |
| `...nodes` | (`string` \| `Node`)[] |

#### Returns

`void`

#### Inherited from

HTMLElement.replaceWith

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3465

___

### requestFullscreen

▸ **requestFullscreen**(`options?`): `Promise`<`void`\>

Displays element fullscreen and resolves promise when done.

When supplied, options's navigationUI member indicates whether showing navigation UI while in fullscreen is preferred or not. If set to "show", navigation simplicity is preferred over screen space, and if set to "hide", more screen space is preferred. User agents are always free to honor user preference over the application's. The default value "auto" indicates no application preference.

#### Parameters

| Name | Type |
| :------ | :------ |
| `options?` | `FullscreenOptions` |

#### Returns

`Promise`<`void`\>

#### Inherited from

HTMLElement.requestFullscreen

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4799

___

### requestPointerLock

▸ **requestPointerLock**(): `void`

#### Returns

`void`

#### Inherited from

HTMLElement.requestPointerLock

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4800

___

### scroll

▸ **scroll**(`options?`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `options?` | `ScrollToOptions` |

#### Returns

`void`

#### Inherited from

HTMLElement.scroll

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4801

▸ **scroll**(`x`, `y`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `x` | `number` |
| `y` | `number` |

#### Returns

`void`

#### Inherited from

HTMLElement.scroll

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4802

___

### scrollBy

▸ **scrollBy**(`options?`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `options?` | `ScrollToOptions` |

#### Returns

`void`

#### Inherited from

HTMLElement.scrollBy

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4803

▸ **scrollBy**(`x`, `y`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `x` | `number` |
| `y` | `number` |

#### Returns

`void`

#### Inherited from

HTMLElement.scrollBy

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4804

___

### scrollIntoView

▸ **scrollIntoView**(`arg?`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `arg?` | `boolean` \| `ScrollIntoViewOptions` |

#### Returns

`void`

#### Inherited from

HTMLElement.scrollIntoView

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4805

___

### scrollTo

▸ **scrollTo**(`options?`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `options?` | `ScrollToOptions` |

#### Returns

`void`

#### Inherited from

HTMLElement.scrollTo

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4806

▸ **scrollTo**(`x`, `y`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `x` | `number` |
| `y` | `number` |

#### Returns

`void`

#### Inherited from

HTMLElement.scrollTo

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4807

___

### setAttribute

▸ **setAttribute**(`qualifiedName`, `value`): `void`

Sets the value of element's first attribute whose qualified name is qualifiedName to value.

#### Parameters

| Name | Type |
| :------ | :------ |
| `qualifiedName` | `string` |
| `value` | `string` |

#### Returns

`void`

#### Inherited from

HTMLElement.setAttribute

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4809

___

### setAttributeNS

▸ **setAttributeNS**(`namespace`, `qualifiedName`, `value`): `void`

Sets the value of element's attribute whose namespace is namespace and local name is localName to value.

#### Parameters

| Name | Type |
| :------ | :------ |
| `namespace` | ``null`` \| `string` |
| `qualifiedName` | `string` |
| `value` | `string` |

#### Returns

`void`

#### Inherited from

HTMLElement.setAttributeNS

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4811

___

### setAttributeNode

▸ **setAttributeNode**(`attr`): ``null`` \| `Attr`

#### Parameters

| Name | Type |
| :------ | :------ |
| `attr` | `Attr` |

#### Returns

``null`` \| `Attr`

#### Inherited from

HTMLElement.setAttributeNode

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4812

___

### setAttributeNodeNS

▸ **setAttributeNodeNS**(`attr`): ``null`` \| `Attr`

#### Parameters

| Name | Type |
| :------ | :------ |
| `attr` | `Attr` |

#### Returns

``null`` \| `Attr`

#### Inherited from

HTMLElement.setAttributeNodeNS

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4813

___

### setPointerCapture

▸ **setPointerCapture**(`pointerId`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `pointerId` | `number` |

#### Returns

`void`

#### Inherited from

HTMLElement.setPointerCapture

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4814

___

### setShadowRoot

▸ `Private` **setShadowRoot**(): `void`

设置 shadowRoot

#### Returns

`void`

#### Defined in

src/component.ts:66

___

### startObserving

▸ `Private` **startObserving**(`observer`): `void`

开启 DOM 观察

#### Parameters

| Name | Type |
| :------ | :------ |
| `observer` | `MutationObserver` |

#### Returns

`void`

#### Defined in

src/component.ts:55

___

### toggleAttribute

▸ **toggleAttribute**(`qualifiedName`, `force?`): `boolean`

If force is not given, "toggles" qualifiedName, removing it if it is present and adding it if it is not present. If force is true, adds qualifiedName. If force is false, removes qualifiedName.

Returns true if qualifiedName is now present, and false otherwise.

#### Parameters

| Name | Type |
| :------ | :------ |
| `qualifiedName` | `string` |
| `force?` | `boolean` |

#### Returns

`boolean`

#### Inherited from

HTMLElement.toggleAttribute

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4820

___

### webkitMatchesSelector

▸ **webkitMatchesSelector**(`selectors`): `boolean`

**`deprecated`** This is a legacy alias of `matches`.

#### Parameters

| Name | Type |
| :------ | :------ |
| `selectors` | `string` |

#### Returns

`boolean`

#### Inherited from

HTMLElement.webkitMatchesSelector

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:4822
