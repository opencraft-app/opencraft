[@tencent/watermarkjs](../README.md) / [Modules](../modules.md) / type

# Module: type

## Table of contents

### Interfaces

- [IGraphOptions](../interfaces/type.IGraphOptions.md)
- [IOptions](../interfaces/type.IOptions.md)
