[@tencent/watermarkjs](../README.md) / [Modules](../modules.md) / component

# Module: component

## Table of contents

### Classes

- [default](../classes/component.default.md)
