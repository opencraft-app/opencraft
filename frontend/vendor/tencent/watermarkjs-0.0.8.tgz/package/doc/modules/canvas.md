[@tencent/watermarkjs](../README.md) / [Modules](../modules.md) / canvas

# Module: canvas

## Table of contents

### Functions

- [default](canvas.md#default)

## Functions

### default

▸ **default**(`content`, `options`): `string`

生成水印图像数据

#### Parameters

| Name | Type | Description |
| :------ | :------ | :------ |
| `content` | `string` | 水印内容 |
| `options` | `Partial`<[`IGraphOptions`](../interfaces/type.IGraphOptions.md)\> | 配置项 |

#### Returns

`string`

#### Defined in

src/canvas.ts:8
