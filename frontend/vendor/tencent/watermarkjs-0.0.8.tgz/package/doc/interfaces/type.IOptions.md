[@tencent/watermarkjs](../README.md) / [Modules](../modules.md) / [type](../modules/type.md) / IOptions

# Interface: IOptions

[type](../modules/type.md).IOptions

## Table of contents

### Properties

- [IGraphOptions](type.IOptions.md#igraphoptions)
- [className](type.IOptions.md#classname)
- [enableObserver](type.IOptions.md#enableobserver)
- [opacity](type.IOptions.md#opacity)
- [tagName](type.IOptions.md#tagname)
- [zIndex](type.IOptions.md#zindex)

## Properties

### IGraphOptions

• **IGraphOptions**: `Partial`<[`IGraphOptions`](type.IGraphOptions.md)\>

图形选项

#### Defined in

src/type.ts:82

___

### className

• **className**: `string`

class属性的值

#### Defined in

src/type.ts:77

___

### enableObserver

• **enableObserver**: `boolean`

是否开启 DOM 监听，防止篡改和删除

#### Defined in

src/type.ts:62

___

### opacity

• **opacity**: `number`

透明度

#### Defined in

src/type.ts:72

___

### tagName

• **tagName**: `string`

标签名，符合 DOMString 标准的字符串，不能是单个单词，且其中必须要有短横线

#### Defined in

src/type.ts:57

___

### zIndex

• **zIndex**: `number`

层级

#### Defined in

src/type.ts:67
