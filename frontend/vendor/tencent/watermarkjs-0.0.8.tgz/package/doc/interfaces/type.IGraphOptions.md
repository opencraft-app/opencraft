[@tencent/watermarkjs](../README.md) / [Modules](../modules.md) / [type](../modules/type.md) / IGraphOptions

# Interface: IGraphOptions

[type](../modules/type.md).IGraphOptions

## Hierarchy

- `Partial`<`CanvasRenderingContext2D`\>

  ↳ **`IGraphOptions`**

## Table of contents

### Properties

- [canvas](type.IGraphOptions.md#canvas)
- [color](type.IGraphOptions.md#color)
- [direction](type.IGraphOptions.md#direction)
- [fillStyle](type.IGraphOptions.md#fillstyle)
- [fillTextX](type.IGraphOptions.md#filltextx)
- [fillTextY](type.IGraphOptions.md#filltexty)
- [filter](type.IGraphOptions.md#filter)
- [font](type.IGraphOptions.md#font)
- [globalAlpha](type.IGraphOptions.md#globalalpha)
- [globalCompositeOperation](type.IGraphOptions.md#globalcompositeoperation)
- [height](type.IGraphOptions.md#height)
- [imageSmoothingEnabled](type.IGraphOptions.md#imagesmoothingenabled)
- [imageSmoothingQuality](type.IGraphOptions.md#imagesmoothingquality)
- [lineCap](type.IGraphOptions.md#linecap)
- [lineDashOffset](type.IGraphOptions.md#linedashoffset)
- [lineJoin](type.IGraphOptions.md#linejoin)
- [lineWidth](type.IGraphOptions.md#linewidth)
- [miterLimit](type.IGraphOptions.md#miterlimit)
- [rotateAngle](type.IGraphOptions.md#rotateangle)
- [shadowBlur](type.IGraphOptions.md#shadowblur)
- [shadowColor](type.IGraphOptions.md#shadowcolor)
- [shadowOffsetX](type.IGraphOptions.md#shadowoffsetx)
- [shadowOffsetY](type.IGraphOptions.md#shadowoffsety)
- [strokeStyle](type.IGraphOptions.md#strokestyle)
- [textAlign](type.IGraphOptions.md#textalign)
- [textBaseline](type.IGraphOptions.md#textbaseline)
- [textMaxLength](type.IGraphOptions.md#textmaxlength)
- [width](type.IGraphOptions.md#width)

### Methods

- [arc](type.IGraphOptions.md#arc)
- [arcTo](type.IGraphOptions.md#arcto)
- [beginPath](type.IGraphOptions.md#beginpath)
- [bezierCurveTo](type.IGraphOptions.md#beziercurveto)
- [clearRect](type.IGraphOptions.md#clearrect)
- [clip](type.IGraphOptions.md#clip)
- [closePath](type.IGraphOptions.md#closepath)
- [createImageData](type.IGraphOptions.md#createimagedata)
- [createLinearGradient](type.IGraphOptions.md#createlineargradient)
- [createPattern](type.IGraphOptions.md#createpattern)
- [createRadialGradient](type.IGraphOptions.md#createradialgradient)
- [drawFocusIfNeeded](type.IGraphOptions.md#drawfocusifneeded)
- [drawImage](type.IGraphOptions.md#drawimage)
- [ellipse](type.IGraphOptions.md#ellipse)
- [fill](type.IGraphOptions.md#fill)
- [fillRect](type.IGraphOptions.md#fillrect)
- [fillText](type.IGraphOptions.md#filltext)
- [getContextAttributes](type.IGraphOptions.md#getcontextattributes)
- [getImageData](type.IGraphOptions.md#getimagedata)
- [getLineDash](type.IGraphOptions.md#getlinedash)
- [getTransform](type.IGraphOptions.md#gettransform)
- [isPointInPath](type.IGraphOptions.md#ispointinpath)
- [isPointInStroke](type.IGraphOptions.md#ispointinstroke)
- [lineTo](type.IGraphOptions.md#lineto)
- [measureText](type.IGraphOptions.md#measuretext)
- [moveTo](type.IGraphOptions.md#moveto)
- [putImageData](type.IGraphOptions.md#putimagedata)
- [quadraticCurveTo](type.IGraphOptions.md#quadraticcurveto)
- [rect](type.IGraphOptions.md#rect)
- [resetTransform](type.IGraphOptions.md#resettransform)
- [restore](type.IGraphOptions.md#restore)
- [rotate](type.IGraphOptions.md#rotate)
- [save](type.IGraphOptions.md#save)
- [scale](type.IGraphOptions.md#scale)
- [setLineDash](type.IGraphOptions.md#setlinedash)
- [setTransform](type.IGraphOptions.md#settransform)
- [stroke](type.IGraphOptions.md#stroke)
- [strokeRect](type.IGraphOptions.md#strokerect)
- [strokeText](type.IGraphOptions.md#stroketext)
- [transform](type.IGraphOptions.md#transform)
- [translate](type.IGraphOptions.md#translate)

## Properties

### canvas

• `Optional` `Readonly` **canvas**: `HTMLCanvasElement`

#### Inherited from

Partial.canvas

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3360

___

### color

• **color**: `string`

文字颜色

#### Defined in

src/type.ts:5

___

### direction

• `Optional` **direction**: `CanvasDirection`

#### Inherited from

Partial.direction

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3388

___

### fillStyle

• `Optional` **fillStyle**: `string` \| `CanvasGradient` \| `CanvasPattern`

#### Inherited from

Partial.fillStyle

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3280

___

### fillTextX

• **fillTextX**: `number`

文本起点的 x 轴坐标，CanvasRenderingContext2D.fillText 方法的第二个参数

#### Defined in

src/type.ts:35

___

### fillTextY

• **fillTextY**: `number`

文本起点的 y 轴坐标，CanvasRenderingContext2D.fillText 方法的第三个参数

#### Defined in

src/type.ts:40

___

### filter

• `Optional` **filter**: `string`

#### Inherited from

Partial.filter

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3288

___

### font

• **font**: `string`

字体

#### Overrides

Partial.font

#### Defined in

src/type.ts:25

___

### globalAlpha

• `Optional` **globalAlpha**: `number`

#### Inherited from

Partial.globalAlpha

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3255

___

### globalCompositeOperation

• `Optional` **globalCompositeOperation**: `string`

#### Inherited from

Partial.globalCompositeOperation

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3256

___

### height

• **height**: `number`

图像高度

#### Defined in

src/type.ts:20

___

### imageSmoothingEnabled

• `Optional` **imageSmoothingEnabled**: `boolean`

#### Inherited from

Partial.imageSmoothingEnabled

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3315

___

### imageSmoothingQuality

• `Optional` **imageSmoothingQuality**: `ImageSmoothingQuality`

#### Inherited from

Partial.imageSmoothingQuality

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3316

___

### lineCap

• `Optional` **lineCap**: `CanvasLineCap`

#### Inherited from

Partial.lineCap

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3332

___

### lineDashOffset

• `Optional` **lineDashOffset**: `number`

#### Inherited from

Partial.lineDashOffset

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3333

___

### lineJoin

• `Optional` **lineJoin**: `CanvasLineJoin`

#### Inherited from

Partial.lineJoin

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3334

___

### lineWidth

• `Optional` **lineWidth**: `number`

#### Inherited from

Partial.lineWidth

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3335

___

### miterLimit

• `Optional` **miterLimit**: `number`

#### Inherited from

Partial.miterLimit

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3336

___

### rotateAngle

• **rotateAngle**: `number`

顺时针旋转的弧度，CanvasRenderingContext2D.rotate 方法参数

#### Defined in

src/type.ts:30

___

### shadowBlur

• `Optional` **shadowBlur**: `number`

#### Inherited from

Partial.shadowBlur

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3370

___

### shadowColor

• `Optional` **shadowColor**: `string`

#### Inherited from

Partial.shadowColor

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3371

___

### shadowOffsetX

• `Optional` **shadowOffsetX**: `number`

#### Inherited from

Partial.shadowOffsetX

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3372

___

### shadowOffsetY

• `Optional` **shadowOffsetY**: `number`

#### Inherited from

Partial.shadowOffsetY

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3373

___

### strokeStyle

• `Optional` **strokeStyle**: `string` \| `CanvasGradient` \| `CanvasPattern`

#### Inherited from

Partial.strokeStyle

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3281

___

### textAlign

• **textAlign**: `CanvasTextAlign`

文本的对齐方式，CanvasRenderingContext2D.textAlign

#### Overrides

Partial.textAlign

#### Defined in

src/type.ts:50

___

### textBaseline

• **textBaseline**: `CanvasTextBaseline`

文本基线，CanvasRenderingContext2D.textBaseline

#### Overrides

Partial.textBaseline

#### Defined in

src/type.ts:45

___

### textMaxLength

• **textMaxLength**: `number`

文字最大长度

#### Defined in

src/type.ts:10

___

### width

• **width**: `number`

图像宽度

#### Defined in

src/type.ts:15

## Methods

### arc

▸ `Optional` **arc**(`x`, `y`, `radius`, `startAngle`, `endAngle`, `counterclockwise?`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `x` | `number` |
| `y` | `number` |
| `radius` | `number` |
| `startAngle` | `number` |
| `endAngle` | `number` |
| `counterclockwise?` | `boolean` |

#### Returns

`void`

#### Inherited from

Partial.arc

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3320

___

### arcTo

▸ `Optional` **arcTo**(`x1`, `y1`, `x2`, `y2`, `radius`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `x1` | `number` |
| `y1` | `number` |
| `x2` | `number` |
| `y2` | `number` |
| `radius` | `number` |

#### Returns

`void`

#### Inherited from

Partial.arcTo

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3321

___

### beginPath

▸ `Optional` **beginPath**(): `void`

#### Returns

`void`

#### Inherited from

Partial.beginPath

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3266

___

### bezierCurveTo

▸ `Optional` **bezierCurveTo**(`cp1x`, `cp1y`, `cp2x`, `cp2y`, `x`, `y`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `cp1x` | `number` |
| `cp1y` | `number` |
| `cp2x` | `number` |
| `cp2y` | `number` |
| `x` | `number` |
| `y` | `number` |

#### Returns

`void`

#### Inherited from

Partial.bezierCurveTo

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3322

___

### clearRect

▸ `Optional` **clearRect**(`x`, `y`, `w`, `h`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `x` | `number` |
| `y` | `number` |
| `w` | `number` |
| `h` | `number` |

#### Returns

`void`

#### Inherited from

Partial.clearRect

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3353

___

### clip

▸ `Optional` **clip**(`fillRule?`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `fillRule?` | `CanvasFillRule` |

#### Returns

`void`

#### Inherited from

Partial.clip

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3267

▸ `Optional` **clip**(`path`, `fillRule?`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `path` | `Path2D` |
| `fillRule?` | `CanvasFillRule` |

#### Returns

`void`

#### Inherited from

Partial.clip

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3268

___

### closePath

▸ `Optional` **closePath**(): `void`

#### Returns

`void`

#### Inherited from

Partial.closePath

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3323

___

### createImageData

▸ `Optional` **createImageData**(`sw`, `sh`, `settings?`): `ImageData`

#### Parameters

| Name | Type |
| :------ | :------ |
| `sw` | `number` |
| `sh` | `number` |
| `settings?` | `ImageDataSettings` |

#### Returns

`ImageData`

#### Inherited from

Partial.createImageData

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3307

▸ `Optional` **createImageData**(`imagedata`): `ImageData`

#### Parameters

| Name | Type |
| :------ | :------ |
| `imagedata` | `ImageData` |

#### Returns

`ImageData`

#### Inherited from

Partial.createImageData

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3308

___

### createLinearGradient

▸ `Optional` **createLinearGradient**(`x0`, `y0`, `x1`, `y1`): `CanvasGradient`

#### Parameters

| Name | Type |
| :------ | :------ |
| `x0` | `number` |
| `y0` | `number` |
| `x1` | `number` |
| `y1` | `number` |

#### Returns

`CanvasGradient`

#### Inherited from

Partial.createLinearGradient

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3282

___

### createPattern

▸ `Optional` **createPattern**(`image`, `repetition`): ``null`` \| `CanvasPattern`

#### Parameters

| Name | Type |
| :------ | :------ |
| `image` | `CanvasImageSource` |
| `repetition` | ``null`` \| `string` |

#### Returns

``null`` \| `CanvasPattern`

#### Inherited from

Partial.createPattern

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3283

___

### createRadialGradient

▸ `Optional` **createRadialGradient**(`x0`, `y0`, `r0`, `x1`, `y1`, `r1`): `CanvasGradient`

#### Parameters

| Name | Type |
| :------ | :------ |
| `x0` | `number` |
| `y0` | `number` |
| `r0` | `number` |
| `x1` | `number` |
| `y1` | `number` |
| `r1` | `number` |

#### Returns

`CanvasGradient`

#### Inherited from

Partial.createRadialGradient

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3284

___

### drawFocusIfNeeded

▸ `Optional` **drawFocusIfNeeded**(`element`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `element` | `Element` |

#### Returns

`void`

#### Inherited from

Partial.drawFocusIfNeeded

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3406

▸ `Optional` **drawFocusIfNeeded**(`path`, `element`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `path` | `Path2D` |
| `element` | `Element` |

#### Returns

`void`

#### Inherited from

Partial.drawFocusIfNeeded

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3407

___

### drawImage

▸ `Optional` **drawImage**(`image`, `dx`, `dy`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `image` | `CanvasImageSource` |
| `dx` | `number` |
| `dy` | `number` |

#### Returns

`void`

#### Inherited from

Partial.drawImage

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3260

▸ `Optional` **drawImage**(`image`, `dx`, `dy`, `dw`, `dh`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `image` | `CanvasImageSource` |
| `dx` | `number` |
| `dy` | `number` |
| `dw` | `number` |
| `dh` | `number` |

#### Returns

`void`

#### Inherited from

Partial.drawImage

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3261

▸ `Optional` **drawImage**(`image`, `sx`, `sy`, `sw`, `sh`, `dx`, `dy`, `dw`, `dh`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `image` | `CanvasImageSource` |
| `sx` | `number` |
| `sy` | `number` |
| `sw` | `number` |
| `sh` | `number` |
| `dx` | `number` |
| `dy` | `number` |
| `dw` | `number` |
| `dh` | `number` |

#### Returns

`void`

#### Inherited from

Partial.drawImage

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3262

___

### ellipse

▸ `Optional` **ellipse**(`x`, `y`, `radiusX`, `radiusY`, `rotation`, `startAngle`, `endAngle`, `counterclockwise?`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `x` | `number` |
| `y` | `number` |
| `radiusX` | `number` |
| `radiusY` | `number` |
| `rotation` | `number` |
| `startAngle` | `number` |
| `endAngle` | `number` |
| `counterclockwise?` | `boolean` |

#### Returns

`void`

#### Inherited from

Partial.ellipse

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3324

___

### fill

▸ `Optional` **fill**(`fillRule?`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `fillRule?` | `CanvasFillRule` |

#### Returns

`void`

#### Inherited from

Partial.fill

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3269

▸ `Optional` **fill**(`path`, `fillRule?`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `path` | `Path2D` |
| `fillRule?` | `CanvasFillRule` |

#### Returns

`void`

#### Inherited from

Partial.fill

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3270

___

### fillRect

▸ `Optional` **fillRect**(`x`, `y`, `w`, `h`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `x` | `number` |
| `y` | `number` |
| `w` | `number` |
| `h` | `number` |

#### Returns

`void`

#### Inherited from

Partial.fillRect

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3354

___

### fillText

▸ `Optional` **fillText**(`text`, `x`, `y`, `maxWidth?`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `text` | `string` |
| `x` | `number` |
| `y` | `number` |
| `maxWidth?` | `number` |

#### Returns

`void`

#### Inherited from

Partial.fillText

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3382

___

### getContextAttributes

▸ `Optional` **getContextAttributes**(): `CanvasRenderingContext2DSettings`

#### Returns

`CanvasRenderingContext2DSettings`

#### Inherited from

Partial.getContextAttributes

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3361

___

### getImageData

▸ `Optional` **getImageData**(`sx`, `sy`, `sw`, `sh`, `settings?`): `ImageData`

#### Parameters

| Name | Type |
| :------ | :------ |
| `sx` | `number` |
| `sy` | `number` |
| `sw` | `number` |
| `sh` | `number` |
| `settings?` | `ImageDataSettings` |

#### Returns

`ImageData`

#### Inherited from

Partial.getImageData

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3309

___

### getLineDash

▸ `Optional` **getLineDash**(): `number`[]

#### Returns

`number`[]

#### Inherited from

Partial.getLineDash

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3337

___

### getTransform

▸ `Optional` **getTransform**(): `DOMMatrix`

#### Returns

`DOMMatrix`

#### Inherited from

Partial.getTransform

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3395

___

### isPointInPath

▸ `Optional` **isPointInPath**(`x`, `y`, `fillRule?`): `boolean`

#### Parameters

| Name | Type |
| :------ | :------ |
| `x` | `number` |
| `y` | `number` |
| `fillRule?` | `CanvasFillRule` |

#### Returns

`boolean`

#### Inherited from

Partial.isPointInPath

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3271

▸ `Optional` **isPointInPath**(`path`, `x`, `y`, `fillRule?`): `boolean`

#### Parameters

| Name | Type |
| :------ | :------ |
| `path` | `Path2D` |
| `x` | `number` |
| `y` | `number` |
| `fillRule?` | `CanvasFillRule` |

#### Returns

`boolean`

#### Inherited from

Partial.isPointInPath

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3272

___

### isPointInStroke

▸ `Optional` **isPointInStroke**(`x`, `y`): `boolean`

#### Parameters

| Name | Type |
| :------ | :------ |
| `x` | `number` |
| `y` | `number` |

#### Returns

`boolean`

#### Inherited from

Partial.isPointInStroke

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3273

▸ `Optional` **isPointInStroke**(`path`, `x`, `y`): `boolean`

#### Parameters

| Name | Type |
| :------ | :------ |
| `path` | `Path2D` |
| `x` | `number` |
| `y` | `number` |

#### Returns

`boolean`

#### Inherited from

Partial.isPointInStroke

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3274

___

### lineTo

▸ `Optional` **lineTo**(`x`, `y`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `x` | `number` |
| `y` | `number` |

#### Returns

`void`

#### Inherited from

Partial.lineTo

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3325

___

### measureText

▸ `Optional` **measureText**(`text`): `TextMetrics`

#### Parameters

| Name | Type |
| :------ | :------ |
| `text` | `string` |

#### Returns

`TextMetrics`

#### Inherited from

Partial.measureText

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3383

___

### moveTo

▸ `Optional` **moveTo**(`x`, `y`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `x` | `number` |
| `y` | `number` |

#### Returns

`void`

#### Inherited from

Partial.moveTo

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3326

___

### putImageData

▸ `Optional` **putImageData**(`imagedata`, `dx`, `dy`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `imagedata` | `ImageData` |
| `dx` | `number` |
| `dy` | `number` |

#### Returns

`void`

#### Inherited from

Partial.putImageData

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3310

▸ `Optional` **putImageData**(`imagedata`, `dx`, `dy`, `dirtyX`, `dirtyY`, `dirtyWidth`, `dirtyHeight`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `imagedata` | `ImageData` |
| `dx` | `number` |
| `dy` | `number` |
| `dirtyX` | `number` |
| `dirtyY` | `number` |
| `dirtyWidth` | `number` |
| `dirtyHeight` | `number` |

#### Returns

`void`

#### Inherited from

Partial.putImageData

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3311

___

### quadraticCurveTo

▸ `Optional` **quadraticCurveTo**(`cpx`, `cpy`, `x`, `y`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `cpx` | `number` |
| `cpy` | `number` |
| `x` | `number` |
| `y` | `number` |

#### Returns

`void`

#### Inherited from

Partial.quadraticCurveTo

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3327

___

### rect

▸ `Optional` **rect**(`x`, `y`, `w`, `h`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `x` | `number` |
| `y` | `number` |
| `w` | `number` |
| `h` | `number` |

#### Returns

`void`

#### Inherited from

Partial.rect

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3328

___

### resetTransform

▸ `Optional` **resetTransform**(): `void`

#### Returns

`void`

#### Inherited from

Partial.resetTransform

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3396

___

### restore

▸ `Optional` **restore**(): `void`

#### Returns

`void`

#### Inherited from

Partial.restore

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3377

___

### rotate

▸ `Optional` **rotate**(`angle`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `angle` | `number` |

#### Returns

`void`

#### Inherited from

Partial.rotate

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3397

___

### save

▸ `Optional` **save**(): `void`

#### Returns

`void`

#### Inherited from

Partial.save

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3378

___

### scale

▸ `Optional` **scale**(`x`, `y`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `x` | `number` |
| `y` | `number` |

#### Returns

`void`

#### Inherited from

Partial.scale

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3398

___

### setLineDash

▸ `Optional` **setLineDash**(`segments`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `segments` | `number`[] |

#### Returns

`void`

#### Inherited from

Partial.setLineDash

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3338

___

### setTransform

▸ `Optional` **setTransform**(`a`, `b`, `c`, `d`, `e`, `f`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `a` | `number` |
| `b` | `number` |
| `c` | `number` |
| `d` | `number` |
| `e` | `number` |
| `f` | `number` |

#### Returns

`void`

#### Inherited from

Partial.setTransform

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3399

▸ `Optional` **setTransform**(`transform?`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `transform?` | `DOMMatrix2DInit` |

#### Returns

`void`

#### Inherited from

Partial.setTransform

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3400

___

### stroke

▸ `Optional` **stroke**(): `void`

#### Returns

`void`

#### Inherited from

Partial.stroke

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3275

▸ `Optional` **stroke**(`path`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `path` | `Path2D` |

#### Returns

`void`

#### Inherited from

Partial.stroke

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3276

___

### strokeRect

▸ `Optional` **strokeRect**(`x`, `y`, `w`, `h`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `x` | `number` |
| `y` | `number` |
| `w` | `number` |
| `h` | `number` |

#### Returns

`void`

#### Inherited from

Partial.strokeRect

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3355

___

### strokeText

▸ `Optional` **strokeText**(`text`, `x`, `y`, `maxWidth?`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `text` | `string` |
| `x` | `number` |
| `y` | `number` |
| `maxWidth?` | `number` |

#### Returns

`void`

#### Inherited from

Partial.strokeText

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3384

___

### transform

▸ `Optional` **transform**(`a`, `b`, `c`, `d`, `e`, `f`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `a` | `number` |
| `b` | `number` |
| `c` | `number` |
| `d` | `number` |
| `e` | `number` |
| `f` | `number` |

#### Returns

`void`

#### Inherited from

Partial.transform

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3401

___

### translate

▸ `Optional` **translate**(`x`, `y`): `void`

#### Parameters

| Name | Type |
| :------ | :------ |
| `x` | `number` |
| `y` | `number` |

#### Returns

`void`

#### Inherited from

Partial.translate

#### Defined in

node_modules/typescript/lib/lib.dom.d.ts:3402
