export interface IGraphOptions extends Partial<CanvasRenderingContext2D> {
  /**
   * 文字颜色
   */
  color: string;

  /**
   * 文字最大长度
   */
  textMaxLength: number;

  /**
   * 图像宽度
   */
  width: number;

  /**
   * 图像高度
   */
  height: number;

  /**
   * 字体
   */
  font: string;

  /**
   * 顺时针旋转的弧度，CanvasRenderingContext2D.rotate 方法参数
   */
  rotateAngle: number;

  /**
   * 文本起点的 x 轴坐标，CanvasRenderingContext2D.fillText 方法的第二个参数
   */
  fillTextX: number;

  /**
   * 文本起点的 y 轴坐标，CanvasRenderingContext2D.fillText 方法的第三个参数
   */
  fillTextY: number;

  /**
   * 文本基线，CanvasRenderingContext2D.textBaseline
   */
  textBaseline: CanvasTextBaseline;

  /**
   * 文本的对齐方式，CanvasRenderingContext2D.textAlign
   */
  textAlign: CanvasTextAlign;
}

export interface IOptions {
  /**
   * 标签名，符合 DOMString 标准的字符串，不能是单个单词，且其中必须要有短横线
   */
  tagName: string;

  /**
   * 是否开启 DOM 监听，防止篡改和删除
   */
  enableObserver: boolean;

  /**
   * 层级
   */
  zIndex: number;

  /**
   * 透明度
   */
  opacity: number;

  /**
   * class属性的值
   */
  className: string;

  /**
   * 图形选项
   */
  IGraphOptions: Partial<IGraphOptions>;
}
