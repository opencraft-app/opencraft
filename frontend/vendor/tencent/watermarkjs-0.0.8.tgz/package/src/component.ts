import { IOptions } from '@/type';
import genImageDataByCanvas from '@/canvas';

export default class Watermark extends HTMLElement {
  private readonly watermarkInfo: string;
  private readonly content: string;
  private readonly wmShadowRoot: ShadowRoot;
  private opts: Partial<IOptions>;

  /**
   * @constructor
   */
  public constructor() {
    super();
    this.opts = {};

    this.wmShadowRoot = this.attachShadow({
      mode: 'closed',
    });

    this.content = this.getAttribute('data-content') || '';
    const options = this.getAttribute('data-options');

    if (options) {
      try {
        this.opts = JSON.parse(options);
        if (typeof this.opts !== 'object') {
          this.opts = {};
        }
      } catch (error) {
        console.warn(error);
      }
    }

    const { enableObserver } = this.opts;

    this.watermarkInfo = this.getWaterMarkerInfo();

    this.setShadowRoot();

    if (enableObserver) {
      const observer = new MutationObserver(() => {
        observer.disconnect();
        this.setShadowRoot();
        this.startObserving(observer);
      });
      this.startObserving(observer);
    }
  }

  /**
   * 开启 DOM 观察
   * @param observer
   */
  private startObserving(observer: MutationObserver): void {
    observer.observe(this.wmShadowRoot, {
      childList: true,
      attributes: true,
      subtree: true,
    });
  }

  /**
   * 设置 shadowRoot
   */
  private setShadowRoot(): void {
    const { watermarkInfo } = this;
    const { zIndex = 5000, opacity = 0.15 } = this.opts;
    const template = `
    <div style='position: fixed;left: 0;top: 0;width: 100vw;height: 100vh;z-index: ${zIndex};opacity: ${opacity};pointer-events: none;background: url(${watermarkInfo}) repeat;'></div>`;

    this.wmShadowRoot.innerHTML = template;
  }

  /**
   * 获取水印图形数据
   */
  private getWaterMarkerInfo(): string {
    const { IGraphOptions: graphOptions = {} } = this.opts;
    return genImageDataByCanvas(this.content, graphOptions);
  }
}
