import { IGraphOptions } from '@/type';

/**
 * 生成水印图像数据
 * @param content 水印内容
 * @param options 配置项
 */
export default function genImageDataByCanvas(
  content: string,
  options?: Partial<IGraphOptions>,
): string {
  if (!content) {
    return '';
  }

  const defaultOptions: IGraphOptions = {
    color: '#B9C0CA',
    textMaxLength: 20,
    width: 300,
    height: 200,
    font: '400 26px Arial',
    rotateAngle: (-30 * Math.PI) / 180,
    fillTextX: 70,
    fillTextY: 130,
    textBaseline: 'middle',
    textAlign: 'center',
  };
  const opts = Object.assign(defaultOptions, options);

  let marker = '';
  try {
    const name = content.substring(0, opts.textMaxLength);
    const canvaEl = document.createElement('canvas');
    const context = canvaEl.getContext('2d');

    if (!context) {
      return '';
    }

    canvaEl.width = opts.width;
    canvaEl.height = opts.height;
    context.rotate(opts.rotateAngle);
    context.font = opts.font;
    context.fillStyle = opts.color;
    context.textAlign = opts.textAlign;
    context.textBaseline = opts.textBaseline;
    context.fillText(name, opts.fillTextX, opts.fillTextY);
    marker = canvaEl.toDataURL('image/png');
  } catch (error) {
    console.warn(error);
  }

  return marker;
}
