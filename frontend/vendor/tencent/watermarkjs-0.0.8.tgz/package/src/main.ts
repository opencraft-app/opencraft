import { IOptions } from '@/type';
import Watermark from '@/component';

/**
 * watermarkjs 水印生成工具
 */
export default class Core {
  private readonly content: string;
  private node: HTMLElement;
  private opts: Partial<IOptions>;

  /**
   * @constructor
   * @content 水印信息
   * @options 配置项
   */
  public constructor(content: string, options: Partial<IOptions> = {}) {
    this.content = content;
    this.opts = options;
    this.node = this.createNode();

    this.init();
  }

  /**
   * 初始化
   */
  private init(): void {
    this.insertNode();

    if (this.opts.enableObserver) {
      const observer = this.mutationObserverInit();
      this.startObserving(observer);
    }
  }

  private createNode(): HTMLElement {
    const { tagName = 'w-m', className = '' } = this.opts;
    const node = document.createElement(tagName);
    node.setAttribute('data-content', this.content);

    try {
      node.setAttribute('data-options', JSON.stringify(this.opts));
    } catch (error) {
      console.warn(error);
    }

    if (className) {
      node.setAttribute('class', className);
    }

    return node;
  }

  /**
   * 插入节点
   */
  private insertNode(): void {
    document.body.appendChild(this.node);
    const { tagName = 'w-m' } = this.opts;
    if (!window.customElements.get(tagName)) {
      window.customElements.define(tagName, Watermark);
    }
  }

  /**
   * 初始化 DOM 观察器
   */
  private mutationObserverInit(): MutationObserver {
    const observer = new MutationObserver((mutations: MutationRecord[]) => {
      mutations.forEach((mutation: MutationRecord) => {
        if (mutation?.removedNodes?.length) {
          mutation.removedNodes.forEach((removedNode: Node) => {
            if (removedNode.nodeName === this.node.nodeName) {
              observer.disconnect();
              this.insertNode();
              this.startObserving(observer);
            }
          });
        }
      });
    });

    return observer;
  }

  /**
   * 开启 DOM 观察
   */
  private startObserving(observer: MutationObserver): void {
    if (!this.node.parentNode) {
      return;
    }

    observer.observe(this.node.parentNode, {
      childList: true,
      attributes: true,
      subtree: true,
    });
  }
}
