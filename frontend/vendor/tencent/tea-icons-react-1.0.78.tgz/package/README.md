# tea-icons 组件库

## 安装
- `npm i @tencent/tea-icons`

```js
  // 按需加载使用举例
  import { CloseIcon, TimeIcon } from "@tencent/tea-icons";

  <CloseIcon />;

  // 全量加载使用举例
  import Icon from "@tencent/tea-icons";

  <Icon name="xxx" />;
```

## 支持多色图标颜色修改

## 支持方法

1. 🎨 colors 修改svg图标颜色
2. 🔥 hover 修改svg hover颜色
3. 🔐 onClick 点击事件
4. 🔇 disable
6. 🔍️ size 大小，支持：'small' | 'medium' | 'large' | string | number;
7. 🚀 style?: CSSProperties; and className?: string;
8. 🌐 className


## 最新提交
- denghuizhou
- ADD

> 📸 通过figma插件 Ruyi Icons Autopipe 流水线构建生成
