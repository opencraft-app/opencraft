/**
 * 此处支持以名称动态
 */
export declare const DEFAULT_CLASS_PREFIX = "ruyi";
export declare const DEFAULT_LOCALE = "zh-CN";
export interface Config {
    /**
     * 组件类名前缀
     *
     * @default 'ruyi-icons'
     */
    classPrefix?: string;
    /**
     * 组件语言版本
     *
     * @default 'zh-CN'
     */
    locale?: 'zh-CN';
}
declare const ConfigContext: import("react").Context<Config>;
export default ConfigContext;
