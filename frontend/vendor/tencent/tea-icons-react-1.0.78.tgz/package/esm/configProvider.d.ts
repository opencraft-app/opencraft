import React from 'react';
declare type IconGlobalConfig = {
    /**
     * 组件类名前缀
     *
     * @default 'ruyi'
     */
    classPrefix: string;
};
declare type IconGlobalConfigProvider = React.FC<{
    globalConfig: IconGlobalConfig;
    children?: React.ReactNode;
}>;
export declare const DEFAULT_CLASS_PREFIX = "ruyi";
export declare const IconConfigContext: React.Context<IconGlobalConfig>;
export declare const IconConfigProvider: IconGlobalConfigProvider;
export {};
