import React from "react";
import { IconProps } from "../icon";
declare const Fullscreen2Icon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default Fullscreen2Icon;
