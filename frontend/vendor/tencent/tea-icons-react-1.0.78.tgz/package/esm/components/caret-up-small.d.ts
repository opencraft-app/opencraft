import React from "react";
import { IconProps } from "../icon";
declare const CaretUpSmallIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CaretUpSmallIcon;
