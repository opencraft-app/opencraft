import React from "react";
import { IconProps } from "../icon";
declare const MinusCircleFilledIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default MinusCircleFilledIcon;
