import React from "react";
import { IconProps } from "../icon";
declare const CallIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CallIcon;
