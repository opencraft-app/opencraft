import React from "react";
import { IconProps } from "../icon";
declare const CaretUpIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CaretUpIcon;
