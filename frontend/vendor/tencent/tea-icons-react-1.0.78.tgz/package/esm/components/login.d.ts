import React from "react";
import { IconProps } from "../icon";
declare const LoginIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LoginIcon;
