import React from "react";
import { IconProps } from "../icon";
declare const Cloud5GIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default Cloud5GIcon;
