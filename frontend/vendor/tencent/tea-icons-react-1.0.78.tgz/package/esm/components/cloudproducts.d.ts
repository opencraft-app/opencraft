import React from "react";
import { IconProps } from "../icon";
declare const CloudproductsIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CloudproductsIcon;
