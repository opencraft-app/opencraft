import React from "react";
import { IconProps } from "../icon";
declare const HistoryRecordIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default HistoryRecordIcon;
