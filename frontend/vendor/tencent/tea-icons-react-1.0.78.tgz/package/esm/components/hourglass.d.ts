import React from "react";
import { IconProps } from "../icon";
declare const HourglassIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default HourglassIcon;
