import React from "react";
import { IconProps } from "../icon";
declare const DeleteIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default DeleteIcon;
