import React from "react";
import { IconProps } from "../icon";
declare const CloseCircleIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CloseCircleIcon;
