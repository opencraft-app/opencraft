import React from "react";
import { IconProps } from "../icon";
declare const LogoEdgeFilledIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LogoEdgeFilledIcon;
