import React from "react";
import { IconProps } from "../icon";
declare const GuessIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default GuessIcon;
