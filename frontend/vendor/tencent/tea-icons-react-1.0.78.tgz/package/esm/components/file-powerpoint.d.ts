import React from "react";
import { IconProps } from "../icon";
declare const FilePowerpointIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default FilePowerpointIcon;
