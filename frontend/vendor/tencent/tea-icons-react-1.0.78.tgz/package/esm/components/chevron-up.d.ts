import React from "react";
import { IconProps } from "../icon";
declare const ChevronUpIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ChevronUpIcon;
