import React from "react";
import { IconProps } from "../icon";
declare const MobileVibrateIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default MobileVibrateIcon;
