import React from "react";
import { IconProps } from "../icon";
declare const ArrowDownIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ArrowDownIcon;
