import React from "react";
import { IconProps } from "../icon";
declare const MoneyCircleIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default MoneyCircleIcon;
