import React from "react";
import { IconProps } from "../icon";
declare const DownloadIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default DownloadIcon;
