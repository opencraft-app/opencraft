import React from "react";
import { IconProps } from "../icon";
declare const CreditcardIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CreditcardIcon;
