import React from "react";
import { IconProps } from "../icon";
declare const AddBigIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default AddBigIcon;
