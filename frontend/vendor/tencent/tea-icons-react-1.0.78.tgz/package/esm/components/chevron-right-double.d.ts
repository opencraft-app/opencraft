import React from "react";
import { IconProps } from "../icon";
declare const ChevronRightDoubleIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ChevronRightDoubleIcon;
