import React from "react";
import { IconProps } from "../icon";
declare const ChartLineIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ChartLineIcon;
