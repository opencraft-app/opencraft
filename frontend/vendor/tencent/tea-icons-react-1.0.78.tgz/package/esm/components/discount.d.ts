import React from "react";
import { IconProps } from "../icon";
declare const DiscountIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default DiscountIcon;
