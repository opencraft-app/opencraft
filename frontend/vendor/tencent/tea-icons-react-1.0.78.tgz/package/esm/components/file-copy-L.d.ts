import React from "react";
import { IconProps } from "../icon";
declare const FileCopyLIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default FileCopyLIcon;
