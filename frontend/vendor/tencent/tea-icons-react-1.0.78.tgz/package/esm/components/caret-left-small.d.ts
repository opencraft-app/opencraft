import React from "react";
import { IconProps } from "../icon";
declare const CaretLeftSmallIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CaretLeftSmallIcon;
