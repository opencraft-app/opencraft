import React from "react";
import { IconProps } from "../icon";
declare const LogoWindowsFilledIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LogoWindowsFilledIcon;
