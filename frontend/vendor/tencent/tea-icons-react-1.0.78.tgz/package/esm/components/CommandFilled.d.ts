import React from "react";
import { IconProps } from "../icon";
declare const CommandFilledIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CommandFilledIcon;
