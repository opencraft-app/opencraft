import React from "react";
import { IconProps } from "../icon";
declare const DashboardIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default DashboardIcon;
