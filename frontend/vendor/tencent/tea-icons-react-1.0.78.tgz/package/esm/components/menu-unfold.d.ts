import React from "react";
import { IconProps } from "../icon";
declare const MenuUnfoldIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default MenuUnfoldIcon;
