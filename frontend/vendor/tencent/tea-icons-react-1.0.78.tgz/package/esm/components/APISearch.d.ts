import React from "react";
import { IconProps } from "../icon";
declare const ApiSearchIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ApiSearchIcon;
