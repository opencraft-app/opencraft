import React from "react";
import { IconProps } from "../icon";
declare const ChevronRightCircleIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ChevronRightCircleIcon;
