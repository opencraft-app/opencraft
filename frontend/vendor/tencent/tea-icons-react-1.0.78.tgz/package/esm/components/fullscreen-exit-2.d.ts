import React from "react";
import { IconProps } from "../icon";
declare const FullscreenExit2Icon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default FullscreenExit2Icon;
