import React from "react";
import { IconProps } from "../icon";
declare const BulletpointIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default BulletpointIcon;
