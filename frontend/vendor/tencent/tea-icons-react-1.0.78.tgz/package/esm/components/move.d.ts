import React from "react";
import { IconProps } from "../icon";
declare const MoveIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default MoveIcon;
