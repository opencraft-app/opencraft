import React from "react";
import { IconProps } from "../icon";
declare const CodeIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CodeIcon;
