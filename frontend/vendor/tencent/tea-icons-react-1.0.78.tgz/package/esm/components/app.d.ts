import React from "react";
import { IconProps } from "../icon";
declare const AppIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default AppIcon;
