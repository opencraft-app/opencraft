import React from "react";
import { IconProps } from "../icon";
declare const HeartIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default HeartIcon;
