import React from "react";
import { IconProps } from "../icon";
declare const FolderIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default FolderIcon;
