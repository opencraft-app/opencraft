import React from "react";
import { IconProps } from "../icon";
declare const CloseSmallIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CloseSmallIcon;
