import React from "react";
import { IconProps } from "../icon";
declare const HomeIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default HomeIcon;
