import React from "react";
import { IconProps } from "../icon";
declare const CheckRectangleIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CheckRectangleIcon;
