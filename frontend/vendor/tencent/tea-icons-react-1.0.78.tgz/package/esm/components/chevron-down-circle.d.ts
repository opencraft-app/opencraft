import React from "react";
import { IconProps } from "../icon";
declare const ChevronDownCircleIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ChevronDownCircleIcon;
