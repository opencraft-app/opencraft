import React from "react";
import { IconProps } from "../icon";
declare const HelpCircleFilledIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default HelpCircleFilledIcon;
