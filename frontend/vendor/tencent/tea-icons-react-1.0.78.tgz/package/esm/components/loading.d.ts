import React from "react";
import { IconProps } from "../icon";
declare const LoadingIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LoadingIcon;
