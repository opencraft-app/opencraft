import React from "react";
import { IconProps } from "../icon";
declare const AddIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default AddIcon;
