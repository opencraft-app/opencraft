import React from "react";
import { IconProps } from "../icon";
declare const FilterIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default FilterIcon;
