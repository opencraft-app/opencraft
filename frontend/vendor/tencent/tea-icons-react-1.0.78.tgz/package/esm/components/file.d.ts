import React from "react";
import { IconProps } from "../icon";
declare const FileIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default FileIcon;
