import React from "react";
import { IconProps } from "../icon";
declare const ChevronDownDoubleIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ChevronDownDoubleIcon;
