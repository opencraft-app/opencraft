import React from "react";
import { IconProps } from "../icon";
declare const LogoOfficialaccountIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LogoOfficialaccountIcon;
