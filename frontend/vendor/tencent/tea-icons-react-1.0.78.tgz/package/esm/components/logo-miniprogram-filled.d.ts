import React from "react";
import { IconProps } from "../icon";
declare const LogoMiniprogramFilledIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LogoMiniprogramFilledIcon;
