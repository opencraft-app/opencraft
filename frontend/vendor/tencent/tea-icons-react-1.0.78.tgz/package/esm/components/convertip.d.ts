import React from "react";
import { IconProps } from "../icon";
declare const ConvertipIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ConvertipIcon;
