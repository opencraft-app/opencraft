import React from "react";
import { IconProps } from "../icon";
declare const GenderFemaleIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default GenderFemaleIcon;
