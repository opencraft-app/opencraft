import React from "react";
import { IconProps } from "../icon";
declare const ChevronUpRectangleIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ChevronUpRectangleIcon;
