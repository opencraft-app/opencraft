import React from "react";
import { IconProps } from "../icon";
declare const FormatVerticalAlignCenterIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default FormatVerticalAlignCenterIcon;
