import React from "react";
import { IconProps } from "../icon";
declare const FullscreenExitIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default FullscreenExitIcon;
