import React from "react";
import { IconProps } from "../icon";
declare const ChevronDownMenuIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ChevronDownMenuIcon;
