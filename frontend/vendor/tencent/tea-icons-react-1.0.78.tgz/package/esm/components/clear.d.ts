import React from "react";
import { IconProps } from "../icon";
declare const ClearIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ClearIcon;
