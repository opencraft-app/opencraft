import React from "react";
import { IconProps } from "../icon";
declare const CartIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CartIcon;
