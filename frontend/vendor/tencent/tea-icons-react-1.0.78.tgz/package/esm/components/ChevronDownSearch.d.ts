import React from "react";
import { IconProps } from "../icon";
declare const ChevronDownSearchIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ChevronDownSearchIcon;
