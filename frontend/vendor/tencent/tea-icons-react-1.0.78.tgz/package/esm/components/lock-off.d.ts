import React from "react";
import { IconProps } from "../icon";
declare const LockOffIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LockOffIcon;
