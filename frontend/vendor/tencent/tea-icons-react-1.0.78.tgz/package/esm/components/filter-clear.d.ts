import React from "react";
import { IconProps } from "../icon";
declare const FilterClearIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default FilterClearIcon;
