import React from "react";
import { IconProps } from "../icon";
declare const OrderDescendingIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default OrderDescendingIcon;
