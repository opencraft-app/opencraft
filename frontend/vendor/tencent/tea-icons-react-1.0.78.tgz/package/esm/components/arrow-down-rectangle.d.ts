import React from "react";
import { IconProps } from "../icon";
declare const ArrowDownRectangleIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ArrowDownRectangleIcon;
