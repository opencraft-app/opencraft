import React from "react";
import { IconProps } from "../icon";
declare const GenderMaleIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default GenderMaleIcon;
