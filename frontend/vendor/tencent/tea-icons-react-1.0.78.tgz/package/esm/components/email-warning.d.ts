import React from "react";
import { IconProps } from "../icon";
declare const EmailWarningIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default EmailWarningIcon;
