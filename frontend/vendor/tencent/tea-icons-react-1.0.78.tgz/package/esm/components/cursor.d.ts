import React from "react";
import { IconProps } from "../icon";
declare const CursorIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CursorIcon;
