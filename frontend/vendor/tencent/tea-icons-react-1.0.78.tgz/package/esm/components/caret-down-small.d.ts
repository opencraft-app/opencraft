import React from "react";
import { IconProps } from "../icon";
declare const CaretDownSmallIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CaretDownSmallIcon;
