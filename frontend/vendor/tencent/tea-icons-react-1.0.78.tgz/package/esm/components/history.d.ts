import React from "react";
import { IconProps } from "../icon";
declare const HistoryIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default HistoryIcon;
