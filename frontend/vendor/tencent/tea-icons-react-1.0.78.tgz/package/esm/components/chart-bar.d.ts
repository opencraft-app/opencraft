import React from "react";
import { IconProps } from "../icon";
declare const ChartBarIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ChartBarIcon;
