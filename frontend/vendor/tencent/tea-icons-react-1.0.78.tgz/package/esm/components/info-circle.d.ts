import React from "react";
import { IconProps } from "../icon";
declare const InfoCircleIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default InfoCircleIcon;
