import React from "react";
import { IconProps } from "../icon";
declare const ChartBubbleIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ChartBubbleIcon;
