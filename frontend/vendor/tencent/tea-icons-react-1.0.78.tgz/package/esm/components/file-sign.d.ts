import React from "react";
import { IconProps } from "../icon";
declare const FileSignIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default FileSignIcon;
