import React from "react";
import { IconProps } from "../icon";
declare const ChevronRightRectangleIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ChevronRightRectangleIcon;
