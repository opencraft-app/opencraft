import React from "react";
import { IconProps } from "../icon";
declare const InfoCircleFilledIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default InfoCircleFilledIcon;
