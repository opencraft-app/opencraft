import React from "react";
import { IconProps } from "../icon";
declare const ControlPlatformIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ControlPlatformIcon;
