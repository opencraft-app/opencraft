import React from "react";
import { IconProps } from "../icon";
declare const LogoChromeFilledIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LogoChromeFilledIcon;
