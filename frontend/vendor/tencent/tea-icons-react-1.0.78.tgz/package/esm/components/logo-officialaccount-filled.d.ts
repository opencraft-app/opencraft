import React from "react";
import { IconProps } from "../icon";
declare const LogoOfficialaccountFilledIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LogoOfficialaccountFilledIcon;
