import React from "react";
import { IconProps } from "../icon";
declare const CheckCircleFilledIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CheckCircleFilledIcon;
