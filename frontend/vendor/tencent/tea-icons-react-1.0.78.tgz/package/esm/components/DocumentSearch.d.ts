import React from "react";
import { IconProps } from "../icon";
declare const DocumentSearchIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default DocumentSearchIcon;
