import React from "react";
import { IconProps } from "../icon";
declare const MenuFoldIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default MenuFoldIcon;
