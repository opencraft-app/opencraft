import React from "react";
import { IconProps } from "../icon";
declare const NoDataMenuIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default NoDataMenuIcon;
