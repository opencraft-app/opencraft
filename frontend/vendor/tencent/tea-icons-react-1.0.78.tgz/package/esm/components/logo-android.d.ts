import React from "react";
import { IconProps } from "../icon";
declare const LogoAndroidIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LogoAndroidIcon;
