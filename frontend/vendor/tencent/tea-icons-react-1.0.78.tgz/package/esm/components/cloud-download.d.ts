import React from "react";
import { IconProps } from "../icon";
declare const CloudDownloadIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CloudDownloadIcon;
