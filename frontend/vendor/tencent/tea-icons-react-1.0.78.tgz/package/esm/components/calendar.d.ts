import React from "react";
import { IconProps } from "../icon";
declare const CalendarIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CalendarIcon;
