import React from "react";
import { IconProps } from "../icon";
declare const LogoChromeIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LogoChromeIcon;
