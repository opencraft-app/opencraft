import React from "react";
import { IconProps } from "../icon";
declare const GiftIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default GiftIcon;
