import React from "react";
import { IconProps } from "../icon";
declare const LogoCodepenIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LogoCodepenIcon;
