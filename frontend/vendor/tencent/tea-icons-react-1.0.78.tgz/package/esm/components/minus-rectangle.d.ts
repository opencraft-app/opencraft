import React from "react";
import { IconProps } from "../icon";
declare const MinusRectangleIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default MinusRectangleIcon;
