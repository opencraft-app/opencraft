import React from "react";
import { IconProps } from "../icon";
declare const ErrorIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ErrorIcon;
