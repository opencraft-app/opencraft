import React from "react";
import { IconProps } from "../icon";
declare const CaretLeftIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CaretLeftIcon;
