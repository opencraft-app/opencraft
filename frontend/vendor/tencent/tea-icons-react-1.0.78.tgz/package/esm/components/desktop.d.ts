import React from "react";
import { IconProps } from "../icon";
declare const DesktopIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default DesktopIcon;
