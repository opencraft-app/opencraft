import React from "react";
import { IconProps } from "../icon";
declare const LogoMiniprogramIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LogoMiniprogramIcon;
