import React from "react";
import { IconProps } from "../icon";
declare const IdcardFilledIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default IdcardFilledIcon;
