import React from "react";
import { IconProps } from "../icon";
declare const MultiLineIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default MultiLineIcon;
