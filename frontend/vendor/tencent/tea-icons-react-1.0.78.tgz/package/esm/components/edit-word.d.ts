import React from "react";
import { IconProps } from "../icon";
declare const EditWordIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default EditWordIcon;
