import React from "react";
import { IconProps } from "../icon";
declare const MenuApplicationIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default MenuApplicationIcon;
