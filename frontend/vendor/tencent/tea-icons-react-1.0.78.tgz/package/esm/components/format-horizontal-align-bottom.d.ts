import React from "react";
import { IconProps } from "../icon";
declare const FormatHorizontalAlignBottomIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default FormatHorizontalAlignBottomIcon;
