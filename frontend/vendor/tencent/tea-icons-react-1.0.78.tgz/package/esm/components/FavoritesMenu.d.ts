import React from "react";
import { IconProps } from "../icon";
declare const FavoritesMenuIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default FavoritesMenuIcon;
