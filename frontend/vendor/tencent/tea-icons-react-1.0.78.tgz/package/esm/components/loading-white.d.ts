import React from "react";
import { IconProps } from "../icon";
declare const LoadingWhiteIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LoadingWhiteIcon;
