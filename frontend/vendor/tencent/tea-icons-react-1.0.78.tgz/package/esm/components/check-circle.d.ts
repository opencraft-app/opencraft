import React from "react";
import { IconProps } from "../icon";
declare const CheckCircleIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CheckCircleIcon;
