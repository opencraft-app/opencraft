import React from "react";
import { IconProps } from "../icon";
declare const FileImageIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default FileImageIcon;
