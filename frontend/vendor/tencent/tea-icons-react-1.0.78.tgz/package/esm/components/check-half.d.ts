import React from "react";
import { IconProps } from "../icon";
declare const CheckHalfIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CheckHalfIcon;
