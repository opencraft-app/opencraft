import React from "react";
import { IconProps } from "../icon";
declare const NotificationIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default NotificationIcon;
