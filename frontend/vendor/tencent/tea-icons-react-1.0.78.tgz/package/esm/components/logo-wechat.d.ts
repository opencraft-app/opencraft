import React from "react";
import { IconProps } from "../icon";
declare const LogoWechatIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LogoWechatIcon;
