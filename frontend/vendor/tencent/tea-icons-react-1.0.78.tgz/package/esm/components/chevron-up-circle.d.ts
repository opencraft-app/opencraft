import React from "react";
import { IconProps } from "../icon";
declare const ChevronUpCircleIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ChevronUpCircleIcon;
