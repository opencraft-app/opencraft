import React from "react";
import { IconProps } from "../icon";
declare const MonitorIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default MonitorIcon;
