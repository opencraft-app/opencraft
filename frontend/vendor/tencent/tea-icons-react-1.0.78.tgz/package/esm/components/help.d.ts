import React from "react";
import { IconProps } from "../icon";
declare const HelpIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default HelpIcon;
