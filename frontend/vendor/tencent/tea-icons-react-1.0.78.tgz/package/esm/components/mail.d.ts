import React from "react";
import { IconProps } from "../icon";
declare const MailIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default MailIcon;
