import React from "react";
import { IconProps } from "../icon";
declare const FileExcelIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default FileExcelIcon;
