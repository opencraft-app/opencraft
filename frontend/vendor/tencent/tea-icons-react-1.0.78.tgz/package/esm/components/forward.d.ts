import React from "react";
import { IconProps } from "../icon";
declare const ForwardIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ForwardIcon;
