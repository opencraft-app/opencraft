import React from "react";
import { IconProps } from "../icon";
declare const NextIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default NextIcon;
