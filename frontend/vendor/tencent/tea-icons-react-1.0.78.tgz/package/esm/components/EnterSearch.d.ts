import React from "react";
import { IconProps } from "../icon";
declare const EnterSearchIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default EnterSearchIcon;
