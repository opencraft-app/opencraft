import React from "react";
import { IconProps } from "../icon";
declare const ChevronDownIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ChevronDownIcon;
