import React from "react";
import { IconProps } from "../icon";
declare const FileDailyIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default FileDailyIcon;
