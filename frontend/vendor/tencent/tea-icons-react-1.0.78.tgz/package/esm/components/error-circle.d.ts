import React from "react";
import { IconProps } from "../icon";
declare const ErrorCircleIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ErrorCircleIcon;
