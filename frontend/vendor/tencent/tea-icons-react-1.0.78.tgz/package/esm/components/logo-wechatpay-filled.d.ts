import React from "react";
import { IconProps } from "../icon";
declare const LogoWechatpayFilledIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LogoWechatpayFilledIcon;
