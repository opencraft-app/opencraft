import React from "react";
import { IconProps } from "../icon";
declare const FilterFilledIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default FilterFilledIcon;
