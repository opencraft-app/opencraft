import React from "react";
import { IconProps } from "../icon";
declare const FilePdfIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default FilePdfIcon;
