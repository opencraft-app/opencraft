import React from "react";
import { IconProps } from "../icon";
declare const FilePasteIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default FilePasteIcon;
