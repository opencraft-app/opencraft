import React from "react";
import { IconProps } from "../icon";
declare const CallFilledIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CallFilledIcon;
