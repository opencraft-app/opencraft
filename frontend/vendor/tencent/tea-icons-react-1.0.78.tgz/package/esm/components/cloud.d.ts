import React from "react";
import { IconProps } from "../icon";
declare const CloudIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CloudIcon;
