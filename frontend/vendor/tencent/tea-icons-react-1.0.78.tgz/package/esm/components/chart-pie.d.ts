import React from "react";
import { IconProps } from "../icon";
declare const ChartPieIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ChartPieIcon;
