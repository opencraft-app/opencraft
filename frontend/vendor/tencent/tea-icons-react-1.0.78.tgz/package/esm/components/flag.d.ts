import React from "react";
import { IconProps } from "../icon";
declare const FlagIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default FlagIcon;
