import React from "react";
import { IconProps } from "../icon";
declare const OrderAscendingIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default OrderAscendingIcon;
