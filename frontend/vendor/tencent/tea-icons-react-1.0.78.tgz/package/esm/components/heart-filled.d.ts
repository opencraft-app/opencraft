import React from "react";
import { IconProps } from "../icon";
declare const HeartFilledIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default HeartFilledIcon;
