import React from "react";
import { IconProps } from "../icon";
declare const MinusCircleIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default MinusCircleIcon;
