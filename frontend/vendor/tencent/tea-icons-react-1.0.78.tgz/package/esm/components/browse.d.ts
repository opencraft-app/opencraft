import React from "react";
import { IconProps } from "../icon";
declare const BrowseIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default BrowseIcon;
