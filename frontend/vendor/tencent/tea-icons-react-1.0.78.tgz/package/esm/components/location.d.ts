import React from "react";
import { IconProps } from "../icon";
declare const LocationIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LocationIcon;
