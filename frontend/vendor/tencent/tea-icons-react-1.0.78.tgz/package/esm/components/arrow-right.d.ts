import React from "react";
import { IconProps } from "../icon";
declare const ArrowRightIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ArrowRightIcon;
