import React from "react";
import { IconProps } from "../icon";
declare const BarcodeIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default BarcodeIcon;
