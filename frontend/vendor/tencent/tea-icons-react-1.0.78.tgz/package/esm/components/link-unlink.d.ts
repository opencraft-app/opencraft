import React from "react";
import { IconProps } from "../icon";
declare const LinkUnlinkIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LinkUnlinkIcon;
