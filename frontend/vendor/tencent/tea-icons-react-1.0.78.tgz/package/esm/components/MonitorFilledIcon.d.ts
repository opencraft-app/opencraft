import React from "react";
import { IconProps } from "../icon";
declare const MonitorFilledIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default MonitorFilledIcon;
