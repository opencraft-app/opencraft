import React from "react";
import { IconProps } from "../icon";
declare const CheckRectangleFilledIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CheckRectangleFilledIcon;
