import React from "react";
import { IconProps } from "../icon";
declare const ColumnSearchIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ColumnSearchIcon;
