import React from "react";
import { IconProps } from "../icon";
declare const HistoryFilledIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default HistoryFilledIcon;
