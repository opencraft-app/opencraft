import React from "react";
import { IconProps } from "../icon";
declare const LockOnIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LockOnIcon;
