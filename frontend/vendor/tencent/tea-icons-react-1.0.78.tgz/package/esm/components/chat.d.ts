import React from "react";
import { IconProps } from "../icon";
declare const ChatIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ChatIcon;
