import React from "react";
import { IconProps } from "../icon";
declare const ArrowRightStrokeIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ArrowRightStrokeIcon;
