import React from "react";
import { IconProps } from "../icon";
declare const FormatHorizontalAlignCenterIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default FormatHorizontalAlignCenterIcon;
