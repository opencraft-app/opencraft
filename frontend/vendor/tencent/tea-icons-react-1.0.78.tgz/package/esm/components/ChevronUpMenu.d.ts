import React from "react";
import { IconProps } from "../icon";
declare const ChevronUpMenuIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ChevronUpMenuIcon;
