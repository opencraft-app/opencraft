import React from "react";
import { IconProps } from "../icon";
declare const FilterClearFilledIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default FilterClearFilledIcon;
