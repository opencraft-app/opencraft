import React from "react";
import { IconProps } from "../icon";
declare const CurIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CurIcon;
