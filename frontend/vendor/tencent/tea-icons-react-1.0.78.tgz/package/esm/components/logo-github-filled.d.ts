import React from "react";
import { IconProps } from "../icon";
declare const LogoGithubFilledIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LogoGithubFilledIcon;
