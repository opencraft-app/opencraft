import React from "react";
import { IconProps } from "../icon";
declare const CloudUploadIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CloudUploadIcon;
