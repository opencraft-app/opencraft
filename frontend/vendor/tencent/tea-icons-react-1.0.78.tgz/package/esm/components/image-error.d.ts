import React from "react";
import { IconProps } from "../icon";
declare const ImageErrorIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ImageErrorIcon;
