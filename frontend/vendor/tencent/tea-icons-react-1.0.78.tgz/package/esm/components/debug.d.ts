import React from "react";
import { IconProps } from "../icon";
declare const DebugIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default DebugIcon;
