import React from "react";
import { IconProps } from "../icon";
declare const ChevronUpSearchIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ChevronUpSearchIcon;
