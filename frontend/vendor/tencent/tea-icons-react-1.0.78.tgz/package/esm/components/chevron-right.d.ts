import React from "react";
import { IconProps } from "../icon";
declare const ChevronRightIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ChevronRightIcon;
