import React from "react";
import { IconProps } from "../icon";
declare const LogoAppleFilledIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LogoAppleFilledIcon;
