import React from "react";
import { IconProps } from "../icon";
declare const FormatVerticalAlignLeftIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default FormatVerticalAlignLeftIcon;
