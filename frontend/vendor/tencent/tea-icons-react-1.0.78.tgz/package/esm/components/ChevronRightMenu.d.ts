import React from "react";
import { IconProps } from "../icon";
declare const ChevronRightMenuIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ChevronRightMenuIcon;
