import React from "react";
import { IconProps } from "../icon";
declare const ForkIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ForkIcon;
