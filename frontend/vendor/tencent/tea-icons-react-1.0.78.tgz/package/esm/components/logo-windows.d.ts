import React from "react";
import { IconProps } from "../icon";
declare const LogoWindowsIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LogoWindowsIcon;
