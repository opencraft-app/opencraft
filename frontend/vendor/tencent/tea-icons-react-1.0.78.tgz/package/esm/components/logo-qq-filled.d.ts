import React from "react";
import { IconProps } from "../icon";
declare const LogoQqFilledIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LogoQqFilledIcon;
