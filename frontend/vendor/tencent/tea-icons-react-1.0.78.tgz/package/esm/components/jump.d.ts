import React from "react";
import { IconProps } from "../icon";
declare const JumpIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default JumpIcon;
