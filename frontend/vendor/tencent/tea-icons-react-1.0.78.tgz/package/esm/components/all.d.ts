import React from "react";
import { IconProps } from "../icon";
declare const AllIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default AllIcon;
