import React from "react";
import { IconProps } from "../icon";
declare const FileCopyIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default FileCopyIcon;
