import React from "react";
import { IconProps } from "../icon";
declare const LanguageIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LanguageIcon;
