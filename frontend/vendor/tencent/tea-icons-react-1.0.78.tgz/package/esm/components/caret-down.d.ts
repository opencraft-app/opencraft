import React from "react";
import { IconProps } from "../icon";
declare const CaretDownIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CaretDownIcon;
