import React from "react";
import { IconProps } from "../icon";
declare const ArrowUpIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ArrowUpIcon;
