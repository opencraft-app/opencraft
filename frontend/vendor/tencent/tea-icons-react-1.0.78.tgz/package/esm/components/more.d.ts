import React from "react";
import { IconProps } from "../icon";
declare const MoreIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default MoreIcon;
