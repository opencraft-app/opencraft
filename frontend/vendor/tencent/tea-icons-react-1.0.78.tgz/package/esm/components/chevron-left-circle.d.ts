import React from "react";
import { IconProps } from "../icon";
declare const ChevronLeftCircleIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ChevronLeftCircleIcon;
