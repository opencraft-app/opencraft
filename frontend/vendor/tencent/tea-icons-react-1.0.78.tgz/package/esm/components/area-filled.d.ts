import React from "react";
import { IconProps } from "../icon";
declare const AreaFilledIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default AreaFilledIcon;
