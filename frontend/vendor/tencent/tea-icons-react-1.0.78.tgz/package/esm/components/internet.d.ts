import React from "react";
import { IconProps } from "../icon";
declare const InternetIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default InternetIcon;
