import React from "react";
import { IconProps } from "../icon";
declare const BacktopIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default BacktopIcon;
