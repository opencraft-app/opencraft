import React from "react";
import { IconProps } from "../icon";
declare const ArrowFlatIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ArrowFlatIcon;
