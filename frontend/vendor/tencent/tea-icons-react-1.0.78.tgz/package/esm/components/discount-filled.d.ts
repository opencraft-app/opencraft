import React from "react";
import { IconProps } from "../icon";
declare const DiscountFilledIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default DiscountFilledIcon;
