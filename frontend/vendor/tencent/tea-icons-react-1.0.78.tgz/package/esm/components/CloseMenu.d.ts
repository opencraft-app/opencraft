import React from "react";
import { IconProps } from "../icon";
declare const CloseMenuIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CloseMenuIcon;
