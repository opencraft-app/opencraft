import React from "react";
import { IconProps } from "../icon";
declare const MobileIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default MobileIcon;
