import React from "react";
import { IconProps } from "../icon";
declare const CircleIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CircleIcon;
