import React from "react";
import { IconProps } from "../icon";
declare const DoubleColumnSearchIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default DoubleColumnSearchIcon;
