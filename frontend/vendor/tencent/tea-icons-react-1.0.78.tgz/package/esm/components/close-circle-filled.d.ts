import React from "react";
import { IconProps } from "../icon";
declare const CloseCircleFilledIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CloseCircleFilledIcon;
