import React from "react";
import { IconProps } from "../icon";
declare const BoxIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default BoxIcon;
