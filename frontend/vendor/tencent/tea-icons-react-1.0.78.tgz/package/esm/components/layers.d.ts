import React from "react";
import { IconProps } from "../icon";
declare const LayersIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LayersIcon;
