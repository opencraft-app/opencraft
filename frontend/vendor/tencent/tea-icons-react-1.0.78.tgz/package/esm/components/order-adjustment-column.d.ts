import React from "react";
import { IconProps } from "../icon";
declare const OrderAdjustmentColumnIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default OrderAdjustmentColumnIcon;
