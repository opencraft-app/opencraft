import React from "react";
import { IconProps } from "../icon";
declare const CloseIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CloseIcon;
