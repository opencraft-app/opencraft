import React from "react";
import { IconProps } from "../icon";
declare const CurActiveIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CurActiveIcon;
