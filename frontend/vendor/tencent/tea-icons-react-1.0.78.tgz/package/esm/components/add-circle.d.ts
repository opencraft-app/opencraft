import React from "react";
import { IconProps } from "../icon";
declare const AddCircleIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default AddCircleIcon;
