import React from "react";
import { IconProps } from "../icon";
declare const BooksIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default BooksIcon;
