import React from "react";
import { IconProps } from "../icon";
declare const LaptopIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LaptopIcon;
