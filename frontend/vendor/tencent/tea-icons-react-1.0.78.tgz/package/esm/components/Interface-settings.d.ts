import React from "react";
import { IconProps } from "../icon";
declare const InterfaceSettingsIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default InterfaceSettingsIcon;
