import React from "react";
import { IconProps } from "../icon";
declare const ArchitectureIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ArchitectureIcon;
