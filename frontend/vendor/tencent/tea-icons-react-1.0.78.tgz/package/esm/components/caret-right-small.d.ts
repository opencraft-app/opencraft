import React from "react";
import { IconProps } from "../icon";
declare const CaretRightSmallIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default CaretRightSmallIcon;
