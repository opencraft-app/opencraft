import React from "react";
import { IconProps } from "../icon";
declare const NotificationFilledIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default NotificationFilledIcon;
