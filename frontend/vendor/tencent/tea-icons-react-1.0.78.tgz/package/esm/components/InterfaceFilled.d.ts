import React from "react";
import { IconProps } from "../icon";
declare const InterfaceFilledIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default InterfaceFilledIcon;
