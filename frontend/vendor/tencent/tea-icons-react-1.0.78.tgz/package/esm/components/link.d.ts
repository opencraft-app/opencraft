import React from "react";
import { IconProps } from "../icon";
declare const LinkIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LinkIcon;
