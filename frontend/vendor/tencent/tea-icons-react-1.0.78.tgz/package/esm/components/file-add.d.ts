import React from "react";
import { IconProps } from "../icon";
declare const FileAddIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default FileAddIcon;
