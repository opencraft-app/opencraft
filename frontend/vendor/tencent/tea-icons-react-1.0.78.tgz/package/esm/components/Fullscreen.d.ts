import React from "react";
import { IconProps } from "../icon";
declare const FullscreenIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default FullscreenIcon;
