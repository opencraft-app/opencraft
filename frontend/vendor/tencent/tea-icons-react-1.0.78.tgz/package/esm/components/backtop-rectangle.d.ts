import React from "react";
import { IconProps } from "../icon";
declare const BacktopRectangleIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default BacktopRectangleIcon;
