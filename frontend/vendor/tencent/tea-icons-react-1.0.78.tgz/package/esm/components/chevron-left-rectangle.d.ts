import React from "react";
import { IconProps } from "../icon";
declare const ChevronLeftRectangleIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default ChevronLeftRectangleIcon;
