import React from "react";
import { IconProps } from "../icon";
declare const PageFirstIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default PageFirstIcon;
