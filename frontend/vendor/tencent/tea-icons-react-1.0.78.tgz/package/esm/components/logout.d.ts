import React from "react";
import { IconProps } from "../icon";
declare const LogoutIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default LogoutIcon;
