import React from "react";
import { IconProps } from "../icon";
declare const EmailErrorIcon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<SVGSVGElement>>;
export default EmailErrorIcon;
