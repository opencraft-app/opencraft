import { CSSProperties, SVGAttributes, ForwardRefExoticComponent, RefAttributes } from "react";
export interface IconColor {
    targetColor: string;
    reviseColor: string;
}
export interface IconProps extends SVGAttributes<SVGSVGElement> {
    style?: CSSProperties;
    className?: string;
    size?: number | string;
    /**
     * hover color修改: Colored 无效
     */
    hover?: string | IconColor[];
    /**
     * hover 背景色修改:Colored 无效
     */
    /**
     * 修改icon颜色: Colored 无效
     */
    colors?: string | IconColor[];
    /**
     * 修改icon颜色: Colored 无效 单色图标有用，多色图标无法使用
     */
    color?: string;
    /**
     * icon禁用
     * @deprecated 该属性已废弃，请不要使用
     */
    disabled?: boolean;
    /**
     * icon禁用
     */
    onClick?: (e?: React.MouseEvent<SVGSVGElement, MouseEvent>) => void;
}
export interface IconFulfilledProps extends IconProps {
    initColor: string[];
    initName: string;
}
export declare type CompoundedComponent = ForwardRefExoticComponent<IconFulfilledProps & RefAttributes<SVGElement>>;
export declare const useApiProps: (props: IconFulfilledProps) => {
    colorList: string[];
    sizeStyle: CSSProperties;
    cls: any;
    setColors: React.Dispatch<React.SetStateAction<string[]>>;
};
