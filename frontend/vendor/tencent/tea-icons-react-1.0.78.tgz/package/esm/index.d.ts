export * from "./icons";
export * from "./manifest";
export * from "./icon";
export * from "./configProvider";
export declare const Icon: {
    (props: import("./icon").IconProps): JSX.Element;
    displayName: string;
};
