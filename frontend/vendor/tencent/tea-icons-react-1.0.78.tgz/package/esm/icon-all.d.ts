import { IconProps } from './icon';
export interface IIcons extends IconProps {
    name: string;
}
declare const RuyiIcons: {
    (props: IconProps): JSX.Element;
    displayName: string;
};
export default RuyiIcons;
