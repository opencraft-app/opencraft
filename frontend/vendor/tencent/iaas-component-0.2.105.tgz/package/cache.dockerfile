# 选择一个 Base 镜像
FROM node:16.14.0

# 设置工作目录
WORKDIR /cache/

# 将 by 中的文件列表 COPY 过来
COPY package.json .
COPY package-lock.json .

# 根据 COPY 过来的文件进行依赖的安装
RUN npm install --registry https://mirrors.tencent.com/npm/
ENV NODE_PATH=/cache/node_modules
