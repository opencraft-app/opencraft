module.exports = {
  setupFilesAfterEnv: ["./tests/setupFramework.js"],
  transform: {
    "^.+\\.jsx?$": "./tests/custom-transformer.js",
    "^.+\\.tsx?$": "./tests/custom-transformer.js",
  },
  transformIgnorePatterns: ["node_modules/?!(popper.js)"],
  moduleFileExtensions: ["ts", "tsx", "js", "jsx", "json", "node"],
  verbose: true,
};
