[TOC]

# iaas-component 组件库

已接入 OCI，合并主干，自动发包 (.orange-ci.yml)

## 组件目录

## 开发

### 包调试

```shell


# 注册包
npm link


# 进入目标项目
npm link @tencent/iaas-component

```

#### 新建组件

如需新建组件，请先在上文 **组件目录** 中添加组件说明，并建立相对应的目录。
