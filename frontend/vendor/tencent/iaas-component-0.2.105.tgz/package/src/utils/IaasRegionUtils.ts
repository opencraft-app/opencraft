const constants = seajs.require('constants')

/**
 * regionId to area 映射
 *  1 => 华南地区
 */
export function getAreaByRegionId(regionId: number): string {
  // REGIONIDMAP['1'] = 'ap-guangzhou'
  const region = constants.REGIONIDMAP[regionId]
  // REGIONAREAMAP['ap-guangzhou'] = {name:'广州',area:'华南地区'}
  const areaInfo = constants.REGIONAREAMAP[region]
  return areaInfo ? areaInfo.area : ''
}
