import iaas from './iaas'
import { app } from '@tencent/tea-app'

/**
 * 云API请求
 * 入参 data内字段 请全部大写
 * 出参 全部大写，不再转换
 * @param {*} param0
 * @param {*} opts
 */
type IRegion = number
export interface IRequestParam {
  action: string
  data: any
  regionId: IRegion
}
export interface ICapiRequestParam extends IRequestParam {
  serviceType: string
  tcbRequest?: boolean
}

/**
 * qcbase cgi请求参数
 */
export interface ICgiRequestParam {
  cgi: string
  action: string
  data: any
  regionId: number
}
/**
 * iaas请求 设置
 */
export interface IRequestOpts {
  /** 是否显示全局加载条 默认true */
  global?: boolean
  /** 是否显示失败提示 默认true */
  tipErr?: boolean
  /** 是否使用经典的 json 回包(code=0, 表示成功, 其他表示失败) 默认true */
  classicResponse?: boolean
  camTips?: boolean
  camTipsType?: string
}
/**
 * 云 API 请求过滤条件
 */
interface ICapiRequestParamFilter {
  Name: string
  Values: string[]
}

/**
 * 云API请求
 * @param serviceType 业务缩写
 * @param action 云API方法
 * @param data 接口入参
 * @param regionId 请求地域 地域数字ID
 */
export async function capiRequest(
  { serviceType, action, data, regionId, tcbRequest = false }: ICapiRequestParam,
  opts?: IRequestOpts
) {
  return iaas.apiRequest(
    {
      serviceType,
      action,
      regionId,
      data,
    },
    {
      camTipsType: 'dialog',
      ...opts,
    }
  )
}

/**
 * qcbase cgi 请求
 * @param cgi 对应qcbase/views/文件名
 * @param action 对应cgi文件中的方法
 * @param data 入参
 */
export async function cgiRequest(
  { cgi, action, data = {}, regionId }: ICgiRequestParam,
  opts: IRequestOpts = { tipErr: true }
): Promise<any> {
  return new Promise(function(resolve, reject) {
    return iaas.request(`/cgi/${cgi}?action=${action}`, data, opts).then(
      function(res) {
        resolve(res)
      },
      function(res) {
        if (opts.tipErr && res?.code) {
          app.tips.error(`[${res.code}]${res.message}`)
        }
        reject(res)
      }
    )
  })
}
