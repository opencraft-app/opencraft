export interface IGetActionsAuth<T, N> {
  items: T[]
  events: string[]
  options?: N
  judgement: {
    /** 单个操作判断依据  */
    [eventName: string]: (items: T[], options: N) => string
    /** 所有操作共同判断依据 */
    common?: (items: T[], options: N) => string
  }
}
/**
 *
 */
export interface IOperateStatusMap {
  [eventName: string]: string
}

/**
 * 操作掩码
 * @param
 */
export function getAuth<T, N>(props: IGetActionsAuth<T, N>): IOperateStatusMap {
  const { items = [], options = null, events = [], judgement = {} } = props
  let operateAuth: IOperateStatusMap = {}
  events.forEach((eventName) => {
    /** 公共判定部分 */
    const commonAuth: string = judgement.common?.(items, options)
    if (commonAuth) {
      operateAuth[eventName] = commonAuth
      return
    }
    /** 单个操作部分 */
    operateAuth[eventName] = judgement[eventName]?.(items, options)
  })
  return operateAuth
}
