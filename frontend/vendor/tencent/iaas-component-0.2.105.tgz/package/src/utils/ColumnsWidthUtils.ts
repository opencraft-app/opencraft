import { TableColumn } from '@tencent/tea-component'
import sortBy from 'lodash/sortBy'
/** 默认表格padding值 */
const DEFAULT_PADDING = 20
/** 默认表格外的宽度  */
const DEFAULT_GRID_WIDTH = 250
/** 容错 */
const RONGCUO = 5

export interface IColumn extends TableColumn {
  /** 是否支持，如果不支持，则在列配置界面上也不展示 */
  supported?: boolean
  /** 是否强制展示，此时列配置界面无法取消勾选 */
  required?: boolean
  /** 是否默认隐藏，此时列配置界面上仍可添加勾选 */
  hide?: boolean
  /**  表最小宽度 */
  minWidth: number
  /**  表最大宽度 */
  maxWidth: number
  /**  优先级，在优先级条件下会自动根据优先级显示列 */
  priority?: number
}
export interface IFormatColumnsProps {
  /** 列 */
  originColumns: IColumn[]
  /** 默认展示的最大列 */
  maxLimit?: number
  /** 表格宽度 */
  gridWidth?: number
  /** 是否应用优先级 */
  isPriority?: boolean
  /** 表格padding值 */
  padding?: number
}

/**
 * 控制台列宽算法：根据最大最小值计算权重
 */
export default function formatColumns(props: IFormatColumnsProps) {
  const {
    originColumns,
    gridWidth = window.innerWidth - DEFAULT_GRID_WIDTH,
    isPriority = false,
    maxLimit,
    padding = DEFAULT_PADDING,
  } = props

  let dColumn: IColumn[] = originColumns.map((item) => ({ ...item }))
  let columns: IColumn[] = dColumn

  // 若是按优先级展示，超出最大列部分不展示
  if (isPriority && maxLimit) {
    const requiredColumns = dColumn.filter((col) => col.required)
    let highPropertyColumns = dColumn.filter((col) => !col.required)
    highPropertyColumns = sortBy(highPropertyColumns, 'priority').slice(
      0,
      maxLimit - requiredColumns.length
    )
    columns = dColumn.filter(
      (col) => col.required || !!highPropertyColumns.find((i) => i.key === col.key)
    )
  }

  let allConfigMinWidth = 0 /** 所有列最小宽读和 */
  let allConfigMaxWidth = 0 /** 所有列最大宽读和 */
  let allConfigWeight = 0 /** 剩余宽度和 */

  columns.map(function(col) {
    allConfigMinWidth += col.minWidth
    allConfigMaxWidth += col.maxWidth + padding
    allConfigWeight += col.maxWidth - col.minWidth
    return col
  })

  const len = columns.length
  let leaveWidth = gridWidth - padding * len - allConfigMinWidth - RONGCUO
  if (leaveWidth > 0 && allConfigMaxWidth > gridWidth) {
    columns.forEach(function(col) {
      col.width = Number(
        (
          col.minWidth +
          ((col.maxWidth - col.minWidth) * leaveWidth) / allConfigWeight +
          padding
        ).toFixed()
      )
    })
  } else {
    columns = leaveWidth > 0 ? setAllMaxWidth(columns, padding) : setAllMinWidth(columns, padding)
  }

  return columns
}

/*
 *所有列取最小宽度
 */
function setAllMinWidth(columns, padding) {
  return columns.map(function(col) {
    col.width = col.minWidth + padding
    return col
  })
}

/*
 *所有列取最大宽度
 */
function setAllMaxWidth(columns, padding) {
  const len = columns.length

  return columns.map(function(col, idx) {
    /**
     * @description 仅在有剩余空间时，设置最后一列为auto，以使其余固定宽度列不失效，其余清空，均设置自适应宽度
     */
    col.width = idx === len - 1 ? 'auto' : col.maxWidth + padding
    return col
  })
}

/**
 * @ getMaxCols
 * 计算显示最大列数公共方法
 * 根据分辨率设定最大展示列数
 */
export function getMaxCols() {
  let windowWidth = window.innerWidth
  let maxColNum
  switch (true) {
    case windowWidth <= 768:
      maxColNum = 4
      break
    case windowWidth <= 900:
      maxColNum = 5
      break
    case windowWidth <= 1024:
      maxColNum = 7
      break
    case windowWidth <= 1366:
      maxColNum = 9
      break
    case windowWidth <= 1440:
      maxColNum = 10
      break
    case windowWidth <= 1600:
      maxColNum = 11
      break
    case windowWidth <= 1680:
      maxColNum = 12
      break
    default:
      maxColNum = 12
      break
  }
  return maxColNum
}
