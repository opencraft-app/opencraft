let iaas
import qcloudIaasApi from '@tencent/qcloud-iaas-api'

try {
  iaas = seajs.require('models/iaas')
} catch (e) {
  iaas = qcloudIaasApi
}

export default iaas
