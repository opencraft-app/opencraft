// pageComponent 购买页标记， 在购买页不加载router，navigate函数请使用其他方式跳转
const proxyedRouter: any = { navigate: () => {} }
let router = proxyedRouter
if ((window as any).pageComponent !== 'buy') {
  seajs.use(['router'])
  router = seajs.require('router')
}
export { router }
