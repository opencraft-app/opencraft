import React from 'react';
import { SDKLoader } from '@tea/app';
import { LoadingTip as DefaultLoadingTipComponent } from '@tea/component/tips';

/**
 * 对 tea app 的 SDKLoader 进行封装，提供更简洁的调用 SDK Component 的方法 ，不必每次使用 SDK Component 都得用 SDKLoad 包裹一层
 * @param sdkName SDK 名
 * @param componentName 组件名
 */
export function loadTeaAppSdkComponent(sdkName: string, componentName: string) {
  return React.forwardRef(({
    sdkLoadingTip = <DefaultLoadingTipComponent/>,
    onSdkLoadError,
    ...componentProps
  }: any, ref) => {
    return (
      <SDKLoader
        sdkNames={[sdkName]}
        loading={sdkLoadingTip}
        error={onSdkLoadError}
        // error={(error, retry) => <ErrorTipComponent onRetry={retry} />}
      >
        {
          ([sdk]) => {
            if (sdk?.components?.[componentName]) {
              const Component = sdk.components[componentName];
              return <Component ref={ref} {...componentProps} />;
            }
            return null;
          }
        }
      </SDKLoader>
    );
  });
}
