import React from 'react'
import { t, Trans } from '@tencent/tea-app/lib/i18n'
import { Select, SelectProps } from '@tencent/tea-component'

export function Selector(props: SelectProps) {
  const { options, onChange, ...rest } = props
  const defaultOptions = [{ text: t('暂无数据'), value: '-1' }]
  return (
    <Select
      options={options?.length ? options : defaultOptions}
      onChange={options.length && onChange}
      {...rest}
    />
  )
}
