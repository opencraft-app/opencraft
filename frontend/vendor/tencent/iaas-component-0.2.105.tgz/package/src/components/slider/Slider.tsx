import React, { Component } from 'react'
import { Slider as SliderBase, SliderProps } from '@tencent/tea-component'

export interface ISliderProps extends SliderProps {
  /** 自定义展示的point值， 如[100, 200, 400] */
  points?: any[]
  unit?: string
}

export class Slider extends Component<ISliderProps> {
  /* eslint-disable */
  private adapter: Adapter = new Adapter()
  render() {
    const { min, max, value, onChange, points = [], unit = '', range, step, ...rest } = this.props
    const marks = this.adapter.getMarks(points, unit, step)
    const tipFormatter = (value) => {
      const label = this.adapter.decode(value) + unit
      return label || value
    }
    return (
      <SliderBase
        min={this.adapter.encode(min)}
        max={this.adapter.encode(max)}
        marks={this.props.marks || marks}
        value={this.adapter.encode(value)}
        range={[this.adapter.encode(range[0]), this.adapter.encode(range[1])]}
        tipFormatter={this.props.tipFormatter || tipFormatter}
        onChange={(value) => {
          onChange && onChange(this.adapter.decode(value), null)
        }}
        {...rest}
      />
    )
  }
}
class Adapter {
  points: any[]
  step: number
  getMarks(points, unit, step = 1) {
    if (points && points.length) {
      this.points = points
      this.step = step
      const count = points.length
      const max = points[count - 1]
      return points.map((value, index) => {
        return {
          value: ((index + 1) / count) * max,
          label: value + unit,
        }
      })
    }
  }
  encode(value) {
    const points = this.points
    const step = this.step
    if (!points || !points.length) {
      return value
    }
    let result = value
    const len = points.length
    let average = points[len - 1] / len
    points.forEach((currPoint, index) => {
      let lastPoint = index === 0 ? 0 : points[index - 1]
      let lastValue = average * index
      if (value >= lastPoint && value <= currPoint) {
        const newValue = Math.round(value / step) * step
        result =
          lastValue + Math.floor(((newValue - lastPoint) * average) / (currPoint - lastPoint))
      }
    })
    return result
  }
  decode(value) {
    const points = this.points
    const step = this.step
    if (!points || !points.length) {
      return value
    }
    let result = value
    const len = points.length
    let average = points[len - 1] / len
    points.forEach((currPoint, index) => {
      let lastPoint = index === 0 ? 0 : points[index - 1]
      let lastValue = average * index
      let currValue = average * (index + 1)
      if (value >= lastValue && value <= currValue) {
        result = lastPoint + Math.floor(((value - lastValue) * (currPoint - lastPoint)) / average)
      }
    })
    return Math.round(result / step) * step
  }
}
