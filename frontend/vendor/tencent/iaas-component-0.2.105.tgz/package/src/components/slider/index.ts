export { ISliderProps, Slider } from './Slider'
