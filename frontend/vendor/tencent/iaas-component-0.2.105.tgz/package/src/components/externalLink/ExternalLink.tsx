import React, { Component } from 'react'
import { app } from '@tencent/tea-app'
import { ExternalLink as TeaExternalLink, ExternalLinkProps } from '@tencent/tea-component'
import classNames from 'classnames'
export interface IExternalLinkProps extends ExternalLinkProps {
  /**
   * 是否需要icon，默认为true
   */
  icon?: boolean
}

export class ExternalLink extends Component<IExternalLinkProps> {
  onClick(e) {
    const { href, onClick } = this.props
    onClick && onClick(e)
    e.stopPropagation()
    app.insight.stat({
      ns: location.pathname.split('/')[1] || 'cvm',
      event: 'click-external-link',
      stringFields: {
        href,
      },
    })
  }
  render() {
    const { icon = true, weak = false, onClick, ...props } = this.props
    if (icon) {
      return <TeaExternalLink onClick={this.onClick.bind(this)} weak={weak} {...props} />
    } else {
      return (
        <a
          href={this.props.href}
          target="_blank"
          rel="noopener noreferrer"
          className={classNames({
            'tea-text': weak,
          })}
          onClick={this.onClick.bind(this)}
          {...props}
        >
          {this.props.children}
        </a>
      )
    }
  }
}
