import React, { useEffect, useState } from 'react'
import { t } from '@tencent/tea-app/lib/i18n'
import {
  Segment, SegmentProps, Button, SelectOption, Badge,
  Bubble, Dropdown, List, Justify, Text 
} from '@tencent/tea-component'

export interface ITimePillProps extends Omit<SegmentProps, 'options'> {
  /** 可自定义 */
  options?: Array<SelectOption & {
    discount?: string
  }>
  /** 当前选中值 */
  value?: string
  /**
   * 值发生变更时进行回调
   * - `value` 变更的目标值
   * - `context` 此次变更的更多上下文信息，其中 `context.event` 可以获得导致变更的 React 事件
   */
  /**
   * 是否显示所有，默认为false
   */
  all?: boolean
  onToggleAll?: (all: boolean)=>void
  onChange?: (value: string) => void
  /** 是否显示折扣信息 */
  showDiscountIcon?: boolean
  bubbleContent?: string
  /**
   * 下拉框选项,当时长非常多的时候适用
   */
  dropdownOptions?: Array<SelectOption & {
    discount?: string
  }>
}

export const TimePill = function(props: ITimePillProps) {
  const {
    showDiscountIcon = true, value, onChange,
    options, all = false, onToggleAll, bubbleContent, dropdownOptions, ...rest
  } = props
  const [showAllPill, setShowAllPill] = useState(all)
  const defaultOptions = getDefaultTimeOptions(showAllPill, value)
  return (
    <div>
      <Segment
        value={value}
        onChange={onChange}
        options={
          (options || defaultOptions).map((item) => ({
            text:
              item.discount && showDiscountIcon ? (
                <span>
                  {item.text}
                  <Bubble content={bubbleContent}>
                    <Badge theme="warning" dark>
                    {item.discount}
                    </Badge>
                  </Bubble>
                </span>
              ) : (
                item.text
              ),
            value: item.value,
          }))
        }
        {...rest}
      />
      {showAllPill ? null : (
        <Button
          className="ml-5"
          type="link"
          onClick={() => {
            setShowAllPill(!showAllPill);
            if (onToggleAll) {
              onToggleAll(!showAllPill);
            }
          }}
        >
          {t('其他时长')}
        </Button>
      )}
      {dropdownOptions?.length ? <TimeDropdown 
      value={value} 
      onChange={onChange}
      dropdownOptions={dropdownOptions}
      showDiscountIcon={showDiscountIcon}/>
      : null}
    </div>
  )
}

interface ITimeDropdownProps {
  value: string;
  onChange: (value: string) => void;
  showDiscountIcon: boolean;
  dropdownOptions?: Array<SelectOption & {
    discount?: string
  }>
}
const TimeDropdown = ({value, dropdownOptions, onChange, showDiscountIcon}: ITimeDropdownProps) => {
  const [selectText, setSelectText] = useState(null);
  useEffect(() => {
    const finder = dropdownOptions?.find((item) => item.value === value);
    if (finder?.discount && showDiscountIcon) {
      setSelectText(
        <>
          {finder.text}
          <Badge theme="warning" dark>
            {finder.discount}
          </Badge>
        </>
      );
    } else {
      setSelectText(finder?.text);
    }
  }, [value, dropdownOptions]);
  return (
    <Dropdown
      style={{ marginLeft: 8, minWidth: 100 }}
      button={selectText || t('更多时长')}
      appearance="button"
      matchButtonWidth
      >
      <List type="option">
        {dropdownOptions?.map((item, index) => (
          <List.Item key={index} onClick={() => {
            onChange(item.value);
          }}>
            <Justify
              left={<Text reset>{item.text}</Text>}
              right={item.discount && showDiscountIcon ? 
                <Badge theme="warning" dark>
                  {item.discount}
                </Badge> : null
              }
              />
          </List.Item>
        ))}
      </List>
    </Dropdown>
  );
}


function getDefaultTimeOptions(showAllPill: boolean, value: string) {
  const monthSection = []
  const monthLen = showAllPill ? 11 : 3
  for (let i = 1; i < monthLen + 1; i++) {
    const checked = value === String(i)
    const text = checked ? t('{{count}}个月', { count: i }) : i
    if (i >= 6) {
      monthSection.push({
        text,
        value: String(i),
        discount: t('88折'),
      })
    } else {
      monthSection.push({
        text,
        value: String(i),
      })
    }
  }
  const YEAR_SECTION = [
    { text: t('1年'), value: '12', discount: t('83折') },
    { text: t('2年'), value: '24', discount: t('7折') },
    { text: t('3年'), value: '36', discount: t('5折') },
    { text: t('4年'), value: '48', discount: t('5折') },
    { text: t('5年'), value: '60', discount: t('5折') },
  ]
  return monthSection.concat(YEAR_SECTION)
}
