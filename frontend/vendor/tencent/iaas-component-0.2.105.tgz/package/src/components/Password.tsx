import React, { useState } from 'react'
import * as classnames from 'classnames'
import { Bubble, Input, BubbleProps } from '@tencent/tea-component'
import { t, Trans } from '@tencent/tea-app/lib/i18n'
const { Password: TeaPassword } = Input;

export interface IPasswordProps extends Omit<BubbleProps, 'onBlur' | 'onChange'> {
  /** windows机器 */
  hasWindowsSystem: boolean
  /** linux 机器 */
  hasLinuxSystem: boolean
  placement?: 'right' | 'top' | 'left' | 'bottom'
  userName?: string
  /** 是否可用 */
  disabled?: boolean
  placeholder?: string
  value: string
  onBlur?: Function
  onChange?: ({ value: string, valid: boolean }) => void
  // 自定义tips
  renderTips?: (publicTips: string) => string
}

interface IPasswordState {
  value?: string
  valid?: boolean
  isStrongPassword?: boolean
  rules?: Array<any>
  osType?: string
}
interface IRuleItem {
  name: string
  desc: string
  con: Function | RegExp
  valid?: boolean
  children?: Array<IRuleItem>
}
/** 操作系统类型 */
const INSTANCE_OS_TYPE = {
  WINDOWS: 'windows',
  LINUX: 'linux',
  MINXINSYSTEM: 'minxinSystem',
}
const publicTips = t(
  "不能包含空格，不支持“/”置于密码首位，至少包括三项（[a-z],[A-Z],[0-9]和[()`~!@#$%^&*-+=_|{}[]:;'<>,.?/]的特殊符号）"
)
const tipMap = {
  [INSTANCE_OS_TYPE.LINUX]: t('Linux机器密码需8到30位，{{publicTips}}', {
    publicTips,
  }),
  [INSTANCE_OS_TYPE.WINDOWS]: t(
    'Windows机器密码需12到30位，{{publicTips}}，且不得包含用户名，如：“administrator”（大小写不敏感）',
    { publicTips }
  ),
  [INSTANCE_OS_TYPE.MINXINSYSTEM]: t(
    '机器密码需12到30位，{{publicTips}}，且不得包含用户名，如：“administrator”（大小写不敏感）',
    { publicTips }
  ),
}
const strongTip = t(
  "提示：您的密码已经符合设置密码规则，但密码需要具备一定的强度，建议您的密码设置12位及以上，至少包括4项（[a-z],[A-Z],[0-9]和[()`~!@#$%^&*-+=_|{}[]:;'<>,.?/]的特殊符号]），每种字符大于等于2位且不相同。"
)
export class Password extends React.Component<IPasswordProps, IPasswordState> {
  constructor(props) {
    super(props)
    const osType =
      this.props.hasWindowsSystem && this.props.hasLinuxSystem
        ? INSTANCE_OS_TYPE.MINXINSYSTEM
        : this.props.hasLinuxSystem
        ? INSTANCE_OS_TYPE.LINUX
        : INSTANCE_OS_TYPE.WINDOWS
    this.state = {
      value: this.props.value || '',
      valid: true,
      isStrongPassword: true,
      osType: osType,
      rules: getRules(osType, this.props.userName),
    }
  }
  /* eslint-disable */
  isStrong(value) {
    const numbers = '0123456789'
    const letters = 'abcdefghijklmnopqrstuvwxyz'
    const symbols = "()`~!@#$%^&*-+=_|{}[]:;'<>,.?/"
    const result = [numbers, letters, letters.toUpperCase(), symbols].map((item) => {
      const arr = item.split('')
      const count = arr.reduce((prev, one) => (value.indexOf(one) > -1 ? ++prev : prev), 0)
      return count
    })
    return result.every((count) => count >= 2)
  }

  validate(value) {
    const { rules = [] } = this.state
    const _validate = (rules = []) => {
      const test = (con, value, res = []) => {
        let valid
        if (Object.prototype.toString.call(con) === '[object RegExp]') {
          valid = con.test(value)
        } else if (Object.prototype.toString.call(con) === '[object Function]') {
          valid = con.call(this, value, res)
        }
        return valid
      }
      return rules.map((item) => {
        const con = item.con || (() => {})
        let children, valid
        if (item.children && item.children.length) {
          children = _validate(item.children)
          valid = test(
            item.con,
            value,
            children.map((item) => item.valid)
          )
          return { ...item, children, valid }
        } else {
          valid = test(item.con, value)
          return { ...item, valid }
        }
      })
    }
    return _validate(rules)
  }

  handleChange(value) {
    const { onChange } = this.props
    const rules = this.validate(value)
    const valid = rules.every((item) => item.valid)
    onChange({ value, valid })
    this.setState({
      value,
      rules,
      valid,
    })
  }

  handleBlur() {
    const { onBlur } = this.props
    const { value, rules = [] } = this.state
    const valid = rules.every((item) => item.valid)
    const isStrongPassword = this.isStrong(value)
    this.setState({
      valid,
      isStrongPassword,
    })
    onBlur && onBlur()
  }

  render() {
    const { placeholder, disabled, placement = 'right', renderTips } = this.props
    const { value, valid, isStrongPassword, rules = [], osType } = this.state
    return (
      <span className={classnames({ 'is-error': !valid })}>
        <Bubble
          trigger="click"
          placement={placement}
          content={
            <ul className="mod-password-tips">
              {rules.map((item) => (
                <li className={classnames({ success: item.valid })} key={item.desc}>
                  <p>
                    <i className="n-success-icon" />
                    {item.desc}
                  </p>
                  {item.children ? (
                    <ul className="sub-list">
                      {item.children.map((one) => (
                        <li
                          className={classnames({
                            success: one.valid,
                          })}
                          key={one.name}
                        >
                          <p>
                            <i className="n-success-icon" />
                            {one.desc}
                          </p>
                        </li>
                      ))}
                    </ul>
                  ) : null}
                </li>
              ))}
            </ul>
          }
        >
          <TeaPassword
            rules={false}
            value={value}
            placeholder={placeholder}
            onBlur={!disabled && this.handleBlur.bind(this)}
            onChange={!disabled && this.handleChange.bind(this)}
          />
        </Bubble>
        {!valid ? (
          <p className={classnames('tea-form__help-text', 'tea-text-danger')}>
            {renderTips ? renderTips(publicTips) : tipMap[osType] || ''}
          </p>
        ) : !isStrongPassword ? (
          <p className={classnames('tea-form__help-text')}>
            <span>{strongTip}</span>
          </p>
        ) : null}
      </span>
    )
  }
}

export const SecondPassword = function({
  password,
  value,
  onChange,
  placeholder,
  onBlur,
  onFocus,
  valid,
}: {
  password: string
  value: string
  onChange: (value: string) => void
  placeholder?: string
  onBlur: () => any
  onFocus: () => any
  valid: boolean
}) {
  return (
    <div className={classnames({ 'is-error': !valid })}>
      <TeaPassword
        rules={false}
        placeholder={placeholder}
        value={value}
        onBlur={onBlur}
        onChange={onChange}
        onFocus={onFocus}
      />
      {!valid ? (
        <p className={classnames('tea-form__help-text', 'text-danger')}>{t('两次密码不一致！')}</p>
      ) : null}
    </div>
  )
}

const symbolRegStr = "()`~!@#$%^&*-+=_|{}[]:;'<>,.?/"
  .split('')
  .map(function(s) {
    return '\\' + s
  })
  .join('')

/** 操作系统通用密码规则 */
const basicRule: IRuleItem[] = [
  {
    name: 'space',
    desc: t('不能包含空格'),
    con: /^[^ ]+$/,
  },
  {
    name: 'character',
    desc: t('只能输入大写字母、小写字母、数字、()`~!@#$%^&*-+=_|{}[]:;\'<>,.?/ 中的特殊符号'),
    con: new RegExp('^[\\da-zA-Z' + symbolRegStr + ']+$'),
  },
  {
    name: 'start',
    desc: t('不能以“/”开头'),
    con: /^(?!\/).+$/,
  },
  {
    name: 'content',
    desc: t('至少包含三项'),
    children: [
      {
        name: 'lowerCase',
        desc: t('小写字母a~z'),
        con: /[a-z]+/,
      },
      {
        name: 'upperCase',
        desc: t('大写字母A~Z'),
        con: /[A-Z]+/,
      },
      {
        name: 'number',
        desc: t('数字0~9'),
        con: /[0-9]+/,
      },
      {
        name: 'symbol',
        desc: "()`~!@#$%^&*-+=_|{}[]:;'<>,.?/",
        con: new RegExp('[' + symbolRegStr + ']'),
      },
    ],
    con: (value, res) => {
      const count = res.reduce((prev, data) => prev + (data ? 1 : 0), 0)
      return count >= 3
    },
  },
]
/** windows系统密码长度限制 */
const windowsLengthRule: IRuleItem[] = [
  {
    name: 'length',
    desc: t('长度12~30位'),
    con: new RegExp('^.{12,30}$'),
  },
]
/** linux系统密码长度限制 */
const linuxLengthRule: IRuleItem[] = [
  {
    name: 'length',
    desc: t('长度8~30位，推荐使用12位以上的密码'),
    con: new RegExp('^.{8,30}$'),
  },
]
/**
 * 密码校验规则
 * @param osType 操作系统
 * @param userName 用户名，默认为
 */
function getRules(osType: string, userName: string): IRuleItem[] {
  const name = 'administrator'
  const usernameRule: IRuleItem[] = [
    {
      name: 'username',
      desc: t('不包括用户名'),
      con: /^((?!administrator).)+$/i,
    },
  ]
  const windowsRule = windowsLengthRule.concat(basicRule, usernameRule)
  const linuxRule = linuxLengthRule.concat(basicRule)
  const ruleMap = {
    [INSTANCE_OS_TYPE.LINUX]: linuxRule,
    [INSTANCE_OS_TYPE.WINDOWS]: windowsRule,
    [INSTANCE_OS_TYPE.MINXINSYSTEM]: windowsRule,
  }
  return ruleMap[osType] || []
}
