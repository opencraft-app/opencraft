import React from 'react'
import { HtmlAttributes } from 'csstype'

export interface IRouterLinkProps extends React.HTMLAttributes<HTMLAnchorElement> {
  href: string
}
export function RouterLink(props: IRouterLinkProps) {
  const {href, children, ...rest} = props
  return (
    <a href={href || 'javascript: void(0);'} data-event="nav" {...rest}>
      {children}
    </a>
  )
}
