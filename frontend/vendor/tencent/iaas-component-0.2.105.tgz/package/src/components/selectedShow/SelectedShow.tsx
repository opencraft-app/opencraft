import React, { useState } from 'react'
import { t } from '@tencent/tea-app/lib/i18n'
import { Table, TableProps, Button, useClassNames } from '@tencent/tea-component'
import { forwardRefWithStatics } from '../../_util/forward-ref-with-statics'

export interface SelectedShowProps extends TableProps {
  /**
   * 组件内容
   */
  children?: React.ReactNode
}

export const SelectedShow = forwardRefWithStatics(
  (props: SelectedShowProps, ref: React.Ref<HTMLDivElement>) => {
    const [isExpand, setExpand] = useState(true)
    const { children, ...rest } = props
    const { Margin } = useClassNames()
    return (
      <div className={Margin.Bottom['5n']}>
        <p className={Margin.Bottom['1n']}>
          {children}
          <Button
            style={{ verticalAlign: 'baseline' }}
            type="link"
            className={Margin.Left['1n']}
            onClick={() => {
              setExpand(!isExpand)
            }}
          >
            {isExpand ? t('收起') : t('查看详情')}
          </Button>
        </p>
        {isExpand ? <Table ref={ref} {...rest} /> : null}
      </div>
    )
  },
  {
    defaultLabelAlign: 'middle',
  }
)
