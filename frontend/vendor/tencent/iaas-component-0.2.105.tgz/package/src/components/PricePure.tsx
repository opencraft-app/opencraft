import React, { Fragment } from 'react'
import { t, Trans, site } from '@tencent/tea-app/lib/i18n'

export interface IPricePureProps {
  discountPrice: string | number
  originPrice?: string | number
  isDiscount?: boolean
  unit?: string
}
const IS_I18N = site === 2
export const PricePure = (props: IPricePureProps) => {
  const { originPrice, discountPrice, unit, isDiscount = false } = props
  const currency = IS_I18N ? t('美元') : t('元')
  const showDisCount = isDiscount || originPrice > discountPrice
  return (
    <>
      <span className="tea-text-cost">
        <span>{discountPrice !== undefined ? discountPrice : originPrice}</span>
        {currency}
        {unit}
      </span>
      {showDisCount ? (
        <span className="original-cost">
          {originPrice}
          {currency}
          {unit}
        </span>
      ) : null}
    </>
  )
}
