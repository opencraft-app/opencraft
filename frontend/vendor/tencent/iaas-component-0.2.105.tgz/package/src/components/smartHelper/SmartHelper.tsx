import React, { useState } from 'react'
import { Bubble } from '@tencent/tea-component'
import { t } from '@tencent/tea-app/lib/i18n'

/**
 * 腾讯云智能客服
 */
export function SmartHelper({ href }: { href: string }) {
  const [visible, setVisible] = useState(false)
  return (
    <div className="service-help dev-service-help">
      <Bubble visible={visible} placement="left" content={t('腾讯云智能客服')}>
        <a
          href={href || '/smarty?from=cvm-console'}
          target="__blank"
          onMouseOver={() => setVisible(true)}
          onMouseOut={() => setVisible(false)}
        >
          <i className="service-help-icon" />
        </a>
      </Bubble>
    </div>
  )
}
