import React, { Component, Fragment } from 'react'
import { t, Trans } from '@tencent/tea-app/lib/i18n'
import { Bubble, Button, List, Dropdown, DropdownProps, ButtonProps } from '@tencent/tea-component'
import { Placement } from "popper.js";

interface IOperation {
  action?: string
  desc?: string
  disabled?: string | React.ReactNode
  type?: string
  hidden?: boolean
}

export interface IButtonWithBubbleProps extends ButtonProps {
  bubblePlacement?: Placement
}

export interface IButtonOperation extends IOperation {
  buttonProps?: IButtonWithBubbleProps
}

export interface IDropdownOperation extends IOperation {
  label?: string
  subMenu?: IOperation[]
}

export interface IOperationProps {
  deniedActionMap: { [key: string]: string }
  /**
   * 铺开的操作列表
   */
  buttonOperationList?: IButtonOperation[]
  /**
   * 点击更多下拉操作列表
   */
  dropdownOperationList?: IDropdownOperation[]
  /**
   * 更多操作的下拉框属性，因为tea定义是需要children，所以这没有用tea的DropdownProps
   */
  dropdownProps?: DropdownProps
  onClick?: Function
}
/**
 * 关闭延时
 */
const CLOSE_DELAY = 500

/**
 * 操作
 */
export class OperationPure extends Component<IOperationProps> {
  render() {
    const { deniedActionMap = {}, dropdownProps, onClick } = this.props
    let { buttonOperationList = [], dropdownOperationList = [] } = this.props
    buttonOperationList = buttonOperationList.map((buttonOperationItem) => {
      return {
        ...buttonOperationItem,
        disabled: getOperationDisabled(buttonOperationItem, deniedActionMap),
      }
    })
    dropdownOperationList = dropdownOperationList.map((dropdownOperationItem) => {
      return {
        ...dropdownOperationItem,
        disabled: getOperationDisabled(dropdownOperationItem, deniedActionMap),
        subMenu:
          dropdownOperationItem.subMenu && dropdownOperationItem.subMenu.length
            ? dropdownOperationItem.subMenu.map((subMenuOperationItem) => ({
                ...subMenuOperationItem,
                disabled: getOperationDisabled(subMenuOperationItem, deniedActionMap),
              }))
            : null,
      }
    })
    return (
      <>
        {buttonOperationList.map((buttonOperationItem, index) =>
          !buttonOperationItem.hidden ? (
            <Bubble
              content={buttonOperationItem.disabled}
              key={buttonOperationItem.action}
              closeDelay={CLOSE_DELAY}
              placement={buttonOperationItem?.buttonProps?.bubblePlacement ?? 'top'}
            >
              <Button
                disabled={!!buttonOperationItem.disabled}
                type={buttonOperationItem.type || 'link'}
                onClick={(event) => {
                  event.stopPropagation()
                  onClick(buttonOperationItem.action)
                }}
                {...buttonOperationItem.buttonProps}
              >
                {buttonOperationItem.desc}
              </Button>
            </Bubble>
          ) : null
        )}
        {dropdownOperationList.length ? (
          <Bubble content={deniedActionMap.dropDownDisabled} closeDelay={CLOSE_DELAY}>
            <div style={{ display: 'inline-block' }}>
              <Dropdown
                clickClose={true}
                button={t('更多操作')}
                appearence="button"
                {...dropdownProps}
                disabled={!!deniedActionMap.dropDownDisabled}
              >
                <List type="option" style={{ maxHeight: '100%' }}>
                  {dropdownOperationList.map((dropdownOperationItem) =>
                    dropdownOperationItem.hidden ? null : dropdownOperationItem.subMenu &&
                      dropdownOperationItem.subMenu.length ? (
                      <List.SubMenu
                        key={dropdownOperationItem.label}
                        label={dropdownOperationItem.label}
                        placement="left"
                      >
                        <List type="option" style={{ maxHeight: '100%' }}>
                          {dropdownOperationItem.subMenu.map((subMenuOperationItem) => (
                            <OperationListItem
                              key={subMenuOperationItem.desc}
                              operationItem={subMenuOperationItem}
                              onClick={onClick}
                            />
                          ))}
                        </List>
                      </List.SubMenu>
                    ) : (
                      <OperationListItem
                        key={dropdownOperationItem.action}
                        operationItem={dropdownOperationItem}
                        onClick={onClick}
                      />
                    )
                  )}
                </List>
              </Dropdown>
            </div>
          </Bubble>
        ) : null}
      </>
    )
  }
}

function OperationListItem({ operationItem, onClick }) {
  return operationItem.hidden ? null : (
    <Bubble
      key={operationItem.action}
      content={operationItem.disabled}
      closeDelay={CLOSE_DELAY}
      placement="left"
    >
      <List.Item
        disabled={!!operationItem.disabled}
        onClick={(event) => {
          event.stopPropagation()
          onClick(operationItem.action)
        }}
      >
        {operationItem.desc}
      </List.Item>
    </Bubble>
  )
}

function getOperationDisabled(operation: IOperation, deniedActionMap: any): string {
  return operation.disabled
    ? operation.disabled
    : (deniedActionMap &&
        operation.action &&
        (deniedActionMap[operation.action] || deniedActionMap[operation.action.split('.')[0]])) ||
        null
}
