import * as React from 'react'
import { SearchTableDuck as Duck } from '../ducks/SearchTable'
import { DuckCmpProps, purify, memorize } from 'saga-duck'
import { t, Trans } from '@tencent/tea-app/lib/i18n'
import { Table, TableProps, SearchBox } from '@tencent/tea-component'
import CamTips, { isCamRefused } from '@tencent/iaas-common/components/Cam'
import { SelectableOptions } from '@tencent/tea-component/src/table/addons/selectable';
const { scrollable, radioable, autotip, selectable } = Table.addons

export interface ISearchTableProps extends DuckCmpProps<Duck>, Omit<TableProps, 'records'> {
  searchPlaceholder?: string
  needRadio?: boolean
  needCheckbox?: boolean
  checkboxProps?: Partial<SelectableOptions>
  needScrollable?: boolean
  needAutoTip?: boolean
  needSearch?: boolean
  emptyText?: React.ReactNode
  searchBox?: React.ReactNode
}

const getHandlers = memorize(({ creators }: Duck, dispatch) => ({
  inputKeyword: (keyword) => dispatch(creators.inputKeyword(keyword)),
  clearKeyword: () => dispatch(creators.search('')),
  select: (values) => dispatch(creators.select(values)),
  more: () => dispatch(creators.more()),
  search: (keyword) => dispatch(creators.search(keyword)),
}))

/**
 * 带搜索和分页功能的table
 */
export default purify(function (props: ISearchTableProps) {
  const handlers = getHandlers(props)
  const {
    duck,
    store,
    recordKey,
    columns,
    addons: parentAddons = [],
    searchPlaceholder = t('输入关键字搜索'),
    needRadio = false,
    needScrollable = true,
    needCheckbox = false,
    checkboxProps = {},
    needAutoTip = true,
    needSearch = true,
    emptyText,
    bordered = true,
    searchBox,
    ...rest
  } = props
  const { selector } = duck
  const {
    ids,
    pendingKeyword,
    keyword,
    list,
    nomore,
    fetcher: { loading, error },
  } = selector(store)
  const selectedKeys = ids
  const isCAMError = error && isCamRefused(error)
  const showError = !loading && error && !!error.message
  const addons = []

  // 单选框
  if (needRadio) {
    addons.push(
      radioable({
        value: selectedKeys[0],
        rowSelect: true,
        onChange: (key) => {
          handlers.select([key])
        },
      })
    )
  }
  if (needScrollable) {
    addons.push(
      scrollable({
        maxHeight: 200,
        onScrollBottom: nomore ? undefined : handlers.more,
      })
    )
  }
  if (needCheckbox) {
    addons.push(
      selectable({
        value: selectedKeys,
        rowSelect: true,
        onChange: handlers.select,
        ...checkboxProps
      })
    )
  }

  if (needAutoTip) {
    addons.push(
      autotip({
        isLoading: loading,
        isError: showError,
        isFound: !!keyword,
        onClear: handlers.clearKeyword,
        onRetry: handlers.more,
        foundKeyword: keyword,
        emptyText: emptyText,
        errorText: showError ? error.message || t('加载失败') : null,
      })
    )
  }

  return (
    <div>
      {needSearch && searchBox || (
        <SearchBox
          style={{ marginBottom: -1 }}
          value={pendingKeyword}
          onChange={handlers.inputKeyword}
          onClear={handlers.clearKeyword}
          placeholder={searchPlaceholder}
          onSearch={handlers.search}
        />
      )}
      <Table
        recordKey={recordKey}
        columns={columns}
        records={list || []}
        addons={[...addons, ...parentAddons]}
        bordered={bordered}
        topTip={isCAMError ? <CamTips error={error} message={error?.message} /> : null}
        {...rest}
      />
    </div>
  )
})
