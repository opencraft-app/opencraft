import React from 'react'
import { memorize, DuckCmpProps, purify } from 'saga-duck'
import KVTagSearchBox, {
  Props as IKVTagSearchBoxProps,
} from '@tencent/iaas-common/components/KVTagSearchBox'
import { SearchBoxDuck as Duck } from '../ducks/SearchBox'
import { SearchBox } from '@tencent/tea-component'
import { t, Trans } from '@tencent/tea-app/lib/i18n'


const getHandlers = memorize(({ creators }: Duck, dispatch) => ({
  search: (values) => dispatch(creators.onSearch(values)),
}))

export interface ISearchBoxProps extends Partial<IKVTagSearchBoxProps<any>>, DuckCmpProps<Duck> {
  minWidth?: string
  placeHolder?: string
  size?: string
  /**
   * 存储搜索结果的 sessionkey
   */
  sessionKey?: string
  /**
   * 是否标签选择模式，默认为true
   */
  tagMode?: boolean
}

export const DEFAULT_TAG_KEY = 'innerSearch'

export default (function (props: ISearchBoxProps) {
  const {
    duck: { selector },
    store,
    tagMode = true,
    placeHolder,
    sessionKey,
    size = 'm',
    ...rest
  } = props
  const { attributes, values } = selector(store)
  const handlers = getHandlers(props)
  const valueStr = SearchAdapter.encode(values)
  const [inputValue, setInputValue] = React.useState(valueStr)
  const [firstRender, setFirstRender] = React.useState(false)

  try {
    // 存在 sessionKey时，首次要更新值，
    if (!firstRender && sessionKey) {
      setFirstRender(true)
      const dataStr = sessionStorage.getItem(sessionKey)
      const data = JSON.parse(dataStr)
      const hasSearchValue = values && Object.values(values)?.length
      const hasSessionValue = dataStr && Object.values(data)?.length
      if (data && !hasSearchValue && hasSessionValue) {
        handlers.search(data)
      }
    } else if (sessionKey) {
      // 存在 sessionKey时， 同步sessionStorage
      syncSearchSessionStorage(sessionKey, values)
    }
  } catch (e) {}

  return tagMode ? (
    <KVTagSearchBox
      multipleText={true}
      attributes={attributes}
      value={values}
      defaultKey={DEFAULT_TAG_KEY}
      onChange={handlers.search}
      tips={placeHolder || t('多个关键字用竖线 “|” 分隔，多个过滤标签用回车键分隔')}
      {...rest}
    />
  ) : (
    <SearchBox
      size={size}
      value={inputValue}
      onChange={setInputValue}
      multiline={false}
      placeholder={placeHolder || ''}
      onSearch={(value) => handlers.search(SearchAdapter.decode(value))}
      onClear={() => handlers.search(SearchAdapter.decode(''))}
    />
  )
})

const SearchAdapter = {
  encode: (values): string => {
    return values?.[DEFAULT_TAG_KEY]?.[0] || ''
  },
  decode: (value: string) => {
    return {
      [DEFAULT_TAG_KEY]: [value],
    }
  },
}

function syncSearchSessionStorage(sessionKey, values) {
  if (sessionKey) {
    const valueStr = JSON.stringify(values)
    const searchStr = sessionStorage.getItem(sessionKey)
    if (searchStr !== valueStr) {
      sessionStorage.setItem(sessionKey, JSON.stringify(values))
    }
  }
}