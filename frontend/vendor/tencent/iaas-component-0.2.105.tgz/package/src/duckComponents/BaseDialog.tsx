import * as React from 'react'
import * as classnames from 'classnames'
import {
  Modal,
  ModalProps,
  Icon,
  PopConfirm,
  Button,
  ButtonProps as TeaButtonProps,
} from '@tencent/tea-component'
import { DuckCmpProps, memorize, purify } from 'saga-duck'
import Duck from '@tencent/iaas-common/ducks/DialogPure'
import { t, Trans } from '@tencent/tea-app/lib/i18n'

export interface IBaseDialogProps extends Omit<ModalProps, 'children' | 'onClose'> {
  /** 对话框标题 */
  title?: string | JSX.Element
  children?: React.ReactChild | React.ReactChild[]
  /** 自定义按钮 */
  buttons?: JSX.Element | JSX.Element[] | string | ButtonsCreator
  /** 是否显示默认提交按钮 */
  defaultSubmit?: boolean
  /** 默认提交按钮文案 */
  defaultSubmitText?: string
  /** 提交回调 */
  onSubmit?: (e?) => void
  /** 关闭回调 */
  onClose?: (e?) => void
  /** 是否显示默认取消按钮 */
  defaultCancel?: boolean
  /** 默认取消按钮文案 */
  defaultCancelText?: string
  /** 是否显示底部 */
  showFooter?: boolean
  /** 提交按钮禁用时的提示 */
  submitTooltip?: string | React.ReactNode
  /** 是否显示二次确认弹窗 */
  hasPopConfirm?: boolean
  /** 二次确认弹窗配置 */
  popConfirm?: {
    title: React.ReactNode
    message: React.ReactNode
  }
}
interface IButtonProps extends TeaButtonProps {
  key?: string
  className?: string
  text?: string
  tooltip?: string | React.ReactNode
}
type ButtonCreator = (props?: IButtonProps) => JSX.Element
type ButtonsCreator = (
  submitCreator?: ButtonCreator,
  cancelCreator?: ButtonCreator
) => JSX.Element[]
const getOptions = memorize(({ creators }, dispatch) => ({
  onClose: () => {
    dispatch(creators.hide())
  },
  onSubmit: () => {
    dispatch(creators.submit())
  },
}))

function noop() {}

export default purify(function DuckDialog({
  duck: { selectors },
  store,
  size,
  title,
  children,
  buttons,
  className,
  disableEscape = true,
  disableCloseIcon = false,
  defaultSubmit = true,
  defaultSubmitText = t('提交'),
  onSubmit,
  onClose,
  defaultCancel = true,
  defaultCancelText = t('关闭'),
  showFooter = true,
  submitTooltip,
  hasPopConfirm = false,
  popConfirm,
  scrollable = false,
  ...rest
}: DuckCmpProps<Duck> & IBaseDialogProps) {
  const loading = selectors.loading(store)
  const canSubmit = selectors.canSubmit(store)
  const visible = selectors.visible(store)
  const options = getOptions(arguments[0])
  const bodyStyle = showFooter ? {} : { margin: 0 }

  const submitCreator: ButtonCreator = (props = {}) => {
    const {
      text = defaultSubmitText,
      className = '',
      tooltip = !canSubmit && submitTooltip,
      onClick: myOnSubmit,
      loading: myLoading = loading,
      disabled = !canSubmit,
      ...rest
    } = props
    if (hasPopConfirm && canSubmit) {
      return (
        <PopConfirm
          title={popConfirm?.title}
          message={popConfirm?.message}
          footer={(close) => (
            <>
              <Button
                type="link"
                onClick={() => {
                  close()
                  const submitFun = myOnSubmit || onSubmit || options.onSubmit
                  submitFun()
                }}
              >
                {t('确定')}
              </Button>
              <Button
                type="text"
                onClick={() => {
                  close()
                }}
              >
                {t('取消')}
              </Button>
            </>
          )}
          placement="top-start"
        >
          <Button
            key="default-submit"
            type="primary"
            className={className}
            disabled={disabled}
            tooltip={tooltip}
          >
            {myLoading && <Icon type="loading" />}
            <span>{text}</span>
          </Button>
        </PopConfirm>
      )
    }
    return (
      <Button
        key="default-submit"
        type="primary"
        className={className}
        disabled={disabled}
        tooltip={tooltip}
        onClick={canSubmit ? myOnSubmit || onSubmit || options.onSubmit : noop}
        {...rest}
      >
        {myLoading && <Icon type="loading" />}
        <span>{text}</span>
      </Button>
    )
  }
  const cancelCreator: ButtonCreator = (props = {}) => {
    const { text = defaultCancelText, className, onClick: myOnClose, ...rest } = props
    return (
      <Button
        key="default-cancel"
        type="weak"
        disabled={loading}
        onClick={loading ? noop : myOnClose || onClose || options.onClose}
        {...rest}
      >
        <span>{text}</span>
      </Button>
    )
  }
  return (
    <Modal
      className={className}
      caption={title}
      size={size}
      disableEscape={disableEscape}
      visible={visible}
      onClose={loading ? noop : onClose || options.onClose}
      disableCloseIcon={disableCloseIcon}
      scrollable={scrollable}
      {...rest}
    >
      <Modal.Body style={bodyStyle} className="tea-pr-2n">
        {children}
      </Modal.Body>
      {showFooter && (
        <Modal.Footer>
          {typeof buttons === 'function' ? buttons(submitCreator, cancelCreator) : buttons}
          {defaultSubmit && submitCreator()}
          {defaultCancel && cancelCreator()}
        </Modal.Footer>
      )}
    </Modal>
  )
})
