import * as React from 'react'
import { DuckCmpProps, memorize, purify } from 'saga-duck'
import { Button, Form, Select, StatusTip, Table, Text, useClassNames } from '@tencent/tea-component'
import { scrollable } from '@tencent/tea-component/lib/table/addons/scrollable'
import { t, Trans } from '@tencent/tea-app/lib/i18n'
import { CamHelpTips, isCamRefused } from '@tencent/iaas-common/components/Cam'
import { EditTagDuck as Duck, IRow } from '../ducks'

const EMPTY = t('(空值)')
const getHandlers = memorize(({ creators }: Duck, dispatch) => ({
  updateTag: (value: IRow) => dispatch(creators.updateTag(value)),
  addRow: () => dispatch(creators.addRow()),
  deleteRow: (value: IRow) => dispatch(creators.deleteRow(value)),
  queryTagKey: (value: IRow) => dispatch(creators.queryTagKey(value)),
  queryTagValue: (value: IRow) => dispatch(creators.queryTagValue(value)),
  updateRow: (value: IRow) => dispatch(creators.updateRow(value)),
}))

export default purify(function (props: DuckCmpProps<Duck>) {
  const { duck, store } = props
  const { selector } = duck
  const {
    selectedTagList,
    selectedTagKeyMap,
    tagKeyFetcher: { loading: tagKeyLoading, error: tagKeyError },
    tagValueFetcher: { loading: tagValueLoading, error: tagValueError },
  } = selector(store)
  const handlers = getHandlers(props)
  const { Margin } = useClassNames()
  const columns = [
    {
      key: 'name',
      header: t('标签键'),
      render: (item) => (
        <Select
          searchable
          boxSizeSync
          size="full"
          type="simulate"
          appearance="button"
          onOpen={() => handlers.queryTagKey(item)}
          options={(item.keyList || []).map((tagKey) => {
            return {
              value: tagKey,
              text: tagKey,
              tooltip: tagKey,
              disabled: Boolean(selectedTagKeyMap[tagKey]) && tagKey !== item.tagKey,
            }
          })}
          value={item.tagKey}
          onChange={(value) => handlers.updateTag({ ...item, tagKey: value, tagValue: '' })}
          tips={
            tagKeyLoading ? (
              <StatusTip.LoadingTip />
            ) : tagKeyError ? (
              <StatusTip.ErrorTip
                errorText={
                  isCamRefused(tagKeyError) ? (
                    <CamHelpTips
                      error={tagKeyError}
                      content={t('您没有权限访问标签键')}
                      attachEl=".iaas_component_edit_tag_anchor"
                    />
                  ) : (
                    tagKeyError?.message
                  )
                }
                onRetry={() => handlers.queryTagKey(item)}
              />
            ) : !item.keyList || !item.keyList.length ? (
              <StatusTip.EmptyTip />
            ) : null
          }
        />
      ),
    },
    {
      key: 'value',
      header: t('标签值'),
      render: (item) => {
        return (
          <Select
            searchable
            boxSizeSync
            size="full"
            type="simulate"
            appearance="button"
            onOpen={() => handlers.queryTagValue(item)}
            options={(item.valueList || []).map((tagValue) => {
              let text = tagValue === '' ? <Text theme="weak">{EMPTY}</Text> : tagValue
              return {
                value: tagValue,
                text: text,
                tooltip: text,
              }
            })}
            value={item.tagValue}
            disabled={!item.tagKey}
            onChange={(value) => handlers.updateTag({ ...item, tagValue: value })}
            tips={
              tagValueLoading ? (
                <StatusTip.LoadingTip />
              ) : tagValueError ? (
                <StatusTip.ErrorTip
                  errorText={
                    isCamRefused(tagValueError) ? (
                      <CamHelpTips
                        error={tagValueError}
                        content={t('您没有权限访问标签值')}
                        attachEl=".iaas_component_edit_tag_anchor"
                      />
                    ) : (
                      tagValueError?.message
                    )
                  }
                  onRetry={() => handlers.queryTagValue(item)}
                />
              ) : !item.valueList || !item.valueList.length ? (
                <StatusTip.EmptyTip />
              ) : null
            }
          />
        )
      },
    },
    {
      key: 'action',
      header: t('操作'),
      width: 100,
      render: (item) => (
        <Button
          onClick={() => {
            handlers.deleteRow(item)
          }}
        >
          {t('删除')}
        </Button>
      ),
    },
  ]
  return (
    <div className="iaas_component_edit_tag_anchor">
      {!selectedTagList.length ? null : (
        <>
          <Form.Text className={Margin.Bottom['2n']}>
            <Text theme="label">
              <Trans>
                标签用于从不同维度对资源分类管理。如现有标签不符合您的要求，请前往{' '}
                <a href="https://console.cloud.tencent.com/tag/taglist" target="_blank">
                  标签管理
                </a>
              </Trans>
            </Text>
          </Form.Text>
          <Table
            bordered={Boolean(true)}
            records={selectedTagList}
            columns={columns}
            addons={[scrollable({ maxHeight: 200 })]}
          />
        </>
      )}
      <Button
        type="link"
        disabled={selectedTagList.length >= 50}
        tooltip={selectedTagList.length >= 50 ? t('标签数量已达上限') : ''}
        onClick={handlers.addRow}
      >
        {t('添加')}
      </Button>
    </div>
  )
})
