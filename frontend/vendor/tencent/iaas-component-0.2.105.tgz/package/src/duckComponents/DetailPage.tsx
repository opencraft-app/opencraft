import * as React from 'react'
import CamTips, { isCamRefused } from '@tencent/iaas-common/components/Cam'
import { purify, DuckCmpProps } from 'saga-duck'
import Duck from '@tencent/iaas-common/ducks/DetailPage'
import { t, Trans } from '@tencent/tea-app/lib/i18n'
import { Layout } from '@tencent/tea-component'
import { router } from '../utils'

const TextTip = purify(function TextTip({ children }) {
  return <div style={{ textAlign: 'center', padding: '100px' }}>{children}</div>
})

interface CountdownRedirectProps {
  backRoute: string
  onBack?: () => any
  /** 倒计时秒数，默认5秒 */
  countdown?: number
  /** 跳转目标文案，默认"列表页" */
  redirectText?: string
}

function CountdownRedirect({
  backRoute,
  onBack,
  countdown: initialCountdown = 5,
  redirectText = t('列表页'),
}: CountdownRedirectProps) {
  const [countdown, setCountdown] = React.useState(initialCountdown)

  React.useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        const next = prev - 1
        if (next <= 0) {
          clearInterval(timer)
          if (onBack) {
            onBack()
          } else if (backRoute) {
            router.navigate(backRoute)
          }
        }
        return next
      })
    }, 1000)

    return () => {
      clearInterval(timer)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <TextTip>
      {t('未找到指定资源，{{countdown}}s后返回{{redirectText}}', { countdown, redirectText })}
    </TextTip>
  )
}

function historyBack() {
  history.go(-1)
}

interface IDetailPageProps {
  className?: string
  /** 点击返回时的回调 */
  onBack?: () => any
  /** 是否优先尝试返回历史记录（如果有的话），仅当onBack未设置时才有效 */
  backHistory?: boolean
  /** 返回路由，仅当onBack未设置时才有效 */
  backRoute: string
  /** 返回文案，现有样式实际上并不会展示 @deprecated */
  backTitle?: string
  /** 标题 */
  title?: string | JSX.Element | JSX.Element[]
  /** 子标题 */
  subTitle?: string | JSX.Element | JSX.Element[]
  /** 额外标题 */
  titleRight?: string | JSX.Element | JSX.Element[]
  children?: string | JSX.Element | JSX.Element[]
  popComponent?: string | JSX.Element | JSX.Element[]
  full?: boolean
  showBackButton?: boolean
  /** 未找到资源时是否自动跳转，默认false */
  notFoundAutoRedirect?: boolean
  /** 自动跳转倒计时秒数，默认5秒 */
  notFoundRedirectCountdown?: number
  /** 自动跳转目标文案，默认"列表页" */
  notFoundRedirectText?: string
}
/**
 * Layout布局组件重写的DetailPage
 */
export default purify(function DetailPage({
  duck: { selectors, selector },
  store,
  dispatch,
  className,
  /** 是否优先尝试返回历史记录（如果有的话） */
  backHistory,
  backRoute,
  backTitle,
  title,
  subTitle,
  onBack,
  titleRight,
  children,
  full = true,
  popComponent = <noscript />,
  showBackButton = true,
  notFoundAutoRedirect = false,
  notFoundRedirectCountdown,
  notFoundRedirectText,
}: DuckCmpProps<Duck> & IDetailPageProps) {
  const { ready } = selector(store)
  const id = selectors.id(store)
  const data = selectors.data(store)
  const loading = selectors.loading(store)
  const error = selectors.error(store) as any
  let backRouteHref = backRoute
  let onClickBack = onBack
  // 如果历史记录大于2（chrome打开时，新标签页也是1次，当前是第2次）
  if (!onClickBack && backHistory && history.length > 2) {
    backRouteHref = ''
    onClickBack = historyBack
  }
  let overrideChildren
  if (!ready || (loading && !data)) {
    // loading最优先
    // 优化体验，改为仅首屏加载出现  enofan 2019年10月7日17:45:30
    overrideChildren = <TextTip>{t('加载中...')}</TextTip>
  } else if (error) {
    // 其次错误
    overrideChildren = isCamRefused(error) ? (
      <CamTips message={error.message} />
    ) : (
      <TextTip>{error.message}</TextTip>
    )
  } else if (!data) {
    // 其次没有找到
    overrideChildren = notFoundAutoRedirect ? (
      <CountdownRedirect
        backRoute={backRoute}
        onBack={onBack}
        countdown={notFoundRedirectCountdown}
        redirectText={notFoundRedirectText}
      />
    ) : (
      <TextTip>{t('未找到指定资源')}</TextTip>
    )
  }
  return (
    <Layout>
      <Layout.Body>
        <Layout.Content>
          <Layout.Content.Header
            showBackButton={showBackButton}
            onBackButtonClick={() => {
              if (onClickBack) {
                onClickBack()
              } else if (backRouteHref) {
                router.navigate(backRouteHref)
              }
            }}
            title={title || id}
            subtitle={
              subTitle ? (typeof subTitle === 'string' ? ` (${subTitle}) ` : subTitle) : null
            }
            operation={titleRight}
          />
          <Layout.Content.Body full={full}>{overrideChildren || children}</Layout.Content.Body>
        </Layout.Content>
      </Layout.Body>
    </Layout>
  )
})
