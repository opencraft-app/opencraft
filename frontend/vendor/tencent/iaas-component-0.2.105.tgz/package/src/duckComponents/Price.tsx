import React, { Component, Fragment } from 'react'
import { memorize, DuckCmpProps, purify } from 'saga-duck'
import { Icon } from '@tencent/tea-component'
import { t, Trans } from '@tencent/tea-app/lib/i18n'
import { PriceDuck as Duck } from '../ducks/Price'
import { PricePure } from '../components/PricePure'

const getHandlers = memorize(({ creators }: Duck, dispatch) => ({
  reload: () => dispatch(creators.reload()),
}))

export default purify(function Price(props: DuckCmpProps<Duck>) {
  const {
    duck: { selector },
    store,
  } = props
  const { data, error, loading } = selector(store)
  const handler = getHandlers(props)
  return (
    <div className="tea-action-state tea-action-state--form-align">
      {loading ? (
        <span className="tea-action-state__text">
          <Icon type="loading" className="mr-5" />
          {t('费用查询中...')}
        </span>
      ) : error ? (
        <Trans>
          <span className="tea-action-state__text tea-text-danger">
            <Icon type="error" className="mr-5" />
            查询失败，请
          </span>
          <a href="javascript:;" className="tea-action-state__text" onClick={handler.reload}>
            重试
          </a>
        </Trans>
      ) : (
        <PricePure
          originPrice={data?.originPrice}
          discountPrice={
            data && (data.discountPrice || data.discountPrice === 0) ? data.discountPrice : '-'
          }
          isDiscount={data?.isDiscount}
          unit={data?.unit}
        />
      )}
    </div>
  )
})
