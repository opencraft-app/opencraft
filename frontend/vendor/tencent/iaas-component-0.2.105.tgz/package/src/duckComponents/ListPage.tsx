// 核心依赖
import React, { Fragment } from 'react'
import { memorize, DuckCmpProps, purify } from 'saga-duck'
// tea 框架 组件
import { t, Trans } from '@tencent/tea-app/lib/i18n'
import { Layout, Button, Bubble, Card, Justify, Table, Tooltip } from '@tencent/tea-component'
import {
  rowtooltip,
  selectable,
  autotip,
  injectable,
} from '@tencent/tea-component/lib/table/addons'

// iaas 公共组件
import { Region, GridPageGrid, GridPagePagination } from '@tencent/iaas-common/duckComponents'
import { Props as GridPageGridProps } from '@tencent/iaas-common/duckComponents/Grid'
import FieldManager from '@tencent/iaas-common/duckComponents/FieldManager'
import CamTips, { isCamRefused } from '@tencent/iaas-common/components/Cam'
import { app, i18n } from '@tencent/tea-app'

import {
  RegionSelect,
  getMaxCols,
  SearchBox,
  formatColumns,
  IColumn,
  ListPageDuck,
  BatchOperation,
} from '../index'

// 业务依赖
let clientWidth = 0

const getHandlers = memorize(({ creators, ducks, hotTagPrefix }: ListPageDuck, dispatch) => ({
  setCustomFields: (customFields) => {
    dispatch(creators.setCustomFields(customFields))
  },
  reload: () => {
    app.insight.reportHotTag(hotTagPrefix + 'button.refresh')
    // 用户主动刷新，应该展示loading
    dispatch(creators.setEnableShowLoading(true))
    dispatch(creators.reload())
  },
}))

export interface IListPageProps<T = ListPageDuck>
  extends DuckCmpProps<T>,
    Omit<GridPageGridProps, 'columns'> {
  /**
   * 标题
   */
  title: React.ReactNode
  /**
   * 操作区内容
   */
  pageOperation?: React.ReactNode
  /**
   * 是否为全屏
   *
   * @default false
   */
  full?: boolean
  /**
   * 公告内容
   */
  children?: React.ReactNode
  /**
   * 下载组件
   */
  downloadNode?: React.ReactNode
  /**
   * 是否使用默认操作panel
   */
  needDefaultOperationPanel?: boolean

  /**
   * 字段选择key
   */
  cacheKey?: string
  /**
   * 地域组件
   */
  regionSelectNode?: React.ReactNode
  /**
   *
   */
  paginationNode?: React.ReactNode
  /**
   * 找到结果时的文案
   */
  foundText?: React.ReactNode
  /**
   * 搜索结果为空显示组件
   */
  emptyText?: React.ReactNode
  /**
   * 搜索
   */
  searchBoxProps?: {
    size?: string
    tagMode?: boolean
    placeHolder?: string
    minWidth?: string
  }
  searchBox?: React.ReactNode
  /**
   * 位于table上部的组件
   */
  uponTableNode?: React.ReactNode
  /**
   * 是否展示列表卡片模块
   *
   * @default true
   */
  showTableCard?: boolean
  fieldManagerProps?: Partial<React.ComponentProps<typeof FieldManager>>
}

export default purify(function ListPage(props: IListPageProps) {
  const {
    duck,
    dispatch,
    store,
    title,
    pageOperation = null,
    full,
    children,
    cacheKey,
    needDefaultOperationPanel = true,
    paginationNode = (
      <GridPagePagination
        duck={duck}
        store={store}
        dispatch={dispatch}
        minPageSize={10}
        pageSizeInterval={10}
      />
    ),
    foundText = null,
    emptyText = <span>{t('暂无数据')}</span>,
    regionSelectNode = <RegionSelect duck={duck.ducks.region} store={store} dispatch={dispatch} />,
    downloadNode = (
      <Bubble content={t('导出')}>
        <Button icon="download" onClick={() => {}} />
      </Bubble>
    ),
    needAutoTip = true,
    needChecker = true,
    addons = [],
    searchBoxProps = {
      size: 'm',
      tagMode: true,
      placeHolder: '',
      minWidth: '100%',
    },
    searchBox = (
      <div style={{ width: 500, display: 'inline-block' }}>
        <SearchBox
          duck={duck.ducks.searchBox}
          store={store}
          dispatch={dispatch}
          {...searchBoxProps}
        />
      </div>
    ),
    fieldManagerProps = {},
    uponTableNode = null,
    showTableCard = true,
    ...rest
  } = props
  
  const { selectors, ducks, creators, selector, hotTagPrefix, recordKey } = duck
  const { grid: gridDuck, region: regionDuck, operation: operationDuck } = ducks
  const ready = selectors.ready(store)
  if (ready === null) {
    return <noscript />
  }
  const {
    grid: { error, list, loading, totalCount },
    operation: { selectedItems, deniedBatchActionMap },
    enableShowLoading,
    keyword,
  } = selector(store)
  const handlers = getHandlers(props)
  const isCAMError = error && isCamRefused(error)
  const showError = !loading && error && !!error.message
  const showLoading = Boolean(loading && enableShowLoading)
  const maxColumnLimit = getMaxCols()
  const fields = selectors.fields(store)
  /** 列宽计算 : 目前是刷新即重新计算，需要优化性能？ */
  const originColumns = selectors.columns(store)
  let columns = formatColumns({
    isPriority: true,
    originColumns: originColumns as IColumn[],
    gridWidth: clientWidth - 30,
    maxLimit: maxColumnLimit,
  })
  const selectedRegion = regionDuck.selectors.selected(store)
  const isCamRefusedError = !loading && error && isCamRefused(error)
  const regionResource = regionDuck.selectors.selectedRegionResource(store)
  if (needAutoTip && !isCamRefusedError) {
    let message = showError ? error?.message || error : ''
    if (typeof message !== 'string') {
      message = JSON.stringify(message)
    }
    addons.push(
      autotip({
        isLoading: showLoading,
        isError: showError,
        isFound: !!keyword,
        foundCount: totalCount,
        foundKeyword: keyword,
        foundText: foundText,
        errorText: showError ? error.message || t('加载失败') : null,
        foundKeywordMaxLength: 300,
        onClear: () => {
          dispatch(creators.clearSearchCondition())
        },
        onRetry: () => {
          dispatch(creators.reload())
        },
        emptyText: emptyText,
      })
    )
  }
  if (needChecker) {
    addons.push(
      selectable({
        // 不使用gridPageGrid是因为要更新选中实例到 operationDuck， 反之从grid中取selection 在operation中处理太麻烦
        value: selectedItems.map((item) => item[recordKey]),
        onChange: (ids) => {
          dispatch(
            ducks.operation.creators.setSelectedItems(
              list.filter((item) => ids.includes(item[recordKey]))
            )
          )
        },
      }),
      rowtooltip({
        tooltip: (item) => (item.IsLoadingStatus ? t('正在执行操作') : null),
      })
    )
  }
  return (
    <Layout>
      <Layout.Body>
        <Layout.Content>
          <Layout.Content.Header title={title} operation={pageOperation}>
            {regionSelectNode}
          </Layout.Content.Header>
          <Layout.Content.Body full={full}>
            {children}
            {!needDefaultOperationPanel ? null : (
              <Table.ActionPanel>
                <Justify
                  left={<BatchOperation duck={operationDuck} store={store} dispatch={dispatch} />}
                  right={
                    <>
                      {searchBox}
                      <Bubble content={t('刷新')}>
                        <Button icon="refresh" onClick={handlers.reload} />
                      </Bubble>
                      {!cacheKey ? null : (
                        <Bubble content={t('设置列表字段')}>
                          <div
                            style={{ display: 'inline-block' }}
                            onClick={() => {
                              app.insight.reportHotTag(hotTagPrefix + 'button.setGridFields')
                            }}
                          >
                            <FieldManager
                              fields={fields}
                              maxLimit={maxColumnLimit}
                              cacheKey={cacheKey}
                              onChange={handlers.setCustomFields}
                              {...fieldManagerProps}
                            />
                          </div>
                        </Bubble>
                      )}
                      {downloadNode}
                    </>
                  }
                />
              </Table.ActionPanel>
            )}
            {showTableCard && <Card className="tea-mt-2n">
              <div
                ref={(ref) => {
                  clientWidth = ref?.clientWidth || 0
                }}
              >
                {uponTableNode}
                <GridPageGrid
                  duck={duck}
                  store={store}
                  dispatch={dispatch}
                  columns={columns}
                  verticalTop={true}
                  needAutoTip={false}
                  needChecker={false}
                  addons={addons}
                  {...rest}
                />
                {paginationNode}
              </div>
            </Card>}
          </Layout.Content.Body>
        </Layout.Content>
      </Layout.Body>
    </Layout>
  )
})
