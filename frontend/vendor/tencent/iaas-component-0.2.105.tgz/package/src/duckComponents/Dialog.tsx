import React, { Fragment } from 'react'
import { purify, DuckCmpProps, memorize, Duck, BaseDuck, DuckMap } from 'saga-duck'
import Dialog, { IBaseDialogProps } from './BaseDialog'
import { Button, Stepper, Checkbox } from '@tencent/tea-component'
import { t } from '@tencent/tea-app/lib/i18n'
import { OperateBase as OperateBaseDuck } from '../ducks'

const getHanders = memorize(({ creators }, dispatch) => ({
  setStep: (step) => dispatch(creators.setStep(step)),
  confirm: (value) => dispatch(creators.confirm(value)),
}))

export interface IDialogProps extends IBaseDialogProps, DuckCmpProps<OperateBaseDuck> {
  /**
   * 弹框中用户点击确认的文案
   */
  confirmCheckBoxInnerDom?: React.ReactNode
  defaultPrevButtonText?: React.ReactNode
  defaultNextButtonText?: React.ReactNode
  // 自定义上一步下一步操作，如果传入该creators，则执行,callback参数为切换到’下一步‘操作
  nextButtonHandler?: Function
  prevButtonHandler?: Function
  /**
   * 在步骤条下面，步骤切换后依然还展示的组件
   */
  mainComponent?: React.ReactNode 
}

export default purify(function StepperDialog(props: IDialogProps) {
  const {
    duck,
    store,
    dispatch,
    buttons,
    children,
    confirmCheckBoxInnerDom = null,
    defaultSubmit = true,
    defaultCancel = true,
    defaultSubmitText = t('确定'),
    defaultPrevButtonText = t('上一步'),
    defaultNextButtonText = t('下一步'),
    nextButtonHandler,
    prevButtonHandler,
    mainComponent,
    ...reset
  } = props
  const { selector, selectors } = duck
  const handlers = getHanders(props)
  const { step: currentStep, confirmed } = selector(store)
  const steppers = selectors.steppers(store) || []
  const disabledNext = selectors.disabledNext(store)
  const disabledPrev = selectors.disabledPrev(store)

  const {
    id: currentStepId,
    component: CurrentStepComponent,
    duck: CurrentStepDuck,
    props: CurrentStepProps,
  } = steppers[currentStep] || {
    id: null,
    component: null,
    duck: null,
    props: null,
  }
  const isFirstStep = currentStep === 0
  const isLastStep = currentStep === steppers.length - 1
  return (
    <Dialog
      duck={duck}
      store={store}
      dispatch={dispatch}
      defaultSubmit={steppers.length ? isLastStep : defaultSubmit}
      defaultCancel={steppers.length > 1 ? !isLastStep : defaultCancel}
      defaultSubmitText={defaultSubmitText}
      buttons={
        steppers.length
          ? [
              !isFirstStep ? (
                <Button
                  type="weak"
                  key="prev"
                  disabled={disabledPrev}
                  className="tea-ml-3n"
                  onClick={() => {
                    if (prevButtonHandler) {
                      dispatch(
                        prevButtonHandler({
                          state: store,
                          callback: () => handlers.setStep(currentStep - 1),
                        })
                      )

                      return
                    }

                    handlers.setStep(currentStep - 1)
                  }}
                >
                  {defaultPrevButtonText}
                </Button>
              ) : null,
              !isLastStep ? (
                <Button
                  type="primary"
                  key="next"
                  disabled={disabledNext}
                  className="tea-ml-2n"
                  onClick={() => {
                    if (nextButtonHandler) {
                      dispatch(
                        nextButtonHandler({
                          state: store,
                          callback: () => handlers.setStep(currentStep + 1),
                        })
                      )
                      return
                    }

                    handlers.setStep(currentStep + 1)
                  }}
                >
                  {defaultNextButtonText}
                </Button>
              ) : null,
            ]
          : buttons
      }
      {...reset}
    >
      {steppers.length ? (
        <>
          {steppers.length > 1 && <Stepper steps={steppers} current={currentStepId} className="tea-mb-5n" />}
          {mainComponent}
          <CurrentStepComponent
            duck={CurrentStepDuck}
            store={store}
            dispatch={dispatch}
            {...CurrentStepProps}
          />
          {children}
          {confirmCheckBoxInnerDom && isLastStep ? (
            <p>
              <Checkbox name="confirmCheckbox" value={confirmed} onChange={handlers.confirm}>
                {confirmCheckBoxInnerDom}
              </Checkbox>
            </p>
          ) : null}
        </>
      ) : (
        children
      )}
    </Dialog>
  )
})
