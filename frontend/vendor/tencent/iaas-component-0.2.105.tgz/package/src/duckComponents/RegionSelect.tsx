// 同Region.tsx，但展示为tea2新样式
import * as React from 'react'
import { DuckCmpProps } from 'saga-duck'
import Duck, { Region } from '@tencent/iaas-common/ducks/Region'
import { RegionSelect, RegionPanel, RegionOption } from '@tencent/tea-component/lib/regionselect'
import { purify } from 'saga-duck/purify'
import { t } from '@tencent/tea-app/lib/i18n'
import { getAreaByRegionId, router } from '../utils'
import { RegionSupport } from '@tencent/tea-app';
interface IProps extends DuckCmpProps<Duck> {
  /**
   * 当需要处理地域展示、分组等信息时，可在此处理
   *
   * 例如添加地域实例数量：
   *
   * javascript```
   *  <RegionSelect injectRegionSetting={s => { s.content += `(${count})`; return s }} />
   * ```
   */
  injectRegionSetting?: (defaultSetting: IRegionSetting) => IRegionSetting
  boxStyle?: React.CSSProperties
  /**
   * 是否展示最近访问地域，默认不展示
   */
  showRecentVisitedRegions?: boolean
}

export default purify(function DuckRegionBar(props: IProps) {
  const { dispatch, duck, store, injectRegionSetting = defaultGetSetting, showRecentVisitedRegions = false, ...rest } = props
  const { creators, selectors } = duck
  const list = selectors.list(store)

  if (!list.length) return <noscript />
  const selected = selectors.selected(store)
  const areaArrayList = getAreaArrayList(list)
  const maxRowNum = getMaxRows()
  const regionSettings: IRegionSetting[] = list.map((region) =>
    injectRegionSetting(getRegionDefaultSetting(region, maxRowNum, areaArrayList))
  )

  // 先计算分组
  let groups = new Map<string, Map<string, IRegionSetting[]>>()
  regionSettings.forEach((r) => {
    const largeGroupName = r.largeGroup || r.group
    let largeGroup = groups.get(largeGroupName)
    if (!largeGroup) {
      largeGroup = new Map<string, IRegionSetting[]>()
      groups.set(largeGroupName, largeGroup)
    }
    let group = largeGroup.get(r.group)
    if (!group) {
      group = []
      largeGroup.set(r.group, group)
    }
    group.push(r)
  })

  // 如果一个业务只有国内地域，或考虑将group进行一次提升，避免只显示在一列内，不太好看
  if (groups.size === 1) {
    for (const [lname, lg] of groups) {
      for (const [name, regions] of lg) {
        const riseGroup = new Map<string, IRegionSetting[]>()
        riseGroup.set(name, regions)
        groups.set(name, riseGroup)
      }
      groups.delete(lname)
      break
    }
  }
  const regionSelect = (RegionSelect, RegionPanel, RegionOption) => (<RegionSelect
    value={selected ? String(selected.value) : null}
    onChange={(val) => {
      const regionItem = regionSettings.find((r) => String(r.value) === val)
      if (regionItem?.isOvmRegion) {
        // 选中ovm区域 则页面渲染为ovm控制台(ovm?region=Tokyo)
        router.navigate(`/ovm?region=${regionItem.extraInfo.routeValue}`)
      } else {
        dispatch(creators.select(parseInt(val, 10)))
      }
    }}
    {...rest}
  >
    <RegionPanel>
      {Array.from(groups.entries()).map(([largeGroupName, largeGroup]) => (
        <RegionPanel.Column key={largeGroupName}>
          {Array.from(largeGroup.entries()).map(([groupName, regions]) => (
            <RegionPanel.Group name={groupName} key={groupName}>
              {regions.map((region) => (
                <RegionOption key={region.value} value={region.value} dot={region.dot}>
                  {region.content}
                </RegionOption>
              ))}
            </RegionPanel.Group>
          ))}
        </RegionPanel.Column>
      ))}
    </RegionPanel>
  </RegionSelect>)

  return showRecentVisitedRegions ? (
    <RegionSupport>
      {({ RegionSelect, RegionPanel, RegionOption }) => (
        regionSelect(RegionSelect, RegionPanel, RegionOption)
      )}
    </RegionSupport>
  ) : regionSelect(RegionSelect, RegionPanel, RegionOption)
})

function getRegionDefaultSetting(
  r: IRegion,
  maxRowNum: number,
  areaArrayList: number[][]
): IRegionSetting {
  const area = r.isOvmRegion ? OVM_REGION_TO_AREA[r.value] : getAreaByRegionId(r.value)
  const colIndex = getRegionColIndex(r.value, maxRowNum, areaArrayList)
  return {
    value: String(r.value),
    content: r.name,
    largeGroup: colIndex ? colIndex : '',
    group: area ? area : '',
    dot: r.newFlag,
    isOvmRegion: r.isOvmRegion,
    extraInfo: r.extraInfo,
  }
}

/**
 * 获取按area分组的二维regionId数组 形如：[[1, 11, 12], [4, 7], ...]
 * 这里未考虑area的排序，因为没有排序数据来源，暂时先默认按 region list 的顺序
 * @param regionList region列表
 */
function getAreaArrayList(regionList: Region[]): number[][] {
  let areaArrayList: number[][] = []
  // 已经存在的area
  let curExistAreas = []
  regionList.forEach((region) => {
    const regionId = region.value
    const area = getAreaByRegionId(regionId)
      ? getAreaByRegionId(regionId)
      : OVM_REGION_TO_AREA[regionId]
    // 当前region所在area是否存在
    if (!curExistAreas.includes(area)) {
      curExistAreas.push(area)
      areaArrayList.push([])
    }
    areaArrayList[curExistAreas.indexOf(area)].push(regionId)
  })
  return areaArrayList
}

/**
 * 获取region所在的列序号 计算方法：region实际的index除以每列允许排的最大个数，然后取整
 * @param regionId
 * @param maxRowNum 每列最大行数
 * @param areaArrayList 按area分组的二维regionId数组
 */
function getRegionColIndex(regionId: number, maxRowNum: number, areaArrayList: number[][]): string {
  let regionRealIndex = 0
  let accumulateIndex = 0
  areaArrayList.some((regionList) => {
    regionList.some((regionListItem, regionListItemIndex) => {
      // 每一个largeRegion的标题占一位 `华南地区`
      if (regionListItemIndex === 0) {
        accumulateIndex++
      }
      // 处理一个largeRegion被分到两个column
      if (regionListItemIndex !== 0 && accumulateIndex % maxRowNum === 0) {
        accumulateIndex++
      }
      // 每一个region占一位
      accumulateIndex++
      // 处理一个column满了
      if (accumulateIndex > (regionRealIndex + 1) * maxRowNum) {
        regionRealIndex++
      }
      if (regionListItemIndex === regionList.length - 1) {
        // 处理一个column的最后一个largeRegion恰好只能放一个间隔和标题
        if ((accumulateIndex + 2) % maxRowNum === 0) {
          accumulateIndex += 2
        }
        // 处理每个largeRegion的间隔
        else if (accumulateIndex % maxRowNum !== 0) {
          accumulateIndex++
        }
      }
      return regionListItem === regionId
    })
    return regionList.includes(regionId)
  })
  return String(regionRealIndex)
}

function defaultGetSetting(defaultSetting?: IRegionSetting): IRegionSetting {
  return defaultSetting
}

/** 地域展示属性 */
interface IRegionSetting {
  /** 地域ID，默认为数字ID，也可自行订制为gz、ap-guangzhou等格式 */
  value: string
  /** 内容自定义，如没有则直接显示地域名 */
  content?: React.ReactChild
  /** 所属地区 */
  group?: string
  /** 所属大类，它不会展示，但同largeGroup的不同group会展示在同一列内 */
  largeGroup?: string
  /** 是否展示小红点 */
  dot?: boolean
  /** 是否为Ovm地域 */
  isOvmRegion?: boolean
  /** 额外扩展信息 */
  extraInfo?: any
}

interface IRegion extends Region {
  newFlag?: boolean
  isOvmRegion?: boolean
  extraInfo?: any
}

// OVM地域接口的area信息 国际站与中文站返回的皆是中文...
// 为了国际化的词条能翻译到目前只能这样映射
/** OVM地域对应的Area映射 */
export const OVM_REGION_TO_AREA: { [regionId: number]: string } = {
  50010: t('北美地区'),
  50020: t('北美地区'),
  50030: t('北美地区'),
  30020: t('欧洲地区'),
  30030: t('欧洲地区'),
  40010: t('南美地区'),
  10030: t('亚太地区'),
  20010: t('亚太地区'),
}

// 偏移值的来源：每个地区显示的块，地区title会占一行，块后会空一行，因此每个地区块除了所显示的region行数外还占用前述的额外两行
// 所以某region的总偏移值 = 2（每个地区的额外行数） * n（在这个region之前的地区个数） + 1（它所在地区的title占一行）
/** 一个地区的偏移值 */
const AREA_OFFSET = 2

/** 获取每列最大行数 */
function getMaxRows() {
  let windowHeight = window.innerHeight
  let maxRowNum
  switch (true) {
    case windowHeight <= 400:
      maxRowNum = 5
      break
    case windowHeight <= 500:
      maxRowNum = 7
      break
    case windowHeight <= 600:
      maxRowNum = 9
      break
    case windowHeight <= 700:
      maxRowNum = 11
      break
    case windowHeight <= 800:
      maxRowNum = 13
      break
    default:
      maxRowNum = 13
      break
  }
  return maxRowNum
}
