import React, { Component, Fragment } from 'react'
import { DuckMap, DuckCmpProps, memorize } from 'saga-duck'
import { OperationDuck, IOperationProps, OperationPure, IButtonWithBubbleProps } from '../index'

const getHandlers = memorize(({ creators }: OperationDuck, dispatch) => ({
  select: (value) => dispatch(creators.select(value)),
}))

export interface IBatchOperationProps
  extends DuckCmpProps<OperationDuck>,
    Omit<IOperationProps, 'deniedActionMap', 'buttonOperationList', 'dropdownOperationList'> {
  params?: any
}

/**
 * 列表表格顶部批量操作
 */
export function BatchOperation(props: IBatchOperationProps) {
  const { duck, store, params } = props
  const { selector, selectors } = duck
  const { deniedBatchActionMap } = selector(store)
  const buttonOperationList = selectors.batchOperationButtonList(store)
  const dropdownOperationList = selectors.batchOperationDropDownList(store)
  const handlers = getHandlers(props)
  return (
    <OperationPure
      deniedActionMap={deniedBatchActionMap || {}}
      buttonOperationList={buttonOperationList}
      dropdownOperationList={dropdownOperationList}
      onClick={(action) => {
        handlers.select({
          operationAction: action,
          selectedItems: null,
          params: params,
        })
      }}
    />
  )
}

export interface IItemOperationProps<T> extends IOperationProps {
  item: T
  duck: OperationDuck
  dispatch: any
  buttonProps?: IButtonWithBubbleProps
  dropdownProps?: any
  params?: any
}

/**
 * 单个item的操作列
 * @param props
 */
export function SingleItemOperation<T>(props: IItemOperationProps<T>) {
  const {
    item,
    dropdownProps,
    deniedActionMap,
    buttonOperationList = [],
    dropdownOperationList = [],
    buttonProps,
    params = null,
  } = props
  const handlers = getHandlers(props)
  return (
    <OperationPure
      deniedActionMap={deniedActionMap}
      buttonOperationList={buttonOperationList.map((o) => ({ buttonProps, ...o }))}
      dropdownOperationList={dropdownOperationList}
      dropdownProps={dropdownProps}
      onClick={(action) => {
        handlers.select({
          operationAction: action,
          selectedItems: [item],
          params: params,
        })
      }}
    />
  )
}
