import React, { Fragment } from 'react'
import { purify, DuckCmpProps, memorize } from 'saga-duck'
import { DownloadDuck as Duck } from '../ducks'
import { t, Trans } from '@tencent/tea-app/lib/i18n'
import { Form, Radio } from '@tencent/tea-component'
import { Dialog } from '../duckComponents'

const getHandlers = memorize(({ creators, ducks }: Duck, dispatch) => ({
  setExportOption: (value) => dispatch(creators.setExportOption(value)),
}))

export interface IExportBaseProps extends DuckCmpProps<Duck> {
  projectName: string
  title: string
  before?: React.ReactNode
  after?: React.ReactNode
}

export default purify(function(props: IExportBaseProps) {
  const { duck, store, dispatch, projectName, title, before = null, after = null } = props
  const { selector } = duck
  const handlers = getHandlers(props)
  const { list, exportOption } = selector(store)
  return (
    <Dialog duck={duck} store={store} dispatch={dispatch} size="m" title={title}>
      <>
        {before}
        <Form>
          <Form.Item label={t('导出范围')}>
            <Radio.Group value={exportOption} onChange={handlers.setExportOption} layout="column">
              <Radio name="all">{t('导出全部{{projectName}}', { projectName })}</Radio>
              <Radio name="filter">{t('仅导出搜索结果')}</Radio>
              <Radio
                name="selected"
                disabled={list.length === 0}
                tooltip={list.length === 0 ? t('未选中{{projectName}}', { projectName }) : ''}
              >
                {t('仅导出选中{{projectName}}', { projectName })}
              </Radio>
            </Radio.Group>
          </Form.Item>
        </Form>
        {after}
      </>
    </Dialog>
  )
})
