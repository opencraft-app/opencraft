import { DuckMap, reduceFromPayload, createToPayload, asResult } from 'saga-duck'
import Base, { Region } from '@tencent/iaas-common/ducks/Region'
import { put, select, call, fork, apply } from 'redux-saga/effects'
import { runAndTakeLatest, takeLatest } from 'redux-saga-catch'
import { delay } from 'redux-saga'
import { site } from '@tencent/tea-app/lib/i18n'
import { app } from '@tencent/tea-app'
import { cgiRequest } from '../utils'

/**
 * 团体云地域
 */
export const FT_CLOUD_REGIONS = window.ftCloudRegions || [];
export const AD_CLOUD_REGIONS = window.autoDrivingCloudRegions || [];

const IS_I18N = site === 2

export interface IResourceCount {
  totalCount: number
  regionId: number
  newFlag?: boolean
  expiredCount?: number
}

enum Types {
  REFRESH_RESOURCE_COUNT_LIST,
  SET_RESOURCE_COUNT_LIST,
}
export class RegionDuck extends Base {
  /** 
   * 是否需要判断团体云逻辑
   * 默认 false 
   */
  public get needFilterFtCloudRegion() {
    return false
  }

  /**
   * 是否需要判断自动驾驶云逻辑
   * 默认 false
   */
  public get needFilterAdCloudRegion() {
    return false
  }

  public get quickTypes() {
    return {
      ...super.quickTypes,
      ...Types,
    }
  }
  public get reducers() {
    const { types } = this
    return {
      ...super.reducers,
      resourceCountList: reduceFromPayload<IResourceCount[]>(types.SET_RESOURCE_COUNT_LIST, []),
    }
  }
  public get creators() {
    const { types } = this
    return {
      ...super.creators,
    }
  }

  public get rawSelectors() {
    type State = this['State']
    return {
      ...super.rawSelectors,
      selectedRegionResource: ({ resourceCountList, id }: State) =>
        resourceCountList?.find(({ regionId }) => regionId === id),
      list: ({ fullList, whiteList, resourceCountList }: State): Region[] => {
        return fullList
          .filter((region) => {
            return !whiteList.length || whiteList.indexOf(region.value) >= 0
          })
          .map((item) => {
            const finder = resourceCountList?.find((o) => o.regionId === item.value)
            return {
              ...item,
              name: finder
                ? item.name + '(' + finder.totalCount + ')'
                : item.name,
              newFlag: finder ? finder.newFlag : false,
            }
          })
      },
    }
  }

  /** 触发数量更新的type */
  public get refreshRgionNumType() {
    const { types } = this
    return [types.REFRESH_RESOURCE_COUNT_LIST]
  }
  public *saga() {
    const duck = this
    yield fork([duck, duck.watchAndUpdateResourceCount])
    yield fork([duck, duck.watchAndUpdateExtraList])
    yield* super.saga()
  }

  *watchAndUpdateResourceCount() {
    const duck = this
    const { types } = duck
    yield takeLatest([types.SET_FULL_LIST], function*({ payload }) {
      const resourceCountList: IResourceCount[] = yield call([duck, duck.getResourceCount], payload)
      yield put({
        type: types.SET_RESOURCE_COUNT_LIST,
        payload: resourceCountList,
      })
    })
  }

  *watchAndUpdateExtraList() {}

  /** 获取地域数量方法，业务自定义 */
  public *getResourceCount() {
    return yield []
  }

  /**
   * 加载地域列表
   * @param duck
   */
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  async fetchRegion(duck: this): Promise<this['Item'][]> {
    const { needFilterFtCloudRegion, needFilterAdCloudRegion } = duck
    // 团体云用户只展示团体云支持的地域，不需要考虑国际站
    const isFtCloudUser = await app.user.isFtCloudUser();
    if (needFilterFtCloudRegion && isFtCloudUser && !IS_I18N) {
      return duck.queryftCloudRegion();
    }
    // 自动驾驶云用户只展示自动驾驶云支持的地域，不需要考虑国际站
    const isAdCloudUser = await app.user.isAutoDrivingCloudUser();
    if (needFilterAdCloudRegion && isAdCloudUser && !IS_I18N) {
      return duck.queryAdCloudRegion();
    }
    // 默认直接返回控制台地域
    return duck.queryConsoleRegion();
  }

  /**
   * 获取团体云地域列表
   * @returns Region[]
  */
  queryftCloudRegion(): Region[] {
    return FT_CLOUD_REGIONS?.map((region) => {
      const regionId = parseInt(region.id as any, 10);
      return {
        // 从 regionName: 华南地区（深圳金融）中提取area和name
        area: region.regionName.match(/(\S*)（/)?.[1] || region.regionName,
        name: region.regionName.match(/（(\S*)）/)?.[1] || region.regionName,
        value: regionId,
        regionId,
        region: region.region,
      };
    });
  }

  /**
   * 获取自动驾驶云地域列表
   */
  queryAdCloudRegion(): Region[] {
    return AD_CLOUD_REGIONS?.map((region) => {
      const regionId = parseInt(region.id as any, 10);
      return {
        // 从 regionName: 华东地区（上海自动驾驶云）中提取area和name
        area: region.regionName.match(/(\S*)（/)?.[1] || region.regionName,
        name: region.regionName.match(/（(\S*)）/)?.[1] || region.regionName,
        value: regionId,
        regionId,
        region: region.region,
      };
    });
  }

  /**
   * 获取控制台完整地域列表
   * @returns Region[]
   */
  async queryConsoleRegion() {
    const result = await QueryConsoleRegion();
    return result.regionList.map<Region>((region) => {
      const regionId = parseInt(region.regionId as any, 10);
      return {
        area: region.area,
        name: region.regionName,
        value: regionId,
        regionId,
        region: region.region,
      };
    });
  }
}

/**
 * qcbase提供的查询地域列表
 * @param param 请求参数
 * @param regionId 请求地域
 * @param opts 请求设置
 */
async function QueryConsoleRegion(): Promise<{
  regionList: {
    area: string; // 华南地区
    region: string; // ap-guangzhou
    regionId: number; // 1
    regionName: string; // 广州
  }[];
}> {
  return cgiRequest({ cgi: 'area', action: 'queryConsoleRegion', regionId: 1, data: {} });
}
