/**
 * 编辑和创建标签
 */
import { fork, put, select, take } from 'redux-saga/effects'
import { createToPayload, DuckMap, reduceFromPayload } from 'saga-duck'
import { takeLatest } from 'redux-saga-catch'
import Fetcher from '@tencent/iaas-common/ducks/Fetcher'
import { capiRequest } from '../utils'

const TAG_LIMIT = 1000

export interface ITagItem {
  tagKey: string
  tagValue: string
}

export interface IRow {
  tagKey?: string
  tagValue?: string
  index: number
  keyList?: string[]
  valueList?: string[]
}

const EMPTY_ROW: IRow = {
  tagKey: '',
  tagValue: '',
  index: 0,
  keyList: [],
  valueList: [],
}

export interface ITagResult {
  key: string
  value: string
}

export class EditTagDuck extends DuckMap {
  get quickDucks() {
    return {
      ...super.quickDucks,
      tagKeyFetcher: class TagKeyFetcher extends Fetcher {
        Param: {
          allTagKeyList: string[]
          regionId: number
        }
        Data: string[]

        async getDataAsync(param: this['Param']): Promise<this['Data']> {
          const { regionId, allTagKeyList } = param

          // 缓存
          if (allTagKeyList) {
            return allTagKeyList
          }
          let {
            Response: { Tags = [], TotalCount },
          } = await capiRequest(
            {
              serviceType: 'tag',
              action: 'DescribeTagKeys',
              data: {
                Offset: 0,
                Limit: TAG_LIMIT,
                Version: '2018-08-13',
              },
              regionId,
            },
            {
              camTips: false,
            }
          )

          if (TAG_LIMIT < TotalCount) {
            let taskList = []
            for (let offset = TAG_LIMIT; offset < TotalCount; offset += TAG_LIMIT) {
              taskList.push(
                capiRequest(
                  {
                    serviceType: 'tag',
                    action: 'DescribeTagKeys',
                    data: {
                      Offset: offset,
                      Limit: TAG_LIMIT,
                      Version: '2018-08-13',
                    },
                    regionId,
                  },
                  {
                    camTips: false,
                  }
                ).then(({ Response: { Tags } }) => Tags)
              )
            }
            const resultList = await Promise.all(taskList)
            resultList.forEach((newList) => Array.prototype.push.apply(Tags, newList))
          }

          return Tags
        }
      },
      tagValueFetcher: class TagValueFetcher extends Fetcher {
        Param: {
          tagKeyValueMap: { [key: string]: string[] }
          tagKey: string
          regionId: number
        }
        Data: { [key: string]: string[] }

        async getDataAsync(param: this['Param']): Promise<this['Data']> {
          const { regionId, tagKey, tagKeyValueMap } = param

          // 缓存
          if (!tagKey || tagKeyValueMap?.[tagKey]) {
            return tagKeyValueMap
          }
          let {
            Response: { Tags, TotalCount },
          } = await capiRequest(
            {
              serviceType: 'tag',
              action: 'DescribeTagValues',
              data: {
                Offset: 0,
                Limit: TAG_LIMIT,
                TagKeys: [tagKey],
                Version: '2018-08-13',
              },
              regionId,
            },
            {
              camTips: false,
            }
          )

          if (TAG_LIMIT < TotalCount) {
            let taskList = []
            for (let offset = TAG_LIMIT; offset < TotalCount; offset += TAG_LIMIT) {
              taskList.push(
                capiRequest(
                  {
                    serviceType: 'tag',
                    action: 'DescribeTagValues',
                    data: {
                      Offset: offset,
                      Limit: TAG_LIMIT,
                      TagKeys: [tagKey],
                      Version: '2018-08-13',
                    },
                    regionId,
                  },
                  {
                    camTips: false,
                  }
                ).then(({ Response: { Tags } }) => Tags)
              )
            }
            const resultList = await Promise.all(taskList)
            resultList.forEach((newList) => Array.prototype.push.apply(Tags, newList))
          }

          return {
            ...tagKeyValueMap,
            [tagKey]: Tags.map(({ TagValue }) => TagValue),
          }
        }
      },
    }
  }

  get quickTypes() {
    enum Types {
      INIT,
      ADD_ROW,
      DELETE_ROW,
      UPDATE_TAG,
      SET_TAG_KEY_MAP,
      SET_ALL_KEYS_LIST,
      SET_SELECTED_TAG_LIST,
      SET_SELECTED_TAG_KEY_MAP,
      QUERY_TAG_KEY,
      QUERY_TAG_VALUE,
      UPDATE_ROW,
    }

    return {
      ...super.quickTypes,
      ...Types,
    }
  }

  get reducers() {
    const { types } = this
    return {
      ...super.reducers,
      regionId: (state = 1, action) => {
        if (action.type === types.INIT) {
          return action.payload?.regionId || 1
        }
        return state
      },
      allTagKeyList: reduceFromPayload<string[]>(types.SET_ALL_KEYS_LIST, null),
      tagKeyValueMap: reduceFromPayload<{ [key: string]: string[] }>(types.SET_TAG_KEY_MAP, {}),
      selectedTagList: reduceFromPayload<IRow[]>(types.SET_SELECTED_TAG_LIST, []),
      selectedTagKeyMap: reduceFromPayload<{ [key: string]: number }>(
        types.SET_SELECTED_TAG_KEY_MAP,
        {}
      ),
    }
  }

  get creators() {
    const { types } = this
    return {
      ...super.creators,
      init: createToPayload<{ regionId: number }>(types.INIT),
      setAllKeyList: createToPayload<string[]>(types.SET_ALL_KEYS_LIST),
      setTagKeyValueMap: createToPayload<{ [key: string]: string[] }>(types.SET_TAG_KEY_MAP),
      setSelectedTagList: createToPayload<IRow[]>(types.SET_SELECTED_TAG_LIST),
      setSelectedTagKeyMap: createToPayload<{ [key: string]: number }>(
        types.SET_SELECTED_TAG_KEY_MAP
      ),
      updateTag: createToPayload<IRow>(types.UPDATE_TAG),
      deleteRow: createToPayload<IRow>(types.DELETE_ROW),
      addRow: () => ({ type: types.ADD_ROW }),
      queryTagKey: createToPayload<IRow>(types.QUERY_TAG_KEY),
      queryTagValue: createToPayload<IRow>(types.QUERY_TAG_VALUE),
      updateRow: createToPayload<IRow>(types.UPDATE_ROW),
    }
  }

  get rawSelectors() {
    type State = this['State']
    return {
      ...super.rawSelectors,
      selectedTagList: ({ selectedTagList }: State) => selectedTagList,
      allTagKeyList: ({ allTagKeyList }: State) => allTagKeyList,
      tagKeyValueMap: ({ tagKeyValueMap }: State) => tagKeyValueMap,
      // 传给外界的值
      values: ({ selectedTagList }: State): ITagItem[] => {
        return (
          selectedTagList
            // 过滤tagList中的无效项, null，{key:'', value:''}
            .filter((item) => item && item.tagKey !== '')
            .map((item) => ({
              tagKey: item.tagKey,
              tagValue: item.tagValue,
            }))
        )
      },
    }
  }

  *watchToFetchTagList() {
    const duck = this
    const { types, creators, selector, ducks } = duck

    /** 拉取标签键列表 */
    yield takeLatest([types.QUERY_TAG_KEY], function* ({ payload }: { payload: IRow }) {
      const { regionId, allTagKeyList } = selector(yield select())
      yield put(ducks.tagKeyFetcher.creators.fetch({ regionId, allTagKeyList }))

      yield take(ducks.tagKeyFetcher.types.FETCH_DONE)
      const {
        tagKeyFetcher: { data },
      } = selector(yield select())
      yield put(creators.setAllKeyList(data))

      yield put(creators.updateRow(payload))
    })

    /** 拉取标签值列表 */
    yield takeLatest([types.QUERY_TAG_VALUE], function* ({ payload }: { payload: IRow }) {
      const { tagKey } = payload
      const { regionId, tagKeyValueMap } = selector(yield select())
      yield put(ducks.tagValueFetcher.creators.fetch({ regionId, tagKey, tagKeyValueMap }))

      yield take(ducks.tagValueFetcher.types.FETCH_DONE)
      const {
        tagValueFetcher: { data },
      } = selector(yield select())
      yield put(creators.setTagKeyValueMap(data))

      yield put(creators.updateRow(payload))
    })
  }

  *watchToRowUpdate() {
    const duck = this
    const { types, creators, selector, selectors } = duck
    /** 增加标签 */
    yield takeLatest([types.ADD_ROW], function* () {
      let { selectedTagList, allTagKeyList } = selector(yield select())
      selectedTagList = selectedTagList.concat([
        {
          ...EMPTY_ROW,
          tagKey: '',
          tagValue: '',
          index: selectedTagList.length,
          keyList: allTagKeyList,
          valueList: null,
        },
      ])
      yield put(creators.setSelectedTagList(selectedTagList))
    })
    /** 更新某列的keyList valueList */
    yield takeLatest([types.UPDATE_ROW], function* ({ payload }: { payload: IRow }) {
      let { allTagKeyList, tagKeyValueMap, selectedTagList } = selector(yield select())
      const { index } = payload

      selectedTagList = selectedTagList.map((item) => {
        if (item.index === index) {
          return {
            ...item,
            keyList: item.keyList || allTagKeyList,
            valueList: item.valueList || tagKeyValueMap?.[item.tagKey],
          }
        } else {
          return { ...item }
        }
      })
      yield put(creators.setSelectedTagList(selectedTagList))
    })
    /** 删除某条标签 */
    yield takeLatest([types.DELETE_ROW], function* ({ payload }) {
      const { index, tagKey } = payload
      let { selectedTagList, selectedTagKeyMap } = selector(yield select())
      selectedTagList = selectedTagList.filter((item) => item.index !== index)
      if (tagKey) {
        delete selectedTagKeyMap[tagKey]
        yield put(creators.setSelectedTagKeyMap(selectedTagKeyMap))
      }
      yield put(creators.setSelectedTagList(selectedTagList))
    })
  }

  *watchToUpdateTag() {
    const duck = this
    const { types, selectors, creators, selector } = duck

    /** 更新某条标签 */
    yield takeLatest([types.UPDATE_TAG], function* ({ payload }) {
      const { index, tagKey, tagValue, keyList } = payload
      let { selectedTagList, tagKeyValueMap, selectedTagKeyMap } = selector(yield select())
      let oldTagItem = selectedTagList[index]
      selectedTagKeyMap[oldTagItem.tagKey] = selectedTagKeyMap[oldTagItem.tagKey] - 1
      selectedTagKeyMap[tagKey] = selectedTagKeyMap[tagKey] ? selectedTagKeyMap[tagKey] + 1 : 1

      selectedTagList[index] = {
        ...oldTagItem,
        tagKey,
        tagValue,
        index,
        keyList: keyList,
        valueList: tagKeyValueMap?.[tagKey],
      }

      yield put(creators.setSelectedTagList([...selectedTagList]))
      yield put(creators.setSelectedTagKeyMap({ ...selectedTagKeyMap }))
    })
  }

  *saga() {
    const duck = this
    yield* super.saga()
    yield fork([duck, duck.watchToFetchTagList])
    yield fork([duck, duck.watchToRowUpdate])
    yield fork([duck, duck.watchToUpdateTag])
  }
}
