import { reduceFromPayload, createToPayload, DuckMap, asResult } from 'saga-duck'
import { fork, call, select } from 'redux-saga/effects'
import { delay } from 'redux-saga'
import { takeLatest, takeEvery, runAndTakeLatest } from 'redux-saga-catch'

export abstract class DetailPageTabDuck extends DuckMap {
  abstract IData
  get quickTypes() {
    enum Types {
      SET_DATA,
      ACTIVE,
      SWITCH_TAB,
    }
    return {
      ...super.quickTypes,
      ...Types,
    }
  }

  get creators() {
    const { types } = this
    return {
      ...super.creators,
      setData: createToPayload<this['IData']>(types.SET_DATA),
    }
  }

  get reducers() {
    const { types } = this
    return {
      ...super.reducers,
      tab: reduceFromPayload<string>(types.SWITCH_TAB, ''),
      data: (state = null, action): this['IData'] => {
        switch (action.type) {
          case types.ACTIVE:
          case types.SET_DATA:
            return action.payload
          default:
            return state
        }
      },
    }
  }

  get rawSelectors() {
    type State = this['State']
    return {
      ...super.rawSelectors,
    }
  }
  /**
   * 监听tab被激活
   */
  *watchTabActive() {
    const { types, selector, ducks } = this
    const duck = this
    yield takeLatest([types.ACTIVE], function* ({ payload }) {
      yield call([duck, duck.afterTabActive], payload)
    })
  }
  *saga() {
    const duck = this
    yield* super.saga()
    yield fork([duck, duck.watchTabActive])
  }
  /**
   * 每次当tab被激活后？
   */
  abstract afterTabActive(payload)
}
