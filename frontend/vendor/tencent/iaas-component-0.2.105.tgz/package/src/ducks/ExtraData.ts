import { put, call, fork } from 'redux-saga/effects'
import { BaseDuck } from 'saga-duck'
import { takeLatest } from 'redux-saga-catch'
enum Types {
  FETCH,
  FETCH_DONE,
}
interface IExtraData {
  [key: string]: any
}

export class ExtraDataDuck extends BaseDuck {
  IState: IExtraData
  get quickTypes() {
    return {
      ...super.quickTypes,
      ...Types,
    }
  }
  get reducer() {
    const { types } = this
    return (state = null, action): this['IState'] => {
      switch (action.type) {
        case types.FETCH_DONE:
          return action.payload
        default:
          return state
      }
    }
  }
  /**
   * 获取额外数据方法，子类继承实现
   */
  *getExtraData(payload) {
    return yield {}
  }
  *watchToFetch() {
    const duck = this
    const { types } = duck
    yield takeLatest(types.FETCH, function*({ payload }) {
      const extraData = yield call([duck, duck.getExtraData], payload)
      yield put({
        type: types.FETCH_DONE,
        payload: extraData,
      })
    })
  }
  *saga() {
    yield* super.saga()
    const duck = this
    yield fork([duck, duck.watchToFetch])
  }
}
