import { select, put, call, take, fork, join } from 'redux-saga/effects'
import { takeLatest, takeEvery, runAndTakeLatest } from 'redux-saga-catch'
import { delay } from 'redux-saga'
import { reduceFromPayload, createToPayload, DuckMap } from 'saga-duck'
import { app } from '@tencent/tea-app'
import { t } from '@tencent/tea-app/lib/i18n'

import { showDialog } from '@tencent/iaas-common/helpers/showDialog'
import { IButtonOperation, IDropdownOperation, OperateBase } from '../index'
import { PageParam } from '@tencent/iaas-common/ducks/Page'
export interface IOperationMap {
  [action: string]: IButtonOperation & {
    /**
     * 操作的action一般为云API接口名，除非是非云API的操作，首字母大写
     */
    action: string
    /**
     * 操作的描述
     */
    desc: string
    duck: any
    component?: any
    /**
     * 可选项
     */
    options?: {
      /**
       * 是否需要mfa校验？
       */
      mfa?: boolean
      /**
       * 云API业务名，如cvm，当需要mfa校验时才需要设置
       */
      serviceType?: string
      /**
       * 操作是否不需要选中实例？
       */
      isNotNeedSelectedItems?: boolean
    }
  }
}

export interface IOperationResultOptions {
  /**
   * 是否完成后清空选中项（目前的逻辑 refresh 则一定会clear）
   */
  clear: boolean
  /**
   * 是否完成后刷新列表
   */
  refresh: boolean
  /**
   * 是否显示tip，暂时为操作成功提示
   */
  tips?: boolean
}
export type IOperationStatus = 'SUCCESS' | 'FAILED' | 'CANCEL'
export interface IOperationResult {
  status: IOperationStatus
  action?: string
  desc?: string
  params?: any
  callback?: Function
  options: IOperationResultOptions
}

export const OPERATION_STATUS: {
  [key: string]: IOperationStatus
} = {
  SUCCESS: 'SUCCESS',
  FAILED: 'FAILED',
  CANCEL: 'CANCEL',
}

export const DEFAULT_OPERATION_RESULT = {
  status: OPERATION_STATUS.CANCEL,
  options: {
    clear: true,
    refresh: true,
    tips: true,
  },
}
export abstract class OperationDuck extends DuckMap {
  abstract IItem
  abstract IExtraData
  get defaultExtraData(): this['IExtraData'] {
    return null
  }
  get operationMap(): IOperationMap {
    return null
  }
  get quickTypes() {
    enum Types {
      SET_DENIED_BATCH_ACTION_MAP,
      SET_SELECTED_ITEMS,
      SELECT_OPERATION,
      EXECUTE_OPERATION,
      FINISH_OPERATION,
      SET_DATA,
      SET_CURRENT_ACTION,
    }
    return {
      ...super.quickTypes,
      ...Types,
    }
  }
  get reducers() {
    const { types } = this
    return {
      ...super.reducers,
      /**
       * 当前选中的操作
       */
      action: reduceFromPayload<string>(types.SET_CURRENT_ACTION, ''),
      /**
       * 被禁止的批量操作
       */
      deniedBatchActionMap: reduceFromPayload<{ [key: string]: string }>(
        types.SET_DENIED_BATCH_ACTION_MAP,
        null
      ),
      selectedItems: (state = [], action): this['IItem'][] => {
        switch (action.type) {
          case types.SET_SELECTED_ITEMS:
            return action.payload
          case types.SELECT_OPERATION:
            return action.payload.selectedItems ? action.payload.selectedItems : state
          default:
            return state
        }
      },
      extraData: reduceFromPayload<this['IExtraData']>(types.SET_DATA, this.defaultExtraData),
    }
  }
  get creators() {
    const { types } = this
    return {
      ...super.creators,
      setDeniedBatchOperationMap: createToPayload<string>(types.SET_DENIED_BATCH_ACTION_MAP),
      setSelectedItems: createToPayload<this['IItem'][]>(types.SET_SELECTED_ITEMS),
      select: createToPayload<{
        operationAction: string
        selectedItems?: this['IItem'][]
        params?: any
      }>(types.SELECT_OPERATION),
      execute: createToPayload<{ operationAction: string; params: any }>(types.EXECUTE_OPERATION),
      finish: createToPayload<IOperationResult>(types.FINISH_OPERATION),
      setExtraData: createToPayload<this['IExtraData']>(types.SET_DATA),
      setCurrentAction: createToPayload<string>(types.SET_CURRENT_ACTION),
    }
  }
  get rawSelectors() {
    type State = this['State']
    return {
      ...super.rawSelectors,
      /**
       * 批量平铺操作
       */
      batchOperationButtonList: (state: State): IButtonOperation[] => [],
      /**
       * 批量下拉操作
       */
      batchOperationDropDownList: (state: State): IDropdownOperation[] => [],
      currentAction: ({ action }: State) => action,
    }
  }
  get quickDucks() {
    return {
      ...super.quickDucks,
    }
  }
  /**
   * 与RouteDuck配合时使用
   */
  getRouteParam(o: Partial<PageParam> = {}): PageParam<string> {
    return {
      key: 'action',
      route: 'action',
      history: false,
      order: 10,
      defaults: '',
      alwaysVisible: false,
      type: this.types.SET_CURRENT_ACTION,
      selector: this.selectors.currentAction,
      creator: this.creators.setCurrentAction,
      ...o,
    }
  }
  /**
   * 获取批量操作的限制
   */
  getDeniedBatchActionMap() {
    return {}
  }
  /**
   * 更新批量操作的限制（单个操作限制在item里）
   */
  *watchToUpdateDeniedActionMap() {
    const duck = this
    const { creators, selector, types } = duck
    yield runAndTakeLatest(
      [types.SET_SELECTED_ITEMS, types.SELECT_OPERATION, types.SET_DATA],
      function* (action) {
        // 因为存在列表操作单个实例不需要先勾选checkbox的情况
        if (action && action.type === types.SELECT_OPERATION && !action.payload.selectedItems) {
          return
        }
        const deniedBatchActionMap = yield call([duck, duck.getDeniedBatchActionMap])
        yield put({
          type: types.SET_DENIED_BATCH_ACTION_MAP,
          payload: deniedBatchActionMap,
        })
      }
    )
  }
  /**
   * 开始执行操作
   * todo: 待sdk的callback逻辑确认后，将cvmoperationduck的逻辑迁移到此处
   */
  *watchToExecuteOperation() {
    const duck = this
    const { creators, selector, types, operationMap } = duck
    yield takeLatest(types.EXECUTE_OPERATION, function* ({ payload: { operationAction, params } }) {
      const operation = operationMap[operationAction]
      /**
       * 操作结果
       */
      let operationResult: IOperationResult = null

      if (operation) {
        if (
          // 没有选择实例
          (!params.selectedItems || !params.selectedItems.length) &&
          // 又没有设置 操作不需要选择实例
          !(operation.options && operation.options.isNotNeedSelectedItems)
        ) {
          return app.tips.error(t('请先选择需要执行操作的对象！'))
        }
        const OperationComponent = operation.component
        const OperationDuck = operation.duck
        if (OperationDuck) {
          if (OperationComponent) {
            // 存在弹窗交互的操作
            operationResult = yield new Promise(function (resolve, reject) {
              showDialog<OperateBase>(OperationComponent, OperationDuck, function* (duck) {
                // mfa 校验
                if (operation.options && operation.options.mfa) {
                  const mfaPassed = yield app.mfa.verify(
                    `${operation.options.serviceType}:${operation.action}`
                  )
                  if (!mfaPassed) {
                    // 校验取消，跳过后续业务
                    return
                  }
                }
                yield takeLatest(duck.types.HIDE, function* () {
                  const store = yield select()
                  const { status } = duck.selector(store)
                  const callback = duck.selectors.callback(store)
                  const params = duck.selectors.params(store)
                  const options = duck.selectors.options(store)
                  // 返回操作的结果
                  resolve({
                    status,
                    callback,
                    params,
                    options,
                    store, // 传入弹框store,供弹框关闭后，外部使用弹框关闭前的部分数据
                  })
                })
                // 操作弹窗显示，开始具体的操作交互
                yield duck.show(
                  {
                    ...params,
                    operationDesc: operation.desc,
                  },
                  function (submitData, dialogData) {
                    // 操作完成回调
                  }
                )
              })
            })
          } else {
            // 不存在业务实现的弹窗组件交互的操作，如查看监控，调用其他业务SDK
            const operationDuck = new OperationDuck({
              namespace: operation.action,
            })
            // 返回结果
            operationResult = yield operationDuck.execute({
              ...params,
            })
          }
        }
        // 上报点击操作 路由+action  cvm.instance.index.operation.RebootInstances.SUCCESS
        app.insight.reportHotTag(
          `${location.pathname.split('/').join('.').substring(1)}.operation.${operationAction}.${
            operationResult.status || DEFAULT_OPERATION_RESULT.status
          }`
        )
        if (operationResult.status === 'SUCCESS') {
          yield delay(1000)
        }
        yield put(
          creators.finish({
            ...DEFAULT_OPERATION_RESULT,
            ...operationResult,
            action: operation.action,
            desc: operation.desc,
          })
        )
      } else {
        app.tips.error(t('不存在该操作的实现方法'))
      }
    })
  }
  /**
   * 执行操作成功
   */
  *watchExecuteOperationFinished() {
    const duck = this
    const { creators, selector, types } = duck
    yield takeLatest(types.FINISH_OPERATION, function* ({
      payload: { status, action, desc, options, callback },
    }) {
      // 顶部提示
      if (status === 'SUCCESS') {
        if (options) {
          if (options.operationAction) {
            const { selectedItems } = selector(yield select())
            yield put(
              creators.select({
                selectedItems,
                operationAction: options.operationAction,
              })
            )
          }
          // 成功提示
          if (options.tips) {
            app.tips.success(t('操作成功'))
          }
          // 清空选中项
          if (options.clear) {
            yield put(creators.setSelectedItems([]))
          }
          // 回调函数
          if (options.callback) {
            yield call([duck, options.callback])
          }
          if (callback) {
            yield call([duck, callback])
          }
        }
      }
    })
  }
  /**
   * 监听以设置当前action
   * 为什么本来在reducer就可以完成更新的，但是为了触发url更新，又拆分出来了
   */
  *watchToSetCurrentAction() {
    const { creators, types, selector } = this
    yield takeLatest(types.SELECT_OPERATION, function* ({ payload }) {
      const { action } = selector(yield select())
      if (payload?.operationAction !== action) {
        yield put(creators.setCurrentAction(payload.operationAction))
      }
    })
    yield takeLatest(types.FINISH_OPERATION, function* ({ payload }) {
      yield put(creators.setCurrentAction(''))
    })
  }
  *saga() {
    const duck = this
    yield* super.saga()
    yield fork([duck, duck.watchExecuteOperationFinished])
    yield fork([duck, duck.watchToExecuteOperation])
    yield fork([duck, duck.watchToUpdateDeniedActionMap])
    yield fork([duck, duck.watchToSetCurrentAction])
  }
}
