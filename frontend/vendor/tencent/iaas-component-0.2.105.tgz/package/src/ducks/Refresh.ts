import { Duck as Base, reduceFromPayload, createToPayload } from 'saga-duck'
import { select, put, call, take, fork, join } from 'redux-saga/effects'
import { delay } from 'redux-saga'
import { takeLatest, takeEvery } from 'redux-saga-catch'
import { FetcherDuck } from '@tencent/iaas-common/ducks'

/**
 * 轮询查询刷新duck，仅用来执行查询逻辑
 */
export abstract class RefreshDuck extends FetcherDuck {
  abstract Item
  Param: {
    regionId: number
    loadingIdList: string[]
  }
  Data: {
    list: Array<{ $isLoading: boolean } & this['Item']>
  }
  get quickTypes() {
    enum Types {
      UPDATE_MAX_REFRESH_COUNT_MAP,
    }
    return {
      ...super.quickTypes,
      ...Types,
    }
  }
  get reducers() {
    const { types } = this
    return {
      ...super.reducers,
      maxRefreshCountMap: (state = {}, action): { [key: string]: number } => {
        switch (action.type) {
          case types.UPDATE_MAX_REFRESH_COUNT_MAP:
            return { ...state, ...action.payload }
          default:
            return state
        }
      },
    }
  }
  get creators() {
    const { types } = this
    return {
      ...super.creators,
      updateRefreshCountMap: createToPayload<{ [key: string]: number }>(
        types.UPDATE_MAX_REFRESH_COUNT_MAP
      ),
    }
  }
  isLoading(item: any) {
    return false
  }
}
