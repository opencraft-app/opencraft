seajs.use(['util'])
import { OperateBase as Base } from '../ducks'
import { reduceFromPayload, createToPayload } from 'saga-duck'
import { select, call } from 'redux-saga/effects'
import iaas from '../utils/iaas';
const appUtil = seajs.require('appUtil')
const util = seajs.require('util')

export abstract class DownloadDuck extends Base {
  /** 传入参数 */
  ExtraData: {
    /** 是否异步加载 */
    inAsyncFetchWhite: any
    /** 当前搜索条件 */
    searchParams?: any
  }
  /** 数据导出的 cgi 地址，是否异步下载白名单 */
  abstract exportInfo: {
    cgiUrl?: string
    asyncCgiUrl?: string
    asyncPollUrl?: string
  }
  *getQueryParams() {
    const duck = this
    const {
      list,
      regionId,
      exportOption,
      data: { searchParams },
    } = duck.selector(yield select())
    let param
    switch (exportOption) {
      case 'filter':
        param = { ...searchParams }
        break
      case 'selected':
        param = duck.getSelectedItemParams(list)
        break
      default:
        param = {}
        break
    }
    return { ...param, regionId }
  }
  *onSubmit() {
    const duck = this
    const { selectors, selector } = duck
    const queryParams = yield call([duck, duck.getQueryParams], duck)
    const { columns } = yield select(this.selector)
    const {
      data: { inAsyncFetchWhite },
    } = yield select(selector)
    start(
      {
        inAsyncFetchWhite,
        cgiUrl: this.exportInfo.cgiUrl,
        asyncCgiUrl: this.exportInfo.asyncCgiUrl,
        asyncPollUrl: this.exportInfo.asyncPollUrl,
      },
      queryParams,
      columns || undefined
    )
  }

  get quickTypes() {
    enum Types {
      SET_EXPORT_OPTION,
      SET_QUERY_PARAMS,
      SET_COLUMNS,
    }
    return {
      ...super.quickTypes,
      ...Types,
    }
  }
  get reducers() {
    const { types } = this
    return {
      ...super.reducers,
      exportOption: reduceFromPayload<string>(types.SET_EXPORT_OPTION, 'all'),
      /** 导出时选择的字段，返回字段名称数组，返回null代表请求中不包含字段信息 */
      columns: reduceFromPayload<string[]>(types.SET_COLUMNS, []),
      queryParams: reduceFromPayload(types.SET_QUERY_PARAMS, null),
    }
  }
  get creators() {
    const { types } = this
    return {
      ...super.creators,
      setColumns: createToPayload<string[]>(types.SET_COLUMNS),
      setExportOption(payload: string) {
        return { type: types.SET_EXPORT_OPTION, payload }
      },
    }
  }
  /** 下载列表选中项的参数，供外界自定义 */
  abstract getSelectedItemParams(list)
}

function getParams(options, columns, rk = undefined) {
  return {
    t: new Date().getTime(),
    uin: util.getUin(),
    csrfCode: util.getACSRFToken(),
    regionId: options.regionId || appUtil.getRegionId(),
    expired: options.expired,
    qip: JSON.stringify(options),
    columns: columns || undefined,
    rk: rk,
  }
}

interface IExportOptions {
  /** 是否下载过期云盘 */
  expired?: boolean
  /** 指定下载云盘 */
  qip?: string[]
}
interface IExportInfo {
  inAsyncFetchWhite: boolean
  cgiUrl: string
  asyncCgiUrl: string
  asyncPollUrl: string
}
function start(exportInfo: IExportInfo, options: IExportOptions = {}, columns = undefined) {
  if (exportInfo.inAsyncFetchWhite) {
    // 白名单客户走异步下载，前台进行轮询
    // redis key 自动生成
    const rk = [util.getUin(), new Date().getTime(), Math.round(Math.random() * 10000)].join('-')
    pollExportStatus(exportInfo.asyncPollUrl, getParams(options, columns, rk), function() {
      // 成功后进行下载
      const downloadLink =
        exportInfo.asyncCgiUrl + '&' + util.objectToParams(getParams(options, columns, rk))
      location.href = downloadLink
    })
  } else {
    // 直接下载
    location.href = exportInfo.cgiUrl + '&' + util.objectToParams(getParams(options, columns))
  }
}
function pollExportStatus(link, bodyData, callBack) {
  iaas.request(link, { data: bodyData }).then(function(data) {
    if (data.status === 'DONE') {
      callBack && callBack()
    } else {
      setTimeout(function() {
        pollExportStatus(link, bodyData, callBack)
      }, 5000)
    }
  })
}
