import Base from '@tencent/iaas-common/ducks/WhiteList'

export interface IWhiteList {
  [key: string]: boolean
}
export class WhiteListDuck extends Base {
  get whiteKeys() {
    return ['test']
  }
}
