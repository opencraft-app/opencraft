/**
 * table search
 * 1. 可搜索（也可关闭此功能）
 * 2. 可分页加载更多
 */
import Base from '@tencent/iaas-common/ducks/SearchableList'
import { createToPayload, reduceFromPayload } from 'saga-duck'
export abstract class SearchTableDuck extends Base {
  ID: string
  abstract getId(o: this['Item']): this['ID']
  get quickTypes() {
    enum Types {
      SELECT,
    }
    return {
      ...super.quickTypes,
      ...Types,
    }
  }
  get pageSize() {
    /** 默认取100条 */
    return 100
  }
  get reducers() {
    const { types } = this
    return {
      ...super.reducers,
      ids: reduceFromPayload(types.SELECT, []),
    }
  }
  get rawSelectors() {
    type State = this['State']
    const duck = this
    return {
      ...super.rawSelectors,
      ids: (state: State) => state.ids,
      selectedItems: (state: State) => {
        return duck.find(state.list, state.ids)
      },
    }
  }
  get creators() {
    const { types } = this
    type TID = this['ID']
    return {
      ...super.creators,
      select: createToPayload<TID[]>(types.SELECT),
    }
  }
  /* eslint-disable */
  protected find(list: this['Item'][], ids: this['ID'][]): this['Item'][] {
    const duck = this
    return (list || []).filter((item) => ids.indexOf(duck.getId(item)) > -1)
  }
}
