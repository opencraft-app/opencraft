import { call } from 'redux-saga/effects'
import Base from '@tencent/iaas-common/ducks/Fetcher'

export interface PriceResult {
  originPrice?: string | number
  discountPrice: string | number
  isDiscount?: boolean
  unit?: string
}

export abstract class PriceDuck extends Base {
  Data: PriceResult & this['Result']

  PriceParam: this['Param'] & {
    regionId: number
  }

  /** 扩展返回值 */
  Result: {};

  *getData(filter: this['PriceParam']) {
    const duck = this
    const { regionId, ...param } = filter
    return yield call([duck, duck.queryPrice], param, regionId)
  }

  get creators() {
    type Param = this['PriceParam']
    const { types } = this
    return {
      ...super.creators,
      /** 按指定过滤条件加载数据 */
      fetch: (param: Param) => ({ type: types.FETCH, payload: param }),
    }
  }

  /** 自定义询价方法 */
  abstract async queryPrice(
    param: this['Param'],
    regionId: number
  ): Promise<PriceResult & this['Result']>
}
