/**
 * 列表操作BaseDuck
 */
import Base from '@tencent/iaas-common/ducks/DialogPure'
import React, { forwardRef, Ref, ReactNode } from 'react'
import {
  reduceFromPayload,
  createToPayload,
  DuckCmpProps,
  Duck,
  BaseDuck,
  DuckMap,
} from 'saga-duck'
import { takeLatest, runAndTakeLatest } from 'redux-saga-catch'
import { put, select, call, all, fork, take } from 'redux-saga/effects'
import { delay } from 'redux-saga'
import { IOperationResultOptions, OPERATION_STATUS } from './Operation'
interface IData<T> {
  /**
   * 当前地域
   */
  regionId: number
  /**
   * 选中的操作项
   */
  selectedItems: T[]
  /**
   * 操作名称： 关机/开机
   */
  operationDesc?: string
}
export abstract class OperateBase extends Base {
  /** 选中项类型 */
  Item: any
  /** 用于扩展初始化操作需要的数据 */
  ExtraData: {}

  /** 白名单key会不断的变化，方便子类重新定义更为严谨的白名单类型，更好地约束编码 */
  whiteList: { 
    /**
    * 用户白名单
    */
    whiteList?: { [key: string]: boolean }
  }

  Data: this['ExtraData'] & IData<this['Item']> & this['whiteList']

  /** 检验提醒 */
  IInvalidField: {
    [fieldName: string]: string
  }
  /** 多步操作才需定义 */
  IStepper: {
    id: string
    label: string
    component: React.ComponentType<DuckCmpProps<any>>
    duck?: Duck | BaseDuck | DuckMap
    props?: any
  }
  get steppers(): this['IStepper'][] {
    return null
  }
  get quickTypes() {
    enum Types {
      SET_LIST,
      SET_REGION_ID,
      TOGGLE_DISABLED,
      /** Button置灰上的提示 */
      SET_REASON,
      /** 设置校验字段 */
      SET_INVALID_MAP,
      UPDATE_INVALID_MAP,
      SET_STEP,
      SET_CONFIRM_FLAG,
      TOGGLE_IF_VALIDATED,
      TOGGLE_IF_SUBMITTED,
    }
    return {
      ...super.quickTypes,
      ...Types,
    }
  }

  get rawSelectors() {
    type State = this['State']
    return {
      ...super.rawSelectors,
      reason: (state: State) => state.reason,
      regionId: (state: State) => state.regionId,
      list: (state: State) => state.list,
      invalidFieldMap: (state: State) => state.invalidFieldMap,
      steppers: (state: State) => this.steppers,
      disabledNext: (state: State) => false,
      disabledPrev: (state: State) => false,
      /**
       * 回调参数 enofan
       */
      params: (state: State) => null,
      /**
       * 回调函数 enofan
       */
      callback: (state: State): Function => null,
      /**
       * 可选项 enofan
       */
      options: (state: State): IOperationResultOptions => this.afterOperationOptions,
    }
  }

  get reducers() {
    const { types } = this
    return {
      ...super.reducers,
      /** 用于Button显示置灰文案 */
      reason: reduceFromPayload<string>(types.SET_REASON, null),
      step: reduceFromPayload<number>(types.SET_STEP, 0),
      regionId: reduceFromPayload<number>(types.SET_REGION_ID, null),
      list: reduceFromPayload<this['Item'][]>(types.SET_LIST, []),
      invalidFieldMap: reduceFromPayload<this['IInvalidField']>(types.SET_INVALID_MAP, {}),
      confirmed: reduceFromPayload<boolean>(types.SET_CONFIRM_FLAG, false),
      /**
       * 是否已执行过 validate 方法
       */
      hasValidated: reduceFromPayload<boolean>(types.TOGGLE_IF_VALIDATED, false),
      /**
       * 是否已执行过 onsubmit 方法
       */
      hasSubmitted: reduceFromPayload<boolean>(types.TOGGLE_IF_SUBMITTED, false),

      /**
       * 本次弹窗内的操作状态，成功，失败(一般只有最后是cam报错才会保持为failed)，取消
       */
      status: (state = OPERATION_STATUS.CANCEL, action): string => {
        switch (action.type) {
          case types.SUBMIT_DONE:
            return OPERATION_STATUS.SUCCESS
          case types.SUBMIT_FAIL:
            return OPERATION_STATUS.FAILED
          default:
            return state
        }
      },
    }
  }

  get creators() {
    const { types } = this
    return {
      ...super.creators,
      setStep: createToPayload<number>(types.SET_STEP),
      confirm: createToPayload<boolean>(types.SET_CONFIRM_FLAG),
      updateInvalidMap: createToPayload(types.UPDATE_INVALID_MAP),
      toggleIfValidated: createToPayload<boolean>(types.TOGGLE_IF_VALIDATED),
      toggleIfSubmitted: createToPayload<boolean>(types.TOGGLE_IF_SUBMITTED),
    }
  }
  /** 哪些动作需要触发表单放开置灰+清空无效信息 */
  get cancelButtonDisbleType(): string[] {
    return []
  }

  *watchCancelButtonDisable() {
    const duck = this
    const { types, cancelButtonDisbleType, selectors } = duck
    yield takeLatest([cancelButtonDisbleType], function* reloadOnChange() {
      yield call(delay, 10)
      const invalidFieldMap = yield select(selectors.invalidFieldMap)
      if (invalidFieldMap) {
        yield put({
          type: types.SET_INVALID_MAP,
          payload: {},
        })
        yield put({
          type: types.TOGGLE_DISABLED,
          payload: false,
        })
      }
    })
  }

  /** 哪些动作需要触发校验表单放开置灰+清空无效信息 */
  get execValidateMethodType(): string[] {
    return []
  }

  *watchToExecValidate() {
    const duck = this
    const { types, execValidateMethodType, creators } = duck
    yield takeLatest(execValidateMethodType, function* () {
      yield call([duck, duck.onValidate])
    })
  }

  *onValidate() {
    const duck = this
    const { types, creators, selector } = duck
    const { hasValidated, disabled } = selector(yield select())
    const isValid = yield call([duck, duck.validate])
    if (!hasValidated) {
      yield put(creators.toggleIfValidated(true))
    }
    const nextDisabled = !isValid
    if (disabled !== nextDisabled) {
      yield put({ type: types.SET_DISABLED, payload: nextDisabled })
    }
    return isValid
  }

  *beforeSubmit() {
    const duck = this
    const { creators, types, selector } = duck
    const { hasSubmitted } = selector(yield select())
    if (!hasSubmitted) {
      yield put(creators.toggleIfSubmitted(true))
    }
    const isValid = yield call([duck, duck.onValidate])
    if (!isValid) {
      throw new Error('isValid')
    }
    yield duck.onSubmit()
  }

  /** 提交，共外界自定义 */
  *onSubmit(): any {}

  /** 校验，供外界自定义 */
  /* eslint-disable require-yield */
  *validate(): any {
    return true
  }

  *initLoadData(): any {}

  *saga() {
    const duck = this
    const { types, selectors, ducks } = duck
    yield* super.saga()

    yield fork([duck, duck.watchCancelButtonDisable])
    yield fork([duck, duck.watchToExecValidate])

    /** 扩展按钮置灰方法 */
    yield takeLatest([types.TOGGLE_DISABLED], function* ({ payload }) {
      if (Object.prototype.toString.call(payload) === '[object Object]') {
        const { disable, message = '' } = payload
        yield put({
          type: types.SET_DISABLED,
          payload: !!disable,
        })
        yield put({
          type: types.SET_REASON,
          payload: message,
        })
      } else {
        yield put({
          type: types.SET_DISABLED,
          payload: !!payload,
        })
      }
    })

    /** 更新单个不合法字段 */
    yield takeLatest([types.UPDATE_INVALID_MAP], function* ({ payload }) {
      const invalidFieldMap = yield select(selectors.invalidFieldMap)
      if (payload) {
        yield put({
          type: types.SET_INVALID_MAP,
          payload: {
            ...invalidFieldMap,
            ...payload,
          },
        })
      }
    })
    /** 初始化加载 */
    yield takeLatest([types.SHOW], function* ({ payload }) {
      if (payload) {
        const { regionId, selectedItems } = payload
        yield put({
          type: types.SET_LIST,
          payload: selectedItems || [],
        })
        yield put({
          type: types.SET_REGION_ID,
          payload: regionId || null,
        })
      }
      yield duck.initLoadData()
    })
  }
  /**
   * 操作完成后的可选项（目前只有成功后才有这些动作
   * clear 清空选中项
   * refresh 刷新列表
   * tips 成功提示
   */
  get afterOperationOptions(): IOperationResultOptions {
    return {
      clear: true,
      refresh: true,
      tips: true,
    }
  }
}
