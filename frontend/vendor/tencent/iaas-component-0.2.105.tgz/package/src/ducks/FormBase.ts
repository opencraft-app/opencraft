import { reduceFromPayload, createToPayload, asResult, DuckMap } from 'saga-duck'
import { select, put, call, take, fork, join } from 'redux-saga/effects'
import { delay } from 'redux-saga'
import { takeLatest, takeEvery } from 'redux-saga-catch'

export abstract class FormBase extends DuckMap {
  abstract Data
  get defaultData(): this['Data'] {
    return null
  }
  get quickTypes() {
    enum Types {
      SUBMIT,
      SUBMIT_FAILED,
      SUBMIT_SUCCESS,
      TOGGLE_VALIDATION,
      TOGGLE_IF_VALIDATED,
      SET_DATA,
    }
    return {
      ...super.quickTypes,
      ...Types,
    }
  }
  get reducers() {
    const { types } = this
    return {
      ...super.reducers,
      /**
       * 校验是否通过
       */
      isValid: reduceFromPayload<boolean>(types.TOGGLE_VALIDATION, true),
      /**
       * 是否已首次校验
       */
      hasValidated: (state = false, action): boolean => {
        switch (action.type) {
          case types.TOGGLE_IF_VALIDATED:
            return action.payload
          case types.TOGGLE_VALIDATION:
            return true
          default:
            return state
        }
      },
      data: reduceFromPayload<this['Data']>(types.SET_DATA, this.defaultData),
      submitting: (state = false, action): boolean => {
        switch (action.type) {
          case types.SUBMIT:
            return true
          case types.SUBMIT_FAILED:
          case types.SUBMIT_SUCCESS:
            return false
          default:
            return state
        }
      },
    }
  }
  get creators() {
    const { types } = this
    return {
      ...super.creators,
      submit: () => ({ type: types.SUBMIT }),
      toggleValidation: createToPayload<boolean>(types.TOGGLE_VALIDATION),
      setHasValidated: createToPayload<boolean>(types.TOGGLE_IF_VALIDATED),
      setData: createToPayload<this['Data']>(types.SET_DATA),
    }
  }
  get rawSelectors() {
    type State = this['State']
    return {
      ...super.rawSelectors,
    }
  }
  get quickDucks() {
    return {
      ...super.quickDucks,
    }
  }
  get execValidateMethodType() {
    return []
  }

  *watchToExecValidate() {
    const duck = this
    const { types, execValidateMethodType, creators } = duck
    yield takeLatest(execValidateMethodType, function*() {
      yield call([duck, duck.onValidate])
    })
  }

  *sagaWatchToSubmit() {
    const duck = this
    const { ducks, types, selector, selectors, creators } = this

    yield takeLatest([types.SUBMIT], function*() {
      const isValid = yield call([duck, duck.onValidate])
      if (!isValid) {
        yield put({
          type: types.SUBMIT_FAILED,
          payload: 'isValid',
        })
        return
      }
      try {
        yield call([duck, duck.submit])
        yield put({
          type: types.SUBMIT_SUCCESS,
        })
      } catch (e) {
        yield put({
          type: types.SUBMIT_FAILED,
          payload: e,
        })
      }
    })
  }

  /**
   * 校验方法，供外界扩展
   */
  *validate(): any {
    return true
  }

  /**
   * 提交表单方法，供外界扩展
   */
  *submit(): any {}

  /**
   * 校验
   */
  *onValidate(): any {
    const duck = this
    const { creators, selector } = duck
    const { hasValidated } = selector(yield select())
    const isValid = yield call([duck, duck.validate])
    yield put(creators.toggleValidation(Boolean(isValid)))
    return Boolean(isValid)
  }

  *saga() {
    yield* super.saga()
    yield fork([this, this.sagaWatchToSubmit])
    yield fork([this, this.watchToExecValidate])
  }
}
