import { reduceFromPayload, createToPayload, asResult } from 'saga-duck'
import { select, put, call, take, fork, join } from 'redux-saga/effects'
import { delay } from 'redux-saga'
import { takeLatest, takeEvery, runAndTakeLatest } from 'redux-saga-catch'
import { app } from '@tencent/tea-app'
import { DetailPageDuck as Base, RegionDuck } from '@tencent/iaas-common/ducks'
import { OperationDuck, ExtraDataDuck } from '../index'
import WhiteListBaseDuck from '@tencent/iaas-common/ducks/WhiteList'

enum Types {
  FIRST_DATA_DONE,
  SWITCH_TAB,
}

let reloadCount = 0
export abstract class DetailPageDuck extends Base {
  /**
   * 点击流上报前置，基于baseUrl
   * 如 cvm.instance.detail.
   */
  get hotTagPrefix() {
    return this.baseUrl.split('/').join('.').substring(1) + '.'
  }
  /**
   * 上报点击流tag，已拼接前置路由
   * 如 cvm.instance.detail.${hotTag}
   * @param hotTag
   */
  reportHotTag(hotTag: string) {
    app.insight.reportHotTag(this.hotTagPrefix + hotTag)
  }
  get quickTypes() {
    return {
      ...super.quickTypes,
      ...Types,
    }
  }
  get reducers() {
    const { types } = this
    return {
      ...super.reducers,
      tab: reduceFromPayload<string>(types.SWITCH_TAB, null),
      /**
       * 是否首屏数据加载完毕
       */
      isFirstDataDone: (state = false, action): boolean => {
        switch (action.type) {
          case types.FIRST_DATA_DONE:
            return true
          default:
            return state
        }
      },
    }
  }
  get creators() {
    const { types } = this
    return {
      ...super.creators,
      switchTab: createToPayload<string>(types.SWITCH_TAB),
      updateData: createToPayload<this['Data']>(types.UPDATE),
    }
  }
  get rawSelectors() {
    type State = this['State']
    return {
      ...super.rawSelectors,
      composedId: (state: State): this['ComposedId'] => ({
        id: state.id,
        regionId: state.region.id,
      }),
    }
  }
  get whiteKeys() {
    return ['test']
  }

  get quickDucks() {
    const duck = this
    return {
      ...super.quickDucks,
      region: RegionDuck,
      whiteList: class WhiteListDuck extends WhiteListBaseDuck {
        get whiteKeys() {
          return duck.whiteKeys
        }
      },
      operation: OperationDuck,
      extraData: ExtraDataDuck,
    }
  }
  get params() {
    const { ducks, types } = this
    return [
      ...super.params,
      ducks.region.getRouteParam({
        key: 'regionId',
        route: 'rid',
        history: false,
        order: -1,
      }),
      {
        key: 'tab',
        defaults: 'basicInfo',
        type: types.SWITCH_TAB,
      },
      ducks.operation.getRouteParam(),
    ]
  }
  /**
   * 获取格式化后的详情页data数据
   */
  *getFormatedData() {
    const { selectors } = this
    return yield select(selectors.data)
  }

  /**
   * 更新子tab duck中的实例详情
   */
  *watchToUpdateTabDuckData() {
    const { types, selector, ducks } = this
    yield takeLatest([types.UPDATE], function* () {
      const { data, tab } = asResult(selector, yield select(selector))
      const tabDuck = ducks[tab]
      if (data && tabDuck && tabDuck.creators && tabDuck.creators.setData) {
        yield put(tabDuck.creators.setData(data))
      }
    })
  }
  /**
   * 切换详情页Tab，激活tab的ACTIVE事件
   * 由于url参数默认触发了一次SWITCH_TAB，当时还没有 data，当fetch_done时再触发一次，才算真正的active
   */
  *watchToSwitchTab() {
    const duck = this
    const { types, selector, ducks } = this
    yield takeLatest([types.FETCH_DONE, types.SWITCH_TAB], function* () {
      const { data, tab } = asResult(selector, yield select(selector))
      const tabDuck = ducks[tab]
      if (data && tabDuck && tabDuck.types && tabDuck.types.ACTIVE) {
        // 上报切换tab点击事件
        duck.reportHotTag('switchTab.' + tab)
        yield put({
          type: tabDuck.types.ACTIVE,
          payload: data,
        })
      }
    })
  }
  /**
   * 获取执行操作需要的额外数据，供子类重写
   */
  getExtraExecuteOperationParams(options: any) {
    return {}
  }
  /**
   * 监听点击了某个操作按钮。
   */
  *watchSelectOperation() {
    const duck = this
    const {
      creators,
      selector,
      types,
      ducks: { operation: operationDuck },
    } = duck
    yield takeLatest(operationDuck.types.SELECT_OPERATION, function* ({ payload }) {
      const {
        region: { id: regionId },
        operation: { selectedItems },
        whiteList,
      } = asResult(selector, yield select(selector))
      // 获取操作额外的参数，某些操作需要其他参数
      const extraExecuteOperationParams = yield call([duck, duck.getExtraExecuteOperationParams], {
        operationAction: payload.operationAction,
      })
      yield put(
        operationDuck.creators.execute({
          operationAction: payload.operationAction,
          params: {
            selectedItems,
            regionId,
            whiteList,
            ...payload.params,
            ...extraExecuteOperationParams,
          },
        })
      )
      duck.reportHotTag(
        `operation.${payload.operationAction}.${
          selectedItems.length ? (selectedItems.length === 1 ? 'single' : 'batch') : 'none'
        }`
      )
    })
  }
  *watchExecuteOperationFinished() {
    const duck = this
    const {
      creators,
      ducks: { operation: operationDuck },
    } = duck
    yield takeLatest(operationDuck.types.FINISH_OPERATION, function* ({ payload }) {
      if (payload) {
        const { options, action, desc, status } = payload
        if (status === 'SUCCESS' && options && options.refresh) {
          yield put(creators.reload())
        }
      }
    })
  }
  /**
   * 监听并格式化data
   */
  *watchFetchFormatedData() {
    const duck = this
    const {
      ducks: { extraData: extraDataDuck },
      creators,
    } = duck
    yield takeLatest([extraDataDuck.types.FETCH_DONE], function* () {
      const formatedData = yield call([duck, duck.getFormatedData])
      yield put(creators.updateData(formatedData))
    })
  }

  /**
   * 监听并获取列表额外数据
   */
  *watchFetchExtraData() {
    const duck = this
    const {
      ducks: { extraData: extraDataDuck },
      selector,
      types,
    } = duck
    yield takeLatest(types.FETCH_DONE, function* () {
      const {
        data,
        region: { id: regionId },
      } = asResult(selector, yield select(selector))
      if (data) {
        yield put({
          type: extraDataDuck.types.FETCH,
          payload: {
            list: [data],
            regionId,
          },
        })
      }
    })
  }
  get LoadingTimeInterval() {
    return 1000
  }
  /**
   * 用于包含操作中的实例轮询刷新，(列表有$loading态实例，则隔 LoadingTimeInterval 刷新一次)
   * 使用条件:
   * 定义$loading
   */
  *watchToRefreshLoadingItem() {
    const { types, selector, creators, LoadingTimeInterval } = this
    yield takeLatest([types.FETCH_DONE], function* () {
      const { data } = selector(yield select())
      const hasLoading = reloadCount < 50 && data && data.$isLoading
      /** 轮询 */
      if (hasLoading) {
        reloadCount++
        yield call(delay, LoadingTimeInterval)
        yield put(creators.reload())
      } else {
        reloadCount = 0
      }
    })
  }

  *saga() {
    const duck = this
    yield* super.saga()
    yield fork([duck, duck.watchToUpdateTabDuckData])
    yield fork([duck, duck.watchToSwitchTab])
    yield fork([duck, duck.watchSelectOperation])
    yield fork([duck, duck.watchExecuteOperationFinished])
    yield fork([duck, duck.watchFetchFormatedData])
    yield fork([duck, duck.watchFetchExtraData])
    yield fork([duck, duck.watchToRefreshLoadingItem])
  }
}
