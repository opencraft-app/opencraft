import { put, select, fork, call } from 'redux-saga/effects'
import { takeLatest, runAndTakeLatest } from 'redux-saga-catch'
import { DuckMap } from 'saga-duck'
import { reduceFromPayload, createToPayload } from 'saga-duck/helper'
import { AttributeValue } from '@tencent/tea-component/lib/tagsearchbox/AttributeSelect'
import { KVAttribute } from '@tencent/iaas-common/components/KVTagSearchBox'
import { t } from '@tencent/tea-app/lib/i18n'
import { PageParam } from '@tencent/iaas-common/ducks/Page'

export interface ISearchBoxFilterOption {
  name: string
  label: string
  value: any
  key?: any
}
export interface ISearchBoxValues {
  [key: string]: string[]
}
interface IAttribute extends Omit<KVAttribute<string, any>, 'values'> {
  values: any[]
}

export class SearchBoxDuck extends DuckMap {
  /** 外界Init传入的值 */
  InitialData: {}
  /** 标签过滤 key: values map */
  IFilterOptionMap: {}
  /** 标签值对应的 <=> 搜索参数 */
  ISearchParams: {
    [key: string]: any
  }
  /** 标签值 values 数组 */
  IValues: ISearchBoxValues
  IAttributeValues: IAttribute[]
  get quickTypes() {
    enum Types {
      INIT,
      ON_SEARCH,
      SET_ATTRIBUTES,
      SET_VALUES,
      UPDATE_VALUES,
      CLEAR_VALUES,
      SET_FILTER_OPTION_MAP,
      SET_SEARCH_PARAMS,
    }
    return {
      ...super.quickTypes,
      ...Types,
    }
  }

  get creators() {
    const { types } = this
    return {
      ...super.creators,
      setValues: createToPayload<this['IValues']>(types.SET_VALUES),
      onSearch: createToPayload<this['IValues']>(types.ON_SEARCH),
      updateValues: createToPayload(types.UPDATE_VALUES),
      init: createToPayload<this['InitialData']>(types.INIT),
      clearValues: () => ({
        type: types.CLEAR_VALUES,
      }),
    }
  }

  get reducers() {
    const { types } = this
    return {
      ...super.reducers,
      attributes: reduceFromPayload<this['IAttributeValues']>(types.SET_ATTRIBUTES, [
        { key: 'innerSearch', name: t('搜索值'), type: 'input' },
      ] as this['IAttributeValues']),
      filterOptionMap: reduceFromPayload<this['IFilterOptionMap']>(types.SET_FILTER_OPTION_MAP, {}),
      values: reduceFromPayload<this['IValues']>(types.SET_VALUES, {}),
      searchParams: reduceFromPayload<this['ISearchParams']>(types.SET_SEARCH_PARAMS, {}),
      initialData: reduceFromPayload<this['InitialData']>(types.INIT, {}),
    }
  }

  get rawSelectors() {
    const duck = this
    type State = this['State']
    return {
      ...super.rawSelectors,
      valueDesc: ({ values, attributes }: State): string => {
        return duck.stringify(values, attributes)
      },
      /** 路由数据格式为 */
      innerSearchStr: ({ values }: State): string =>
        values.innerSearch && values.innerSearch.join(','),
    }
  }
  /** 搜索预处理，可自定义 */
  public hanldSearchResult(values: this['IValues']): this['IValues'] {
    return values
  }
  public getFilterOptions(state: this['State']): this['IFilterOptionMap'] {
    return state.filterOptionMap
  }
  public getAttributes(state: this['State']): AttributeValue[] {
    return state.attributes
  }
  /** 搜索解析参数，传给后台用户查询数据 */
  public searchKeyValuesToParams(
    values: this['IValues'],
    data?: this['State']
  ): this['ISearchParams'] {
    return values
  }
  /**
   * 与RouteDuck配合时使用
   */
  public getRouteParam(selectedParams: Partial<PageParam>[] = []): PageParam<any>[] {
    const duck = this
    const { types, selectors, creators } = duck
    return [
      {
        key: 'keyword',
        route: 'keyword',
        history: false,
        order: -1,
        type: types.SET_VALUES,
        selector: selectors.innerSearchStr,
        creator: (str) =>
          creators.updateValues({
            innerSearch: str?.toString()?.split(','),
          }),
      },
    ]
  }
  /** 将搜索条件转成字符串 */
  stringify(values: this['IValues'], attributes: this['IAttributeValues']): string {
    return attributes
      .filter((attr) => {
        return (
          attr.searchNotify !== false && attr.key in values && attr.defaults !== values[attr.key]
        )
      })
      .map((attr) => {
        const value = values[attr.key]
        const label = 'searchLabel' in attr ? attr.searchLabel : attr.name
        let text = ''
        const type =
          Object.prototype.toString.call(attr.type) === '[object Array]' ? attr.type[0] : attr.type
        switch (type) {
          case 'input':
            text = value.join('|')
            break
          case 'single':
            text =
              attr.values &&
              attr.values
                .filter((a) => value === a.value)
                .map((o) => o.name)
                .join('|')
            break
          case 'multiple':
            text =
              attr.values &&
              attr.values
                .filter((a) => value.indexOf(a.value) > -1)
                .map((o) => o.name)
                .join('|')
            break
        }
        return label && text ? `${label}:${text}` : text
      })
      .join(';')
  }
  /**
   * 格式化 value值：
   * 1. (可选) 过滤掉 attributes 中不存在的值
   * 2. 删除 key: [] 和 key: undefined
   * @param values
   * @param attributes
   */
  private formatValues(
    values: this['IValues'],
    attributes?: this['IAttributeValues']
  ): this['IValues'] {
    let cloneValues
    if (attributes) {
      cloneValues = {}
      attributes.map((attr) => {
        const value = values[attr.key]
        cloneValues[attr.key] = value
      })
    } else {
      cloneValues = { ...values }
    }

    Object.keys(cloneValues).forEach((key) => {
      if (!cloneValues[key] || !cloneValues[key].length) {
        delete cloneValues[key]
      }
    })
    return cloneValues
  }
  /**
   * 校验value值是否变更
   * @param lastValues
   * @param values
   */
  private isValueDifferent(lastValues: this['IValues'], values: this['IValues']): boolean {
    const duck = this
    let lastFormatValues = duck.formatValues(lastValues)
    let formatValues = duck.formatValues(values)
    let isDifferent = false
    // 1. 比较选中字段长度
    if (Object.keys(formatValues).length !== Object.keys(lastFormatValues).length) {
      isDifferent = true
    }
    // 2. 比较每个字段数组
    for (const key in formatValues) {
      if (formatValues.hasOwnProperty(key)) {
        const v1 = formatValues[key]
        const v2 = lastFormatValues[key]

        // single类型，value是string
        if (typeof v1 === 'string') {
          if (v1 !== v2) {
            isDifferent = true
            break
          }
        } else {
          // multiple/input类型，value是Array<string>
          if (
            !v2 ||
            !v2.length ||
            v1.length !== v2.length ||
            JSON.stringify(v1.sort()) !== JSON.stringify(v2.sort())
          ) {
            isDifferent = true
            break
          }
        }
      }
    }
    return isDifferent
  }

  *saga() {
    const duck = this
    const { types, selectors, selector } = duck
    yield* super.saga()

    /** 根据state计算attributes**/
    yield runAndTakeLatest([types.INIT], function* () {
      let state = yield select(selector)
      yield put({
        type: types.SET_FILTER_OPTION_MAP,
        payload: duck.getFilterOptions(state),
      })
      state = yield select(selector)
      yield put({
        type: types.SET_ATTRIBUTES,
        payload: duck.getAttributes(state),
      })
    })
    yield takeLatest([types.ON_SEARCH], function* ({ payload }) {
      yield put({
        type: types.SET_VALUES,
        payload: duck.hanldSearchResult(payload),
      })
    })
    /**
     * 监听哪些值的变化会引起搜索结果变更
     * 1. values 值变化
     */
    yield takeLatest([types.SET_VALUES], function* ({ payload }) {
      let data = selector(yield select())
      yield put({
        type: types.SET_SEARCH_PARAMS,
        payload: duck.searchKeyValuesToParams(data.values, data),
      })
    })
    /**
     * 监听哪些值的变化会引起搜索结果变更
     * 2. attributes 变化，过滤掉 values 中不存在的 attribute
     */
    yield takeLatest([types.SET_ATTRIBUTES], function* ({ payload }) {
      const { values } = selector(yield select())
      const formattedValues = duck.formatValues(values, payload)
      // 性能优化，非变更 values 值不进行设定
      const hasValueChanged = duck.isValueDifferent(values, formattedValues)
      if (hasValueChanged) {
        yield put({
          type: types.SET_VALUES,
          payload: formattedValues,
        })
      }
    })
    /** 更新部分搜索值 */
    yield takeLatest([types.UPDATE_VALUES], function* ({ payload }) {
      const { values } = yield select(selector)
      const newValues = { ...values, ...payload }
      // 性能优化，非变更 values 值不进行设定
      const hasValueChanged = duck.isValueDifferent(values, newValues)
      if (hasValueChanged) {
        yield put({
          type: types.SET_VALUES,
          payload: duck.formatValues(newValues),
        })
      }
    })

    /** 清空搜索框 */
    yield takeLatest([types.CLEAR_VALUES], function* ({ payload }) {
      yield put({
        type: types.SET_VALUES,
        payload: {},
      })
    })
  }
}
