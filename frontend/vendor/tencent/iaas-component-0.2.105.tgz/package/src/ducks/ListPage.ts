import { asResult, createToPayload, reduceFromPayload } from 'saga-duck'
import { put, select, fork, call } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga-catch'
import { delay } from 'redux-saga'
import { app, i18n } from '@tencent/tea-app'
import WhiteListBaseDuck from '@tencent/iaas-common/ducks/WhiteList'
import BaseGridPage, {
  Result as BaseResult,
  Filter as BaseFilter,
} from '@tencent/iaas-common/ducks/GridPage'
import { SearchBoxDuck, RegionDuck, OperationDuck, ISearchBoxValues, ExtraDataDuck } from '../ducks'
/**
 * 默认列表每页最大数据条数
 */
export const DEFAULT_MAX_PAGE_COUNT = 50

let reloadCount = 0
/**
 * 单Grid页面 公共逻辑提取：
 * grid加载、搜索、翻页、过滤、额外数据加载
 */
export interface IListPageFilter extends BaseFilter {
  regionId: number
  searchParams: ISearchBoxValues
}

export abstract class ListPageDuck extends BaseGridPage {
  Filter: IListPageFilter
  /** 可设置等待白名单加载完成 */
  ready() {
    return true
  }
  /**
   * 点击流上报前置，基于baseUrl
   * 如/cvm/instance/index => cvm.instance.index.
   */
  get hotTagPrefix() {
    return this.baseUrl.split('/').join('.').substring(1) + '.'
  }
  /**
   * 上报点击流tag，已拼接前置路由
   * 如 cvm.instance.index.${hotTag}
   * @param hotTag
   */
  reportHotTag(hotTag: string) {
    app.insight.reportHotTag(this.hotTagPrefix + hotTag)
  }
  get params() {
    const {
      ducks: { region: regionDuck, operation: operationDuck },
    } = this
    return [
      ...super.params,
      regionDuck?.getRouteParam({
        key: 'regionId',
        route: 'rid',
        history: false,
        order: -1,
      }),
      operationDuck.getRouteParam(),
    ]
  }
  get quickTypes() {
    enum Types {
      ENABLE_SHOW_LOADING,
    }
    return {
      ...super.quickTypes,
      ...Types,
    }
  }
  get watchTypes() {
    const { ducks } = this
    // 不更新页码的 reload
    return [...super.watchTypes, ducks.region.types.SELECT]
  }
  get resetPageTypes() {
    const { ducks, types } = this
    return [types.SEARCH, ducks.region.types.SELECT]
  }
  get whiteKeys() {
    return ['test']
  }

  get quickDucks() {
    const duck = this
    return {
      ...super.quickDucks,
      region: RegionDuck,
      whiteList: class WhiteListDuck extends WhiteListBaseDuck {
        get whiteKeys() {
          return duck.whiteKeys
        }
      },
      searchBox: SearchBoxDuck,
      operation: OperationDuck,
      extraData: ExtraDataDuck,
    }
  }
  get reducers() {
    const { types } = this
    return {
      ...super.reducers,
      enableShowLoading: reduceFromPayload<boolean>(types.ENABLE_SHOW_LOADING, true),
    }
  }
  get creators() {
    const {
      types,
      ducks: { searchBox },
    } = this
    return {
      ...super.creators,
      /**
       * 覆盖父元素返回原列表
       */
      clearSearchCondition: () => ({ type: searchBox.types.CLEAR_VALUES, payload: '' }),
      setEnableShowLoading: createToPayload<boolean>(types.ENABLE_SHOW_LOADING),
    }
  }
  get rawSelectors() {
    type State = this['State']
    return {
      ...super.rawSelectors,
      filter: (state: State) => ({
        regionId: state.region.id,
        page: state.page,
        count: state.count,
        keyword: state.keyword,
        searchParams: state.searchBox.searchParams,
      }),
      regionId: (state: State) => state.region.id,
      columnOptions: (state: State): this['ColumnOptions'] => ({
        whiteListMap: state.whiteList,
      }),
    }
  }
  get maxPageSize() {
    return DEFAULT_MAX_PAGE_COUNT
  }
  /**
   * 获取格式化后的列表list数据
   */
  *getFormatedData() {
    const {
      ducks: { grid: gridDuck },
    } = this
    return yield select(gridDuck.selectors.list)
  }

  /**
   * 从列表获取执行操作需要的额外数据，供子类重写
   */
  *getExtraExecuteOperationParams(options: any): any {
    return {}
  }
  /**
   * 监听搜索框输入并搜索
   */
  *watchToSearch() {
    const {
      types,
      ducks: { searchBox: searchBoxDuck },
    } = this
    // /** 搜索的tag变化，触发搜索 */
    yield takeLatest([searchBoxDuck.types.SET_SEARCH_PARAMS], function* () {
      yield put({
        type: types.SEARCH,
        payload: searchBoxDuck.selectors.valueDesc(yield select()),
      })
    })
  }
  /**
   * 监听点击了某个操作按钮。
   * 放listpage这，是因为需要从列表拿一些数据，比如某些操作是没有选中项的，需要regionId，或白名单等
   */
  *watchSelectOperation() {
    const duck = this
    const {
      creators,
      selector,
      types,
      ducks: { region: regionDuck, operation: operationDuck, whiteList },
    } = duck
    yield takeLatest(operationDuck.types.SELECT_OPERATION, function* ({ payload }) {
      const {
        region: { id: regionId },
        operation: { selectedItems },
        whiteList,
      } = asResult(selector, yield select(selector))
      // 获取操作额外的参数，某些操作需要其他参数
      const extraExecuteOperationParams = yield call([duck, duck.getExtraExecuteOperationParams], {
        operationAction: payload.operationAction,
      })
      yield put(
        operationDuck.creators.execute({
          operationAction: payload.operationAction,
          params: {
            selectedItems,
            regionId,
            whiteList,
            ...payload.params,
            ...extraExecuteOperationParams,
          },
        })
      )
    })
  }
  /**
   * 监听并格式化列表
   */
  *watchFetchFormatedData() {
    const duck = this
    const {
      ducks: { grid: gridDuck, extraData: extraDataDuck },
      selector,
      types,
    } = duck
    yield takeLatest([extraDataDuck.types.FETCH_DONE], function* () {
      const formatedList = yield call([duck, duck.getFormatedData])
      yield put(gridDuck.creators.updateList(formatedList))
    })
  }
  /**
   * 监听并获取列表额外数据
   */
  *watchFetchExtraData() {
    const duck = this
    const {
      ducks: { grid: gridDuck, extraData: extraDataDuck },
      selector,
    } = duck
    yield takeLatest(gridDuck.types.FETCH_DONE, function* () {
      const {
        grid: { list },
        region: { id: regionId },
      } = asResult(selector, yield select(selector))
      if (list?.length) {
        yield put({
          type: extraDataDuck.types.FETCH,
          payload: {
            list,
            regionId,
          },
        })
      }
    })
  }
  *watchExecuteOperationFinished() {
    const duck = this
    const {
      creators,
      selector,
      types,
      ducks: { operation: operationDuck },
    } = duck
    yield takeLatest(operationDuck.types.FINISH_OPERATION, function* ({ payload }) {
      if (payload) {
        const { options, action, desc, status } = payload
        if (status === 'SUCCESS' && options && options.refresh) {
          yield put(creators.setEnableShowLoading(true))
          yield put(creators.reload())
        }
      }
    })
  }
  get LoadingTimeInterval() {
    return 1000
  }

  /**
   * 用于包含操作中的实例轮询刷新，(列表有$loading态实例，则隔 LoadingTimeInterval 刷新一次)
   * 使用条件:
   * 定义$loading
   */
  *watchToRefreshLoadingItems() {
    const {
      types,
      selector,
      creators,
      ducks: { grid },
      LoadingTimeInterval,
    } = this
    yield takeLatest([grid.types.FETCH_DONE], function* () {
      const {
        grid: { list },
      } = selector(yield select())
      const hasLoading = reloadCount < 50 && list.find((item) => item.$isLoading)
      /** 轮询 */
      if (hasLoading) {
        reloadCount++
        yield call(delay, LoadingTimeInterval)
        yield put(creators.reload())
      } else {
        reloadCount = 0
      }
      yield put(creators.setEnableShowLoading(!hasLoading))
    })
  }

  *saga() {
    yield* super.saga()
    const duck = this
    yield fork([duck, duck.watchToSearch])
    yield fork([duck, duck.watchSelectOperation])
    yield fork([duck, duck.watchFetchFormatedData])
    yield fork([duck, duck.watchExecuteOperationFinished])
    yield fork([duck, duck.watchToRefreshLoadingItems])
  }
}
