interface IConfigCvm {
  deviceTypeList: {
    cvmType: string;
    icon: string;
    instanceFamily: string;
    key: string;
    name: string;
    payMode: any[];
    showInMenu: number;
    showPrio: number;
    tip: string;
    type: string;
    typeName: string;
    typeNameEn: string;
    value: string;
    whiteListKey: string;
  }[];
  diskCategory: {
    cloud: number[];
    local: number[];
  };
  diskTypeList: {
    category: string;
    diskType: string;
    name: string;
    storageType: string;
    value: number;
  }[];
  instanceTypeList: {
    cpu: number;
    deviceClass: string;
    fpga: number;
    gpu: number;
    instanceFamily: string;
    instanceType: string;
    localDiskTypeList: {
      maxSize: number;
      minSize: number;
      partitionType: string;
      type: string;
    }[];
    mem: number;
    networkCard: number;
    prepayEnable: number;
    quotiesEnable: number;
    status: number;
    storageBlock: number;
    whiteListKey: string;
    zoneId: number;
  }[];
  regionMap: {
    area: string;
    code: string;
    icon: string;
    isDefault: boolean;
    name: string;
    order: number;
    oversea: number;
    payMode: string[];
    regionId: string;
    tip: string;
    whiteList: string;
    value: number;
  }[];
  zoneList: {
    [key: number]: {
      [key: number]: {
        apply: any;
        applyTip: any;
        area: string;
        code: string;
        icon: string;
        id: string;
        isDefault: number;
        name: string;
        offline: number;
        order: number;
        payMode: string[];
        tip: string;
        whiteList: string;
        zoneId: string;
      };
    };
  };
}
