interface DefineInterface {
  (id: string, factory: (require: nmc.Require, exports, module) => any): any
}

declare namespace Mock {
  export var mock: Function
}
