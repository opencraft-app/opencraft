declare interface Window {
  seajs: typeof seajs
  Mock: typeof Mock
  // RFB: typeof RFB
  // Util: typeof Util
  QCBUY_HOST: string
  QCBASE_HOST: string
  QCCDN_HOST: string
  QCCONSOLE_HOST: string
  QCMAIN_HOST: string
  ftCloudRegions:{
    id: string
    region: string
    regionName: string
    regionNameEn: string
    regionPrefix: string
    zoneList: {
      zoneId: string
      zoneName: string
    }[]
  }[]
  autoDrivingCloudRegions:{
    id: string
    region: string
    regionName: string
    regionNameEn: string
    regionPrefix: string
    zoneList: {
      zoneId: string
      zoneName: string
    }[]
  }[]
  getLifeInfo: () => { lid: string; life: number }
  userAgentFromServer: {
    device: {
      family: 'Other'
      major: '0'
    }
    family: string
    major: string
    os: {
      family: string
      major: string
    }
  }
}
