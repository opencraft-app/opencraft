# Tea App

[![版本](https://mirrors.tencent.com/mirrors/api/npm/package/badge?package_name=@tencent/tea-app)](https://mirrors.tencent.com/#/private/npm/detail?repo_id=537&project_name=%40tencent%2Ftea-app)

---

`@tencent/tea-app` 为接入腾讯云控制台的业务提供下面两个能力：

- 向控制台注册业务模块入口
- 为业务模块提供控制台接口调用

## 开始使用

业务应优先考虑接入 tea 框架，获取完整的开发服务配套，点击[这里开始](http://tapd.oa.com/tcp_access/markdown_wikis/view/#1020399462008761129)。

如果业务出于**特殊情况**，需要单独使用，可独立安装此包：

```
npm i @tencent/tea-app --registry=https://mirrors.tencent.com/npm/
```

为了可以通过 `@tea/app` 导入，需要在编译的 Webpack 配置中指定 alias（使用 Tea 框架生成的，无需关注）：

```js
{
  alias: {
    "@tea/app": path.resolve(APP_ROOT, "./node_modules/@tencent/tea-app"),
  }
}
```

## 模块入口注册

使用 `app.routes()` 注册指定路由的模块入口。

```js
import { app } from '@tea/app';

app.routes({
  'cvm': CvmIndexPage,
  'cvm/list': CvmListPage,
  'cvm/detail': CvmDetailPage,
});
```

- 前两级路由需通过该方法注册
- 两级以上的路由需要使用模块内部路由，请参考[这篇文章](http://tapd.oa.com/tcp_access/markdown_wikis/view/#1020399462008691883)。

## 路由

### 模块内路由

使用 `@tencent/tea-app` 提供的 `history` 配合 React Router 进行模块内部路由：

```jsx
import React from 'react';
import { Router, Route, Link } from 'react-router-dom';
import { useHistory } from '@tea/app';
import { CvmDetailInstance } from './components';
export function CvmDetail() {
  // 此处为 React Hooks，只能在 Function Component 中使用
  const history = useHistory();
  return (
    <Router history={history}>
      <div>
        <Link to="/cvm/detail/ins-1q2w3e4r">ins-1q2w3e4r</Link>
        <Route path="/cvm/detail/:instanceId" component={CvmDetailInstance}></Route>
      </div>
    </Router>
  );
}
```

#### 提示

如 SDK 内需要使用 history，无法从 useHistory 获得，需要从业务调用处传入

### 监听/阻止路由跳转（模块销毁）

> 需要 `^2.0.11` 版本

使用 `useBeforeDestroy()` 钩子可以监听路由跳转或页面销毁，并可阻止该行为：

  - 如果监听函数返回字符串，则弹出确认框确认是否执行跳转（销毁）行为。
  - 如果监听函数返回 false，则会阻止跳转（销毁）行为。

```js
import { useBeforeDestroy } from '@tea/app';

function Component() {
  useBeforeDestroy(({ type, url }) => {
    return "确认离开当前页面？";
    // return 字符串时将弹出确认框：是（跳转）/否（阻止跳转）
    // return false 时将阻止跳转逻辑
  }, []);
  return <div>Component</div>
}
```

详细 API 请参考 [beforeDestroy.ts](https://git.woa.com/tea-design/tea2/blob/master/tea-app/src/core/beforeDestroy.ts)

## 用户信息

### 属性（`@2.0.3` 版本加入）

> 不建议将前端直接获取的 Uin 等信息作为参数传递给后端接口，可能会产生账号切换时信息实时性和安全问题

```js
const { loginUin } = app.user;
```

下列用户信息相关属性可直接在 `app.user` 中获取：

```ts
interface GlobalUserInfo {
  /** 是否为主账号 */
  isOwner: boolean;
  /** 当前用户登录的 UIN */
  loginUin: number;
  /** 当前用户登录的主账号 UIN */
  ownerUin: number;
  /** 当前用户登录的主账号 APPID */
  appId: number;
  /** 当前用户的实名认证信息，如果未实名认证，此字段为 null */
  identity: AppUserIdentityInfo | null;
  /** 注册国家名称 */
  countryName: string;
  /** 注册国家代码 */
  countryCode: string;
  /** 当前用户所在站点 `1`-国内站 `2`-国际站 */
  area: 1 | 2;
}
```

### `app.user.current()`

异步获取当前用户信息。

```js
const user = await app.user.current();
```

用户信息数据结构如下：

```ts
export interface AppUserData {
  /** 是否为主账号 */
  isOwner: boolean;

  /** 当前用户登录的 UIN */
  loginUin: number;

  /** 当前用户登录的主账号 UIN */
  ownerUin: number;

  /** 当前用户登录的主账号 APPID */
  appId: number;

  /** 当前用户的实名认证信息，如果未实名认证，此字段为 null */
  identity: AppUserIdentityInfo | null;

  /** @deprecated 字段含义不明确，建议不再使用，改用 displayName 或者 ownerDisplayName */
  nickName?: string;

  /** 用户标识名称，含开发商信息 */
  displayName?: string;

  /** 子账号登录情况下，对应主账号的昵称（不含子账号昵称信息） */
  ownerDisplayName?: string;
}
```

### `app.user.getAntiCSRFToken()`

获取当前登录用户的反 CSRF 凭据，用于网络请求中防御跨站脚本攻击。

### `app.user.getSessionHash()`

获取会话唯一标识。


### `app.user.isFtCloudUser()`

判断是否为金融云用户。

### `app.user.checkWhitelist(key: string, fieldType?: 'ownerUin' | 'appid' | 'loginUin')`

异步检查用户是否在指定的白名单中，默认使用 `'ownerUin'`。

**注意**：这个方法不会缓存白名单查询结果，如果不想重复查询，业务请自行缓存。

```js
// 如在白名单内，返回当前 ownerUin，否则返回 0
const ownerUin = await app.user.checkWhitelist('CLB_NEW_CONSOLE');
if (ownerUin) {
  // ...白名单操作
}

// 改变第二个参数可以指定根据 appid 查询，如在白名单内，返回当前 appid，否则返回 0
const appid = await app.user.checkWhitelist('CLB_NEW_CONSOLE', 'appid');
```

### `app.user.checkWhitelistBatch(keys: string[], fieldType?: 'ownerUin' | 'appid' | 'loginUin')`

批量检查用户是否在指定的白名单中，默认使用 `'ownerUin'`。

**注意**：这个方法不会缓存白名单查询结果，如果不想重复查询，业务请自行缓存。

```js
const keys = ['CLB_NEW_CONSOLE', 'CLB_NEW_CONSOLE2'];
const result = await app.user.checkWhitelistBatch(keys);
const [k1, k2] = keys;
if (result[k1] || result[k2]) {
  // 命中任意白名单
}
```

### `app.user.hasLastRegionId()`

是否存在用户最后使用的 regionId

### `app.user.getLastRegionId()`

获取用户最后使用的 regionId

- 该数据基于用户当前的 ownerUin 存储在 localStorage 中
- 基于上一点，该数据可能会被其它业务修改，所以使用前应该先校验合法性

### `app.user.setLastRegionId()`

设置用户最后一次访问的 regionId，该数据可以被其它业务使用。

### 项目相关接口

** 重要：为了规范资源管理模式，新产品不再支持项目的接入。请使用标签能力进行资源管理，参考指引：http://km.oa.com/group/19368/docs/show/189661 **

如果你是老业务，需要参考接口信息，请单独联系 techirdliu。

### `app.user.login()`

清除用户当前登录态，并弹出登录对话框。

### `app.user.logout()`

清除用户当前登录态。

### `app.user.on("invalidate", callback)`

用户登录态失效时触发：

```js
app.user.on("invalidate", (event) => {
  console.log(event);
});
```

其中 `event` 参数结构如下：

```ts
interface InvalidateEventArgs {
  source: "accountChanged" | "logout";
}
```
## 云 API 请求{#capi}

> [如何查询控制台地域列表](http://tapd.oa.com/CVM_document/markdown_wikis/view/#1010127391011553601)

> [控制台测试、预发环境说明](http://tapd.oa.com/tcp_access/markdown_wikis/show/#1220399462000786341)

> **`⚠️ 以下方法通过控制台框架请求云 API，包体大小限制为 600KB`**

> **`⚠️ 注意：控制台不再支持云api v2调用，capi.request 方法禁止使用，推荐使用requestV3`**

如果云 API 已经在公有云发布，推荐使用 `app.capi.requestV3Public` 方法来调用，基于 `tencentcloud-sdk-nodejs` 支持入参出参的类型。使用前可更新该 SDK 至最新版本（只引用了类型，不会被打包至产物）：

```
npm install tencentcloud-sdk-nodejs -D
```
方法签名：`app.capi.request(body:RequestBody, options:RequestOptions): Promise<any>`

其中，`body` 和 `options` 参数结构如下：

> [如何查询控制台地域列表](http://tapd.oa.com/CVM_document/markdown_wikis/view/#1010127391011553601)

```ts
interface RequestBody {
  /**
   * 请求的云 API 地域
   */
  regionId: number;

  /**
   * 请求的云 API 业务
   */
  serviceType: string;

  /**
   * 请求的云 API 名称
   */
  cmd: string;

  /**
   * 请求的云 API 数据
   */
  data?: any;
}

interface RequestOptions {

  /**
   * 是否使用安全的临时密钥 API 方案，建议使用 true
   * @default true
   */
  secure?: boolean;

  /**
   * 使用的云 API 版本，该参数配合 secure 使用
   *
   *   - `secure == false`，该参数无意义
   *   - `secure == true && version = 1`，将使用老的临时密钥服务进行密钥申请，否则使用新的密钥服务
   *   - `secure == true && version = 3`，使用云 API v3 域名请求，不同地域域名不同
   */
  version?: number;

  /**
   * 是否将客户端 IP 附加在云 API 的 `clientIP` 参数中
   * @deprecated
   */
  withClientIP?: boolean;

  /**
   * 是否将客户端 UA 附加在云 API 的 `clientUA` 参数中
   */
  withClientUA?: boolean;

  /**
   * 公共参数是否包含语言（Language 字段）
   * 如果设置为 true，则 Language 取值为控制台当前语言
   * @default false
   */
  withLanguage?: boolean;

  /**
   * 是否在顶部显示接口错误
   * 默认为 true，会提示云 API 调用错误信息，如果自己处理异常，请设置该配置为 false
   */
  tipErr?: boolean;

  /**
   * 请求时是否在顶部显示 Loading 提示
   * 默认为 true
   */
  tipLoading?: boolean;

  /**
   * 禁用非中文站点下接口数据自动翻译
   * @default false
   */
  disableTranslate?: boolean;

  /**
   * 接入层到云api调用是否使用json模式
   * 控制台默认不支持空数组作为参数传递，如需传递空数组，请增加此设置为 true 即可
   */
  json?: boolean;

  /**
   * 前端事务进行跟踪的请求头 X-TC-TraceId
   *
   * - 需满足标准uuid的正则 ` ^(\\w{8}(-\\w{4}){3}-\\w{12}?)`
   * 例如：958cccac-ab2a-dcfe-6fc4-1456f8ddc3a9
   */
  traceId?: string;

  /**
   * 数据传输过程是否启用gzip压缩
   */
  enableZip?: boolean;
}
```

调用云 API，会包含出入参的参数检查和代码提示：

> 需要 `^2.1.0` 版本

```js
const response = await app.capi.requestV3Public({
  regionId: 1,
  serviceType: 'cvm',
  cmd: 'DescribeInstance',
  data: { Version: '2017-03-12', Offset: 0, Limit: 20 }
});
```

对于未发布到公有云的接口，请求云 API v3 可使用 `app.capi.requestV3` 方法：

```js
const response = await app.capi.requestV3({
  regionId: 1,
  serviceType: 'cvm',
  cmd: 'DescribeInstance',
  data: { Version: '2017-03-12', Offset: 0, Limit: 20 }
}, {
  tipErr: false,
  tipLoading: false,
  json: true
});
```

**`请求 V2 云 API 接口已废弃，禁止使用`**：

```js
const response = await app.capi.request({
  regionId: 1,
  serviceType: 'cvm',
  cmd: 'DescribeInstance',
  data: { Offset: 0, Limit: 20 }
}, {
  version: 3
});
```




## 大容量云 API 请求

大容量云 API 请求是指在实现普通云 API 请求的基础上，支持更长的超时、更大的包体，适用于对接口耗时比较长、包体积比较大的场景，但会降低用户的体验，请求业务按需使用。

> 1、需要安装 @tencent/tea-app@^2.1.22版本
>
> 2、使用大容量云 API 请求有任何问题请联系接口人：@ruchocliu、@jasonzqchen

### `app.capi.requestV3()`

需添加 `highCapacity: true` 选项，其余配置选项请看[对应部分](#capi)

专门为 **`接口耗时高（超过 15s）`** 、 **`请求包体积比较大（超过 600K）`** 、 **`响应包体积更大（超过 10M）`** 的接口提供

大容量集群支持最多 **60s** 的超时以及最大 **10M** 的请求包体
```js
const response = await app.capi.requestV3({
  regionId: 1,
  serviceType: 'cvm',
  cmd: 'DescribeInstance',
  data: { Version: '2017-03-12', Offset: 0, Limit: 20 }
}, {
  tipErr: false,
  tipLoading: false,
  highCapacity: true  // 启用大容量请求支持
});
```

如无必要请尽量使用[普通的接口](#capi)，大容量集群的稳定性优先级低于一般集群

对于 `app.capi.requestV3Public()` 也支持 `highCapacity: true` 选项

### `app.capi.batchRequest()`

批量调用云 API 

使用示例

```js
const allResponse = app.capi
	.batchRequest([
		{
			serviceType: 'cam',
			cmd: 'DescribeUserAnalysisReportCheck',
			data: {
				Version: '2019-01-16',
				Type: 1,
			},
			regionId: 1,
		},
		{
			serviceType: 'account',
			cmd: 'DescribeCurrentUserDetails',
			data: {
				Version: '2018-12-25',
			},
			regionId: 1,
		},
	])
	.map(async (promise, index) => {
		try {
			const response = await promise;
			console.log('response: ', response, index);
			return response;
		} catch (err) {
			console.log('err: ', err, index);
		}
	});
await Promise.all(allResponse);
console.log('all request done.');
```

### `app.capi.generateSseRequest()`

只提供云 API [SSE](https://developer.mozilla.org/en-US/docs/Web/API/Server-sent_events/Using_server-sent_events) 请求的相关数据

请自行选择合适的方式发送 SSE 请求，推荐使用 [fetch-event-stream](https://www.npmjs.com/package/fetch-event-stream)

> 原推荐 @microsoft/fetch-event-source 现已不推荐使用，因为该包无论请求成功与否都会 AbortRequest，会导致控制台上报日志失败，且该包本身就已多年未更新

```js
const info = app.capi.generateSseRequest({
  serviceType: "hunyuan",
  cmd: "ChatStd",
  data: {
    Messages: [
      {
        Role: "user",
        Content: t("介绍下自己"),
      },
    ],
    Version: "2023-09-01",
  },
  regionId: 1,
});

console.log("sse prepareInfo: ", info);

const { url, method, headers, body } = info;
// 发起请求
const res = await fetch(url, {
  method,
  headers,
  body,
  mode: "cors",
  credentials: "include",
});

if (res.ok) {
  const stream = events(res);
  console.log("sse message: ", msg);
  for await (const event of stream) {
    console.log("<<", event.data);
  }
}

console.log("sse over");
```

## MFA

### `app.mfa.verify()`

校验 MFA：调用敏感接口前，需要调用 MFA 让用户完成认证。

```js
// 发起 MFA 校验
const mfaPassed = await app.mfa.verify('cvm:DestroyInstance');

if (!mfaPassed) {
  // 校验取消，跳过后续业务
  return;
}

// 校验完成，调用云 API
const result = await app.capi.request({
  serviceType: 'cvm',
  cmd: 'DestroyInstance',
  // ...
});
```

### `app.mfa.request()`

校验 MFA 后调用云 API，使用 `app.mfa.request()` 具备失败重新校验的能力。

```js
const result = await app.mfa.request({
  regionId: 1,
  serviceType: 'cvm',
  cmd: 'DestroyInstance',
  data: {
    instanceId: 'ins-a5d3ccw8c'
  }
}, {
  onMFAError: error => {
    // 碰到 MFA 的错误请进行重试逻辑，业务可以自己限制重试次数
    return error.retry();
  }
})
```

> 注意：*如果已经使用了 `app.mfa.verify()` 方法进行 MFA 校验，则无需再使用该方法发起 API 请求，直接使用*


## 时区

### API

```js

const time = {
  /**
   * 注意：此时的入参为北京时间，或北京时间构造的moment or date对象
   * @param t 北京时间的入参数
   * @returns 基于北京时间的moment对象
   */
  fromBJTime: (t?: MomentInput) => Time,

  /**
   * 传递的参数默认为本地时间，此时可以直接使用moment
   * @param t 本地时间的入参
   * @returns 基于用户本地时间的moment对象
   */
  fromLocalTime: (t?: MomentInput) => Time,

  /**
   * 参数为时间戳或者utc时间的情况
   * @param t 时间戳 | utc时间
   * @returns 带时区的moment对象
   */
  from: (t?: MomentInput) => Time,

  /**
   * 设置语种
   * @param l zh|en|ko|jp
   */
  setLang: (l: string) => void,
}

// 具体使用的时间类
class Time {
  /**
   * 获取当前使用的moment对象
   * @returns Moment
   */
  getMoment: () => Moment;

  /**
   * 返回标准时间，不带语种参数，默认为zh格式。
   * @param withTZ: boolean 是否携带时区
   * @example
   * zh: 2023-11-30 07:00:00 (UTC-05:00)
   * en: Nov 30, 2023 07:00:00 (UTC-05:00)
   * @returns string
   */
  getFullTime: (withTZ?: boolean) => string;

  /**
   * 获取当前用户系统的基于UTC标准的时区偏移
   * @example UTC-05:00
   * @returns string
   */
  getOffset: () => string;

  /**
   * 获取当前用户系统的时区标志
   * @example America/New_York
   * @returns string
   */
  getTimeZone: () => string;

  /**
   * 将用户时区统一转换为UTC标准时间，用于参数传递
   * 注意，此时接受的时间参数为用户当前系统的时区时间
   * 默认不带时区标志的入参都为北京时间
   * @example 2023-11-30T12:00:00Z
   * @returns string
   */
  toUTC: () => string;

  /**
   * 将用户时区转换为时间戳，用于参数传递
   * 注意，此时接受的时间参数为用户当前系统的时区时间
   * @example 1701392400000
   * @returns number
   */
  toValue: () => number;
}
```

### 示例

```js
import { app } from '@tencent/tea-app';

/**
 * 首先确认startTime为北京时间还是用户系统的时间
 * 以下结果均在America/New_York时区输出
 */
const startTime = '2023-11-30 20:00:00';

// (不建议)若不需要在英文环境使用英文的日期格式，可setLang为zh，全局生效
// app.time.setLang('en');

// 若确认startTime为用户系统时间(此时认为是New_York时区)
const localT = app.time.fromLocalTime(startTime);

// 若确认startTime为北京时间，建议使用fromBJTime
const bjT = app.time.fromBJTime(startTime);

// 若是utc时间或者时间戳，建议使用from方法
const stampT = app.time.from(1701345600000);

/** 以下用北京时间做例子 **/
// 标准转换
localT.getFullTime();
// output
// zh: 2023-11-30 07:00:00
// en: Nov 30, 2023 07:00:00

// 带时区标志
localT.getFullTime(true);
// output
// zh: 2023-11-30 07:00:00 (UTC-05:00)
// en: Nov 30, 2023 07:00:00 (UTC-05:00)

// 获取时区偏移
localT.getOffset();
// output UTC-05:00

// 获取时区标志
localT.getTimeZone();
// output America/New_York

// 获取UTC标准时间
// 此时入参的时间默认为用户当前系统的时间
localT.toUTC();
// output 2023-11-30T12:00:00Z

// 获取时间戳
// 此时入参的时间默认为用户当前系统的时间
localT.toValue();
// output 1701345600000

// 可以返回moment对象
// 已将入参的非utc标准北京时间，转换成了utc+8的时间
// 可认为该moment对象为moment("2023-11-30T20:00:00+08:00")
const moment = bjT.getMoment();
moment.format(); // 2023-11-30T07:00:00-05:00
moment.valueOf(); // 1701345600000

// 通过fromLocalTime()返回的moment为本地时间构造，未作任何处理
const localMoment = localT.getMoment();
```

## 顶部提示

`tips` 下包含 `success`、`error` 和 `loading` 方法，每个方法都支持两种传参方式。

### 成功提示

#### API

`duration` 默认值 4000ms

```
app.tips.success(message, duration?);
```
```
app.tips.success({ message, duration? });
```

#### 示例

```js
app.tips.success('操作成功');
```

### 错误提示

#### API

`duration` 默认值 4000ms

```js
app.tips.error(message, duration?, context?: TipsErrorContextData);
```
```js
app.tips.error({ message, duration?, context? });
```

#### 属性

```js
interface TipsErrorContextData {
  // 业务
  service?: string;
  // 接口
  action?: string;
  // 错误码
  errorCode?: string;
  // 控制台请求 ID
  reqId?: string;
  // 云 API 请求 ID
  capiRequestId?: string;
  // 接口耗时时间，单位：ms
  cost?: number;
  // 业务自定义原因，notification footer 优先显示业务自定义原因
  reason?: string;
  // 请求 ID，使用扩展域名（如：workbench.cloud.tencent.com）的场景
  exReqId?: string;
  // 接口地址，使用扩展域名（如：workbench.cloud.tencent.com）的场景
  exUrl?: string;
}
```

#### 示例

```js
app.tips.error('操作失败');
```

### loading 提示

`loading` 可使用其返回值中的 `stop` 方法手动停止提示。

**注意：当前 loading 提示持续不会超过 `5000ms`，超时后自动销毁。**

#### API

`message` 默认值 `"正在加载..."`（已处理国际化）

`duration` 默认值 `4000ms`

```
app.tips.loading(message?, duration?);
```
```
app.tips.loading({ message?, duration? });
```

#### 示例

```js
app.tips.loading();
```

```js
async function someAsyncTask() {
  const loadingTip = app.tips.loading({ duration: 5000 });

  try {
    await doAsyncTask();
  } catch (err) {
  } finally {
    loadingTip.stop();
  }
}
```

## 地域选择

平台提供了统一的 `地域选择器` 及 `地域信息获取方式`，详见 [文档](http://tapd.oa.com/tcp_access/markdown_wikis/show/#1220399462002140419)。


## 数据上报

> [数据上报说明](http://tapd.oa.com/tcp_access/markdown_wikis/#1020399462011479313)

> **注意**：上报只会在现网环境（非预览模式）下被执行。

由于上报数据占用 Insight 集群的存储/计算资源，当前采取下面的策略限制资源：

- 10 秒内调用次数不能超过 10 条，超过的部分丢弃并且控制台输出告警（最多输出一次）
- 10 秒内调用次数如果超过 100 条，则后续所有上报全部丢弃，预防不小心的高频上报


### 点击流上报

主动上报：

```js
app.insight.reportHotTag("xxx.yyy.zzz")
```

或设置 `data-hot` 属性至点击元素（只支持 a 标签）：

```html
<a data-hot="xxx.yyy.zzz">链接</a>
```

统计数据可在 http://yehe.isd.com/console-insight/hottag 查询

### 自定义上报

自定义上报限制：

- 总字段个数（`stringFields` + `integerFields`）不能超过 20 个
- 字符串字段的长度，不能超过 4096

#### 事件上报

```js
app.insight.stat({
  ns: 'cvm',
  event: 'restart',
  stringFields: {
    instance: 'ins-1d7x8C3s'
  },
  integerFields: {
    instanceCount: 1
  }
});
```

上报流水可以在 [Kibana](http://kibana.qcloud.woa.com/goto/638d65b86323684afcc2fa9023cf94ea) 查询，请自行修改 `d.ns` 和 `d.stat` 条件。

### 任务上报

上报任务适合需要统计任务成功率和耗时的场景。

```js

const cvmRestartStat = app.insight.statTask('cvm-restart', 'cvm', 15000);
try {
  await performCvmRestart(instanceIds);
    // 上报成功，可以附带 int 和 string 变量
  cvmRestartStat.success({
    stringFields: {
      instance: instanceIds.join(';'),
    },
    integerFields: {
      instanceCount: instanceIds.length,
    }
  });
} catch(error) {
  // 失败可以上报 stack
  cvmRestartStat.fail({
    stack: error?.stack
  });
}
```

上报流水可以在 [Kibana](http://kibana.qcloud.woa.com/goto/638d65b86323684afcc2fa9023cf94ea) 查询，请自行修改 `d.ns` 和 `d.stat` 条件。对于任务上报，可以从 `d.cost` 看到任务耗时。

### 首屏上报

特别的，控制台业务都应该上报首屏渲染任务，该任务应该在组件开始渲染时创建，数据完成加载，用户可操作性时上报。推荐使用 Hooks 完成上报：

```js
import { usePageReadyStat } from '@tencent/tea-app';
function MyPage() {
  const pageReady = usePageReadyStat();

  return (
    <MyPageContent
      onSuccess={pageReady.success}
      onFail={pageReady.fail}
    />
  );
}

```

如果是 Class 组件不能使用 React Hooks，则参考下列用法：

```ts
import { app } from '@tencent/tea-app';
class MyClassPage extends React.Component {
  private pageReady = app.insight.statPageReady();

  componentDidMount() {
    // ...
    // your data load and render logic
    // ...

    // 组件渲染成功，调用 success，否则调用 fail
    if (this.isPageSuccess()) {
      this.pageReady.success();
    } else {
      this.pageReady.fail();
    }
  }

  componentWillUnmount() {
    // 组件可能会在渲染完成前离开，要调用 abort()
    this.pageReady.abort();
  }
}
```

上报流水可以在 [Kibana](http://kibana.qcloud.woa.com/goto/ae6b78fbe3398c70fd9f2145672438b5) 查询，请自行修改 `d.path` 或 `d.productId` 查看自己产品的数据。

## SDK

2019 年 4 月份开始，控制台正式支持 SDK 的接入，详情请参考[此文档](http://tapd.oa.com/tcp_access/markdown_wikis/view/#1020399462008859945)。

### 注册 SDK

对于使用 `tea-cli` 生成的项目，下面的使用代码会自动生成：

```js
app.sdk.register('demo-sdk', () => {
  // SDK 导出的方法
  return {
    hello() {
      console.log('Hello from demo-sdk');
    }
  }
});
```

### 引用 SDK

使用 `app.sdk.use(sdkName)` 引用在控制台已经登记的 SDK：

```js
try {
  const demoSDK = await app.sdk.use('demo-sdk');
  demoSDK.hello();
}
catch (err) {
  console.error('加载 SDK 失败：' + err.message);
}
```

### 组件中引用 SDK

`@2.0.6`

使用 `app.sdk.SDKLoader` 在组件中引用 SDK：

```jsx
import { SDKLoader } from "@tencent/tea-app";
import { LoadingTip, ErrorTip } from "@tencent/tea-component";

function Page() {
  return (
    <SDKLoader
      sdkNames={["demo-sdk"]}
      loading={<LoadingTip />}
      error={(error, retry) => <ErrorTip onRetry={retry} />}
    >
      {([demoSDK]) => <Content sdk={demoSDK} />}
    </SDKLoader>
  );
}

function Content({ sdk }) {
  // SDK 导出的 hook 及组件可直接使用
  const { useDemo, Demo } = sdk;
  useDemo();
  return (
    <div><Demo /></div>
  )
}
```

---

## 国际化相关

```js
import { i18n } from "@tea/app"

// or

import { t, Trans } from "@tea/app/i18n"
```

### 参数结构

```ts
declare const i18n: {
  /**
   * 当前用户的国际化语言，已知语言：
   *  - `zh` 中文
   *  - `en` 英文
   *  - `jp` 日语
   *  - `ko` 韩语
   */
  lng: string;
  /**
   * 当前用户所在站点
   *  - `1` 表示国内站；
   *  - `2` 表示国际站；
   *
   * @type {1 | 2}
   */
  site: number;
  /**
   * 注册国家
   */
  country: {
      name: string;
      code: string;
  };
  /**
   * 初始化当前语言的国际化配置
   */
  init: ({ translation }: I18NInitOptions) => void;
  /**
   * 标记翻译句子
   * 详细的标记说明，请参考 http://tapd.oa.com/QCloud_2015/markdown_wikis/view/#1010103951008390841
   */
  t: (sentence: string, options?: I18NTranslationOptions) => string;
  /**
   * 标记翻译组件
   * 详细的标记说明，请参考 http://tapd.oa.com/QCloud_2015/markdown_wikis/view/#1010103951008390841
   */
  Trans: import("react").ComponentClass<import("react-i18next").TransProps, any>;
};
```

### 词条标记
若`window.showi18nKey`标记存在，tea-app对Trans组件和t函数的翻译结果进行标记
Trans组件添加属性 `data-i18ntag`
```
<span data-i18ntag="k_0hc154g">
  "目前视图中的内容无法满足需要？您可以创建"
</span>
```
t函数在内容后添加i18n词条对应的key
```
回到旧版_K_114lnus
```
详情见[词条位置可视化](https://iwiki.woa.com/p/4012719551)

## Buffet 脚本灰度

`@2.2.0`

2021/06/22 开始，控制台发布除了「百分比」灰度，还支持「自定义脚本」灰度，提供更灵活的发布方式，详情请参考[Buffet 系统发布策略](http://tapd.oa.com/tcp_access/markdown_wikis/show/#1220399462001848503)

### 注册灰度脚本

对于使用 `tea-cli` 生成的项目，下面的使用代码会自动生成：

```js
app.buffetStrategy.register('demo-strategy', () => {
  // SDK 导出的方法
  return {
    strategy(versions: BuffetStrategyVersions, strategyConfig: BuffetStrategyConfig, bussinessKey: string) {
      console.log('Hello from demo-sdk');
    }
  }
});
```

### 定义灰度逻辑

通过 `tea-cli` 创建项目之后，你可以在 strategy 函数中定义灰度逻辑

函数定义：

```js
strategy: (versions: BuffetStrategyVersions, strategyConfig: BuffetStrategyConfig, bussinessKey: string) => void;
```

参数定义：

```js
export interface BuffetStrategyVersions {
  // 切换到变更单版本
  enterTicketVersion: () => void;

  // 切换到现网版本
  enterMasterVersion: () => void;
}

export interface BuffetStrategyConfig {
  // 策略可选值
  scopes: {
    // 新增一级 default 预留后续可能要支持多维度的策略器
    default: string[];
  },

  // 策略值
  values: {
    default: string[];

    // 发布时选择的百分比
    percentage: number;

    // 发布时填写的灰度 UIN
    uins: any[];
  },

  // 脚本 CDN 地址
  script: string;
}
```

示例脚本：

```js
import { app } from '@tencent/tea-app';
import { t } from '@tea/app/i18n';

const { loginUin = '' } = app.user || {};

app.buffetStrategy.register('scritp-card', () => ({
  strategy: (versions, strategyConfig, bussinessKey) => {
    const { values } = strategyConfig;
    const { uins } = values;

    // 效果等同于 buffet 灰度 uin
    if (!uins.includes(loginUin)) {
      console.log(t('开始渲染现网版本'));
      versions.enterMasterVersion();
    } else {
      console.log(t('开始渲染灰度版本'));
      versions.enterTicketVersion();
    }
  },
}));
```

## 服务器

### 获取服务器时间

获取控制台的服务器时间。依赖控制台环境，其他环境将返回客户端时间。

```ts
import { getCurrentServerTime } from '@tencent/tea-app';

console.log(getCurrentServerTime().toISOString());
```
