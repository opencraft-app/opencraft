# @tencent/tea-app

## 2.1.25

### Patch Changes

- 82884d4: 升级 i18next 和 react-i18next
- 59ec0ca: feat i18ntag
- Updated dependencies [9b2bb4c]
- Updated dependencies [f8d470b]
- Updated dependencies [fdf697a]
- Updated dependencies [dadafd0]
- Updated dependencies [e2e69f3]
- Updated dependencies [45fa21e]
- Updated dependencies [a300249]
- Updated dependencies [e58fd47]
- Updated dependencies [1d865dd]
- Updated dependencies [64e189d]
- Updated dependencies [add14d6]
- Updated dependencies [27551b3]
- Updated dependencies [2736c5e]
- Updated dependencies [4cb7bd4]
- Updated dependencies [2c0c56e]
- Updated dependencies [69df8f6]
- Updated dependencies [d8f0c51]
- Updated dependencies [5a0c863]
- Updated dependencies [1ed2801]
- Updated dependencies [e6a7e83]
- Updated dependencies [aed6bff]
- Updated dependencies [120f2a0]
  - @tencent/tea-component@2.8.5

## 2.1.25-beta.1

### Patch Changes

- 59ec0ca: feat i18ntag

## 2.1.25-beta.0

### Patch Changes

- 82884d4: 升级 i18next 和 react-i18next

## 2.1.24

### Patch Changes

- 35feb1d: tea-cli、tea-app、tea-scripts 处理一些安全扫描
- 9c64c5b: 改动
  - tea-component 升级样式包为@tencent/tea-style@1.1.9
  - tea-app RequestOptions json 参数补充说明
- Updated dependencies [4407628]
- Updated dependencies [71e78f9]
- Updated dependencies [7c1771d]
- Updated dependencies [4285f7d]
- Updated dependencies [de01c3f]
- Updated dependencies [2fc6714]
- Updated dependencies [9c64c5b]
- Updated dependencies [2488aac]
- Updated dependencies [57151c6]
- Updated dependencies [8304db9]
- Updated dependencies [35a3447]
- Updated dependencies [02b2c3b]
- Updated dependencies [3d282aa]
- Updated dependencies [a316613]
- Updated dependencies [9bef0ed]
- Updated dependencies [0fabe18]
- Updated dependencies [cfb029b]
- Updated dependencies [8217576]
- Updated dependencies [81d9555]
- Updated dependencies [47b3c8c]
- Updated dependencies [b8c9ce1]
  - @tencent/tea-component@2.8.4

## 2.1.23-beta.10

### Patch Changes

- 9c64c5b: 改动
  - tea-component 升级样式包为@tencent/tea-style@1.1.9
  - tea-app RequestOptions json 参数补充说明
- Updated dependencies [9c64c5b]
  - @tencent/tea-component@2.8.4-beta.21

## 2.1.23-beta.9

### Patch Changes

- 35feb1d: tea-cli、tea-app、tea-scripts 处理一些安全扫描
