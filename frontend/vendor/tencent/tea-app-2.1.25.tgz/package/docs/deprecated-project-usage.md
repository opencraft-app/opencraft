项目相关接口
==========

为了规范资源管理模式，新产品不再支持项目的接入。请使用标签能力进行资源管理，参考指引：http://km.oa.com/group/19368/docs/show/189661

本文档仅供以前使用项目的业务使用。

### `app.user.getLastProjectId()`

获取用户最后使用的 projectId

- 如果不存在，则返回 `-1`
- 该数据基于用户当前的 ownerUin 存储在 localStorage 中
- 基于上一点，该数据可能会被其它业务修改，所以使用前应该先校验合法性

### `app.user.setLastProjectId()`

设置用户最后一次访问的 projectId，该数据可以被其它业务使用。

### `app.user.getPermitedProjectInfo()`

异步获取用户有权限的项目信息。

```js
const { isShowAll, projects } = await app.user.getPermitedProjectInfo();
```

返回数据结构如下：

```ts
interface PermitedProjectInfo {
  /**
   * 当前用户是否有具备查看所有项目的权限
   */
  isShowAll: boolean;

  /**
   * 当前用户有权限的项目列表
   */
  projects: ProjectItem[];
}

interface ProjectItem {
  /**
   * 项目 ID，为 0 表示默认项目
   */
  projectId: number;

  /**
   * 项目名称
   */
  projectName: string;
}
```

### `app.user.getPermitedProjectList()`

同上，不过直接返回 `projects`：

```js
const projects = await app.user.getPermitedProjectList();

for (let { projectId, projectName } of projects) {
  console.log(projectId, projectName);
}
```
