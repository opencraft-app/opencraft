import React from "react";
import { RegionSelect, RegionPanel, RegionOption, RegionFlag } from "@tencent/tea-component";
declare global {
    interface Window {
        g_buffet_data: {
            version: string;
        };
    }
}
interface RegionComponents {
    RegionSelect: typeof RegionSelect;
    RegionPanel: typeof RegionPanel;
    RegionOption: typeof RegionOption;
    RegionFlag?: typeof RegionFlag;
}
export declare function RegionSupport({ children, }: {
    children: (components: RegionComponents) => React.ReactNode;
}): React.JSX.Element;
export {};
