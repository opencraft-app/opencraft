import { History } from "history";
import React from "react";
export type Confirmation = typeof import("history/DOMUtils").getConfirmation;
interface HistoryContextValue {
    history: History<any> & {
        getReferrer?: () => string;
    };
    setConfirmation: (confirmation: Confirmation) => void;
}
export declare const HistoryContext: React.Context<HistoryContextValue>;
/**
 * 使用适配控制台的 history（React Hooks）
 *
 * 具体使用方法请参考 http://tapd.oa.com/QCloud_2015/markdown_wikis/view/#1010103951008571667
 *
 * @param getConfirmation (experimental) 路由切换前，让用户确认
 *
 * @example
```js
import React from 'react';
import { Router, Route, Link } from 'react-router-dom';
import { useHistory } from '@tea/app';
import { CvmDetailInstance } from './components';

export function CvmDetail() {
  // 此处为 React Hooks，只能在 Function Component 中使用
  const history = useHistory();

  return (
    <Router history={history}>
      <div>
        <Link to="/cvm/detail/ins-1q2w3e4r">ins-1q2w3e4r</Link>
        <Route path="/cvm/detail/:instanceId" component={CvmDetailInstance}></Route>
      </div>
    </Router>
  );
}
```
 */
export declare const useHistory: (getConfirmation?: Confirmation) => History<any> & {
    getReferrer?: () => string;
};
export declare function withHistory<C extends React.ComponentClass<any>>(WrappedComponent: C): C;
export {};
