/**
 * @fileoverview
 *
 * 导出 `app` 命名空间，包括：
 *
 *   - 路由注册方法
 *   - 控制台桥接工具
 */
export { ErrorBoundary } from "./ErrorBoundary";
export { routes } from "./routes";
export * from "./server";
export * from "../bridge";
