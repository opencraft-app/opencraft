import React from "react";
/**
 * 用于 <Trans> 中插值
 */
declare function Slot({ content }: {
    content: any;
}): React.JSX.Element;
/**
 * 国际化包括的信息以及所需的工具
 */
export declare const i18n: {
    /**
     * 当前用户的国际化语言，已知语言：
     *  - `zh` 中文
     *  - `en` 英文
     *  - `jp` 日语
     *  - `ko` 韩语
     */
    lng: string;
    /**
     * 当前用户的国际化语言，已知语言：
     *  - `zh` 中文
     *  - `en` 英文
     *  - `jp` 日语
     *  - `ko` 韩语
     */
    lang: string;
    /**
     * 当前用户所在站点
     *  - `1` 表示国内站；
     *  - `2` 表示国际站；
     *
     * @type {1 | 2}
     */
    site: number;
    /**
     * 注册国家
     */
    country: {
        name: string;
        code: string;
    };
    /**
     * 初始化当前语言的国际化配置
     */
    init: ({ translation }: I18NInitOptions) => void;
    /**
     * 标记翻译句子
     * 详细的标记说明，请参考 http://tapd.oa.com/tcp_access/markdown_wikis/0#1020399462009480783
     */
    t: (sentence: string, options?: I18NTranslationOptions) => string;
    /**
     * 标记翻译组件
     * 详细的标记说明，请参考 http://tapd.oa.com/tcp_access/markdown_wikis/0#1020399462009480783
     */
    Trans: React.ComponentType<Omit<{
        children?: import("react-i18next/TransWithoutContext").TransChild | import("react-i18next/TransWithoutContext").TransChild[];
        components?: readonly React.ReactElement<any, string | React.JSXElementConstructor<any>>[] | {
            readonly [tagName: string]: React.ReactElement<any, string | React.JSXElementConstructor<any>>;
        };
        count?: number;
        context?: string;
        defaults?: string;
        i18nKey?: unknown;
        ns?: unknown;
        parent?: string | React.ComponentType<any>;
        tOptions?: {};
        values?: {};
        shouldUnescape?: boolean;
        t?: any;
    }, keyof import("react-i18next").WithTranslation<N, undefined>> & import("react-i18next").WithTranslationProps>;
    /**
     * 用于 <Trans> 中插值
     */
    Slot: typeof Slot;
};
export declare const getI18NInstance: () => import("i18next").i18n;
/**
 * @internal 国际化容器，内部使用
 */
export declare const I18NProvider: React.FunctionComponent<import("react-i18next").I18nextProviderProps>;
export interface I18NInitOptions {
    translation: I18NTranslation;
}
export interface I18NTranslation {
    [key: string]: string;
}
export interface I18NTranslationOptions {
    /** 用于确定单复数的数量值 */
    count?: number;
    /** 用于确定上下文的说明文本，只能使用字符串常量，否则无法扫描 */
    context?: string;
    [key: string]: any;
}
export {};
