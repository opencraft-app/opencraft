export declare function initTips(): void;
