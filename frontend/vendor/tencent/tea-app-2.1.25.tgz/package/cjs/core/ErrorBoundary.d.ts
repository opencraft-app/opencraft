import React, { ErrorInfo } from "react";
type State = {
    hasError: boolean;
    error?: Error;
};
type renderProps = {
    error: Error;
    reset: () => void;
};
type Props = {
    render?: (props: renderProps) => React.ReactNode;
    customErrorInfo?: (errorInfo: ErrorInfo) => Record<string, any>;
};
/**
 * 错误边界处理
 * 1. 支持全局错误边界上报
 * 2. 支持局部渲染错误边界上报，自定义错误处理 UI
 */
export declare class ErrorBoundary extends React.Component<Props, State> {
    constructor(props: any);
    static getDerivedStateFromError(error: any): {
        hasError: boolean;
        error: any;
    };
    componentDidCatch(error: any, errorInfo: any): void;
    render(): React.ReactNode;
}
export {};
