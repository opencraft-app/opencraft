/// <reference types="react" />
import { i18n } from "./core/i18n";
declare const lng: string, lang: string, site: number, country: {
    name: string;
    code: string;
}, init: ({ translation }: import("./core/i18n").I18NInitOptions) => void, t: (sentence: string, options?: import("./core/i18n").I18NTranslationOptions) => string, Trans: import("react").ComponentType<Omit<{
    children?: import("react-i18next/TransWithoutContext").TransChild | import("react-i18next/TransWithoutContext").TransChild[];
    components?: readonly import("react").ReactElement<any, string | import("react").JSXElementConstructor<any>>[] | {
        readonly [tagName: string]: import("react").ReactElement<any, string | import("react").JSXElementConstructor<any>>;
    };
    count?: number;
    context?: string;
    defaults?: string;
    i18nKey?: unknown;
    ns?: unknown;
    parent?: string | import("react").ComponentType<any>;
    tOptions?: {};
    values?: {};
    shouldUnescape?: boolean;
    t?: any;
}, keyof import("react-i18next").WithTranslation<N, undefined>> & import("react-i18next").WithTranslationProps>, Slot: ({ content }: {
    content: any;
}) => import("react").JSX.Element;
export default i18n;
export { lng, lang, site, country, init, t, Trans, Slot };
