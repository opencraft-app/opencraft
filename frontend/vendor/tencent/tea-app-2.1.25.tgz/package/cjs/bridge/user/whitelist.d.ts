export type WhitelistFieldType = 'ownerUin' | 'appid' | 'loginUin';
/**
 * 批量检查用户白名单
 */
export declare const checkWhitelistBatch: (keys: string[], fieldType?: WhitelistFieldType) => Promise<{
    [key: string]: number;
}>;
/**
 * 检查白名单
 */
export declare const checkWhitelist: (key: string, fieldType?: WhitelistFieldType) => Promise<number>;
