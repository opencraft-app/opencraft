export declare const getAntiCSRFToken: () => string;
export declare const getSessionHash: () => string;
