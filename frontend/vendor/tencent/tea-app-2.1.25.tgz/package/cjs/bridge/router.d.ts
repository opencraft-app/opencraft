/**
 * 导航控制台路由到指定的路径
 *
 * @param path 要导航的路径，如 `/cvm`
 * @param silent 如果为 true，则只会进行路由，而不会改变浏览器历史。默认为 false
 * @param replace 如果为 true，则会替换浏览器当前页面，后退按钮将无法回到当前页面
 */
export declare function navigate(path: string, silent?: boolean, replace?: boolean): void;
