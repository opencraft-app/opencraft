export declare const page: {};
