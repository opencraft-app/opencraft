export declare const insight: {
    /**
     * 上报点击流
     * @param tag 点击标识
     */
    reportHotTag(tag: string): void;
    /**
     * 上报图片加载错误
     * @param {string} imageUrl 图片 url
     */
    reportImageLoadError(imageUrl: string): void;
    /**
     * 自定义上报，如果 ns 和 event 参数不正确，会扔出异常
     *
     * 控制台在预览模式或开发模式不会上报，如果要验证效果，请在手动添加标识到 localStorage:
     *
     * ```js
     * localStorage.debugInsight = true
     * ```
     *
     * 然后刷新页面。
     *
     * @example
     *
      ```js
      import { app } from '@tea/app';
  
      app.insight.stat({
        ns: 'cvm',
        event: 'restart',
        cost: 996,
        stringFields: {
          instance: 'ins-1d7x8C3s'
        },
        integerFields: {
          instanceCount: 1
        }
      });
    ```
     */
    stat({ ns, event, cost, result, stack, integerFields, stringFields, }: InsightStat): void;
    /** 创建一个统计任务，不马上上报结果。上报结果的时候，报告任务是否成功，并自动统计耗时。如果指定了 timeout，则超时未上报会上报一个 timeout 统计 */
    statTask(task: string, ns: string, timeout?: number): {
        /** 上报任务成功 */
        success: (fields?: Pick<InsightStat, "integerFields" | "stringFields">) => void;
        /** 上报任务失败 */
        fail: (fields?: Pick<InsightStat, "stack" | "result"> & Pick<InsightStat, "integerFields" | "stringFields">) => void;
        /** 上报任务终止 */
        abort: () => void;
    };
    /**
     * 说明：函数组件请使用 usePageReadyStat，会自动在组件销毁时中断上报任务
     * 如果是旧的业务代码使用类组件，请在 componentWillUnmount 的时候手动 abort()
     */
    statPageReady: () => {
        /** 上报任务成功 */
        success: (fields?: Pick<InsightStat, "integerFields" | "stringFields">) => void;
        /** 上报任务失败 */
        fail: (fields?: Pick<InsightStat, "stack" | "result"> & Pick<InsightStat, "integerFields" | "stringFields">) => void;
        /** 上报任务终止 */
        abort: () => void;
    };
};
/** 创建首屏可用统计。业务应尽量提供该上报。在数据全部加载完成，用户已经可操作后上报 success */
export declare const usePageReadyStat: () => {
    /** 上报任务成功 */
    success: (fields?: Pick<InsightStat, "integerFields" | "stringFields">) => void;
    /** 上报任务失败 */
    fail: (fields?: Pick<InsightStat, "stack" | "result"> & Pick<InsightStat, "integerFields" | "stringFields">) => void;
    /** 上报任务终止 */
    abort: () => void;
};
export interface InsightStat {
    /**
     * 为了不与其他业务的数据冲突，需要制定上报的命名空间，如 "cvm"
     *
     * 命名空间允许使用的字符：字母、数字、斜杠 `/`（不允许出现在首尾），如：
     *
     *  - "cvm2"
     *  - "cvm/sg"
     */
    ns: string;
    /**
     * 本次统计的事件名称
     *
     * 事件名允许使用的字符：字母、数字、横杠 `-`（不允许出现在首尾），如：
     *
     *  - "restart-fail"
     *  - "move2recycle"
     */
    event: string;
    /**
     * 事件所用耗时，可以不占用 integerFields 和 stringFields 额度。
     * 为了兼容以前大部分业务的数据，会尝试从 int_timeCost、int_cost、int_costTime 查找
     */
    cost?: number;
    /** 事件结果 */
    result?: "success" | "fail" | "timeout";
    /** 仅当结果失败或者超时上报。提供统计调用堆栈，方便定位问题 */
    stack?: string;
    /**
     * 自定义数据（整数类型）
     *
     * 如果传入的是不是 number 类型，会被忽略。如果传入的不是整数，会使用 Math.round 取整。
     */
    integerFields?: Record<any, number>;
    /**
     * 自定义数据（字符串类型）
     *
     * 如果传入的不是 string 类型，会被忽略。
     *
     * 单个字段的长度，不能超过 4096，否则会被裁切
     */
    stringFields?: Record<any, string>;
}
