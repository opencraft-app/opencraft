export interface StrategyExecutionInfo {
    strategy: (versions: BuffetStrategyVersions, strategyConfig: BuffetStrategyConfig, bussinessKey: string) => void;
}
export interface BuffetStrategyVersions {
    enterTicketVersion: () => void;
    enterMasterVersion: () => void;
}
export interface BuffetStrategyConfig {
    scopes: {
        default: string[];
    };
    values: {
        default: string[];
        percentage: number;
        uins: any[];
        internalIp: boolean;
    };
    script: string;
    ticketId?: number;
    groupId?: number;
}
export declare const buffetStrategy: {
    /**
     * 注册 buffet 灰度策略器
     *
     * @param strategyName
     * @param strategyFactory
     */
    register: (strategyName: string, strategyFactory: () => StrategyExecutionInfo) => void;
};
