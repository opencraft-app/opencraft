export declare const net: {};
