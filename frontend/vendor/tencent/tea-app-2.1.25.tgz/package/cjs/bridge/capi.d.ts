import { BaseRequest, RequestBody, RequestHcOptions, RequestV3, RequestV3Public } from "../types/capi";
export declare const capi: {
    /** 云 API 请求
     * @deprecated 请求 V2 云 API 接口已废弃，请使用 `requestV3Public` 或 `requestV3` 方法
     * @param body 云 API 请求参数
     * @param options 云 API 请求选项
     */
    request: BaseRequest;
    /** 云 API V3 请求
     * @param body 云 API 请求参数
     * @param options 云 API 请求选项
     */
    requestV3: RequestV3;
    /** 云 API V3 请求，使用公有云已经公开的接口，会通过 tencentcloud-sdk-nodejs 进行类型支持。 */
    requestV3Public: RequestV3Public;
    /** 云 API 批量调用接口 */
    batchRequest<T = any>(body: RequestBody[], options?: RequestHcOptions): Promise<T>[];
    /** 提供云 API SSE请求的相关数据
     * 请自行选择合适的方式发送 SSE 请求
     * 推荐使用 fetch-event-stream
     */
    generateSseRequest(body: RequestBody, options?: RequestHcOptions): {
        url: string;
        body: string;
        method: string;
        headers: Record<string, string>;
    };
};
export { SDK, RequestBody, RequestOptions, RequestV3Options, RequestV3Public, RequestV3PublicBody, } from "../types/capi";
