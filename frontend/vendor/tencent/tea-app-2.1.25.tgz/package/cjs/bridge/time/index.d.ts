import type { Moment, MomentInput } from "moment";
declare class Time {
    private tMoment;
    private lang;
    constructor(t: Moment);
    /**
     * 获取当前使用的moment对象
     * @example
      ```js
      const moment = app.time.fromBJTime('2023-11-30 20:00:00').getMoment();
      moment.valueOf(); // 1701345600000
      moment.format(); // 2023-11-30T07:00:00-05:00
      ```
     * @returns Moment
     */
    getMoment(): Moment;
    /**
     * 返回标准时间，语种跟随cookie里的language字段
     * @param withTZ: boolean 是否携带时区
     * zh: 2023-11-30 07:00:00 (UTC-05:00)
     * en: Nov 30, 2023 07:00:00 (UTC-05:00)
     * @returns string
     */
    getFullTime(withTZ?: boolean): string;
    /**
     * 获取当前用户系统的基于UTC标准的时区偏移
     * @example UTC-05:00
     * @returns string
     */
    getOffset(): string;
    /**
     * 获取当前用户系统的时区标志
     * @example America/New_York
     * @returns string
     */
    getTimeZone(): string;
    /**
     * 将用户时区统一转换为UTC标准时间，用于参数传递
     * @example 2023-11-30T12:00:00Z
     * @returns string
     */
    toUTC(): string;
    /**
     * 将用户时区转换为时间戳，用于参数传递
     * @example 1701392400000
     * @returns number
     */
    toValue(): number;
}
declare const time: {
    /**
     * 注意：此时的入参为北京时间，或北京时间构造的moment or date对象
     * @param t 北京时间的入参数
     * @returns 基于北京时间的moment对象
     */
    fromBJTime: (t?: MomentInput) => Time;
    /**
     * 传递的参数默认为本地时间，此时可以直接使用moment
     * @param t 本地时间的入参
     * @returns 基于用户本地时间的moment对象
     */
    fromLocalTime: (t?: MomentInput) => Time;
    /**
     * 参数为时间戳或者utc时间的情况
     * @param t 时间戳 | utc时间
     * @returns 带时区的moment对象
     */
    from: (t?: MomentInput) => Time;
    /**
     * 设置语种
     * @param l zh|en|ko|jp
     */
    setLang: (l: string) => void;
};
export { time, };
