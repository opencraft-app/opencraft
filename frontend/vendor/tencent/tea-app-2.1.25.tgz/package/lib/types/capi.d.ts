export interface RequestBody {
  /**
   * 请求的云 API 地域
   */
  regionId: number;

  /**
   * 请求的云 API 业务
   */
  serviceType: string;

  /**
   * 请求的云 API 名称
   */
  cmd: string;

  /**
   * 请求的云 API 数据
   */
  data?: any;
}

export interface RequestOptions {
  /**
   * 是否使用安全的临时密钥 API 方案，建议使用 true
   * @default true
   */
  secure?: boolean;

  /**
   * 使用的云 API 版本，该参数配合 secure 使用
   *
   *   - `secure == false`，该参数无意义
   *   - `secure == true && version = 1`，将使用老的临时密钥服务进行密钥申请，否则使用新的密钥服务
   *   - `secure == true && version = 3`，使用云 API v3 域名请求，不同地域域名不同
   */
  version?: number;

  /**
   * 是否将客户端 IP 附加在云 API 的 `clientIP` 参数中
   */
  withClientIP?: boolean;

  /**
   * 是否将客户端 UA 附加在云 API 的 `clientUA` 参数中
   */
  withClientUA?: boolean;

  /**
   * 公共参数是否包含语言（Language 字段）
   * 如果设置为 true，则 Language 取值为控制台当前语言
   * @default false
   */
  withLanguage?: boolean;

  /**
   * 是否在顶部显示接口错误
   * 默认为 true，会提示云 API 调用错误信息，如果自己处理异常，请设置该配置为 false
   * @default true
   */
  tipErr?: boolean;

  /**
   * 禁用非中文站点下接口数据自动翻译
   * @default false
   */
  disableTranslate?: boolean;

  /**
   * 请求时是否在顶部显示 Loading 提示
   * @default true
   */
  tipLoading?: boolean;

  /**
   * 接入层到云api调用是否使用json模式
   * 控制台默认不支持空数组作为参数传递，如需传递空数组，请增加此设置为 true 即可
   */
  json?: boolean;

  /**
   * 前端事务进行跟踪的请求头 X-TC-TraceId
   *
   * - 需满足标准uuid的正则 ` ^(\\w{8}(-\\w{4}){3}-\\w{12}?)`
   * 例如：958cccac-ab2a-dcfe-6fc4-1456f8ddc3a9
   */
  traceId?: string;

  /**
   * 数据传输过程是否启用gzip压缩
   */
  enableZip?: boolean;
}

export type RequestV3Options = Pick<
  RequestOptions,
  Exclude<keyof RequestOptions, "secure" | "version">
>;

export type RequestHcOptions = Omit<RequestV3Options, "json"> & {
  /** 针对普通云 API 请求是否启用高可用模式
   * 对于其它 hc 高级请求则无需开启，锁定采用高可用模式
   */
  highCapacity?: true;
};

/// ////////////////////////////////////////////////////
/// 下面的代码支持从腾讯云 API 的公开 SDK 中获得 API 类型 ///
/// ////////////////////////////////////////////////////

// value naming:
// - sdk.cvm.v20170312.Client.prototype
//
// type naming:
// - SDK: typeof sdk
// - Service: keyof SDK
// - Action: keyof SDK[Service]
// - Namespace: SDK[Service][Version]
// - Client: VersionClient['Client']['prototype']
// - Action: keyof Client
// - Method: Client[Action]
// - Request: req of method
// - Response: res of method

// #region dependency
/** 将 SDK 中的 'v20200608' 传值改为标准的 '2020-06-08' */
type NormalizeVersion<V> =
  V extends `v${infer A}${infer B}${infer C}${infer D}${infer E}${infer F}${infer G}${infer H}`
    ? `${A}${B}${C}${D}-${E}${F}-${G}${H}`
    : string;

/** Node 导出的 SDK 类型 */
export type SDK = typeof import("tencentcloud-sdk-nodejs");

/** 从 Namespace 解构 Client */
type Client<Namespace> = Namespace extends {
  Client: { prototype: infer T };
}
  ? T
  : never;

/** Client 支持的方法名 */
type Actions<T> = keyof Client<T>;

/** 云 API 方法的签名都是这种类型，用来反向推导 Request 和 Response 类型 */
type Method<Req, Res> = (
  req: Req,
  cb?: (error: string, res: Res) => void
) => Promise<Res>;
type Request<
  Client,
  Action extends keyof Client
> = Client[Action] extends Method<infer Req, any> ? Req : never;
type Response<
  Client,
  Action extends keyof Client
> = Client[Action] extends Method<any, infer Res> ? Res : never;
// #endregion

// #region v3Public
export interface RequestV3PublicBody<
  Service extends keyof SDK,
  Version extends keyof SDK[Service],
  Action extends Actions<SDK[Service][Version]>
> {
  /**
   * 请求的云 API 地域
   */
  regionId?: number;

  /**
   * 请求的云 API 业务
   */
  serviceType: Service;

  /**
   * 要请求的 API 名称
   * (此参数比传，这里给出可选只是为了可以正常推导)
   */
  cmd: Action;

  /**
   * 请求的 API 数据
   */
  data?: Request<Client<SDK[Service][Version]>, Action> & {
    /** 指定接口版本，可使用从公有云 NodeJS SDK 类型中推导的值。需要覆改则改成自定义值并 as any  */
    Version: NormalizeVersion<Version>;
  };
}

export interface RequestV3PublicResult<Response> {
  /** 为保持和 capi.requestV3() 方法的返回结构一致，调用结果有一层 data.Response，业务请自行解构 */
  data?: {
    /** 云 API 的响应数据 */
    Response?: Response;
  };
}
// #endregion

// #region overload
export type BaseRequest = {
  <T = any>(body: RequestBody, options?: RequestOptions): Promise<T>;
  <T = any>(body: RequestBody, options: RequestHcOptions): Promise<T>;
};

export type RequestV3 = {
  <T = any>(body: RequestBody, options?: RequestV3Options): Promise<T>;
  <T = any>(body: RequestBody, options: RequestHcOptions): Promise<T>;
};

export type RequestV3Public = {
  <
    Service extends keyof SDK,
    Version extends keyof SDK[Service],
    Action extends Actions<SDK[Service][Version]>
  >(
    body: RequestV3PublicBody<Service, Version, Action>,
    options?: RequestV3Options
  ): Promise<
    RequestV3PublicResult<Response<Client<SDK[Service][Version]>, Action>>
  >;
  <
    Service extends keyof SDK,
    Version extends keyof SDK[Service],
    Action extends Actions<SDK[Service][Version]>
  >(
    body: RequestV3PublicBody<Service, Version, Action>,
    options: RequestHcOptions
  ): Promise<
    RequestV3PublicResult<Response<Client<SDK[Service][Version]>, Action>>
  >;
};
// #endregion
