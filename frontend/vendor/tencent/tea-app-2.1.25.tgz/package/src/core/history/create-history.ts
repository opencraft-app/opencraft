import {
  Action,
  BrowserHistoryBuildOptions,
  createLocation,
  createPath,
  History,
  Location,
  LocationDescriptorObject,
  LocationListener,
  LocationState,
} from "history";
import createTransitionManager, {
  Prompt,
} from "history/createTransitionManager";
import warning from "warning";

import { _bridge } from "../../bridge/_bridge";

interface ConsoleRouter {
  /**
   * 控制台路由方法
   */
  navigateWithState(
    url: string,
    silent: boolean,
    replacement: boolean,
    state: any
  ): void;

  /**
   * 注册动态路由
   */
  use(rule: string, action: Function): void;

  /**
   * 取消注册动态路由
   */
  unuse(rule: string): void;
}

export interface TeaHistoryBuildOptions extends BrowserHistoryBuildOptions {
  controller?: string;
  action?: string;
  getUserConfirmation?: (
    message: string,
    callback: (confirm: boolean) => void
  ) => void;
}

/**
 * 利用控制台的 Router 对象创建兼容 React Router 的 history
 *
 * 参考 createBrowserHistory 实现
 * @see https://github.com/ReactTraining/history/blob/master/modules/createBrowserHistory.js
 */
export function createHistory<S>(props: TeaHistoryBuildOptions): History<S> {
  const globalHistory = window.history;

  const { controller, action, getUserConfirmation, keyLength = 6 } = props;

  const consoleRouter: ConsoleRouter = window.seajs.require("router");
  const consoleRouteRule = `/${controller}/${action}(/*params)`;

  const transitionManager = createTransitionManager();
  const initialLocation = getDOMLocation(getHistoryState());

  const history = {
    length: globalHistory.length,
    action: "POP" as Action,
    location: initialLocation,
    createHref,
    push: perform("PUSH"),
    replace: perform("REPLACE"),
    go,
    goBack,
    goForward,
    block,
    listen,
    getReferrer,
  };

  function getReferrer() {
    return _bridge("router").referrer;
  }

  function perform(action: Action) {
    return (path: string | LocationState, state?: LocationState) => {
      warning(
        !(
          typeof path === "object" &&
          (path as any).state !== undefined &&
          state !== undefined
        ),
        `You should avoid providing a 2nd state argument to ${action.toLocaleLowerCase()} when the 1st ` +
          "argument is a location-like object that already has state; it is ignored"
      );
      const location = createLocation(
        path,
        state,
        createKey(),
        history.location
      );

      transitionManager.confirmTransitionTo(
        location,
        action,
        getUserConfirmation,
        ok => {
          if (!ok) return;

          const href = createHref(location);
          const { key, state } = location;

          // createBrowserHistory 的实现是调用 history.pushState()
          // 这里改为通过控制台路由代理
          muteNextPop = true;
          consoleRouter.navigateWithState(href, false, action === "REPLACE", {
            key,
            state,
          });
          muteNextPop = false;

          setState({ action, location });
        }
      );
    };
  }

  function go(n: number) {
    globalHistory.go(n);
  }

  function goBack() {
    go(-1);
  }

  function goForward() {
    go(1);
  }

  let listenerCount = 0;
  function checkRouterListeners(delta) {
    listenerCount += delta;

    if (listenerCount === 1 && delta === 1) {
      // add
      consoleRouter.use(consoleRouteRule, handlePopState);
    } else if (listenerCount === 0) {
      // remove
      consoleRouter.unuse(consoleRouteRule);
    }
  }

  function handlePopState() {
    const location = getDOMLocation(getHistoryState());
    handlePop(location);
  }

  let muteNextPop = false;

  function handlePop(location: Location) {
    // push/replace 触发 console router.navigate() 方法
    // 同样会回调 handlePop()
    // 实际上，此时状态已经设置完毕，无需处理
    if (muteNextPop) {
      return;
    }
    const action = "POP";
    setState({ action, location });
  }

  let isBlocked = false;
  function block(prompt: Prompt = false) {
    const unblock = transitionManager.setPrompt(prompt);

    if (!isBlocked) {
      checkRouterListeners(1);
      isBlocked = true;
    }

    return () => {
      if (isBlocked) {
        isBlocked = false;
        checkRouterListeners(-1);
      }

      return unblock();
    };
  }

  function listen(listener: LocationListener) {
    const unlisten = transitionManager.appendListener(listener);
    checkRouterListeners(1);

    return () => {
      checkRouterListeners(-1);
      unlisten();
    };
  }

  function createHref(location: LocationDescriptorObject) {
    return createPath(location);
  }

  function createKey() {
    return Math.random().toString(36).substr(2, keyLength);
  }

  function setState(nextState?: Pick<History, "action" | "location">) {
    if (nextState) {
      Object.assign(history, nextState);
    }
    history.length = globalHistory.length;
    transitionManager.notifyListeners(history.location, history.action);
  }

  return history as History<S>;
}

function getHistoryState() {
  try {
    return window.history.state || {};
  } catch (e) {
    // IE 11 sometimes throws when accessing window.history.state
    // See https://github.com/ReactTraining/history/pull/289
    return {};
  }
}

function getDOMLocation(historyState: any) {
  const { key = undefined, state = undefined } = historyState || {};
  const { pathname, search, hash } = window.location;

  const path = pathname + search + hash;

  return createLocation(path, state, key);
}
