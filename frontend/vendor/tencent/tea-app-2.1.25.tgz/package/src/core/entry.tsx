import React, { Suspense } from "react";
import ReactDOM from "react-dom";
import { StatusTip } from "@tencent/tea-component";

import { logTrace } from "../helpers/logTrace";
import {
  internalInsightShouldNotUsedByBusiness as _insight,
  InsightCore,
} from "./insight";
import { I18NProvider, getI18NInstance } from "./i18n";
import { createHistory } from "./history/create-history";
import { Confirmation, HistoryContext } from "./history/history-context";
import {
  BeforeDestroyContext,
  BeforeDestroyListener,
  BeforeDestroyParams,
} from "./beforeDestroy";
import { _bridge } from "../bridge/_bridge";
import { ConfigProvider as ESConfigProvider } from "@tencent/tea-component";
import { ConfigProvider } from "@tencent/tea-component/lib/configprovider";
import { ErrorBoundary } from "./ErrorBoundary";

type LazyComponent = React.LazyExoticComponent<() => JSX.Element>;

const { LoadingTip } = StatusTip;

// 入口组件
function createEntry(
  controller: string,
  action: string,
  entry: Exclude<AppEntry, 404>,
  setBeforeDestroyListener: (listener: BeforeDestroyListener) => void
) {
  const i18n = getI18NInstance();

  // 如果是 React.lazy 返回的组件包装一层 render
  if (
    typeof entry === "object" &&
    Symbol.for("react.lazy") === (entry as LazyComponent).$$typeof
  ) {
    const LazyEntry = entry as LazyComponent;
    entry = {
      render: () => <LazyEntry />,
    };
  }

  const EntryContent =
    typeof entry === "function"
      ? entry
      : (entry as AppEntryDetail).component || (entry as AppEntryDetail).render;

  EntryContent["displayName"] = `Entry(${controller}/${action})`;

  let confirmation: Confirmation = null;
  const history = createHistory({
    controller,
    action,
    getUserConfirmation: (message, callback) => {
      if (!confirmation) {
        callback(window.confirm(message));
      } else {
        confirmation(message, callback);
      }
    },
  });

  return function TeaEntry() {
    const classPrefix =
      typeof TEA_CLASS_PREFIX !== "undefined" ? TEA_CLASS_PREFIX : "tea";
    const locale =
      typeof WEBPACK_BUILD_LOCALE !== "undefined"
        ? WEBPACK_BUILD_LOCALE
        : i18n.language;
    return (
      <ErrorBoundary>
        <I18NProvider i18n={i18n}>
          <ESConfigProvider locale={locale as any} classPrefix={classPrefix}>
            <ConfigProvider locale={locale as any} classPrefix={classPrefix}>
              <HistoryContext.Provider
                value={{
                  history,
                  setConfirmation: current => (confirmation = current),
                }}
              >
                <BeforeDestroyContext.Provider
                  value={{
                    setBeforeDestroyListener,
                  }}
                >
                  <Suspense
                    fallback={
                      <div
                        style={{
                          display: "flex",
                          justifyContent: "center",
                          height: "100%",
                        }}
                      >
                        <LoadingTip />
                      </div>
                    }
                  >
                    <EntryContent />
                  </Suspense>
                </BeforeDestroyContext.Provider>
              </HistoryContext.Provider>
            </ConfigProvider>
          </ESConfigProvider>
        </I18NProvider>
      </ErrorBoundary>
    );
  };
}

/**
 * 为模块生成渲染和销毁方法
 */
export const factory: EntryModuleFactory =
  (controller, action, entry) => () => {
    // 模块需要实现渲染和销毁两个方法
    let render: () => void, destroy: () => void;

    // 渲染 DOM，render() 时创建，destory() 时回收
    let container: HTMLDivElement;

    // 模块标识，同时用作 container 的 id
    const moduleKey = `${controller}-${action}`;

    let currentBeforeListener: BeforeDestroyListener = null;

    const beforeDestroy = (beforeDestroyParams: BeforeDestroyParams) => {
      if (typeof currentBeforeListener === "function") {
        return currentBeforeListener(beforeDestroyParams);
      }
    };

    const setBeforeDestroyListener = (listener: BeforeDestroyListener) => {
      currentBeforeListener = listener;
    };

    // 渲染：路由命中时渲染
    render = () => {
      if (entry === 404) {
        return 404;
      }
      // window.nmc.render 负责把 DOM 创建并放在 #app-area 中，这个 DOM 后续被渲染所用
      window.nmc.render(
        `<div id="${moduleKey}" class="tea-page-root"></div>`,
        // 总览 home 特殊处理
        controller === "home" ? "" : controller
      );
      container = document.querySelector(`#${moduleKey}`);
      if (container) {
        const Entry = createEntry(
          controller,
          action,
          entry,
          setBeforeDestroyListener
        );
        ReactDOM.render(<Entry />, container);
      }
    };

    // 模块：路由切走时销毁
    destroy = () => {
      if (container) {
        ReactDOM.unmountComponentAtNode(container);
      }
      container = null;
    };

    return {
      // 包装 render 和 destroy 方法的异常处理
      ...insightFactory(moduleKey, render, destroy, beforeDestroy),
      // 导出文档标题（如果已定义）
      title:
        typeof entry === "object" && (entry as AppEntryDetail).title
          ? (entry as AppEntryDetail).title
          : null,
    } as EntryModule;
  };

export interface EntryModuleFactory {
  (controller: string, action: string, entry: AppEntry): () => EntryModule;
}

export interface EntryModule {
  render(): void;
  destroy(): void;
  title?: string;
}

/**
 * 单个路由入口定义，包含渲染方法、菜单和 CSS 定义
 */
export type AppEntry =
  | React.ComponentType<any>
  | LazyComponent
  | AppEntryDetail
  | 404;

export type AppEntryDetail = {
  /**
   * 路由渲染组件
   */
  component?: React.ComponentType<any>;

  /**
   * 路由渲染方法，需返回一个 React.ReactNode
   */
  render?: () => JSX.Element;

  /**
   * 该路由下所有的文档标题
   *
   * 如果希望动态设置标题，可以使用 useDocumentTitle() / setDocumentTitle()
   */
  title?: string;

  /**
   * 设置为控制台 controller 级模块
   */
  controllerMode?: boolean;
};

function insightFactory(
  moduleKey: string,
  render: () => void,
  destroy: () => void,
  beforeDestroy: BeforeDestroyListener
) {
  const { care, register, EventLevel } = _insight || ({} as InsightCore);
  function wrapFn(fn, moduleError, message) {
    return care(fn, {
      capture: trace => {
        const logMessage = `模块 ${moduleKey} ${message}：${trace.message}`;
        logTrace(logMessage, trace);
        moduleError.push({
          message: logMessage,
          moduleKey,
          stack: trace.stack,
        });
        throw trace;
      },
    });
  }

  if (typeof care === "function") {
    // 监控：模块渲染异常
    const moduleRenderError = register("module-render-error", {
      level: EventLevel.Error,
    });
    // 监控：模块销毁异常
    const moduleDestroyError = register("module-destroy-error", {
      level: EventLevel.Error,
    });
    // 监控：beforeDestroy 异常
    const moduleBeforeDestroyError = register("module-before-destroy-error", {
      level: EventLevel.Error,
    });
    // 捕获渲染异常
    render = wrapFn(render, moduleRenderError, "渲染异常");
    // 捕获销毁异常
    destroy = wrapFn(destroy, moduleDestroyError, "销毁异常");
    // 捕获 beforeDestroy 钩子异常
    beforeDestroy = wrapFn(
      beforeDestroy,
      moduleBeforeDestroyError,
      "before Destroy 异常"
    );
  }
  return { render, destroy, beforeDestroy };
}
