/**
 * 控制台接入层直出数据
 */

/**
 * 获取服务端时间
 * @returns 时间戳
 */
export function getCurrentServerTime() {
  return window.serverTimeForPlatformUsageOnly?.() || new Date().getTime();
}
