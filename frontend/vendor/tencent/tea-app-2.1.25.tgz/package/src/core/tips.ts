import { message, notification } from "@tencent/tea-component/lib";
import {
  message as esMessage,
  notification as esNotification,
  MessageProps,
  MessageOptions,
  NotificationOptions,
} from "@tencent/tea-component";
import { sdk } from "../bridge";

let tips;

function show(type: "loading", options: MessageOptions);
function show(
  type: "success" | "warning" | "error",
  options: NotificationOptions
);
function show(type, options) {
  try {
    if (tips) {
      return tips[type](options);
    }
    // 未出现前模拟可隐藏
    let hidden = false;
    const mockHandle = { hide: () => (hidden = true) };
    sdk
      .use("menus-sdk")
      .then(sdk => {
        if (sdk.tips) {
          tips = sdk.tips;
          if (!hidden) {
            const handle = tips[type](options);
            if (typeof handle === "object" && (handle.hide || handle.destroy)) {
              mockHandle.hide = handle.hide || handle.destroy;
            }
          }
        }
      })
      .catch(() => {
        tips = null;
      });
    // 先同步返回后续更新引用
    return {
      hide: () => mockHandle.hide(),
      destroy: () => mockHandle.hide(),
    };
  } catch (err) {
    tips = null;
  }
}

export function initTips() {
  // 判断控制台环境
  if (!window["g_buffet_data"] || !sdk.has("menus-sdk")) {
    return;
  }

  try {
    sdk
      .use("menus-sdk")
      .then(sdk => {
        if (sdk.tips) {
          tips = sdk.tips;
        }
      })
      .catch(() => {});
  } catch (err) {}

  if (esMessage && esMessage["setShowMethod"]) {
    const handler = (
      type: MessageProps["type"],
      { content, ...options }: MessageOptions
    ) => {
      if (type === "loading") {
        return show(type, { content, ...options });
      }
      // 控制台 message 形式只提供 loading
      return show(type, { description: content, ...options });
    };
    message["setShowMethod"](handler);
    esMessage["setShowMethod"](handler);
  }
  if (esNotification && esNotification["setShowMethod"]) {
    notification["setShowMethod"](show);
    esNotification["setShowMethod"](show);
  }
}
