import warning from "warning";
import { lazy } from "react";
import { factory, AppEntry, AppEntryDetail } from "./entry";
import { config } from "./config";
import { getI18NInstance } from "./i18n";
import { initTips } from "./tips";

/**
 * 注册应用路由
 *
 * @param routemap 路由映射，每个路由对应一个路由定义
 *
 * @example
```js
app.routes({
  'cvm': {
    render: () => <CvmIndex />,
  },
  'cvm/overview': {
    render: () => <CvmOverview />,
  }
});
```
 *
 * @todo 支持 React-Hot
 */
export function routes(routemap: AppRouteMap, ...args) {
  warning(
    args.length === 0,
    "导航菜单及样式配置现已移至 yehe，请移除 `app.routes()` 中 `menu` 及 `css` 配置"
  );

  // i18n.init() 要求在 app.routes() 之前执行
  if (!getI18NInstance()) {
    throw new Error(
      "未初始化国际化资源，请在 `app.route()` 之前执行 `i18n.init()`"
    );
  }

  initTips();

  const controllerSet = new Set<string>();

  for (let [route, entry] of Object.entries(routemap)) {
    // 兼容开头包含 / 情况
    route = route.replace(/^\//, "");
    addEntry(route, entry);
  }

  // 提供默认 404 页面
  for (let controller of controllerSet) {
    const route404 = `${controller}/404`;
    if (!routemap[route404]) {
      addEntry(route404, 404);
    }
  }

  function addEntry(route: string, entry: AppEntry) {
    if (!isLowerCase(route)) {
      throw new Error(`路由 ${route} 非法：路由只允许使用小写字母`);
    }
    if (!entry) {
      throw new Error(`路由 ${route} 非法：路由实例为空`);
    }
    if (
      typeof entry !== "function" &&
      typeof entry !== "object" &&
      entry !== 404
    ) {
      throw new Error(
        `路由 ${route} 非法：路由实例只能为 Function、Object 或使用 404 表示页面不存在，此处传入了 ${typeof entry}`
      );
    }
    let [controller, action, ...rest] = route.split("/");
    if (rest.length >= 1) {
      throw new Error(
        `路由 ${route} 非法：只允许注册一级和二级路由，更多级需求请使用模块内路由`
      );
    }
    controllerSet.add(controller);
    // 没提供 action 的，使用 index
    action = action || "index";

    // controllerMode
    if (typeof entry === "object" && (entry as AppEntryDetail).controllerMode) {
      return window.define(
        `modules/${controller}/${controller}`,
        config(factory)(controller, action, entry)
      );
    }

    // 通过控制台的模块约定方式来注册模块
    window.define(
      `modules/${controller}/${action}/${action}`,
      config(factory)(controller, action, entry)
    );
  }
}

function isLowerCase(str: string) {
  return str === str.toLowerCase();
}

/**
 * 路由映射
 */
export interface AppRouteMap {
  [key: string]: AppEntry;
}
