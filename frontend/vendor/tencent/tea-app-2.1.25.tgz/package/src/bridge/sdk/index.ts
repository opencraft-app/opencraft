import { _sdk } from "../_bridge";
import { SDKLoader } from "./SDKLoader";
import { initTips } from "../../core/tips";

/**
 * 提供 SDK 注册和加载接口
 */
export const sdk = {
  /**
   * 注册 SDK
   *
   * @param sdkName SDK 名称
   * @param sdkFactory SDK 工厂方法，应该返回 SDK 提供的 API
   */
  register: (sdkName: string, sdkFactory: () => any) => {
    // 全局 tips 统一使用 menus-sdk
    try {
      if (sdkName !== "menus-sdk") {
        initTips();
      }
      window.define(`sdk/${sdkName}`, sdkFactory);
    } catch (err) {}
  },

  /**
   * 加载并使用指定的 SDK
   *
   * @param sdkName SDK 名称
   */
  use: <T = any>(sdkName: string) => _sdk.use(sdkName) as Promise<T>,

  /**
   * 检查 SDK 是否加载
   *
   * @param sdkName SDK 名称
   */
  has: (sdkName: string) => _sdk && _sdk.has && _sdk.has(sdkName),

  /**
   * SDK 加载组件
   */
  SDKLoader,
};
