import EventEmitter from "eventemitter3";

interface InvalidateEventArgs {
  source: "accountChanged" | "logout";
  /**
   * 账号变化类型，仅在 source="accountChanged" 的时候有值
   * -9:表示开发商发生变化，即用户身份发生变化
   * 其他：表示登录账号发生变化
   */
  changeType?: number;
}

interface UserEventTypes {
  invalidate: [InvalidateEventArgs];
  [x: string]: any[];
}

export class UserEmitter extends EventEmitter<UserEventTypes> {}

export const userEmitter = new UserEmitter();
