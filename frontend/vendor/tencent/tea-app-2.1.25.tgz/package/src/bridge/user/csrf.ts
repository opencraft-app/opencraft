import { _util } from "../_bridge";

export const getAntiCSRFToken = () => String(_util.getACSRFToken());
export const getSessionHash = () => String(_util.getSessionHash());
