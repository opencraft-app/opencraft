import { _manager } from "../_bridge";

export type WhitelistFieldType = 'ownerUin' | 'appid' | 'loginUin';

/**
 * 批量检查用户白名单
 */
export const checkWhitelistBatch = (keys: string[], fieldType?: WhitelistFieldType) =>
  new Promise<{ [key: string]: number }>((resolve, reject) =>
    _manager.queryWhiteList(
      // params
      { whiteKey: keys, whiteField: fieldType },
      // onSuccess
      (result: any) => {
        let ret = {};

        for (let key of keys) {
          ret[key] = (result && result[key] && +result[key][0]) || 0;
        }

        resolve(ret);
      },
      // onError
      (error: any) => reject(Object.assign(new Error(error.msg), error || {}))
    )
  );

/**
 * 检查白名单
 */
export const checkWhitelist = (key: string, fieldType?: WhitelistFieldType) =>
  checkWhitelistBatch([key], fieldType).then(result => result[key]);
