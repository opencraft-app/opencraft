import { _bridge, _buffetStrategyManager } from "./_bridge";

export interface StrategyExecutionInfo {
  strategy: (versions: BuffetStrategyVersions, strategyConfig: BuffetStrategyConfig, bussinessKey: string) => void;
}

export interface BuffetStrategyVersions {
  // 切换到变更单版本
  enterTicketVersion: () => void;

  // 切换到现网版本
  enterMasterVersion: () => void;
}

export interface BuffetStrategyConfig {
  // 策略可选值
  scopes: {
    // 新增一级 default 预留后续可能要支持多维度的策略器
    default: string[];
  },

  // 策略值
  values: {
    default: string[];

    // 发布时选择的百分比
    percentage: number;

    // 发布时填写的灰度 UIN
    uins: any[];

    // 灰度办公网
    internalIp: boolean;
  },

  // 脚本 CDN 地址
  script: string;

  // 当前变更的 Buffet Id
  ticketId?: number;

  // 当前变更的 Buffet GroupId
  groupId?: number;
}

export const buffetStrategy = {
  /**
   * 注册 buffet 灰度策略器
   *
   * @param strategyName
   * @param strategyFactory
   */
  register: (strategyName: string, strategyFactory: () => StrategyExecutionInfo) => {
    const strategyModuleId = `nmc/buffet-strategy/strategies/${strategyName}`;
    window.define(strategyModuleId, () => (bussinessKey: string) => _buffetStrategyManager.add(bussinessKey, {
      ...strategyFactory(),
      strategyName
    }));
  }
};

