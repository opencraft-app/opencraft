import {
  BaseRequest,
  RequestBody,
  RequestHcOptions,
  RequestV3,
  RequestV3Public,
} from "../types/capi";
import { _bridge } from "./_bridge";

const api = _bridge("models/api");

const request: BaseRequest = (body: any, options: any = {}) => {
  options = { tipErr: true, ...options };
  const { tipLoading, ...otherOptions } = options;
  return api.request(body, {
    secure: true,
    global: tipLoading,
    ...otherOptions,
  });
};

const requestV3: RequestV3 = (body: any, options: any = {}) => {
  const { highCapacity } = options;
  return request(body, {
    ...options,
    version: highCapacity ? undefined : 3,
  });
};

const requestV3Public: RequestV3Public = (body: any, options: any = {}) =>
  requestV3(body, options);

export const capi = {
  /** 云 API 请求
   * @deprecated 请求 V2 云 API 接口已废弃，请使用 `requestV3Public` 或 `requestV3` 方法
   * @param body 云 API 请求参数
   * @param options 云 API 请求选项
   */
  request,

  /** 云 API V3 请求
   * @param body 云 API 请求参数
   * @param options 云 API 请求选项
   */
  requestV3,

  /** 云 API V3 请求，使用公有云已经公开的接口，会通过 tencentcloud-sdk-nodejs 进行类型支持。 */
  requestV3Public,

  /** 云 API 批量调用接口 */
  batchRequest<T = any>(
    body: RequestBody[],
    options?: RequestHcOptions
  ): Promise<T>[] {
    return api.batchRequest(body, options);
  },

  /** 提供云 API SSE请求的相关数据
   * 请自行选择合适的方式发送 SSE 请求
   * 推荐使用 fetch-event-stream
   */
  generateSseRequest(
    body: RequestBody,
    options?: RequestHcOptions
  ): {
    url: string;
    body: string;
    method: string;
    headers: Record<string, string>;
  } {
    return api.prepareSSERequest(body, options);
  },
};

export {
  SDK,
  RequestBody,
  RequestOptions,
  RequestV3Options,
  RequestV3Public,
  RequestV3PublicBody,
} from "../types/capi";
