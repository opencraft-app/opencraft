import { useEffect, useMemo } from "react";
import { internalInsightShouldNotUsedByBusiness as _insight } from "../core/insight";
import { FrequencyLimiter } from "../helpers/frequencyLimiter";

const hottagEvent =
  _insight &&
  _insight.register("hottag", {
    level: _insight.EventLevel.Info,
  });

const imageLoadErrorEvent =
  _insight &&
  _insight.register("image-load-error", {
    level: _insight.EventLevel.Error,
  });

const hotTagLimiter = new FrequencyLimiter({ name: "insight.reportHotTag" });
const statLimiter = new FrequencyLimiter({ name: "insight.stat" });
const imageErrorLimiter = new FrequencyLimiter({
  name: "insight.reportImageError",
});
const possibleCostFields = new Set(["timeCost", "cost", "costTime"]);
const taskLevelMap: Record<InsightStat["result"], number> = _insight && {
  success: _insight.EventLevel.Info,
  fail: _insight.EventLevel.Error,
  timeout: _insight.EventLevel.Warn,
};
const taskStatusMap: Record<InsightStat["result"], string> = {
  success: "成功",
  fail: "失败",
  timeout: "超时",
};

export const insight = {
  /**
   * 上报点击流
   * @param tag 点击标识
   */
  reportHotTag(tag: string): void {
    if (typeof _insight !== "object") {
      return;
    }
    if (!tag || !hottagEvent) {
      return;
    }
    hotTagLimiter.exec(() => hottagEvent.push({ hottag: String(tag) }, true));
  },

  /**
   * 上报图片加载错误
   * @param {string} imageUrl 图片 url
   */
  reportImageLoadError(imageUrl: string): void {
    if (typeof _insight !== "object") {
      return;
    }
    if (!imageUrl || !imageLoadErrorEvent) {
      return;
    }
    imageErrorLimiter.exec(() =>
      imageLoadErrorEvent.push({ url: String(imageUrl) }, true)
    );
  },

  /**
   * 自定义上报，如果 ns 和 event 参数不正确，会扔出异常
   *
   * 控制台在预览模式或开发模式不会上报，如果要验证效果，请在手动添加标识到 localStorage:
   *
   * ```js
   * localStorage.debugInsight = true
   * ```
   *
   * 然后刷新页面。
   *
   * @example
   *
    ```js
    import { app } from '@tea/app';

    app.insight.stat({
      ns: 'cvm',
      event: 'restart',
      cost: 996,
      stringFields: {
        instance: 'ins-1d7x8C3s'
      },
      integerFields: {
        instanceCount: 1
      }
    });
  ```
   */
  stat({
    ns,
    event,
    cost,
    result,
    stack,
    integerFields,
    stringFields,
  }: InsightStat) {
    if (typeof _insight !== "object") {
      return;
    }
    if (!ns) throw new Error("ns 不能为空");
    if (!/^[a-zA-Z1-9\/]+$/.test(ns)) {
      throw new Error("ns 只允许包括字母、数字、斜杠");
    } else if (/^\/|\/$/.test(ns)) {
      throw new Error("ns 使用的斜杠不允许出现在首尾");
    }

    if (!event) throw new Error("event 不能为空");
    if (!/^[a-zA-Z1-9\-]+$/.test(event)) {
      throw new Error("event 只允许包括字母、数字、横杠");
    } else if (/^-|-$/.test(event)) {
      throw new Error("event 使用的横杠不允许出现在首尾");
    }

    statLimiter.exec(() => {
      const stat = [ns, event].join(":");
      const data: Record<string, any> = { cost, result };

      let totalLimit = 20;
      if (integerFields) {
        for (let [field, value] of Object.entries(integerFields)) {
          if (typeof value === "number" && !isNaN(value)) {
            if (totalLimit >= 0) {
              totalLimit--;
              data[`int_${field}`] = Math.round(value);
            }
            if (
              typeof data.cost === "undefined" &&
              possibleCostFields.has(field)
            ) {
              data.cost = Math.round(value);
            }
          }
        }
      }
      if (stringFields) {
        for (let [field, value] of Object.entries(stringFields)) {
          if (totalLimit >= 0 && typeof value === "string") {
            totalLimit--;
            data[`str_${field}`] = value.slice(0, 4096);
          }
        }
      }

      if (result && cost) {
        data.level = taskLevelMap[result];
        data.message = `任务 <${stat}> ${taskStatusMap[result]} (cost ${cost} ms)`;
        if (result !== "success" && typeof stack === "string") {
          data.stack = stack;
        }
      }
      _insight.stat(stat, data);
    });
  },

  /** 创建一个统计任务，不马上上报结果。上报结果的时候，报告任务是否成功，并自动统计耗时。如果指定了 timeout，则超时未上报会上报一个 timeout 统计 */
  statTask(task: string, ns: string, timeout?: number) {
    const start = Date.now();
    const trace = _insight.captureTrace(`StatTask <${ns}:${task}>`);
    type StatFields = Pick<InsightStat, "integerFields" | "stringFields">;
    type StatReport = Pick<InsightStat, "stack" | "result"> & StatFields;
    let hasReported = false;
    let timeoutTimer: ReturnType<typeof setTimeout>;
    const report = ({
      result,
      stack,
      stringFields,
      integerFields,
    }: StatReport = {}) => {
      clearTimeout(timeoutTimer);
      if (result !== "timeout") {
        if (hasReported) {
          return;
        }
        hasReported = true;
      }
      const cost = Date.now() - start;
      return insight.stat({
        ns,
        event: task,
        cost,
        result,
        stack: stack
          ? _insight.concatTrace({ message: "", stack }, trace).stack
          : trace.stack,
        integerFields,
        stringFields,
      });
    };
    if (timeout > 0) {
      timeoutTimer = setTimeout(() => report({ result: "timeout" }), timeout);
    }
    return {
      /** 上报任务成功 */
      success: (fields?: StatFields) =>
        report({ ...fields, result: "success" }),
      /** 上报任务失败 */
      fail: (fields?: StatReport) => report({ ...fields, result: "fail" }),
      /** 上报任务终止 */
      abort: () => {
        clearTimeout(timeoutTimer);
        hasReported = true;
      },
    };
  },

  /**
   * 说明：函数组件请使用 usePageReadyStat，会自动在组件销毁时中断上报任务
   * 如果是旧的业务代码使用类组件，请在 componentWillUnmount 的时候手动 abort()
   */
  statPageReady: () => insight.statTask("page-ready", "console", 15000),
};

/** 创建首屏可用统计。业务应尽量提供该上报。在数据全部加载完成，用户已经可操作后上报 success */
export const usePageReadyStat = () => {
  const task = useMemo(insight.statPageReady, []);

  // abort on unmount
  useEffect(() => task.abort, []);

  return task;
};

export interface InsightStat {
  /**
   * 为了不与其他业务的数据冲突，需要制定上报的命名空间，如 "cvm"
   *
   * 命名空间允许使用的字符：字母、数字、斜杠 `/`（不允许出现在首尾），如：
   *
   *  - "cvm2"
   *  - "cvm/sg"
   */
  ns: string;

  /**
   * 本次统计的事件名称
   *
   * 事件名允许使用的字符：字母、数字、横杠 `-`（不允许出现在首尾），如：
   *
   *  - "restart-fail"
   *  - "move2recycle"
   */
  event: string;

  /**
   * 事件所用耗时，可以不占用 integerFields 和 stringFields 额度。
   * 为了兼容以前大部分业务的数据，会尝试从 int_timeCost、int_cost、int_costTime 查找
   */
  cost?: number;

  /** 事件结果 */
  result?: "success" | "fail" | "timeout";

  /** 仅当结果失败或者超时上报。提供统计调用堆栈，方便定位问题 */
  stack?: string;

  /**
   * 自定义数据（整数类型）
   *
   * 如果传入的是不是 number 类型，会被忽略。如果传入的不是整数，会使用 Math.round 取整。
   */
  integerFields?: Record<any, number>;

  /**
   * 自定义数据（字符串类型）
   *
   * 如果传入的不是 string 类型，会被忽略。
   *
   * 单个字段的长度，不能超过 4096，否则会被裁切
   */
  stringFields?: Record<any, string>;
}
