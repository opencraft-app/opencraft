export const _bridge = (moduleName: string) =>
  window.seajs && window.seajs.require(moduleName);
export const _manager = _bridge("manager");
export const _util = _bridge("util");
export const _appUtil = _bridge("appUtil");
export const _sdk = _bridge("nmc/sdk/sdk");
export const _buffetStrategyManager = _bridge(
  "nmc/buffet-strategy/buffet-strategy-manager"
);
