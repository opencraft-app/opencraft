import type { Moment, MomentInput } from "moment";
import moment from "moment";

const LANG_CHINESE = 'zh';
const LANG_ENGLISH = 'en';
const DEFAULT_LANG = LANG_CHINESE; // 默认语种为中文

const FORMAT_ZH = "YYYY-MM-DD HH:mm:ss"; // 中日韩语种格式
const FORMAT_EN = "MMM DD, YYYY HH:mm:ss"; // 英文语种格式


let global_lang: string; // global language


function getCookie(name: string) {
  let arr;
  const reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
  if (arr = document.cookie.match(reg)) {
    return unescape(arr[2]);
  }
  return null;
}

/**
 * 判断是否为UTC时间
 * @param str String
 * @returns boolean
 */
function isUTCDateString(str: string) {

  const date = Date.parse(str);

  if (isNaN(date)) {
    return false;
  }

  return /Z|([+-]\d{2}:\d{2})$/.test(str);
}

/**
 * 将moment对象转换为UTC+8标准时间
 * @param m Moment
 * @example 2023-11-30T20:00:00+08:00
 * @returns string 
 */
function toCNTime(m: Moment) {
  return m.format().replace(/(-|\+)\d{2}:\d{2}$/, "+08:00");
}


class Time {

  // 当前使用的moment
  private tMoment: Moment;

  // 当前语种环境
  private lang: string;

  constructor(t: Moment) {
    this.tMoment = t;
    this.lang = global_lang || getCookie("language") || DEFAULT_LANG;
  }

  /**
   * 获取当前使用的moment对象
   * @example
    ```js
    const moment = app.time.fromBJTime('2023-11-30 20:00:00').getMoment();
    moment.valueOf(); // 1701345600000
    moment.format(); // 2023-11-30T07:00:00-05:00
    ```
   * @returns Moment
   */
  getMoment(): Moment {
    return this.tMoment;
  }

  /**
   * 返回标准时间，语种跟随cookie里的language字段
   * @param withTZ: boolean 是否携带时区
   * zh: 2023-11-30 07:00:00 (UTC-05:00)
   * en: Nov 30, 2023 07:00:00 (UTC-05:00)
   * @returns string
   */
  getFullTime(withTZ?: boolean): string {
    const formatStr = this.lang === LANG_ENGLISH ? FORMAT_EN : FORMAT_ZH;
    if (withTZ) {
      return this.tMoment.format(`${formatStr} (UTCZ)`);
    }

    return this.tMoment.format(formatStr);
  }

  /**
   * 获取当前用户系统的基于UTC标准的时区偏移
   * @example UTC-05:00
   * @returns string
   */
  getOffset(): string {
    return moment().format("UTCZ");
  }

  /**
   * 获取当前用户系统的时区标志
   * @example America/New_York
   * @returns string
   */
  getTimeZone(): string {
    return Intl.DateTimeFormat().resolvedOptions().timeZone;
  }

  /**
   * 将用户时区统一转换为UTC标准时间，用于参数传递
   * @example 2023-11-30T12:00:00Z
   * @returns string
   */
  toUTC(): string {
    return this.tMoment.utc().format();
  }

  /**
   * 将用户时区转换为时间戳，用于参数传递
   * @example 1701392400000
   * @returns number
   */
  toValue(): number {
    return this.tMoment.valueOf();
  }
}


const time = {
  /**
   * 注意：此时的入参为北京时间，或北京时间构造的moment or date对象
   * @param t 北京时间的入参数
   * @returns 基于北京时间的moment对象
   */
  fromBJTime: (t?: MomentInput) => {
    let obj = t;

    // 参数为moment对象的情况下，需拿到moment的入参，进行时区转换
    if (moment.isMoment(t)) {
      obj = moment(toCNTime(t));
    }
    // 参数为string的输入类型，但又不是UTC标准时间的情况下，如"2023-11-30 20:00:00"
    else if (typeof(t) === 'string' && !isUTCDateString(t)) {
      obj = moment(toCNTime(moment(t)));
    }
    // 其他所有类型，包括时间戳，Date对象，统一走moment转换
    else {
      obj = moment(t);
    }
    return new Time(obj);
  },
  
  /**
   * 传递的参数默认为本地时间，此时可以直接使用moment
   * @param t 本地时间的入参
   * @returns 基于用户本地时间的moment对象
   */
  fromLocalTime: (t?: MomentInput) => {
    return new Time(moment.isMoment(t) ? t : moment(t));
  },

  /**
   * 参数为时间戳或者utc时间的情况
   * @param t 时间戳 | utc时间
   * @returns 带时区的moment对象
   */
  from: (t?: MomentInput) => {
    if (typeof(t) === 'number' || (typeof(t) === 'string' && isUTCDateString(t))) {
      return new Time(moment.isMoment(t) ? t : moment(t));
    }
    console.warn('fromTime建议只使用时间戳和utc时间，其他时间格式请根据入参时区选择fromBJTime或fromLocalTime');
    return new Time(moment(t));
  },

  /**
   * 设置语种
   * @param l zh|en|ko|jp
   */
  setLang: (l: string) => {
    global_lang = l;
  }
};


export {
  time,
}