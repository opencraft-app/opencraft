/**
 * 打印异常信息到浏览器控制台
 */
export function logTrace(leadMessage: string, trace) {
  if (console.groupCollapsed) {
    console.groupCollapsed(
      "%c%s",
      "background-color: #fdf0f0; color: red;",
      `${leadMessage}`
    );
  } else {
    console.log(
      "%c%s",
      "background-color: #fdf0f0; color: red;",
      `${leadMessage}`
    );
  }
  console.log(trace.stack);
  if (console.groupEnd) {
    console.groupEnd();
  }
}
