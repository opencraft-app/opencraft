import { i18n } from "./core/i18n";

const { lng, lang, site, country, init, t, Trans, Slot } = i18n;

export default i18n;

// 独立导出 i18n 中业务需要使用到的内容
export { lng, lang, site, country, init, t, Trans, Slot };
