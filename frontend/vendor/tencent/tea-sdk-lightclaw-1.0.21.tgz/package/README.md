# tea-sdk-lightclaw

OpenClaw SDK for Lighthouse console - OpenClaw configuration panel.

## 简介

`@tencent/tea-sdk-lightclaw` 是 OpenClaw AI 助手配置面板 SDK，以 npm 包形式提供，包含：

1. **OpenClawPanel** - 组合面板组件（内置全部子组件的 Tab 布局）
2. **独立子组件** - ModelCard / ChannelCard / SkillCard / TokenUsage / MemoryPlugin / Hospital / ConfigBackup / OpenClawWebUIPanel，可脱离 OpenClawPanel 按业务需要自由组合
3. **OpenClawInfoHeader** - 信息头部组件（Logo + 版本 + 运行状态 + 重启/升级/WebUI 按钮）
4. **Scripts SDK** - 脚本命令生成 + 远程执行
5. **Hooks** - `useOpenClawInternals` / `useOpenClawConfig` 等公共能力 Hook

## 核心架构

所有子组件均为**独立自治**模式——内部自动创建 `scriptCommands`、`executor`、`executeGatewayCommand`、`configData` 等，消费方只需传最小参数集：

```
instance + regionShortName + featureFlags（+ 可选 productConfig / scriptCommands）
```

```
┌──────────────────────────────────────────────────────┐
│                   消费方（宿主应用）                    │
│  传入: instance, regionShortName, featureFlags        │
└──────────┬──────────┬──────────┬──────────┬──────────┘
           │          │          │          │
     ┌─────▼───┐ ┌───▼────┐ ┌──▼───┐ ┌───▼────────┐
     │ModelCard│ │Channel │ │Skill │ │TokenUsage  │ ...
     │         │ │Card    │ │Card  │ │            │
     └────┬────┘ └───┬────┘ └──┬───┘ └───┬────────┘
          │          │          │          │
  ┌───────▼──────────▼──────────▼──────────▼───────┐
  │         useOpenClawInternals (Hook)             │
  │  scriptCommands / executor / gateway commands   │
  └───────────────────┬────────────────────────────┘
                      │
  ┌───────────────────▼────────────────────────────┐
  │         useOpenClawConfig (Hook)                │
  │  configData / loading / restartAndRefresh       │
  │  (ModelCard / ChannelCard / WebUIPanel 使用)     │
  └────────────────────────────────────────────────┘
```

## 快速开始

### 方式一：使用组合面板（OpenClawPanel）

```tsx
import { OpenClawPanel, OpenClawInfoHeader } from '@tencent/tea-sdk-lightclaw';

<OpenClawPanel
  instance={instance}
  regionShortName="gz"
  featureFlags={featureFlags}
  isUpgrading={isUpgrading}
  isDataReady={isDataReady}
  operationDisabledTip={operationDisabledTip}
  webUIModalVisible={webUIModalVisible}
  setWebUIModalVisible={setWebUIModalVisible}
  firewallAdapter={firewallAdapter}
  productConfig={productConfig}  // 可选，默认 lighthouse
/>
```

### 方式二：独立使用子组件（推荐）

```tsx
import { ModelCard, ChannelCard, SkillCard } from '@tencent/tea-sdk-lightclaw';

// 每个组件完全独立，内部自动创建 executor / configData / gateway commands
<ModelCard
  instance={instance}
  regionShortName="gz"
  featureFlags={featureFlags}
  isOperationDisabled={false}
  operationDisabledContent=""
/>

<ChannelCard
  instance={instance}
  regionShortName="gz"
  featureFlags={featureFlags}
  isOperationDisabled={false}
  operationDisabledContent=""
/>

<SkillCard
  instance={instance}
  regionShortName="gz"
  featureFlags={featureFlags}
  isDataReady={true}
  isOperationDisabled={false}
  operationDisabledContent=""
  operationDisabledTip=""
/>
```

### 方式三：纯脚本执行（无 UI）

```typescript
import { createLightClawScripts, createCommandExecutor } from '@tencent/tea-sdk-lightclaw';

const scripts = createLightClawScripts({ regionShortName: 'gz' });
const executor = createCommandExecutor({ instance });

const result = await executor.run({
  command: scripts.gateway.getRestartCommand(),
});
// result => { success: true, output: '...' }
```

## 独立子组件

所有子组件遵循统一的 Props 设计：

### 公共基础参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `instance` | `IInstanceInfo` | 是 | 实例信息（InstanceId + RegionId） |
| `regionShortName` | `string` | 二选一 | 地域简称，如 `'gz'`（组件内部创建 scriptCommands） |
| `scriptCommands` | `LightClawScriptsSDK` | 二选一 | 外部注入 scriptCommands（适用于定制场景） |
| `featureFlags` | `IFeatureFlags` | 是 | 功能特性标志 |
| `productConfig` | `IProductConfig` | 否 | 产品差异化配置（默认 lighthouse） |

### 各组件特有参数

#### ModelCard

| 参数 | 类型 | 说明 |
|------|------|------|
| `isOperationDisabled` | `boolean` | 操作是否禁用 |
| `operationDisabledContent` | `string` | 禁用提示文案 |

> 模型提供商列表由 SDK 内部根据 `productConfig` 和 `instance.Zone` 自动推导，无需外部传入。

#### ChannelCard

| 参数 | 类型 | 说明 |
|------|------|------|
| `isOperationDisabled` | `boolean` | 操作是否禁用 |
| `operationDisabledContent` | `string` | 禁用提示文案 |

#### SkillCard

| 参数 | 类型 | 说明 |
|------|------|------|
| `isDataReady` | `boolean` | 数据是否就绪 |
| `isOperationDisabled` | `boolean` | 操作是否禁用 |
| `operationDisabledContent` | `string` | 禁用提示文案 |
| `operationDisabledTip` | `string` | 禁用提示 |

#### TokenUsage

无额外必填参数，只需公共基础参数。

#### MemoryPlugin

| 参数 | 类型 | 说明 |
|------|------|------|
| `isOperationDisabled` | `boolean` | 操作是否禁用 |

#### Hospital（含 ConfigBackup）

| 参数 | 类型 | 说明 |
|------|------|------|
| `isUpgrading` | `boolean` | 是否正在升级 |
| `isOperationDisabled` | `boolean` | 操作是否禁用 |
| `operationDisabledTip` | `string` | 禁用提示 |

#### OpenClawWebUIPanel

| 参数 | 类型 | 说明 |
|------|------|------|
| `visible` | `boolean` | 面板是否可见 |
| `onClose` | `() => void` | 关闭回调 |
| `firewallAdapter` | `IFirewallAdapter` | 防火墙适配器 |
| `displayBlueprintVersion` | `string` | 当前蓝图版本 |

## Hooks

### useOpenClawInternals

封装 scriptCommands / executor / useGatewayCommand 的公共创建逻辑，所有独立组件内部使用：

```typescript
import { useOpenClawInternals } from '@tencent/tea-sdk-lightclaw';

const {
  scriptCommands,       // 脚本命令生成器
  executor,             // 命令执行器
  productConfig,        // 产品配置（含默认值）
  executeGatewayCommand,// 通用命令执行
  currentAction,        // 当前操作标识
  restartGateway,       // 重启网关
  // ... 更多能力
} = useOpenClawInternals({
  instance,
  regionShortName: 'gz',
  featureFlags,
  productConfig,  // 可选
});
```

### useOpenClawConfig

封装 configData 请求、解析、loading 管理。ModelCard / ChannelCard / WebUIPanel 内部使用：

```typescript
import { useOpenClawConfig } from '@tencent/tea-sdk-lightclaw';

const {
  configData,           // 配置数据 { providers, channels, webUI }
  loading,              // 加载状态
  currentChannelList,   // 当前通道列表
  restartAndRefresh,    // 重启并刷新配置
  refresh,              // 刷新配置
} = useOpenClawConfig({
  instance,
  regionShortName: 'gz',
  featureFlags,
});
```

## 多产品接入

通过 `productConfig` 注入产品差异化配置：

```tsx
import type { IProductConfig } from '@tencent/tea-sdk-lightclaw';

const myConfig: IProductConfig = {
  modelProviders: [...],
  getChannelList: (opts) => [...],
  cosBaseUrl: 'https://my-product-scripts.cos.ap-shanghai.myqcloud.com',

  // 自定义命令执行接口（可选，默认内置 TAT API）
  runCommand: async (data) => {
    // 自定义 RunCommand 实现
    return { InvocationId: '...' };
  },
  getInvocationTask: async (regionId, invocationId, options) => {
    // 自定义轮询实现
    return { TaskStatus: 'SUCCESS', TaskResult: { Output: '...' } };
  },
};

<ModelCard
  instance={instance}
  regionShortName="gz"
  featureFlags={featureFlags}
  productConfig={myConfig}
  ...
/>
```

### productConfig 字段说明

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `modelProviders` | `IModelProvider[]` | 是 | 模型提供商列表 |
| `getChannelList` | `(opts) => IChannelConfig[]` | 是 | 获取通道列表 |
| `cosBaseUrl` | `string` | 是 | COS 脚本基础路径 |
| `getFilteredModelProviders` | `(region?) => IModelProvider[]` | 否 | 地域过滤模型列表 |
| `getTencentApiKey` | `(provider, modelId?) => Promise<string>` | 否 | 腾讯系 API Key 自动获取 |
| `isTencentProvider` | `(value) => boolean` | 否 | 判断是否腾讯系 provider |
| `customJsonPlaceholder` | `string` | 否 | 自定义模型 JSON 占位符 |
| `getChannelPluginName` | `(channelValue, isQQBot?) => string` | 否 | 通道→插件名映射 |
| `openclawVersions` | `IOpenClawVersion[]` | 否 | 镜像版本特性映射 |
| `getNotSupportList` | `(feature) => string[]` | 否 | 根据功能获取不支持的镜像 |
| `isOpenClawBlueprint` | `(blueprint) => boolean` | 否 | 判断是否 OpenClaw 镜像 |
| `localScriptRoot` | `string` | 否 | 本地脚本存放根目录 |
| `ext` | `Record<string, Function>` | 否 | 业务扩展命令 |
| `runCommand` | `(data) => Promise<{ InvocationId? }>` | 否 | 自定义 RunCommand 实现 |
| `getInvocationTask` | `(regionId, id?, opts?) => Promise<IInvocationTask>` | 否 | 自定义 getInvocationTask 实现 |
| `isI18n` | `boolean` | 否 | 是否国际站 |

## 防火墙适配器（IFirewallAdapter）

WebUI 面板需要调用宿主应用的防火墙 API 来检查/放通端口：

```typescript
const firewallAdapter: IFirewallAdapter = {
  checkPort: async (instanceId, regionId, port) => {
    // 返回 true 表示已放通
  },
  openPort: async (instanceId, regionId, port) => {
    // 返回 true 表示放通成功
  },
};
```

## 脚本命令生成

> **远程脚本仓库**：脚本源码维护在 [lightclaw-dashboard/lightclaw](https://git.woa.com/lighthouse/lightclaw-dashboard/tree/master/lightclaw)，SDK 负责生成下载并执行这些脚本的 shell 命令。

```typescript
import { createLightClawScripts } from '@tencent/tea-sdk-lightclaw';

const scripts = createLightClawScripts({ regionShortName: 'gz' });

// 模型
scripts.model.getConfigCommand({ providerName, baseurl, apiKey, api, models });
scripts.model.getApplyCommand({ providerName, modelId });
scripts.model.getDeleteCommand({ providerName });

// 通道
scripts.channel.getConfigCommand(params);
scripts.channel.getTelegramConfigCommand('bot-token');
scripts.channel.getDiscordConfigCommand('token');
// ... 更多通道

// 配置 & 备份
scripts.config.getConfigCommand();
scripts.config.getListBackupCommand();
scripts.config.getManualBackupCommand('remark');
scripts.config.getRollbackCommand('filename');

// Gateway
scripts.gateway.getStatusCommand();
scripts.gateway.getRestartCommand();

// 插件 / 技能 / Token / OAuth / WebUI / 升级 / 诊断
scripts.plugin.getEnableCommand('feishu');
scripts.skill.getListCommand();
scripts.token.getUsageCommand();
scripts.doctor.getDoctorCommand();
scripts.upgrade.getUpgradeCommand(blueprintId, version);
```

## 命令执行器

SDK 内置 TAT API 封装，也支持自定义实现：

```typescript
import { createCommandExecutor } from '@tencent/tea-sdk-lightclaw';

// 默认：使用内置 TAT API
const executor = createCommandExecutor({ instance });

// 自定义：注入自己的实现（通过 productConfig 配置）
const executor = createCommandExecutor({
  instance,
  runCommand: myRunCommand,
  getInvocationTask: myGetInvocationTask,
});

// 普通执行
const result = await executor.run({ command: '...', timeout: 60 });

// 流式执行（长时间命令）
const result = await executor.runWithProgress({
  command: '...',
  timeout: 1800,
  onProgress: (output) => console.log(output),
});
```

## API 参考

### 顶层导出

| 导出 | 说明 |
|------|------|
| `OpenClawPanel` | 组合配置面板（内置全部子组件） |
| `ModelCard` / `ChannelCard` / `SkillCard` / `TokenUsage` / `MemoryPlugin` / `Hospital` / `ConfigBackup` | 独立子组件 |
| `OpenClawWebUIPanel` | WebUI 面板（可独立使用） |
| `OpenClawInfoHeader` | 信息头部组件 |
| `createLightClawScripts(config)` | 创建脚本命令生成器 |
| `createCommandExecutor(config)` | 创建命令执行器 |
| `createLighthouseConfig()` | 创建 Lighthouse 默认产品配置 |
| `useOpenClawInternals(props)` | 公共能力 Hook（scriptCommands / executor / gateway） |
| `useOpenClawConfig(params)` | 配置数据 Hook（configData / loading / refresh） |

### 类型导出

| 类型 | 说明 |
|------|------|
| `IProductConfig` | 产品差异化配置 |
| `IOpenClawComponentBaseProps` | 独立组件公共 Props 基类 |
| `IFeatureFlags` | 功能特性标志 |
| `IInstanceInfo` | 实例信息 |
| `IFirewallAdapter` | 防火墙适配器接口 |
| `ICommandExecutor` / `ICommandExecutorConfig` | 命令执行器类型 |
| `ICustomRunCommand` / `ICustomGetInvocationTask` | 自定义命令接口类型 |
| `ModelCardProps` / `ChannelCardProps` / `SkillCardProps` / ... | 各子组件 Props 类型 |

## 开发

```bash
npm install       # 安装依赖
npm run dev        # 启动开发服务（端口 8969）
npm run build      # 构建
npm run publish    # 构建 + 版本号 +1 + 发布（需要 tnpm）
```

## 目录结构

```
src/
├── common/                    # 公共模块
│   ├── components/            # 公共组件（OpenClawOpsCards 等）
│   ├── config/                # 产品配置层
│   │   ├── types.ts           # IProductConfig / IModelProvider / IFirewallAdapter 等
│   │   ├── defaultProductConfig.ts  # createLighthouseConfig()
│   │   └── index.ts
│   ├── hooks/                 # 自定义 Hooks
│   │   ├── useOpenClawInternals.ts  # 公共能力（scriptCommands / executor / gateway）
│   │   ├── useOpenClawConfig.ts     # 配置数据（configData / loading）
│   │   ├── useGatewayCommand.ts     # 网关命令执行
│   │   └── useThemeManager.ts       # 主题管理
│   ├── model.ts               # TAT / Lighthouse API 封装
│   └── utils/                 # 工具函数
├── components/                # 业务组件
│   ├── OpenClawPanel/         # 组合面板 + 全部独立子组件
│   │   ├── index.tsx          # 组合面板（Tab 布局容器）
│   │   ├── ModelCard.tsx      # 模型配置（独立，内部 useOpenClawConfig）
│   │   ├── ChannelCard.tsx    # 通道配置（独立，内部 useOpenClawConfig）
│   │   ├── SkillCard.tsx      # 技能配置（独立，内部 useOpenClawInternals）
│   │   ├── TokenUsage.tsx     # Token 用量（独立，内部 useOpenClawInternals）
│   │   ├── MemoryPlugin.tsx   # 记忆管理（独立，内部 useOpenClawInternals）
│   │   ├── Hospital.tsx       # 龙虾医院（独立，内部 useOpenClawInternals）
│   │   ├── ConfigBackup.tsx   # 配置备份（独立，内部 useOpenClawInternals + useOpenClawConfig）
│   │   ├── OAuthModal.tsx     # OAuth 弹窗（props 驱动）
│   │   ├── QrCodeModal.tsx    # 扫码弹窗（props 驱动）
│   │   └── ConfirmModals.tsx  # 确认弹窗（组件内部自管）
│   ├── OpenClawInfoHeader/    # 信息头部
│   └── OpenClawWebUIPanel/    # WebUI 面板（独立，内部 useOpenClawConfig + useOpenClawInternals）
├── scripts/                   # Scripts SDK（纯 TS，无框架依赖）
│   ├── commands/              # 命令模块（model / channel / config / gateway / ...）
│   ├── executor.ts            # 命令执行器（支持自定义 runCommand / getInvocationTask）
│   ├── create-scripts.ts      # Scripts SDK 工厂函数
│   └── script-paths.ts        # 脚本路径管理
└── index.ts                   # npm 包入口
```

## License

UNLICENSED
