/**
 * LightClaw Scripts SDK - 核心工厂函数
 *
 * 创建一个绑定了特定地域的 SDK 实例，提供所有命令生成功能
 *
 * @example
 * ```ts
 * import { app } from '@tencent/tea-app'
 *
 * const lightclawSdk = app.sdk.use('lightclaw-sdk')
 *
 * // 创建 Scripts SDK 实例（OpenClaw，默认）
 * const scripts = lightclawSdk.createScripts({ regionShortName: 'gz' })
 *
 * // 使用模型命令
 * const modelCmd = scripts.model.getConfigCommand({
 *   providerName: 'openai',
 *   baseurl: 'https://api.openai.com/v1',
 *   apiKey: 'sk-xxx',
 *   api: 'openai-completions',
 *   models: [{ modelId: 'gpt-4', modelName: 'GPT-4' }],
 * })
 *
 * // 创建 Hermes SDK 实例
 * const hermesSdk = lightclawSdk.createScripts({ regionShortName: 'gz', agentType: 'hermes' })
 *
 * // 使用 hermes 命名空间（与 openclaw 的 model/channel/skill/gateway 并列）
 * const hermesModelCmd = hermesSdk.hermes.model.getConfigCommand({
 *   modelId: 'gpt-4',
 *   providerName: 'openai',
 *   baseUrl: 'https://api.openai.com/v1',
 *   apiKey: 'sk-xxx',
 * })
 * ```
 */
import type { IOpenClawSDKConfig } from './types';
import type { ScriptPaths } from './script-paths';
import type { ModelCommands, ChannelCommands, ConfigCommands, GatewayCommands, PluginCommands, SkillCommands, TokenCommands, OAuthCommands, WebUICommands, UpgradeCommands, DoctorCommands, HermesModelCommands, HermesChannelCommands, HermesSkillCommands, HermesGatewayCommands } from './commands';
/**
 * Hermes 命令命名空间
 *
 * 仅当 agentType === 'hermes' 时所有字段才被填充；
 * agentType === 'openclaw' 时字段仍存在（便于组件层无需分支类型判断），
 * 但调用前应通过 productConfig.agentType 判断是否使用。
 */
export interface HermesScriptsNamespace {
    readonly model: HermesModelCommands;
    readonly channel: HermesChannelCommands;
    readonly skill: HermesSkillCommands;
    readonly gateway: HermesGatewayCommands;
}
/** LightClaw Scripts SDK 实例类型 */
export interface LightClawScriptsSDK {
    /** 地域简称 */
    readonly regionShortName: string;
    /** 所有脚本路径（OpenClaw 使用） */
    readonly paths: ScriptPaths;
    /** OpenClaw 模型相关命令 */
    readonly model: ModelCommands;
    /** OpenClaw 通道相关命令 */
    readonly channel: ChannelCommands;
    /** OpenClaw 配置相关命令 */
    readonly config: ConfigCommands;
    /** OpenClaw Gateway 相关命令 */
    readonly gateway: GatewayCommands;
    /** OpenClaw 插件相关命令 */
    readonly plugin: PluginCommands;
    /** OpenClaw Skill 相关命令 */
    readonly skill: SkillCommands;
    /** Token 统计相关命令（OpenClaw/Hermes 共用） */
    readonly token: TokenCommands;
    /** OAuth 相关命令（仅 OpenClaw） */
    readonly oauth: OAuthCommands;
    /** WebUI 相关命令 */
    readonly webui: WebUICommands;
    /** 升级相关命令 */
    readonly upgrade: UpgradeCommands;
    /** Doctor 诊断修复相关命令 */
    readonly doctor: DoctorCommands;
    /**
     * Hermes 专属命名空间（harness CLI 命令）
     * 只在 agentType === 'hermes' 时使用；其他情况下字段依然存在（便于类型一致），
     * 但组件层应判断 productConfig.agentType 后再调用。
     */
    readonly hermes: HermesScriptsNamespace;
}
/**
 * 创建 LightClaw Scripts SDK 实例
 *
 * @param config SDK 配置
 * @returns SDK 实例
 */
export declare function createLightClawScripts(config: IOpenClawSDKConfig): LightClawScriptsSDK;
