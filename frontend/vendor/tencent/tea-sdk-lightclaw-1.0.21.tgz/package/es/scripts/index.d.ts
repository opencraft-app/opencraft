/**
 * LightClaw Scripts SDK - 对外导出入口
 *
 * 纯 TypeScript 实现，无任何框架依赖（无 React、无 Vue 等）
 *
 * @example
 * ```ts
 * import { createLightClawScripts, createCommandExecutor } from '@tencent/tea-sdk-lightclaw';
 *
 * // 创建 Scripts SDK 实例
 * const scripts = createLightClawScripts({ regionShortName: 'gz' })
 * const cmd = scripts.model.getConfigCommand({ providerName: 'openai', ... })
 *
 * // 创建执行器
 * const executor = createCommandExecutor({ instance })
 * const result = await executor.run({ command: cmd })
 * ```
 */
export { SCRIPT_PATHS, getScriptPaths, getScriptPath, getOpenClawCosBase, getYuanbaoScriptUrl, getLineScriptUrl, downloadAndRun, } from './script-paths';
export type { ScriptKey, ScriptPaths, IScriptPathsOptions } from './script-paths';
export type { IScriptInfo, IOpenClawSDKConfig } from './types';
export type { ModelCommands, IModelConfigParams, IApplyModelParams, IDeleteProviderParams, ChannelCommands, IChannelConfigParams, IWecomAgentParams, ConfigCommands, GatewayCommands, PluginCommands, SkillCommands, TokenCommands, ITokenUsageOptions, OAuthCommands, IOAuthProvider, IOAuthProviderConfig, IOAuthProviderModel, WebUICommands, UpgradeCommands, } from './commands';
export { createModelCommands, createChannelCommands, createConfigCommands, createGatewayCommands, createPluginCommands, createSkillCommands, createTokenCommands, createOAuthCommands, createWebUICommands, createUpgradeCommands, } from './commands';
export { parseOAuthOutput } from './commands';
export { GATEWAY_STATUS, UPGRADE_STATUS, UPGRADE_STAGE_MAP, CHANNEL_PLUGIN_MAP } from './commands';
export { createLightClawScripts } from './create-scripts';
export type { LightClawScriptsSDK } from './create-scripts';
export { createCommandExecutor } from './executor';
export type { IExecuteInstance, ICommandExecutorConfig, IExecuteCommandOptions, IExecuteCommandWithProgressOptions, ICommandResult, ICommandExecutor, } from './executor';
