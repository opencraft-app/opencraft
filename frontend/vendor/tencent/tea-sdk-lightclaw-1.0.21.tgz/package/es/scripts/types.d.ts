/**
 * LightClaw Scripts SDK - 基础类型定义
 */
/** Agent 类型 */
export declare type AgentType = 'openclaw' | 'hermes';
/** SDK 初始化配置 */
export interface IOpenClawSDKConfig {
    /** 地域简称，如 'gz'、'sh'、'bj'、'hk' 等 */
    regionShortName: string;
    /** COS 脚本基础路径（可选），不传则使用默认值 */
    cosBaseUrl?: string;
    /** 本地脚本存放根目录（可选），不传则使用默认值 '$HOME/openclaw_scripts' */
    localScriptRoot?: string;
    /**
     * Agent 类型（可选，默认 'openclaw'）
     * - 'openclaw'：返回 openclaw 脚本命令（走 downloadAndRun 下载 COS 脚本）
     * - 'hermes'：返回 harness CLI 命令（直接下发 `harness xxx`）
     */
    agentType?: AgentType;
}
/** 脚本路径信息 */
export interface IScriptInfo {
    /** 远程 COS URL */
    url: string;
    /** 本地路径 */
    local: string;
}
