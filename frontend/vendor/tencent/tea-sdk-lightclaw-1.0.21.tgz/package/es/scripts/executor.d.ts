/**
 * LightClaw Scripts SDK - 远程命令执行器
 *
 * 提供在远程实例上执行脚本命令的公共函数，纯 TS 实现，无框架依赖。
 * 默认使用内置 RunCommand / getInvocationTask，也支持用户注入自定义实现。
 *
 * @example
 * ```ts
 * // 使用内置 TAT API（默认）
 * const executor = createCommandExecutor({ instance });
 *
 * // 使用自定义接口
 * const executor = createCommandExecutor({
 *   instance,
 *   runCommand: myRunCommand,
 *   getInvocationTask: myGetInvocationTask,
 * });
 *
 * const result = await executor.run({ command: scripts.gateway.getRestartCommand() });
 * ```
 */
import type { IRunCommandParams, IInvocationTask, IPollingOptions } from '../common/model';
/** 实例信息（执行命令所需的最小字段） */
export interface IExecuteInstance {
    InstanceId: string;
    RegionId: number;
    PlatformType?: string;
}
/**
 * 自定义 RunCommand 接口签名
 *
 * 与内置 RunCommand 保持一致：接收命令参数，返回包含 InvocationId 的结果。
 */
export declare type ICustomRunCommand = (data: IRunCommandParams) => Promise<{
    InvocationId?: string;
}>;
/**
 * 自定义 getInvocationTask 接口签名
 *
 * 与内置 getInvocationTask 保持一致：传入 regionId + invocationId，轮询并返回任务结果。
 */
export declare type ICustomGetInvocationTask = (regionId: number, invocationId?: string, options?: IPollingOptions) => Promise<IInvocationTask>;
/** 创建执行器的配置 */
export interface ICommandExecutorConfig {
    /** 目标实例 */
    instance: IExecuteInstance;
    /**
     * 自定义 RunCommand 实现（可选）
     * 不传则使用内置 TAT API 封装
     */
    runCommand?: ICustomRunCommand;
    /**
     * 自定义 getInvocationTask 实现（可选）
     * 不传则使用内置轮询逻辑
     */
    getInvocationTask?: ICustomGetInvocationTask;
    /**
     * 以指定用户名下发命令（对应 TAT RunCommand 的 Username 字段）
     * - 不传：以镜像默认用户执行（通常 root）
     * - Hermes 镜像传 'agentuser'
     *
     * 作用于本 executor 发出的所有命令；单次调用可通过 IExecuteCommandOptions.runAs 覆盖。
     */
    runAs?: string;
}
/** 执行命令选项 */
export interface IExecuteCommandOptions {
    /** 要执行的命令字符串 */
    command: string;
    /** 超时时间（秒），默认 60 */
    timeout?: number;
    /**
     * 单次调用以指定用户名下发命令（覆盖 executor 创建时的 runAs）
     * 传空字符串 '' 则显式清空（以镜像默认用户执行）
     */
    runAs?: string;
}
/** 流式执行命令选项 */
export interface IExecuteCommandWithProgressOptions extends IExecuteCommandOptions {
    /** 进度回调，轮询中每次返回当前输出（已 Base64 解码） */
    onProgress?: (output: string) => void;
    /** 最大轮询次数，默认 180（约 3 分钟） */
    maxRetries?: number;
}
/** 命令执行结果 */
export interface ICommandResult {
    /** 是否成功 */
    success: boolean;
    /** 命令输出（已 Base64 解码并 trim） */
    output: string;
}
/** 命令执行器实例 */
export interface ICommandExecutor {
    /** 执行一条命令（等待完成后返回） */
    run: (options: IExecuteCommandOptions) => Promise<ICommandResult>;
    /** 流式执行一条命令（轮询中实时回调输出） */
    runWithProgress: (options: IExecuteCommandWithProgressOptions) => Promise<ICommandResult>;
}
/**
 * 创建命令执行器
 *
 * @param config 执行器配置
 * @param config.instance 目标实例（必传）
 * @param config.runCommand 自定义 RunCommand 实现（可选，默认内置 TAT API）
 * @param config.getInvocationTask 自定义 getInvocationTask 实现（可选，默认内置轮询）
 * @returns 命令执行器实例，提供 run 和 runWithProgress 两种执行方式
 */
export declare function createCommandExecutor(config: ICommandExecutorConfig): ICommandExecutor;
