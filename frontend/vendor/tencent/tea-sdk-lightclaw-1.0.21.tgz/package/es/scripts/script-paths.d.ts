/**
 * LightClaw Scripts SDK - 脚本路径管理
 *
 * 远程脚本源码仓库：https://git.woa.com/lighthouse/lightclaw-dashboard/tree/master/lightclaw
 */
import type { IScriptInfo } from './types';
/** 脚本相对路径映射表 */
export declare const SCRIPT_PATHS: {
    readonly ADD_MODEL: "model/add_model.sh";
    readonly APPLY_MODEL: "model/apply_model.sh";
    readonly DELETE_MODEL: "model/delete_model.sh";
    readonly OAUTH_MODEL: "model/openclaw_oauth.py";
    readonly ADD_CHANNEL: "channel/add_channel.sh";
    readonly DELETE_CHANNEL: "channel/delete_channel.sh";
    readonly ADD_FEISHU: "channel/feishu/feishu_bot_creator.py";
    readonly GET_LINE_UID: "channel/line/get_line_uid.sh";
    readonly ADD_LINE: "channel/line/line_webhook.py";
    readonly ADD_WECOM: "channel/wecom/add_wecom_channel.sh";
    readonly ADD_WHATSAPP: "channel/whatsapp/whatsapp_bot_creator.py";
    readonly ADD_WEIXIN: "channel/weixin/weixin_bot_creator.py";
    readonly YUANBAO_BOT_CREATOR: "channel/yuanbao/yuanbao_bot_creator.py";
    readonly BACKUP_CONFIG: "config/backup_config.sh";
    readonly GET_CONFIG: "config/get_config.sh";
    readonly CHECK_WEIXIN: "config/check_weixin_channel.sh";
    readonly CHECK_GATEWAY: "gateway/check_gateway.sh";
    readonly RESTART_GATEWAY: "gateway/restart_gateway.sh";
    readonly PLUGIN: "plugin/plugin.sh";
    readonly INSTALL_SKILL: "skills/install_skill.sh";
    readonly LIST_SKILLS: "skills/list_skills.sh";
    readonly GET_UPGRADE_STAGE: "upgrade/get_upgrade_stage.sh";
    readonly GET_UPGRADE_STATUS: "upgrade/get_upgrade_status.sh";
    readonly GET_UPGRADE_VERSION: "upgrade/get_upgrade_version.sh";
    readonly CHECK_DISK_SPACE: "upgrade/check_disk_space.sh";
    readonly UPGRADE: "upgrade/upgrade.sh";
    readonly DOCTOR: "webui/doctor/doctor.sh";
    readonly MODIFY_PORT_BASE_PATH: "webui/modify_port_base_path.py";
    readonly START_WEBUI: "webui/start_webui.sh";
    readonly TOKEN_USAGE_REPORT: "webui/token_usage/token_usage_report.py";
};
export declare type ScriptKey = keyof typeof SCRIPT_PATHS;
export declare type ScriptPaths = Record<ScriptKey, IScriptInfo>;
/** 脚本路径配置选项 */
export interface IScriptPathsOptions {
    /** COS 脚本基础路径，不传则使用默认值 */
    cosBaseUrl?: string;
    /** 本地脚本存放根目录，不传则使用默认值 */
    localScriptRoot?: string;
}
/**
 * 根据地域简称获取 COS 基础路径
 * @param regionShortName 地域简称
 * @param cosBaseUrl COS 基础路径（可选，不传则使用默认值）
 */
export declare const getOpenClawCosBase: (regionShortName: string, cosBaseUrl?: string) => string;
/**
 * 获取所有脚本的远程 URL 和本地路径
 * @param regionShortName 地域简称
 * @param options 脚本路径配置选项（cosBaseUrl / localScriptRoot）
 */
export declare function getScriptPaths(regionShortName: string, options?: IScriptPathsOptions): ScriptPaths;
/**
 * 获取单个脚本的路径信息
 * @param regionShortName 地域简称
 * @param scriptKey 脚本键名
 * @param options 脚本路径配置选项（cosBaseUrl / localScriptRoot）
 */
export declare function getScriptPath(regionShortName: string, scriptKey: ScriptKey, options?: IScriptPathsOptions): IScriptInfo;
/** 获取元宝脚本 URL */
export declare const getYuanbaoScriptUrl: (regionShortName: string, options?: IScriptPathsOptions) => string;
/** 获取 LINE 脚本 URL */
export declare const getLineScriptUrl: (regionShortName: string, options?: IScriptPathsOptions) => string;
/** 生成「下载远程脚本到本地并执行」的命令模板 */
export declare const downloadAndRun: (script: IScriptInfo, args?: string) => string;
