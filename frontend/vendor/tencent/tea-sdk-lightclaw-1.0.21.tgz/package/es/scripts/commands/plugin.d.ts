/**
 * LightClaw Scripts SDK - Plugin 命令模块
 *
 * 提供插件启用/禁用/状态查询相关的命令生成功能
 * 对应 SCRIPT_PATHS: PLUGIN
 */
/**
 * 创建插件命令生成器
 * @param regionShortName 地域简称
 */
export declare function createPluginCommands(regionShortName: string): {
    /**
     * 获取启用插件命令
     */
    getEnableCommand(pluginName: string): string;
    /**
     * 获取禁用插件命令
     */
    getDisableCommand(pluginName: string): string;
    /**
     * 获取插件状态命令
     */
    getStatusCommand(pluginName: string): string;
};
export declare type PluginCommands = ReturnType<typeof createPluginCommands>;
