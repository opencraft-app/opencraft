/**
 * LightClaw Scripts SDK - Doctor 命令模块
 *
 * 提供 OpenClaw 诊断修复相关的命令生成功能
 * 对应 SCRIPT_PATHS: DOCTOR
 */
/**
 * 创建 Doctor 命令生成器
 * @param regionShortName 地域简称
 */
export declare function createDoctorCommands(regionShortName: string): {
    /**
     * 获取 Doctor 诊断修复命令
     */
    getDoctorCommand(): string;
};
export declare type DoctorCommands = ReturnType<typeof createDoctorCommands>;
