/**
 * LightClaw Scripts SDK - Upgrade 命令模块
 *
 * 提供热更新相关的命令生成功能
 * 对应 SCRIPT_PATHS: UPGRADE, GET_UPGRADE_STAGE, GET_UPGRADE_STATUS, GET_UPGRADE_VERSION
 */
export declare const UPGRADE_STAGE_MAP: Record<string, string>;
export declare const UPGRADE_STATUS: {
    readonly PROGRESSING: "PROGRESSING";
    readonly COMPLETED: "COMPLETED";
    readonly FAILED: "FAILED";
    readonly UNKNOWN: "UNKNOWN";
};
/**
 * 创建升级命令生成器
 * @param regionShortName 地域简称
 */
export declare function createUpgradeCommands(regionShortName: string): {
    /**
     * 获取热更新命令
     * @param blueprintId 蓝图 ID
     * @param version 目标版本
     */
    getUpgradeCommand(blueprintId: string, version: string): string;
    /**
     * 获取升级阶段查询命令
     */
    getStageCommand(): string;
    /**
     * 获取升级状态查询命令
     */
    getStatusCommand(): string;
    /**
     * 获取版本查询命令
     */
    getVersionCommand(): string;
    /**
     * 获取磁盘剩余空间查询命令（返回根分区可用 MB 数）
     */
    getDiskSpaceCommand(): string;
};
export declare type UpgradeCommands = ReturnType<typeof createUpgradeCommands>;
