/**
 * LightClaw Scripts SDK - Token 命令模块
 *
 * 提供 Token 用量统计相关的命令生成功能
 * 对应 SCRIPT_PATHS: TOKEN_USAGE_REPORT
 */
/** Token 用量报告选项 */
export interface ITokenUsageOptions {
    /** 开始日期 (YYYY-MM-DD) */
    start?: string;
    /** 结束日期 (YYYY-MM-DD) */
    end?: string;
    /** 天数（与 start/end 二选一） */
    days?: number;
    /** 时区 */
    timezone?: string;
}
/**
 * 创建 Token 命令生成器
 * @param regionShortName 地域简称
 */
export declare function createTokenCommands(regionShortName: string): {
    /**
     * 获取 Token 用量报告命令
     */
    getUsageCommand(options?: ITokenUsageOptions): string;
};
export declare type TokenCommands = ReturnType<typeof createTokenCommands>;
