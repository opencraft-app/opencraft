/**
 * LightClaw Scripts SDK - Model 命令模块
 *
 * 提供模型相关的命令生成功能
 */
/** 模型配置参数 */
export interface IModelConfigParams {
    /** 提供商名称，如 'openai'、'anthropic'、'hunyuan' */
    providerName: string;
    /** API 基础 URL */
    baseurl: string;
    /** 模型列表 */
    models: Array<{
        modelId: string;
        modelName: string;
        input?: string[];
    }>;
    /** API Key */
    apiKey: string;
    /** API 类型，如 'openai-completions', 'anthropic-messages' */
    api: string;
    /** 是否包含 compat 配置（OpenAI 协议自定义模型需要） */
    includeCompat?: boolean;
}
/** 应用模型参数 */
export interface IApplyModelParams {
    /** 提供商名称 */
    providerName: string;
    /** 模型 ID */
    modelId: string;
}
/** 删除模型提供商参数 */
export interface IDeleteProviderParams {
    /** 提供商名称 */
    providerName: string;
    /** 是否清理 auth-profiles.json */
    cleanAuthProfile?: boolean;
}
/**
 * 创建模型命令生成器
 * @param regionShortName 地域简称
 */
export declare function createModelCommands(regionShortName: string): {
    /**
     * 获取模型配置命令
     * 用于添加/更新模型提供商配置到 openclaw.json
     *
     * @param params 模型配置参数
     * @returns 可执行的 shell 命令
     *
     * @example
     * ```ts
     * const cmd = model.getConfigCommand({
     *   providerName: 'openai',
     *   baseurl: 'https://api.openai.com/v1',
     *   apiKey: 'sk-xxx',
     *   api: 'openai-completions',
     *   models: [{ modelId: 'gpt-4', modelName: 'GPT-4', input: ['text', 'image'] }]
     * })
     * ```
     */
    getConfigCommand(params: IModelConfigParams): string;
    /**
     * 获取应用模型命令
     * 用于切换当前激活的模型
     *
     * @param params 应用模型参数
     * @returns 可执行的 shell 命令
     */
    getApplyCommand(params: IApplyModelParams): string;
    /**
     * 获取删除模型提供商命令
     *
     * @param params 删除提供商参数
     * @returns 可执行的 shell 命令
     */
    getDeleteCommand(params: IDeleteProviderParams): string;
};
export declare type ModelCommands = ReturnType<typeof createModelCommands>;
