/**
 * LightClaw Scripts SDK - Skill 命令模块
 *
 * 提供 Skill 安装和列表查询相关的命令生成功能
 * 对应 SCRIPT_PATHS: INSTALL_SKILL, LIST_SKILLS
 */
/**
 * 创建 Skill 命令生成器
 * @param regionShortName 地域简称
 */
export declare function createSkillCommands(regionShortName: string): {
    /**
     * 获取 Skills 列表命令
     */
    getListCommand(): string;
    /**
     * 获取安装 Skill 命令
     */
    getInstallCommand(skill: string): string;
};
export declare type SkillCommands = ReturnType<typeof createSkillCommands>;
