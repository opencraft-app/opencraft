/**
 * LightClaw Scripts SDK - OAuth 命令模块
 *
 * 提供 OAuth 授权相关的命令生成功能
 */
/** OAuth 提供商模型配置 */
export interface IOAuthProviderModel {
    id: string;
    name: string;
    input?: string[];
}
/** OAuth 提供商配置 */
export interface IOAuthProviderConfig {
    baseUrl: string;
    api: string;
}
/** OAuth 提供商信息 */
export interface IOAuthProvider {
    /** 唯一标识，用于 Select/Cascader 的 value */
    value: string;
    /** 分类：coding_plan 为 Coding Plan 订阅模式，api 为直接 API 调用模式 */
    category: 'coding_plan' | 'api';
    /** 底层 provider 标识，用于写入 openclaw.json 配置 */
    provider: string;
    /** 显示名称（已国际化） */
    provider_name: string;
    /** 描述信息（可含 HTML） */
    description: string;
    /** API Key 获取地址 */
    api_key_url: string;
    /** API 基础地址 */
    base_url: string;
    /** API 协议类型，如 'openai-completions' | 'anthropic-messages' */
    api: string;
    /** 该提供商支持的模型列表 */
    models: Array<{
        id: string;
        name: string;
        input?: string[];
    }>;
    /** OAuth 授权配置（存在则支持 OAuth） */
    oauth?: {
        /** 脚本 init/poll 的 provider 参数（如 'codex'） */
        provider: string;
        /** gateway 生成的 models.json 中的 provider key（如 'openai-codex'），用于 parseConfigResult 匹配 */
        openclawProvider: string;
        /** 是否需要用户回填回调 URL（Authorization Code Flow） */
        requireCallbackUrl?: boolean;
        /** 是否为纯 OAuth 模式（不支持 API Key） */
        exclusive?: boolean;
        /** 写入 openclaw.json 的 provider 配置 */
        providerConfig?: {
            baseUrl: string;
            api: string;
        };
        /** 删除时是否需要清理 auth-profiles.json */
        cleanAuthProfile?: boolean;
        /** init 命令额外参数（如 'cn'），拼接在 provider 之后 */
        initArgs?: string;
        /** poll 命令固定参数（当 requireCallbackUrl=false 时替代回调 URL） */
        pollArgs?: string;
        /** OAuth 专属模型列表（写入 openclaw.json 时使用，不同于 providerInfo.models） */
        models?: Array<{
            id: string;
            name: string;
            input?: string[];
        }>;
    };
}
/**
 * 创建 OAuth 命令生成器
 * @param regionShortName 地域简称
 */
export declare function createOAuthCommands(regionShortName: string): {
    /**
     * 获取 OAuth 初始化命令
     * 下载脚本并获取授权 URL
     *
     * @param oauthProvider OAuth 提供商名称（如 'codex'）
     * @param initArgs 可选的额外参数
     */
    getInitCommand(oauthProvider: string, initArgs?: string): string;
    /**
     * 获取 OAuth 轮询命令
     * 用回调 URL 换取 token
     *
     * @param oauthProvider OAuth 提供商名称
     * @param callbackUrl 回调 URL
     */
    getPollCommand(oauthProvider: string, callbackUrl: string): string;
    /**
     * 获取 OAuth 应用 Provider 命令
     * OAuth 成功后，将 provider 配置写入 openclaw.json
     *
     * @param providerInfo Provider 信息（models 由调用方做 oauth.models || provider.models fallback）
     */
    getApplyProviderCommand(providerInfo: IOAuthProvider): string;
};
export declare type OAuthCommands = ReturnType<typeof createOAuthCommands>;
/**
 * 从脚本多行 JSON 输出中查找指定 action 的记录
 */
export declare function parseOAuthOutput(output: string, action: string): Record<string, unknown> | null;
