/**
 * LightClaw Scripts SDK - WebUI 命令模块
 *
 * 提供 WebUI 相关的命令生成功能
 * 对应 SCRIPT_PATHS:  MODIFY_PORT_BASE_PATH, START_WEBUI
 */
/**
 * 创建 WebUI 命令生成器
 * @param regionShortName 地域简称
 */
export declare function createWebUICommands(regionShortName: string): {
    /**
     * 获取修改 WebUI 端口和 basePath 命令
     */
    getModifyPortCommand(): string;
    /**
     * 获取启动 WebUI 命令
     */
    getStartCommand(): string;
};
export declare type WebUICommands = ReturnType<typeof createWebUICommands>;
