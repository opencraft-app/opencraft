/**
 * LightClaw Scripts SDK - Channel 命令模块
 *
 * 提供通道配置相关的命令生成功能
 */
/** 通用通道配置参数 */
export interface IChannelConfigParams {
    /** 通道类型 */
    channel: string;
    /** 通道 ID 字段名 */
    channelIdName: string;
    /** 通道 ID 值 */
    channelIdValue: string;
    /** 通道密钥字段名 */
    channelKeyName: string;
    /** 通道密钥值 */
    channelKeyValue: string;
}
/** 企业微信应用模式专用参数 */
export interface IWecomAgentParams {
    /** 企业 ID */
    corpId: string;
    /** 应用密钥 */
    corpSecret: string;
    /** 应用 ID */
    agentId: string;
    /** Token */
    token: string;
    /** EncodingAESKey */
    encodingAESKey: string;
}
/**
 * 创建通道命令生成器
 * @param regionShortName 地域简称
 */
export declare function createChannelCommands(regionShortName: string): {
    /**
     * 获取通用通道配置命令
     */
    getConfigCommand(params: IChannelConfigParams): string;
    /**
     * 获取飞书通道配置命令
     */
    getFeishuConfigCommand(params: IChannelConfigParams, domain: string): string;
    /**
     * 获取企业微信通道配置命令
     */
    getWeComConfigCommand(params: IChannelConfigParams, isAgent: boolean, agentParams?: IWecomAgentParams, isWecomLongConn?: boolean, welcomeText?: string, streamPlaceholderContent?: string): string;
    /**
     * 获取 Telegram 通道配置命令
     */
    getTelegramConfigCommand(botToken: string): string;
    /**
     * 获取 Discord 通道配置命令
     */
    getDiscordConfigCommand(token: string): string;
    /**
     * 获取 Slack 通道配置命令
     */
    getSlackConfigCommand(botToken: string, appToken: string): string;
    /**
     * 获取 LINE 通道配置命令
     */
    getLineConfigCommand(channelSecret: string, channelAccessToken: string): string;
    /**
     * 获取 LINE 用户 ID 命令
     */
    getLineUserIdCommand(userId: string): string;
    /**
     * 获取删除通道命令
     */
    getDeleteCommand(channelValue: string): string;
    /**
     * 获取微信账号检测命令
     */
    getWeixinAccountsCommand(): string;
    /**
     * 飞书扫码创建机器人命令
     * @param platform 'lark' 为国际站，不传为国内站
     */
    getFeishuCreateCommand(platform?: 'lark'): string;
    /**
     * WhatsApp 扫码配置命令
     */
    getWhatsAppCreateCommand(): string;
    /**
     * 元宝扫码绑定命令
     * @param instanceId 实例 ID
     * @param publicAddress 实例公网 IP
     */
    getYuanbaoCreateCommand(instanceId: string, publicAddress: string): string;
    /**
     * LINE 扫码配置命令
     */
    getLineCreateCommand(): string;
    /**
     * 微信扫码接入命令
     */
    getWeixinCreateCommand(): string;
};
export declare type ChannelCommands = ReturnType<typeof createChannelCommands>;
