/**
 * LightClaw Scripts SDK - Gateway 命令模块
 *
 * 提供 Gateway 状态查询和重启相关的命令生成功能
 * 对应 SCRIPT_PATHS: CHECK_GATEWAY, RESTART_GATEWAY
 */
export declare const GATEWAY_STATUS: {
    readonly RUNNING: "running";
    readonly STOPPED: "stopped";
    readonly UNKNOWN: "unknown";
};
/**
 * 创建 Gateway 命令生成器
 * @param regionShortName 地域简称
 */
export declare function createGatewayCommands(regionShortName: string): {
    /**
     * 获取 Gateway 状态命令
     */
    getStatusCommand(): string;
    /**
     * 获取重启 Gateway 命令
     */
    getRestartCommand(): string;
};
export declare type GatewayCommands = ReturnType<typeof createGatewayCommands>;
