/**
 * LightClaw Scripts SDK - Hermes 专属命令模块
 *
 * 为 Hermes 镜像提供与 OpenClaw 并列的命令工厂。
 *
 * 设计要点：
 *  - 所有命令直接返回 `harness` CLI 命令字符串（不走 downloadAndRun）
 *  - 模块层不关心 TAT 如何下发；调用方在 executor 上层注入 `runAs: 'agentuser'`
 *  - 接口尽量与 OpenClaw 对应命令（model/channel/skill/gateway）保持"同构"
 *
 * 使用示例：
 *   const sdk = createLightClawScripts({ regionShortName: 'gz', agentType: 'hermes' });
 *   sdk.model.getConfigCommand({ providerName: 'openai', modelId: 'gpt-5', ... });
 */
/** Hermes model set 参数 */
export interface IHermesModelSetParams {
    /** 模型 ID（harness 命令行参数 --model） */
    modelId: string;
    /** provider 名称（harness 命令行参数 --name） */
    providerName: string;
    /** API 基础 URL（harness 命令行参数 --base-url） */
    baseUrl: string;
    /** API Key（harness 命令行参数 --api-key） */
    apiKey: string;
    /**
     * API 协议类型（harness 命令行参数 --api-mode）
     * 如 'openai-completions' / 'anthropic-messages'
     */
    apiMode?: string;
}
/** Hermes 删除 provider 参数 */
export interface IHermesDeleteProviderParams {
    /** provider 名称（harness 命令行参数 --name） */
    providerName: string;
}
/** 创建 Hermes Model 命令生成器 */
export declare function createHermesModelCommands(): {
    /**
     * 一步完成模型配置（保存 fallback provider + 自动重启网关）
     * 对应：`harness model set-fallbacks --fallback '{"name":"...","model":"...","base_url":"...","api_key":"...","api_mode":"..."}'`
     */
    getConfigCommand(params: IHermesModelSetParams): string;
    /**
     * 获取模型列表
     * 对应：`harness model list-fallbacks`
     */
    getListCommand(): string;
    /**
     * 删除 provider
     * 对应：`harness provider delete --name X`
     */
    getDeleteCommand(params: IHermesDeleteProviderParams): string;
};
export declare type HermesModelCommands = ReturnType<typeof createHermesModelCommands>;
export interface IHermesQQBotConfigParams {
    appId: string;
    clientSecret: string;
}
export interface IHermesDingTalkConfigParams {
    clientId: string;
    clientSecret: string;
    /** 可选：允许使用的用户白名单 */
    allowedUsers?: string;
}
/** 扫码通道类型 */
export declare type HermesQrPlatform = 'weixin' | 'feishu';
/** 创建 Hermes Channel 命令生成器 */
export declare function createHermesChannelCommands(): {
    /**
     * 获取通道列表
     * 对应：`harness channel list`
     */
    getListCommand(): string;
    /**
     * 配置 QQ 机器人
     * 对应：`harness configure gateway qqbot --app-id X --client-secret Y`
     */
    getQQBotConfigCommand(params: IHermesQQBotConfigParams): string;
    /**
     * 配置钉钉
     * 对应：`harness configure gateway dingtalk --client-id X --client-secret Y [--allowed-users Z]`
     */
    getDingTalkConfigCommand(params: IHermesDingTalkConfigParams): string;
    /**
     * 获取扫码 URL（流式输出，需配合 executor.runWithProgress）
     * 对应：`harness gateway qr-url-fast --platform weixin|feishu`
     */
    getQrUrlCommand(platform: HermesQrPlatform): string;
    /**
     * 删除通道
     * 对应：`harness channel delete --platform X`
     *
     * @param platform 通道 platform 值（weixin / qqbot / feishu / dingtalk）
     */
    getDeleteCommand(platform: string): string;
};
export declare type HermesChannelCommands = ReturnType<typeof createHermesChannelCommands>;
/** 创建 Hermes Skill 命令生成器 */
export declare function createHermesSkillCommands(): {
    /**
     * 获取已安装技能列表
     * 对应：`harness skills list`
     */
    getListCommand(): string;
    /**
     * 安装技能
     * 对应：`harness skills install NAME`
     */
    getInstallCommand(skillName: string): string;
};
export declare type HermesSkillCommands = ReturnType<typeof createHermesSkillCommands>;
/** 创建 Hermes Gateway 命令生成器 */
export declare function createHermesGatewayCommands(): {
    /**
     * 获取网关状态
     * 对应：`harness gateway status` —— 返回 JSON，用 parseHermesGatewayStatus 解析
     */
    getStatusCommand(): string;
    /**
     * 重启网关
     * 对应：`harness gateway restart`
     */
    getRestartCommand(): string;
    /**
     * 下载/更新 harness CLI（-z 条件请求）
     * 由维护镜像自举使用
     */
    getInstallHarnessCommand(): string;
};
export declare type HermesGatewayCommands = ReturnType<typeof createHermesGatewayCommands>;
