/**
 * LightClaw Scripts SDK - Config 命令模块
 *
 * 提供 OpenClaw 配置查询和备份相关的命令生成功能
 * 对应 SCRIPT_PATHS: GET_CONFIG, BACKUP_CONFIG
 *
 */
/** 备份类型 */
export declare type BackupType = 'prechange' | 'manual' | 'cron';
/**
 * 创建配置命令生成器
 * @param regionShortName 地域简称
 */
export declare function createConfigCommands(regionShortName: string): {
    /**
     * 在执行命令前自动备份 openclaw.json（prechange 类型）
     * 先下载最新备份脚本再执行，备份失败不阻塞主命令
     *
     * @param cmd 要执行的主命令
     */
    withBackup(cmd: string): string;
    /**
     * 获取 OpenClaw 配置查询命令
     */
    getConfigCommand(): string;
    /**
     * 列出备份文件
     */
    getListBackupCommand(): string;
    /**
     * 手动备份
     * @param remark 可选备注
     */
    getManualBackupCommand(remark?: string): string;
    /**
     * 回退到指定备份文件
     * @param filename 备份文件名
     */
    getRollbackCommand(filename: string): string;
    /**
     * 删除指定备份文件
     * @param filename 备份文件名
     */
    getDeleteBackupCommand(filename: string): string;
    /**
     * 修改备份文件备注
     * @param filename 备份文件名
     * @param remark 新备注
     */
    getRemarkCommand(filename: string, remark: string): string;
    /**
     * 查看备份文件内容
     * 输出格式: {size}\n{content}，用 head -c 防止超出 TAT 24KB 限制
     * @param filePath 备份文件完整路径（由业务方拼接）
     */
    getViewBackupCommand(filePath: string): string;
    /**
     * 查询定时备份状态
     */
    getCronStatusCommand(): string;
    /**
     * 开启定时备份
     */
    getEnableCronCommand(): string;
    /**
     * 关闭定时备份
     */
    getDisableCronCommand(): string;
};
export declare type ConfigCommands = ReturnType<typeof createConfigCommands>;
