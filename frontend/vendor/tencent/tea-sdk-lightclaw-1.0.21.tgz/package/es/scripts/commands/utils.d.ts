/**
 * LightClaw Scripts SDK - 通用常量
 *
 * 跨模块使用的常量和映射表
 */
export declare const CHANNEL_PLUGIN_MAP: Record<string, string>;
