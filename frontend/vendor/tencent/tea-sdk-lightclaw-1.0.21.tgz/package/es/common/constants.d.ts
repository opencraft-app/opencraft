/**
 * 是否国际站用户
 */
export declare const IS_I18N: boolean;
/** 当前语言是否为英文 */
export declare const IS_EN: boolean;
