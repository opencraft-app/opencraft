/**
 * 轻量级 message 提示 — 替代 tea-component message（React 19 兼容）
 *
 * tea-component 的 message.success/error 内部使用 ReactDOM.render，
 * 在 React 19 + Vite 环境下会触发 race condition。
 * 本模块用纯 DOM 实现，无 React 依赖。
 *
 * API 与 tea-component message 保持一致：
 *   showMessage.success({ content: '操作成功' })
 *   showMessage.error({ content: '操作失败' })
 */
interface MessageOptions {
    content: string;
    duration?: number;
}
export declare const message: {
    success: (options: MessageOptions) => void;
    error: (options: MessageOptions) => void;
    warning: (options: MessageOptions) => void;
    info: (options: MessageOptions) => void;
};
export {};
