declare type StepStatus = 'success' | 'loading' | 'error' | 'warning';
/** JSON Lines 脚本输出的单行结构 */
export interface IJsonLine {
    action?: string;
    level?: string;
    step?: string;
    message?: string;
    content?: string;
    ts?: string;
    [key: string]: unknown;
}
/** 流式输出解析上下文 — 由 startQrCodeFlow 的 onProgress 回调构造 */
export interface IProgressContext {
    /** 完整解码输出 */
    decoded: string;
    /** 本次增量内容 */
    increment: string;
    /** 完整输出解析的 JSON Lines */
    jsonLines: IJsonLine[];
    /** 增量解析的 JSON Lines */
    incrementLines: IJsonLine[];
    setQrCodeToken: (token: string) => void;
    setQrCodeStatus: (status: 'init' | 'loading' | 'ready' | 'failed' | 'success') => void;
    setQrCodeScanned: (scanned: boolean) => void;
    setPollSteps: (steps: Array<{
        text: string;
        num: number;
        status: StepStatus;
    }>) => void;
    setLoadingText: (text: string) => void;
}
/** 最终结果解析上下文 — 由 startQrCodeFlow 的 onFinish 回调构造 */
export interface IFinishContext {
    /** 最终完整输出（已解码） */
    finalOutput: string;
    /** 解析后的 JSON Lines */
    jsonLines: any[];
    setQrCodeStatus: (status: 'failed' | 'success') => void;
    setQrCodeErrorMessage: (msg: string) => void;
    setSuccessBotName: (name: string) => void;
    setSuccessManageUrl: (url: string) => void;
    /** 高级权限审批地址（部分成功时由策略设置） */
    setAuditUrl: (url: string) => void;
    /** 需要审批的高级权限 scope 列表（部分成功时由策略设置） */
    setAuditPermissions: (permissions: string[]) => void;
    handlePollComplete: (result: {
        bot_name: string;
        manage_url: string;
    }, status: 'success' | 'failed') => void;
    markLastStepError: () => void;
}
/** 扫码快捷配置策略接口 */
export interface IQrCodeStrategy {
    /** 执行命令（下载+执行一体化，由 SDK downloadAndRun 提供） */
    command: string;
    /** 弹窗文案 */
    labels: {
        scanPrompt: string;
        configuring: string;
        scanTitle: string;
        successTitle: string;
        failedTitle: string;
        failedMessage: string;
        timeoutMessage: string;
    };
    /** 步骤条标签映射（key 顺序即展示顺序） */
    stepLabels: Record<string, string>;
    /** 不展示在步骤条中的 step key */
    hiddenStepKeys?: string[];
    /** 流式输出解析 */
    onProgress: (ctx: IProgressContext) => void;
    /** 最终结果解析 */
    onFinish: (ctx: IFinishContext) => void;
    /** QR 码是字符画模式而非 URL（默认 false）。
     *  为 true 时 onProgress 中 setQrCodeToken 传入的是字符画文本，
     *  前端需要用 <pre> 渲染而非 QRCodeCanvas */
    isCharacterArtQr?: boolean;
    /** 成功后是否需要重启 Gateway（默认 true） */
    needsRestartGateway?: boolean;
    /** 是否需要实例公网 IP 才能执行（默认 false） */
    requiresPublicAddress?: boolean;
    /**
     * 通道配置前的额外准备操作（如放通防火墙端口等）
     * 快捷配置路径在脚本执行前调用
     * 钩子内部应自行 try/catch 非关键错误，仅在致命错误时 throw
     */
    prepareChannel?: (instanceId: string, regionId: number) => Promise<void>;
}
/**
 * 从 JSON Lines 数组中提取步骤进度
 * 修复：按 labels key 顺序排列（非输出出现顺序），前置约束保证不跳跃
 */
export declare const parseJsonLineSteps: (lines: IJsonLine[], labels: Record<string, string>, hiddenStepKeys?: string[]) => Array<{
    key: string;
    text: string;
    num: number;
    status: StepStatus;
}>;
export declare const FEISHU_PERMISSION_LABELS: Record<string, string>;
export declare const FEISHU_STEP_LABELS: Record<string, string>;
export declare const WHATSAPP_STEP_LABELS: Record<string, string>;
export declare const YUANBAO_STEP_LABELS: Record<string, string>;
export declare const LINE_STEP_LABELS: Record<string, string>;
export declare const WEIXIN_STEP_LABELS: Record<string, string>;
/**
 * @remarks 仅用于 OpenClaw 镜像。Hermes 镜像的扫码流程（微信/飞书）由
 * `components/OpenClawPanel/HermesQrCodeModal.tsx` 独立实现，不走本策略注册表。
 */
export declare const createQrCodeStrategies: (scriptCommands: any, instance: {
    InstanceId: string;
    PublicAddresses?: string[];
}) => Record<string, IQrCodeStrategy>;
export {};
