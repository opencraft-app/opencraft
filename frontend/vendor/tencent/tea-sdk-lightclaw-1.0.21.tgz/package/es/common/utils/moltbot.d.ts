/** 判断是否为 Windows 平台 */
export declare function isWindowsPlatFormType(platformType?: string): boolean;
export declare const OPENCLAW_VERSIONS: readonly [{
    readonly id: "lhbp-8hq35xoy";
    readonly features: readonly [];
}, {
    readonly id: "lhbp-b4h2hzmk";
    readonly features: readonly ["channel"];
}, {
    readonly id: "lhbp-pg6swctw";
    readonly features: readonly ["channel", "gateway"];
}, {
    readonly id: "lhbp-af49p6zc";
    readonly features: readonly ["channel", "gateway", "skills", "qrConfig"];
}, {
    readonly id: "lhbp-qr19tbkm";
    readonly features: readonly ["channel", "gateway", "skills", "wecomChannel", "qrConfig"];
}, {
    readonly id: "lhbp-gl155ki8";
    readonly features: readonly ["channel", "gateway", "skills", "wecomChannel", "qrConfig"];
}, {
    readonly id: "lhbp-dxuz4oaa";
    readonly features: readonly ["channel", "gateway", "skills", "wecomChannel", "adpChannel", "qrConfig"];
}, {
    readonly id: "lhbp-qf70co1g";
    readonly features: readonly ["channel", "gateway", "skills", "wecomChannel", "adpChannel", "qrConfig"];
}, {
    readonly id: "lhbp-5igpmlng";
    readonly features: readonly ["channel", "gateway", "skills", "wecomChannel", "adpChannel", "qrConfig"];
}, {
    readonly id: "lhbp-2jn60c9c";
    readonly features: readonly ["channel", "gateway", "skills", "wecomChannel", "adpChannel", "qrConfig"];
}, {
    readonly id: "lhbp-qbpa23xy";
    readonly features: readonly ["channel", "gateway", "skills", "wecomChannel", "adpChannel", "qrConfig"];
}, {
    readonly id: "lhbp-8kp7tl0a";
    readonly features: readonly ["channel", "gateway", "skills", "wecomChannel", "adpChannel", "wecomLongConn", "qrConfig"];
}, {
    readonly id: "lhbp-dmgfgwe4";
    readonly features: readonly ["channel", "gateway", "skills", "wecomChannel", "adpChannel", "wecomLongConn", "qrConfig"];
}, {
    readonly id: "lhbp-m9h7580k";
    readonly features: readonly ["channel", "gateway", "skills", "wecomChannel", "adpChannel", "wecomLongConn", "qrConfig", "webUI"];
}, {
    readonly id: "lhbp-8sf3xbas";
    readonly features: readonly ["channel", "gateway", "skills", "wecomChannel", "adpChannel", "wecomLongConn", "qrConfig", "webUI"];
}, {
    readonly id: "lhbp-15bczcae";
    readonly features: readonly ["channel", "gateway", "skills", "wecomChannel", "adpChannel", "wecomLongConn", "qrConfig", "webUI", "yuanbaoChannel"];
}, {
    readonly id: "lhbp-p0x1qa4w";
    readonly features: readonly ["channel", "gateway", "skills", "wecomChannel", "adpChannel", "wecomLongConn", "qrConfig", "webUI", "yuanbaoChannel"];
}, {
    readonly id: "lhbp-m24fc9me";
    readonly features: readonly ["channel", "gateway", "skills", "wecomChannel", "adpChannel", "wecomLongConn", "qrConfig", "webUI", "yuanbaoChannel"];
}, {
    readonly id: "lhbp-1jmw0qz6";
    readonly features: readonly ["channel", "gateway", "skills", "wecomChannel", "adpChannel", "wecomLongConn", "qrConfig", "webUI", "yuanbaoChannel", "weixinChannel"];
}, {
    readonly id: "lhbp-rn2vvmsy";
    readonly features: readonly ["channel", "gateway", "skills", "wecomChannel", "adpChannel", "wecomLongConn", "qrConfig", "webUI", "yuanbaoChannel", "weixinChannel"];
}, {
    readonly id: "lhbp-b4irohq4";
    readonly features: readonly ["channel", "gateway", "skills", "wecomChannel", "adpChannel", "wecomLongConn", "qrConfig", "webUI", "yuanbaoChannel", "weixinChannel", "memoryManagement"];
}, {
    readonly id: "lhbp-eilgi5gy";
    readonly features: readonly ["channel", "gateway", "skills", "wecomChannel", "adpChannel", "wecomLongConn", "qrConfig", "webUI", "yuanbaoChannel", "weixinChannel", "memoryManagement"];
}, {
    readonly id: "lhbp-pwgwkgvq";
    readonly features: readonly ["channel", "gateway", "skills", "wecomChannel", "adpChannel", "wecomLongConn", "qrConfig", "webUI", "yuanbaoChannel", "weixinChannel", "memoryManagement", "qqbotplugin"];
}, {
    readonly id: "lhbp-o60d7x1s";
    readonly features: readonly ["channel", "gateway", "skills", "wecomChannel", "adpChannel", "wecomLongConn", "qrConfig", "webUI", "yuanbaoChannel", "weixinChannel", "memoryManagement", "qqbotplugin"];
}, {
    readonly id: "lhbp-ht58t2m6";
    readonly features: readonly ["channel", "gateway", "skills", "wecomChannel", "adpChannel", "wecomLongConn", "qrConfig", "webUI", "yuanbaoChannel", "weixinChannel", "memoryManagement", "qqbotplugin", "memoryV2"];
}];
export declare const OPEN_CLAW: string[];
export declare const getNotSupportList: (feature: string) => string[];
export declare const isOpenClaw: (bluePrint: {
    BlueprintId?: string;
    BlueprintName?: string;
}) => boolean;
/**
 * 腾讯系 provider 列表（apiKey 自动获取，无需用户手动输入）
 *
 * 这些 provider 的 `getTencentApiKey` 实现**强依赖腾讯云 CAPI**：
 *   - hunyuan             → QueryHunyuanUserStatus / GetHunyuanAPIKey (+ 开通服务/后付费 / MFA 弹窗)
 *   - qcloud_lkeap        → DescribeLkeapOpenStatus / ListLkeapPostpaidProduct / ...
 *   - tencent_coding_plan → DescribeCodingPlanPkg / ListCodingPlanAPIKey / GetHunyuanAPIKey
 *   - tencent_token_plan  → DescribeTokenPlanUsage / ListTokenPlanAPIKey / GetHunyuanAPIKey
 *
 * 在非腾讯云账号体系的宿主（如 mono 平台）下，CAPI 调用会全部失败。
 * 宿主可在 `IProductConfig.supportsTencentCloudApi = false` 时由 SDK 自动屏蔽这些 provider。
 */
export declare const TENCENT_PROVIDERS: string[];
/** 根据实例地域过滤模型提供商列表（香港地域隐藏部分国际服务商） */
export declare function getFilteredModelProviderList(region?: string): IModelProvider[];
/** 判断是否为腾讯系 provider */
export declare function isTencentProvider(value: string): boolean;
/** 模型提供商配置 */
export interface IModelProvider {
    /** 唯一标识，用于 Select/Cascader 的 value */
    value: string;
    /** 分类：coding_plan 为 Coding Plan 订阅模式，api 为直接 API 调用模式 */
    category: 'coding_plan' | 'api';
    /** 底层 provider 标识，用于写入 openclaw.json 配置 */
    provider: string;
    /** 显示名称（已国际化） */
    provider_name: string;
    /** 描述信息（可含 HTML） */
    description: string;
    /** API Key 获取地址 */
    api_key_url: string;
    /** API 基础地址 */
    base_url: string;
    /** API 协议类型，如 'openai-completions' | 'anthropic-messages' */
    api: string;
    /** 该提供商支持的模型列表 */
    models: Array<{
        id: string;
        name: string;
        input?: string[];
    }>;
    /** OAuth 授权配置（存在则支持 OAuth） */
    oauth?: {
        /** 脚本 init/poll 的 provider 参数（如 'codex'） */
        provider: string;
        /** gateway 生成的 models.json 中的 provider key（如 'openai-codex'），用于 parseConfigResult 匹配 */
        openclawProvider: string;
        /** 是否需要用户回填回调 URL（Authorization Code Flow） */
        requireCallbackUrl?: boolean;
        /** 是否为纯 OAuth 模式（不支持 API Key） */
        exclusive?: boolean;
        /** 写入 openclaw.json 的 provider 配置 */
        providerConfig?: {
            baseUrl: string;
            api: string;
        };
        /** 删除时是否需要清理 auth-profiles.json */
        cleanAuthProfile?: boolean;
        /** init 命令额外参数（如 'cn'），拼接在 provider 之后 */
        initArgs?: string;
        /** poll 命令固定参数（当 requireCallbackUrl=false 时替代回调 URL） */
        pollArgs?: string;
        /** OAuth 专属模型列表（写入 openclaw.json 时使用，不同于 providerInfo.models） */
        models?: Array<{
            id: string;
            name: string;
            input?: string[];
        }>;
    };
}
export declare const MODEL_PROVIDER_LIST: IModelProvider[];
interface IChannelConfig {
    value: string;
    channel: string;
    channel_name: string;
    description?: string;
    url?: string;
    supportQrConfig?: boolean;
    qrCodeOnly?: boolean;
    /** 一级选项展示名；有此字段的通道按数据源顺序作为一级直选项，其余归入「其他」 */
    primaryLabel?: string;
    channel_keys: {
        key: string;
        description: string;
    }[];
}
export declare const CHANNEL_LIST: IChannelConfig[];
/** getChannelListNew 函数的配置选项 */
interface IGetChannelListNewOptions {
    /** 是否支持 ADP 通道的 OpenClaw 镜像 */
    isSupportAdpChannelOpenClawBlueprint?: boolean;
    isSupportWecomLongConnOpenClawBlueprint?: boolean;
    isSupportYuanbaoChannelBlueprint?: boolean;
    isSupportWeixinChannelBlueprint?: boolean;
}
export declare const getChannelListNew: (options?: IGetChannelListNewOptions) => IChannelConfig[];
/** 从脚本多行 JSON 输出中查找指定 action 的记录 */
export declare function parseOAuthOutput(output: string, action: string): Record<string, any> | null;
export declare const GATEWAY_STATUS: {
    readonly RUNNING: "running";
    readonly STOPPED: "stopped";
    readonly UNKNOWN: "unknown";
};
export declare const UPGRADE_STATUS: {
    readonly PROGRESSING: "PROGRESSING";
    readonly COMPLETED: "COMPLETED";
    readonly FAILED: "FAILED";
    readonly UNKNOWN: "UNKNOWN";
};
export declare const UPGRADE_STAGE_MAP: Record<string, string>;
export declare const CUSTOM_JSON_PLACEHOLDER: string;
export declare const CHANNEL_PLUGIN_MAP: Record<string, string>;
/**
 * 根据通道和镜像版本获取 plugin 名称
 * 新版镜像（支持 qqbotplugin 特性）qqbot 的 plugin 名称从 'openclaw-qqbot' 改为 'qqbot'
 */
export declare const getChannelPluginName: (channelValue: string, isSupportQQBotPlugin?: boolean) => string | undefined;
export declare const getMemoryPluginName: (isV2: boolean) => "memory-tencentdb" | "memory-tdai";
export {};
