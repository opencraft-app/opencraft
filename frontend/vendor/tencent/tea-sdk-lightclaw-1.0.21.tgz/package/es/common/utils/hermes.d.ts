/**
 * Hermes 镜像专属数据与解析函数
 *
 * 与 moltbot.ts (OpenClaw) 并存：
 *  - 模型列表：复用 OpenClaw MODEL_PROVIDER_LIST，过滤掉 OAuth-only 的 provider
 *  - 通道列表：固定 3 个（微信、QQ、飞书）
 *  - 解析函数：将 `harness` CLI 的 JSON 输出转为面板可用结构
 *
 * 注意：本文件不包含任何 CLI 命令字符串；命令统一由 scripts/commands/hermes/* 生成。
 */
import type { IChannelConfig, IModelProvider } from '../config/types';
/** 判断镜像是否为 Hermes 镜像（BlueprintName 含 'hermes_agent'） */
export declare const isHermes: (bluePrint: {
    BlueprintId?: string;
    BlueprintName?: string;
}) => boolean;
/** Hermes 专用 TAT 执行用户名 */
export declare const HERMES_TAT_USERNAME = "agentuser";
export declare const HERMES_GATEWAY_STATUS: {
    readonly RUNNING: "running";
    readonly ACTIVATING: "activating";
    readonly STOPPED: "stopped";
    readonly NOT_INSTALLED: "not_installed";
    readonly UNKNOWN: "unknown";
};
export declare type HermesGatewayStatus = (typeof HERMES_GATEWAY_STATUS)[keyof typeof HERMES_GATEWAY_STATUS];
/**
 * Hermes 通道列表
 * 注意：Hermes 不按版本动态变化，始终返回这 3 项
 */
export declare const HERMES_CHANNEL_LIST: IChannelConfig[];
/** Hermes getChannelList 包装（参数与 OpenClaw 一致但被忽略，始终返回固定列表） */
export declare const getHermesChannelList: () => IChannelConfig[];
export declare const HERMES_MODEL_PROVIDER_LIST: IModelProvider[];
/** 按地域过滤 Hermes 模型提供商 */
export declare function getHermesFilteredModelProviderList(region?: string): IModelProvider[];
export declare function isHermesTencentProvider(value: string): boolean;
export declare const HERMES_CUSTOM_JSON_PLACEHOLDER = "{\n  \"base_url\": \"https://api.example.com/v1\",\n  \"api_key\": \"your-api-key-here\",\n  \"model\": \"model-name\",\n  \"api_mode\": \"openai-completions\"\n}";
export interface IHermesChannelEntry {
    value: string;
    channel: string;
    channel_name: string;
    enabled: boolean;
}
export interface IHermesActiveModel {
    provider?: string;
    name?: string;
    base_url?: string;
    api_key_status?: 'configured' | 'not configured' | string;
    [key: string]: any;
}
export interface IHermesParsedProviders {
    providers: any[];
    activeModel: IHermesActiveModel | null;
}
/**
 * 解析 `harness model list` 输出
 * 返回 { providers, activeModel }
 *
 * providers 为空但 activeModel 有效时，将 activeModel 构造成单条 provider 记录供面板展示
 */
export declare function parseHermesProviderList(json: string): IHermesParsedProviders;
/**
 * 解析 `harness channel list` 输出
 * 仅保留 effective 通道，映射为 { value, channel, channel_name, enabled }
 */
export declare function parseHermesChannelList(json: string): IHermesChannelEntry[];
/**
 * 解析 `harness gateway status` 输出
 * 返回枚举字符串
 */
export declare function parseHermesGatewayStatus(json: string): HermesGatewayStatus;
/** 支持 Hermes 配置面板的最低日期版本 */
export declare const HERMES_MIN_PANEL_DATE_VERSION = "2026.4.16";
/** 支持 WebUI 的最低 Hermes semver 版本 */
export declare const HERMES_MIN_WEBUI_VERSION = "v0.9.0";
/** 从 DisplayVersion 提取 semver（"v0.9.0 (v2026.4.13)" → "v0.9.0"） */
export declare const parseHermesVersion: (displayVersion: string) => string | null;
/** 从 DisplayVersion 提取日期版本（"v0.9.0 (v2026.4.13)" → "2026.4.13"） */
export declare const parseHermesDateVersion: (displayVersion: string) => string | null;
/** 判断 Hermes 版本是否支持 WebUI */
export declare const isHermesWebUISupported: (displayVersion: string) => boolean;
/** 判断 Hermes 版本是否支持配置面板 */
export declare const isHermesPanelSupported: (displayVersion: string) => boolean;
