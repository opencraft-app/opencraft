export * from './moltbot';
/**
 * 腾讯系 provider 自动获取 API Key
 * 完整实现在 tea-app-lighthouse 的 application/common/utils.ts 中
 * SDK 中暂为桩函数，由宿主应用 lighthouse 通过 API 调用实现
 * TODO: 从 lighthouse 迁移完整实现（依赖混元/LKEAP/CodingPlan/TokenPlan 云 API）
 */
export declare function getTencentApiKey(_provider: string, _modelId?: string): Promise<string>;
/**
 * 日期格式化
 */
export declare function formatDate(date: Date): string;
