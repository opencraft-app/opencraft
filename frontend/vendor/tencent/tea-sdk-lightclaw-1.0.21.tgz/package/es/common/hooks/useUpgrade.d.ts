/**
 * useUpgrade — 热更新 & 磁盘空间管理 Hook
 *
 * 从 useGatewayCommand 中抽离的独立能力，负责：
 * - 触发热更新（triggerUpgrade）
 * - 轮询升级状态（queryUpgradeStatus）
 * - 查询升级版本号（queryUpgradeVersion）
 * - 查询磁盘剩余空间（queryDiskSpace）
 *
 * 消费方（如 OpenClawInfoHeader 的宿主应用）使用示例：
 * ```ts
 * const upgrade = useUpgrade({ instance, regionShortName: 'gz', featureFlags });
 * // upgrade.triggerUpgrade(blueprintId, version)
 * // upgrade.upgradeStatus / upgrade.upgradeStage / upgrade.availableDiskMB
 * ```
 */
import type { LightClawScriptsSDK } from '../../scripts/create-scripts';
import type { ICommandExecutor } from '../../scripts/executor';
import type { IOpenClawComponentBaseProps } from './useOpenClawInternals';
export interface IUseUpgradeResult {
    /** 当前升级状态（PROGRESSING / COMPLETED / FAILED / UNKNOWN） */
    upgradeStatus: string;
    /** 更新版本号（镜像 ID） */
    upgradeVersion: string;
    /** 热更新后的展示版本号（如 "2026.3.11"） */
    upgradeDisplayVersion: string;
    /** 当前升级阶段（如 "0"、"1"、"2"） */
    upgradeStage: string;
    /** 查询热更新状态（轮询直到完成/失败） */
    queryUpgradeStatus: () => Promise<void>;
    /** 查询更新版本号 */
    queryUpgradeVersion: () => Promise<void>;
    /** 触发热更新 */
    triggerUpgrade: (blueprintId: string, version: string) => Promise<void>;
    /** 磁盘剩余空间（MB），null 表示尚未查询 */
    availableDiskMB: number | null;
    /** 查询磁盘剩余空间 */
    queryDiskSpace: () => Promise<void>;
    /** 内部的 scriptCommands（供高级用途） */
    scriptCommands: LightClawScriptsSDK;
    /** 内部的 executor（供高级用途） */
    executor: ICommandExecutor;
}
export declare function useUpgrade(props: IOpenClawComponentBaseProps): IUseUpgradeResult;
