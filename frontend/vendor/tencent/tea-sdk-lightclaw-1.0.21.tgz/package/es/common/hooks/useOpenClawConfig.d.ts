/**
 * @fileoverview useOpenClawConfig — 独立的 configData 请求 hook
 *
 * 封装 configData 的请求（getOpenclawConfig）和解析（parseConfigResult）逻辑，
 * 无需依赖 OpenClawPanel 或 OpenClawContext。
 *
 * **Hermes 兼容**：当 `productConfig.agentType === 'hermes'` 时，
 * hook 内部自动切换为 harness CLI 数据通路（model list / channel list），
 * 对外保持相同的返回接口；组件层无需感知 agentType 差异。
 *
 * @example
 * ```tsx
 * import { useOpenClawConfig } from '@tencent/tea-sdk-lightclaw';
 *
 * function ModelCard(props) {
 *   const { configData, loading, refresh, restartAndRefresh } = useOpenClawConfig({
 *     instance: props.instance,
 *     regionShortName: props.regionShortName,
 *     featureFlags: props.featureFlags,
 *     productConfig: props.productConfig,
 *   });
 *
 *   // 使用 configData.providers
 *   // 操作后调 refresh() / restartAndRefresh() 刷新
 * }
 * ```
 */
/// <reference types="react" />
import type { IProductConfig } from '../config/types';
import type { IConfigData, IFeatureFlags } from '../../components/OpenClawPanel/types';
import type { IOpenClawComponentBaseProps } from './useOpenClawInternals';
export interface IUseOpenClawConfigParams extends IOpenClawComponentBaseProps {
    /** 数据是否准备就绪（可选，默认 true） */
    isDataReady?: boolean;
    /** 操作禁用提示（有值时跳过请求） */
    operationDisabledTip?: string;
}
export interface IUseOpenClawConfigResult {
    /** 解析后的配置数据 */
    configData: IConfigData;
    /** 是否正在加载 */
    loading: boolean;
    /** 设置 loading 状态（供外部控制） */
    setLoading: React.Dispatch<React.SetStateAction<boolean>>;
    /**
     * 主动刷新配置数据
     * @param silent - 静默模式，不显示 loading
     * @returns 解析后的配置数据，失败时返回 void
     */
    refresh: (silent?: boolean) => Promise<IConfigData | void>;
    /** 重启网关并刷新配置 */
    restartAndRefresh: (needRestart?: boolean) => Promise<void>;
    /** 当前正在执行的操作标识 */
    currentAction: string;
    /** 设置当前操作标识 */
    setCurrentAction: React.Dispatch<React.SetStateAction<string>>;
    /** 当前通道列表（基于 configData.webUI.port + featureFlags + productConfig 计算） */
    currentChannelList: any[];
}
/**
 * 解析远端 openclaw.json 配置为 IConfigData
 *
 * 从 OpenClawPanel/index.tsx 中抽离的纯函数，不依赖任何 React 状态。
 */
export declare function parseConfigResult(configResult: string, options: {
    featureFlags: IFeatureFlags;
    currentChannelList: Array<{
        value: string;
        channel: string;
        channel_name: string;
        [key: string]: any;
    }>;
    productConfig: IProductConfig;
}): IConfigData;
/**
 * 独立的 configData 请求 hook
 *
 * 将 configData 的请求（getOpenclawConfig）和解析（parseConfigResult）逻辑
 * 封装为可独立使用的 hook，无需依赖 OpenClawPanel 或 OpenClawContext。
 *
 * 内部自动创建 scriptCommands / executor / useGatewayCommand，
 * 消费方只需传最小参数集。
 */
export declare function useOpenClawConfig(params: IUseOpenClawConfigParams): IUseOpenClawConfigResult;
