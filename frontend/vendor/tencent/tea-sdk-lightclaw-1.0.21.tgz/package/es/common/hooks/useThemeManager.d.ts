export interface UseThemeManagerReturn {
    currentTheme: number | null;
}
export declare const useThemeManager: (themeChangeCallback?: (themeType: number) => void) => UseThemeManagerReturn;
