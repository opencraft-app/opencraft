/**
 * 企微长链接机器人扫码创建 Hook
 *
 * @returns openAuth - 调用后弹出扫码授权窗口，返回 BotInfo { botid, secret }
 *
 * @example
 * const { openAuth } = useWecomAIBotSDK();
 * const handleClick = async () => {
 *   try {
 *     const bot = await openAuth();
 *     // bot.botid, bot.secret -> 写入通道配置
 *   } catch (e) {
 *     console.error(e);
 *   }
 * };
 */
export declare function useWecomAIBotSDK(): {
    openAuth: () => Promise<import("@wecom/wecom-aibot-sdk").BotInfo>;
};
