/// <reference types="react" />
import type { LightClawScriptsSDK } from '../../scripts/create-scripts';
import type { ICommandExecutor } from '../../scripts/executor';
interface UseGatewayCommandOptions {
    /** SDK 命令实例（生成 shell 命令字符串） */
    scriptCommands: LightClawScriptsSDK;
    /** SDK 命令执行器（在远程实例上执行命令） */
    executor: ICommandExecutor;
}
interface ExecuteCommandOptions {
    command: string;
    action: string;
    showButtonLoading?: boolean;
    shouldQueryStatus?: boolean;
    timeout?: number;
    callback?: (result?: any) => void | Promise<void>;
    onFailed?: (error?: any) => void | Promise<void>;
}
export declare const useGatewayCommand: ({ scriptCommands, executor }: UseGatewayCommandOptions) => {
    gatewayLoading: boolean;
    currentAction: string;
    status: string;
    setCurrentAction: import("react").Dispatch<import("react").SetStateAction<string>>;
    executeGatewayCommand: (options: ExecuteCommandOptions) => Promise<void>;
    queryGatewayStatus: () => Promise<void>;
    restartGateway: (showButtonLoading?: boolean) => Promise<void>;
};
export {};
