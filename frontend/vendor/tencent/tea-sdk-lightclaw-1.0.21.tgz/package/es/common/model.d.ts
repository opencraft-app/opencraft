/**
 * LightClaw Scripts SDK - TAT API 封装
 *
 * 基于 @tencent/iaas-workbench-api-client 的 apiRequest 封装 TAT 云 API。
 *
 * ## 为什么 apiRequest 采用懒加载？
 *
 * `@tencent/iaas-workbench-api-client/lib/region.js` 在模块顶层
 * **立即执行** `initRegionIdMap()`，会同步向 `workbench.cloud.tencent.com`
 * 发起 `DescribeRegionsAndZones` 请求。对于不在腾讯云控制台 iframe 环境
 * 下的消费方（如 mono/frontend 的 Vite dev server），该请求必然：
 *   1) 触发 CORS 跨域错误（preflight 失败）
 *   2) 没有腾讯云会话 cookie 导致 401
 *
 * 消费方如果通过 `IProductConfig.runCommand` / `.getInvocationTask`
 * 自定义命令通道（例如走自家后端的 TAT 代理），本模块内的函数就
 * **不会**被调用，理想状态是连这个包都不要加载。
 *
 * 因此：
 *   - 顶层 `import { apiRequest }` → 改为 `import type` 或动态 import
 *   - 仅在真正的 `tatCapiRequest` / `lhCapiRequest` 调用时才 `await import()`
 *   - 打包工具（Vite / webpack）会把该包单独切成 chunk，按需加载
 */
/** 请求配置选项 */
interface IRequestOpts {
    camTips?: boolean;
    tipErr?: boolean;
    [key: string]: any;
}
/**
 * TAT 云 API 请求封装
 */
export declare function tatCapiRequest<T = any>({ action, data, regionId }: {
    action: string;
    data?: Record<string, any>;
    regionId: number;
}, options?: IRequestOpts): Promise<T>;
/** RunCommand 请求参数 */
export interface IRunCommandParams {
    RegionId: number;
    InstanceIds: string[];
    SaveCommand: boolean;
    CommandType: string;
    Content: string;
    Timeout: number;
    /**
     * 以指定用户名执行命令（TAT RunCommand 的 Username 字段）
     * 不传则以镜像默认用户执行（通常 root）。Hermes 镜像传 'agentuser'。
     */
    Username?: string;
}
/** 执行任务结果 */
export interface IInvocationTask {
    TaskStatus?: string;
    TaskResult?: {
        Output?: string;
    };
}
/** 轮询任务的可选配置 */
export interface IPollingOptions {
    /** 进度回调，每次轮询时传入当前的 base64 编码输出 */
    onProgress?: (output: string) => void;
    /** 最大轮询次数，不传则不限 */
    maxRetries?: number;
}
/**
 * 执行命令 (TAT RunCommand)
 */
export declare function RunCommand(data: IRunCommandParams, options?: IRequestOpts): Promise<{
    InvocationId?: string;
}>;
/**
 * 查询执行任务 (TAT DescribeInvocationTasks)
 */
export declare function DescribeInvocationTasks(data: {
    RegionId: number;
    InvocationTaskIds?: string[];
    Filters?: {
        Name: string;
        Values: string[];
    }[];
    Limit?: number;
    Offset?: number;
    HideOutput?: boolean;
}, options?: IRequestOpts): Promise<{
    InvocationTaskSet?: any[];
}>;
/**
 * 获取执行任务结果（自动轮询直到任务完成）
 *
 * - 不传 options：普通模式，轮询直到完成，无次数限制
 * - 传 onProgress：流式模式，每次轮询回调当前输出，受 maxRetries 限制
 *
 * @param regionId 地域 ID
 * @param invocationId 执行 ID
 * @param options 可选轮询配置
 */
export declare function getInvocationTask(regionId: number, invocationId?: string, options?: IPollingOptions): Promise<IInvocationTask>;
/**
 * Lighthouse 云 API 请求封装
 */
export declare function lhCapiRequest<T = any>({ action, data, regionId }: {
    action: string;
    data?: Record<string, any>;
    regionId: number;
}, options?: IRequestOpts): Promise<T>;
/** 防火墙规则类型 */
interface IFirewallRule {
    Protocol: string;
    Port: string;
    CidrBlock: string;
    Action: string;
    FirewallRuleDescription?: string;
}
interface IFirewallRuleInfo extends IFirewallRule {
    [key: string]: any;
}
/** 查询防火墙规则 */
export declare function DescribeFirewallRules(params: {
    InstanceId: string;
    Offset: number;
    Limit?: number;
}, regionId: number, opts?: IRequestOpts): Promise<{
    TotalCount: number;
    FirewallRuleSet: IFirewallRuleInfo[];
    FirewallVersion: number;
    RequestId: string;
}>;
/** 添加防火墙规则 */
export declare function CreateFirewallRules(params: {
    InstanceId: string;
    FirewallRules: IFirewallRule[];
    FirewallVersion: number;
}, regionId: number, opts?: IRequestOpts): Promise<{
    RequestId: string;
}>;
export {};
