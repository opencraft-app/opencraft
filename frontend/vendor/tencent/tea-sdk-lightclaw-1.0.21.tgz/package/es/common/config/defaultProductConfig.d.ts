/**
 * Lighthouse 默认产品配置
 *
 * 将 moltbot.ts 中硬编码的 lighthouse 产品数据包装为 IProductConfig，
 * 供现有 lighthouse 接入方一行配置即可使用。
 */
import type { IProductConfig } from './types';
/** `createLighthouseConfig` 可选参数 */
export interface ICreateLighthouseConfigOptions {
    /**
     * Agent 类型，默认 `'openclaw'`
     * - `'openclaw'`：返回 OpenClaw 配置（走 COS 脚本命令链路）
     * - `'hermes'`：返回 Hermes 配置（走 harness CLI 命令链路）
     */
    agentType?: IProductConfig['agentType'];
    /**
     * 宿主是否支持调用腾讯云 CAPI（默认 `true`）
     *
     * - tea-app-lighthouse → 保持默认 `true`
     * - mono 等非腾讯云账号体系宿主 → 传 `false`，SDK 会自动从模型列表中
     *   过滤掉 `TENCENT_PROVIDERS` 里的 provider（混元/LKEAP/Coding Plan/Token Plan）
     */
    supportsTencentCloudApi?: boolean;
}
/**
 * 创建 Lighthouse 默认产品配置
 *
 * @param options 可选参数（如 agentType、是否支持腾讯云 CAPI）
 * @returns 完整的 IProductConfig
 *
 * @example
 * ```tsx
 * import { createLighthouseConfig } from '@tencent/tea-sdk-lightclaw';
 *
 * // tea-app-lighthouse OpenClaw（默认）
 * <OpenClawPanel productConfig={createLighthouseConfig()} />
 *
 * // tea-app-lighthouse Hermes
 * <OpenClawPanel productConfig={createLighthouseConfig({ agentType: 'hermes' })} />
 *
 * // mono 平台（非腾讯云账号体系）：屏蔽依赖腾讯云 CAPI 的 provider
 * <OpenClawPanel productConfig={createLighthouseConfig({ supportsTencentCloudApi: false })} />
 *
 * // Hermes + mono
 * <OpenClawPanel productConfig={createLighthouseConfig({
 *   agentType: 'hermes',
 *   supportsTencentCloudApi: false,
 * })} />
 * ```
 */
export declare function createLighthouseConfig(options?: ICreateLighthouseConfigOptions): IProductConfig;
