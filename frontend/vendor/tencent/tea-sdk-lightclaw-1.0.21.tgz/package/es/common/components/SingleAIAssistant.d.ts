/**
 * AI 助手控制器 - 桩模块
 * lighthouse 中为 SingleAIAssistant 组件，SDK 中暂不可用
 * 后续 lighthouse 迁移时补充实现
 */
export declare const AIAssistantController: {
    change: (_opts: any) => void;
};
