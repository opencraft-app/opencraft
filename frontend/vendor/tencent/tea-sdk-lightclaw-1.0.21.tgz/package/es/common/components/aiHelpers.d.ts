/**
 * AI 辅助函数 - 桩模块
 * lighthouse 中用于构造实例环境信息列表，SDK 中暂不可用
 */
export declare const getInstanceEnvList: (_instance: any) => [string, string][];
