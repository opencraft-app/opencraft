import React from 'react';
import type { IExecuteCommandOptions } from '../../components/OpenClawPanel/types';
import type { LightClawScriptsSDK as LightClawSDK } from '../../scripts/create-scripts';
/** 心跳脉搏 SVG 图标 */
interface IOpenClawOpsCardsProps {
    /** 操作是否禁用的提示文案，为空表示可操作 */
    operationDisabledTip: string;
    /** 是否正在升级中 */
    isUpgrading: boolean;
    /** 当前实例数据 */
    instance: any;
    /** 命令执行函数（由父组件通过 context 提供） */
    executeGatewayCommand: (options: IExecuteCommandOptions) => Promise<void>;
    /** SDK 命令实例（用于获取 shell 命令字符串） */
    scriptCommands: LightClawSDK;
}
/** 自愈操作步骤列表 */
/**
 * OpenClaw 运维操作卡片组件
 * 包含「自愈」和「一键排障」两个功能卡片，上下排列
 */
declare const OpenClawOpsCards: React.FC<IOpenClawOpsCardsProps>;
export default OpenClawOpsCards;
