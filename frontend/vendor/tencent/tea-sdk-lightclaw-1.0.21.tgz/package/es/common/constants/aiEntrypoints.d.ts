/**
 * AI 入口点常量 - 桩模块
 * lighthouse 中定义 AI 助手入口点，SDK 中暂不可用
 */
export declare const AI_ENTRYPOINTS: {
    readonly OPENCLAW_TROUBLESHOOT: "openclaw_troubleshoot";
};
