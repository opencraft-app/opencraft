/**
 * 初始化 SDK 的国际化词条。
 *
 * tea-scripts（webpack）消费方：SDK 入口自动调用，无需手动。
 * Vite 消费方：必须在应用入口显式调用一次 `initI18n()`，否则
 * 生产构建中 t() 返回空字符串（Rollup 会 tree-shake 掉纯副作用代码）。
 *
 * 多次调用安全（幂等），tea-app i18n.init 会合并词条。
 */
export declare function initI18n(): void;
