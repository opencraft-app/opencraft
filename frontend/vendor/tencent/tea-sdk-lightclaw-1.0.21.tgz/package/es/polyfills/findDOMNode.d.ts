/**
 * React 19 兼容 polyfill —— 为 `@tencent/tea-component` 补齐已移除的 API。
 *
 * tea-component 内部使用了三个 React 19 已移除的 `react-dom` API：
 *
 *   1. `ReactDOM.findDOMNode(instance)`
 *      - DomRef.js / ThemeMode.js / react-transition-group
 *
 *   2. `ReactDOM.render(element, container, callback?)`
 *      - Modal.show / Modal.confirm / Modal.alert
 *      - notification.open / message.info / message.error …
 *
 *   3. `ReactDOM.unmountComponentAtNode(container)`
 *      - 上述命令式弹窗关闭时卸载
 *
 * 本模块在 import 时自动把这三个 API 补回 `react-dom` 的 exports 对象。
 *
 * **Import this file for its side effects only.**
 * SDK 入口（`src/index.ts`）在最顶部引入，保证在任何 tea-component
 * 模块被评估前完成补丁。
 *
 * ## 平台差异
 *
 * - **webpack / tea-scripts (React 16/17)**：这些 API 本来就存在，
 *   `if` 守卫会自动跳过，零开销。
 * - **Vite + React 19**：Vite 把 `react-dom` 预打包成 ESM，namespace
 *   对象本身是 sealed 的，但 `.default` 指向的是可变的 CJS `module.exports`，
 *   tea-component 最终读的也是这个对象。在 `.default` 上打补丁即可。
 *   不过由于 Vite 预打包的时序问题，SDK 侧的 polyfill 不一定能在
 *   deps chunk 之前执行，因此 **Vite 消费方还需要在 `vite.config.ts`
 *   里通过 esbuild 注入同等逻辑**（详见开发指南）。
 */
export {};
