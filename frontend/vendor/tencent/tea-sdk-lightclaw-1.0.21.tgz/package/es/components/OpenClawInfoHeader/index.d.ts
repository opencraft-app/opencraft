/**
 * OpenClawInfoHeader — OpenClaw 信息头部组件
 *
 * 对应 tea-app-lighthouse OpenClawInfo.tsx 中的头部区域：
 * Logo + 版本号 + 运行状态 + 重启按钮 + 一键更新 + WebUI/更新日志/问题反馈按钮
 *
 * 业务数据（镜像查询、升级状态、featureFlags 等）由宿主应用计算后通过 props 传入，
 * 本组件仅负责 UI 渲染和交互。
 */
import React from 'react';
import type { IFeatureFlags, IInstanceInfo } from '../OpenClawPanel/types';
import type { IFirewallAdapter, IProductConfig } from '../../common/config/types';
import type { LightClawScriptsSDK } from '../../scripts/create-scripts';
export interface IOpenClawInfoHeaderProps {
    /** 实例信息 */
    instance: IInstanceInfo;
    /** 功能特性标志 */
    featureFlags: IFeatureFlags;
    /** 操作禁用提示（为空表示可操作） */
    operationDisabledTip: string;
    /** 是否国际站 */
    isI18n?: boolean;
    /** 软件名称（如 "OpenClaw"） */
    softwareName?: string;
    /** 当前展示版本号（如 "3.23" 或 "2026.3.11"） */
    currentDisplayVersion?: string;
    /** 数据是否加载完成 */
    isDataReady: boolean;
    /** 是否正在升级 */
    isUpgrading: boolean;
    /** 升级是否失败 */
    isUpgradeFailed?: boolean;
    /** 是否有新版本可升级 */
    hasNewVersion?: boolean;
    /** 当前升级阶段（如 "0"、"1"、"2"） */
    upgradeStage?: string;
    /**
     * 触发升级回调（可选）
     * 传入时直接使用此回调；未传时内部调 fetchLatestBlueprint + upgrade.triggerUpgrade
     */
    onTriggerUpgrade?: () => void;
    /**
     * 获取最新镜像信息的回调（可选）
     * 返回 { blueprintId, displayVersion }，用于升级确认时刷新最新版本
     * 未传 onTriggerUpgrade 时必须提供此回调
     */
    fetchLatestBlueprint?: () => Promise<{
        blueprintId: string;
        displayVersion: string;
    } | null>;
    /** 最新镜像展示版本（用于升级确认弹窗中的版本特定警告） */
    latestBlueprintDisplayVersion?: string;
    /** 是否显示一键更新按钮（默认 true） */
    showUpgradeButton?: boolean;
    /** 网关状态查询 loading */
    gatewayLoading?: boolean;
    /** 网关状态 */
    gatewayStatus?: string;
    /** 当前正在执行的操作 */
    currentAction?: string;
    /** 重启网关回调 */
    onRestartGateway?: () => void;
    /** 地域简称（WebUI 面板内部创建 scriptCommands 所需） */
    regionShortName?: string;
    /** 外部注入的 scriptCommands（可选） */
    scriptCommands?: LightClawScriptsSDK;
    /** 产品差异化配置（可选） */
    productConfig?: IProductConfig;
    /** 防火墙适配器（传入则启用 WebUI 面板） */
    firewallAdapter?: IFirewallAdapter;
    /** 当前蓝图展示版本 */
    displayBlueprintVersion?: string;
    /** 自定义类名 */
    className?: string;
    /** 自定义 Logo URL */
    logoUrl?: string;
    /** 更新日志链接 */
    changelogUrl?: string;
    /** 问卷调查链接 */
    surveyUrl?: string;
}
declare const OpenClawInfoHeader: React.FC<IOpenClawInfoHeaderProps>;
export default OpenClawInfoHeader;
