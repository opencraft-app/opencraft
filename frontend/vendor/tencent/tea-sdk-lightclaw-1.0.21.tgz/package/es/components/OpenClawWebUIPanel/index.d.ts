/**
 * OpenClawWebUIPanel — WebUI 面板组件
 *
 * 对应 tea-app-lighthouse OpenClawWebUIPanel.tsx，逻辑完全一致。
 * 独立封装 WebUI 开启流程：修改端口(如需) → 检查端口 → 放通端口(如需) → 启动WebUI
 */
import React from 'react';
import type { IFirewallAdapter, IProductConfig } from '../../common/config/types';
import type { LightClawScriptsSDK } from '../../scripts/create-scripts';
import type { IInstanceInfo, IFeatureFlags } from '../OpenClawPanel/types';
export interface IOpenClawWebUIPanelProps {
    visible: boolean;
    onClose: () => void;
    /** 实例信息（必传） */
    instance: IInstanceInfo;
    /** 地域简称（与 scriptCommands 二选一） */
    regionShortName?: string;
    /** 外部注入的 scriptCommands（与 regionShortName 二选一） */
    scriptCommands?: LightClawScriptsSDK;
    /** 功能特性标志（必传） */
    featureFlags: IFeatureFlags;
    /** 产品差异化配置（可选，默认 lighthouse） */
    productConfig?: IProductConfig;
    /** 当前生效的蓝图版本 */
    displayBlueprintVersion?: string;
    /** 防火墙适配器 — 用于检查/放通端口 */
    firewallAdapter: IFirewallAdapter;
    /** 数据是否就绪 */
    isDataReady?: boolean;
    /** 操作禁用提示 */
    operationDisabledTip?: string;
}
/**
 * WebUI 面板组件
 * 独立封装 WebUI 开启流程：修改端口(如需) → 检查端口 → 放通端口(如需) → 启动WebUI
 */
declare const OpenClawWebUIPanel: (props: IOpenClawWebUIPanelProps) => React.JSX.Element;
export default OpenClawWebUIPanel;
