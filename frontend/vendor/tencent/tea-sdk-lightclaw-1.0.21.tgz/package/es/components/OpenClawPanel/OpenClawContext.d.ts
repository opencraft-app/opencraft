/// <reference types="react" />
import type { IOpenClawContextValue } from './types';
export declare const OpenClawProvider: import("react").Provider<IOpenClawContextValue>;
export declare function useOpenClawContext(): IOpenClawContextValue;
