import React from 'react';
import type { IConfirmModalConfig } from './types';
/**
 * ConfirmModals manages confirmation modals extracted from OpenClawConfig.
 *
 * tea-component Modal 在 Vite+React19 环境下 visible 切换不生效，
 * 改用 createPortal + 自定义 JSX 实现，样式复用 styles/index.css 中 _lh-confirm-modal__* 规则。
 */
export interface IConfirmModalsProps {
    onRegister: (openConfirmModal: (config: IConfirmModalConfig) => void) => void;
}
export default function ConfirmModals({ onRegister }: IConfirmModalsProps): React.ReactPortal;
