import React from 'react';
import type { LightClawScriptsSDK } from '../../scripts/create-scripts';
import type { ICommandExecutor } from '../../scripts/executor';
import type { IFeatureFlags, IInstanceInfo, IConfigData } from './types';
export interface IQrCodeModalProps {
    channel: string;
    channelId: string;
    channelKey: string;
    channelExtra: string;
    configureChannel: (overrideValues?: {
        channelIdValue: string;
        channelKeyValue: string;
    }, options?: {
        skipPluginCheck?: boolean;
    }) => Promise<void>;
    validateChannelConfig: () => boolean;
    /** Called when internal qrCodeStatus changes so parent can react (e.g. disable buttons) */
    onStatusChange?: (status: 'init' | 'loading' | 'ready' | 'failed' | 'success') => void;
    /** 以下字段原从 Context 获取，现由父组件透传 */
    instance: IInstanceInfo;
    restartGateway: (showLoading?: boolean) => Promise<void>;
    getOpenclawConfig: (silent?: boolean) => Promise<IConfigData | void>;
    featureFlags: IFeatureFlags;
    scriptCommands: LightClawScriptsSDK;
    executor: ICommandExecutor;
}
/** Imperative handle exposed via ref for triggering QR code flows from parent */
export interface IQrCodeModalHandle {
    startQrCodeFlow: () => Promise<void>;
    startWecomLongConnQrCodeFlow: () => Promise<void>;
}
export declare const QrCodeModal: React.ForwardRefExoticComponent<IQrCodeModalProps & React.RefAttributes<IQrCodeModalHandle>>;
export default QrCodeModal;
