import React from 'react';
interface ICardHeaderProps {
    icon: React.ReactNode;
    title: React.ReactNode;
}
export default function CardHeader({ icon, title }: ICardHeaderProps): React.JSX.Element;
export {};
