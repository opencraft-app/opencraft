/**
 * @fileoverview HermesQrCodeModal — Hermes 镜像专用扫码弹窗
 *
 * tea-component Modal 在 Vite+React19 环境下 visible 切换不生效，
 * 改用纯 JSX + createPortal 实现，DOM 结构对齐截图视觉。
 *
 * 参考实现：tea-app-lighthouse feat/hermes1.0 分支 HermesPanel/ChannelCard.tsx
 */
import React from 'react';
import type { LightClawScriptsSDK } from '../../scripts/create-scripts';
import type { ICommandExecutor } from '../../scripts/executor';
import type { IInstanceInfo } from './types';
export declare type HermesQrStatus = 'init' | 'loading' | 'ready' | 'expired' | 'failed' | 'success';
export interface IHermesQrCodeModalProps {
    channel: string;
    scriptCommands: LightClawScriptsSDK;
    executor: ICommandExecutor;
    instance: IInstanceInfo;
    onSuccess?: () => Promise<void> | void;
    onStatusChange?: (status: HermesQrStatus) => void;
}
export interface IHermesQrCodeModalHandle {
    startQrCodeFlow: () => Promise<void>;
}
export declare const HermesQrCodeModal: React.ForwardRefExoticComponent<IHermesQrCodeModalProps & React.RefAttributes<IHermesQrCodeModalHandle>>;
export default HermesQrCodeModal;
