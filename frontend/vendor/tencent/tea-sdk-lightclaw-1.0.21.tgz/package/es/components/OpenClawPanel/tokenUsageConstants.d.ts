export declare const TOKEN_TYPES: readonly ["input", "output", "cacheRead", "cacheWrite"];
export declare type TokenType = typeof TOKEN_TYPES[number];
export declare const TOKEN_COLORS: Record<string, string>;
export declare const TOKEN_LABELS: Record<string, string>;
