import React from 'react';
import type { IOpenClawPanelProps } from './types';
declare const OpenClawPanel: React.FC<IOpenClawPanelProps>;
export default OpenClawPanel;
