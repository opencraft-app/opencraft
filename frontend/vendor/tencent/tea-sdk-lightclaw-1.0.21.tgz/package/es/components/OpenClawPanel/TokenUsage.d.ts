import React from 'react';
import type { LightClawScriptsSDK } from '../../scripts/create-scripts';
import type { IInstanceInfo, IFeatureFlags } from './types';
import type { IProductConfig } from '../../common/config/types';
export interface TokenUsageProps {
    /** 实例信息（必传） */
    instance: IInstanceInfo;
    /** 地域简称（与 scriptCommands 二选一） */
    regionShortName?: string;
    /** 外部注入的 scriptCommands（与 regionShortName 二选一） */
    scriptCommands?: LightClawScriptsSDK;
    /** 功能特性标志（必传） */
    featureFlags: IFeatureFlags;
    /** 产品差异化配置（可选） */
    productConfig?: IProductConfig;
}
export default function ClawBotTokenUsage(props: TokenUsageProps): React.JSX.Element;
