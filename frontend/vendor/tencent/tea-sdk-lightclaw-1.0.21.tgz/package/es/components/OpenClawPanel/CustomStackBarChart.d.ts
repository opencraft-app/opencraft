import React from 'react';
interface ProviderData {
    provider: string;
    count: number;
    totals: {
        input: number;
        output: number;
        cacheRead: number;
        cacheWrite: number;
        totalTokens: number;
        [key: string]: any;
    };
}
interface CustomStackBarChartProps {
    byProvider: ProviderData[];
    totalTokens: number;
}
export default function CustomStackBarChart({ byProvider, totalTokens }: CustomStackBarChartProps): React.JSX.Element;
export {};
