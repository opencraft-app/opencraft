import type { IProductConfig } from '../../common/config/types';
import type { LightClawScriptsSDK as LightClawSDK } from '../../scripts/create-scripts';
import type { ICommandExecutor } from '../../scripts/executor';
/**
 * 安全获取字符串值，防止用户篡改字段为对象导致渲染异常
 */
export declare const safeString: (value: unknown, defaultValue?: string) => string;
/**
 * 加载状态展示：根据 loading 返回 Status 组件 props
 */
export declare const getLoadingStatusProps: (isLoading: boolean) => {
    icon: "loading" | "blank";
    title: string;
};
/**
 * 判断当前蓝图版本是否支持指定功能
 * 替代 11 个 isSupportXxx 布尔 props 的逐层传递
 */
export declare const isFeatureSupported: (isOpenClawBlueprint: boolean, displayBlueprintVersion: string, feature: string, productConfig?: IProductConfig) => boolean;
/**
 * 密钥遮罩：保留前3字符，其余替换为星号
 */
export declare const maskSecret: (value: string) => string;
/**
 * LINE 通道：写入 userId 配置到 credentials/line-default-allowFrom.json
 * @returns 是否成功
 */
export declare const writeLineUserId: (params: {
    scriptCommands: LightClawSDK;
    executor: ICommandExecutor;
    channelExtra: string;
    onError?: (msg: string) => void;
}) => Promise<boolean>;
/**
 * 添加通道前确保对应 plugin 已开启
 * - 无映射的通道（国际通道等）直接返回 true
 * - 已开启则跳过，未开启则自动开启
 * @returns 是否成功（true = 已就绪 / 无需操作）
 */
export declare const ensurePluginEnabled: (params: {
    channelValue: string;
    scriptCommands: LightClawSDK;
    executor: ICommandExecutor;
    isSupportQQBotPlugin?: boolean;
    productConfig?: IProductConfig;
}) => Promise<boolean>;
/**
 * 删除通道后，如果没有其他通道还在使用同一个 plugin，则自动关闭该 plugin
 * @param channelValue  被删除的通道 value
 * @param remainingChannels  删除后剩余的通道列表（每项需有 value 字段）
 * @param executeGatewayCommand  执行远端命令的函数
 */
export declare const disablePluginIfUnused: (params: {
    channelValue: string;
    remainingChannels: Array<{
        value?: string;
    }>;
    scriptCommands: LightClawSDK;
    executor: ICommandExecutor;
    isSupportQQBotPlugin?: boolean;
    productConfig?: IProductConfig;
}) => Promise<void>;
