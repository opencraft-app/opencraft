import React from 'react';
import 'xterm/css/xterm.css';
/**
 * Terminal QR Code 渲染组件
 * 使用 xterm.js 渲染 ASCII 字符二维码
 */
interface ITerminalQRCodeProps {
    qrCodeText: string;
}
declare const TerminalQRCode: ({ qrCodeText }: ITerminalQRCodeProps) => React.JSX.Element;
export default TerminalQRCode;
