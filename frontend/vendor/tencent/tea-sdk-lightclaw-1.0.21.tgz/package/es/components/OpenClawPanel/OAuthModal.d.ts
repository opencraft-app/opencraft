import React from 'react';
import type { IModelProvider } from '../../common/config/types';
import type { LightClawScriptsSDK } from '../../scripts/create-scripts';
import type { IExecuteCommandOptions } from './types';
export interface IOAuthModalProps {
    visible: boolean;
    onClose: () => void;
    providerInfo: IModelProvider | null;
    model: string;
    /** 命令执行函数（由父组件透传） */
    executeGatewayCommand: (options: IExecuteCommandOptions) => Promise<void>;
    /** 重启网关并刷新配置（由父组件透传） */
    restartAndRefresh: (needRestart?: boolean) => Promise<void>;
    /** SDK 脚本命令集（由父组件透传） */
    scriptCommands: LightClawScriptsSDK;
}
export declare function OAuthModal(props: IOAuthModalProps): React.JSX.Element;
export default OAuthModal;
