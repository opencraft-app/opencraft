import React from 'react';
export default function CustomLegend(): React.JSX.Element;
