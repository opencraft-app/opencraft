export declare const TUTORIAL_URL: string;
