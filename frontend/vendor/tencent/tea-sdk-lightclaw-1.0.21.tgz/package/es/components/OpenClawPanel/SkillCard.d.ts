import React from 'react';
import type { IProductConfig } from '../../common/config/types';
import type { LightClawScriptsSDK } from '../../scripts/create-scripts';
import type { IInstanceInfo, IFeatureFlags } from './types';
export interface SkillCardProps {
    /** 实例信息（必传） */
    instance: IInstanceInfo;
    /** 地域简称（与 scriptCommands 二选一） */
    regionShortName?: string;
    /** 外部注入的 scriptCommands（与 regionShortName 二选一） */
    scriptCommands?: LightClawScriptsSDK;
    /** 功能特性标志（必传） */
    featureFlags: IFeatureFlags;
    /** 产品差异化配置（可选，默认 lighthouse） */
    productConfig?: IProductConfig;
    /** 数据是否就绪 */
    isDataReady: boolean;
    /** 操作是否禁用 */
    isOperationDisabled: boolean;
    /** 操作禁用提示文案 */
    operationDisabledContent: string;
    /** 操作禁用提示 */
    operationDisabledTip: string;
}
export default function SkillCard(props: SkillCardProps): React.JSX.Element;
