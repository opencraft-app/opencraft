import React from 'react';
import type { LightClawScriptsSDK } from '../../scripts/create-scripts';
import type { IInstanceInfo, IFeatureFlags } from './types';
import type { IProductConfig } from '../../common/config/types';
export interface HospitalProps {
    /** 实例信息（必传） */
    instance: IInstanceInfo;
    /** 地域简称（与 scriptCommands 二选一） */
    regionShortName?: string;
    /** 外部注入的 scriptCommands（与 regionShortName 二选一） */
    scriptCommands?: LightClawScriptsSDK;
    /** 功能特性标志（必传） */
    featureFlags: IFeatureFlags;
    /** 产品差异化配置（可选，默认 lighthouse） */
    productConfig?: IProductConfig;
    /** 操作是否禁用的提示文案，为空表示可操作 */
    operationDisabledTip: string;
    /** 是否正在升级中 */
    isUpgrading: boolean;
    /** 操作是否禁用 */
    isOperationDisabled: boolean;
    /** 数据是否就绪 */
    isDataReady?: boolean;
}
export default function Hospital(props: HospitalProps): React.JSX.Element;
