# Tea 框架 - 组件库

## 文档 & 示例

组件用法可参考 http://tea.tencent.com/component

## 组件目录

组件升级还在进行中，进度如下（🏃 进行中 📌 已计划 🕒 暂时挂起）：

<!--<ComponentTOC>-->

- 通用
  - [x] [Theme](./src/theme) - 主题
  - [x] [Button](./src/button) - 按钮
  - [x] [Icon](./src/icon) - 图标
  - [x] [Avatar](./src/avatar) - 头像
- 布局
  - [x] [Grid](./src/grid) - 栅格
  - [x] [Layout](./src/layout) - 布局
  - [x] [Justify](./src/justify) - 端对齐
  - [x] [Space](./src/space) - 间距
- 导航
  - [x] [Breadcrumb](./src/breadcrumb) - 面包屑
  - [x] [Jumper](./src/jumper) - 跳转
  - [x] [Link](./src/link) - 链接
  - [x] [Menu](./src/menu) - 左侧菜单
  - [x] [NavMenu](./src/navmenu) - 导航菜单
  - [x] [Pagination](./src/pagination) - 分页
  - [x] [Tabs](./src/tabs) - 选项卡
- 展示
  - [x] [Alert](./src/alert) - 警示
  - [x] [Badge](./src/badge) - 徽章
  - [x] [Calendar](./src/calendar) - 日历
  - [x] [Card](./src/card) - 卡片
  - [x] [Collapse](./src/collapse) - 折叠面板
  - [x] [Form](./src/form) - 表单
  - [x] [List](./src/list) - 列表
  - [x] [MediaObject](./src/mediaobject) - 媒体对象
  - [x] [MetricsBoard](./src/metricsboard) - 统计面板
  - [x] [Progress](./src/progress) - 进度
  - [x] [Status](./src/status) - 状态
  - [x] [StatusTip](./src/tips) - 加载状态提示
  - [x] [Stepper](./src/stepper) - 步骤
  - [x] [Table](./src/table) - 表格
  - [x] [Tag](./src/tag) - 标签
  - [x] [Text](./src/text) - 文本
  - [x] [Timeline](./src/timeline) - 时间轴
  - [x] [Tree](./src/tree) - 树形控件
- 输入
  - [x] [AutoComplete](./src/autocomplete) - 自动补全
  - [x] [Checkbox](./src/checkbox) - 多选
  - [x] [Cascader](./src/cascader) - 级联选择
  - [x] [DatePicker](./src/datepicker) - 日期选择
  - [x] [Input](./src/input) - 文本输入
  - [x] [InputAdornment](./src/inputadornment) - 输入装饰
  - [x] [InputNumber](./src/inputnumber) - 数字输入
  - [x] [Radio](./src/radio) - 单选
  - [x] [Rate](./src/rate) - 评分
  - [x] [SearchBox](./src/searchbox) - 搜索
  - [x] [Segment](./src/segment) - 分段选择
  - [x] [Select](./src/select) - 下拉选择
  - [x] [Slider](./src/slider) - 滑块
  - [x] [Switch](./src/switch) - 开关
  - [x] [TagSelect](./src/tagselect) - 标签选择
  - [x] [TimePicker](./src/timepicker) - 时间选择
  - [x] [Upload](./src/upload) - 上传
- 交互
  - [x] [Bubble](./src/bubble) - 气泡
  - [ ] [CheckTree](./src/checktree) - 树状多选
  - [x] [Drawer](./src/drawer) - 抽屉
  - [x] [Dropdown](./src/dropdown) - 下拉
  - [x] [ImagePreview](./src/imagepreview) - 图片预览
  - [x] [Guide](./src/guide) - 引导
  - [x] [Message](./src/message) - 提示
  - [x] [Modal](./src/modal) - 对话框
  - [x] [Notification](./src/notification) - 通知
  - [x] [PopConfirm](./src/popconfirm) - 就地确认
  - [x] [Popover](./src/popover) - 就地弹出
  - [x] [Tooltip](./src/tooltip) - 文本解释
  - [x] [Transfer](./src/transfer) - 穿梭框
  - [x] [Video](./src/video) - 视频播放
- 工具
  - [x] [Affix](./src/affix) - 固钉
  - [x] [Copy](./src/copy) - 复制
  - [x] [Overlay](./src/overlay) - 定位浮层
  - [x] [Transition](./src/transition) - 转场动画
- 业务相关
  - [x] [Blank](./src/blank) - 空白页
  - [x] [MonacoEditor](./src/monacoeditor) - 代码编辑器
  - [x] [RegionSelect](./src/regionselect) - 地域选择
  - [x] [TagSearchBox](./src/tagsearchbox) - 标签搜索
- 其他
  - [x] [ConfigProvider](./src/configprovider) - 全局配置
- 工具方法
  - [x] [ClassNames](./src/util/classnames) - 获取内置类名
  - [x] [Config](./src/util/config) - 获取全局配置
  - [x] [OutsideClick](./src/util/outsideclick) - 外部点击处理
- 不推荐使用
  - [x] [CodeEditor](./src/codeeditor) - 代码输入[@deprecated]
  - [x] [ContentView](./src/contentview) - 内容视图[@deprecated]

<!--</ComponentTOC>-->

## 开发

### 本地开发

前往 `tea-web` 目录，执行 `npm install` 完成依赖安装，然后执行 `npm run start`，即可在本地运行起 Tea 文档站点。

#### 新建组件

如需新建组件，请先在上文 **组件目录** 中添加组件说明，并建立相对应的目录。

#### README.md

网站中组件示例由 `tea-component/src/` 下各组件目录中 `README.md` 生成，一个 `README.md` 的示例如下：

```md
# Button 按钮

提供标准的按钮交互和样式。

## 使用示例

<!-- <Half> -->

### 主要按钮

主按钮是用户在整个页面需要关注的优先级最高的操作，或者是我们需要最想要引导用户关注的操作。

[Example: 主要按钮](./_example/PrimaryButton.jsx)

<!-- </Half> -->

## 组件属性

[Interface: ButtonProps](./Button.tsx)
```

### git 相关

[开发指引](../CONTRIBUTING.md)
