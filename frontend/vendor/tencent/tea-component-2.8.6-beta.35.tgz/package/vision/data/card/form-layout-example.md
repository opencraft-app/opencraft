# Card - 嵌套 Form

## 组件
Card

## 示例描述
嵌套 Form

## 视觉特征
### 整体
该组件采用卡片式布局，分为「布局选项」和「布局效果」两个主要区域。整体风格简洁，以白色为主背景，黑色文字，蓝色强调色用于按钮和选中状态。核心交互包括布局类型切换、表单输入和保存操作。

### Card.Body: title="布局选项"
标题为黑色的「布局选项」，位于卡片顶部，采用无边框设计。

### Card.Body: title="布局效果"
标题为黑色的「布局效果」，位于卡片下半部分，作为表单区域的标题。

### Form.Item: label="姓名"
标签为黑色的「姓名」，右侧为一个带有灰色占位符「你是谁」的输入框。

### Form.Item: label="年龄"
标签为黑色的「年龄」，右侧为一个带有数字「18」的输入框，两侧有「-」和「+」按钮。

### Button: type="primary"
一个蓝色的「保存」按钮，文字为白色，位于表单底部。

## 实现代码
```jsx
import React, { useState } from "react";
import {
  Form,
  Input,
  RadioGroup,
  Radio,
  CheckboxGroup,
  Checkbox,
  InputNumber,
  Card,
  Segment,
  Button,
  Switch,
} from "@tencent/tea-component";

export default function FormLayoutExample() {
  /** @type {any} */
  const [layout, setLayout] = useState("default");
  const [hideLabel, setHideLabel] = useState(false);

  return (
    <div className="example-stage">
      <Card>
        <Card.Body title="布局选项">
          <Form hideLabel={hideLabel}>
            <Form.Item label="布局类型">
              <Segment
                value={layout}
                onChange={layout => setLayout(layout)}
                options={[
                  { value: "default", text: "默认", tooltip: "default" },
                  { value: "fixed", text: "定宽", tooltip: "fixed" },
                  { value: "vertical", text: "垂直", tooltip: "vertical" },
                  { value: "inline", text: "内联", tooltip: "inline" },
                  { value: "flex", text: "flex", tooltip: "flex" },
                  {
                    value: "inline-vertical",
                    text: "内联垂直",
                    tooltip: "inline-vertical",
                  },
                ]}
              />
            </Form.Item>
            <Form.Item label="隐藏 Label">
              <Switch
                value={hideLabel}
                onChange={value => setHideLabel(value)}
              />
            </Form.Item>
          </Form>
        </Card.Body>
        <hr />
        <Card.Body title="布局效果">
          <Form
            layout={layout}
            hideLabel={hideLabel}
            fixedLabelWidth={layout === "fixed" ? "10em" : "20%"}
          >
            <Form.Item label="地址">
              <Form.Text>深圳市南山区</Form.Text>
            </Form.Item>
            <Form.Item label="姓名">
              <Input placeholder="你是谁" size="full" />
            </Form.Item>
            <Form.Item label="性别">
              <RadioGroup>
                <Radio name="male">男</Radio>
                <Radio name="female">女</Radio>
              </RadioGroup>
            </Form.Item>
            <Form.Item label="年龄">
              <InputNumber defaultValue={18} min={12} max={100} />
            </Form.Item>
            <Form.Item label="兴趣">
              <CheckboxGroup>
                <Checkbox name="code">编程</Checkbox>
                <Checkbox name="web">抠图</Checkbox>
                <Checkbox name="jinli">超越</Checkbox>
              </CheckboxGroup>
            </Form.Item>
            <Form.Item label="自我介绍" tips="100 字以内">
              <Input multiline placeholder="介绍下自己" />
            </Form.Item>
          </Form>
          <Form.Action>
            <Button type="primary">保存</Button>
            <Button>取消</Button>
          </Form.Action>
        </Card.Body>
      </Card>
    </div>
  );
}
```
