# Card - 结合 Tabs

## 组件
Card

## 示例描述
结合 Tabs

## 视觉特征
### 整体
该组件采用卡片式布局，包含顶部标题、描述文本和操作按钮。整体设计简洁，以蓝色为主色调，突出信息层级。核心交互为标签页切换，支持内容分组展示。

### Card: 无具体变体信息
白色背景的矩形卡片，顶部有蓝色背景的标题区域，下方为描述文本和操作按钮。

### Tabs: 无具体变体信息
水平排列的标签页，用于切换不同内容区域，当前选中状态以蓝色高亮显示。

### Button: 无具体变体信息
两个并列的按钮，分别为“查看”和“下载”，文字颜色为蓝色，背景为白色。

## 实现代码
```jsx
import React, { useState } from "react";
import { Card, Tabs, TabPanel, Switch } from "@tencent/tea-component";

export default function CardExample() {
  const [placement, setPlacement] = useState("top");

  const tabs = [
    { id: "1", label: "Tab 1" },
    { id: "2", label: "Tab 2" },
    { id: "3", label: "Tab 3" },
  ];

  return (
    <>
      <section>
        <Switch
          value={placement === "left"}
          onChange={value => setPlacement(value ? "left" : "top")}
        >
          垂直布局
        </Switch>
      </section>
      <div className="example-stage">
        <Card className="demo-card">
          <Tabs
            tabs={tabs}
            // @ts-ignore
            placement={placement}
          >
            <TabPanel id="1">
              <Card.Body>Tab 1</Card.Body>
            </TabPanel>
            <TabPanel id="2">
              <Card.Body>Tab 2</Card.Body>
            </TabPanel>
            <TabPanel id="3">
              <Card.Body>Tab 3</Card.Body>
            </TabPanel>
          </Tabs>
        </Card>
      </div>
    </>
  );
}

/*
.demo-card {
  line-height: 0;

  .tea-tabs__tabitem {
    height: 50px;
    line-height: 50px;

    .tea-tabs__tab {
      min-width: 100px;
      text-align: center;
    }
  }

  .tea-tabs__backward, .tea-tabs__forward {
    height: 50px;
  }

  .tea-tabs--vertical {
    .tea-tabs__tab {
      text-align: right;
    }
  }
}
*/
```
