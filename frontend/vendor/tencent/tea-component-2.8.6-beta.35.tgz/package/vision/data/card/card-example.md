# Card - 基本用法

## 组件
Card

## 示例描述
基本用法

## 视觉特征
### 整体
这是一个卡片组件，采用简洁的白色背景和浅灰色边框。整体布局分为标题区、内容区和操作区。核心交互是右上角的链接按钮。配色以黑白灰为主，文字为深灰色，链接为蓝色。

### Card.Body: subtitle="(小标题)" title="内容区标题"
显示标题为“内容区标题”的卡片内容区，下方有较小字号的灰色“（小标题）”文本。

### Button: type="link"
一个蓝色的文本链接按钮，文字为“操作区”，无边框，具有下划线效果。

## 实现代码
```jsx
import React, { useState } from "react";
import {
  Card,
  Button,
  Switch,
  useClassNames,
  H3,
} from "@tencent/tea-component";

export default function CardExample() {
  const [headerVisible, setHeaderVisible] = useState(false);
  const [footerVisible, setFooterVisible] = useState(false);
  const [borderVisible, setBorderVisible] = useState(false);
  const { Padding } = useClassNames();

  return (
    <>
      <section>
        <Switch
          value={headerVisible}
          onChange={value => setHeaderVisible(value)}
        >
          显示头部
        </Switch>
        <Switch
          value={footerVisible}
          onChange={value => setFooterVisible(value)}
        >
          显示底部
        </Switch>
        <Switch
          value={borderVisible}
          onChange={value => setBorderVisible(value)}
        >
          显示边框
        </Switch>
      </section>
      <div className="example-stage">
        <Card bordered={borderVisible}>
          {headerVisible && (
            <Card.Header>
              <H3>卡片头部</H3>
            </Card.Header>
          )}
          <Card.Body
            title="内容区标题"
            subtitle="(小标题)"
            operation={<Button type="link">操作区</Button>}
          >
            内容区
          </Card.Body>
          {footerVisible && (
            <Card.Footer>
              <p className={Padding["5n"]}>卡片底部</p>
            </Card.Footer>
          )}
        </Card>
      </div>
    </>
  );
}
```
