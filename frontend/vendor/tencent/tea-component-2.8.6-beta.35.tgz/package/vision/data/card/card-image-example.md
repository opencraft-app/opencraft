# Card - 卡片的使用

## 组件
Card

## 示例描述
卡片的使用

## 视觉特征
### 整体
整体为蓝色背景，带有白色波浪线条装饰，布局简洁，风格现代，无明显交互元素。

## 实现代码
```jsx
import React from "react";
import { Card } from "@tencent/tea-component";

export default function CardExample() {
  return (
    <div className="example-stage">
      <Card style={{ maxWidth: 400 }}>
        <img
          style={{ width: "100%", display: "block" }}
          src="////main.qcloudimg.com/raw/6c8fd423cd9bdd7a77b0e99725e04fff.png"
          alt="bg"
        />
      </Card>
    </div>
  );
}
```
