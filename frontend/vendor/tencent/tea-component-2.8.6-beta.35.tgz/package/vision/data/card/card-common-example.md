# Card - 典型卡片

## 组件
Card

## 示例描述
典型卡片

## 视觉特征
### 整体
该组件采用分层布局，包含头部、内容区和底部。核心交互为蓝色链接按钮，整体风格简洁，以白色为主背景，文字为深灰色，链接为蓝色。

### Card.Body: subtitle="(小标题)" title="内容区标题"
显示标题和小标题，标题为深灰色，小标题为浅灰色，文字居左对齐。

### Button: type="link"
蓝色文本链接，无边框，文字为“操作区”，用于触发交互。

## 实现代码
```jsx
import React from "react";
import { Card, Button, useClassNames } from "@tencent/tea-component";

export default function CardExample() {
  const { Padding } = useClassNames();

  return (
    <div className="example-stage">
      <Card>
        <Card.Header>
          <h3>卡片头部</h3>
        </Card.Header>
        <Card.Body
          title="内容区标题"
          subtitle="(小标题)"
          operation={<Button type="link">操作区</Button>}
        >
          内容区
        </Card.Body>

        <Card.Footer>
          <p className={Padding["5n"]}>卡片底部</p>
        </Card.Footer>
      </Card>

      <Card>
        <Card.Body
          title="内容区标题"
          subtitle="(小标题)"
          operation={<Button type="link">操作区</Button>}
        >
          内容区
        </Card.Body>
      </Card>

      <Card>
        <Card.Body>内容区</Card.Body>
      </Card>
    </div>
  );
}
```
