# Card - 卡片的使用

## 组件
Card

## 示例描述
卡片的使用

## 视觉特征
### 整体
采用垂直布局，卡片主体包含标题和小标题，下方为标签页导航。整体风格简洁，以白色为主背景，文字为深灰色，标签页选中状态用蓝色下划线高亮。

### Card.Body: subtitle="(小标题)" title="标题"
卡片内包含标题和小标题，标题为深灰色，小标题为浅灰色，文字居左对齐。

### Button: type="link"
链接按钮，无背景色，文字为深灰色，无边框，呈现可点击的文本样式。

## 实现代码
```jsx
import React from "react";
import { Card, Button, H3 } from "@tencent/tea-component";

export default function CardExample() {
  return (
    <div className="example-stage">
      <Card style={{ maxWidth: 400 }}>
        <img
          width="100%"
          src="////main.qcloudimg.com/raw/6c8fd423cd9bdd7a77b0e99725e04fff.png"
          alt="bg"
        />
        <Card.Body title="标题" subtitle="(小标题)">
          描述文案
        </Card.Body>
        <Card.Footer style={{ padding: "8px 20px" }}>
          <Button type="link">查看</Button>
          <Button type="link" style={{ marginLeft: 16 }}>
            下载
          </Button>
        </Card.Footer>
      </Card>
      <Card style={{ maxWidth: 400, marginTop: 16 }}>
        <Card.Header>
          <H3>标题</H3>
        </Card.Header>
        <img
          width="100%"
          src="////main.qcloudimg.com/raw/6c8fd423cd9bdd7a77b0e99725e04fff.png"
          alt="bg"
        />
        <Card.Body>描述文案</Card.Body>
        <Card.Footer style={{ padding: "8px 20px" }}>
          <Button type="link">查看</Button>
          <Button type="link" style={{ marginLeft: 16 }}>
            下载
          </Button>
        </Card.Footer>
      </Card>
    </div>
  );
}
```
