# Card - 卡片的使用

## 组件
Card

## 示例描述
卡片的使用

## 视觉特征
### 整体
整体采用卡片式布局，主标题为「快速入门」，下方为四宫格卡片排列。卡片具有边框，内容包含图标、标题和状态信息。核心交互为卡片点击，整体配色以白色背景和灰色文字为主，图标和状态符号使用橙色。

### Card: bordered=true
卡片带有浅灰色边框，背景为白色，整体呈现清晰的矩形轮廓。

### Card.Body: title="快速入门"
卡片标题为「快速入门」，文字为深灰色，位于卡片顶部居左位置。

### Col: span=6
列布局占6个网格单位，用于控制卡片在容器中的宽度比例。

### Col: span=8
列布局占8个网格单位，用于控制卡片在容器中的宽度比例。

### Icon: type="monitor"
图标为「monitor」，显示为一个显示器形状，颜色为灰色。

## 实现代码
```jsx
import React from "react";
import {
  Card,
  Row,
  Col,
  H3,
  Icon,
  useClassNames,
} from "@tencent/tea-component";

export default function CardExample() {
  const { FontSizeReset } = useClassNames();
  return (
    <div className="example-stage">
      <Card>
        <Card.Body
          title="快速入门"
          operation={<a className={FontSizeReset}>更多</a>}
        >
          <Row>
            <Col span={6}>
              <Item />
            </Col>
            <Col span={6}>
              <Item />
            </Col>
            <Col span={6}>
              <Item />
            </Col>
            <Col span={6}>
              <Item />
            </Col>
          </Row>
        </Card.Body>
      </Card>
    </div>
  );
}

function Item() {
  return (
    <Card bordered>
      <Card.Body>
        <img
          alt="logo"
          src="//mc.qcloudimg.com/static/img/8550e1784df7cb15221a6b5617ba0b4d/Linux.svg"
        />
        <H3>Linux 基础入门</H3>
      </Card.Body>
      <Card.Footer>
        <Row style={{ padding: "8px 20px" }}>
          <Col span={8}>
            <Icon type="monitor" />
          </Col>
          <Col span={8}>
            <Icon type="pending" />
          </Col>
          <Col span={8}>
            <Icon type="realname" />
          </Col>
        </Row>
      </Card.Footer>
    </Card>
  );
}
```
