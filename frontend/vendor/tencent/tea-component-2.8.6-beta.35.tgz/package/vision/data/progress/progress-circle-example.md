# Progress - 环形进度条

## 组件
Progress

## 示例描述
环形进度条

## 视觉特征
### 整体
两个环形进度条组件并列展示，均采用简洁的圆形设计，背景为浅灰色，进度条为粉色，中心显示百分比数值，整体风格现代、清晰。

### Progress: tips="正在上传应用，请稍等" type="circle"
背景为浅灰色，边框为浅灰色，进度条为粉色，中心显示黑色"20%"，无额外文字或图标，尺寸中等。

### Progress: text="加固中" theme="default" type="circle"
背景为浅灰色，边框为浅灰色，进度条为粉色，中心显示黑色"20%"，上方有黑色"加固中"文字，尺寸中等。

## 实现代码
```jsx
import React, { useState, useEffect } from "react";
import { Progress } from "@tencent/tea-component";

export default function ProgressCircleExample() {
  const [percent, setPercent] = useState(0);

  useEffect(() => {
    const timer = setInterval(
      () => setPercent(percent => (percent % 100) + 10),
      1000
    );
    return () => clearInterval(timer);
  }, []);

  return (
    <>
      <Progress type="circle" percent={percent} tips="正在上传应用，请稍等" />
      <hr />
      <Progress
        type="circle"
        theme="default"
        percent={percent}
        text="加固中"
        tips={
          <>
            <p>大约需要5分钟，您可以先去进行其他操作，稍后再来看看。</p>
            <p>
              推荐您使用<a href="#">乐固自助加固</a>工具，可自动加固、签名。
            </p>
          </>
        }
      />
    </>
  );
}
```
