# Progress - 自定义样式

## 组件
Progress

## 示例描述
自定义样式

## 视觉特征
### 整体
整体布局为垂直排列的两个进度组件，采用简洁的白色背景和圆角设计，文字内容清晰，主要展示上传进度状态。

### Progress: strokeColor="#faa3c4" strokeWidth=16
圆形进度条，背景为白色，边框为粉色，显示文字“20%”，文字颜色为黑色，无图标，尺寸较小。

### Progress: strokeColor="#faa3c4" strokeWidth=16 type="circle"
圆形进度条，背景为白色，边框为粉色，显示文字“加固中”，文字颜色为黑色，无图标，尺寸中等。

### Progress: strokeColor="#faa3c4" strokeWidth=16 type="circle" width=240
圆形进度条，背景为白色，边框为粉色，显示文字“加固中”，文字颜色为黑色，无图标，尺寸较大。

## 实现代码
```jsx
import React, { useState, useEffect } from "react";
import { Progress } from "@tencent/tea-component";

export default function ProgressCircleExample() {
  const [percent, setPercent] = useState(0);

  useEffect(() => {
    const timer = setInterval(
      () => setPercent(percent => (percent % 100) + 10),
      1000
    );
    return () => clearInterval(timer);
  }, []);

  return (
    <>
      <Progress
        percent={percent}
        text={percent => `${percent} %`}
        strokeColor="#faa3c4"
        strokeWidth={16}
      />
      <Progress
        type="circle"
        percent={percent}
        strokeColor="#faa3c4"
        strokeWidth={16}
      />
      <Progress
        type="circle"
        percent={percent}
        strokeColor="#faa3c4"
        strokeWidth={16}
        width={240}
      />
    </>
  );
}
```
