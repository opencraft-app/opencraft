# Progress - 条形进度条

## 组件
Progress

## 示例描述
条形进度条

## 视觉特征
### 整体
条形进度条组件，水平布局，包含进度条、百分比文本和状态文本。设计风格简洁，通过颜色区分状态。

### Progress: percent=30 text="运行中" theme="default"
蓝色进度条，背景为浅灰色，文字为黑色，无图标。

### Progress: percent=60 text="运行失败" theme="danger"
红色进度条，背景为浅灰色，文字为白色，无图标。

### Progress: percent=90 text="运行成功" theme="success"
绿色进度条，背景为浅灰色，文字为白色，无图标。

## 实现代码
```jsx
import React, { useState, useEffect } from "react";
import { Progress } from "@tencent/tea-component";

export default function ProgressCircleExample() {
  const [percent, setPercent] = useState(0);

  useEffect(() => {
    const timer = setInterval(
      () => setPercent(percent => (percent % 100) + 10),
      1000
    );
    return () => clearInterval(timer);
  }, []);

  return (
    <>
      <Progress percent={percent} text={percent => `${percent} %`} />
      <Progress percent={30} theme="default" text="运行中" />
      <Progress percent={60} theme="danger" text="运行失败" />
      <Progress percent={90} theme="success" text="运行成功" />
    </>
  );
}
```
