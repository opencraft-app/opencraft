# Tips - 产品实例状态使用

## 组件
Tips

## 示例描述
产品实例状态使用

## 视觉特征
### 整体
该组件采用水平布局，左侧为圆形状态图标，右侧为文字说明，整体风格简洁，用于展示产品实例的运行状态。

### StatusTip.InstanceTip: status="running"
绿色圆形图标，文字为“运行中”，文字颜色为深灰色。

### StatusTip.InstanceTip: status="operating"
蓝色圆形图标，文字为“关机中”，文字颜色为深灰色。

### StatusTip.InstanceTip: status="closed"
灰色圆形图标，文字为“已关机”，文字颜色为深灰色。

### StatusTip.InstanceTip: status="warning"
橙色圆形图标，文字为“救援模式”，文字颜色为深灰色。

### StatusTip.InstanceTip: status="error"
红色圆形图标，文字为“待回收”，文字颜色为深灰色。

### Text: underline=true
文字带有下划线，用于强调或提示可交互性。

## 实现代码
```jsx
import React from "react";
import { StatusTip, Text } from "@tencent/tea-component";

export default function StatusTipExample() {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        gap: 12,
      }}
    >
      <StatusTip.InstanceTip status="running">运行中</StatusTip.InstanceTip>
      <StatusTip.InstanceTip status="operating">关机中</StatusTip.InstanceTip>
      <StatusTip.InstanceTip status="closed">已关机</StatusTip.InstanceTip>
      <StatusTip.InstanceTip status="warning">
        <Text underline>救援模式</Text>
      </StatusTip.InstanceTip>
      <StatusTip.InstanceTip status="error">待回收</StatusTip.InstanceTip>
    </div>
  );
}
```
