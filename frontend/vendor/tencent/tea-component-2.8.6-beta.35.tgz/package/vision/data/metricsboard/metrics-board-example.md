# Metricsboard - MetricsBoardExample

## 组件
Metricsboard

## 示例描述
MetricsBoardExample

## 视觉特征
### 整体
该组件采用卡片式布局，分为标题区和数据展示区。核心交互为数据对比，通过图标和颜色指示趋势。整体配色以黑白为主，关键数据使用红色突出，风格简洁专业。

### Card.Body: title="昨日数据"
卡片标题区域，显示文字“昨日数据”，字体为常规黑色。

### MetricsBoard: title="语音时长" unit="分钟"
展示数值“7890”，单位为“分钟”，下方有趋势对比信息。

### MetricsBoard: title="语音 DAU 总人数"
展示数值“456”，下方有“比较前天”、“比较上周”、“比较上月”的对比信息。

### Icon: type="trenddown"
向下的箭头图标，表示数据下降趋势。

### Text: theme="danger"
文字颜色为红色，用于强调关键数据或异常状态。

## 实现代码
```jsx
import React from "react";
import {
  Row,
  Col,
  Card,
  MetricsBoard,
  Icon,
  Text,
} from "@tencent/tea-component";
import { ArrowFlatIcon } from "@tencent/tea-icons-react";

export default function MetricsBoardExample() {
  return (
    <Card>
      <Card.Body title="昨日数据">
        <Row showSplitLine>
          <Col>
            <MetricsBoard
              title="语音时长"
              unit="分钟"
              value={7890}
              infos={[
                <>
                  比较前天 <Icon type="trenddown" /> 0%
                </>,
              ]}
              onClick={event => console.log(event)}
            />
          </Col>
          <Col>
            <MetricsBoard
              title="语音 DAU 总人数"
              value={456}
              infos={[
                <>
                  比较前天 <Icon type="trendup" /> 0%
                </>,
                <>
                  比较上周 <Icon type="trenddown" /> 0%
                </>,
                <>
                  比较上月 <ArrowFlatIcon /> 0%
                </>,
              ]}
            />
          </Col>
          <Col>
            <MetricsBoard
              title="语音 DAU 总人数"
              value={789}
              infos={[
                <>
                  <MetricsBoard.InfoLabel>标清</MetricsBoard.InfoLabel>
                  <MetricsBoard.InfoKey>
                    <Text theme="danger">23</Text>
                  </MetricsBoard.InfoKey>
                </>,
                <>
                  <MetricsBoard.InfoLabel>高清</MetricsBoard.InfoLabel>
                  <MetricsBoard.InfoKey>23</MetricsBoard.InfoKey>
                </>,
                <>
                  <MetricsBoard.InfoLabel>1080P</MetricsBoard.InfoLabel>
                  <MetricsBoard.InfoKey>23</MetricsBoard.InfoKey>
                </>,
              ]}
            />
          </Col>
          <Col>
            <MetricsBoard
              title="语音 DAU 总人数"
              value="00"
              infos={[
                <>
                  比较前天 <Icon type="trendup" /> 0%
                </>,
              ]}
            />
          </Col>
        </Row>
      </Card.Body>
    </Card>
  );
}
```
