# Navmenu - NavMenuExample

## 组件
Navmenu

## 示例描述
NavMenuExample

## 视觉特征
### 整体
深色水平导航栏，左侧为品牌标识，中间为导航项，右侧为用户和通知入口。核心交互为点击导航项和下拉菜单。整体采用深色背景，文字和图标使用主色文本色，通知角标为深色危险主题。

### NavMenu.Item: type="logo"
左侧的图片式Logo，作为导航栏的起始标识。

### NavMenu.Item: selected=true
文字为“云服务器”，处于选中状态，文字颜色为白色。

### NavMenu.Item: type="dropdown"
文字为“用户名”和“费用”，带有下拉箭头，表示可展开菜单。

### NavMenu.Item: selected=true type="dropdown"
文字为“工单”，处于选中状态并带有下拉箭头。

### Badge: dark=true theme="danger"
红色的圆形角标，内有白色数字“7”，位于通知图标上。

### 交互后视觉特征
交互后展示导航子菜单：
- 点击/hover 导航项展开子菜单
- 垂直布局时子菜单向下展开
- 水平布局时子菜单向下弹出
- 支持图标和文字组合

## 实现代码
```jsx
import React from "react";
import { NavMenu, List, Icon, Badge } from "@tencent/tea-component";

export default function NavMenuExample() {
  return (
    <div
      style={{
        padding: "20px",
        backgroundColor: "var(--tea-color-bg-page-default)",
      }}
    >
      <NavMenu
        // theme="light"
        left={
          <>
            <NavMenu.Item type="logo">
              <img
                src="https://via.placeholder.com/32.png?text=LOGO"
                alt="logo"
              />
            </NavMenu.Item>
            <NavMenu.Item>总览</NavMenu.Item>
            <NavMenu.Item selected>云服务器</NavMenu.Item>
          </>
        }
        right={
          <>
            <NavMenu.Item
              type="dropdown"
              overlay={close => (
                <List type="option">
                  <List.Item onClick={close}>账号信息</List.Item>
                  <List.Item className="tea-nav__list-line" onClick={close}>
                    安全设置
                  </List.Item>
                  <List.Item onClick={close}>退出</List.Item>
                </List>
              )}
            >
              用户名
            </NavMenu.Item>
            <NavMenu.Item type="dropdown" overlay={<div />} selected>
              费用
            </NavMenu.Item>
            <NavMenu.Item>工单</NavMenu.Item>
            <NavMenu.Item type="icon" selected>
              <Icon type="news" color="var(--tea-color-text-primary)" />
              <Badge dark theme="danger">
                7
              </Badge>
            </NavMenu.Item>
            <NavMenu.Item type="icon">
              <Icon type="help" color="var(--tea-color-text-primary)" />
            </NavMenu.Item>
          </>
        }
      />
    </div>
  );
}
```
