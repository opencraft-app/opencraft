# Menu - MenuWithRouterExample

## 组件
Menu

## 示例描述
MenuWithRouterExample

## 视觉特征
### 整体
这是一个深色主题的垂直菜单组件。左侧为菜单区域，顶部有产品名称标题。核心交互是可展开的菜单项，通过点击展开或收起子菜单。整体采用深色背景和白色文字，视觉对比清晰。

### Menu: theme="dark" title="产品名称"
深色背景的垂直菜单容器，顶部显示白色文字“产品名称”作为标题。

### Menu.SubMenu: defaultOpened=true title="一级菜单"
一个可展开的菜单项，标题为“一级菜单”，默认处于展开状态，显示其子菜单项。

### Menu.Item: title="二级菜单 - foo"
一个菜单项，显示文字“二级菜单 - foo”，文字颜色为白色。

### Menu.Item: title="二级菜单 - bar"
一个菜单项，显示文字“二级菜单 - bar”，文字颜色为白色。

### 交互后视觉特征
交互后，一级菜单项展开，显示其下的两个子菜单项：“二级菜单 - foo”和“二级菜单 - bar”。展开的菜单项背景变为浅灰色，文字颜色为深灰色。

## 实现代码
```jsx
import React from "react";
import { Layout, Card, Menu } from "@tencent/tea-component";

// eslint-disable-next-line import/no-extraneous-dependencies
import { HashRouter, Route, Link, Switch, withRouter } from "react-router-dom";

const { Body, Sider, Content: LayoutContent } = Layout;

const MenuWithRouter = withRouter(function MenuWithRouter({ location }) {
  const pathname = location && location.pathname;
  return (
    <Menu theme="dark" title="产品名称">
      <Menu.Item
        title="一级菜单"
        selected={!pathname || pathname === "/home"}
        render={children => <Link to="/home">{children}</Link>}
      />
      <Menu.SubMenu defaultOpened title="一级菜单">
        <Menu.Item
          title="二级菜单 - foo"
          selected={pathname.startsWith("/foo")}
          render={children => <Link to="/foo">{children}</Link>}
        />
        <Menu.Item
          title="二级菜单 - bar"
          selected={pathname.startsWith("/bar")}
          render={children => <Link to="/bar">{children}</Link>}
        />
      </Menu.SubMenu>
    </Menu>
  );
});

function Content({ match }) {
  const path = match && match.path;
  return (
    <LayoutContent>
      <LayoutContent.Header title={path} />
      <LayoutContent.Body>
        <Card>
          <Card.Body>{path}</Card.Body>
        </Card>
      </LayoutContent.Body>
    </LayoutContent>
  );
}

export default function MenuWithRouterExample() {
  return (
    <HashRouter>
      <Layout className="demo-layout-l">
        <Body>
          <Sider>
            <MenuWithRouter />
          </Sider>
          <Switch>
            <Route path="/home" component={Content} />
            <Route path="/foo" component={Content} />
            <Route path="/bar" component={Content} />
          </Switch>
        </Body>
      </Layout>
    </HashRouter>
  );
}
```
