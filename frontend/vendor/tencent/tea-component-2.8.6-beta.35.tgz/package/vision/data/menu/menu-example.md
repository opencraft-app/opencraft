# Menu - MenuExample

## 组件
Menu

## 示例描述
MenuExample

## 视觉特征
### 整体
左侧为垂直菜单栏，右侧为内容区域。菜单栏包含可展开的菜单项和分组，整体采用浅色背景和深色文字，风格简洁。核心交互为菜单项的展开与收起。

### Menu.Item: title="一级菜单"
菜单项文本为“一级菜单”，文字颜色为深灰色，背景为浅灰色，无边框。

### Menu.Item: title="二级菜单"
菜单项文本为“二级菜单”，文字颜色为深灰色，背景为蓝色，文字颜色为白色。

### Menu.SubMenu: title="一级菜单"
菜单项文本为“一级菜单”，文字颜色为深灰色，背景为浅灰色，右侧有向下的箭头图标。

### Menu.Group: title="菜单分组"
菜单分组标题文本为“菜单分组”，文字颜色为深灰色，背景为浅灰色，无边框。

### ExternalLink: weak=true
外部链接图标为“externallink”类型，颜色为深灰色，尺寸较小，位于文本右侧。

### 交互后视觉特征
交互后，“一级菜单”子项展开，显示“二级菜单”和“菜单分组”等子菜单项，背景颜色变为浅灰色。

## 实现代码
```jsx
import React, { useState } from "react";
import {
  Layout,
  Card,
  Text,
  ExternalLink,
  Menu,
  Icon,
} from "@tencent/tea-component";

const { Body, Sider, Content } = Layout;

export default function MenuExample() {
  const [selected, setSelected] = useState("2-1");

  const getMenuItemProps = id => ({
    selected: selected === id,
    onClick: () => setSelected(id),
  });

  return (
    <Layout className="demo-layout-l">
      <Body>
        <Sider>
          <Menu
            back={{
              title: "产品名称产品名称产品名称",
              description: "数据测试",
              tooltip: "产品名称产品名称产品名称 - 数据测试勿删",
              onClick: () => console.log("back"),
            }}
          >
            <Menu.Item title="一级菜单" {...getMenuItemProps("1")} />
            <Menu.SubMenu title="一级菜单">
              <Menu.Item title="二级菜单" {...getMenuItemProps("2-1")} />
              <Menu.Item title="二级菜单" {...getMenuItemProps("2-2")} />
            </Menu.SubMenu>
            <Menu.Group title="菜单分组">
              <Menu.Item
                title={
                  <>
                    一级菜单
                    <Icon type="externallink" />
                  </>
                }
                {...getMenuItemProps("3")}
              />
            </Menu.Group>

            <Menu.Group title="菜单分组">
              <Menu.SubMenu title="一级菜单">
                <Menu.Item title="二级菜单" {...getMenuItemProps("4-1")} />
                <Menu.Item title="二级菜单" {...getMenuItemProps("4-2")} />
              </Menu.SubMenu>
            </Menu.Group>
          </Menu>
        </Sider>
        <Content>
          <Content.Header
            title="内容标题"
            subtitle={
              <>
                说明文字 <Text theme="label">带颜色说明文字</Text>
              </>
            }
            operation={<ExternalLink weak>内容帮助</ExternalLink>}
          />
          <Content.Body>
            {/* 内容区域一般使用 Card 组件显示内容 */}
            <Card>
              <Card.Body>内容卡片</Card.Body>
            </Card>
          </Content.Body>
        </Content>
      </Body>
    </Layout>
  );
}
```
