# Theme - 切换主题示例

## 组件
Theme

## 示例描述
切换主题示例

## 视觉特征
### 整体
该组件包含两个文本按钮，分别显示浅色和深色文字，右侧为带文字的按钮，整体布局水平排列，风格简洁。

### Text: theme="warning"
显示为深色背景上的白色文字，文字内容为“深色”，文字颜色为白色。

### Text: theme="warning"
显示为浅色背景上的深色文字，文字内容为“浅色”，文字颜色为深色。

### Button: theme="warning"
显示为浅色背景上的深色文字，文字内容为“打开深色抽屉”，文字颜色为深色。

## 实现代码
```jsx
import React, { useState } from "react";
import { CssToken, Switch, Text, ThemeMode } from "@tencent/tea-component";

export default () => {
  const [darkMode, setDarkMode] = useState(false);

  return (
    <>
      <div style={{ marginBottom: "12px" }}>
        <Switch value={darkMode} onChange={setDarkMode}>
          深色主题
        </Switch>
      </div>
      <ThemeMode mode={darkMode ? "dark" : "light"}>
        <div
          style={{
            border: "1px solid",
            borderColor: CssToken.colorBorderPrimaryDefault,
            color: CssToken.colorBgBrandDefault,
            background: CssToken.colorBgPrimaryDefault,
            height: "50px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          Tea design makes it easy to build a beautiful UI
        </div>
        <p style={{ marginTop: 12 }}>
          📢 注意：
          <Text theme="warning">
            控制台业务，框架统一控制深浅模式，无需包裹 ThemeMode
          </Text>
        </p>
      </ThemeMode>
    </>
  );
};
```
