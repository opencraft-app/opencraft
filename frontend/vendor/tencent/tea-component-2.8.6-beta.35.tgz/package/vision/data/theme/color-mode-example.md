# Theme - ColorMode

## 组件
Theme

## 示例描述
ColorMode

## 视觉特征
### 整体
该组件采用左右分栏布局，左侧为深色主题切换控件，右侧为浅色主题示例区域。核心交互为通过左侧控件切换主题模式，整体配色方案为深色与浅色对比，突出主题切换功能。

### Drawer: title="Title"
标题为"Title"的抽屉组件，背景为深色主题，文字颜色为白色。

## 实现代码
```jsx
import React, { useState } from "react";
import {
  LightMode,
  DarkMode,
  Drawer,
  Button,
  CssToken,
} from "@tencent/tea-component";

const CustomDiv = ({ children, style }) => {
  return <div style={style}>{children}</div>;
};

export default () => {
  const [visible, setVisible] = useState(false);
  /** @type {React.CSSProperties} */
  const customDivStyle = {
    borderColor: CssToken.colorBorderPrimaryDefault,
    color: CssToken.colorTextPrimary,
    background: CssToken.colorBgPrimaryDefault,
    height: 26,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flex: 1,
  };
  return (
    <>
      <section style={{ display: "flex", gap: 12, alignItems: "center" }}>
        <LightMode>
          <CustomDiv style={customDivStyle}>浅色</CustomDiv>
        </LightMode>
        <DarkMode>
          <CustomDiv style={customDivStyle}>深色</CustomDiv>
        </DarkMode>
        <Button onClick={() => setVisible(true)}>打开深色抽屉</Button>
      </section>
      <DarkMode>
        <Drawer
          visible={visible}
          title="Title"
          onClose={() => setVisible(false)}
        >
          注入theme-mode
        </Drawer>
      </DarkMode>
    </>
  );
};
```
