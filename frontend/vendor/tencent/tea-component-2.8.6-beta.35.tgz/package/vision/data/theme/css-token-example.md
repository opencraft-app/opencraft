# Theme - CSS Token 示例

## 组件
Theme

## 示例描述
CSS Token 示例

## 视觉特征
### 整体
整体布局为居中显示的文本内容，采用简洁现代风格，文字颜色为蓝色，背景为浅色，突出主题信息。

## 实现代码
```jsx
import React from "react";
import { CssToken } from "@tencent/tea-component";

export default () => (
  <div
    style={{
      color: CssToken.colorTextBrandDefault,
      background: CssToken.colorBgPageDefault,
      height: "50px",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
    }}
  >
    我是主题文字
  </div>
);
```
