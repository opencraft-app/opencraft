# Inputadornment - InputAdornmentSelect

## 组件
Inputadornment

## 示例描述
InputAdornmentSelect

## 视觉特征
### 整体
整体布局为水平排列的输入框与选择器组合，采用简洁的线性设计风格，主要由文本输入框和下拉选择器构成。

### InputAdornmentSelect: 无具体变体信息
输入框左侧显示 'http://' 文本，右侧为下拉选择器，选择器内显示 '.cn' 文本，文字颜色为深灰色。

### InputAdornmentSelect: 无具体变体信息
输入框左侧显示 'http://' 文本，中间为下拉选择器，选择器内显示 'tencent' 文本，右侧为下拉选择器，选择器内显示 '.cn' 文本，文字颜色为深灰色。

## 实现代码
```jsx
import React from "react";
import { InputAdornment, Input, Select } from "@tencent/tea-component";

export default function InputAdornmentExample() {
  const protocolSelect = (
    <Select
      options={["http://", "https://"].map(value => ({ value }))}
      defaultValue="http://"
      style={{ width: "auto" }}
    />
  );

  const tldSelect = (
    <Select
      options={[".com", ".cn", ".net", ".org"].map(value => ({ value }))}
      defaultValue=".cn"
      style={{ width: "auto" }}
    />
  );

  const domainSelect = (
    <Select
      options={["tencent", "qq", "cloud.tencent"].map(value => ({ value }))}
      defaultValue="tencent"
      style={{ width: "auto", marginLeft: "8px" }}
    />
  );

  return (
    <>
      <section>
        <InputAdornment before={protocolSelect}>
          <Input />
        </InputAdornment>
      </section>

      <section>
        <InputAdornment after={tldSelect}>
          <Input />
        </InputAdornment>
      </section>

      <section>
        <InputAdornment before={protocolSelect} after={tldSelect}>
          <Input />
        </InputAdornment>
      </section>

      <section>
        <InputAdornment before={protocolSelect} after={tldSelect}>
          {domainSelect}
        </InputAdornment>
      </section>
    </>
  );
}
```
