# Inputadornment - InputAdornment

## 组件
Inputadornment

## 示例描述
InputAdornment

## 视觉特征
### 整体
该组件采用水平布局，将输入框与前后装饰性文本结合。主要区域包括输入框和左右两侧的文本装饰。核心交互为文本输入，整体配色为中性灰白，文字颜色为深灰色，设计风格简洁现代。

### InputAdornment: before="www."
输入框左侧显示深灰色文本“www.”，作为前缀装饰，无边框，与输入框对齐。

### InputAdornment: after=".com"
输入框右侧显示深灰色文本“.com”，作为后缀装饰，无边框，与输入框对齐。

### InputAdornment: after="Mbps"
输入框右侧显示深灰色文本“Mbps”，作为后缀装饰，无边框，与输入框对齐。

### InputAdornment: after=".00" before="$"
输入框左侧显示深灰色符号“$”，右侧显示深灰色文本“.00”，作为前后缀装饰，无边框，与输入框对齐。

### Input: size="s"
输入框尺寸较小，高度较矮，整体呈紧凑的矩形，边框为浅灰色，内部文本为深灰色。

## 实现代码
```jsx
import React from "react";
import {
  InputAdornment,
  Input,
  InputNumber,
  Select,
} from "@tencent/tea-component";

export default function InputAdornmentExample() {
  const domainSelect = (
    <Select
      options={["tencent", "qq", "cloud.tencent"].map(value => ({ value }))}
      defaultValue="tencent"
      style={{ width: "auto" }}
    />
  );

  return (
    <>
      <section>
        <InputAdornment before="www.">
          <Input />
        </InputAdornment>
      </section>

      <section>
        <InputAdornment before="$" after=".00">
          <Input size="s" />
        </InputAdornment>
      </section>

      <section>
        <InputAdornment after=".com">{domainSelect}</InputAdornment>
      </section>

      <section>
        <InputAdornment after="Mbps" appearance="pure">
          <InputNumber />
        </InputAdornment>
      </section>
    </>
  );
}
```
