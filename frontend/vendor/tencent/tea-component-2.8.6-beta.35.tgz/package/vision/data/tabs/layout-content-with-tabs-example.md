# Tabs - TabsCeiling

## 组件
Tabs

## 示例描述
TabsCeiling

## 视觉特征
### 整体
该组件采用顶部标签页布局，包含标题栏和标签导航区。标签页固定在顶部，文字为深灰色，当前选中项有蓝色下划线。整体风格简洁，以浅灰和白色为主色调，突出内容区域。

### Text: theme="label"
标签页文字为深灰色，字体大小适中，无特殊装饰，显示如“基本信息”等标签内容。

### ExternalLink: weak=true
右上角的“内容帮助”链接，文字为深灰色，无下划线，视觉上较弱，表示次要功能。

### Tabs: animated=false ceiling=true
顶部固定标签栏，标签项水平排列，当前选中项有蓝色下划线，未选中项为深灰色文字，无动画效果。

## 实现代码
```jsx
import React from "react";
import {
  Layout,
  Card,
  Text,
  ExternalLink,
  Tabs,
  TabPanel,
} from "@tencent/tea-component";

const { Body, Content } = Layout;

export default function LayoutContentWithTabsExample() {
  const tabs = [
    { id: "basic", label: "基本信息" },
    { id: "network", label: "弹性网卡" },
    { id: "monitor", label: "监控信息" },
    { id: "sg", label: "安全组", disabled: true },
    { id: "oplog", label: "操作日志" },
  ];

  return (
    <Layout className="demo-layout">
      <Body>
        <Content>
          <Content.Header
            showBackButton
            onBackButtonClick={console.log}
            title="内容标题"
            subtitle={
              <>
                说明文字 <Text theme="label">带颜色说明文字</Text>
              </>
            }
            operation={<ExternalLink weak>内容帮助</ExternalLink>}
          />
          <Content.Body>
            <Tabs ceiling animated={false} tabs={tabs}>
              <TabPanel id="basic">
                <Card>
                  <Card.Body>基本信息</Card.Body>
                </Card>
              </TabPanel>
              <TabPanel id="network">
                <Card>
                  <Card.Body>弹性网卡</Card.Body>
                </Card>
              </TabPanel>
              <TabPanel id="monitor">
                <Card>
                  <Card.Body>监控信息</Card.Body>
                </Card>
              </TabPanel>
              <TabPanel id="oplog">
                <Card>
                  <Card.Body>操作日志</Card.Body>
                </Card>
              </TabPanel>
            </Tabs>
          </Content.Body>
        </Content>
      </Body>
    </Layout>
  );
}
```
