# Rate - 选择半星

## 组件
Rate

## 示例描述
选择半星

## 视觉特征
### 整体
整体布局为水平排列的五颗星图标，前两颗为实心橙色，后三颗为空心灰色，呈现半星评分效果，设计风格简洁现代。

### Rate: allowHalf=true
组件包含五颗星图标，前两颗为实心橙色，第三颗为半实心半空心橙色，后两颗为空心灰色，图标尺寸统一，无文字内容。

## 实现代码
```jsx
import React from "react";
import { Rate } from "@tencent/tea-component";

export default function RateHalfExample() {
  return (
    <Rate allowHalf defaultValue={3.5} onChange={value => console.log(value)} />
  );
}
```
