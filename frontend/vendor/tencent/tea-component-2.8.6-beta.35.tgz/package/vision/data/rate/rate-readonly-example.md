# Rate - 只读

## 组件
Rate

## 示例描述
只读

## 视觉特征
### 整体
整体布局为水平排列的五颗星图标，采用简洁的线性设计风格，背景为纯白色，图标为实心橙色，无额外文字或装饰元素。

### Rate: readonly=true
显示五颗星图标，前四颗为实心橙色，第五颗为空心灰色，图标尺寸统一，无文字内容，背景为白色，无边框。

## 实现代码
```jsx
import React from "react";
import { Rate } from "@tencent/tea-component";

export default function RateReadonlyExample() {
  return <Rate readonly defaultValue={3} />;
}
```
