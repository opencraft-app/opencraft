# Rate - 基本用法

## 组件
Rate

## 示例描述
基本用法

## 视觉特征
### 整体
整体布局为水平排列的五个星形图标，前三个为实心橙色，后两个为空心灰色，背景为纯白色，设计风格简洁直观。

## 实现代码
```jsx
import React from "react";
import { Rate } from "@tencent/tea-component";

export default function RateExample() {
  return <Rate defaultValue={3} onChange={value => console.log(value)} />;
}
```
