# Rate - 主题配色

## 组件
Rate

## 示例描述
主题配色

## 视觉特征
### 整体
整体布局为水平排列的五颗星图标，采用简洁现代风格，背景为纯白色，图标颜色为蓝色，无额外装饰元素。

### Rate: allowHalf=true theme="primary"
背景为白色，边框为无，文字内容为空，文字颜色为黑色，图标为实心蓝色五角星，尺寸中等，未显示半星状态。

## 实现代码
```jsx
import React from "react";
import { Rate } from "@tencent/tea-component";

export default function RateThemeExample() {
  return <Rate allowHalf theme="primary" defaultValue={3.5} />;
}
```
