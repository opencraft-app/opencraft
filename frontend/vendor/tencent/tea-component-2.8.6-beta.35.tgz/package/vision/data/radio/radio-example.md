# Radio - 单选组

## 组件
Radio

## 示例描述
单选组

## 视觉特征
### 整体
这是一个垂直排列的单选组，采用简洁的线性布局，选项以圆形未选中状态呈现，文字为深色，整体风格清晰、功能导向。

### Radio.Group: layout="column"
单选组以垂直列形式排列，选项间有明显间距，布局规整，适用于多选项场景。

### Radio: disabled=true
单选按钮处于禁用状态，圆形边框和内部圆点呈灰色，文字颜色为浅灰色，不可交互。

## 实现代码
```jsx
import React, { useState } from "react";
import { Radio } from "@tencent/tea-component";

export default function RadioExample() {
  const [gender, setGender] = useState(null);
  const [paymode, setPaymode] = useState(null);

  return (
    <>
      <section>
        <Radio.Group value={gender} onChange={value => setGender(value)}>
          <Radio name="male">男性</Radio>
          <Radio name="female">女性</Radio>
        </Radio.Group>
      </section>

      <hr />
      <section>如果选项超过三个，应该使用垂直分布来提高可读性：</section>
      <section>
        <Radio.Group
          value={paymode}
          onChange={value => setPaymode(value)}
          layout="column"
        >
          <Radio name="prepaid">预付费</Radio>
          <Radio name="billing">后付费</Radio>
          <Radio name="subscription">订阅模式</Radio>
          <Radio name="friend" disabled>
            朋友代付
          </Radio>
        </Radio.Group>
      </section>
    </>
  );
}
```
