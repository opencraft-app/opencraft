# Radio - 受控 Radio

## 组件
Radio

## 示例描述
受控 Radio

## 视觉特征
### 整体
整体布局为水平排列的单选按钮组，采用简洁的线性设计风格，按钮间有清晰间距，文字内容明确。

### Radio: display="block"
背景为白色，边框为浅灰色，文字内容为'1个月'，文字颜色为深灰色，图标为未选中状态的空心圆圈，尺寸较小。

### Radio: disabled=true display="block"
背景为浅灰色，边框为浅灰色，文字内容为'2年'，文字颜色为灰色，图标为未选中状态的空心圆圈，尺寸较小。

## 实现代码
```jsx
import React from "react";
import { Radio } from "@tencent/tea-component";

export default function RadioControlledExample() {
  return (
    <>
      <Radio display="block" value={false}>
        未选中
      </Radio>
      <Radio display="block" value>
        已选中
      </Radio>
      <Radio display="block" value={false} disabled>
        禁用未选中
      </Radio>
      <Radio display="block" value disabled>
        禁用已选中
      </Radio>
    </>
  );
}
```
