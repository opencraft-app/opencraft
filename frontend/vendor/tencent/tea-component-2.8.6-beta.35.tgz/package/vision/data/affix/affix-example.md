# Affix - AffixExample

## 组件
Affix

## 示例描述
AffixExample

## 视觉特征
### 整体
页面采用简洁的两栏布局，左侧为操作按钮区，右侧为内容展示区。整体风格现代，以白色为主背景，搭配灰色和蓝色作为强调色。核心交互为按钮触发的固定定位功能。

### Affix: offsetTop=20
一个固定在顶部的白色按钮，文字为“钉在顶部”，按钮边框为灰色，文字颜色为黑色。

### Affix: offsetBottom=0
一个固定在底部的蓝色按钮，文字为“钉在底部”，按钮背景为蓝色，文字颜色为白色。

### Button: type="primary"
一个蓝色的主按钮，文字为“钉在底部”，按钮背景为蓝色，文字颜色为白色。

## 实现代码
```jsx
import React, { useEffect, useRef } from "react";
import { Layout, Card, Affix, Button } from "@tencent/tea-component";

const { Body, Content } = Layout;

function LayoutContentExample() {
  // 处理外层滚动
  const topAffixRef = useRef(null);
  const bottomAffixRef = useRef(null);
  useEffect(() => {
    const handleScroll = () => {
      topAffixRef.current.update();
      bottomAffixRef.current.update();
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <Layout>
      <Body>
        <Content className="affix-target">
          <Content.Header title="内容标题" />
          <Content.Body>
            {/* 内容区域一般使用 Card 组件显示内容 */}
            <Card style={{ height: 1200 }}>
              <Card.Body>
                <Affix
                  ref={topAffixRef}
                  offsetTop={20}
                  target={() => document.querySelector(".affix-target")}
                >
                  <Button>钉在顶部</Button>
                </Affix>
              </Card.Body>
            </Card>
            <Affix
              ref={bottomAffixRef}
              offsetBottom={0}
              target={() => document.querySelector(".affix-target")}
            >
              <Card>
                <Card.Body>
                  <Button type="primary">钉在底部</Button>
                </Card.Body>
              </Card>
            </Affix>
          </Content.Body>
          <Content.Footer>
            <div className="demo-layout-footer">
              (可选项)自定义页脚
              <br />
              京公网安备 11010802017518 粤B2-20090059-1
            </div>
          </Content.Footer>
        </Content>
      </Body>
    </Layout>
  );
}

export default function Demo() {
  return (
    <section
      style={{
        height: 360,
        // border: "1px solid #ddd",
      }}
    >
      <LayoutContentExample />
    </section>
  );
}
```
