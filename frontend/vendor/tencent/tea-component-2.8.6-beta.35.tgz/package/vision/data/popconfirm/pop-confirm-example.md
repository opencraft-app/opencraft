# Popconfirm - PopConfirmExample

## 组件
Popconfirm

## 示例描述
PopConfirmExample

## 视觉特征
### 整体
整体布局为水平排列，包含一个文本标签和两个按钮。设计风格简洁，采用中性色调，按钮为无边框链接样式。

### PopConfirm: message="解除后，配置将不再生效，也不做关联。" placement="top-start" title="确定要解除关联？"
一个 PopConfirm 组件，其触发按钮为文本“解除关联”，按钮为无边框链接样式，文字颜色为深灰色。

### Button: type="link"
一个无边框的链接按钮，文字为“解除关联”，颜色为深灰色。

### Button: type="text"
一个无边框的文本按钮，文字为“解除关联”，颜色为深灰色。

### 交互后视觉特征
交互后，弹出一个白色背景的 PopConfirm 气泡框，内含一个蓝色信息图标和提示文字“腾讯云 Tea x TDesign 融合版正式发布，助力业务上云！”，右上角有一个深灰色的关闭图标。

## 实现代码
```jsx
import React, { useState } from "react";
import { PopConfirm, Button } from "@tencent/tea-component";

export default function PopConfirmExample() {
  return (
    <PopConfirm
      title="确定要解除关联？"
      message="解除后，配置将不再生效，也不做关联。"
      footer={close => (
        <>
          <Button
            type="link"
            onClick={() => {
              close();
              console.log("已解除");
            }}
          >
            解除
          </Button>
          <Button
            type="text"
            onClick={() => {
              close();
              console.log("已取消");
            }}
          >
            取消
          </Button>
        </>
      )}
      placement="top-start"
    >
      <Button type="text">解除关联</Button>
    </PopConfirm>
  );
}
```
