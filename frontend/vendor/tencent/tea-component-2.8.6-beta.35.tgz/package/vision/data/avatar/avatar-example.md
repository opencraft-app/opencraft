# Avatar - AvatarExample

## 组件
Avatar

## 示例描述
AvatarExample

## 视觉特征
### 整体
该组件采用水平线性布局，展示多个圆形头像。主要区域为头像集合，核心交互为头像的视觉状态展示。整体配色方案为多色渐变，包含多种纯色背景，文字为白色，强调对比度和辨识度。

### Avatar: text="T"
圆形头像，背景为蓝色，文字为白色，无边框，标准尺寸。

### Avatar: color="#000000" text="T"
圆形头像，背景为黑色，文字为白色，无边框，标准尺寸。

### Avatar: badge=true color="100013414624" text="T"
圆形头像，背景为紫色，文字为白色，右上角有小徽章，标准尺寸。

### Avatar: color="100033414613" text="T"
圆形头像，背景为红色，文字为白色，无边框，标准尺寸。

## 实现代码
```jsx
import React from "react";
import { Avatar } from "@tencent/tea-component";

export default function AvatarExample() {
  return (
    <>
      <Avatar color={Avatar.Color.Blue} text="T" />
      <Avatar color={Avatar.Color.SkyBlue} text="T" />
      <Avatar color={Avatar.Color.Turquoise} text="T" />
      <Avatar color={Avatar.Color.Green} text="T" />
      <Avatar color={Avatar.Color.Purple} text="T" />
      <Avatar color={Avatar.Color.Pink} text="T" />
      <Avatar color={Avatar.Color.Orange} text="T" />
      <Avatar color={Avatar.Color.Red} text="T" />
      <Avatar color={Avatar.Color.DarkRed} text="T" />
      <Avatar color={Avatar.Color.DarkPurple} text="T" />
      <Avatar color={Avatar.Color.LakeBlue} text="T" />
      <Avatar color={Avatar.Color.LightLakeBlue} text="T" />
      <Avatar color={Avatar.Color.LightSkyBlue} text="T" />
      <Avatar color={Avatar.Color.LightGreen} text="T" />
      <Avatar color="#000000" text="T" />
      <Avatar color="100013414624" text="T" badge />
      <Avatar color="100033414613" text="T" />
    </>
  );
}
```
