# Popover - PopoverMenuExample

## 组件
Popover

## 示例描述
PopoverMenuExample

## 视觉特征
### 整体
这是一个基于右键菜单的弹出式菜单组件，整体采用简洁的白色背景和深灰色文字。主要区域划分为标题栏和选项列表，核心交互元素为右键触发的弹出菜单，整体配色方案为中性色调，突出内容可读性。

### Popover: placement="bottom-start" trigger="contextMenu"
一个从触发元素左下方弹出的矩形菜单，背景为白色，边框为浅灰色，具有轻微的阴影效果。

### List: type="option"
一个垂直排列的选项列表，每个选项项为矩形，背景为白色，文字为深灰色，无边框。

### 交互后视觉特征
交互后，弹出菜单中展示了一个标题和一个选项。标题文字为“腾讯云 Tea x TDesign 融合版正式发布，助力业务上云！”，文字为深灰色。选项文字为“右键菜单”，文字为深灰色。

## 实现代码
```jsx
import React, { useState } from "react";
import { List, Popover, DropdownBox } from "@tencent/tea-component";

export default function PopoverExample() {
  const [visible, setVisible] = useState(false);
  return (
    <Popover
      visible={visible}
      onVisibleChange={visible => setVisible(visible)}
      placement="bottom-start"
      trigger="contextMenu"
      overlay={
        <DropdownBox>
          <List type="option">
            <List.Item
              onClick={() => {
                console.log("点击菜单项");
                setVisible(false);
              }}
            >
              菜单项
            </List.Item>
          </List>
        </DropdownBox>
      }
    >
      右键菜单
    </Popover>
  );
}
```
