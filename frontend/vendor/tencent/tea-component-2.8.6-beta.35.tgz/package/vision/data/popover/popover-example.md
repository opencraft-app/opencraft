# Popover - PopoverExample

## 组件
Popover

## 示例描述
PopoverExample

## 视觉特征
### 整体
整体采用简洁的白色背景和灰色边框设计，文字内容清晰，图标为蓝色圆形内含白色信息符号，布局紧凑。

### Popover: placement="top-start"
背景为白色，边框为浅灰色，文字内容为“腾讯云 Tea x TDesign 融合版正式发布，助力业务上云！”，文字颜色为深灰色，左侧有一个蓝色圆形图标，内含白色信息符号“i”，整体尺寸较小。

### 交互后视觉特征
交互后展示内容为“腾讯云 Tea x TDesign 融合版正式发布，助力业务上云！”，文字颜色为深灰色，左侧有蓝色圆形图标，内含白色信息符号“i”，背景为白色，边框为浅灰色。

## 实现代码
```jsx
import React from "react";
import { Popover } from "@tencent/tea-component";

export default function PopoverExample() {
  return (
    <Popover
      placement="top-start"
      overlay={
        <div
          style={{
            display: "inline-block",
            background: "red",
            color: "yellow",
            padding: 2,
          }}
        >
          这是浮层内容
        </div>
      }
    >
      鼠标上来
    </Popover>
  );
}
```
