# Inputnumber - 格式化

## 组件
Inputnumber

## 示例描述
格式化

## 视觉特征
### 整体
整体布局为上下两个输入框，均包含减号、数值和加号按钮。设计风格简洁，采用浅色背景和细边框，文字为深灰色，图标为灰色。

### InputNumber: min=0 size="l" step=100
输入框尺寸较大，背景为白色，边框为浅灰色。数值显示为"¥ 0"，文字为深灰色。左侧减号图标和右侧加号图标均为灰色，按钮区域有轻微背景色。

### InputNumber: max=100 min=0 step=1
输入框尺寸较小，背景为白色，边框为浅灰色。数值显示为"0%"，文字为深灰色。左侧减号图标和右侧加号图标均为灰色，按钮区域有轻微背景色。

## 实现代码
```jsx
import React from "react";
import { InputNumber } from "@tencent/tea-component";

export default function InputNumberFormatExample() {
  return (
    <>
      <InputNumber
        onChange={value => {
          console.log(value);
        }}
        min={0}
        step={100}
        size="l"
        formatter={value => `¥ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ",")}
        parser={value => Number(value.replace(/¥\s?|(,*)/g, ""))}
      />
      <hr />
      <InputNumber
        onChange={value => {
          console.log(value);
        }}
        min={0}
        max={100}
        step={1}
        formatter={value => `${value}%`}
        parser={value => Number(value.replace("%", ""))}
      />
    </>
  );
}
```
