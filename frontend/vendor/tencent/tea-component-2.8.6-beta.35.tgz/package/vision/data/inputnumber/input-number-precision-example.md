# Inputnumber - 格式化

## 组件
Inputnumber

## 示例描述
格式化

## 视觉特征
### 整体
两个并列的输入框组件，采用简洁的白色背景和浅灰色边框，包含数值输入和加减按钮，整体风格现代、清晰。

### InputNumber: min=0 size="l" step=0.01
白色背景，浅灰色边框，输入框内显示文字“0.00”，文字颜色为深灰色，左右两侧有减号和加号图标，图标颜色为深灰色，尺寸较大。

### InputNumber: max=100 min=0 precision=2 size="l"
白色背景，浅灰色边框，输入框内显示文字“0.00%”，文字颜色为深灰色，左右两侧有减号和加号图标，图标颜色为深灰色，尺寸较大。

## 实现代码
```jsx
import React from "react";
import { InputNumber } from "@tencent/tea-component";

export default function InputNumberPrecisionExample() {
  return (
    <>
      <InputNumber
        onChange={value => {
          console.log(value);
        }}
        min={0}
        step={0.01}
        size="l"
      />
      <hr />
      <InputNumber
        min={0}
        max={100}
        size="l"
        precision={2}
        onChange={value => {
          console.log(value);
        }}
        formatter={value => `${value}%`}
        parser={value => Number(value.replace("%", ""))}
      />
    </>
  );
}
```
