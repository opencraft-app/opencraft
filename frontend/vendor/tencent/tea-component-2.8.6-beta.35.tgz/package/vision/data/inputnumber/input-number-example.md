# Inputnumber - 数字输入

## 组件
Inputnumber

## 示例描述
数字输入

## 视觉特征
### 整体
整体布局为水平排列的数字输入控件，包含减号、数值输入框、加号和单位标签。设计风格简洁，采用标准输入框样式，边框为浅灰色，背景为白色。

### InputNumber: unit="台"
输入框右侧显示单位“台”，文字颜色为深灰色，字体大小与输入框一致，单位文本与输入框在同一水平线上，无额外图标。

### InputNumber: min=0
输入框左侧显示减号按钮，按钮背景为白色，边框为浅灰色，图标为深灰色减号；输入框内默认值为“0”，文字颜色为深灰色，字体大小适中。

## 实现代码
```jsx
import React, { useState } from "react";
import { InputNumber } from "@tencent/tea-component";

export default function InputNumberExample() {
  const [min, setMin] = useState(0);
  const [max, setMax] = useState(10);
  const [step, setStep] = useState(1);
  const [value, setValue] = useState(0);

  return (
    <>
      <section>
        <InputNumber
          value={value}
          onChange={value => {
            console.log(value);
            setValue(value);
          }}
          min={min}
          max={max}
          step={step}
          unit="台"
        />
      </section>
      <hr />
      <section>
        <p>变动下述属性对上方输入框进行调整：</p>
        <br />
        <label>
          最小值：
          <InputNumber
            value={min}
            max={max}
            onChange={value => setMin(value)}
          />
        </label>
        <label style={{ marginLeft: 10 }}>
          最大值：
          <InputNumber
            value={max}
            min={min}
            onChange={value => setMax(value)}
          />
        </label>
        <label style={{ marginLeft: 10 }}>
          步长：
          <InputNumber
            value={step}
            min={0}
            onChange={value => setStep(value)}
          />
        </label>
      </section>
    </>
  );
}
```
