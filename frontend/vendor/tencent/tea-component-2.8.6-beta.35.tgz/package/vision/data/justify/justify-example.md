# Justify - Justify

## 组件
Justify

## 示例描述
Justify

## 视觉特征
### 整体
整体布局为水平排列的工具栏，左侧为蓝色按钮，中间为搜索框，右侧为三个功能图标按钮，风格简洁现代。

### Button: type="primary"
蓝色背景的矩形按钮，文字为白色，显示“新建”

### Button: icon="setting"
圆形灰色背景按钮，内含灰色齿轮图标

### Button: icon="refresh"
圆形灰色背景按钮，内含灰色刷新箭头图标

### Button: icon="download"
圆形灰色背景按钮，内含灰色下载箭头图标

## 实现代码
```jsx
import React from "react";
import {
  Justify,
  Button,
  SearchBox,
  useClassNames,
} from "@tencent/tea-component";

export default function JustifyExample() {
  const { Margin } = useClassNames();
  return (
    <Justify
      left={
        <>
          <Button type="primary">新建</Button>
          <Button>开机</Button>
        </>
      }
      right={
        <>
          <SearchBox />
          <Button icon="setting" className={Margin.Left["1n"]} />
          <Button icon="refresh" className={Margin.Left["1n"]} />
          <Button icon="download" className={Margin.Left["1n"]} />
        </>
      }
    />
  );
}
```
