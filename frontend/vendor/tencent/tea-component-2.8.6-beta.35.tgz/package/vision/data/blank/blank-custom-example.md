# Blank - BlankCustomExample

## 组件
Blank

## 示例描述
BlankCustomExample

## 视觉特征
### 整体
整体布局为左右分栏，左侧为插画，右侧为信息区。信息区包含标题、成功提示、步骤列表和操作按钮。核心交互为引导用户完成特定任务。整体采用蓝白配色，强调清晰和专业。

### Card: full=true
一个占据大部分宽度的卡片，背景为白色，无边框，内容居中对齐。

### Blank: description="提供什么服务，达到什么目的，文字不超过两行。提供什么服务，达到什么目的，文字不超过两行"
组件内包含两行黑色描述文字，位于插画下方，字体大小适中。

### Button: type="primary"
一个蓝色的实心按钮，文字为“前往访问管理”，按钮尺寸较大，具有圆角。

### Alert: type="success"
一个浅绿色背景的提示条，左侧有一个绿色的对勾图标，文字为“成功信息提示语”，文字颜色为深灰色。

### List: type="bullet"
一个项目符号列表，使用实心圆点作为项目符号，列表项文字为黑色，其中一项包含一个蓝色的“联系我们”链接。

## 实现代码
```jsx
import React from "react";
import {
  Button,
  Blank,
  Card,
  Layout,
  ExternalLink,
  Alert,
  List,
} from "@tencent/tea-component";

const { Body, Content } = Layout;

function BlankCustomExample() {
  return (
    <Layout>
      <Body>
        <Content>
          <Content.Body>
            <Card full>
              <Blank
                theme={{
                  image: {
                    background:
                      "//imgcache.qq.com/open_proj/proj_qcloud_v2/bee-v2/css/img/gif/cloud-dev-bg.png",
                    gif:
                      "//imgcache.qq.com/open_proj/proj_qcloud_v2/bee-v2/css/img/gif/cloud-dev-open.gif",
                  },
                }}
                description="提供什么服务，达到什么目的，文字不超过两行。提供什么服务，达到什么目的，文字不超过两行"
                operation={
                  <>
                    <Button type="primary">前往访问管理</Button>
                    <Button>了解访问管理</Button>
                  </>
                }
                extra={
                  <>
                    <ExternalLink>查看接入流程</ExternalLink>
                    <ExternalLink>查看计价</ExternalLink>
                  </>
                }
              >
                <Alert type="success">成功信息提示语</Alert>
                <Blank.Steps
                  steps={["步骤一内容；", "步骤二内容内容；", "步骤三内容"]}
                />
                <List type="bullet">
                  <List.Item>
                    操作提示一操作提示一操作提示一操作提示一操作提示一
                  </List.Item>
                  <List.Item>
                    操作提示二操作提示二操作提示二操作提示二操作提示二提示二{" "}
                    <ExternalLink>操作提示二</ExternalLink>
                  </List.Item>
                  <List.Item>
                    更多问题，请 <ExternalLink>联系我们</ExternalLink>
                  </List.Item>
                </List>
              </Blank>
            </Card>
          </Content.Body>
        </Content>
      </Body>
    </Layout>
  );
}

export default function Demo() {
  return (
    <section
      style={{
        height: 640,
        // border: "1px solid #ddd",
      }}
    >
      <BlankCustomExample />
    </section>
  );
}
```
