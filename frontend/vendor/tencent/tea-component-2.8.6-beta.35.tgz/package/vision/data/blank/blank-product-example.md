# Blank - BlankProductExample

## 组件
Blank

## 示例描述
BlankProductExample

## 视觉特征
### 整体
整体采用左右分栏布局，左侧为信息区，右侧为插图。设计风格简洁现代，主色调为蓝色系，包含标题、提示信息、操作列表和主要行动按钮。核心交互为引导用户完成操作流程。

### Blank: title="CVM"
组件标题为'CVM'，使用深灰色标准字体，位于页面左上角，作为整个空白示例的主标题。

### Alert: type="info"
一个浅蓝色背景的信息提示框，标题为'信息提示'，文字为深灰色，用于展示操作步骤说明。

### Button: type="primary"
一个蓝色的主操作按钮，文字为'前往选购'，按钮背景为纯蓝色，文字为白色，尺寸较大，位于信息区下方。

### List: type="bullet"
一个项目符号列表，包含三个操作提示项，每项前有蓝色圆形项目符号，文字为深灰色。

### Icon: type="notice-blue"
一个蓝色的圆形图标，内部为白色立方体图案，位于标题上方，作为组件的视觉标识。

## 实现代码
```jsx
import React from "react";
import {
  Button,
  Blank,
  Card,
  Layout,
  ExternalLink,
  Alert,
  List,
  Icon,
} from "@tencent/tea-component";

const { Body, Content } = Layout;

function BlankCustomExample() {
  return (
    <Layout>
      <Body>
        <Content>
          <Content.Body>
            <Blank
              title="CVM"
              image={{
                background:
                  "https://imgcache.qq.com/qcloud/tcloud_dtc/static/tc_console/114b4d79-fdd8-4c8c-8771-418a8fa81bbb.svg",
                logo:
                  "https://imgcache.qq.com/qcloud/tcloud_dtc/static/tc_console_product/3ad6629b-8cf5-42ee-8a7f-4e3802768638.svg",
              }}
              operation={<Button type="primary">前往选购</Button>}
              extra={
                <>
                  <ExternalLink>查看接入流程</ExternalLink>
                  <ExternalLink>查看计价</ExternalLink>
                </>
              }
              bottom={[
                <>
                  <Icon type="notice-blue" />
                  <a>全民上云季，云服务器3折起</a>
                </>,
                <>
                  <Icon type="notice-blue" />
                  <a>AMD 1核 1G 服务器 15元/月，拼团最高获赠40个月时长</a>
                </>,
              ]}
            >
              <Alert type="info">信息提示</Alert>
              <Blank.Steps
                steps={["步骤一内容；", "步骤二内容内容；", "步骤三内容"]}
              />
              <List type="bullet">
                <List.Item>
                  操作提示一操作提示一操作提示一操作提示一操作提示一
                </List.Item>
                <List.Item>
                  操作提示二操作提示二操作提示二操作提示二操作提示二提示二{" "}
                  <ExternalLink>操作提示二</ExternalLink>
                </List.Item>
                <List.Item>
                  更多问题，请 <ExternalLink>联系我们</ExternalLink>
                </List.Item>
              </List>
            </Blank>
          </Content.Body>
        </Content>
      </Body>
    </Layout>
  );
}

export default function Demo() {
  return (
    <section
      style={{
        height: 700,
        // border: "1px solid #ddd",
      }}
    >
      <BlankCustomExample />
    </section>
  );
}
```
