# Blank - BlankExample

## 组件
Blank

## 示例描述
BlankExample

## 视觉特征
### 整体
页面采用左右分栏布局，左侧为信息与交互区，右侧为插画区。整体风格简洁现代，以浅灰和白色为主色调，点缀蓝色强调元素。核心交互包括单选按钮组、描述文本、操作按钮和列表。

### Radio.Group: layout="inline"
水平排列的单选按钮，包含四个选项，当前选中项为蓝色实心圆点。

### Blank: description="提供什么服务，达到什么目的，文字不超过两行。提供什么服务，达到什么目的，文字不超过两行"
居中显示的描述文本，黑色常规字体，内容为两行服务说明。

### Button: type="primary"
蓝色背景的主按钮，文字为白色，包含“前往访问管理”和“了解访问管理”两个按钮。

### List: type="bullet"
项目符号列表，包含两个操作提示项，文字为黑色，项目符号为蓝色。

## 实现代码
```jsx
import React, { useState } from "react";
import {
  Button,
  Blank,
  Card,
  Layout,
  ExternalLink,
  Radio,
  List,
} from "@tencent/tea-component";

const { Body, Content } = Layout;

function BlankExample() {
  /**
   * @type [any, any]
   */
  const [theme, setTheme] = useState("permission");

  return (
    <Layout>
      <Body>
        <Content>
          <Content.Header title="场景切换">
            <Radio.Group
              value={theme}
              onChange={value => setTheme(value)}
              layout="inline"
            >
              <Radio name="error">报错</Radio>
              <Radio name="open">开通</Radio>
              <Radio name="arrears">欠费</Radio>
              <Radio name="permission">权限</Radio>
            </Radio.Group>
          </Content.Header>
          <Content.Body>
            <Blank
              theme={theme}
              description="提供什么服务，达到什么目的，文字不超过两行。提供什么服务，达到什么目的，文字不超过两行"
              operation={
                <>
                  <Button type="primary">前往访问管理</Button>
                  <Button>了解访问管理</Button>
                </>
              }
              extra={
                <>
                  <ExternalLink>查看接入流程</ExternalLink>
                  <ExternalLink>查看计价</ExternalLink>
                </>
              }
            >
              <List type="bullet">
                <List.Item>
                  操作提示一操作提示一操作提示一操作提示一操作提示一
                </List.Item>
                <List.Item>
                  操作提示二操作提示二操作提示二操作提示二操作提示二提示二{" "}
                  <ExternalLink>操作提示二</ExternalLink>
                </List.Item>
                <List.Item>
                  更多问题，请 <ExternalLink>联系我们</ExternalLink>
                </List.Item>
              </List>
            </Blank>
          </Content.Body>
        </Content>
      </Body>
    </Layout>
  );
}

export default function Demo() {
  return (
    <section
      style={{
        height: 540,
        // border: "1px solid #ddd",
      }}
    >
      <BlankExample />
    </section>
  );
}
```
