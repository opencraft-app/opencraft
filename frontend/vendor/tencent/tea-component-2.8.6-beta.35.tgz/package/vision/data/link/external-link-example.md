# Link - ExternalLink

## 组件
Link

## 示例描述
ExternalLink

## 视觉特征
### 整体
该 UI 组件为外部链接，采用简洁设计风格，包含文字和外部链接图标，整体布局水平排列。

### ExternalLink: href="https://cloud.tencent.com"
背景为白色，边框为浅灰色，文字为深灰色，内容为“官网”，右侧有外部链接图标，图标为深灰色，尺寸较小。

### ExternalLink: href="https://console.cloud.tencent.com" weak=true
背景为白色，边框为浅灰色，文字为深灰色，内容为“控制台”，右侧有外部链接图标，图标为深灰色，尺寸较小。

## 实现代码
```jsx
import React from "react";
import { ExternalLink } from "@tencent/tea-component";

export default function ExternalLinkExample() {
  return (
    <>
      <ExternalLink
        href="https://cloud.tencent.com"
        style={{ marginRight: 10 }}
      >
        官网
      </ExternalLink>
      <ExternalLink href="https://console.cloud.tencent.com" weak>
        控制台
      </ExternalLink>
    </>
  );
}
```
