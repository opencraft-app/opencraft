# Link - Link

## 组件
Link

## 示例描述
Link

## 视觉特征
### 整体
该 UI 组件为按钮，采用简洁现代设计风格，主要通过文字内容和颜色区分功能，布局规整，视觉清晰。

## 实现代码
```jsx
import React from "react";

export default function ExternalLinkExample() {
  return <a href="/component/button">Button 组件</a>;
}
```
