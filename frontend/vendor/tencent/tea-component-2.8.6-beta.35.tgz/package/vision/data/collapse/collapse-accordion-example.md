# Collapse - 手风琴模式

## 组件
Collapse

## 示例描述
手风琴模式

## 视觉特征
### 整体
手风琴模式的折叠面板，垂直排列，每个面板标题前有三角形图标，内容区域背景色较浅，整体风格简洁。

### Collapse: accordion=true
组件以手风琴模式呈现，仅允许一个面板展开，面板标题前有可点击的三角形图标，背景为白色。

### Collapse.Panel: title="高级设置 1"
面板标题为“高级设置 1”，文字为深灰色，左侧有向下的三角形图标，内容区域显示“内容”。

### Collapse.Panel: title="高级设置 2"
面板标题为“高级设置 2”，文字为深灰色，左侧有向下的三角形图标，内容区域显示“内容”。

### Collapse.Panel: title="高级设置 3"
面板标题为“高级设置 3”，文字为深灰色，左侧有向下的三角形图标，内容区域显示“内容”。

### Collapse.Panel: title="高级设置 4"
面板标题为“高级设置 4”，文字为深灰色，左侧有向下的三角形图标，内容区域显示“内容”。

### 交互后视觉特征
交互后展示折叠内容：
- 点击面板标题区域展开/收起内容
- 标题栏通常有展开/收起箭头图标
- 展开时内容区域平滑展开动画
- 支持手风琴模式（同时只展开一个）

## 实现代码
```jsx
import React from "react";
import { Collapse } from "@tencent/tea-component";

export default function CollapseAccordionExample() {
  const content = (
    <div
      style={{
        height: 40,
        padding: 4,
        backgroundColor: "var(--tea-color-bg-secondary-default)",
      }}
    >
      内容
    </div>
  );
  return (
    <Collapse accordion defaultActiveIds={["1"]}>
      <Collapse.Panel id="1" title="高级设置 1">
        {content}
      </Collapse.Panel>
      <Collapse.Panel id="2" title="高级设置 2">
        {content}
      </Collapse.Panel>
      <Collapse.Panel id="3" title="高级设置 3">
        {content}
      </Collapse.Panel>
      <Collapse.Panel id="4" title="高级设置 4">
        {content}
      </Collapse.Panel>
    </Collapse>
  );
}
```
