# Collapse - 多个面板

## 组件
Collapse

## 示例描述
多个面板

## 视觉特征
### 整体
这是一个垂直堆叠的折叠面板列表，采用简洁的线性布局，所有面板标题文字颜色一致，背景为浅灰色，整体风格统一。

### Collapse.Panel: title="高级设置 1"
标题为“高级设置 1”，文字颜色为深灰色，面板处于展开状态，下方显示内容区域。

### Collapse.Panel: title="高级设置 2"
标题为“高级设置 2”，文字颜色为深灰色，面板处于折叠状态，左侧有向下的三角形图标。

### Collapse.Panel: title="高级设置 3"
标题为“高级设置 3”，文字颜色为深灰色，面板处于折叠状态，左侧有向下的三角形图标。

### Collapse.Panel: title="高级设置 4"
标题为“高级设置 4”，文字颜色为深灰色，面板处于折叠状态，左侧有向下的三角形图标。

### 交互后视觉特征
交互后展示折叠内容：
- 点击面板标题区域展开/收起内容
- 标题栏通常有展开/收起箭头图标
- 展开时内容区域平滑展开动画
- 支持手风琴模式（同时只展开一个）

## 实现代码
```jsx
import React from "react";
import { Collapse } from "@tencent/tea-component";

export default function CollapseMultiExample() {
  const content = (
    <div
      style={{
        height: 40,
        padding: 4,
        backgroundColor: "var(--tea-color-bg-secondary-default)",
      }}
    >
      内容
    </div>
  );
  return (
    <Collapse defaultActiveIds={["1", "2"]}>
      <Collapse.Panel id="1" title="高级设置 1">
        {content}
      </Collapse.Panel>
      <Collapse.Panel id="2" title="高级设置 2">
        {content}
      </Collapse.Panel>
      <Collapse.Panel id="3" title="高级设置 3">
        {content}
      </Collapse.Panel>
      <Collapse.Panel id="4" title="高级设置 4">
        {content}
      </Collapse.Panel>
    </Collapse>
  );
}
```
