# Collapse - 基本用法

## 组件
Collapse

## 示例描述
基本用法

## 视觉特征
### 整体
整体采用简洁的白色背景和深色文字，布局清晰，包含一个标题为“高级设置”的折叠面板，风格统一。

### Collapse.Panel: title="高级设置"
面板标题为“高级设置”，文字颜色为深灰色，无特殊图标或边框，处于默认展开状态。

### 交互后视觉特征
交互后展示折叠内容：
- 点击面板标题区域展开/收起内容
- 标题栏通常有展开/收起箭头图标
- 展开时内容区域平滑展开动画
- 支持手风琴模式（同时只展开一个）

## 实现代码
```jsx
import React from "react";
import { Collapse } from "@tencent/tea-component";

export default function CollapseExample() {
  return (
    <Collapse>
      <Collapse.Panel id="1" title="高级设置">
        <div
          style={{
            height: 40,
            padding: 4,
            backgroundColor: "var(--tea-color-bg-secondary-default)",
          }}
        >
          内容
        </div>
      </Collapse.Panel>
    </Collapse>
  );
}
```
