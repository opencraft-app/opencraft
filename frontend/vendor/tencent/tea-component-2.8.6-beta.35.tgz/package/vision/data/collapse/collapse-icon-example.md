# Collapse - 自定义图标

## 组件
Collapse

## 示例描述
自定义图标

## 视觉特征
### 整体
整体采用简洁的列表布局，文字与图标并列，图标位于右侧，风格统一，突出信息层级。

### Collapse: iconPosition="right"
图标位于内容右侧，与文字并列，视觉上与标题对齐，无额外装饰。

### Collapse.Panel: title="高级设置"
标题文字为“高级设置”，颜色为深灰色，字体清晰，无特殊样式或图标。

### 交互后视觉特征
交互后展示折叠内容：
- 点击面板标题区域展开/收起内容
- 标题栏通常有展开/收起箭头图标
- 展开时内容区域平滑展开动画
- 支持手风琴模式（同时只展开一个）

## 实现代码
```jsx
import React from "react";
import { Collapse, Icon } from "@tencent/tea-component";

export default function CollapseExample() {
  return (
    <Collapse
      icon={active => <Icon type={active ? "minus" : "plus"} />}
      iconPosition="right"
    >
      <Collapse.Panel id="1" title="高级设置">
        <div
          style={{
            height: 40,
            padding: 4,
            backgroundColor: "var(--tea-color-bg-secondary-default)",
          }}
        >
          内容
        </div>
      </Collapse.Panel>
    </Collapse>
  );
}
```
