# Grid - SplitLine

## 组件
Grid

## 示例描述
SplitLine

## 视觉特征
### 整体
这是一个基于 Grid 布局的水平分割线示例，采用简洁的线性设计，通过不同列宽的单元格展示布局结构。

### Row: showSplitLine=true
在 Row 组件中启用水平分割线，显示为一条贯穿容器的细线，用于分隔不同行内容。

### Col: span=6
Col 组件以 span=6 的宽度显示，内容为 'col-8'，文字为深灰色，背景为浅灰色，表示固定列宽布局。

## 实现代码
```jsx
import React from "react";
import { Row, Col } from "@tencent/tea-component";

export default function GridSplitLineExample() {
  return (
    <Row showSplitLine>
      <Col span={6}>
        <Box>col-6</Box>
      </Col>
      <Col span={6}>
        <Box>col-6</Box>
      </Col>
      <Col span={6}>
        <Box>col-6</Box>
      </Col>
      <Col span={6}>
        <Box>col-6</Box>
      </Col>
    </Row>
  );
}

function Box({ children }) {
  return <div className="demo-grid-box">{children}</div>;
}
```
