# Grid - Equal

## 组件
Grid

## 示例描述
Equal

## 视觉特征
### 整体
这是一个水平排列的标签组，采用等宽网格布局，背景为浅灰色，文字为深灰色，整体风格简洁统一。

### Tag: size: 'small', color: 'default'
标签文字为黑色，背景为浅灰色，边框为浅灰色，文字内容为'一花'、'二乃'、'三玖'、'四叶'、'五月'。

## 实现代码
```jsx
import React from "react";
import { Row, Col } from "@tencent/tea-component";

export default function GridEqualExample() {
  return (
    <Row>
      <Col>
        <Box>一花</Box>
      </Col>
      <Col>
        <Box>二乃</Box>
      </Col>
      <Col>
        <Box>三玖</Box>
      </Col>
      <Col>
        <Box>四叶</Box>
      </Col>
      <Col>
        <Box>五月</Box>
      </Col>
    </Row>
  );
}

function Box({ children }) {
  return <div className="demo-grid-box">{children}</div>;
}
```
