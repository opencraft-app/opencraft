# Grid - GridResponsive

## 组件
Grid

## 示例描述
GridResponsive

## 视觉特征
### 整体
这是一个基于 Grid 的响应式布局示例，采用两行六列的卡片式设计，整体风格简洁统一，背景为浅灰色，文字居中显示。

### Box: lg=6 md=8 sm=12 xl=4 xs=24 xxl=2
浅灰色矩形卡片，内部居中显示黑色文字“Box”，无边框或图标，所有实例外观一致。

## 实现代码
```jsx
import React from "react";
import { Row, Col } from "@tencent/tea-component";

export default function GridResponsiveExample() {
  return (
    <Row>
      <Col xs={24} sm={12} md={8} lg={6} xl={4} xxl={2}>
        <Box>Box</Box>
      </Col>
      <Col xs={24} sm={12} md={8} lg={6} xl={4} xxl={2}>
        <Box>Box</Box>
      </Col>
      <Col xs={24} sm={12} md={8} lg={6} xl={4} xxl={2}>
        <Box>Box</Box>
      </Col>
      <Col xs={24} sm={12} md={8} lg={6} xl={4} xxl={2}>
        <Box>Box</Box>
      </Col>
      <Col xs={24} sm={12} md={8} lg={6} xl={4} xxl={2}>
        <Box>Box</Box>
      </Col>
      <Col xs={24} sm={12} md={8} lg={6} xl={4} xxl={2}>
        <Box>Box</Box>
      </Col>
      <Col xs={24} sm={12} md={8} lg={6} xl={4} xxl={2}>
        <Box>Box</Box>
      </Col>
      <Col xs={24} sm={12} md={8} lg={6} xl={4} xxl={2}>
        <Box>Box</Box>
      </Col>
      <Col xs={24} sm={12} md={8} lg={6} xl={4} xxl={2}>
        <Box>Box</Box>
      </Col>
      <Col xs={24} sm={12} md={8} lg={6} xl={4} xxl={2}>
        <Box>Box</Box>
      </Col>
      <Col xs={24} sm={12} md={8} lg={6} xl={4} xxl={2}>
        <Box>Box</Box>
      </Col>
      <Col xs={24} sm={12} md={8} lg={6} xl={4} xxl={2}>
        <Box>Box</Box>
      </Col>
    </Row>
  );
}

function Box({ children }) {
  return <div className="demo-grid-box">{children}</div>;
}
```
