# Grid - Gap

## 组件
Grid

## 示例描述
Gap

## 视觉特征
### 整体
整体采用水平布局，左侧为交互控件区，右侧为网格预览区。控件区包含滑块和输入框，预览区展示四列等宽的灰色矩形块。整体风格简洁，以灰白为主色调，突出组件的结构和间距效果。

### Slider: max=50 min=0
水平滑块控件，轨道为浅灰色，滑块为深灰色圆形，位于控件区顶部。

### InputNumber: max=50 min=0
输入框控件，边框为浅灰色，内部文本为深灰色，显示数值，位于滑块下方。

### Col: span=8
四个并列的浅灰色矩形块，每个块内居中显示深灰色文字“col-6”。

## 实现代码
```jsx
import React, { useState } from "react";
import { Row, Col, Slider, InputNumber } from "@tencent/tea-component";

export default function GridGapExample() {
  const [gap, setGap] = useState(20);

  return (
    <>
      <Slider
        min={0}
        max={50}
        value={gap}
        onUpdate={value => setGap(value)}
        after={
          <InputNumber
            min={0}
            max={50}
            value={gap}
            onChange={value => setGap(value)}
          />
        }
        tipFormatter={value => `间距：${value}`}
      />
      <Row gap={gap}>
        <Col span={8}>
          <Box>col-8</Box>
        </Col>
        <Col span={8}>
          <Box>col-8</Box>
        </Col>
        <Col span={8}>
          <Box>col-8</Box>
        </Col>
      </Row>
    </>
  );
}

function Box({ children }) {
  return <div className="demo-grid-box">{children}</div>;
}
```
