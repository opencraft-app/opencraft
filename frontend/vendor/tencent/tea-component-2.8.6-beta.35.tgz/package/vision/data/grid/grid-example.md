# Grid - Grid

## 组件
Grid

## 示例描述
Grid

## 视觉特征
### 整体
采用响应式栅格布局，将页面划分为多行多列区域。核心交互为不同宽度的列块组合，整体风格简洁，以浅灰色背景和深灰色文字为主，突出内容区块的视觉层次。

### Col: span=24
占据整行的宽列块，背景为浅灰色，内部文字为深灰色，内容为'col-24'。

### Col: span=12
中等宽度的列块，背景为浅灰色，内部文字为深灰色，内容为'col-12'。

### Col: span=8
较窄的列块，背景为浅灰色，内部文字为深灰色，内容为'col-8'。

### Col: span=6
最窄的列块，背景为浅灰色，内部文字为深灰色，内容为'col-6'。

### Col: span=16
宽度大于半行的列块，背景为浅灰色，内部文字为深灰色，内容为'col-16'。

## 实现代码
```jsx
import React from "react";
import { Row, Col } from "@tencent/tea-component";

export default function GridExample() {
  return (
    <>
      <section>
        <Row>
          <Col span={24}>
            <Box>col-24</Box>
          </Col>
        </Row>
      </section>
      <section>
        <Row>
          <Col span={12}>
            <Box>col-12</Box>
          </Col>
          <Col span={12}>
            <Box>col-12</Box>
          </Col>
        </Row>
      </section>
      <section>
        <Row>
          <Col span={8}>
            <Box>col-8</Box>
          </Col>
          <Col span={8}>
            <Box>col-8</Box>
          </Col>
          <Col span={8}>
            <Box>col-8</Box>
          </Col>
        </Row>
      </section>
      <section>
        <Row>
          <Col span={6}>
            <Box>col-6</Box>
          </Col>
          <Col span={6}>
            <Box>col-6</Box>
          </Col>
          <Col span={6}>
            <Box>col-6</Box>
          </Col>
          <Col span={6}>
            <Box>col-6</Box>
          </Col>
        </Row>
      </section>
      <section>
        <Row>
          <Col span={8}>
            <Box>col-8</Box>
          </Col>
          <Col span={16}>
            <Box>col-16</Box>
          </Col>
        </Row>
      </section>
      <section>
        <Row>
          <Col span={6}>
            <Box>col-6</Box>
          </Col>
          <Col span={18}>
            <Box>col-18</Box>
          </Col>
        </Row>
      </section>
      <section>
        <Row>
          <Col span={6}>
            <Box>col-6</Box>
          </Col>
          <Col span={12}>
            <Box>col-12</Box>
          </Col>
          <Col span={6}>
            <Box>col-6</Box>
          </Col>
        </Row>
      </section>
    </>
  );
}

function Box({ children }) {
  return <div className="demo-grid-box">{children}</div>;
}
```
