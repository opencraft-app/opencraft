# Grid - Align

## 组件
Grid

## 示例描述
Align

## 视觉特征
### 整体
该组件采用三列布局，展示 Grid 组件的对齐功能。左侧为默认对齐，中间为顶部对齐，右侧为居中对齐。主要交互元素为不同对齐方式的 col-8 区域。整体配色为中性灰白，突出内容区域的对比。

### Col: span=8
一个灰色矩形块，内部有白色文字 'col-8'，文字颜色为白色。

## 实现代码
```jsx
import React, { useState } from "react";
import { Row, Col, RadioGroup, Radio } from "@tencent/tea-component";

export default function GridAlignExample() {
  const [align, setAlign] = useState(null);

  return (
    <>
      <section>
        <RadioGroup value={align} onChange={value => setAlign(value)}>
          <Radio name={null}>默认等高</Radio>
          <Radio name="top">顶部对齐</Radio>
          <Radio name="middle">居中对齐</Radio>
          <Radio name="bottom">底部对齐</Radio>
        </RadioGroup>
      </section>
      <Row verticalAlign={align}>
        <Col span={8}>
          <div style={{ height: "100%", background: "gray" }}>
            <Box>col-8</Box>
            <Box>col-8</Box>
          </div>
        </Col>
        <Col span={8}>
          <div style={{ height: "100%", background: "gray" }}>
            <Box>col-8</Box>
          </div>
        </Col>
        <Col span={8}>
          <div style={{ height: "100%", background: "gray" }}>
            <Box>col-8</Box>
            <Box>col-8</Box>
            <Box>col-8</Box>
          </div>
        </Col>
      </Row>
    </>
  );
}

function Box({ children }) {
  return <div className="demo-grid-box">{children}</div>;
}
```
