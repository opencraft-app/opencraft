# Upload - ImageUploadExample

## 组件
Upload

## 示例描述
ImageUploadExample

## 视觉特征
### 整体
组件采用分层布局，上半部分为上传区域，下半部分为提示信息。核心交互为点击或拖拽上传文件。整体风格简洁，以白色背景为主，文字使用蓝色和灰色，突出可操作区域。

### Form.Control: message="请上传 png 格式文件，大小 1MB 以内"
显示为灰色文本，内容为上传格式和大小限制，位于组件底部。

### Upload: accept="image/png" action="https://run.mocky.io/v3/68ed7204-0487-4135-857d-0e4366b2cfad"
包含蓝色可点击文本“点击上传”和灰色提示“拖拽到此区域”，支持拖拽和点击上传。

### Text: theme="weak"
显示为浅灰色文本，内容为“请上传 zip 格式文件，大小 1MB 以内”，位于组件底部。

### Button: type="link"
蓝色文本“点击上传”，无边框，作为链接样式按钮，用于触发上传操作。

## 实现代码
```jsx
import React, { useState, useRef } from "react";
import { Upload, Text, Form, Modal, Button } from "@tencent/tea-component";

export default function SingleFileUploadExample() {
  const [file, setFile] = useState(null);
  const [image, setImage] = useState(null);
  const [status, setStatus] = useState(null);
  const [percent, setPercent] = useState(null);

  const xhrRef = useRef(null);

  function handleStart(file, { xhr }) {
    setFile(file);
    getBase64(file);
    setStatus("validating");
    xhrRef.current = xhr;
  }

  function handleProgress({ percent }) {
    setPercent(percent);
  }

  function handleSuccess(result) {
    console.log(result);
    setStatus("success");
  }

  function handleError() {
    setStatus("error");
    Modal.alert({
      type: "error",
      message: "错误",
      description: "请求服务器失败",
    });
  }

  function beforeUpload(file, fileList, isAccepted) {
    if (!isAccepted) {
      setStatus("error");
    }
    return isAccepted;
  }

  function handleAbort() {
    if (xhrRef.current) {
      xhrRef.current.abort();
    }
    setFile(null);
    setStatus(null);
    setPercent(null);
  }

  function getBase64(file) {
    const reader = new FileReader();
    reader.onloadend = () => {
      setImage(reader.result);
    };
    reader.readAsDataURL(file);
  }

  return (
    <Form.Control status={status} message="请上传 png 格式文件，大小 1MB 以内">
      <Upload
        action="https://run.mocky.io/v3/68ed7204-0487-4135-857d-0e4366b2cfad"
        accept="image/png"
        maxSize={1024 * 1024}
        onStart={handleStart}
        onProgress={handleProgress}
        onSuccess={handleSuccess}
        onError={handleError}
        beforeUpload={beforeUpload}
      >
        {({ open }) => (
          <Upload.Image
            filename={file ? file.name : <Text theme="weak">还未选择图片</Text>}
            image={
              file
                ? image
                : "//imgcache.qq.com/open_proj/proj_qcloud_v2/tea-style/dist/assets/image/upload-thumb.png"
            }
            percent={percent}
            description={
              file && (
                <>
                  <p>文件大小：{Math.floor(file.size / 1024)}K</p>
                  <p>上传日期：-</p>
                </>
              )
            }
            button={
              status === "validating" ? (
                <Button onClick={handleAbort}>取消上传</Button>
              ) : (
                <>
                  <Button onClick={open}>
                    {status ? "重新上传" : "选择图片"}
                  </Button>
                  {file && (
                    <Button
                      type="link"
                      style={{ marginLeft: 8 }}
                      onClick={handleAbort}
                    >
                      删除
                    </Button>
                  )}
                </>
              )
            }
          />
        )}
      </Upload>
    </Form.Control>
  );
}
```
