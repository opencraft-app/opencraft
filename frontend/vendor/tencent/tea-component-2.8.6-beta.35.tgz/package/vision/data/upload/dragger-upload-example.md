# Upload - DraggerUploadExample

## 组件
Upload

## 示例描述
DraggerUploadExample

## 视觉特征
### 整体
这是一个文件上传区域，采用浅灰色背景和白色卡片式布局。核心交互为拖拽上传和点击选择文件。整体配色以中性灰为主，文字为弱色，风格简洁现代。

### Form.Control: message="请上传 zip 格式文件，大小 1MB 以内"
显示在上传区域下方的提示文本，内容为“请上传 zip 格式文件，大小 1MB 以内”，文字颜色为弱色。

### Upload: accept="application/zip,application/x-zip,application/x-zip-compressed" action="https://run.mocky.io/v3/68ed7204-0487-4135-857d-0e4366b2cfad"
核心上传组件，支持拖拽和点击，接受 zip 格式文件，视觉上为一个带有图片占位符的矩形区域。

### Button: type="link"
一个链接样式的按钮，文字为“选择图片”，无边框，颜色与弱文本一致，用于触发文件选择对话框。

### Text: theme="weak"
显示在上传区域上方的文本“还未选择图片”，文字颜色为弱色，字体较小，用于状态提示。

## 实现代码
```jsx
import React, { useState, useRef } from "react";
import { Upload, Text, Form, Modal, Button } from "@tencent/tea-component";

export default function SingleFileUploadExample() {
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState(null);
  const [percent, setPercent] = useState(null);

  const xhrRef = useRef(null);

  function handleStart(file, { xhr }) {
    setFile(file);
    setStatus("validating");
    xhrRef.current = xhr;
  }

  function handleProgress({ percent }) {
    setPercent(percent);
  }

  function handleSuccess(result) {
    console.log(result);
    setStatus("success");
  }

  function handleError() {
    setStatus("error");
    Modal.alert({
      type: "error",
      message: "错误",
      description: "请求服务器失败",
    });
  }

  function beforeUpload(file, fileList, isAccepted) {
    if (!isAccepted) {
      setStatus("error");
    }
    return isAccepted;
  }

  function handleAbort() {
    if (xhrRef.current) {
      xhrRef.current.abort();
    }
    setFile(null);
    setStatus(null);
    setPercent(null);
  }
  return (
    <Form.Control status={status} message="请上传 zip 格式文件，大小 1MB 以内">
      <Upload
        action="https://run.mocky.io/v3/68ed7204-0487-4135-857d-0e4366b2cfad"
        accept="application/zip,application/x-zip,application/x-zip-compressed"
        maxSize={1024 * 1024}
        onStart={handleStart}
        onProgress={handleProgress}
        onSuccess={handleSuccess}
        onError={handleError}
        beforeUpload={beforeUpload}
      >
        {({ open, isDragging }) => (
          <Upload.Dragger
            filename={file && file.name}
            percent={percent}
            description={
              file && (
                <>
                  <p>文件大小：{Math.floor(file.size / 1024)}K</p>
                  <p>上传日期：-</p>
                </>
              )
            }
            button={
              status === "validating" ? (
                <Button type="link" onClick={handleAbort}>
                  取消上传
                </Button>
              ) : (
                <>
                  <Button type="link" onClick={open}>
                    重新上传
                  </Button>
                  <Button
                    type="link"
                    style={{ marginLeft: 8 }}
                    onClick={() => setFile(null)}
                  >
                    删除
                  </Button>
                </>
              )
            }
          >
            {isDragging ? (
              "释放鼠标"
            ) : (
              <>
                <a onClick={open}>点击上传</a>
                <Text theme="weak">/拖拽到此区域</Text>
              </>
            )}
          </Upload.Dragger>
        )}
      </Upload>
    </Form.Control>
  );
}
```
