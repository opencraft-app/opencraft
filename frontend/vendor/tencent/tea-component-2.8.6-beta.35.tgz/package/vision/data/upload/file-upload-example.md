# Upload - FileUploadExample

## 组件
Upload

## 示例描述
FileUploadExample

## 视觉特征
### 整体
该组件采用左右布局，左侧为文本提示区域，右侧为文件选择按钮。整体风格简洁，以灰色和白色为主色调，按钮为链接样式，突出核心的文件上传交互。

### Form.Control: message="请上传 png 格式文件，大小 100KB 以内"
一个文本输入框，显示灰色提示文字“请上传 png 格式文件，大小 100KB 以内”，文字颜色为灰色。

### Upload: accept="image/png" action="https://run.mocky.io/v3/68ed7204-0487-4135-857d-0e4366b2cfad"
一个文件上传控件，内部包含一个按钮，按钮上显示文字“选择文件”。

### Button: type="link"
一个链接样式的按钮，文字为“选择文件”，颜色为默认文本色，无背景色和边框。

## 实现代码
```jsx
import React, { useState, useRef } from "react";
import { Upload, Button, Form, Modal } from "@tencent/tea-component";

export default function UploadExample() {
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState(null);
  const [percent, setPercent] = useState(null);

  const xhrRef = useRef(null);

  function handleStart(file, { xhr }) {
    setFile(file);
    setStatus("validating");
    xhrRef.current = xhr;
  }

  function handleProgress({ percent }) {
    setPercent(percent);
  }

  function handleSuccess(result) {
    console.log(result);
    setStatus("success");
  }

  function handleError() {
    setStatus("error");
    handleAbort();
    Modal.alert({
      type: "error",
      message: "错误",
      description: "请求服务器失败",
    });
  }

  function beforeUpload(file, fileList, isAccepted) {
    if (!isAccepted) {
      setStatus("error");
    }
    return isAccepted;
  }

  function handleAbort() {
    if (xhrRef.current) {
      xhrRef.current.abort();
    }
    setFile(null);
    setStatus(null);
    setPercent(null);
  }

  return (
    <Form.Control
      status={status}
      message="请上传 png 格式文件，大小 100KB 以内"
    >
      <Upload
        action="https://run.mocky.io/v3/68ed7204-0487-4135-857d-0e4366b2cfad"
        accept="image/png"
        maxSize={100 * 1024}
        onStart={handleStart}
        onProgress={handleProgress}
        onSuccess={handleSuccess}
        onError={handleError}
        beforeUpload={beforeUpload}
      >
        {({ open }) => (
          <Upload.File
            filename={file && file.name}
            percent={percent}
            button={
              status === "validating" ? (
                <Button onClick={handleAbort}>取消上传</Button>
              ) : (
                <>
                  <Button onClick={open}>
                    {status ? "重新上传" : "选择文件"}
                  </Button>
                  {status && (
                    <Button
                      type="link"
                      style={{ marginLeft: 8 }}
                      onClick={handleAbort}
                    >
                      删除
                    </Button>
                  )}
                </>
              )
            }
          />
        )}
      </Upload>
    </Form.Control>
  );
}
```
