# Alert - AlertStyleExample

## 组件
Alert

## 示例描述
AlertStyleExample

## 视觉特征
### 整体
该组件采用水平布局，包含图标、标题和说明文字区域。整体风格简洁，使用不同背景色区分信息类型，核心交互为文本链接。配色方案根据类型变化，包含浅蓝、浅橙、浅灰等。

### Alert: type="warning"
背景为浅橙色，图标为橙色感叹号，文字为深灰色。

### Alert: type="neutral"
背景为浅灰色，图标为灰色信息符号，文字为深灰色。

### Alert: type="white"
背景为白色，图标为蓝色信息符号，文字为深灰色。

### Bubble: content="说明文字"
显示为浅灰色背景的文本气泡，文字为深灰色。

### Text: underline=true
文字为深灰色，带有下划线，表示可点击链接。

## 实现代码
```jsx
import React from "react";
import { Alert, Text, Bubble } from "@tencent/tea-component";

export default function AlertStyleExample() {
  return (
    <>
      <Alert>
        常规提示。
        <Alert.Strong>加强文字描述</Alert.Strong>
      </Alert>
      <Alert type="warning" style={{ marginTop: 8 }}>
        告警提示，
        <Alert.Strong>加强文字描述</Alert.Strong>
      </Alert>

      <Alert type="neutral" style={{ marginTop: 8 }}>
        弱提示。
        <Bubble content="说明文字">
          <Text underline>带说明文案</Text>
        </Bubble>
      </Alert>

      <div
        style={{
          backgroundColor: "var(--tea-color-bg-page-default)",
          padding: "8px",
          marginTop: 8,
        }}
      >
        <Alert type="white" style={{ marginBottom: "0" }}>
          弱提示。
          <a href="https://cloud.tencent.com" target="_blank" rel="noreferrer">
            这是一个链接
          </a>
        </Alert>
      </div>
    </>
  );
}
```
