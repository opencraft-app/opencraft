# Alert - AlertCloseExample

## 组件
Alert

## 示例描述
AlertCloseExample

## 视觉特征
### 整体
浅蓝色背景的警告提示框，左侧有信息图标，右侧有关闭按钮，整体布局简洁，采用中性色调。

### Alert: defaultVisible=true
显示状态的警告提示框，内容为“非受控关闭”，背景为浅蓝色，文字为深色。

### Alert: type="warning"
警告类型的提示框，内容为“受控关闭”，背景为浅橙色，文字为深色。

### Button: type="link"
链接样式的关闭按钮，位于提示框右侧，文字为蓝色，无边框。

## 实现代码
```jsx
import React, { useState } from "react";
import { Alert, Button } from "@tencent/tea-component";

export default function AlertCloseExample() {
  const [alertVisible, setAlertVisible] = useState(true);

  return (
    <>
      <Alert defaultVisible style={{ marginTop: 10 }}>
        非受控关闭
      </Alert>
      <Alert
        type="warning"
        visible={alertVisible}
        onClose={() => setAlertVisible(false)}
        extra={
          <Button type="link" onClick={() => setAlertVisible(false)}>
            关闭
          </Button>
        }
      >
        受控关闭
      </Alert>
    </>
  );
}
```
