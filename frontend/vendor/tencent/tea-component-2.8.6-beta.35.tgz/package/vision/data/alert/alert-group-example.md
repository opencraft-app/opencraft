# Alert - AlertTagExample

## 组件
Alert

## 示例描述
AlertTagExample

## 视觉特征
### 整体
该组件采用分组布局，包含多个信息提示条。主要区域为提示内容区和关闭按钮。核心交互为可关闭的提示信息，整体配色以中性色为主，通过标签颜色区分信息类型。

### Alert.Group: defaultVisible=true type="neutral"
中性类型提示组，包含两条信息，文字为深灰色，背景为浅灰色，无特殊图标。

### Alert.Group: defaultVisible=true prefixSameWidth=true type="neutral"
中性类型提示组，左侧标签与内容对齐，标签背景为浅橙色，文字为深灰色。

### Tag: theme="warning"
警告主题标签，背景为橙色，文字为深灰色，用于标识信息类别。

### Tag: theme="primary"
主要主题标签，背景为蓝色，文字为深灰色，用于标识信息类别。

## 实现代码
```jsx
import React from "react";
import { Alert, Tag } from "@tencent/tea-component";

export default function AlertGroupExample() {
  return (
    <>
      <Alert.Group defaultVisible type="neutral">
        <Alert prefix={<Tag theme="warning">计费</Tag>}>
          弱提示
          <Alert.Strong>
            这里是加强的文字描述，This is strong text.
          </Alert.Strong>
        </Alert>
        <Alert prefix={<Tag theme="primary">提示</Tag>}>
          弱提示，
          <Alert.Strong>
            这里是加强的文字描述，This is strong text.
          </Alert.Strong>
        </Alert>
      </Alert.Group>
      <hr />
      <Alert.Group defaultVisible type="neutral" prefixSameWidth>
        <Alert prefix={<Tag theme="warning">Billing</Tag>}>
          To ensure you benefit from the best pricing strategy, the resource
          package with a historical period of 30 days supports renewal, and the
          renewal duration is calculated according to the new validity period
          policy. For more details, please refer to the documentation.
        </Alert>
        <Alert prefix={<Tag theme="primary">Compliance</Tag>}>
          Thank you for using Tencent Cloud's high-performance computing cluster
          service.
        </Alert>
      </Alert.Group>
    </>
  );
}
```
