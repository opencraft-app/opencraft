# Alert - AlertCarouselExample

## 组件
Alert

## 示例描述
AlertCarouselExample

## 视觉特征
### 整体
浅蓝色背景的横向提示条，左侧有信息图标，中间显示文字内容，右侧有分页指示和关闭按钮，整体风格简洁现代。

### Alert: carouselMode=true defaultVisible=true
浅蓝色背景，深蓝色边框，文字为深蓝色，左侧有蓝色信息图标，文字内容为“小程序云服务器有类内测中，即刻成为产品体验官”，尺寸为横向长条形。

## 实现代码
```jsx
import React from "react";
import { Alert, List } from "@tencent/tea-component";

export default function AlertCarouselExample() {
  return (
    <Alert carouselMode defaultVisible>
      <>小程序云服务器有奖内测中，即刻成为产品体验官</>
      <>云服务器限时秒杀，首购1C1G仅需99元/年</>
      <>让企业普惠上云，云服务器最低至2.5折</>
    </Alert>
  );
}
```
