# Alert - AlertTagExample

## 组件
Alert

## 示例描述
AlertTagExample

## 视觉特征
### 整体
该 UI 组件展示了一个包含标签和提示信息的 Alert 组件示例，采用简洁的卡片式布局，背景色与文字颜色对比清晰，整体风格现代且功能明确。

### Alert: type="neutral"
背景为浅灰色，文字为深灰色，无特殊图标，用于中性提示信息。

### Alert: type="white"
背景为纯白色，文字为深灰色，边框为浅灰色，用于强调内容的提示信息。

### Tag: theme="warning"
橙色背景，白色文字，用于表示警告或需要注意的信息。

### Tag: theme="primary"
蓝色背景，白色文字，用于表示主要操作或强调信息。

## 实现代码
```jsx
import React from "react";
import { Alert, Tag } from "@tencent/tea-component";

export default function AlertTagExample() {
  return (
    <>
      <Alert
        type="neutral"
        style={{ marginTop: 8 }}
        prefix={<Tag theme="warning">计费</Tag>}
      >
        弱提示。
        <Alert.Strong>这里是加强的文字描述，This is strong text.</Alert.Strong>
      </Alert>
      <div
        style={{
          backgroundColor: "var(--tea-color-bg-page-default)",
          padding: "8px",
          marginTop: 8,
        }}
      >
        <Alert
          type="white"
          style={{ marginBottom: "0" }}
          prefix={<Tag theme="primary">提示</Tag>}
        >
          弱提示。
          <Alert.Strong>
            这里是加强的文字描述，This is strong text.
          </Alert.Strong>
        </Alert>
      </div>
    </>
  );
}
```
