# Alert - AlertExample

## 组件
Alert

## 示例描述
AlertExample

## 视觉特征
### 整体
该 alert 组件采用水平布局，包含图标、文本和链接。背景色和图标颜色随类型变化，文字均为深色，整体风格简洁。

### Alert: type="warning"
背景色为浅橙色，边框为橙色，图标为橙色感叹号，文字为深灰色，内容为“告警提示，链接”，尺寸中等。

### Alert: type="error"
背景色为浅红色，边框为红色，图标为红色感叹号，文字为深灰色，内容为“异常提示，链接”，尺寸中等。

### Alert: type="neutral"
背景色为浅灰色，边框为深灰色，图标为深灰色信息符号，文字为深灰色，内容为“常规提示，链接”，尺寸中等。

### Alert: type="white"
背景色为白色，边框为浅灰色，图标为深灰色信息符号，文字为深灰色，内容为“弱提示，链接”，尺寸中等。

## 实现代码
```jsx
import React from "react";
import { Alert } from "@tencent/tea-component";

export default function AlertExample() {
  return (
    <>
      <Alert>
        常规提示，
        <a href="https://cloud.tencent.com" target="_blank" rel="noreferrer">
          链接
        </a>
      </Alert>
      <Alert type="warning" style={{ marginTop: 8 }}>
        告警提示，
        <a href="https://cloud.tencent.com" target="_blank" rel="noreferrer">
          链接
        </a>
      </Alert>
      <Alert type="error" style={{ marginTop: 8 }}>
        异常提示，
        <a href="https://cloud.tencent.com" target="_blank" rel="noreferrer">
          链接
        </a>
      </Alert>
      <Alert type="neutral" style={{ marginTop: 8 }}>
        弱提示，
        <a href="https://cloud.tencent.com" target="_blank" rel="noreferrer">
          链接
        </a>
      </Alert>
      <div
        style={{
          backgroundColor: "var(--tea-color-bg-page-default)",
          padding: "8px",
          marginTop: 8,
        }}
      >
        <Alert type="white" style={{ marginBottom: "0" }}>
          弱提示，
          <a href="https://cloud.tencent.com" target="_blank" rel="noreferrer">
            链接
          </a>
        </Alert>
      </div>
    </>
  );
}
```
