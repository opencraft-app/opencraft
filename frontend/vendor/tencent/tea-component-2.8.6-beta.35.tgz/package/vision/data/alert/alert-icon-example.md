# Alert - 使用AlertIconExample

## 组件
Alert

## 示例描述
使用AlertIconExample

## 视觉特征
### 整体
该 UI 组件采用水平布局，包含图标、文本和链接，背景色区分不同状态，整体风格简洁现代。

### Alert: type="warning"
背景为浅橙色，左侧有橙色齿轮图标，文字为深色，内容为“警告提示，链接”。

### Icon: type="chart-line"
蓝色折线图标，位于文本前，用于表示常规提示。

### Icon: type="setting"
橙色齿轮图标，位于文本前，用于表示警告提示。

## 实现代码
```jsx
import React from "react";
import { Alert, Icon } from "@tencent/tea-component";

export default function AlertIconExample() {
  return (
    <>
      <Alert prefix={<Icon type="chart-line" />}>
        常规提示，
        <a href="https://cloud.tencent.com" target="_blank" rel="noreferrer">
          链接
        </a>
      </Alert>
      <Alert
        type="warning"
        style={{ marginTop: 8 }}
        prefix={<Icon type="setting" />}
      >
        告警提示，
        <a href="https://cloud.tencent.com" target="_blank" rel="noreferrer">
          链接
        </a>
      </Alert>
    </>
  );
}
```
