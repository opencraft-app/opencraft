# Alert - AlertNoticeExample

## 组件
Alert

## 示例描述
AlertNoticeExample

## 视觉特征
### 整体
整体采用浅色背景，包含一个标题和项目符号列表，布局简洁，风格统一，适用于信息提示场景。

### Alert.Notice: defaultOpen=true title="【公告】关于硬盘快照将于2019年7月正式商业化的通知"
显示一个带有标题的公告组件，标题为【公告】关于硬盘快照将于2019年7月正式商业化的通知，文字为深色，背景为浅色，无边框或特殊图标。

### List: type="bullet"
显示一个项目符号列表，包含三条文本信息，每项以圆点开头，文字为深色，背景为浅色，无边框或特殊图标。

## 实现代码
```jsx
import React from "react";
import { Alert, List } from "@tencent/tea-component";

export default function AlertNoticeExample() {
  return (
    <div
      style={{
        backgroundColor: "var(--tea-color-bg-secondary-default)",
        padding: 20,
      }}
    >
      <Alert.Notice
        defaultOpen
        title="【公告】关于硬盘快照将于2019年7月正式商业化的通知"
      >
        <List type="bullet">
          <List.Item>小程序云服务器有奖内测中，即刻成为产品体验官</List.Item>
          <List.Item>
            云服务器限时秒杀，首购1C1G仅需99元/年，还有多款配置供您选择
          </List.Item>
          <List.Item>
            让企业普惠上云，云服务器最低至2.5折，还有更多产品更低折扣满足您的需求
          </List.Item>
        </List>
      </Alert.Notice>
    </div>
  );
}
```
