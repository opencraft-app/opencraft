# Alert - AlertComposingExample

## 组件
Alert

## 示例描述
AlertComposingExample

## 视觉特征
### 整体
该组件采用分层布局，顶部为警告信息区域，下方为可滑动内容列表。核心交互为轮播切换和链接点击。整体使用警示色系，以橙色为主色调，文字为深色，突出重要提示。

### Alert: carouselMode=true type="warning" visible=true
橙色背景的警告框，包含一个信息图标，文字为深色，内容为“重要声明”和两行说明文本。

### List: type="bullet"
项目符号列表，包含两个项目，文字为深色，背景为浅橙色，与警告框背景色一致。

### Button: type="link"
链接样式的按钮，文字为深色，无背景色和边框，位于列表下方，文字内容为“操作项”。

## 实现代码
```jsx
import React from "react";
import { Alert, List, Button, TextEllipsis } from "@tencent/tea-component";

export default function AlertComposingExample() {
  return (
    <>
      <Alert>
        <h4 style={{ marginBottom: 8 }}>重要声明</h4>
        <p>本功能将在 2019 年 2 月 29 日下线，请注意做好下列迁移工作：</p>
        <List type="bullet">
          <List.Item>小程序云服务器有奖内测中，即刻成为产品体验官</List.Item>
          <List.Item>
            云服务器限时秒杀，首购1C1G仅需99元/年，还有多款配置供您选择
          </List.Item>
        </List>
      </Alert>
      <Alert type="warning" carouselMode visible>
        <>
          <h4 style={{ marginBottom: 8 }}>重要声明</h4>
          <List type="bullet">
            <List.Item>小程序云服务器有奖内测中，即刻成为产品体验官</List.Item>
            <List.Item>
              云服务器限时秒杀，首购1C1G仅需99元/年，还有多款配置供您选择
            </List.Item>
          </List>
          <p style={{ marginTop: 8 }}>
            <Button type="link">操作项</Button>
          </p>
        </>
        <>
          <h4 style={{ marginBottom: 8 }}>重要声明</h4>
          <List type="bullet">
            <List.Item>
              云服务器限时秒杀，首购1C1G仅需99元/年，还有多款配置供您选择
            </List.Item>
            <List.Item>小程序云服务器有奖内测中，即刻成为产品体验官</List.Item>
          </List>
          <p style={{ marginTop: 8 }}>
            <Button type="link">操作项</Button>
          </p>
        </>
      </Alert>
    </>
  );
}
```
