# Drawer - Drawer

## 组件
Drawer

## 示例描述
Drawer

## 视觉特征
### 整体
整体布局为表单控件与抽屉组件的组合。左侧为表单区域，右侧为抽屉预览。核心交互为通过按钮触发抽屉。整体采用浅色背景，主要配色为蓝色和灰色，按钮为蓝色，文字为深灰色。

### Drawer: subtitle="说明文字" title="标题"
抽屉组件，标题为“标题”，副标题为“说明文字”，文字颜色为深灰色。

### Form.Item: label="size"
表单项，标签为“size”，文字颜色为深灰色。

### Form.Item: label="placement"
表单项，标签为“placement”，文字颜色为深灰色。

### Form.Item: label="禁用动效"
表单项，标签为“禁用动效”，文字颜色为深灰色。

### Button: type="primary"
主按钮，文字为“展开”，背景为蓝色，文字为白色。

### 交互后视觉特征
交互后展示抽屉面板：
- 半透明黑色遮罩层覆盖整个页面
- 白色面板从屏幕边缘滑入（默认从右侧）
- 顶部：标题栏，包含标题和关闭按钮
- 中间：内容区域，可滚动
- 底部：可选的操作按钮区
- 支持不同方向：left/right/top/bottom

## 实现代码
```jsx
import React, { useState } from "react";
import {
  Button,
  Drawer,
  Segment,
  Form,
  Switch,
  Bubble,
} from "@tencent/tea-component";

export default function DrawerExample() {
  const [size, setSize] = useState("m");
  const [placement, setPlacement] = useState("right");
  const [disableAnimation, setDisableAnimation] = useState(false);
  const [disableOuterClick, setDisableOuterClick] = useState(false);
  const [showMask, setShowMask] = useState(false);

  const [visible, setVisible] = useState(false);

  return (
    <>
      <Form>
        <Form.Item label="size">
          <Segment
            value={size}
            onChange={size => setSize(size)}
            options={[
              { value: "m" },
              { value: "xm" },
              { value: "l" },
              { value: "xl" },
            ]}
          />
        </Form.Item>
        <Form.Item label="placement">
          <Segment
            value={placement}
            onChange={placement => setPlacement(placement)}
            options={[{ value: "left" }, { value: "right" }]}
          />
        </Form.Item>
        <Form.Item label="禁用动效">
          <Switch
            value={disableAnimation}
            onChange={disableAnimation => setDisableAnimation(disableAnimation)}
          />
        </Form.Item>
        <Form.Item label="禁用点击外部区域关闭">
          <Switch
            value={disableOuterClick}
            onChange={disableOuterClick =>
              setDisableOuterClick(disableOuterClick)
            }
          />
        </Form.Item>
        <Form.Item label="是否显示遮罩">
          <Switch
            value={showMask}
            onChange={showMask => setShowMask(showMask)}
          />
        </Form.Item>
      </Form>
      <Form.Action>
        <Button
          type="primary"
          style={{ margin: 32 }}
          onClick={() => setVisible(true)}
        >
          展开
        </Button>
      </Form.Action>

      <Drawer
        // @ts-ignore
        size={size}
        // @ts-ignore
        placement={placement}
        disableAnimation={disableAnimation}
        outerClickClosable={!disableOuterClick}
        showMask={showMask}
        visible={visible}
        title="标题"
        subtitle="说明文字"
        footer={<Button type="primary">操作按钮</Button>}
        onClose={() => setVisible(false)}
      >
        <Bubble content="提示内容" placement="left">
          <p style={{ padding: "20px 0" }}>
            可以根据实际需求，选则是否需要头尾结构
          </p>
        </Bubble>
        <img
          src="http://ue.qzone.qq.com/200x400"
          style={{ width: "100%", verticalAlign: "top" }}
          alt=""
        />
      </Drawer>
    </>
  );
}
```
