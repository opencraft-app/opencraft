# Imagepreview - ImagePreview

## 组件
Imagepreview

## 示例描述
ImagePreview

## 视觉特征
### 整体
这是一个简洁的图片预览组件，采用白色背景和浅灰色边框，包含图片占位符、标题文字和预览图标，整体风格扁平化。

### ImagePreview: previewSrc="https://via.placeholder.com/2000" previewTitle="这是一张示例图片" src="https://via.placeholder.com/100"
组件背景为白色，边框为浅灰色。显示一个100x100像素的缩略图，缩略图右下角有绿色预览图标。预览标题为黑色文字“这是一张示例图片”，位于缩略图上方。

### 交互后视觉特征
交互后展示图片预览层：
- 全屏黑色/半透明遮罩层
- 图片居中大图显示
- 支持缩放、旋转操作按钮
- 多图时有左右切换箭头
- 可能显示图片计数（1/5）

## 实现代码
```jsx
import React from "react";
import { ImagePreview } from "@tencent/tea-component";

export default function ImagePreviewExample() {
  return (
    <ImagePreview
      src="https://via.placeholder.com/100"
      previewSrc="https://via.placeholder.com/2000"
      previewTitle="这是一张示例图片"
    />
  );
}
```
