# Imagepreview - ImagePreviewTrigger

## 组件
Imagepreview

## 示例描述
ImagePreviewTrigger

## 视觉特征
### 整体
整体布局为水平排列，左侧是蓝色文字链接，右侧是蓝色图标，背景为白色，设计风格简洁现代。

### ImagePreview: previewSrc="https://via.placeholder.com/2000" previewTitle="这是一张示例图片"
组件为蓝色文字链接，文字内容为“查看大图”，文字颜色为蓝色，无边框，无图标，尺寸为默认大小。

### 交互后视觉特征
交互后展示图片预览层：
- 全屏黑色/半透明遮罩层
- 图片居中大图显示
- 支持缩放、旋转操作按钮
- 多图时有左右切换箭头
- 可能显示图片计数（1/5）

## 实现代码
```jsx
import React from "react";
import { ImagePreview } from "@tencent/tea-component";

export default function ImagePreviewExample() {
  return (
    <ImagePreview
      previewSrc="https://via.placeholder.com/2000"
      previewTitle="这是一张示例图片"
    >
      {open => <a onClick={open}>查看大图</a>}
    </ImagePreview>
  );
}
```
