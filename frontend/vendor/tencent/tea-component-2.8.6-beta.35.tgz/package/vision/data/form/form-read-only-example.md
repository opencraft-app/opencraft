# Form - FormReadOnly

## 组件
Form

## 示例描述
FormReadOnly

## 视觉特征
### 整体
这是一个卡片式表单，整体布局分为标题区和表单项区。标题为“个人信息”，右上角有“修改”链接按钮。表单项以标签-值对形式垂直排列，背景为白色，文字为深灰色，整体风格简洁清晰。

### Card.Body: title="个人信息"
卡片主体区域，标题为“个人信息”，文字为深灰色，字体较大，位于区域顶部左侧。

### Button: type="link"
按钮文字为“修改”，颜色为蓝色，无背景和边框，呈现为可点击的文本链接样式。

### Form: readonly=true
表单处于只读模式，所有输入项均不可编辑，以文本形式展示数据，布局为标签在左，值在右。

### Form.Item: label="用户名"
标签为“用户名”，文字为深灰色，右侧对应值为“Tea”，文字颜色与标签一致。

### Form.Item: label="密码"
标签为“密码”，文字为深灰色，右侧对应值为“******”，文字颜色与标签一致。

## 实现代码
```jsx
import React from "react";
import { Form, Card, Button } from "@tencent/tea-component";

export default function FormReadOnlyExample() {
  return (
    <div className="example-stage">
      <Card>
        <Card.Body
          title="个人信息"
          operation={<Button type="link">修改</Button>}
        >
          <Form readonly>
            <Form.Item label="用户名">
              <Form.Text>Tea</Form.Text>
            </Form.Item>
            <Form.Item label="密码">
              <Form.Text>******</Form.Text>
            </Form.Item>
            <Form.Item label="生效时间">
              <Form.Text>2019-03-27</Form.Text>
            </Form.Item>
          </Form>
        </Card.Body>
      </Card>
    </div>
  );
}
```
