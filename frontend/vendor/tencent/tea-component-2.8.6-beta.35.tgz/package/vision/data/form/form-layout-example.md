# Form - FormLayout

## 组件
Form

## 示例描述
FormLayout

## 视觉特征
### 整体
该组件采用左右分栏布局，左侧为配置选项，右侧为表单预览。主要交互元素包括布局类型选择器、开关和表单控件。整体配色以白色为主，文字为深灰色，按钮使用蓝色强调色。

### Card.Body: title="布局选项"
标题为深灰色的"布局选项"，位于白色卡片内，无边框，文字颜色为深灰色。

### Card.Body: title="布局效果"
标题为深灰色的"布局效果"，位于白色卡片内，无边框，文字颜色为深灰色。

### Form.Item: label="姓名"
标签为深灰色的"姓名"，右侧为一个带有浅灰色边框的输入框，文字颜色为深灰色。

### Form.Item: label="年龄"
标签为深灰色的"年龄"，右侧为一个包含数字输入框和加减按钮的控件，文字颜色为深灰色。

### Button: type="primary"
一个蓝色的矩形按钮，内部文字为白色，文字内容为"保存"，文字颜色为白色。

## 实现代码
```jsx
import React, { useState } from "react";
import {
  Form,
  Input,
  RadioGroup,
  Radio,
  CheckboxGroup,
  Checkbox,
  InputNumber,
  Card,
  Segment,
  Button,
  Switch,
} from "@tencent/tea-component";

export default function FormLayoutExample() {
  /** @type {any} */
  const [layout, setLayout] = useState("default");
  const [hideLabel, setHideLabel] = useState(false);

  return (
    <div className="example-stage">
      <Card>
        <Card.Body title="布局选项">
          <Form hideLabel={hideLabel}>
            <Form.Item label="布局类型">
              <Segment
                value={layout}
                onChange={layout => setLayout(layout)}
                options={[
                  { value: "default", text: "默认", tooltip: "default" },
                  { value: "fixed", text: "定宽", tooltip: "fixed" },
                  { value: "vertical", text: "垂直", tooltip: "vertical" },
                  { value: "inline", text: "内联", tooltip: "inline" },
                  { value: "flex", text: "flex", tooltip: "flex" },
                  {
                    value: "inline-vertical",
                    text: "内联垂直",
                    tooltip: "inline-vertical",
                  },
                ]}
              />
            </Form.Item>
            <Form.Item label="隐藏 Label">
              <Switch
                value={hideLabel}
                onChange={value => setHideLabel(value)}
              />
            </Form.Item>
          </Form>
        </Card.Body>
        <hr />
        <Card.Body title="布局效果">
          <Form
            layout={layout}
            hideLabel={hideLabel}
            fixedLabelWidth={layout === "fixed" ? "10em" : "20%"}
          >
            <Form.Item label="地址">
              <Form.Text>深圳市南山区</Form.Text>
            </Form.Item>
            <Form.Item label="姓名">
              <Input placeholder="你是谁" size="full" />
            </Form.Item>
            <Form.Item label="性别">
              <RadioGroup>
                <Radio name="male">男</Radio>
                <Radio name="female">女</Radio>
              </RadioGroup>
            </Form.Item>
            <Form.Item label="年龄">
              <InputNumber defaultValue={18} min={12} max={100} />
            </Form.Item>
            <Form.Item label="兴趣">
              <CheckboxGroup>
                <Checkbox name="code">编程</Checkbox>
                <Checkbox name="web">抠图</Checkbox>
                <Checkbox name="jinli">超越</Checkbox>
              </CheckboxGroup>
            </Form.Item>
            <Form.Item label="自我介绍" tips="100 字以内">
              <Input multiline placeholder="介绍下自己" />
            </Form.Item>
          </Form>
          <Form.Action>
            <Button type="primary">保存</Button>
            <Button>取消</Button>
          </Form.Action>
        </Card.Body>
      </Card>
    </div>
  );
}
```
