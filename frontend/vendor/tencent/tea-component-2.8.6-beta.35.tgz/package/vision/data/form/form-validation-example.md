# Form - FormValidation

## 组件
Form

## 示例描述
FormValidation

## 视觉特征
### 整体
整体采用卡片式布局，分为表单区域和控件区域。表单区域包含多个输入项，通过状态色区分验证结果。控件区域展示独立控件的错误提示。整体配色以灰白为主，错误状态使用红色，成功状态使用绿色。

### Form.Item: label="姓名" status="success"
标签为“姓名”，输入框内有文字“你是谁”，右侧有绿色圆形勾选图标，表示验证成功。

### Form.Item: label="性别" message="未选择" status="error"
标签为“性别”，下方有红色文字“未选择”，并有红色感叹号图标，表示验证失败。

### Form.Item: label="年龄" status="validating"
标签为“年龄”，输入框内有数字“18”，右侧有蓝色圆形加载图标，表示正在验证。

### Form.Control: message="设置失败" status="error"
显示红色文字“设置失败”，位于一个独立的控件区域，用于提示操作错误。

### InputNumber: disabled=true max=100 min=12
一个输入框，显示数字“300”，但被红色边框包围，表示超出范围，且无法编辑。

## 实现代码
```jsx
import React from "react";
import {
  Form,
  Input,
  RadioGroup,
  Radio,
  CheckboxGroup,
  Checkbox,
  InputNumber,
  Card,
  Switch,
  InputAdornment,
} from "@tencent/tea-component";

export default function FormValidationExample() {
  return (
    <div className="example-stage">
      <Card>
        <Card.Body title="表单验证">
          {/* <Form.Title>表单验证</Form.Title> */}
          <Form>
            <Form.Item label="姓名" status="success">
              <Input placeholder="你是谁" />
            </Form.Item>
            <Form.Item
              label="性别"
              status="error"
              message="未选择"
              extra="请选择性别"
            >
              <RadioGroup>
                <Radio name="male">男</Radio>
                <Radio name="female">女</Radio>
              </RadioGroup>
            </Form.Item>
            <Form.Item label="年龄" status="validating">
              <InputNumber defaultValue={18} min={12} max={100} disabled />
            </Form.Item>
            <Form.Item label="兴趣" message="选择一项或多项爱好">
              <CheckboxGroup>
                <Checkbox name="code">编程</Checkbox>
                <Checkbox name="web">抠图</Checkbox>
                <Checkbox name="jinli">超越</Checkbox>
              </CheckboxGroup>
            </Form.Item>
          </Form>
          <hr />
          <Form.Title>为控件单独使用</Form.Title>
          <Form.Control status="error" message="设置失败">
            <Switch>自动重启</Switch>
          </Form.Control>
          <Form.Control
            status="error"
            message="不能设置超过 200M"
            style={{ marginTop: 20 }}
          >
            <InputAdornment after="Mbps" appearance="pure">
              <InputNumber defaultValue={300} />
            </InputAdornment>
          </Form.Control>
        </Card.Body>
      </Card>
    </div>
  );
}
```
