# Form - FormWithReactFinalForm

## 组件
Form

## 示例描述
FormWithReactFinalForm

## 视觉特征
### 整体
这是一个白色背景的卡片式表单，标题为“表单验证”。布局分为标题、多个表单项和底部提交按钮。核心交互是表单输入与提交。整体采用简洁的黑白配色，按钮为蓝色。

### Card.Body: title="表单验证"
卡片内容区域的标题，文字为黑色，内容为“表单验证”。

### Form.Item: label="昵称"
标签为“昵称”，文字为黑色，右侧为一个带有“你是谁”占位符的白色输入框。

### Form.Item: label="年龄"
标签为“年龄”，文字为黑色，右侧为一个包含数字“18”的输入框和一个绿色的勾选图标。

### Form.Item: label="兴趣" message="选择一项或多项爱好"
标签为“兴趣”，文字为黑色，下方有三个复选框，提示文字为灰色的“选择一项或多项爱好”。

### Button: htmlType="submit" type="primary"
一个蓝色的矩形按钮，文字为白色，内容为“提交”。

## 实现代码
```jsx
// @ts-nocheck
import React from "react";
import {
  Form,
  Input,
  RadioGroup,
  Radio,
  CheckboxGroup,
  Checkbox,
  Card,
  InputNumber,
  Button,
} from "@tencent/tea-component";

// eslint-disable-next-line
import { Form as FinalForm, Field } from "react-final-form";

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

function getStatus(meta, validating) {
  if (meta.active && validating) {
    return "validating";
  }
  if (!meta.touched) {
    return null;
  }
  return meta.error ? "error" : "success";
}

export default function FormWithReactFinalFormExample() {
  async function onSubmit(values) {
    await sleep(1500);
    alert(JSON.stringify(values));
  }

  return (
    <div className="example-stage">
      <Card>
        <Card.Body title="表单验证">
          {/*
            `initialValuesEqual` 默认为 shallowEqual，如果初始值有多层，会导致重渲染
            https://github.com/final-form/react-final-form#initialvaluesequal-object-object--boolean
          */}
          <FinalForm
            onSubmit={onSubmit}
            initialValuesEqual={() => true}
            initialValues={{
              age: 18,
              hobbies: [],
            }}
          >
            {({ handleSubmit, validating, submitting }) => {
              return (
                <form onSubmit={handleSubmit}>
                  <Form>
                    <Field
                      name="name"
                      validateOnBlur
                      validateFields={[]}
                      validate={async value => {
                        await sleep(1500);
                        return !value || value.length < 4
                          ? "昵称太短了哦"
                          : undefined;
                      }}
                    >
                      {({ input, meta }) => (
                        <Form.Item
                          label="昵称"
                          status={getStatus(meta, validating)}
                          message={
                            getStatus(meta, validating) === "error" &&
                            meta.error
                          }
                        >
                          <Input
                            {...input}
                            autoComplete="off"
                            placeholder="你是谁"
                          />
                        </Form.Item>
                      )}
                    </Field>
                    <Field
                      name="sex"
                      validateFields={[]}
                      validate={value => (!value ? "请选择性别" : undefined)}
                    >
                      {({ input, meta }) => (
                        <Form.Item
                          label="性别"
                          status={getStatus(meta)}
                          message={getStatus(meta) === "error" && meta.error}
                        >
                          <RadioGroup {...input}>
                            <Radio name="male">男</Radio>
                            <Radio name="female">女</Radio>
                          </RadioGroup>
                        </Form.Item>
                      )}
                    </Field>
                    <Field
                      name="age"
                      validateFields={[]}
                      validate={value =>
                        value < 18 ? "你好像还未成年哦" : undefined
                      }
                    >
                      {({ input, meta }) => (
                        <Form.Item
                          label="年龄"
                          status={meta.error ? "error" : "success"}
                          message={meta.error}
                        >
                          <InputNumber {...input} min={12} max={100} />
                        </Form.Item>
                      )}
                    </Field>
                    <Field
                      name="hobbies"
                      validateFields={[]}
                      validate={value =>
                        value.length < 1 ? "请至少选择一个哦" : undefined
                      }
                    >
                      {({ input, meta }) => (
                        <Form.Item
                          label="兴趣"
                          status={getStatus(meta)}
                          message="选择一项或多项爱好"
                        >
                          <CheckboxGroup {...input}>
                            <Checkbox name="code">编程</Checkbox>
                            <Checkbox name="web">抠图</Checkbox>
                            <Checkbox name="jinli">超越</Checkbox>
                          </CheckboxGroup>
                        </Form.Item>
                      )}
                    </Field>
                  </Form>
                  <Form.Action>
                    <Button
                      type="primary"
                      htmlType="submit"
                      loading={submitting}
                    >
                      提交
                    </Button>
                  </Form.Action>
                </form>
              );
            }}
          </FinalForm>
        </Card.Body>
      </Card>
    </div>
  );
}
```
