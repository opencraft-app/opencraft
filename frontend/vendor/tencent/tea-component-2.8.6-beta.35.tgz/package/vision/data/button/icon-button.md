# Button - 图标按钮

## 组件
Button

## 示例描述
图标按钮

## 视觉特征
### 整体
该组件采用表单布局，包含文本按钮、图标按钮和链接按钮等变体。主要区域划分为按钮组和表单项，核心交互为点击操作。整体配色以中性色为主，强调色用于品牌按钮，文字颜色根据按钮状态和样式变化。

### Button: icon="monitor" loading=true shape="square" theme="neutral" title="监控" variant="outlined"
方形轮廓按钮，带有监控图标和加载状态，文字为“监控”，颜色为中性色，边框清晰。

### Button: icon="monitor" shape="square" theme="brand" title="监控" variant="solid"
方形实底按钮，带有监控图标，文字为“监控”，背景为品牌色，文字颜色为白色。

### Button: title="监控" variant="plain"
纯文本按钮，无边框无背景，文字为“监控”，颜色为中性色，用于链接或次要操作。

### Button: disabled=true icon="monitor" shape="square" theme="neutral" title="监控" variant="outlined"
方形轮廓按钮，带有监控图标，文字为“监控”，处于禁用状态，颜色为中性色，边框和文字呈灰色。

### Button: theme="brand" title="监控" variant="solid"
实底按钮，背景为品牌色，文字为“监控”，文字颜色为白色，用于主要操作。

## 实现代码
```jsx
import React from "react";
import { Button, Form } from "@tencent/tea-component";
import { MonitorIcon } from "@tencent/tea-icons-react";

export default function IconButtonExample() {
  const style = { marginRight: 5 };
  return (
    <Form>
      <Form.Item label="普通" align="middle">
        <Button icon="monitor" title="监控" style={style} />
        <Button icon="monitor" title="监控" loading style={style} />
        <Button icon="monitor" title="监控" disabled style={style} />
        <Button title="监控" variant="plain" style={style}>
          <MonitorIcon size={16} />
          按钮
        </Button>
        <Button title="监控" variant="plain" disabled style={style}>
          <MonitorIcon size={16} />
          按钮
        </Button>
      </Form.Item>
      <Form.Item label="带框" align="middle">
        <Button
          icon="monitor"
          shape="square"
          variant="outlined"
          theme="neutral"
          title="监控"
          style={style}
        />
        <Button
          icon="monitor"
          shape="square"
          variant="outlined"
          theme="neutral"
          title="监控"
          loading
          style={style}
        />
        <Button
          icon="monitor"
          shape="square"
          variant="outlined"
          theme="neutral"
          title="监控"
          disabled
          style={style}
        />
        <Button title="监控" style={style}>
          <MonitorIcon size={16} />
          按钮
        </Button>

        <Button title="监控" disabled style={style}>
          <MonitorIcon size={16} />
          按钮
        </Button>
      </Form.Item>
      <Form.Item label="加强" align="middle">
        <Button
          icon="monitor"
          shape="square"
          variant="solid"
          theme="brand"
          title="监控"
          style={style}
        />
        <Button
          icon="monitor"
          shape="square"
          variant="solid"
          theme="brand"
          title="监控"
          loading
          style={style}
        />
        <Button
          icon="monitor"
          shape="square"
          variant="solid"
          theme="brand"
          title="监控"
          disabled
          style={style}
        />
        <Button title="监控" variant="solid" theme="brand" style={style}>
          <MonitorIcon size={16} />
          按钮
        </Button>
        <Button
          title="监控"
          variant="solid"
          theme="brand"
          disabled
          style={style}
        >
          <MonitorIcon size={16} />
          按钮
        </Button>
      </Form.Item>
    </Form>
  );
}
```
