# Button - 常规按钮

## 组件
Button

## 示例描述
常规按钮

## 视觉特征
### 整体
整体布局为三行两列的按钮示例，包含主次按钮样式，采用中性背景与品牌色搭配，文字居中对齐，风格简洁统一。

### Button: theme="brand" variant="solid"
橙色背景，白色文字，无边框，常规状态，文字内容为“支付按钮”

### Button: loading=true theme="brand" variant="solid"
橙色背景，白色文字，无边框，加载状态，文字内容为“支付按钮”

### Button: disabled=true theme="brand" variant="solid"
橙色背景，白色文字，无边框，禁用状态，文字内容为“支付按钮”

### Button: variant="outlined"
白色背景，红色文字，带红色边框，常规状态，文字内容为“次要按钮”

### Button: loading=true variant="outlined"
白色背景，红色文字，带红色边框，加载状态，文字内容为“次要按钮”

### Button: disabled=true variant="outlined"
白色背景，红色文字，带红色边框，禁用状态，文字内容为“次要按钮”

## 实现代码
```jsx
import React from "react";
import { Button, Form } from "@tencent/tea-component";

export default function CommonButtonExample() {
  const style = { marginRight: 5 };
  return (
    <Form>
      <Form.Item label="主要按钮" align="middle">
        <Button variant="solid" theme="brand" style={style}>
          主要按钮
        </Button>
        <Button variant="solid" theme="brand" loading style={style}>
          主要按钮
        </Button>
        <Button variant="solid" theme="brand" disabled style={style}>
          主要按钮
        </Button>
      </Form.Item>
      <Form.Item label="次要按钮" align="middle">
        <Button variant="outlined" style={style}>
          次要按钮
        </Button>
        <Button variant="outlined" loading style={style}>
          次要按钮
        </Button>
        <Button variant="outlined" disabled style={style}>
          次要按钮
        </Button>
      </Form.Item>
    </Form>
  );
}
```
