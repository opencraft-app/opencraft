# Button - 语法糖

## 组件
Button

## 示例描述
语法糖

## 视觉特征
### 整体
水平排列的按钮组件集合，包含多种类型和状态，采用扁平化设计风格，按钮间有明显间距。

### Button: type="primary"
蓝色背景，白色文字，标准矩形按钮，文字内容为"primary button"。

### Button: type="error"
红色背景，白色文字，标准矩形按钮，文字内容为"error button"。

### Button: type="pay"
橙色背景，白色文字，标准矩形按钮，文字内容为"pay button"。

### Button: type="link"
无背景色，蓝色文字，无边框，文字内容为"link button"。

### Button: type="text"
无背景色，黑色文字，无边框，文字内容为"text button"。

### Button: type="weak"
浅灰色背景，深灰色文字，标准矩形按钮，文字内容为"weak"。

### Button: icon="shopcart"
白色背景，黑色图标，无文字，图标为购物车。

## 实现代码
```jsx
import React from "react";
import { Button } from "@tencent/tea-component";

export default function ButtonThemeVariantExample() {
  const style = { marginRight: 10, marginBottom: 10 };
  return (
    <>
      <Button type="primary" style={style}>
        primary button
      </Button>
      <Button type="error" style={style}>
        error button
      </Button>
      <Button type="pay" style={style}>
        pay button
      </Button>
      <Button type="link" style={style}>
        link button
      </Button>
      <Button type="text" style={style}>
        text button
      </Button>
      <Button type="weak" style={style}>
        weak
      </Button>
      <Button icon="shopcart" style={style}>
        icon
      </Button>
    </>
  );
}
```
