# Icon - IconLarge

## 组件
Icon

## 示例描述
IconLarge

## 视觉特征
### 整体
一组圆形图标按钮，采用扁平化设计风格，图标居中，背景色与图标颜色一致，整体布局紧凑，视觉统一。

### Icon: size=32
圆形背景，内含白色图标，背景色分别为橙色、橙色、橙色、蓝色、绿色，图标分别为感叹号、感叹号、时钟、信息、对勾，文字内容为空，文字颜色为白色。

## 实现代码
```jsx
import React from "react";
import { Icon, Bubble, Copy } from "@tencent/tea-component";

const largeIconTypes = ["warning", "error", "pending", "infoblue", "success"];

export default function IconExample() {
  return largeIconTypes.map(type => (
    <Bubble key={type} content={`<Icon type="${type}" size="l" />`}>
      <Copy
        text={`<Icon type="${type}" size="l" />`}
        tips={copied =>
          copied ? (
            "复制成功"
          ) : (
            <>
              <div style={{ textAlign: "center" }}>点击复制</div>
              <div>{`<Icon type="${type}" size="l" />`}</div>
            </>
          )
        }
      >
        <Icon
          type={type}
          size={32}
          style={{ margin: "0 10px 10px 0", cursor: "pointer" }}
        />
      </Copy>
    </Bubble>
  ));
}
```
