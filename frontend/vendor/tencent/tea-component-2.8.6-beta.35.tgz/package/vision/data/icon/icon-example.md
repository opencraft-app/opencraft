# Icon - Icon

## 组件
Icon

## 示例描述
Icon

## 视觉特征
### 整体
图标组件展示了一系列功能图标，采用统一的线性风格，布局为网格排列，图标大小一致，视觉简洁。

### Icon: size="s"
所有图标均为小尺寸，采用单色线条设计，无填充，形状包括圆形、方形和箭头等，颜色为深灰色。

## 实现代码
```jsx
import React from "react";
import { Icon, Bubble, Copy } from "@tencent/tea-component";

// 暂无 SVG：'records', 'sales', 'shutdown', 'running', 'deploy', 'links', 'client', 'alarm', 'try', 'new', 'favorable'
// prettier-ignore
const iconTypes = [
  "close", "dismiss", "delete", "shopcart", "more", "folderclose", "folderopen", "notice",
  "guide", "consult", "realname", "realnamev", "show", "hide", "success",
  "warning", "loading", "error", "sort", "sortup", "sortdown", "btnback", "plus", "minus", "setting",
  "pencil", "copy", "remind", "phone", "phonev", "phone-warning", "phone-error", "wechat", "wechatv",
  "wechat-warning", "wechat-error", "email", "emailv", "email-warning", "email-error", "qq",
  "viewgrid", "viewlist", "monitor", "download", "filter", "convertip--blue", "convertip",
  "info", "arrowup", "arrowdown", "arrowleft", "arrowright", "externallink", "refresh", "refresh-blue",
  "fullscreen", "fullscreenquit", "trenddown", "trendup", "drop", "news", "help", "pending-gray", "pending",
  "infoblue", "lastpage", "firstpage", "search", "transfer", "cur", "cur-active", "fold", "check",
  "not", "and", "detail", "qrcode", "database", "datasheet", "daily",
  "chart-pie", "chart-pie-hover", "chart-line", "chart-line-hover", "chart-column", "chart-column-hover",
  "table", "table-hover", "relationship", "relationship-hover", "multi-line", "percent", "percent-blue", "tag", "teaching"
];

const smallIconTypes = ["close", "dismiss", "check"];

export default function IconExample() {
  return (
    <>
      <section className="demo-icon-show">
        {iconTypes.map(type => (
          <Bubble key={type} content={`<Icon type="${type}" />`}>
            <Copy
              text={`<Icon type="${type}" />`}
              tips={copied =>
                copied ? (
                  "复制成功"
                ) : (
                  <>
                    <div style={{ textAlign: "center" }}>点击复制</div>
                    <div>{`<Icon type="${type}" />`}</div>
                  </>
                )
              }
            >
              <Icon
                type={type}
                style={{ margin: "0 10px 10px 0", cursor: "pointer" }}
              />
            </Copy>
          </Bubble>
        ))}
      </section>
      <section>
        {smallIconTypes.map(type => (
          <Bubble key={type} content={`<Icon type="${type}" size="s" />`}>
            <Copy
              text={`<Icon type="${type}" size="s" />`}
              tips={copied =>
                copied ? (
                  "复制成功"
                ) : (
                  <>
                    <div style={{ textAlign: "center" }}>点击复制</div>
                    <div>{`<Icon type="${type}" size="s" />`}</div>
                  </>
                )
              }
            >
              <Icon
                type={type}
                size="s"
                style={{ margin: "0 10px 10px 0", cursor: "pointer" }}
              />
            </Copy>
          </Bubble>
        ))}
        {/** 无法改变颜色 */}
        {/* <ErrorCircleIcon color="yellow" /> */}
        {/* <LoadingIcon color="yellow" /> */}
        {/** 支持 size */}
        {/* <LoadingIcon color="yellow" size={40} /> */}
        {/** 不支持 size */}
        {/* <LoadingIcon color="yellow" size={40} style={{ display: "block" }} /> */}
      </section>
    </>
  );
}
```
