# Breadcrumb - BreadcrumbExample

## 组件
Breadcrumb

## 示例描述
BreadcrumbExample

## 视觉特征
### 整体
这是一个水平排列的面包屑导航组件，采用深色文字和浅色背景，路径项之间用斜杠分隔，整体风格简洁清晰。

## 实现代码
```jsx
import React from "react";
import { Breadcrumb } from "@tencent/tea-component";

export default function BreadcrumbExample() {
  return (
    <>
      <Breadcrumb>
        <Breadcrumb.Item>
          <a href="">Application 1</a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="">Application 2</a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="">Application 3</a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="">Application 4</a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="">Application 5</a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="">Application 6</a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="">Application 7</a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="">Application 8</a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>About</Breadcrumb.Item>
      </Breadcrumb>
    </>
  );
}
```
