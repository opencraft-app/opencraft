# Breadcrumb - BreadcrumbResponseExample

## 组件
Breadcrumb

## 示例描述
BreadcrumbResponseExample

## 视觉特征
### 整体
这是一个水平排列的面包屑导航组件，采用简洁的无衬线字体，路径项之间用斜杠分隔，整体风格现代且功能导向。

### Breadcrumb: responsible=true
路径项文字为深灰色，当前项为蓝色，路径分隔符为浅灰色，整体为标准文本样式，无额外图标或装饰。

## 实现代码
```jsx
import React from "react";
import { Breadcrumb } from "@tencent/tea-component";

export default function BreadcrumbResponseExample() {
  return (
    <>
      <Breadcrumb responsable>
        <Breadcrumb.Item>
          <a href="https://cloud.tencent.com/" target="_blank" rel="noreferrer">
            Application 1
          </a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="https://cloud.tencent.com/" target="_blank" rel="noreferrer">
            Application 2
          </a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="https://cloud.tencent.com/" target="_blank" rel="noreferrer">
            Application 3
          </a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="https://cloud.tencent.com/" target="_blank" rel="noreferrer">
            Application 4
          </a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="https://cloud.tencent.com/" target="_blank" rel="noreferrer">
            Application 5
          </a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="https://cloud.tencent.com/" target="_blank" rel="noreferrer">
            Application 6
          </a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="https://cloud.tencent.com/" target="_blank" rel="noreferrer">
            Application 7
          </a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="https://cloud.tencent.com/" target="_blank" rel="noreferrer">
            Application 8
          </a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>About</Breadcrumb.Item>
      </Breadcrumb>
    </>
  );
}
```
