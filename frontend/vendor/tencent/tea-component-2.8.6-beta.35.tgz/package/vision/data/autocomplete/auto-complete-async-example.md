# Autocomplete - AutoCompleteAsync

## 组件
Autocomplete

## 示例描述
AutoCompleteAsync

## 视觉特征
### 整体
这是一个简洁的输入框组件，采用白色背景和细边框设计，整体风格现代、干净，适用于表单输入场景。

### Input: size="full"
一个宽度占满父容器的输入框，边框为浅灰色，内部无文字，处于默认状态。

## 实现代码
```jsx
import React, { useState, useEffect, useRef } from "react";
import { AutoComplete, StatusTip, Input } from "@tencent/tea-component";

export default function AutoCompleteAsyncExample() {
  const [options, setOptions] = useState([]);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const [inputValue, setInputValue] = useState("");
  const inputRef = useRef("");
  const timerRef = useRef(null);

  useEffect(() => {
    fetchOptions();
    return () => timerRef.current && clearTimeout(timerRef.current);
  }, []);

  async function fetchOptions(keyword = "") {
    try {
      const options = await new Promise((resolve, reject) => {
        setTimeout(() => {
          if (Math.random() > 0.85) {
            reject(new Error());
            return;
          }
          resolve([
            { value: `1-${keyword}`, text: `${keyword}1` },
            { value: `2-${keyword}`, text: `${keyword}2` },
          ]);
        }, 800);
      });
      if (inputRef.current !== keyword) {
        return;
      }
      setOptions(options);
    } catch (err) {
      setError(true);
    }
    setLoading(false);
  }

  return (
    <AutoComplete
      options={options}
      keyword={inputValue}
      tips={
        <StatusTip
          status={loading ? "loading" : error ? "error" : "empty"} // eslint-disable-line no-nested-ternary
          onRetry={() => {
            setError(false);
            setLoading(true);
            fetchOptions(inputValue);
          }}
        />
      }
      onChange={value => {
        const option = options.find(opt => opt.value === value);
        setInputValue(option.text);
        console.log(value);
      }}
    >
      {ref => (
        <Input
          size="full"
          ref={ref}
          value={inputValue}
          onChange={value => {
            if (timerRef.current) {
              clearTimeout(timerRef.current);
            }
            inputRef.current = value;
            timerRef.current = setTimeout(() => fetchOptions(value), 500);
            setLoading(true);
            setOptions([]);
            setInputValue(value);
          }}
        />
      )}
    </AutoComplete>
  );
}
```
