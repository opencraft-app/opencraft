# Notification - NotificationChangeType

## 组件
Notification

## 示例描述
NotificationChangeType

## 视觉特征
### 整体
整体采用简洁的卡片式布局，白色背景搭配深色文字，信息层级清晰。通知内容包含标题、描述和操作按钮，风格统一。

### Notification: type=info, title=上传中, description=0%
蓝色信息图标，标题为“上传中”，描述文字为“0%”，右侧有“查看详情”链接。

### Notification: type=warning, title=标题, description=文案不限长度，但是展示最大哦显示两行折行的末尾处显示折行的末尾处显示折行的末尾处显示折行的末尾处显示折行的末尾处
黄色警告图标，标题为“标题”，描述文字较长，显示为多行文本，右侧有“查看详情”链接。

### 交互后视觉特征
交互后展示内容为“上传中”和“0%”的详细信息，包含一个蓝色信息图标和一个“查看详情”链接。

## 实现代码
```jsx
import React, { useState, useRef, useEffect } from "react";
import { notification, Button, Progress } from "@tencent/tea-component";

export default function NotificationChangeType() {
  const [percent, setPercent] = useState(0);
  const notificationRef = useRef(null); // 用于保存通知实例
  const timerRef = useRef(null); // 用于保存定时器实例

  const startTimer = () => {
    // 清除之前的定时器
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }

    // 启动新的定时器
    timerRef.current = setInterval(() => {
      setPercent(prevPercent => {
        const newPercent = prevPercent + 10;
        if (newPercent >= 100) {
          clearInterval(timerRef.current); // 达到 100% 后清除定时器
          // 更新通知类型为 success
          if (notificationRef.current) {
            notificationRef.current.setConfig({
              type: "success",
              title: "上传成功",
              description: "上传成功上传成功上传成功上传成功上传成功",
              duration: 3000,
            });
          }
          return 100;
        }
        return newPercent;
      });
    }, 1000);
  };

  useEffect(() => {
    // 当 percent 变化时，更新通知的 description
    if (notificationRef.current && percent < 100) {
      notificationRef.current.setConfig({
        description: (
          <div
            style={{
              width: "250px",
            }}
          >
            <Progress percent={percent} text={percent => `${percent} %`} />
          </div>
        ),
      });
    }
  }, [percent]);

  return (
    <>
      <Button
        onClick={() => {
          // 重置进度条
          setPercent(0);

          // 显示 info 类型的通知，并保存实例
          notificationRef.current = notification.info({
            title: "上传中",
            description: (
              <div
                style={{
                  width: "250px",
                }}
              >
                <Progress percent={percent} text={percent => `${percent} %`} />
              </div>
            ),
            footer: "查看详情",
            onFooterClick: () => console.log("查看详情"),
            duration: 10000,
          });

          // 启动倒计时
          startTimer();
        }}
      >
        点击上传
      </Button>
    </>
  );
}
```
