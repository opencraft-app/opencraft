# Datepicker - DatePickerZone

## 组件
Datepicker

## 示例描述
DatePickerZone

## 视觉特征
### 整体
采用垂直布局的表单结构，包含日期选择、带时间的日期选择和时区选择三个主要区域。核心交互元素为日期选择器和时区选择器。整体配色为浅灰色背景和深灰色文字，风格简洁。

### DatePicker: showTime=true
显示日期和时间的输入框，内容为“2026-01-29 19:57:52”，右侧有日历图标，文字为深灰色。

### Select: appearance="button" matchButtonWidth=true searchable=true size="l" type="simulate"
下拉选择器，显示“时区选择”和“(GMT+08:00) 中国标准时间 - 北京 - Asia/Shanghai”，文字为深灰色，按钮样式。

### Form.Item: label="包含时间的日期选择"
表单项标签，文字为“包含时间的日期选择”，颜色为深灰色。

### Form.Item: label="日期选择"
表单项标签，文字为“日期选择”，颜色为深灰色。

### Form: layout="vertical"
垂直布局的表单，各表单项上下排列，间距均匀。

### 交互后视觉特征
交互后弹出日历面板，显示2026年1月的日历，日期“29”被蓝色圆形背景高亮，其他日期为浅灰色文字。

## 实现代码
```jsx
import React, { useState } from "react";
import moment from "moment";
import momenttz from "moment-timezone";
import { DatePicker, Select, Form } from "@tencent/tea-component";
import data from "./data";

const options = data.map(({ desc, id }) => ({
  value: id,
  text: `${desc} - ${id}`,
}));

export default () => {
  const [timezone, setTimezone] = useState(moment.tz.guess());
  const [value, setValue] = useState(moment().tz(timezone));

  return (
    <Form layout="vertical">
      <Form.Item label="日期选择">
        {/* 时区变化后通过设置 key 重置日历面板 */}
        <DatePicker
          key={timezone}
          range={[
            moment()
              .tz(timezone)
              .subtract(2, "d")
              .startOf("d"),
            moment()
              .tz(timezone)
              .add(2, "d")
              .endOf("d"),
          ]}
          value={value}
          onChange={value => {
            setValue(value);
            console.log(value.format(), value.tz());
          }}
        />
      </Form.Item>
      <Form.Item label="包含时间的日期选择">
        <DatePicker
          showTime
          key={timezone}
          range={[
            moment()
              .tz(timezone)
              .subtract(2, "d")
              .startOf("d"),
            moment()
              .tz(timezone)
              .add(2, "d")
              .endOf("d"),
          ]}
          value={value}
          onChange={value => {
            setValue(value);
            console.log(value.format(), value.tz());
          }}
        />
      </Form.Item>
      <Form.Item label="时区选择">
        <Select
          searchable
          type="simulate"
          appearance="button"
          size="l"
          matchButtonWidth
          options={options}
          value={timezone}
          onChange={tz => {
            setTimezone(tz);
            setValue(moment(value).tz(tz));
            console.log(tz);
          }}
        />
      </Form.Item>
    </Form>
  );
};
```
