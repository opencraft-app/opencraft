# Datepicker - PickerWithSegment

## 组件
Datepicker

## 示例描述
PickerWithSegment

## 视觉特征
### 整体
该组件采用垂直布局，包含多个表单项。主要区域为快捷选项栏、预设快捷选项和自定义头部。核心交互元素是Segment组件，用于切换不同日期选择模式。整体配色以中性色为主，文字颜色为弱色主题。

### Form: layout="vertical"
采用垂直堆叠的表单项布局，每个表单项独立成行，间距均匀。

### Form.Item: label="快捷选项栏"
标签文字为“快捷选项栏”，位于组件最上方，作为该区域的标题。

### Form.Item: label="预设快捷选项"
标签文字为“预设快捷选项”，位于快捷选项栏下方，作为预设选项的标题。

### Form.Item: label="自定义头部"
标签文字为“自定义头部”，位于预设选项下方，作为自定义区域的标题。

### Segment: rimless=true
Segment组件无边框，由多个标签页组成，当前选中状态通过背景色或文字颜色区分。

### Text: theme="weak"
文本内容颜色为弱色主题，视觉上较为柔和，不突出。

### 交互后视觉特征
交互后，Segment组件下方展开一个日历面板，显示2025年12月和2026年1月的日历，当前选中日期为29号，以蓝色高亮显示。

## 实现代码
```jsx
import React, { useState } from "react";
import moment from "moment";
import { DatePicker, Segment, Text, Form } from "@tencent/tea-component";

const { RangePicker } = DatePicker;

const options = [
  { text: "今天", value: "1" },
  { text: "昨天", value: "2" },
  { text: "近7天", value: "3" },
  { text: "近30天", value: "4" },
];

const rangeMap = {
  "1": [moment(), moment()],
  "2": [moment().subtract(1, "d"), moment().subtract(1, "d")],
  "3": [moment().subtract(6, "d"), moment()],
  "4": [moment().subtract(29, "d"), moment()],
};

export default () => {
  const [segmentValue1, setSegmentValue1] = useState(null);
  const [segmentValue2, setSegmentValue2] = useState(null);

  const [value1, setValue1] = useState(null);
  const [value2, setValue2] = useState(null);

  function setRangeValue(value, setter) {
    const range = rangeMap[value];
    setter(range);
    return range;
  }

  function getSegmentValue(dates) {
    const [start, end] = dates;
    return Object.entries(rangeMap).reduce((prev, cur) => {
      const [key, range] = cur;
      if (start.isSame(range[0], "day") && end.isSame(range[1], "day")) {
        return key;
      }
      return prev;
    }, null);
  }

  return (
    <Form layout="vertical">
      <Form.Item label="快捷选项栏">
        <Segment
          value={segmentValue1}
          options={options}
          onChange={value => {
            setSegmentValue1(value);
            const range = setRangeValue(value, setValue1);
            console.log(
              range[0].format("YYYY/MM/DD"),
              range[1].format("YYYY/MM/DD")
            );
          }}
        />
        <RangePicker
          value={value1}
          onChange={value => {
            setValue1(value);
            setSegmentValue1(getSegmentValue(value));
            console.log(
              value[0].format("YYYY/MM/DD"),
              value[1].format("YYYY/MM/DD")
            );
          }}
        />
      </Form.Item>
      <Form.Item label="预设快捷选项">
        <RangePicker
          header={
            <Segment
              rimless
              value={segmentValue2}
              options={options}
              onChange={value => {
                setSegmentValue2(value);
                const range = setRangeValue(value, setValue2);
                console.log(
                  range[0].format("YYYY/MM/DD"),
                  range[1].format("YYYY/MM/DD")
                );
              }}
            />
          }
          value={value2}
          onChange={value => {
            setValue2(value);
            setSegmentValue2(getSegmentValue(value));
            console.log(
              value[0].format("YYYY/MM/DD"),
              value[1].format("YYYY/MM/DD")
            );
          }}
        />
      </Form.Item>
      <Form.Item label="自定义头部">
        <RangePicker
          onChange={value => {
            console.log(
              value[0].format("YYYY/MM/DD"),
              value[1].format("YYYY/MM/DD")
            );
          }}
          range={[moment("2020-01-01"), null]}
          disabledDate={date => {
            return (
              !date.isAfter(moment(), "day") &&
              !date.isBefore(moment("2020-01-01"), "day")
            );
          }}
          header={
            <Text theme="weak">提示：仅支持选择从 2020-01-01 至今的数据</Text>
          }
        />
      </Form.Item>
    </Form>
  );
};
```
