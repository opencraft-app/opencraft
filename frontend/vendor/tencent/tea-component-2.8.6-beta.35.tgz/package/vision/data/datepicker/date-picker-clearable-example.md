# Datepicker - DatePickerClearable

## 组件
Datepicker

## 示例描述
DatePickerClearable

## 视觉特征
### 整体
整体布局为垂直堆叠的日期选择器组件，采用简洁的白色背景和灰色边框，文字为深灰色，图标为浅灰色，风格统一。

### DatePicker: clearable=true
白色背景，浅灰色边框，深灰色文字内容为'2020-10-01'，右侧有浅灰色的'清空'图标，图标为圆形背景内的'×'符号。

### 交互后视觉特征
交互后展示日历视图，背景为白色，日期数字为深灰色，当前选中日期为蓝色背景白色数字'1'，顶部显示'2020年10月'，左右有导航箭头。

## 实现代码
```jsx
import React from "react";
import { DatePicker } from "@tencent/tea-component";

export default () => {
  return (
    <DatePicker
      clearable
      onChange={value => console.log(value)}
      style={{ marginTop: 12 }}
    />
  );
};
```
