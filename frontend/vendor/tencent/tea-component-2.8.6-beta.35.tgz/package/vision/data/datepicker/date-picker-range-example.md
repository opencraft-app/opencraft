# Datepicker - DatePickerRange

## 组件
Datepicker

## 示例描述
DatePickerRange

## 视觉特征
### 整体
整体采用垂直布局，包含多个日期范围选择器，文字标签清晰，输入框与日历控件结合，风格简洁统一。

### DatePicker: showTime=true
显示包含时间的日期范围选择，输入框内文本格式为 'YYYY-MM-DD HH:mm:ss'，文字为深灰色，输入框有浅灰色边框。

### DatePicker: Form: layout="vertical", Form.Item: label="日期选择 range"
基础日期范围选择器，标签为“日期选择 range”，输入框内显示格式为 'YYYY-MM-DD'，文字为深灰色，边框为浅灰色。

### DatePicker: Form: layout="vertical", Form.Item: label="包含时间的日期选择 range"
标签为“包含时间的日期选择 range”，输入框内显示格式为 'YYYY-MM-DD HH:mm:ss'，文字为深灰色，边框为浅灰色。

### DatePicker: Form: layout="vertical", Form.Item: label="月份选择 range"
标签为“月份选择 range”，输入框内显示格式为 'YYYY-MM'，文字为深灰色，边框为浅灰色。

### DatePicker: Form: layout="vertical", Form.Item: label="包含时间的范围选择 range"
标签为“包含时间的范围选择 range”，输入框内显示格式为 'YYYY-MM-DD HH:mm:ss'，文字为深灰色，边框为浅灰色。

### 交互后视觉特征
交互后展示双月日历视图，当前选中日期为10月1日和11月11日，选中日期背景为蓝色，未选日期为浅灰色，日历标题为年月，左右箭头用于切换月份。

## 实现代码
```jsx
import React from "react";
import moment from "moment";
import { DatePicker, Form } from "@tencent/tea-component";

const { RangePicker, MonthPicker } = DatePicker;

export default () => {
  return (
    <Form layout="vertical">
      <Form.Item label="日期选择 range">
        <DatePicker
          defaultValue={moment("2020-10-01")}
          range={[moment("2020-09-01"), moment("2020-11-11")]}
          onChange={value => console.log(value.format("YYYY/MM/DD"))}
        />
      </Form.Item>
      <Form.Item label="包含时间的日期选择 range">
        <DatePicker
          showTime
          range={[moment("2019-12-02 12:30:00"), moment("2020-12-12 12:30:00")]}
          onChange={value => console.log(value.format())}
        />
      </Form.Item>
      <Form.Item label="月份选择 range">
        <MonthPicker
          defaultValue={moment("2020-10-01")}
          range={[moment("2019-09"), moment("2020-12")]}
          onChange={value => console.log(value.format("YYYY/MM/DD"))}
        />
      </Form.Item>
      <Form.Item label="包含时间的范围选择 range">
        <RangePicker
          range={[
            moment()
              .subtract(6, "d")
              .startOf("d"),
            moment().endOf("d"),
          ]}
          defaultValue={[
            moment()
              .subtract(6, "d")
              .startOf("d"),
            moment().endOf("d"),
          ]}
          showTime={{
            defaultValue: [
              moment("00:00:00", "HH:mm:ss"),
              moment("23:59:59", "HH:mm:ss"),
            ],
          }}
          onChange={value => console.log(value[0].format(), value[1].format())}
        />
      </Form.Item>
    </Form>
  );
};
```
