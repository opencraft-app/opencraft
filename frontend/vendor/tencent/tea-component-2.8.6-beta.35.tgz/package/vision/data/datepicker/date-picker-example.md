# Datepicker - DatePicker

## 组件
Datepicker

## 示例描述
DatePicker

## 视觉特征
### 整体
垂直布局的表单，包含多个日期选择器变体。组件采用简洁设计，文字标签为深灰色，输入框为浅灰色边框，整体风格统一。

### DatePicker: format="LL"
标签为“自定义格式”，输入框内显示“2020年10月1日”，文字为深灰色，输入框为浅灰色边框，右侧有日历图标。

### DatePicker: showTime=true, format="YYYY-MM-DD HH:mm:ss.SSS"
标签为“包含毫秒”，输入框内显示“2020-10-01 10:30:30.300”，文字为深灰色，输入框为浅灰色边框，右侧有日历图标。

### DatePicker: showTime=true, format="YYYY-MM-DD HH:mm"
标签为“自定义时间格式”，输入框内显示“2020-10-01 10:30”，文字为深灰色，输入框为浅灰色边框，右侧有日历图标。

### DatePicker: format="YYYY-MM-DD HH:mm:ss.SSS"
标签为“包含时间”，输入框内显示“2020-10-01 10:30:30.300”，文字为深灰色，输入框为浅灰色边框，右侧有日历图标。

### DatePicker: format="YYYY-MM-DD"
标签为“基本用法”，输入框内显示“2020-10-01”，文字为深灰色，输入框为浅灰色边框，右侧有日历图标。

### DatePicker: format="YYYY-MM"
标签为“月份选择”，输入框内显示“2020-12”，文字为深灰色，输入框为浅灰色边框，右侧有日历图标。

### DatePicker: format="YYYY-QQ"
标签为“季度选择”，输入框内显示“2020-Q4”，文字为深灰色，输入框为浅灰色边框，右侧有日历图标。

### 交互后视觉特征
交互后弹出日历面板，显示2020年10月的日历，日期为1-31，当前选中日期为1，日期数字为深灰色，选中日期背景为蓝色，边框为浅灰色。

## 实现代码
```jsx
import React from "react";
import moment from "moment";
import { DatePicker, Form } from "@tencent/tea-component";

const { MonthPicker, QuarterPicker } = DatePicker;

export default () => {
  return (
    <Form layout="vertical">
      <Form.Item label="基本用法">
        <DatePicker
          defaultValue={moment("2020-10-01")}
          onChange={value => console.log(value.format("YYYY/MM/DD"))}
          onOpenChange={open => console.log(open ? "open" : "close")}
        />
      </Form.Item>
      <Form.Item label="自定义格式">
        <DatePicker
          format="LL"
          defaultValue={moment("2020-10-01")}
          onChange={value => console.log(value.format("YYYY/MM/DD"))}
        />
      </Form.Item>
      <Form.Item label="包含时间">
        <DatePicker showTime onChange={value => console.log(value.format())} />
      </Form.Item>
      <Form.Item label="包含毫秒">
        <DatePicker
          format="YYYY-MM-DD HH:mm:ss.SSS"
          showTime={{ format: "HH:mm:ss.SSS", minuteStep: 30 }}
          defaultValue={moment("2020-10-01 10:30:30:300")}
          onChange={value => console.log(value.format())}
        />
      </Form.Item>
      <Form.Item label="自定义时间格式">
        <DatePicker
          format="YYYY-MM-DD HH:mm"
          showTime={{ format: "HH:mm", minuteStep: 30 }}
          defaultValue={moment("2020-10-01 10:30")}
          onChange={value => console.log(value.format())}
        />
      </Form.Item>
      <Form.Item label="月份选择">
        <MonthPicker
          defaultValue={moment("2020-12")}
          onChange={value => console.log(value.format())}
        />
      </Form.Item>
      <Form.Item label="季度选择">
        <QuarterPicker
          defaultValue={moment("2020-12")}
          onChange={value => console.log(value.format())}
        />
      </Form.Item>
    </Form>
  );
};
```
