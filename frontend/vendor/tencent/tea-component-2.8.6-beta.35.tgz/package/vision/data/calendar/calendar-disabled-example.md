# Calendar - CalendarDisabled

## 组件
Calendar

## 示例描述
CalendarDisabled

## 视觉特征
### 整体
这是一个日历组件的禁用状态示例，采用浅灰色背景和灰色文字，整体风格简洁，无交互元素，显示为静态信息展示。

## 实现代码
```jsx
import React from "react";
import moment from "moment";
import { Calendar } from "@tencent/tea-component";

export default () => {
  return (
    <Calendar
      disabledDate={date => !date.isAfter(moment())}
      onChange={value => console.log(value.format("YYYY/MM/DD"), value)}
    />
  );
};
```
