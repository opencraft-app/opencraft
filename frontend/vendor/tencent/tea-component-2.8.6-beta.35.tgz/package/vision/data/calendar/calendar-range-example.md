# Calendar - CalendarRange

## 组件
Calendar

## 示例描述
CalendarRange

## 视觉特征
### 整体
这是一个简洁的日历组件，采用白色背景和灰色边框，日期数字为黑色，当前日期以蓝色高亮显示，整体设计风格现代且直观。

## 实现代码
```jsx
import React from "react";
import moment from "moment";
import { Calendar } from "@tencent/tea-component";

export default () => {
  return (
    <Calendar
      range={[moment("2019-01-01"), moment("2020-01-01")]}
      onChange={value => console.log(value.format("YYYY/MM/DD"), value)}
    />
  );
};
```
