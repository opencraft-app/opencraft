# Cascader - CascaderMenuExample

## 组件
Cascader

## 示例描述
CascaderMenuExample

## 视觉特征
### 整体
整体布局为两组垂直排列的表单项，包含标签和下拉选择框，设计风格简洁，采用标准输入控件样式。

### Cascader: clearable=true multiple=false type="menu"
标签为“单选”，下拉框内显示“请选择”，右侧有向下箭头图标，文字为深灰色，背景为白色，边框为浅灰色。

### Cascader: clearable=true multiple=true type="menu"
标签为“多选”，下拉框内显示“请选择”，右侧有向下箭头图标，文字为深灰色，背景为白色，边框为浅灰色。

### 交互后视觉特征
交互后展示三级菜单结构，包含“北京市”、“上海市”、“广东省”等选项，文字为深灰色，右侧有向右箭头图标，背景为白色。

## 实现代码
```jsx
import React from "react";
import { Cascader, Form } from "@tencent/tea-component";

const data = [
  {
    label: "北京市",
    value: "bj",
    children: [
      { label: "朝阳区", value: "cy" },
      { label: "海淀区", value: "hd" },
    ],
  },
  {
    label: "上海市",
    value: "sh",
    children: [
      { label: "徐汇区", value: "xh" },
      { label: "黄埔区", value: "hp" },
    ],
  },
  {
    label: "广东省",
    value: "gd",
    children: [
      {
        label: "深圳市",
        value: "sz",
        children: [
          { label: "南山区", value: "ns" },
          { label: "宝安区", value: "ba" },
          { label: "福田区", value: "ft", disabled: true },
        ],
      },
    ],
  },
];

export default function CascaderExample() {
  return (
    <Form>
      <Form.Item label="单选">
        <Cascader
          clearable
          type="menu"
          data={data}
          multiple={false}
          onChange={(value, { options }) => console.log(value, options)}
        />
      </Form.Item>
      <Form.Item label="多选">
        <Cascader
          multiple
          clearable
          type="menu"
          data={data}
          onChange={(value, { options }) => console.log(value, options)}
        />
      </Form.Item>
    </Form>
  );
}
```
