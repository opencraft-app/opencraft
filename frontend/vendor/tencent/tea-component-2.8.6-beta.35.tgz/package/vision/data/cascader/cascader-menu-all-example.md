# Cascader - CascaderMenuAllExample

## 组件
Cascader

## 示例描述
CascaderMenuAllExample

## 视觉特征
### 整体
这是一个基于腾讯云 TDesign 的 Cascader 组件菜单示例，采用简洁的白色背景和灰色边框设计，文字为深灰色，图标为蓝色，整体风格现代且清晰。

### Cascader: all=true clearable=true multiple=true type="menu"
背景为白色，边框为浅灰色，文字为深灰色。包含“单选”、“多选”选项，以及“请选择”占位符文本。右侧有蓝色信息图标，图标内为白色字母“i”。

### 交互后视觉特征
交互后展示级联选择面板：
- 触发元素下方出现多列选择面板
- 每列显示一级选项
- 选中某项后，右侧显示下一级选项
- 支持多选和单选模式
- 支持搜索功能

## 实现代码
```jsx
import React from "react";
import { Cascader, Form } from "@tencent/tea-component";

const data = [
  {
    label: "北京市",
    value: "bj",
    children: [
      { label: "朝阳区", value: "cy" },
      { label: "海淀区", value: "hd" },
    ],
  },
  {
    label: "上海市",
    value: "sh",
    children: [
      { label: "徐汇区", value: "xh" },
      { label: "黄埔区", value: "hp" },
    ],
  },
  {
    label: "广东省",
    value: "gd",
    children: [
      {
        label: "深圳市",
        value: "sz",
        children: [
          { label: "南山区", value: "ns" },
          { label: "宝安区", value: "ba" },
          { label: "福田区", value: "ft" },
        ],
      },
    ],
  },
];

export default function CascaderAllExample() {
  return (
    <Cascader
      all
      multiple
      clearable
      type="menu"
      data={data}
      onChange={(value, { options }) => console.log(value, options)}
    />
  );
}
```
