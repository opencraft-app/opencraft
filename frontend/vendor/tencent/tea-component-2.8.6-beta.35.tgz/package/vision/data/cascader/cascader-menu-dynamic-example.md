# Cascader - CascaderMenuDynamicExample

## 组件
Cascader

## 示例描述
CascaderMenuDynamicExample

## 视觉特征
### 整体
这是一个简洁的级联选择器菜单，采用白色背景和灰色边框，文字为深灰色，图标为黑色向下箭头，整体风格现代且功能明确。

### Cascader: multiple=false type="menu"
白色背景，浅灰色边框，文字为深灰色，显示“请选择”；右侧有黑色向下箭头图标，尺寸适中，呈标准三角形。

### 交互后视觉特征
交互后显示“选项 0”，文字为深灰色，背景为白色，右侧有黑色向右箭头图标，尺寸与初始状态一致。

## 实现代码
```jsx
import React, { useState } from "react";
import { Cascader } from "@tencent/tea-component";

function update(data, valueList, options) {
  if (!data) {
    return options;
  }

  let current = data;
  valueList.forEach(value => {
    const option = current.find(option => option.value === value);
    if (option && option.children) {
      current = option.children;
    } else {
      option.children = options;
    }
  });

  return [...data];
}

export default function CascaderDynamicExample() {
  const [data, setData] = useState();

  function onLoad(value, options) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // 模拟失败
        if (Math.random() > 0.85) {
          reject(new Error("Load Error"));
          return;
        }

        const option = options[options.length - 1];
        setData(
          update(
            data,
            value,
            Array(Math.ceil(Math.random() * 12))
              .fill(0)
              .map((_, i) => ({
                label: `选项 ${i}`,
                value: !option ? `${i}` : `${option.value}-${i}`,
                isLeaf: options.length >= 2,
              }))
          )
        );
        resolve();
      }, 800);
    });
  }

  return (
    <Cascader
      data={data}
      type="menu"
      multiple={false}
      onChange={(value, { options }) => console.log(value, options)}
      onLoad={onLoad}
    />
  );
}
```
