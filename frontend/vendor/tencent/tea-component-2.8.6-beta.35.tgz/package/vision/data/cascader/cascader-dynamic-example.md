# Cascader - CascaderDynamicExample

## 组件
Cascader

## 示例描述
CascaderDynamicExample

## 视觉特征
### 整体
该 UI 组件为级联选择器，采用简洁的白色背景和灰色边框设计，文字为深灰色，图标为深灰色向下箭头，整体风格现代且功能明确。

### Cascader: mode='single'
白色背景，浅灰色边框，文字为深灰色'请选择'，右侧有深灰色向下箭头图标，尺寸为标准高度。

### Cascader: mode='multiple'
白色背景，浅灰色边框，文字为深灰色'请选择'，右侧有深灰色向下箭头图标，尺寸为标准高度。

### 交互后视觉特征
交互后显示两列内容，左侧为'M1'，右侧为'M2'，均为深灰色文字，背景为白色，无边框或图标。

## 实现代码
```jsx
import React, { useState } from "react";
import { Cascader } from "@tencent/tea-component";

function update(data, valueList, options) {
  let current = data;
  valueList.forEach(value => {
    const option = current.options.find(option => option.value === value);
    if (option && option.child) {
      current = option.child;
    }
  });
  current.options = options;
  return { ...data };
}

export default function CascaderDynamicExample() {
  const [data, setData] = useState({
    title: "标题 1",
  });

  function onLoad(value, options) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // 模拟失败
        if (Math.random() > 0.85) {
          reject(new Error("Load Error"));
          return;
        }

        const option = options[options.length - 1];
        setData(
          update(
            data,
            value,
            Array(Math.ceil(Math.random() * 12))
              .fill(0)
              .map((_, i) => ({
                label: `选项 ${i}`,
                value: !option ? `${i}` : `${option.value}-${i}`,
                child:
                  options.length >= 2
                    ? null
                    : { title: `标题 ${options.length + 2}` },
              }))
          )
        );
        resolve();
      }, 800);
    });
  }

  return (
    <Cascader
      data={data}
      onChange={(value, { options }) => console.log(value, options)}
      onLoad={onLoad}
    />
  );
}
```
