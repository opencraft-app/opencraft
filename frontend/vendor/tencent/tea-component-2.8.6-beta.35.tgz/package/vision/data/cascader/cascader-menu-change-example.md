# Cascader - CascaderMenuExample

## 组件
Cascader

## 示例描述
CascaderMenuExample

## 视觉特征
### 整体
这是一个简洁的级联选择器菜单，采用白色背景和灰色边框，文字为深灰色，图标为黑色向下箭头，整体风格现代且功能明确。

### Cascader: changeOnSelect=true multiple=false type="menu"
白色背景，浅灰色边框，文字为深灰色，图标为黑色向下箭头，尺寸适中，形状为矩形。

### 交互后视觉特征
交互后显示三级菜单项：全选、北京市、上海市、广东省，均为深灰色文字，右侧有黑色向右箭头图标，背景为白色，边框为浅灰色。

## 实现代码
```jsx
import React from "react";
import { Cascader } from "@tencent/tea-component";

const data = [
  {
    label: "北京市",
    value: "bj",
    children: [
      { label: "朝阳区", value: "cy" },
      { label: "海淀区", value: "hd" },
    ],
  },
  {
    label: "上海市",
    value: "sh",
    children: [
      { label: "徐汇区", value: "xh" },
      { label: "黄埔区", value: "hp" },
    ],
  },
  {
    label: "广东省",
    value: "gd",
    children: [
      {
        label: "深圳市",
        value: "sz",
        children: [
          { label: "南山区", value: "ns" },
          { label: "宝安区", value: "ba" },
        ],
      },
    ],
  },
];

export default function CascaderExample() {
  return (
    <Cascader
      changeOnSelect
      type="menu"
      data={data}
      multiple={false}
      onChange={(value, { options }) => console.log(value, options)}
    />
  );
}
```
