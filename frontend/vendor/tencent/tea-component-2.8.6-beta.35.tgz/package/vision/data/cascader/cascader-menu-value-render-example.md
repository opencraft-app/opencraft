# Cascader - CascaderMenuValueRenderExample

## 组件
Cascader

## 示例描述
CascaderMenuValueRenderExample

## 视觉特征
### 整体
整体布局为两行，上行为模式选择，下行为 Cascader 组件。设计风格简洁，使用蓝色高亮选中项，文字为深灰色，背景为白色。

### Cascader: clearable=true multiple=false type="menu"
单选模式，显示为下拉选择框，文字为“请选择”，右侧有下拉箭头，文字颜色为深灰色。

### Cascader: clearable=true multiple=true type="menu"
多选模式，显示为下拉选择框，文字为“请选择”，右侧有下拉箭头，文字颜色为深灰色。

### 交互后视觉特征
交互后展开为级联菜单，显示“全部”、“北京市”、“上海市”、“广东省”等选项，文字为深灰色，无特殊颜色或图标。

## 实现代码
```jsx
import React from "react";
import { Cascader, Form } from "@tencent/tea-component";

const data = [
  {
    label: "北京市",
    value: "bj",
    children: [
      { label: "朝阳区", value: "cy" },
      { label: "海淀区", value: "hd" },
    ],
  },
  {
    label: "上海市",
    value: "sh",
    children: [
      { label: "徐汇区", value: "xh" },
      { label: "黄埔区", value: "hp" },
    ],
  },
  {
    label: "广东省",
    value: "gd",
    children: [
      {
        label: "深圳市",
        value: "sz",
        children: [
          { label: "南山区", value: "ns" },
          { label: "宝安区", value: "ba" },
          { label: "福田区", value: "ft" },
        ],
      },
    ],
  },
];

export default function CascaderExample() {
  return (
    <Form>
      <Form.Item label="单选">
        <Cascader
          clearable
          type="menu"
          data={data}
          multiple={false}
          onChange={(value, { options }) => console.log(value, options)}
          valueRender={options => {
            const leaf = options[options.length - 1];
            return leaf?.label || leaf?.value;
          }}
        />
      </Form.Item>
      <Form.Item label="多选">
        <Cascader
          multiple
          clearable
          type="menu"
          data={data}
          onChange={(value, { options }) => console.log(value, options)}
          valueRender={options =>
            options.map(({ label, value }) => label || value).join(" / ")
          }
        />
      </Form.Item>
    </Form>
  );
}
```
