# Cascader - CascaderMenuSearchExample

## 组件
Cascader

## 示例描述
CascaderMenuSearchExample

## 视觉特征
### 整体
整体采用简洁的表单布局，包含两个Cascader菜单组件，设计风格统一，以灰色文字和深色图标为主，视觉清晰。

### Cascader: clearable=true multiple=false searchable=true type="menu"
单选模式，显示“请选择”占位符，右侧有深色下拉箭头图标，文字为灰色。

### Cascader: clearable=true multiple=true searchable=true type="menu"
多选模式，显示“请选择”占位符，右侧有深色下拉箭头图标，文字为灰色。

### 交互后视觉特征
展开后显示三级菜单，包含“北京市”、“上海市”、“广东省”等选项，文字为深灰色，右侧有深色右箭头图标。

## 实现代码
```jsx
import React from "react";
import { Cascader, Form } from "@tencent/tea-component";

const data = [
  {
    label: "北京市",
    value: "bj",
    children: [
      { label: "朝阳区", value: "cy" },
      { label: "海淀区", value: "hd" },
    ],
  },
  {
    label: "上海市",
    value: "sh",
    children: [
      { label: "徐汇区", value: "xh" },
      { label: "黄埔区", value: "hp" },
    ],
  },
  {
    label: "广东省",
    value: "gd",
    children: [
      {
        label: "深圳市",
        value: "sz",
        children: [
          { label: "南山区", value: "ns" },
          { label: "宝安区", value: "ba" },
        ],
      },
    ],
  },
];

export default function CascaderExample() {
  return (
    <Form>
      <Form.Item label="单选">
        <Cascader
          clearable
          searchable
          type="menu"
          data={data}
          multiple={false}
          onChange={(value, { options }) => console.log(value, options)}
        />
      </Form.Item>
      <Form.Item label="多选">
        <Cascader
          multiple
          clearable
          searchable
          type="menu"
          data={data}
          onChange={(value, { options }) => console.log(value, options)}
        />
      </Form.Item>
    </Form>
  );
}
```
