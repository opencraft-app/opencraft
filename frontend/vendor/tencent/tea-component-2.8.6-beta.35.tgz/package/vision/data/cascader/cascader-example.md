# Cascader - CascaderExample

## 组件
Cascader

## 示例描述
CascaderExample

## 视觉特征
### 整体
整体布局为两行表单项，包含单选和多选 Cascader 组件，设计风格简洁，使用标准输入框和下拉箭头图标。

### Form.Item: label="单选"
标签为“单选”，后接一个带有“请选择”占位符的 Cascader 输入框，输入框内无内容，右侧有下拉箭头图标。

### Form.Item: label="多选"
标签为“多选”，后接一个带有“请选择”占位符的 Cascader 输入框，输入框内无内容，右侧有下拉箭头图标。

### Cascader: clearable=true
Cascader 组件带有清除按钮，输入框内显示“请选择”占位符，右侧有下拉箭头图标。

### Cascader: clearable=true multiple=true
Cascader 组件带有清除按钮，支持多选，输入框内显示“请选择”占位符，右侧有下拉箭头图标。

### 交互后视觉特征
交互后展示下拉菜单，包含“Module”标题和“M1”、“M2”两个选项，文字为黑色，背景为白色。

## 实现代码
```jsx
import React from "react";
import { Cascader, Form } from "@tencent/tea-component";

const data = {
  title: "Module",
  options: [
    {
      label: "M1",
      value: "M1",
      child: {
        title: "专区",
        col: 2,
        options: [
          {
            label: "191320",
            value: "191320",
            child: {
              title: "SET & 转发协议",
              col: 1,
              options: [
                {
                  label: "联通-IP-企业CAD-SET-1 电信/4层(TCP)",
                  value: "SET-1",
                },
                {
                  label: "联通-IP-企业CAD-SET-2 电信/4层(TCP)",
                  value: "SET-2",
                },
                {
                  label: "联通-IP-企业CAD-SET-3 电信/4层(TCP)",
                  value: "SET-3",
                },
                {
                  label: "联通-IP-企业CAD-SET-4 电信/4层(TCP)",
                  value: "SET-4",
                },
                {
                  label: "联通-IP-企业CAD-SET-5 电信/4层(TCP)",
                  value: "SET-5",
                },
                {
                  label: "联通-IP-企业CAD-SET-6 电信/4层(TCP)",
                  value: "SET-6",
                },
                {
                  label: "联通-IP-企业CAD-SET-7 电信/4层(TCP)",
                  value: "SET-7",
                },
                {
                  label: "联通-IP-企业CAD-SET-8 电信/4层(TCP)",
                  value: "SET-8",
                },
                {
                  label: "联通-IP-企业CAD-SET-9 电信/4层(TCP)",
                  value: "SET-9",
                },
                {
                  label: "联通-IP-企业CAD-SET-10 电信/4层(TCP)",
                  value: "SET-10",
                },
                {
                  label: "联通-IP-企业CAD-SET-11 电信/4层(TCP)",
                  value: "SET-11",
                },
              ],
            },
          },
          {
            label: "191321",
            value: "191321",
            child: {
              title: "SET & 转发协议",
              col: 1,
              options: [
                {
                  label: "联通-IP-企业CAD-SET-1 电信/4层(TCP)",
                  value: "SET-1",
                },
                {
                  label: "联通-IP-企业CAD-SET-2 电信/4层(TCP)",
                  value: "SET-2",
                },
              ],
            },
          },
        ],
      },
    },
    {
      label: "M2",
      value: "M2",
      child: {
        title: "专区",
        col: 2,
        options: [
          {
            label: "191322",
            value: "191322",
            child: {
              title: "SET & 转发协议",
              col: 1,
              options: [
                {
                  label: "联通-IP-企业CAD-SET-1 电信/4层(TCP)",
                  value: "SET-1",
                },
                {
                  label: "联通-IP-企业CAD-SET-2 电信/4层(TCP)",
                  value: "SET-2",
                },
                {
                  label: "联通-IP-企业CAD-SET-3 电信/4层(TCP)",
                  value: "SET-3",
                },
              ],
            },
          },
        ],
      },
    },
  ],
};

export default function CascaderExample() {
  return (
    <Form>
      <Form.Item label="单选">
        <Cascader
          clearable
          data={data}
          onChange={(value, { options }) => console.log(value, options)}
        />
      </Form.Item>
      <Form.Item label="多选">
        <Cascader
          multiple
          clearable
          data={data}
          onChange={(value, { options }) => console.log(value, options)}
        />
      </Form.Item>
    </Form>
  );
}
```
