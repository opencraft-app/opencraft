# Cascader - CascaderMenuModeExample

## 组件
Cascader

## 示例描述
CascaderMenuModeExample

## 视觉特征
### 整体
整体布局为两列式表单，左侧为标签，右侧为组件。核心交互元素是下拉菜单。采用浅色背景和深色文字，视觉风格简洁现代。

### Form.Item: label="值模式"
标签文字为深灰色，内容区域为浅灰色背景的输入框，右侧有深灰色下拉箭头图标。

### Form.Item: label="展示格式"
标签文字为深灰色，内容区域为浅灰色背景的输入框，右侧有深灰色下拉箭头图标。

### Form.Item: label="多选"
标签文字为深灰色，内容区域为浅灰色背景的输入框，右侧有深灰色下拉箭头图标。

### Cascader: clearable=true multiple=true type="menu"
组件为下拉菜单，显示“请选择”占位符，右侧有深灰色箭头图标，整体为圆角矩形。

### 交互后视觉特征
交互后显示三级菜单，包含“北京市”、“上海市”、“广东省”等选项，文字为深灰色，右侧有深灰色箭头图标。

## 实现代码
```jsx
import React, { useState } from "react";
import { Cascader, Segment, Form } from "@tencent/tea-component";

const data = [
  {
    label: "北京市",
    value: "bj",
    children: [
      { label: "朝阳区", value: "cy" },
      { label: "海淀区", value: "hd" },
    ],
  },
  {
    label: "上海市",
    value: "sh",
    children: [
      { label: "徐汇区", value: "xh" },
      { label: "黄埔区", value: "hp" },
    ],
  },
  {
    label: "广东省",
    value: "gd",
    children: [
      {
        label: "广州市",
        value: "gz",
      },
      {
        label: "深圳市",
        value: "sz",
        children: [
          { label: "南山区", value: "ns" },
          { label: "宝安区", value: "ba" },
          { label: "福田区", value: "ft" },
        ],
      },
    ],
  },
];

export default function CascaderAllExample() {
  const [valueMode, setValueMode] = useState("onlyLeaf");
  const [showMode, setShowMode] = useState("onlyLeaf");
  return (
    <Form>
      <Form.Item label="值模式">
        <Segment
          options={[
            { value: "all" },
            { value: "onlyLeaf" },
            { value: "parentFirst" },
          ]}
          value={valueMode}
          onChange={mode => setValueMode(mode)}
        />
      </Form.Item>
      <Form.Item label="展示格式">
        <Segment
          options={[{ value: "onlyLeaf" }, { value: "parentFirst" }]}
          value={showMode}
          onChange={mode => setShowMode(mode)}
        />
      </Form.Item>
      <Form.Item label="多选">
        <Cascader
          multiple
          clearable
          type="menu"
          data={data}
          all={{ label: "全部", value: "all" }}
          valueMode={valueMode}
          showMode={showMode}
          onChange={(value, { options }) => {
            console.log(value, options);
          }}
        />
      </Form.Item>
    </Form>
  );
}
```
