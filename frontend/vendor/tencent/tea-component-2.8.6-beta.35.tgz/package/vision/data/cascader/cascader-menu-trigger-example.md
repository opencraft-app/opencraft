# Cascader - CascaderMenuTriggerExample

## 组件
Cascader

## 示例描述
CascaderMenuTriggerExample

## 视觉特征
### 整体
整体布局为两组垂直排列的表单控件，采用简洁的白色背景和灰色边框，文字为深灰色，视觉风格统一。

### Cascader: clearable=true expandTrigger="hover" multiple=false searchable=true type="menu"
标签为“单选”，输入框内显示“请选择”，右侧有向下的选择图标，文字为深灰色，图标为深灰色。

### Cascader: clearable=true expandTrigger="hover" multiple=true searchable=true type="menu"
标签为“多选”，输入框内显示“请选择”，右侧有向下的选择图标，文字为深灰色，图标为深灰色。

### 交互后视觉特征
交互后展示三级菜单，包含“北京市”、“上海市”、“广东省”等选项，文字为深灰色，右侧有向右的箭头图标。

## 实现代码
```jsx
import React from "react";
import { Cascader, Form } from "@tencent/tea-component";

const data = [
  {
    label: "北京市",
    value: "bj",
    children: [
      { label: "朝阳区", value: "cy" },
      { label: "海淀区", value: "hd" },
    ],
  },
  {
    label: "上海市",
    value: "sh",
    children: [
      { label: "徐汇区", value: "xh" },
      { label: "黄埔区", value: "hp" },
    ],
  },
  {
    label: "广东省",
    value: "gd",
    children: [
      {
        label: "深圳市",
        value: "sz",
        children: [
          { label: "南山区", value: "ns" },
          { label: "宝安区", value: "ba" },
        ],
      },
    ],
  },
];

export default function CascaderExample() {
  return (
    <Form>
      <Form.Item label="单选">
        <Cascader
          expandTrigger="hover"
          type="menu"
          clearable
          searchable
          data={data}
          onChange={(value, { options }) => console.log(value, options)}
          multiple={false}
        />
      </Form.Item>
      <Form.Item label="多选">
        <Cascader
          expandTrigger="hover"
          type="menu"
          multiple
          clearable
          searchable
          data={data}
          onChange={(value, { options }) => console.log(value, options)}
        />
      </Form.Item>
    </Form>
  );
}
```
