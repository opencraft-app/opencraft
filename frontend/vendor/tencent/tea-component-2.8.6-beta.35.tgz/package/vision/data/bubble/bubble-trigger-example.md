# Bubble - BubbleTriggerExample

## 组件
Bubble

## 示例描述
BubbleTriggerExample

## 视觉特征
### 整体
该 UI 组件采用中心内容区与环绕式气泡提示的布局，整体风格简洁，气泡提示以白色背景和灰色边框为主，文字为黑色，呈现统一的视觉风格。

### Bubble: content="我是被点了之后才出现的内容" trigger="click"
气泡内容为黑色文字，背景为白色，边框为灰色，通过点击触发，文字内容明确，无特殊颜色或图标。

### Bubble: placement="right" trigger="focus"
气泡内容为黑色文字，背景为白色，边框为灰色，通过聚焦触发，位置在右侧，文字内容与前一变体一致。

### Input: placeholder="聚焦出现"
输入框内显示灰色占位符文字“聚焦出现”，文字颜色为灰色，无边框或背景色变化，仅作为提示文本。

## 实现代码
```jsx
import React, { useState } from "react";
import { Bubble, Button, Input } from "@tencent/tea-component";

export default function BubbleTriggerExample() {
  const [inputText, setInputText] = useState("");
  const length = parseInt(inputText, 10);

  const inputError = Boolean(inputText) && Number.isNaN(length);

  const content = length
    ? `面积 S = ${length} x ${length} = ${length * length}`
    : "请输入边长，计算正方形面积";

  return (
    <>
      <section>
        <Bubble trigger="click" content="我是被点了之后才出现的内容">
          <Button>点击出现</Button>
        </Bubble>
      </section>
      <section>
        <Bubble
          trigger="focus"
          content={inputError ? "输入有误，请输入整数" : content}
          placement="right"
          error={inputError}
        >
          <Input
            placeholder="聚焦出现"
            value={inputText}
            onChange={value => setInputText(value)}
          />
        </Bubble>
      </section>
    </>
  );
}
```
