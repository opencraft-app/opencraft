# Bubble - BubbleExample

## 组件
Bubble

## 示例描述
BubbleExample

## 视觉特征
### 整体
该组件采用左右分栏布局，左侧为文本标签，右侧为交互控件。整体风格简洁，以浅灰色背景和深灰色文字为主，通过禁用状态和信息提示增强可用性。

### Text: theme="label" verticalAlign="middle"
深灰色文本，用于标签，文字内容为“为图标添加解释：”

### Text: verticalAlign="middle"
深灰色文本，用于标签，文字内容为“为按钮添加解释：”

### Bubble: arrowPointAtCenter=true content="此域名是加速域名 CNAME 到 CDN 节点上的地址" placement="top-end"
白色气泡框，包含深灰色文字，箭头指向中心，用于提示域名信息

### Bubble: content="请选择你要删除的云主机"
白色气泡框，包含深灰色文字，用于提示用户选择云主机

### Button: disabled=true type="text"
浅灰色背景，文字为深灰色，显示“删除”按钮，处于禁用状态

## 实现代码
```jsx
import React from "react";
import {
  Bubble,
  Icon,
  Button,
  Text,
  Input,
  Select,
} from "@tencent/tea-component";

export default function BubbleExample() {
  return (
    <>
      <section>
        <Text theme="label" verticalAlign="middle">
          为图标添加解释：
        </Text>
        <Text verticalAlign="middle" style={{ marginRight: 5 }}>
          CNAME
        </Text>
        <Bubble
          arrowPointAtCenter
          placement="top-end"
          content="此域名是加速域名 CNAME 到 CDN 节点上的地址"
        >
          <Icon type="info" />
        </Bubble>
      </section>

      <section>
        <Text theme="label" verticalAlign="middle">
          为按钮添加解释：
        </Text>
        <Bubble content="请选择你要删除的云主机">
          <Button>删除</Button>
        </Bubble>
      </section>

      <section>
        <Text theme="label" verticalAlign="middle">
          为操作添加解释：
        </Text>
        <Bubble content="运行中的主机无法删除">
          <Button type="text" disabled>
            删除
          </Button>
        </Bubble>
      </section>
      <section>
        <Bubble content="当前状态无法编辑">
          <Input disabled />
        </Bubble>
      </section>
      <section>
        <Bubble content="当前状态无法编辑">
          <Select size="m" appearance="button" disabled type="simulate" />
        </Bubble>
      </section>
    </>
  );
}
```
