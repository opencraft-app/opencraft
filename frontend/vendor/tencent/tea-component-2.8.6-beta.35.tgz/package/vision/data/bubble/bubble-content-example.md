# Bubble - BubbleContentExample

## 组件
Bubble

## 示例描述
BubbleContentExample

## 视觉特征
### 整体
这是一个包含两个气泡内容的示例，采用简洁的卡片式布局，背景为浅色，文字清晰，图标位于左侧，整体风格现代且信息明确。

### BubbleContent: error=true
背景为浅红色，边框为深红色，文字内容为“异常提示”，文字颜色为深灰色，左侧有一个红色感叹号图标，尺寸为标准气泡大小。

### BubbleContent: dark=true
背景为深灰色，边框为深灰色，文字内容为“反色提示”，文字颜色为白色，左侧有一个白色信息图标，尺寸为标准气泡大小。

## 实现代码
```jsx
import React from "react";
import { BubbleContent } from "@tencent/tea-component";

export default function BubbleExample() {
  const mr5 = { marginRight: 5 };
  return (
    <div style={{ position: "relative", height: 180 }}>
      <BubbleContent style={mr5}>气泡内容</BubbleContent>
      <BubbleContent style={mr5} error>
        异常提示
      </BubbleContent>
      <BubbleContent style={mr5} dark>
        反色提示
      </BubbleContent>
      <section
        style={{
          display: "block",
          marginTop: 12,
        }}
      >
        <BubbleContent style={mr5}>
          <strong>宽度自适应：</strong>
          科学家们发现太阳急速衰老膨胀，短时间内包括地球在内的整个太阳系都将被太阳所吞没。为了自救，人类提出一个名为“流浪地球”的大胆计划，即倾全球之力在地球表面建造上万座发动机和转向发动机，推动地球离开太阳系。
        </BubbleContent>
      </section>
    </div>
  );
}
```
