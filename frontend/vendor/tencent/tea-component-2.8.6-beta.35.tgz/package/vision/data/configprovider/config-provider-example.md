# Configprovider - ConfigProviderExample

## 组件
Configprovider

## 示例描述
ConfigProviderExample

## 视觉特征
### 整体
整体布局为水平排列的组件示例，包含文本输入框和图标按钮，设计风格简洁现代，以中性色调为主。

## 实现代码
```jsx
/* eslint-disable */
import React from "react";
import { DatePicker, ConfigProvider } from "@tencent/tea-component";

import ja_JP from "@tencent/tea-component/lib/i18n/locale/ja_JP";

export default function ConfigProviderExample() {
  return (
    <ConfigProvider locale={ja_JP}>
      <DatePicker />
    </ConfigProvider>
  );
}
```
