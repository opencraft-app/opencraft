# Copy - Copy

## 组件
Copy

## 示例描述
Copy

## 视觉特征
### 整体
这是一个简洁的复制按钮组件，采用圆角矩形设计，背景为浅灰色，边框为深灰色，内部包含文字和图标，整体风格现代且功能明确。

### Copy: text="测试内容"
背景为浅灰色，边框为深灰色，文字内容为"测试内容"，文字颜色为深灰色，右侧有一个复制图标，图标颜色为深灰色，组件为标准尺寸，形状为圆角矩形。

## 实现代码
```jsx
import React from "react";
import { Copy } from "@tencent/tea-component";

export default function CopyExample() {
  return (
    <Copy text="测试内容">
      <a>复制</a>
    </Copy>
  );
}
```
