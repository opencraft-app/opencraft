# Copy - Copy

## 组件
Copy

## 示例描述
Copy

## 视觉特征
### 整体
这是一个简洁的复制按钮组件，采用白色背景和灰色边框，图标为灰色剪贴板样式，整体设计风格扁平化，无额外装饰。

### Copy: text="测试内容"
白色背景，灰色边框，文字内容为"测试内容"，文字颜色为黑色，图标为灰色剪贴板样式，尺寸较小，呈方形。

## 实现代码
```jsx
import React from "react";
import { Copy } from "@tencent/tea-component";

export default function CopyExample() {
  return <Copy text="测试内容" />;
}
```
