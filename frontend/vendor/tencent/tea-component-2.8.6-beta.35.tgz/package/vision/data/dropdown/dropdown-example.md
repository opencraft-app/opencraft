# Dropdown - Dropdown

## 组件
Dropdown

## 示例描述
Dropdown

## 视觉特征
### 整体
该组件由按钮和下拉菜单构成，按钮区域与菜单区域水平并列。核心交互为点击或悬停触发下拉。整体采用蓝色系配色，按钮有实色填充，菜单背景为白色，文字为深灰色。

### Dropdown: appearance="solidBrand" button="按钮样式" clickClose=false matchButtonWidth=true
实色填充的蓝色按钮，按钮文字为白色，下拉菜单背景为白色，文字为深灰色。

### Dropdown: appearance="button" button="按钮样式" clickClose=false matchButtonWidth=true
带有边框的按钮，按钮文字为深灰色，下拉菜单背景为白色，文字为深灰色。

### Dropdown: appearance="link" button="链接样式" clickClose=false placement="top"
无边框的链接式按钮，按钮文字为深灰色，下拉菜单背景为白色，文字为深灰色，菜单位于按钮上方。

### Dropdown: appearance="filter" button="筛选" clickClose=false
带有边框的按钮，按钮文字为深灰色，下拉菜单背景为白色，文字为深灰色。

### Button: icon="more" type="icon"
一个圆形的图标按钮，内部为三个竖向排列的点，颜色为深灰色。

## 实现代码
```jsx
import React from "react";
import { Dropdown, List, Button } from "@tencent/tea-component";

export default function DropdownExample() {
  const menu = close => (
    <List type="option">
      <List.Item onClick={close}>预付费</List.Item>
      <List.Item onClick={close}>后付费</List.Item>
      <List.SubMenu label="更多">
        <List type="option">
          <List.Item disabled>订阅</List.Item>
          <List.Item onClick={close}>朋友代付</List.Item>
        </List>
      </List.SubMenu>
    </List>
  );

  return (
    <>
      <Dropdown
        disabled
        trigger="hover"
        clickClose={false}
        style={{ marginRight: 10 }}
        button="Hover me"
        onOpen={() => console.log("open")}
        onClose={() => console.log("close")}
      >
        {menu}
      </Dropdown>
      <Dropdown
        clickClose={false}
        style={{ marginRight: 10 }}
        button="按钮样式"
        appearance="solidBrand"
        onOpen={() => console.log("open")}
        onClose={() => console.log("close")}
        matchButtonWidth
      >
        {menu}
      </Dropdown>
      <Dropdown
        clickClose={false}
        style={{ marginRight: 10 }}
        button="按钮样式"
        appearance="button"
        onOpen={() => console.log("open")}
        onClose={() => console.log("close")}
        matchButtonWidth
      >
        {menu}
      </Dropdown>
      <Dropdown
        clickClose={false}
        style={{ marginRight: 10 }}
        button="链接样式"
        appearance="link"
        placement="top"
      >
        {menu}
      </Dropdown>
      <Dropdown
        clickClose={false}
        style={{ marginRight: 10 }}
        button="筛选"
        appearance="filter"
      >
        {menu}
      </Dropdown>
      <Dropdown
        clickClose={false}
        style={{ marginRight: 10 }}
        button={<Button type="icon" icon="more" />}
        appearance="pure"
      >
        {menu}
      </Dropdown>
    </>
  );
}
```
