# Dropdown - DropdownMore

## 组件
Dropdown

## 示例描述
DropdownMore

## 视觉特征
### 整体
整体布局为左右并列的按钮样式下拉框，采用简洁的白色背景和灰色边框，按钮文字为深灰色，下拉箭头为深灰色。核心交互为点击按钮展开选项列表，整体风格现代、功能导向。

### Dropdown: appearance="button" button="按钮样式" clickClose=false matchButtonWidth=true size="m"
中等尺寸的按钮样式下拉框，按钮文字为深灰色，背景为白色，边框为浅灰色，右侧有深灰色下拉箭头。

### Dropdown: appearance="button" button="按钮样式" clickClose=false size="s"
小尺寸的按钮样式下拉框，按钮文字为深灰色，背景为白色，边框为浅灰色，右侧有深灰色下拉箭头。

### SearchBox: simple=true
简洁的搜索框，背景为白色，边框为浅灰色，无额外图标或提示文字。

### List: type="option"
选项列表，背景为白色，文字为深灰色，无图标或特殊装饰。

### StatusTip: status="loading"
加载状态提示，文字为深灰色，背景为白色，无图标或特殊装饰。

## 实现代码
```jsx
import React from "react";
import {
  Dropdown,
  List,
  StatusTip,
  SearchBox,
  Tabs,
  TabPanel,
  Button,
} from "@tencent/tea-component";

const tabs = [
  { id: "1", label: "选项卡一" },
  { id: "2", label: "选项卡二" },
  { id: "3", label: "选项卡三" },
];

export default function DropdownExample() {
  return (
    <>
      <Dropdown
        button="按钮样式"
        size="m"
        appearance="button"
        matchButtonWidth
        clickClose={false}
        footer={<a>底部内容</a>}
      >
        {close => (
          <>
            <SearchBox simple />
            <List type="option">
              <List.StatusTip>
                <StatusTip status="loading" />
              </List.StatusTip>
              <List.Item onClick={close}>列表项一</List.Item>
              <List.Item onClick={close}>列表项二</List.Item>
              <List.Item onClick={close}>列表项三</List.Item>
            </List>
          </>
        )}
      </Dropdown>
      <Dropdown
        button="按钮样式"
        size="s"
        style={{ marginLeft: 10 }}
        appearance="button"
        clickClose={false}
        footer={<div>底部内容</div>}
      >
        {close => (
          <div
            style={{
              height: 220,
              width: 180,
              padding: 16,
              textAlign: "center",
            }}
          >
            弹出内容
          </div>
        )}
      </Dropdown>
    </>
  );
}
```
