# Jumper - JumperExample

## 组件
Jumper

## 示例描述
JumperExample

## 视觉特征
### 整体
整体布局为水平排列，包含文本提示、两个开关控件和分页导航按钮，设计风格简洁现代。

### Switch: label='使用上下箭头'
左侧开关控件，标签为“使用上下箭头”，当前处于关闭状态，背景为浅灰色，滑块为白色。

### Switch: label='无边框样式'
右侧开关控件，标签为“无边框样式”，当前处于关闭状态，背景为浅灰色，滑块为白色，无外边框。

### Pagination: current=1, total=5
分页导航组件，显示“正在查看第 1/5 条记录”，包含左右箭头按钮，当前页为第1页。

## 实现代码
```jsx
import React, { useState } from "react";
import { Jumper, Switch } from "@tencent/tea-component";

export default function JumperExample() {
  const [page, setPage] = useState(1);
  const maxPage = 5;

  let prevDisabled = false;
  let nextDisabled = false;
  let prevTitle = "上一条";
  let nextTitle = "下一条";

  if (page === 1) {
    prevDisabled = true;
    prevTitle = "当前在第一条";
  } else if (page === maxPage) {
    nextDisabled = true;
    nextTitle = "当前在最后一条";
  }

  const jumperProps = {
    prevDisabled,
    nextDisabled,
    prevTitle,
    nextTitle,
    onNext: () => setPage(page + 1),
    onPrev: () => setPage(page - 1),
  };

  const [updown, setUpdown] = useState(false);
  const [noBordered, setNoBordered] = useState(false);

  return (
    <>
      <Jumper
        direction={updown ? "updown" : "leftright"}
        noBordered={noBordered}
        {...jumperProps}
      />
      <p>
        正在查看第 {page}/{maxPage} 条记录
      </p>
      <section>
        <Switch value={updown} onChange={value => setUpdown(value)}>
          使用上下箭头
        </Switch>
        <Switch value={noBordered} onChange={value => setNoBordered(value)}>
          无边框样式
        </Switch>
      </section>
    </>
  );
}
```
