# Modal - 对话框

## 组件
Modal

## 示例描述
对话框

## 视觉特征
### 整体
这是一个基于白色背景的模态对话框，采用简洁的布局。顶部为标题栏，中部为信息展示区，底部为操作按钮区。整体配色以白色为主，按钮使用蓝色和灰色，信息图标为橙色，文字为深灰色。

### Modal.Message: description="详细描述" icon="warning" message="提示消息"
一个包含橙色警告图标、标题“提示消息”和描述“详细描述”的信息区域，文字为深灰色。

### Button: type="primary"
一个蓝色的矩形按钮，文字为“确定”，文字颜色为白色。

### Button: type="weak"
一个白色的矩形按钮，带有灰色边框，文字为“取消”，文字颜色为深灰色。

### Modal: disableCloseIcon=true
一个白色的对话框，右上角没有关闭（×）图标。

### 交互后视觉特征
交互后，对话框中显示了“提示消息”和“详细描述”文本，以及一个橙色的警告图标。

## 实现代码
```jsx
import React, { useState } from "react";
import { Modal, Button } from "@tencent/tea-component";

export default function ModalMessageExample() {
  const [visible, setVisible] = useState(false);

  const open = () => setVisible(true);
  const close = () => setVisible(false);

  return (
    <>
      <Button type="primary" onClick={open}>
        打开 success
      </Button>
      <Modal visible={visible} disableCloseIcon onClose={close}>
        <Modal.Body>
          <Modal.Message
            icon="warning"
            message="提示消息"
            description="详细描述"
          />
        </Modal.Body>
        <Modal.Footer>
          <Button type="primary" onClick={close}>
            确定
          </Button>
          <Button type="weak" onClick={close}>
            取消
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}
```
