# Modal - API 唤起

## 组件
Modal

## 示例描述
API 唤起

## 视觉特征
### 整体
这是一个中等复杂度的模态框组件示例，采用简洁的卡片式布局，主色调为白色背景和灰色边框，按钮使用蓝色强调色，整体风格现代且功能明确。

### Button: type="primary"
蓝色背景的按钮，文字为白色，用于主要操作，如确认删除。

### 交互后视觉特征
交互后弹出一个模态框，标题为“确认删除当前所选实例？”，下方有提示文字说明删除后果，底部有两个按钮：蓝色的“删除”和灰色的“取消”。

## 实现代码
```jsx
import React, { useState } from "react";
import { Button, Modal } from "@tencent/tea-component";

export default function ModalShowExample() {
  return (
    <Button
      type="primary"
      onClick={() => {
        const modal = Modal.show({
          caption: "Modal.show() 打开对话框",
          children: <TimingModal onClose={() => modal.destroy()} />,
          onClose: () => modal.destroy(),
        });
      }}
    >
      打开
    </Button>
  );
}

// eslint-disable-next-line react/prop-types
function TimingModal({ onClose }) {
  const [time, setTime] = useState(new Date().toTimeString());

  return (
    <>
      <Modal.Body>当前时间 {time}</Modal.Body>
      <Modal.Footer>
        <Button
          type="primary"
          onClick={() => setTime(new Date().toTimeString())}
        >
          更新时间
        </Button>
        <Button onClick={onClose}>关闭</Button>
      </Modal.Footer>
    </>
  );
}
```
