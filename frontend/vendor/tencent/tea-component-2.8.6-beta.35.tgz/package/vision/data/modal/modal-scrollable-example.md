# Modal - ModalScrollableExample

## 组件
Modal

## 示例描述
ModalScrollableExample

## 视觉特征
### 整体
这是一个基于模态框的对话框组件，采用白色背景和深色文字，整体布局清晰。顶部为标题栏，中间为可滚动内容区，底部为操作按钮区。核心交互为点击按钮触发模态框，模态框支持滚动以容纳长内容。

### Button: type="primary"
蓝色背景，白色文字，按钮文本为“更新时间”，尺寸中等，用于主要操作。

### Button: type="weak"
白色背景，灰色边框和文字，按钮文本为“关闭”，尺寸中等，用于次要或取消操作。

### Modal: caption="对话框标题" scrollable=true
白色背景的弹窗，标题为“对话框标题”，内容区域可垂直滚动，用于展示长篇信息。

### 交互后视觉特征
交互后，模态框内显示了“Modal.show() 打开对话框”和“当前时间 20:12:14 GMT+0800 (China Standard Time)”等文本信息，内容区域为可滚动状态。

## 实现代码
```jsx
import React, { useState } from "react";
import { Modal, Button } from "@tencent/tea-component";

export default function ModalScrollableExample() {
  const [visible2, setVisible2] = useState(false);

  const open2 = () => setVisible2(true);

  const close2 = () => setVisible2(false);

  return (
    <>
      <Button onClick={open2}>内容区可滚动</Button>
      <Modal
        scrollable
        visible={visible2}
        caption="对话框标题"
        onClose={close2}
      >
        <Modal.Body>
          <div style={{ width: "100%", height: "2000px" }}>
            <span>占位内容</span>
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button type="primary" onClick={close2}>
            确定
          </Button>
          <Button type="weak" onClick={close2}>
            取消
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}
```
