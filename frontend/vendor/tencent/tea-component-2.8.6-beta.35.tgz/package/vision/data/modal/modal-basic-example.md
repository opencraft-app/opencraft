# Modal - 对话框

## 组件
Modal

## 示例描述
对话框

## 视觉特征
### 整体
这是一个标准的模态对话框，采用白色背景和圆角矩形设计。顶部为标题栏，中部为内容区，底部为操作按钮区。整体配色以白色为主，按钮使用蓝色和灰色，视觉清晰，布局规整。

### Modal: caption="对话框标题"
白色背景的对话框，标题为“对话框标题”，文字为深灰色，位于对话框顶部中央。

### Button: type="primary"
蓝色背景的按钮，文字为白色，内容为“确定”，位于对话框底部左侧。

### Button: type="weak"
白色背景、灰色边框的按钮，文字为深灰色，内容为“取消”，位于对话框底部右侧。

### 交互后视觉特征
交互后，对话框中显示了标题“对话框标题”和内容“我是对话框内容”，底部保留了“确定”和“取消”两个按钮。

## 实现代码
```jsx
import React, { useState } from "react";
import { Modal, Button } from "@tencent/tea-component";

export default function ModalBasicExample() {
  const [visible, setVisible] = useState(false);

  const open = () => setVisible(true);
  const close = () => setVisible(false);

  return (
    <>
      <Button type="primary" onClick={open}>
        打开
      </Button>
      <Modal visible={visible} caption="对话框标题" onClose={close}>
        <Modal.Body>我是对话框内容</Modal.Body>
        <Modal.Footer>
          <Button type="primary" onClick={close}>
            确定
          </Button>
          <Button type="weak" onClick={close}>
            取消
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}
```
