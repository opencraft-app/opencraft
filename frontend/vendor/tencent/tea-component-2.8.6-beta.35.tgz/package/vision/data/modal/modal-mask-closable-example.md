# Modal - MaskClosable

## 组件
Modal

## 示例描述
MaskClosable

## 视觉特征
### 整体
整体采用深色半透明蒙层覆盖背景，中央弹出白色对话框。对话框包含标题栏、内容区和底部操作区。核心交互为点击蒙层关闭，配色以深灰背景和白色弹窗为主，按钮使用蓝色。

### Modal: caption="对话框标题" maskClosable=true
白色背景的对话框，标题为“对话框标题”，右上角有关闭图标，整体为圆角矩形。

### Button: type="primary"
蓝色背景的按钮，文字为“打开”，位于对话框底部。

### 交互后视觉特征
交互后弹出一个标题为“小号对话框”的白色模态框，内容区显示“小号 - S”，右上角有关闭图标。

## 实现代码
```jsx
import React, { useState } from "react";
import { Modal, Button, DatePicker } from "@tencent/tea-component";

export default function ModalBasicExample() {
  const [visible, setVisible] = useState(false);

  const open = () => setVisible(true);
  const close = () => setVisible(false);

  return (
    <>
      <Button type="primary" onClick={open}>
        打开
      </Button>
      <Modal
        maskClosable
        visible={visible}
        caption="对话框标题"
        onClose={close}
      >
        <Modal.Body>
          <DatePicker />
        </Modal.Body>
        <Modal.Footer />
      </Modal>
    </>
  );
}
```
