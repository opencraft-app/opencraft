# Modal - 尺寸

## 组件
Modal

## 示例描述
尺寸

## 视觉特征
### 整体
这是一个中等复杂度的 modal 组件尺寸示例，采用简洁的卡片式布局，白色背景搭配深色文字，整体风格现代且功能明确。

### Modal: size: 'small'
显示为一个小型弹窗，标题为“对话框标题”，内容为“按 ESC 不会关闭”，底部有两个按钮，分别为蓝色的“确定”和白色的“取消”。

### 交互后视觉特征
交互后展示一个内容可滚动的 modal，标题为“对话框标题”，内容包含多行文本说明，底部有两个操作按钮。

## 实现代码
```jsx
import React, { Fragment, useState } from "react";
import { Modal, Button } from "@tencent/tea-component";

export default function ModalSizeExample() {
  const [visible, setVisible] = useState({
    s: false,
    m: false,
    l: false,
    xl: false,
    auto: false,
  });

  const open = size => () =>
    setVisible(visible => ({ ...visible, [size]: true }));
  const close = size => () =>
    setVisible(visible => ({ ...visible, [size]: false }));

  const names = {
    s: "小号",
    m: "中号",
    l: "大号",
    xl: "超大号",
    auto: "自动适应",
  };

  return Object.entries(names).map(([size, name]) => (
    <Fragment key={size}>
      <Button onClick={open(size)} style={{ marginRight: 5 }}>
        {name} ({size})
      </Button>
      <Modal
        visible={visible[size]}
        // @ts-ignore
        size={size}
        caption={`${name}对话框`}
        onClose={close(size)}
      >
        <Modal.Body>
          {name} - {size.toUpperCase()}
        </Modal.Body>
      </Modal>
    </Fragment>
  ));
}
```
