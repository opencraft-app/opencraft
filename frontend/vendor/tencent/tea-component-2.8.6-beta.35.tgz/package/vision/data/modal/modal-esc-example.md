# Modal - DisableESC

## 组件
Modal

## 示例描述
DisableESC

## 视觉特征
### 整体
这是一个基于白色背景的模态框，采用简洁的卡片式布局。顶部为标题栏，中间为内容区域，底部为操作按钮区。整体配色以白色和灰色为主，按钮使用蓝色和灰色，视觉清晰，交互明确。

### Button: type="primary"
蓝色背景的矩形按钮，文字为白色，内容为“打开”。

### Button: type="weak"
灰色背景的矩形按钮，文字为深灰色，内容为“查看代码”。

### Modal: caption="对话框标题" disableEscape=true
白色背景的模态框，标题为“对话框标题”，右上角有关闭图标，内容区包含一个日期选择器。

### 交互后视觉特征
交互后，模态框内显示一个日期选择器组件，标题为“对话框标题”，右上角有关闭图标，整体为白色背景。

## 实现代码
```jsx
import React, { useState } from "react";
import { Modal, Button } from "@tencent/tea-component";

export default function ModalEscExample() {
  const [visible, setVisible] = useState(false);

  const open = () => setVisible(true);
  const close = () => setVisible(false);

  return (
    <>
      <Button onClick={open}>打开</Button>
      <Modal
        disableEscape
        visible={visible}
        caption="对话框标题"
        onClose={close}
      >
        <Modal.Body>按 ESC 不会关闭</Modal.Body>
        <Modal.Footer>
          <Button type="primary" onClick={close}>
            确定
          </Button>
          <Button type="weak" onClick={close}>
            取消
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}
```
