# Overlay - 基本用法

## 组件
Overlay

## 示例描述
基本用法

## 视觉特征
### 整体
整体布局为标题加按钮的简单结构，设计风格简洁，采用标准字体和常规间距。

## 实现代码
```jsx
import React, { useState } from "react";
import { Overlay } from "@tencent/tea-component";

export default function OverlayExample() {
  const [visible, setVisible] = useState(false);
  const open = () => setVisible(true);
  const close = () => setVisible(false);

  return (
    <Overlay
      layers={[
        <Overlay.Layer
          key="layer"
          visible={visible}
          content={
            <div>
              我是浮层内容，<a onClick={close}>关闭</a>
            </div>
          }
        />,
      ]}
    >
      {ref => (
        <a ref={ref} onClick={open}>
          点击弹出浮层
        </a>
      )}
    </Overlay>
  );
}
```
