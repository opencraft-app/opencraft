# Contentview - ContentViewWithTabsExample

## 组件
Contentview

## 示例描述
ContentViewWithTabsExample

## 视觉特征
### 整体
该组件采用顶部标题栏与下方标签页的布局结构，整体风格简洁。标题栏包含返回按钮和标题，标签页区域展示内容。主要使用深色背景和浅色文字，强调对比度。

### ContentView.Header: showBackButton=true title="内容标题"
标题栏左侧为蓝色返回箭头图标，右侧为深灰色标题文字“内容标题”，背景为白色。

### Text: theme="label"
显示为深灰色常规文字，用于标签页标题和内容区域，字体大小适中。

### Tabs: animated=false ceiling=true
水平排列的标签页，当前选中项“基本信息”为深灰色文字并带有蓝色下划线，其他标签页为浅灰色文字。

### ExternalLink: weak=true
右上角“内容帮助”为浅灰色文字，带有帮助图标，表示弱强调的外部链接。

## 实现代码
```jsx
import React from "react";
import {
  Tabs,
  TabPanel,
  ContentView,
  Card,
  Text,
  ExternalLink,
} from "@tencent/tea-component";

export default function ContentViewWithTabsExample() {
  const tabs = [
    { id: "basic", label: "基本信息" },
    { id: "network", label: "弹性网卡" },
    { id: "monitor", label: "监控信息" },
    { id: "sg", label: "安全组", disabled: true },
    { id: "oplog", label: "操作日志" },
  ];

  return (
    <MockLayout>
      <ContentView>
        <ContentView.Header
          showBackButton
          onBackButtonClick={console.log}
          title="内容标题"
          subtitle={
            <>
              说明文字 <Text theme="label">带颜色说明文字</Text>
            </>
          }
          operation={<ExternalLink weak>内容帮助</ExternalLink>}
        />
        <ContentView.Body>
          <Tabs ceiling animated={false} tabs={tabs}>
            <TabPanel id="basic">
              <Card>
                <Card.Body>基本信息</Card.Body>
              </Card>
            </TabPanel>
            <TabPanel id="network">
              <Card>
                <Card.Body>弹性网卡</Card.Body>
              </Card>
            </TabPanel>
            <TabPanel id="monitor">
              <Card>
                <Card.Body>监控信息</Card.Body>
              </Card>
            </TabPanel>
            <TabPanel id="oplog">
              <Card>
                <Card.Body>操作日志</Card.Body>
              </Card>
            </TabPanel>
          </Tabs>
        </ContentView.Body>
      </ContentView>
    </MockLayout>
  );
}

/**
 * 模拟控制台布局，在控制台使用的时候无需这部分，只要保留 ContentView 即可
 */
function MockLayout({ children }) {
  return (
    <div style={{ height: 340, position: "relative" }}>
      <header style={{ height: 40, background: "#262626" }} />
      <div
        className="container"
        style={{
          position: "absolute",
          top: 40,
          right: 0,
          bottom: 0,
          left: 0,
        }}
      >
        <aside
          style={{ float: "left", height: 300, width: 200, background: "#333" }}
        />
        <main
          style={{
            position: "absolute",
            top: 0,
            right: 0,
            bottom: 0,
            left: 200,
          }}
        >
          {children}
        </main>
      </div>
      <div style={{ clear: "left" }} />
    </div>
  );
}
```
