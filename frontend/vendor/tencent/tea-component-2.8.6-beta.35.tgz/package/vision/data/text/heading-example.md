# Text - Heading

## 组件
Text

## 示例描述
Heading

## 视觉特征
### 整体
该组件采用垂直堆叠布局，从上到下依次展示不同级别的标题。核心交互为文本层级展示，整体配色为黑白，视觉风格简洁现代，强调文本的可读性和层级区分。

### text: size=large
文字内容为“一级标题”，字体最大，颜色为黑色，无边框，用于最高层级的标题展示。

### text: size=medium
文字内容为“二级标题”，字体次大，颜色为黑色，用于次级标题，与一级标题形成清晰的层级对比。

### text: size=small
文字内容为“三级标题”，字体较小，颜色为黑色，用于三级标题，保持整体视觉一致性。

### text: size=extra-small
文字内容为“四级标题”，字体更小，颜色为黑色，用于四级标题，进一步细化内容层级。

## 实现代码
```jsx
import React from "react";
import { H1, H2, H3, H4, H5, H6 } from "@tencent/tea-component";

export default function HeadingExample() {
  return (
    <>
      <H1>一级标题</H1>
      <H2>二级标题</H2>
      <H3>三级标题</H3>
      <H4>四级标题</H4>
      <H5>五级标题</H5>
      <H6>六级标题</H6>
    </>
  );
}
```
