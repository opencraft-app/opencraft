# List - ListExample

## 组件
List

## 示例描述
ListExample

## 视觉特征
### 整体
整体布局分为左右两栏，左侧为普通列表和分割线示例，右侧为有序列表和列表嵌套示例。核心交互为列表项的展示与层级嵌套。整体采用浅色背景，文字为深灰色，列表项背景为浅灰色，视觉清晰。

### List: type="bullet"
无序列表，使用黑色圆点作为项目符号，文字为深灰色，内容包括“打开冰箱”、“把大象放到冰箱里”等。

### List: type="number"
有序列表，使用阿拉伯数字作为项目符号，文字为深灰色，内容包括“1. 打开冰箱”、“2. 把大象放到冰箱里”等。

### List: split="divide"
列表项之间有明显水平分割线，文字为深灰色，内容包括“打开冰箱”、“把大象放到冰箱里”等。

### List: split="stripe"
列表项背景交替显示浅灰色和白色，文字为深灰色，内容包括“打开冰箱”、“把大象放到冰箱里”等。

## 实现代码
```jsx
import React from "react";
import { List, Row, Col } from "@tencent/tea-component";

function Title({ children }) {
  return <h4 style={{ margin: "20px 0" }}>{children}</h4>;
}

export default function ListExample() {
  return (
    <>
      <Row>
        <Col>
          <Title>普通列表</Title>
          <List>
            <List.Item>打开冰箱</List.Item>
            <List.Item>把大象放到冰箱里</List.Item>
            <List.Item>关闭冰箱门</List.Item>
          </List>
        </Col>
        <Col>
          <Title>无序列表</Title>
          <List type="bullet">
            <List.Item>打开冰箱</List.Item>
            <List.Item>把大象放到冰箱里</List.Item>
            <List.Item>关闭冰箱门</List.Item>
          </List>
        </Col>
        <Col>
          <Title>有序列表</Title>
          <List type="number">
            <List.Item>打开冰箱</List.Item>
            <List.Item>把大象放到冰箱里</List.Item>
            <List.Item>关闭冰箱门</List.Item>
          </List>
        </Col>
      </Row>
      <Row>
        <Col>
          <Title>分割线</Title>
          <List split="divide">
            <List.Item>打开冰箱</List.Item>
            <List.Item>把大象放到冰箱里</List.Item>
            <List.Item>关闭冰箱门</List.Item>
          </List>
        </Col>
        <Col>
          <Title>分割条纹</Title>
          <List split="stripe">
            <List.Item>打开冰箱</List.Item>
            <List.Item>把大象放到冰箱里</List.Item>
            <List.Item>关闭冰箱门</List.Item>
          </List>
        </Col>
        <Col>
          <Title>列表嵌套</Title>
          <List type="number">
            <List.Item>
              打开冰箱
              <List type="bullet">
                <List.Item>西门子冰箱</List.Item>
                <List.Item>双手打开</List.Item>
              </List>
            </List.Item>
            <List.Item>把大象放到冰箱里</List.Item>
            <List.Item>关闭冰箱门</List.Item>
          </List>
        </Col>
      </Row>
    </>
  );
}
```
