# List - BaseDropdownExample

## 组件
List

## 示例描述
BaseDropdownExample

## 视觉特征
### 整体
该组件采用水平布局，包含多个按钮式下拉菜单和一个气泡提示。整体风格简洁，以中性色为主，通过文字内容和颜色区分功能。核心交互为点击按钮展开菜单或显示说明。

### Dropdown: appearance="button" button="基础单层菜单（限于2-10个以内）" clickClose=false
一个基础按钮，右侧有向下的箭头图标，用于展开包含2-10个选项的单层菜单。

### Dropdown: appearance="button" button="分组菜单（适用于5-15个以内）" clickClose=false
一个基础按钮，右侧有向下的箭头图标，用于展开包含5-15个选项的分组菜单。

### Dropdown: appearance="button" button="层级菜单" clickClose=false
一个基础按钮，右侧有向下的箭头图标，用于展开包含多级子菜单的复杂菜单。

### Bubble: content="请定期重置密码以保证使用的安全性" placement="right"
一个气泡提示框，显示文字“请定期重置密码以保证使用的安全性”，位于触发元素的右侧。

### Text: theme="danger"
一段红色的文字，用于强调危险或重要信息。

## 实现代码
```jsx
import React from "react";
import { List, Dropdown, Bubble, Text } from "@tencent/tea-component";

export default function ListExample() {
  return (
    <div
      style={{
        display: "flex",
        gap: "10px",
      }}
    >
      <section>
        <Dropdown
          button="基础单层菜单（限于2-10个以内）"
          appearance="button"
          clickClose={false}
        >
          {close => (
            <List type="plain">
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>查看详情</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>关机</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>重启</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>升级镜像</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>退换/销毁</List.ItemContent>
                </List.ItemButton>
              </List.Item>
            </List>
          )}
        </Dropdown>
      </section>
      <section>
        <Dropdown
          button="分组菜单（适用于5-15个以内）"
          appearance="button"
          clickClose={false}
        >
          {close => (
            <List type="plain">
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>查看详情</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>关机</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>重启</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>实例自助检测</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.ListDivider />
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>重置密码</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>重装系统</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.ListDivider />
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>制作镜像</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>导入文件</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>升级镜像</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.ListDivider />
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>退换/销毁</List.ItemContent>
                </List.ItemButton>
              </List.Item>
            </List>
          )}
        </Dropdown>
      </section>
      <section>
        <Dropdown button="层级菜单" appearance="button" clickClose={false}>
          {close => (
            <List type="plain">
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>查看详情</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>关机</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.ListDivider />
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>重启</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>实例自助检测</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.ListDivider />
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>重置密码</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>重装系统</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.ListDivider />
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>制作镜像</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.SubMenu label="导入文件">
                <List type="plain">
                  <List.Item>
                    <List.ItemButton>
                      <List.ItemContent>导入本地文件</List.ItemContent>
                    </List.ItemButton>
                  </List.Item>
                  <List.SubMenu label="导入文件">
                    <List type="plain">
                      <List.Item>
                        <List.ItemButton>
                          <List.ItemContent>导入本地文件</List.ItemContent>
                        </List.ItemButton>
                      </List.Item>
                      <List.Item>
                        <List.ItemButton>
                          <List.ItemContent>导入服务器文件</List.ItemContent>
                        </List.ItemButton>
                      </List.Item>
                    </List>
                  </List.SubMenu>
                  <List.Item>
                    <List.ItemButton>
                      <List.ItemContent>导入服务器文件</List.ItemContent>
                    </List.ItemButton>
                  </List.Item>
                </List>
              </List.SubMenu>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>升级镜像</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.ListDivider />
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>退换/销毁</List.ItemContent>
                </List.ItemButton>
              </List.Item>
            </List>
          )}
        </Dropdown>
      </section>
      <section>
        <Dropdown button="气泡说明" appearance="button" clickClose={false}>
          {close => (
            <List type="plain">
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>查看详情</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>关机</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.ListDivider />
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>重启</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>实例自助检测</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.ListDivider />
              <Bubble
                content="请定期重置密码以保证使用的安全性"
                placement="right"
              >
                <List.Item>
                  <List.ItemButton>
                    <List.ItemContent>
                      重置密码<Text theme="danger">(hover me)</Text>
                    </List.ItemContent>
                  </List.ItemButton>
                </List.Item>
              </Bubble>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>重装系统</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.ListDivider />
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>制作镜像</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.SubMenu label="导入文件">
                <List type="plain">
                  <List.Item>
                    <List.ItemButton>
                      <List.ItemContent>导入本地文件</List.ItemContent>
                    </List.ItemButton>
                  </List.Item>
                  <List.Item>
                    <List.ItemButton>
                      <List.ItemContent>导入服务器文件</List.ItemContent>
                    </List.ItemButton>
                  </List.Item>
                </List>
              </List.SubMenu>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>升级镜像</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.ListDivider />
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>退换/销毁</List.ItemContent>
                </List.ItemButton>
              </List.Item>
            </List>
          )}
        </Dropdown>
      </section>
    </div>
  );
}
```
