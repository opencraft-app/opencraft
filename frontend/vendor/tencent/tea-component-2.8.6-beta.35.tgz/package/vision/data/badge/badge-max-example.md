# Badge - BadgeMaxExample

## 组件
Badge

## 示例描述
BadgeMaxExample

## 视觉特征
### 整体
这是一个简洁的徽章组件，采用红色背景和白色文字，右上角带有'99+'的文本，整体设计风格现代且信息明确。

### Badge.Container: content=100 max=99 variant="standard"
红色背景，白色文字，显示'99+'，无边框，无图标，尺寸适中，形状为圆角矩形。

## 实现代码
```jsx
import React from "react";
import { Badge } from "@tencent/tea-component";

export default function BadgeMaxExample() {
  return (
    <div style={{ display: "flex", gap: "8px", flexDirection: "column" }}>
      <Badge.Container variant="standard" content={100} max={99}>
        默认
      </Badge.Container>
    </div>
  );
}
```
