# Badge - BadgeOverlapExample

## 组件
Badge

## 示例描述
BadgeOverlapExample

## 视觉特征
### 整体
该组件展示不同重叠样式的徽章，布局紧凑，采用红底白字设计，突出数量和状态信息。

### Badge.Container: variant="dot"
红色小圆点，无文字内容，表示状态提示。

### Badge.Container: content=99 variant="standard"
红色圆形徽章，内含白色数字“99”，表示数量。

### Badge.Container: overlap="square" variant="dot"
红色小圆点，位于方形元素右上角，无文字内容。

### Badge.Container: content=99 overlap="square" variant="standard"
红色圆形徽章，内含白色数字“99”，位于方形元素右上角。

### Badge.Container: overlap="circular" variant="dot"
红色小圆点，位于圆形元素右上角，无文字内容。

### Badge.Container: content=99 overlap="circular" variant="standard"
红色圆形徽章，内含白色数字“99”，位于圆形元素右上角。

### Avatar: text="T"
蓝色圆形头像，内含白色字母“T”，作为用户标识。

## 实现代码
```jsx
import React from "react";
import { Badge, Avatar } from "@tencent/tea-component";
import { NotificationIcon } from "@tencent/tea-icons-react";

export default function BadgeOverlapExample() {
  return (
    <div style={{ display: "flex", gap: "8px", flexDirection: "column" }}>
      <Badge.Container variant="dot">默认</Badge.Container>
      <Badge.Container variant="standard" content={99}>
        默认
      </Badge.Container>
      <Badge.Container variant="dot" overlap="square">
        <NotificationIcon />
      </Badge.Container>
      <Badge.Container variant="standard" overlap="square" content={99}>
        <NotificationIcon />
      </Badge.Container>
      <Badge.Container variant="dot" overlap="circular">
        <Avatar color={Avatar.Color.Blue} text="T" />
      </Badge.Container>
      <Badge.Container variant="standard" overlap="circular" content={99}>
        <Avatar color={Avatar.Color.Blue} text="T" />
      </Badge.Container>
    </div>
  );
}
```
