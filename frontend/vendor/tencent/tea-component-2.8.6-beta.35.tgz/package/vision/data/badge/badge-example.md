# Badge - BadgeExample

## 组件
Badge

## 示例描述
BadgeExample

## 视觉特征
### 整体
该 UI 组件展示了两个并列的徽章（Badge）示例，左侧为点状徽章，右侧为数字徽章，整体采用简洁的扁平化设计风格。

### Badge.Container: variant="dot"
红色圆形徽章，无文字内容，背景色为红色，无边框，尺寸较小，形状为实心圆点。

### Badge.Container: content=99 variant="standard"
红色圆形徽章，内部显示白色数字“99”，背景色为红色，无边框，尺寸适中，形状为圆形。

## 实现代码
```jsx
import React from "react";
import { Badge } from "@tencent/tea-component";

export default function BadgeExample() {
  return (
    <div style={{ display: "flex", gap: "8px", flexDirection: "column" }}>
      <Badge.Container variant="dot">默认</Badge.Container>
      <Badge.Container variant="standard" content={99}>
        默认
      </Badge.Container>
    </div>
  );
}
```
