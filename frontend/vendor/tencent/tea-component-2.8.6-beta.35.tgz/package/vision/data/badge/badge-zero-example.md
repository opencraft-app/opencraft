# Badge - BadgeZeroExample

## 组件
Badge

## 示例描述
BadgeZeroExample

## 视觉特征
### 整体
该组件为一个带有开关控件的消息提醒区域，整体采用简洁的扁平化设计风格，主要由文字、图标和开关控件构成。

### Badge.Container: content=0 variant="standard"
显示为一个蓝色圆形徽章，内部包含白色数字'0'，徽章位于'消息提醒'文字的右上角。

## 实现代码
```jsx
import React, { useState } from "react";
import { Badge, Switch } from "@tencent/tea-component";

export default function BadgeZeroExample() {
  const [showZero, setShowZero] = useState(true);
  return (
    <div style={{ display: "flex", gap: "16px", flexDirection: "column" }}>
      <Badge.Container variant="standard" content={0} showZero={showZero}>
        消息提醒
      </Badge.Container>
      <Switch value={showZero} onChange={v => setShowZero(v)}>
        是否显示数目为0的徽章
      </Switch>
    </div>
  );
}
```
