# Badge - BadgeInvisibleExample

## 组件
Badge

## 示例描述
BadgeInvisibleExample

## 视觉特征
### 整体
该组件为一个消息提醒的徽章，采用标准样式，显示数字99，位于开关控件左侧，整体风格简洁现代。

### Badge.Container: content=99 variant="standard"
显示数字99的圆形徽章，背景为浅灰色，文字为深灰色，无边框，标准尺寸。

## 实现代码
```jsx
import React, { useState } from "react";
import { Badge, Switch } from "@tencent/tea-component";

export default function BadgeInvisibleExample() {
  const [invisible, setInvisible] = useState(false);
  return (
    <div style={{ display: "flex", gap: "16px", flexDirection: "column" }}>
      <Badge.Container variant="standard" content={99} invisible={invisible}>
        消息提醒
      </Badge.Container>
      <Switch value={invisible} onChange={v => setInvisible(v)}>
        是否隐藏徽章
      </Switch>
    </div>
  );
}
```
