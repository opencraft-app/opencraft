# Space - 方向和对齐

## 组件
Space

## 示例描述
方向和对齐

## 视觉特征
### 整体
该 UI 组件展示了 Space 组件在不同对齐方式下的布局效果，采用简洁的卡片式设计，包含按钮和文本元素，整体风格统一。

### Space: align="start"
两个主按钮和一段文字内容左对齐，按钮为白色背景，文字为黑色，整体布局紧凑。

### Space: align="end"
两个主按钮和一段文字内容右对齐，按钮为白色背景，文字为黑色，整体布局紧凑。

### Space: align="baseline"
两个主按钮和一段文字内容基线对齐，按钮为白色背景，文字为黑色，整体布局紧凑。

## 实现代码
```jsx
import React from "react";
import { Space, Button, Text } from "@tencent/tea-component";

export default function AlignSpace() {
  return (
    <>
      <div
        style={{
          margin: 15,
        }}
      >
        <h4> 默认 </h4>
        <Space>
          <Button>主按钮</Button>
          <Button>主按钮</Button>
          <>纯文字 看对齐</>
          <img src="https://via.placeholder.com/60" alt=""></img>
        </Space>
      </div>
      <div
        style={{
          margin: 15,
        }}
      >
        <h4> start </h4>
        <Space align="start">
          <Button>主按钮</Button>
          <Button>主按钮</Button>
          <>纯文字 看对齐</>
          <img src="https://via.placeholder.com/60" alt=""></img>
        </Space>
      </div>
      <div
        style={{
          margin: 15,
        }}
      >
        <h4> end </h4>
        <Space align="end">
          <Button>主按钮</Button>
          <Button>主按钮</Button>
          <>纯文字 看对齐</>
          <img src="https://via.placeholder.com/60" alt=""></img>
        </Space>
      </div>
      <div
        style={{
          margin: 15,
        }}
      >
        <h4> baseline </h4>
        <Space align="baseline">
          <Button>主按钮</Button>
          <Button>主按钮</Button>
          <>纯文字 看对齐</>
          <img src="https://via.placeholder.com/60" alt=""></img>
        </Space>
      </div>
    </>
  );
}
```
