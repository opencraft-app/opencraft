# Space - 基本用法

## 组件
Space

## 示例描述
基本用法

## 视觉特征
### 整体
整体布局为水平排列的按钮和文本组合，设计风格简洁，采用中性色调，突出内容对齐。

### Button: type='primary'
主按钮，文字为“主按钮”，背景色为蓝色，文字颜色为白色，尺寸为中等，无边框，形状为圆角矩形。

### Button: type='default'
主按钮，文字为“主按钮”，背景色为白色，文字颜色为黑色，尺寸为中等，有灰色边框，形状为圆角矩形。

### Text: align='center'
纯文字，内容为“纯文字 看对齐”，文字颜色为黑色，文本对齐方式为居中。

## 实现代码
```jsx
import React from "react";
import { Space, Button } from "@tencent/tea-component";

export default function BasicSpace() {
  return (
    <Space>
      <Button>主按钮</Button>
      <Button>主按钮</Button>
      <>纯文字 看对齐</>
      <img src="https://via.placeholder.com/60" alt=""></img>
    </Space>
  );
}
```
