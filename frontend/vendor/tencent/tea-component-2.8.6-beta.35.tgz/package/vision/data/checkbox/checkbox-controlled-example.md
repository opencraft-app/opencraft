# Checkbox - 受控组件

## 组件
Checkbox

## 示例描述
受控组件

## 视觉特征
### 整体
整体布局为垂直排列的复选框列表，每个复选框位于文字左侧，采用简洁的线性设计风格。

### Checkbox: display="block"
白色背景，黑色边框，未选中状态，文字为黑色，内容为'预付费'、'后付费'、'订阅模式'、'朋友代付'。

### Checkbox: disabled=true display="block"
灰色背景，灰色边框，未选中状态，文字为灰色，内容为'预付费'、'后付费'、'订阅模式'、'朋友代付'。

### Checkbox: display="block" indeterminate=true
白色背景，黑色边框，半选中状态，文字为黑色，内容为'预付费'、'后付费'、'订阅模式'、'朋友代付'。

### Checkbox: disabled=true display="block" indeterminate=true
灰色背景，灰色边框，半选中状态，文字为灰色，内容为'预付费'、'后付费'、'订阅模式'、'朋友代付'。

## 实现代码
```jsx
import React from "react";
import { Checkbox } from "@tencent/tea-component";

export default function CheckboxControlledExample() {
  return (
    <>
      <Checkbox display="block" value={false}>
        未选中
      </Checkbox>
      <Checkbox display="block" value>
        已选中
      </Checkbox>
      <Checkbox display="block" value={false} disabled>
        禁用未选中
      </Checkbox>
      <Checkbox display="block" value disabled>
        禁用已选中
      </Checkbox>
      <Checkbox display="block" indeterminate>
        半选状态
      </Checkbox>
      <Checkbox display="block" indeterminate disabled>
        半选状态已禁用
      </Checkbox>
    </>
  );
}
```
