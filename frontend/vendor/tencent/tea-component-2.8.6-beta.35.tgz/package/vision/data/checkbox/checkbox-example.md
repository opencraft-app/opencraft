# Checkbox - 基本用法

## 组件
Checkbox

## 示例描述
基本用法

## 视觉特征
### 整体
整体布局为水平排列的三个复选框，设计风格简洁，采用标准字体和中性配色。

### checkbox: label='加辣'
复选框标签为“加辣”，文字颜色为黑色，未选中状态，边框为灰色，内部为空心方框。

### checkbox: label='加麻'
复选框标签为“加麻”，文字颜色为黑色，未选中状态，边框为灰色，内部为空心方框。

### checkbox: label='不要葱花'
复选框标签为“不要葱花”，文字颜色为黑色，未选中状态，边框为灰色，内部为空心方框。

## 实现代码
```jsx
import React, { useState } from "react";
import { Checkbox } from "@tencent/tea-component";

export default function CheckboxExample() {
  const [taste, setTaste] = useState([]);

  return (
    <>
      <p>
        已选中 {taste.length} 个口味要求：{taste.join(", ")}
      </p>
      <section>
        <Checkbox.Group value={taste} onChange={value => setTaste(value)}>
          <Checkbox name="la">加辣</Checkbox>
          <Checkbox name="ma">加麻</Checkbox>
          <Checkbox name="nocong">不要葱花</Checkbox>
        </Checkbox.Group>
      </section>
    </>
  );
}
```
