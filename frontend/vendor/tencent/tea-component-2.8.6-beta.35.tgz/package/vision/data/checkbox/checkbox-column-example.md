# Checkbox - 垂直分布

## 组件
Checkbox

## 示例描述
垂直分布

## 视觉特征
### 整体
垂直排列的复选框组，采用简洁的线性布局，状态通过勾选框和文字颜色区分，整体风格统一。

### Checkbox: tooltip="给了钱再用"
白色背景，未选中状态，文字为黑色，无勾选框，带有提示信息

### Checkbox: tooltip="用了再给钱"
白色背景，未选中状态，文字为黑色，无勾选框，带有提示信息

### Checkbox: tooltip="每个月自动扣钱"
白色背景，未选中状态，文字为黑色，无勾选框，带有提示信息

### Checkbox: disabled=true tooltip="Yomee 帮你给钱"
灰色背景，文字为灰色，勾选框为灰色，表示禁用状态，带有提示信息

## 实现代码
```jsx
import React, { useState } from "react";
import { Checkbox } from "@tencent/tea-component";

export default function CheckboxColumnExample() {
  const [paymode, setPaymode] = useState([]);

  return (
    <>
      <Checkbox.Group
        value={paymode}
        onChange={value => setPaymode(value)}
        layout="column"
      >
        <Checkbox name="prepaid" tooltip="给了钱再用">
          预付费
        </Checkbox>
        <Checkbox name="billing" tooltip="用了再给钱">
          后付费
        </Checkbox>
        <Checkbox name="subscription" tooltip="每个月自动扣钱">
          订阅模式
        </Checkbox>
        <Checkbox name="friend" disabled tooltip="Yomee 帮你给钱">
          朋友代付
        </Checkbox>
      </Checkbox.Group>
    </>
  );
}
```
