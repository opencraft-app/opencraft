# Select - MultiSelect

## 组件
Select

## 示例描述
MultiSelect

## 视觉特征
### 整体
整体布局为垂直排列的表单项，每个表单项包含标签和选择器。核心交互为多选下拉和按钮式选择器。设计风格简洁，以中性色为主，文字颜色为深灰色，按钮为浅灰色背景。

### Form.Item: label="多选"
标签文字为“多选”，字体为深灰色，位于左侧，右侧为下拉选择器。

### Form.Item: label="包含全选"
标签文字为“包含全选”，字体为深灰色，右侧为带有“请选择”文本的下拉选择器。

### Form.Item: label="直接触发改变"
标签文字为“直接触发改变”，字体为深灰色，右侧为带有“请选择”文本的下拉选择器。

### Form.Item: label="自定义按钮内容"
标签文字为“自定义按钮内容”，字体为深灰色，右侧为带有“瓜子”文本的按钮式选择器。

### SelectMultiple: appearance="button" size="s"
按钮式选择器，尺寸较小，背景为浅灰色，文字为深灰色，带有向下箭头图标。

## 实现代码
```jsx
import React from "react";
import { SelectMultiple, Form, Tag, Tooltip } from "@tencent/tea-component";

const options = [
  { value: "gz", text: "瓜子", tooltip: "百煮入味香" },
  {
    value: "hs",
    text: "花生",
    tooltip: "花生已售罄",
    disabled: true,
  },
  { value: "bmf", text: "爆米花", tooltip: "焦糖味" },
  { value: "kl", text: "可乐", tooltip: "肥宅快乐水" },
  { value: "pj", text: "啤酒" },
  { value: "kqs", text: "矿泉水" },
  { value: "bbz", text: "八宝粥" },
];

export default function MultiSelectExample() {
  return (
    <Form>
      <Form.Item label="多选">
        <SelectMultiple options={options} />
      </Form.Item>
      <Form.Item label="包含全选">
        <SelectMultiple
          options={options}
          appearance="button"
          size="s"
          allOption={{
            value: "all",
            text: "全选",
            tooltip: "我都要",
          }}
        />
      </Form.Item>
      <Form.Item label="直接触发改变">
        <SelectMultiple
          options={options}
          staging={false}
          appearance="button"
          allOption={{
            value: "all",
            text: "全选",
            tooltip: "我都要",
          }}
        />
      </Form.Item>
      <Form.Item label="自定义按钮内容">
        <SelectMultiple
          appearance="button"
          defaultValue={["gz"]}
          className="is-unlimited-height"
          options={options}
          button={options =>
            options.length ? (
              <Tooltip title={options.map(o => o.text).join(", ")}>
                <div>
                  <Tag.Group style={{ marginBottom: "4px" }}>
                    {options.map(o => (
                      <Tag key={o.value}>{o.text}</Tag>
                    ))}
                  </Tag.Group>
                </div>
              </Tooltip>
            ) : (
              "请选择"
            )
          }
        />
      </Form.Item>
    </Form>
  );
}
```
