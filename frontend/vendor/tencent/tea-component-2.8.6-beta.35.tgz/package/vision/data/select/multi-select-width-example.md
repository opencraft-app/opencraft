# Select - MultiSelectWidth

## 组件
Select

## 示例描述
MultiSelectWidth

## 视觉特征
### 整体
该 UI 组件为多选下拉选择器，采用按钮式外观，支持不同宽度配置。整体布局为垂直排列的表单项，包含标签、提示文字和选择器控件。

### SelectMultiple: appearance="button" size="m"
按钮式多选，尺寸为中等，下拉箭头图标，文本为“请选择”，提示文字为“默认未开启虚拟滚动，列表自适应宽度”。

### SelectMultiple: appearance="button" size="m" virtual=true
按钮式多选，尺寸为中等，已启用虚拟滚动，下拉箭头图标，文本为“请选择”，提示文字为“启用虚拟滚动后将固定宽度”。

### SelectMultiple: appearance="button" listWidth=360 size="m" virtual=true
按钮式多选，尺寸为中等，已启用虚拟滚动并设置固定宽度为360，下拉箭头图标，文本为“请选择”，提示文字为“设置可容纳较长内容的固定宽度”。

### SelectMultiple: appearance="button" matchButtonWidth=true size="m" virtual=true
按钮式多选，尺寸为中等，已启用虚拟滚动并匹配按钮宽度，下拉箭头图标，文本为“请选择”，提示文字为“视情况启用”。

## 实现代码
```jsx
import React, { useState } from "react";
import { Form, SelectMultiple } from "@tencent/tea-component";

const options = Array.from({ length: 10 }).map((_, i) => ({
  value: `${i}`,
  text: `Tea Component | SelectMultiple | Option - ${i}`,
}));

export default function SelectMultipleExample() {
  const [value, setValue] = useState([]);

  return (
    <Form>
      <Form.Item
        label="默认自适应"
        message="默认未开启虚拟滚动，列表自适应宽度"
      >
        <SelectMultiple
          size="m"
          appearance="button"
          value={value}
          onChange={value => setValue(value)}
          options={options}
        />
      </Form.Item>
      <Form.Item label="启用虚拟滚动" message="启用虚拟滚动后将固定宽度">
        <SelectMultiple
          virtual
          size="m"
          appearance="button"
          value={value}
          onChange={value => setValue(value)}
          options={options}
        />
      </Form.Item>
      <Form.Item label="设置宽度" message="设置可容纳较长内容的固定宽度">
        <SelectMultiple
          virtual
          size="m"
          appearance="button"
          listWidth={360}
          value={value}
          onChange={value => setValue(value)}
          options={options}
        />
      </Form.Item>
      <Form.Item label="按钮同宽" message="视情况启用">
        <SelectMultiple
          virtual
          size="m"
          appearance="button"
          matchButtonWidth
          value={value}
          onChange={value => setValue(value)}
          options={options}
        />
      </Form.Item>
    </Form>
  );
}
```
