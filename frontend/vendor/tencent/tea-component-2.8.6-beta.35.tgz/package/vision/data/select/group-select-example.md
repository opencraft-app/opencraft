# Select - GroupSelect

## 组件
Select

## 示例描述
GroupSelect

## 视觉特征
### 整体
整体布局为垂直堆叠的表单项，包含单选、多选及带分割线的组合。核心交互为下拉选择，采用标准输入框样式，配色以中性灰为主，文字为深灰色，视觉简洁统一。

### Form.Item: label="单选"
标签文字为“单选”，深灰色字体，无特殊样式，位于组件左侧。

### Form.Item: label="分割线"
标签文字为“分割线”，深灰色字体，用于分隔不同功能区域。

### Form.Item: label="多选"
标签文字为“多选”，深灰色字体，表示支持多选功能。

### Form.Item: label="多选分割线"
标签文字为“多选分割线”，深灰色字体，用于分隔多选区域。

### Select: placeholder="请选择你最爱的食品"
输入框内显示灰色占位符文字“请选择你最爱的食品”，右侧有下拉箭头图标。

## 实现代码
```jsx
import React, { useState } from "react";
import { Select, SelectMultiple, Form } from "@tencent/tea-component";

const options = [
  { groupKey: "fruit", value: "strawberry", text: "草莓", tooltip: "甜甜甜" },
  {
    groupKey: "fruit",
    value: "apple",
    text: "苹果",
    disabled: true,
    tooltip: "每日一苹果，医生远离我",
  },
  { groupKey: "fruit", value: "orange", text: "橙子", tooltip: "丰富 VC 含量" },
  { groupKey: "drink", value: "coca-cola", text: "可口可乐" },
  {
    groupKey: "drink",
    value: "pepsi-cola",
    text: "百事可乐",
    tooltip: "百事可乐为什么比可口可乐好喝？",
  },
];

const groups = {
  fruit: "水果",
  drink: "饮料",
};

export default function SelectExample() {
  const [favorite, setFavorite] = useState(null);
  const [favorites, setFavorites] = useState([]);

  return (
    <Form>
      <Form.Item label="单选">
        <Select
          groups={groups}
          options={options}
          value={favorite}
          onChange={value => setFavorite(value)}
          placeholder="请选择你最爱的食品"
        />
      </Form.Item>
      <Form.Item label="分割线">
        <Select
          options={options}
          value={favorite}
          onChange={value => setFavorite(value)}
          placeholder="请选择你最爱的食品"
        />
      </Form.Item>
      <Form.Item label="多选">
        <SelectMultiple
          groups={groups}
          options={options}
          value={favorites}
          onChange={value => setFavorites(value)}
          placeholder="请选择你喜欢的食品"
          allOption={{
            value: "all",
            text: "全选",
            tooltip: "我都要",
          }}
        />
      </Form.Item>
      <Form.Item label="多选分割线">
        <SelectMultiple
          options={options}
          value={favorites}
          onChange={value => setFavorites(value)}
          placeholder="请选择你喜欢的食品"
          allOption={{
            value: "all",
            text: "全选",
            tooltip: "我都要",
          }}
        />
      </Form.Item>
    </Form>
  );
}
```
