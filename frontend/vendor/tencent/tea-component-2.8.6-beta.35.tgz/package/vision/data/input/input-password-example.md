# Input - InputPassword

## 组件
Input

## 示例描述
InputPassword

## 视觉特征
### 整体
整体布局为水平排列的输入框组合，设计风格简洁，采用浅色背景和细边框，文字颜色为深灰色，符合现代表单组件的视觉规范。

## 实现代码
```jsx
import React from "react";
import { Input } from "@tencent/tea-component";

const { Password } = Input;

export default function InputPasswordExample() {
  return (
    <Password onChange={(value, { valid }) => console.log(value, valid)} />
  );
}
```
