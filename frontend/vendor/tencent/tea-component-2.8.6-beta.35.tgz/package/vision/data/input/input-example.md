# Input - Input

## 组件
Input

## 示例描述
Input

## 视觉特征
### 整体
整体布局为垂直排列的输入组件，采用简洁的线性设计风格，以浅灰色边框和文字为主，视觉上清晰易读。

### Input: placeholder="输入文本内容"
单行文本输入框，浅灰色边框，内部显示灰色占位符文字“输入文本内容”，文字颜色为灰色。

### Input: placeholder="输入文本内容"
多行文本输入框，浅灰色边框，内部显示灰色占位符文字“输入文本内容”，文字颜色为灰色，底部显示字符计数“0”。

### Select: placeholder="尺寸" type="simulate"
下拉选择框，显示“尺寸”占位符文字，文字颜色为灰色，右侧有下拉箭头图标，整体为浅灰色边框。

## 实现代码
```jsx
import React, { useState } from "react";
import { Switch, Select, Input } from "@tencent/tea-component";

const { TextArea } = Input;

export default function InputExample() {
  const [size, setSize] = useState(null);
  const [disabled, setDisabled] = useState(false);
  const [readonly, setReadonly] = useState(false);

  const [text, setText] = useState("");

  return (
    <>
      {/* Demo 演示区 */}
      <div>
        <Input
          size={size}
          value={text}
          onChange={(value, context) => {
            setText(value);
            console.log(value, context);
          }}
          placeholder="输入文本内容"
          disabled={disabled}
          readonly={readonly}
          onPressEnter={console.log}
        />
      </div>
      <div style={{ marginTop: 10 }}>
        <TextArea
          showCount
          size={size}
          value={text}
          onChange={(value, context) => {
            setText(value);
            console.log(value, context);
          }}
          placeholder="输入文本内容"
          disabled={disabled}
          readonly={readonly}
          onPressEnter={console.log}
        />
      </div>
      <hr />
      {/* Demo 配置区 */}
      <section>
        <Select
          type="simulate"
          style={{ width: "auto", marginRight: 10 }}
          value={size}
          onChange={value => setSize(value)}
          placeholder="尺寸"
          options={[
            { value: "xs", text: "xs - 极窄" },
            { value: "s", text: "s - 窄" },
            { value: "m", text: "m - 默认" },
            { value: "l", text: "l - 大宽度" },
            { value: "full", text: "full - 全宽" },
          ]}
        />
        <Switch value={disabled} onChange={value => setDisabled(value)}>
          禁用
        </Switch>
        <Switch value={readonly} onChange={value => setReadonly(value)}>
          只读
        </Switch>
      </section>
    </>
  );
}
```
