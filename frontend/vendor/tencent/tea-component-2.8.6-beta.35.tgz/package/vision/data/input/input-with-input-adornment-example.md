# Input - InputWithInputAdornment

## 组件
Input

## 示例描述
InputWithInputAdornment

## 视觉特征
### 整体
白色背景上的输入框，右侧带有一个灰色的清除图标，整体风格简洁现代，采用细边框设计。

### InputWithInputAdornment: InputAdornment: before="www.", Input: size="s"
尺寸为 s 的输入框，左侧显示灰色文字 'www.'，输入区域为白色，边框为浅灰色。

### InputWithInputAdornment: InputAdornment: after=".00" before="$", Input: size="s"
尺寸为 s 的输入框，左侧显示灰色文字 '$'，右侧显示灰色文字 '.00'，输入区域为白色，边框为浅灰色。

## 实现代码
```jsx
import React from "react";
import { InputAdornment, Input } from "@tencent/tea-component";

export default function InputAdornmentExample() {
  return (
    <>
      <section>
        <InputAdornment before="www.">
          <Input />
        </InputAdornment>
      </section>

      <section>
        <InputAdornment before="$" after=".00">
          <Input size="s" />
        </InputAdornment>
      </section>
    </>
  );
}
```
