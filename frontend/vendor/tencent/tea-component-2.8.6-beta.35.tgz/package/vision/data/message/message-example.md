# Message - MessageExample

## 组件
Message

## 示例描述
MessageExample

## 视觉特征
### 整体
这是一个水平排列的 message 组件示例，包含四种状态变体，采用简洁的卡片式设计，背景色和文字颜色区分不同状态。

### Message: type='success'
背景色为浅绿色，边框为绿色，文字内容为'Success'，文字颜色为深绿色，无图标，尺寸为默认大小。

### Message: type='warning'
背景色为浅黄色，边框为橙色，文字内容为'Warning'，文字颜色为深橙色，无图标，尺寸为默认大小。

### Message: type='error'
背景色为浅红色，边框为红色，文字内容为'Error'，文字颜色为深红色，无图标，尺寸为默认大小。

### Message: type='loading'
背景色为浅灰色，边框为灰色，文字内容为'Loading'，文字颜色为深灰色，无图标，尺寸为默认大小。

### 交互后视觉特征
动态展示全局提示：
- 消息条出现在页面顶部居中
- 简短的提示文字，可能带图标
- 支持不同类型：success/error/warning/info/loading
- 自动消失或可手动关闭

## 实现代码
```jsx
import React from "react";
import { message, Button } from "@tencent/tea-component";

export default function NotificationExample() {
  return (
    <>
      <Button
        onClick={() =>
          message.success({
            content: "这是一条成功提示",
          })
        }
      >
        Success
      </Button>
      <Button
        onClick={() =>
          message.warning({
            content: "这是一条警告提示",
          })
        }
      >
        Warning
      </Button>
      <Button
        onClick={() =>
          message.error({
            content: "这是一条异常提示",
          })
        }
      >
        Error
      </Button>
      <Button
        onClick={() =>
          message.loading({
            content: "加载中 ...",
          })
        }
      >
        Loading
      </Button>
    </>
  );
}
```
