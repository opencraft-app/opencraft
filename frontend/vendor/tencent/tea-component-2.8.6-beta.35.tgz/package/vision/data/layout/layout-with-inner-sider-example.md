# Layout - LayoutWithInnerSider

## 组件
Layout

## 示例描述
LayoutWithInnerSider

## 视觉特征
### 整体
左侧为可折叠的深色侧边栏，包含品牌Logo和多级菜单；右侧为内容区域。核心交互为菜单折叠与展开，整体采用深色主题，文字以白色为主，标签使用不同颜色区分状态。

### NavMenu.Item: type="logo"
位于侧边栏顶部的品牌Logo，视觉上为一个图标，无文字内容。

### Menu: collapsable=true icon="https://via.placeholder.com/32.png?text=icon" tag="NEW" theme="dark" title="产品名称"
深色背景的侧边栏菜单，左侧有图标，标题为“产品名称”，并带有“NEW”标签。

### Menu.SubMenu: defaultOpened=true title="一级菜单"
展开状态的菜单项，标题为“一级菜单”，包含多个子菜单项。

### Menu.Item: tag="NEW" title="一级菜单"
菜单项，标题为“一级菜单”，右侧带有“NEW”标签，文字颜色为白色。

### ExternalLink: weak=true
外部链接，文字颜色较浅，表示弱强调，无特殊图标。

## 实现代码
```jsx
import React, { useState } from "react";
import {
  Layout,
  Card,
  Text,
  ExternalLink,
  Menu,
  NavMenu,
} from "@tencent/tea-component";
import { Badge } from "../../badge";

const { Header, Body, Sider, Content } = Layout;

const icon = /** @type {[string, string]} */ ([
  `https://via.placeholder.com/16.png?text=icon`,
  `https://via.placeholder.com/16/006eff/444444`,
]);

export default function LayoutWithInnerSiderExample() {
  const [selected, setSelected] = useState("overview");
  const [subSelected, setSubSelected] = useState("overview");

  const getMenuItemProps = id => ({
    selected: selected === id,
    onClick: () => setSelected(id),
  });

  const getSubMenuItemProps = id => ({
    selected: subSelected === id,
    onClick: () => setSubSelected(id),
  });

  return (
    <Layout className="demo-layout-l">
      <Header>
        <NavMenu
          left={
            <>
              <NavMenu.Item type="logo">
                <img
                  src="https://via.placeholder.com/32.png?text=LOGO"
                  alt="logo"
                />
              </NavMenu.Item>
              <NavMenu.Item>总览</NavMenu.Item>
            </>
          }
        />
      </Header>
      <Body>
        <Sider>
          <Menu
            collapsable
            theme="dark"
            title="产品名称"
            icon="https://via.placeholder.com/32.png?text=icon"
            tag="NEW"
          >
            <Menu.Item
              icon={icon}
              tag="NEW"
              title="一级菜单"
              {...getMenuItemProps("1")}
            />

            <Menu.SubMenu defaultOpened title="一级菜单" icon={icon}>
              <Menu.Item
                tag="NEW"
                title="二级菜单"
                {...getMenuItemProps("2-1")}
              />
              <Menu.Item
                tag={<Badge theme="success">FREE</Badge>}
                title="二级菜单"
                {...getMenuItemProps("2-2")}
              />
            </Menu.SubMenu>

            <Menu.Group title="菜单分组">
              <Menu.SubMenu title="一级菜单" icon={icon}>
                <Menu.Item
                  title="二级菜单"
                  icon={icon}
                  {...getMenuItemProps("3-1")}
                />
                <Menu.Item title="二级菜单" {...getMenuItemProps("3-2")} />
              </Menu.SubMenu>
              <Menu.Item icon={icon} title="外部链接" external />
            </Menu.Group>
          </Menu>
        </Sider>
        <Sider>
          <Menu
            back={{
              title: "产品名称产品名称产品名称产品名称产品名称产品名称",
              tooltip: "产品名称产品名称产品名称产品名称产品名称产品名称",
              onClick: () => console.log("back"),
            }}
          >
            <Menu.Item
              title="一级菜单"
              {...getSubMenuItemProps("s-1")}
              tag="NEW"
            />
            <Menu.SubMenu defaultOpened title="一级菜单">
              <Menu.Item
                title="二级菜单"
                {...getSubMenuItemProps("s-2-1")}
                tag={<Badge theme="success">FREE</Badge>}
              />
              <Menu.Item title="二级菜单" {...getSubMenuItemProps("s-2-2")} />
            </Menu.SubMenu>
          </Menu>
        </Sider>
        <Content>
          <Content.Header
            title="内容标题"
            subtitle={
              <>
                说明文字 <Text theme="label">带颜色说明文字</Text>
              </>
            }
            operation={<ExternalLink weak>内容帮助</ExternalLink>}
          />
          <Content.Body>
            {/* 内容区域一般使用 Card 组件显示内容 */}
            <Card>
              <Card.Body>内容卡片</Card.Body>
            </Card>
          </Content.Body>
        </Content>
      </Body>
    </Layout>
  );
}
```
