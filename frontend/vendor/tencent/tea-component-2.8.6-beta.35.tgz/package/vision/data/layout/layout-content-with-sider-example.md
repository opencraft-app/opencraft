# Layout - LayoutContentWithSider

## 组件
Layout

## 示例描述
LayoutContentWithSider

## 视觉特征
### 整体
这是一个左右分栏的布局组件，左侧为可折叠的侧边栏菜单，右侧为主内容区。采用浅色背景和简洁线条，菜单项支持多级嵌套，整体风格现代、功能导向。

### Menu.Item: title="一级菜单"
文本为黑色，显示在侧边栏菜单中，作为一级菜单项。

### Menu.Item: title="二级菜单"
文本为黑色，缩进显示在一级菜单下，作为二级菜单项。

### Menu.SubMenu: defaultOpened=true title="一级菜单"
文本为黑色，带有可展开箭头图标，当前处于展开状态。

### Text: theme="label"
文本为灰色，用于显示说明性文字。

### ExternalLink: weak=true
文本为灰色，表示弱强调的外部链接。

## 实现代码
```jsx
import React, { useState } from "react";
import { Layout, Card, Text, ExternalLink, Menu } from "@tencent/tea-component";

const { Body, Sider, Content } = Layout;

export default function LayoutContentWithSiderExample() {
  const [selected, setSelected] = useState("overview");

  const getMenuItemProps = id => ({
    selected: selected === id,
    onClick: () => setSelected(id),
  });

  return (
    <Layout className="demo-layout">
      <Body>
        <Sider>
          <Menu
            back={{
              title: "产品名称产品名称产品名称",
              description: "数据测试",
              tooltip: "产品名称产品名称产品名称 - 数据测试勿删",
              onClick: () => console.log("back"),
            }}
          >
            <Menu.Item title="一级菜单" {...getMenuItemProps("1")} />
            <Menu.SubMenu defaultOpened title="一级菜单">
              <Menu.Item title="二级菜单" {...getMenuItemProps("2-1")} />
              <Menu.Item title="二级菜单" {...getMenuItemProps("2-2")} />
            </Menu.SubMenu>
          </Menu>
        </Sider>
        <Content>
          <Content.Header
            title="内容标题"
            subtitle={
              <>
                说明文字 <Text theme="label">带颜色说明文字</Text>
              </>
            }
            operation={<ExternalLink weak>内容帮助</ExternalLink>}
          />
          <Content.Body>
            {/* 内容区域一般使用 Card 组件显示内容 */}
            <Card>
              <Card.Body>内容卡片</Card.Body>
            </Card>
          </Content.Body>
        </Content>
      </Body>
    </Layout>
  );
}
```
