# Layout - LayoutWithoutSider

## 组件
Layout

## 示例描述
LayoutWithoutSider

## 视觉特征
### 整体
这是一个简洁的布局组件，采用顶部导航与内容区域划分。顶部包含返回按钮、标题和帮助入口，内容区为卡片式布局。整体风格现代，以深色导航栏和浅色内容区形成对比，强调信息层级。

### NavMenu.Item: type="logo"
一个位于导航栏左侧的Logo图标，作为导航菜单项，用于品牌标识。

### Text: theme="label"
一个标签文字，内容为“说明文字 带颜色说明文字”，文字颜色为深灰色。

### ExternalLink: weak=true
一个弱样式外部链接，内容为“内容帮助”，文字颜色为深灰色。

## 实现代码
```jsx
import React from "react";
import {
  Layout,
  Card,
  Text,
  ExternalLink,
  NavMenu,
} from "@tencent/tea-component";

const { Header, Body, Content } = Layout;

export default function LayoutExample() {
  return (
    <Layout className="demo-layout-l">
      <Header>
        <NavMenu
          left={
            <>
              <NavMenu.Item type="logo">
                <img
                  src="https://via.placeholder.com/32.png?text=LOGO"
                  alt="logo"
                />
              </NavMenu.Item>
              <NavMenu.Item>总览</NavMenu.Item>
            </>
          }
        />
      </Header>
      <Body>
        <Content>
          <Content.Header
            showBackButton
            onBackButtonClick={console.log}
            title="内容标题"
            subtitle={
              <>
                说明文字 <Text theme="label">带颜色说明文字</Text>
              </>
            }
            operation={<ExternalLink weak>内容帮助</ExternalLink>}
          />
          <Content.Body full>
            {/* 内容区域一般使用 Card 组件显示内容 */}
            <Card>
              <Card.Body>内容卡片</Card.Body>
            </Card>
          </Content.Body>
        </Content>
      </Body>
    </Layout>
  );
}
```
