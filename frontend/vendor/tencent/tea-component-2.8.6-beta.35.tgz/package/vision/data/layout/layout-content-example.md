# Layout - LayoutContent

## 组件
Layout

## 示例描述
LayoutContent

## 视觉特征
### 整体
这是一个内容区域布局组件，采用简洁的卡片式设计。顶部包含标题栏和区域选择器，中部为内容卡片区域，底部为可选的页脚信息。整体配色以浅灰和白色为主，文字为深灰色，交互元素使用蓝色链接。

### ExternalLink: weak=true
一个弱样式链接，文字为深灰色，无下划线，位于页脚处，内容为'京公网安备 11010802017518 粤B2-20090059-1'。

### RegionOption: num=1108
一个区域选择器，显示'全部地域 1108'，文字为深灰色，背景为白色，带有下拉箭头图标。

### RegionOption: num=20
一个区域选择器，显示'全部地域 20'，文字为深灰色，背景为白色，带有下拉箭头图标。

### RegionOption: dot=true num=20
一个带点标记的区域选择器，显示'全部地域 20'，文字为深灰色，背景为白色，带有下拉箭头图标和一个红色小圆点。

## 实现代码
```jsx
import React from "react";
import {
  Layout,
  Card,
  ExternalLink,
  RegionSelect,
  RegionPanel,
  RegionOption,
} from "@tencent/tea-component";

const { Body, Content } = Layout;

export default function LayoutContentExample() {
  return (
    <Layout className="demo-layout">
      <Body>
        <Content>
          <Content.Header
            showBackButton
            onBackButtonClick={console.log}
            title="内容标题"
            operation={<ExternalLink weak>内容帮助</ExternalLink>}
          >
            <RegionSelect>
              <RegionPanel>
                <RegionPanel.Head>
                  <RegionOption value="all" num={1108}>
                    全部地域
                  </RegionOption>
                </RegionPanel.Head>
                <RegionPanel.Column>
                  <RegionPanel.Group name="中国">
                    <RegionOption value="gz" num={20}>
                      广州
                    </RegionOption>
                    <RegionOption value="sh" num={20} dot>
                      上海
                    </RegionOption>
                    <RegionOption value="hk" num={20}>
                      香港
                    </RegionOption>
                  </RegionPanel.Group>
                </RegionPanel.Column>
              </RegionPanel>
            </RegionSelect>
          </Content.Header>
          <Content.Body>
            {/* 内容区域一般使用 Card 组件显示内容 */}
            <Card>
              <Card.Body>内容卡片</Card.Body>
            </Card>
          </Content.Body>
          <Content.Footer>
            <div className="demo-layout-footer">
              (可选项)自定义页脚
              <br />
              京公网安备 11010802017518 粤B2-20090059-1
            </div>
          </Content.Footer>
        </Content>
      </Body>
    </Layout>
  );
}
```
