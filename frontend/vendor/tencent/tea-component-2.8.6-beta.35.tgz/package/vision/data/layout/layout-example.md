# Layout - Layout

## 组件
Layout

## 示例描述
Layout

## 视觉特征
### 整体
这是一个深色主题的侧边栏布局，左侧为可折叠菜单，右侧为内容区域。核心交互是菜单的展开/收起和导航。整体采用深色背景与白色文字，视觉对比强烈。

### NavMenu.Item: type="logo"
一个位于左上角的Logo占位符，用于品牌标识。

### Menu: collapsable=true icon="https://via.placeholder.com/32.png?text=icon" theme="dark" title="产品名称"
一个深色的可折叠侧边栏菜单，标题为“产品名称”，左侧有图标，支持收起和展开。

### Menu.SubMenu: defaultOpened=true title="一级菜单"
一个默认展开的菜单项，标题为“一级菜单”，包含子菜单项。

### Menu.Item: title="一级菜单"
一个菜单项，显示文字为“一级菜单”，文字颜色为白色。

### Text: theme="label"
一段浅灰色的文字，用于显示说明性信息。

## 实现代码
```jsx
import React, { useState } from "react";
import {
  Layout,
  Card,
  Text,
  ExternalLink,
  Menu,
  NavMenu,
} from "@tencent/tea-component";

const { Header, Body, Footer, Sider, Content } = Layout;

const icon = /** @type {[string, string]} */ ([
  `https://via.placeholder.com/16.png?text=icon`,
  `https://via.placeholder.com/16/006eff/444444`,
]);

export default function LayoutExample() {
  const [selected, setSelected] = useState("overview");

  const getMenuItemProps = id => ({
    selected: selected === id,
    onClick: () => setSelected(id),
  });

  return (
    <Layout className="demo-layout-l">
      <Header>
        <NavMenu
          left={
            <>
              <NavMenu.Item type="logo">
                <img
                  src="https://via.placeholder.com/32.png?text=LOGO"
                  alt="logo"
                />
              </NavMenu.Item>
              <NavMenu.Item>总览</NavMenu.Item>
            </>
          }
        />
      </Header>
      <Body>
        <Sider>
          <Menu
            collapsable
            theme="dark"
            title="产品名称"
            icon="https://via.placeholder.com/32.png?text=icon"
          >
            <Menu.Item
              icon={icon}
              title="一级菜单"
              {...getMenuItemProps("1")}
            />

            <Menu.SubMenu defaultOpened title="一级菜单" icon={icon}>
              <Menu.Item title="二级菜单" {...getMenuItemProps("2-1")} />
              <Menu.Item title="二级菜单" {...getMenuItemProps("2-2")} />
            </Menu.SubMenu>
          </Menu>
        </Sider>
        <Content>
          <Content.Header
            showBackButton
            onBackButtonClick={console.log}
            title="内容标题"
            subtitle={
              <>
                说明文字 <Text theme="label">带颜色说明文字</Text>
              </>
            }
            operation={<ExternalLink weak>内容帮助</ExternalLink>}
          />
          <Content.Body>
            {/* 内容区域一般使用 Card 组件显示内容 */}
            <Card>
              <Card.Body>内容卡片</Card.Body>
            </Card>
          </Content.Body>
          <Content.Footer>
            <div className="demo-layout-footer">
              (可选项)自定义页脚
              <br />
              京公网安备 11010802017518 粤B2-20090059-1
            </div>
          </Content.Footer>
        </Content>
      </Body>
      <Footer>
        <div className="demo-layout-footer">
          (可选项)自定义页脚
          <br />
          京公网安备 11010802017518 粤B2-20090059-1
        </div>
      </Footer>
    </Layout>
  );
}
```
