# Layout - LayoutContentWithTabs

## 组件
Layout

## 示例描述
LayoutContentWithTabs

## 视觉特征
### 整体
该组件采用顶部标题栏与标签页导航的布局结构，主内容区为白色卡片。整体风格简洁，以中性灰为主色调，标签页文字为深灰色，当前选中项有蓝色下划线。核心交互为标签页切换，支持外部链接跳转。

### Text: theme="label"
显示“说明文字 带颜色说明文字”，文字为深灰色，字体大小适中，作为页面内的辅助性说明文本。

### ExternalLink: weak=true
显示“内容帮助”文字，文字颜色为深灰色，无下划线，呈现为弱样式链接。

### Tabs: animated=false ceiling=true
水平排列的标签页，包含“基本信息”、“弹性网卡”等选项，当前选中项有蓝色下划线，标签页顶部有固定分隔线。

## 实现代码
```jsx
import React from "react";
import {
  Layout,
  Card,
  Text,
  ExternalLink,
  Tabs,
  TabPanel,
} from "@tencent/tea-component";

const { Body, Content } = Layout;

export default function LayoutContentWithTabsExample() {
  const tabs = [
    { id: "basic", label: "基本信息" },
    { id: "network", label: "弹性网卡" },
    { id: "monitor", label: "监控信息" },
    { id: "sg", label: "安全组", disabled: true },
    { id: "oplog", label: "操作日志" },
  ];

  return (
    <Layout className="demo-layout">
      <Body>
        <Content>
          <Content.Header
            showBackButton
            onBackButtonClick={console.log}
            title="内容标题"
            subtitle={
              <>
                说明文字 <Text theme="label">带颜色说明文字</Text>
              </>
            }
            operation={<ExternalLink weak>内容帮助</ExternalLink>}
          />
          <Content.Body>
            <Tabs ceiling animated={false} tabs={tabs}>
              <TabPanel id="basic">
                <Card>
                  <Card.Body>基本信息</Card.Body>
                </Card>
              </TabPanel>
              <TabPanel id="network">
                <Card>
                  <Card.Body>弹性网卡</Card.Body>
                </Card>
              </TabPanel>
              <TabPanel id="monitor">
                <Card>
                  <Card.Body>监控信息</Card.Body>
                </Card>
              </TabPanel>
              <TabPanel id="oplog">
                <Card>
                  <Card.Body>操作日志</Card.Body>
                </Card>
              </TabPanel>
            </Tabs>
          </Content.Body>
        </Content>
      </Body>
    </Layout>
  );
}
```
