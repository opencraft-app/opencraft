# Layout - LayoutWithLightSider

## 组件
Layout

## 示例描述
LayoutWithLightSider

## 视觉特征
### 整体
左侧为可折叠的亮色侧边栏，右侧为内容区域。侧边栏包含品牌Logo和层级菜单，菜单项支持展开收起。整体采用浅色背景和深色文字，风格简洁现代。

### NavMenu.Item: type="logo"
位于侧边栏顶部的品牌Logo，视觉上为一个图标，无文字。

### Menu: collapsable=true
左侧的导航菜单，支持收起和展开，当前处于展开状态，显示所有菜单项。

### Menu.Item: title="一级菜单"
菜单中的一个一级菜单项，显示文字“一级菜单”，文字颜色为深色。

### Menu.SubMenu: defaultOpened=true title="一级菜单"
一个默认展开的子菜单，标题为“一级菜单”，文字颜色为深色，右侧有展开图标。

### Text: theme="label"
显示为“内容标题”的文本，文字颜色为深色，字体较粗。

## 实现代码
```jsx
import React, { useState } from "react";
import {
  Layout,
  Card,
  Text,
  ExternalLink,
  Menu,
  NavMenu,
} from "@tencent/tea-component";

const { Header, Body, Sider, Content } = Layout;

const icon = /** @type {[string, string]} */ ([
  `https://via.placeholder.com/16.png?text=icon`,
  `https://via.placeholder.com/16/006eff/444444`,
]);

export default function LayoutWithLightSiderExample() {
  const [selected, setSelected] = useState("overview");

  const getMenuItemProps = id => ({
    selected: selected === id,
    onClick: () => setSelected(id),
  });

  return (
    <Layout className="demo-layout-l">
      <Header>
        <NavMenu
          left={
            <>
              <NavMenu.Item type="logo">
                <img
                  src="https://via.placeholder.com/32.png?text=LOGO"
                  alt="logo"
                />
              </NavMenu.Item>
              <NavMenu.Item>总览</NavMenu.Item>
            </>
          }
        />
      </Header>
      <Body>
        <Sider>
          <Menu
            back={{
              title: "产品名称产品名称产品名称",
              description: "数据测试",
              tooltip: "产品名称产品名称产品名称 - 数据测试勿删",
              onClick: () => console.log("back"),
            }}
            collapsable
          >
            <Menu.Item
              icon={icon}
              title="一级菜单"
              {...getMenuItemProps("1")}
            />

            <Menu.SubMenu defaultOpened title="一级菜单" icon={icon}>
              <Menu.Item title="二级菜单" {...getMenuItemProps("2-1")} />
              <Menu.Item title="二级菜单" {...getMenuItemProps("2-2")} />
            </Menu.SubMenu>
          </Menu>
        </Sider>
        <Content>
          <Content.Header
            title="内容标题"
            subtitle={
              <>
                说明文字 <Text theme="label">带颜色说明文字</Text>
              </>
            }
            operation={<ExternalLink weak>内容帮助</ExternalLink>}
          />
          <Content.Body>
            {/* 内容区域一般使用 Card 组件显示内容 */}
            <Card>
              <Card.Body>内容卡片</Card.Body>
            </Card>
          </Content.Body>
        </Content>
      </Body>
    </Layout>
  );
}
```
