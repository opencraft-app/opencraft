# Mediaobject - MediaObjectExample

## 组件
Mediaobject

## 示例描述
MediaObjectExample

## 视觉特征
### 整体
该组件采用左右布局，左侧为媒体占位符，右侧为文本内容。包含对齐方式选择按钮和反色开关控件。整体风格简洁，以中性色为主，通过按钮状态和开关控件提供交互功能。

### Button: variant='primary' size='small' label='top'
蓝色边框的按钮，文字为白色，显示文本'top'，处于选中状态。

### Button: variant='secondary' size='small' label='middle'
白色背景的按钮，文字为深灰色，显示文本'middle'，处于未选中状态。

### Button: variant='secondary' size='small' label='bottom'
白色背景的按钮，文字为深灰色，显示文本'bottom'，处于未选中状态。

### Switch: size='small' checked=false
小型的灰色开关控件，处于关闭状态，旁边有'反色'文字标签。

## 实现代码
```jsx
import React, { useState } from "react";
import {
  MediaObject,
  Segment,
  Switch,
  H4,
  useClassNames,
} from "@tencent/tea-component";

const media = <img src="//placehold.it/64x64" alt="Generic placeholder" />;

export default function MediaObjectExample() {
  const [align, setAlign] = useState("top");
  const [reverse, setReverse] = useState(false);
  const { Margin } = useClassNames();

  const content = (
    <>
      <H4 className={Margin.Bottom["2n"]}>Media heading</H4>
      <p>
        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque
        ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at,
        tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate
        fringilla. Donec lacinia congue felis in faucibus. Cras sit amet nibh
        libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin
        commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra
        turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec
        lacinia congue felis in faucibus.
      </p>
    </>
  );

  return (
    <>
      <MediaObject
        media={media}
        // @ts-ignore
        align={align}
        reverse={reverse}
      >
        {content}
      </MediaObject>
      <section>
        对齐方式：
        <Segment
          options={[{ value: "top" }, { value: "middle" }, { value: "bottom" }]}
          value={align}
          onChange={value => setAlign(value)}
        />
      </section>
      <section>
        反置：
        <Switch value={reverse} onChange={value => setReverse(value)} />
      </section>
    </>
  );
}
```
