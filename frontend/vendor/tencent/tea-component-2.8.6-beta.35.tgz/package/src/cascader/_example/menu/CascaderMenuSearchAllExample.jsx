import React, { useState } from "react";
import { Cascader, Form } from "@tencent/tea-component";

const data = [
  {
    label: "北京市",
    value: "bj",
    children: [
      { label: "朝阳区", value: "cy" },
      { label: "海淀区", value: "hd" },
      { label: "东城区", value: "dc" },
      { label: "西城区", value: "xc" },
    ],
  },
  {
    label: "上海市",
    value: "sh",
    children: [
      { label: "徐汇区", value: "xh" },
      { label: "黄埔区", value: "hp" },
      { label: "静安区", value: "ja" },
      { label: "浦东新区", value: "pudong" },
    ],
  },
  {
    label: "广东省",
    value: "gd",
    children: [
      {
        label: "深圳市",
        value: "sz",
        children: [
          { label: "南山区", value: "ns" },
          { label: "宝安区", value: "ba" },
          { label: "福田区", value: "ft" },
          { label: "龙岗区", value: "lg" },
        ],
      },
      {
        label: "广州市",
        value: "gz",
        children: [
          { label: "天河区", value: "th" },
          { label: "越秀区", value: "yx" },
          { label: "荔湾区", value: "lw" },
        ],
      },
    ],
  },
];

export default function CascaderMenuSearchAllExample() {
  const [value, setValue] = useState([]);

  return (
    <Form>
      <Form.Item label="多选可搜索（支持全选搜索结果）">
        <Cascader
          multiple
          searchable
          clearable
          type="menu"
          data={data}
          all
          value={value}
          onChange={(newValue, { options }) => {
            console.log("Selected:", newValue, options);
            setValue(newValue);
          }}
          placeholder="请输入关键词搜索，如：朝阳、上海等"
        />
      </Form.Item>

      <Form.Item label="自定义全选文案">
        <Cascader
          multiple
          searchable
          clearable
          type="menu"
          data={data}
          all={{ label: "全选搜索结果", value: "all-search" }}
          value={value}
          onChange={(newValue, { options }) => {
            console.log("Selected:", newValue, options);
            setValue(newValue);
          }}
          placeholder="请输入关键词搜索"
        />
      </Form.Item>

      <Form.Item label="当前选中值">
        <div
          style={{ padding: "8px", background: "#f5f5f5", borderRadius: "4px" }}
        >
          {value.length > 0 ? (
            <ul>
              {value.map((item, index) => (
                <li key={index}>{item.join(" > ")}</li>
              ))}
            </ul>
          ) : (
            <span style={{ color: "#999" }}>暂无选中项</span>
          )}
        </div>
      </Form.Item>
    </Form>
  );
}
