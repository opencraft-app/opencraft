/* eslint-disable */
/// <reference path="../../../node_modules/monaco-editor/monaco.d.ts" />
/// <reference path="./frame-env.d.ts" />

// Polyfill
if (typeof Object.assign != 'function') {
  // Must be writable: true, enumerable: false, configurable: true
  Object.defineProperty(Object, "assign", {
    value: function assign(target, varArgs) { // .length of function is 2
      'use strict';
      if (target == null) { // TypeError if undefined or null
        throw new TypeError('Cannot convert undefined or null to object');
      }

      let to = Object(target);

      for (var index = 1; index < arguments.length; index++) {
        var nextSource = arguments[index];

        if (nextSource != null) { // Skip over if undefined or null
          for (let nextKey in nextSource) {
            // Avoid bugs when hasOwnProperty is shadowed
            if (Object.prototype.hasOwnProperty.call(nextSource, nextKey)) {
              to[nextKey] = nextSource[nextKey];
            }
          }
        }
      }
      return to;
    },
    writable: true,
    configurable: true
  });
}

var host = window.parent;
var client = window;
var lang = "zh-cn";
/** @type {monaco.editor.IStandaloneCodeEditor} */
var editor = null;

// 加载编辑器
// prettier-ignore
require.config({
  paths: {
    vs: "https://cloudcache.tencent-cloud.com/qcloud/vendors/monaco-editor/0.16.2/dev/vs"
  },
  "vs/nls": {
    availableLanguages: {
      "*": "zh-cn"
    }
  }
});
require(["vs/editor/editor.main"], connect, errback);

/**
 * 加载后与宿主连接
 */
function connect() {
  // 没有宿主，显示 Demo
  if (client === host) {
    create();
    return;
  }

  // 告诉宿主已经加载完成
  send("ready");

  // 监听宿主发送过来的消息
  client.addEventListener("message", receive);
}

// prettier-ignore
function errback(error) {
  if (typeof error === "undefined") {
    error = {};
  }
  const payload = {
    message: "加载 " + (error.moduleId || "editor") + " 失败"
  };
  send("error", payload);
}

/**
 * 给宿主发送消息
 * @param {string} type
 * @param {any} [payload] 消息数据
 */
function send(type, payload) {
  // TODO: 细化 origin
  host.postMessage(encodeMessage(type, payload), "*");
}

/**
 * 解析从宿主接收到的消息
 * @param {MessageEvent} evt
 */
// prettier-ignore
function receive(evt) {
  // TODO: 判断是否为合法来源
  // if (!isLegalOrigin(evt.origin)) {
  //   return;
  // }

  var message = decodeMessage(evt.data);

  switch (message.type) {
    case "create":
      create(message.payload);
      break;
    case "get-value":
      send("value", {
        key: message.payload.key,
        value:
          editor &&
          editor.getValue(
            message.payload.option || { preserveBOM: false, lineEnding: "\n" }
          )
      });
      break;
    case "set-value":
      if (editor) {
        editor.setValue(message.payload.value);
      }
      break;
    case "focus":
      if (editor) {
        editor.focus();
      }
      break;
    case "update-options":
      if (editor) {
        editor.updateOptions(message.payload.options);
      }
      break;
  }
}

/**
 * 编码消息
 * @param {string} type
 * @param {any} [payload]
 */
function encodeMessage(type, payload) {
  return JSON.stringify({ type: type, payload: payload });
}

/**
 * 解码消息
 * @param {string} message
 * @returns {{ type: string, payload: any }}
 */
function decodeMessage(message) {
  try {
    var decoded = JSON.parse(message);
    if (decoded.type) {
      return decoded;
    }
  } catch (err) {
    return null;
  }
  return null;
}

/**
 * 创建编辑器实例
 * @param {any} [options]
 */
// prettier-ignore
function create(options) {
  var root = document.getElementById("editor-root");
  // 销毁已存在的实例
  if (editor) {
    editor.getModel().dispose();
    editor.dispose();
    root.innerHTML = "";
  }
  // 合并配置
  options = Object.assign(
    {
      language: "javascript",
      scrollBeyondLastLine: false,
      hideCursorInOverviewRuler: true,
      scrollbar: {
        verticalScrollbarSize: 12,
        horizontalScrollbarSize: 12
      },
      fontSize: 12,
      useTabStops: true,
      folding: true,
      minimap: {
        enabled: false
      }
    },
    options || {}
  );

  // 创建
  editor = monaco.editor.create(root, options);
  // 绑定编辑事件
  editor.onDidChangeModelContent(function() {
    send("edit");
  });
  // 绑定保存事件
  editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KEY_S, function() {
    send("save");
  });
  // 支持自动聚焦
  if (options.autoFocus) {
    editor.focus();
  }
}

window.addEventListener("resize", function() {
  if (editor) {
    editor.layout();
  }
});
/* eslint-enable */
