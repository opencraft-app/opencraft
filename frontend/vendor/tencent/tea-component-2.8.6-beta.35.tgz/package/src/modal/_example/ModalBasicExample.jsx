import React, { useState } from "react";
import { Modal, Button } from "@tencent/tea-component";

export default function ModalBasicExample() {
  const [visible, setVisible] = useState(false);

  const open = () => setVisible(true);
  const close = () => setVisible(false);

  return (
    <>
      <Button type="primary" onClick={open}>
        打开
      </Button>
      <Modal visible={visible} caption="对话框标题" onClose={close}>
        <Modal.Body>我是对话框内容</Modal.Body>
        <Modal.Footer>
          <Button type="primary" onClick={close}>
            确定
          </Button>
          <Button type="weak" onClick={close}>
            取消
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}
