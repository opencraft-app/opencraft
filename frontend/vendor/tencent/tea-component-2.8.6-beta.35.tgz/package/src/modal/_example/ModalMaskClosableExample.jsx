import React, { useState } from "react";
import { Modal, Button, DatePicker } from "@tencent/tea-component";

export default function ModalBasicExample() {
  const [visible, setVisible] = useState(false);

  const open = () => setVisible(true);
  const close = () => setVisible(false);

  return (
    <>
      <Button type="primary" onClick={open}>
        打开
      </Button>
      <Modal
        maskClosable
        visible={visible}
        caption="对话框标题"
        onClose={close}
      >
        <Modal.Body>
          <DatePicker />
        </Modal.Body>
        <Modal.Footer />
      </Modal>
    </>
  );
}
