import React, { useState } from "react";
import { Modal, Button } from "@tencent/tea-component";

export default function ModalScrollableExample() {
  const [visible2, setVisible2] = useState(false);

  const open2 = () => setVisible2(true);

  const close2 = () => setVisible2(false);

  return (
    <>
      <Button onClick={open2}>内容区可滚动</Button>
      <Modal
        scrollable
        visible={visible2}
        caption="对话框标题"
        onClose={close2}
      >
        <Modal.Body>
          <div style={{ width: "100%", height: "2000px" }}>
            <span>占位内容</span>
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button type="primary" onClick={close2}>
            确定
          </Button>
          <Button type="weak" onClick={close2}>
            取消
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}
