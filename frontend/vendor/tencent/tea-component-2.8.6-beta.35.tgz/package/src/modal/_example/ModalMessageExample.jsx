import React, { useState } from "react";
import { Modal, Button } from "@tencent/tea-component";

export default function ModalMessageExample() {
  const [visible, setVisible] = useState(false);

  const open = () => setVisible(true);
  const close = () => setVisible(false);

  return (
    <>
      <Button type="primary" onClick={open}>
        打开 success
      </Button>
      <Modal visible={visible} disableCloseIcon onClose={close}>
        <Modal.Body>
          <Modal.Message
            icon="warning"
            message="提示消息"
            description="详细描述"
          />
        </Modal.Body>
        <Modal.Footer>
          <Button type="primary" onClick={close}>
            确定
          </Button>
          <Button type="weak" onClick={close}>
            取消
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}
