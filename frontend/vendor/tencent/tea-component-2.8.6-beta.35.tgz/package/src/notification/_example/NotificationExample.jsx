import React from "react";
import { notification, Button } from "@tencent/tea-component";

export default function NotificationExample() {
  return (
    <>
      <Button
        onClick={() =>
          notification.info({
            title: "标题",
            description:
              "文案不限长度，但是展示最大哦显示两行折行的末尾处显示折行的末尾处显示折行的末尾处显示折折行的末尾处显示折折行的末尾处",
            footer: "查看详情",
            onFooterClick: console.log,
            duration: 0,
          })
        }
      >
        Info
      </Button>
      <Button
        onClick={() =>
          notification.success({
            title: "标题",
            description:
              "文案不限长度，但是展示最大哦显示两行折行的末尾处显示折行的末尾处显示折行的末尾处显示折折行的末尾处显示折折行的末尾处",
            extra: "Test",
            footer: <Button type="text">测试</Button>,
          })
        }
      >
        Success
      </Button>
      <Button
        onClick={() =>
          notification.warning({
            title: "标题",
            description:
              "文案不限长度，但是展示最大哦显示两行折行的末尾处显示折行的末尾处显示折行的末尾处显示折折行的末尾处显示折折行的末尾处",
          })
        }
      >
        Warning
      </Button>
      <Button
        onClick={() =>
          notification.error({
            title: "标题",
            description:
              "文案不限长度，但是展示最大哦显示两行折行的末尾处显示折行的末尾处显示折行的末尾处显示折折行的末尾处显示折折行的末尾处",
            footer: "查看详情",
            onFooterClick: console.log,
          })
        }
      >
        Error
      </Button>
      <Button
        onClick={() =>
          notification.operations({
            title: "腾讯云官网协议更新通知",
            description:
              "您没有设置主机密码，创建后系统将自动为您生成密码并通过站内信发送给您。您也可登录CVM控制台重置密码",
            footer: "前往查看",
            onFooterClick: console.log,
            notificationIcon: (
              <img
                src="https://cloudcache.tencent-cloud.com/qcloud/ui/static/static_source_business/8c9efc87-8c63-430c-bfb7-70dfa710930a.svg"
                alt="11"
              />
            ),
          })
        }
      >
        运营 operations
      </Button>
      <Button
        onClick={() =>
          notification.billing({
            title: "腾讯云官网大促",
            description:
              "您没有设置主机密码，创建后系统将自动为您生成密码并通过站内信发送给您。您也可登录CVM控制台重置密码",
            footer: "前往查看",
            onFooterClick: console.log,
            notificationIcon: (
              <img
                src="https://cloudcache.tencent-cloud.com/qcloud/ui/static/static_source_business/ccea175c-1160-4de2-9ab6-71a463c12c6c.svg"
                alt="11"
              />
            ),
          })
        }
      >
        支付类 billing
      </Button>
    </>
  );
}
