import React, { useState } from "react";
import moment from "moment";
import { DatePicker, Form, Switch } from "@tencent/tea-component";

const { RangePicker } = DatePicker;

const unitTextMap = {
  s: "秒",
  m: "分钟",
  h: "小时",
  d: "天",
  w: "周",
  M: "月",
  y: "年",
};

export default function DatePickerNewExample() {
  const [timeZone, setTimeZone] = useState("");
  const [history, setHistory] = useState([
    [
      moment().subtract(1, "days"),
      moment(),
      { start: moment().subtract(1, "days"), end: moment() },
    ],
    [
      moment().subtract(2, "days"),
      moment(),
      { start: moment().subtract(2, "days"), end: moment() },
    ],
  ]);
  const [relativeRoundDownUnit, setRelativeRoundDownUnit] = useState("");

  return (
    <Form layout="vertical">
      <Form.Item label="支持绝对时间、相对时间选择">
        <RangePicker
          defaultValue={[
            moment().subtract(1, "days"),
            moment(),
            { start: moment().subtract(1, "days"), end: moment() },
          ]}
          onChange={value => {
            console.log(value);
            setHistory([value, ...history]);
          }}
          showTime
          responsive
          showTip
          showQuickRanges
          showFusionPanel={{
            relativeRoundDownUnit,
            relativeTimeFooter: (value, unit) => (
              <Switch
                onChange={value => {
                  if (value) {
                    setRelativeRoundDownUnit(unit);
                  } else {
                    setRelativeRoundDownUnit("");
                  }
                }}
              >
                精确到{unitTextMap[unit]}级
              </Switch>
            ),
            hideTimeSelect: true,
          }}
          closeOnScroll={false}
        />
      </Form.Item>
      <Form.Item label="保留历史记录">
        <RangePicker
          defaultValue={[
            moment().subtract(1, "days"),
            moment(),
            { start: moment().subtract(1, "days"), end: moment() },
          ]}
          onChange={value => {
            console.log(value);
            const newHistory = history.filter(v => {
              return !v[0].isSame(value[0]) || !v[1].isSame(value[1]);
            });
            setHistory([value, ...newHistory]);
          }}
          showTime
          responsive
          showTip
          showQuickRanges
          showFusionPanel={{
            showHistory: true,
            history,
          }}
          closeOnScroll={false}
        />
      </Form.Item>
      <Form.Item label="带时区">
        <RangePicker
          defaultValue={[
            moment().subtract(1, "days"),
            moment(),
            { start: moment().subtract(1, "days"), end: moment() },
          ]}
          onChange={value => {
            console.log(value);
            const newHistory = history.filter(v => {
              return !v[0].isSame(value[0]) || !v[1].isSame(value[1]);
            });
            setHistory([value, ...newHistory]);
          }}
          showTime
          responsive
          showTip
          showQuickRanges
          showFusionPanel={{
            showHistory: true,
            history,
          }}
          closeOnScroll={false}
          showTimeZone
          timeZone={timeZone}
          onTimeZoneChange={value => {
            console.log("timeZone", value);
            setTimeZone(value);
          }}
        />
      </Form.Item>
    </Form>
  );
}
