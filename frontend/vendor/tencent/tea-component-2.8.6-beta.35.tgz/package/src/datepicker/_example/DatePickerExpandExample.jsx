import React, { useState } from "react";
import moment from "moment";
import { ChevronLeftIcon, ChevronRightIcon } from "@tencent/tea-icons-react";
import {
  Button,
  DatePicker,
  Form,
  InputAdornment,
  Tag,
} from "@tencent/tea-component";

const { RangePicker } = DatePicker;

function calculateTimeInterval(startMoment, endMoment) {
  const start = startMoment.isBefore(endMoment) ? startMoment : endMoment;
  const end = startMoment.isBefore(endMoment) ? endMoment : startMoment;

  const years = end.diff(start, "years");
  const months = end.diff(start, "months");
  const days = end.diff(start, "days");
  const hours = end.diff(start, "hours");
  const minutes = end.diff(start, "minutes");
  const seconds = end.diff(start, "seconds");

  // 年份处理：如果超过半年则进位
  if (years > 0) {
    const remainingMonths = end.diff(
      start.clone().add(years, "years"),
      "months"
    );
    return remainingMonths >= 6 ? `${years + 1}年` : `${years}年`;
  }

  // 月份处理：如果超过半个月则进位
  if (months > 0) {
    const remainingDays = end.diff(start.clone().add(months, "months"), "days");
    // 以15天作为半个月的标准
    return remainingDays >= 15 ? `${months + 1}个月` : `${months}个月`;
  }

  // 天数处理：如果超过12小时则进位
  if (days > 0) {
    const remainingHours = end.diff(start.clone().add(days, "days"), "hours");
    return remainingHours >= 12 ? `${days + 1}天` : `${days}天`;
  }

  // 小时处理：如果超过30分钟则进位
  if (hours > 0) {
    const remainingMinutes = end.diff(
      start.clone().add(hours, "hours"),
      "minutes"
    );
    return remainingMinutes >= 30 ? `${hours + 1}小时` : `${hours}小时`;
  }

  // 分钟处理：如果超过30秒则进位
  if (minutes > 0) {
    const remainingSeconds = end.diff(
      start.clone().add(minutes, "minutes"),
      "seconds"
    );
    return remainingSeconds >= 30 ? `${minutes + 1}分钟` : `${minutes}分钟`;
  }

  return `${seconds}秒`;
}

function moveByTimeInterval(startMoment, endMoment, direction = "forward") {
  const start = startMoment.clone();
  const end = endMoment.clone();

  const isReversed = start.isAfter(end);
  const earlier = isReversed ? end : start;
  const later = isReversed ? start : end;

  const duration = moment.duration(later.diff(earlier));

  let newStart;
  let newEnd;

  if (direction === "forward") {
    newStart = start.clone().add(duration);
    newEnd = end.clone().add(duration);
  } else if (direction === "backward") {
    newStart = start.clone().subtract(duration);
    newEnd = end.clone().subtract(duration);
  }

  return [newStart, newEnd];
}

export default function DatePickerNewExample() {
  const [value, setValue] = useState([
    moment().subtract(2, "days"),
    moment(),
    { start: moment().subtract(2, "days"), end: moment() },
  ]);

  function onMoveBackward() {
    const [start, end] = moveByTimeInterval(value[0], value[1], "backward");
    setValue([start, end, { start, end }]);
  }

  function onMoveForward() {
    const [start, end] = moveByTimeInterval(value[0], value[1], "forward");
    setValue([start, end, { start, end }]);
  }

  return (
    <Form layout="vertical">
      <Form.Item label="时间微调">
        <InputAdornment
          appearance="pure"
          before={
            <Button
              variant="outlined"
              shape="square"
              size="md"
              onClick={onMoveBackward}
            >
              <ChevronLeftIcon size={16} />
            </Button>
          }
          after={
            <Button
              variant="outlined"
              shape="square"
              size="md"
              onClick={onMoveForward}
            >
              <ChevronRightIcon size={16} />
            </Button>
          }
        >
          <RangePicker
            value={value}
            onChange={value => {
              console.log(value);
              setValue(value);
            }}
            prefix={
              <Tag variant="soft" size="sm">
                {calculateTimeInterval(value[0], value[1])}
              </Tag>
            }
            showTime
            responsive
            showQuickRanges
            showTimeZone
            showFusionPanel
          />
        </InputAdornment>
      </Form.Item>
    </Form>
  );
}
