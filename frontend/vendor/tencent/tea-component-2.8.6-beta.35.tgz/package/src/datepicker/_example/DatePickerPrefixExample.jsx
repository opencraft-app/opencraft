import React, { useState } from "react";
import moment from "moment";
import { DatePicker, Form, H4, Space, Tag, Text } from "@tencent/tea-component";

const { RangePicker } = DatePicker;

function calculateTimeInterval(startMoment, endMoment) {
  const start = startMoment.isBefore(endMoment) ? startMoment : endMoment;
  const end = startMoment.isBefore(endMoment) ? endMoment : startMoment;

  const years = end.diff(start, "years");
  const months = end.diff(start, "months");
  const days = end.diff(start, "days");
  const hours = end.diff(start, "hours");
  const minutes = end.diff(start, "minutes");
  const seconds = end.diff(start, "seconds");

  // 年份处理：如果超过半年则进位
  if (years > 0) {
    const remainingMonths = end.diff(
      start.clone().add(years, "years"),
      "months"
    );
    return remainingMonths >= 6 ? `${years + 1}年` : `${years}年`;
  }

  // 月份处理：如果超过半个月则进位
  if (months > 0) {
    const remainingDays = end.diff(start.clone().add(months, "months"), "days");
    // 以15天作为半个月的标准
    return remainingDays >= 15 ? `${months + 1}个月` : `${months}个月`;
  }

  // 天数处理：如果超过12小时则进位
  if (days > 0) {
    const remainingHours = end.diff(start.clone().add(days, "days"), "hours");
    return remainingHours >= 12 ? `${days + 1}天` : `${days}天`;
  }

  // 小时处理：如果超过30分钟则进位
  if (hours > 0) {
    const remainingMinutes = end.diff(
      start.clone().add(hours, "hours"),
      "minutes"
    );
    return remainingMinutes >= 30 ? `${hours + 1}小时` : `${hours}小时`;
  }

  // 分钟处理：如果超过30秒则进位
  if (minutes > 0) {
    const remainingSeconds = end.diff(
      start.clone().add(minutes, "minutes"),
      "seconds"
    );
    return remainingSeconds >= 30 ? `${minutes + 1}分钟` : `${minutes}分钟`;
  }

  return `${seconds}秒`;
}

export default function DatePickerNewExample() {
  const [value1, setValue1] = useState([
    moment().subtract(15, "days"),
    moment(),
    { start: moment().subtract(15, "days"), end: moment() },
  ]);
  const [value2, setValue2] = useState([
    moment().subtract(7, "days"),
    moment(),
    { start: "now-7d", end: "now" },
  ]);

  return (
    <>
      <H4>带标签</H4>
      <Form layout="vertical">
        <Form.Item label="自动计算起止时间相隔，用于搭配时间微调、扩大时间范围、自动计算绝对时间">
          <RangePicker
            value={value1}
            onChange={value => {
              console.log(value);
              setValue1(value);
            }}
            prefix={([start, end]) => {
              return (
                <Tag variant="soft" size="sm">
                  {start && end ? calculateTimeInterval(start, end) : "-"}
                </Tag>
              );
            }}
            showTime
            responsive
            showTip
            showQuickRanges
            closeOnScroll={false}
          />
        </Form.Item>
      </Form>
      <H4 style={{ margin: "36px 0 12px" }}>自定义前缀</H4>
      <Form hideLabel>
        <Form.Item>
          <RangePicker
            value={value2}
            onChange={value => {
              console.log(value);
              setValue2(value);
            }}
            prefix={<Text>创建时间:</Text>}
            showTime
            responsive
            showTip
            showQuickRanges
            closeOnScroll={false}
          />
        </Form.Item>
        <Form.Item>
          <RangePicker
            value={value2}
            onChange={value => {
              console.log(value);
              setValue2(value);
            }}
            prefix={([start, end]) => {
              return (
                <div style={{ display: "flex", gap: "4px" }}>
                  <Text>创建时间:</Text>
                  <Tag variant="soft" size="sm">
                    {calculateTimeInterval(start, end)}
                  </Tag>
                </div>
              );
            }}
            showTime
            responsive
            showTip
            showQuickRanges
            closeOnScroll={false}
          />
        </Form.Item>
      </Form>
    </>
  );
}
