import React from "react";
import { DatePicker } from "@tencent/tea-component";

export default () => {
  return (
    <DatePicker
      clearable
      onChange={value => console.log(value)}
      style={{ marginTop: 12 }}
    />
  );
};
