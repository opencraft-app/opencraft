import React, { useState } from "react";
import moment from "moment";
import {
  DatePicker,
  Form,
  H4,
  InputAdornment,
  Segment,
  Text,
  toDateTime,
} from "@tencent/tea-component";

const { RangePicker } = DatePicker;

const dateOptions = [
  { text: "今天", value: "now/d~now/d" },
  { text: "昨天", value: "now-1d/d~now-1d/d" },
  { text: "近 7 天", value: "now-7d~now" },
  { text: "近 30 天", value: "now-30d~now" },
];
const dateTimeOptions = [
  {
    text: "近一小时",
    value: "now-1h~now",
  },
  {
    text: "近 3 小时",
    value: "now-3h~now",
  },
  {
    text: "近 1 天",
    value: "now-1d~now",
  },
  {
    text: "近 3 天",
    value: "now-3d~now",
  },
];

export default function PickerWithQuickRangesExample() {
  const [values, setValues] = useState({
    value1: [moment().subtract(1, "days"), moment()],
    value2: [moment().subtract(1, "days"), moment()],
    value3: [moment().subtract(1, "days"), moment()],
  });
  const [segment1, setSegment1] = useState("");
  const [segment2, setSegment2] = useState("");
  const [segment3, setSegment3] = useState("");
  const [timeZone, setTimeZone] = useState("");
  const [history, setHistory] = useState([]);

  return (
    <>
      <H4>分段按钮组合</H4>
      <Form style={{ margin: "36px 0" }}>
        <Form.Item label="日期范围选择">
          <InputAdornment
            appearance="pure"
            after={
              <RangePicker
                value={values.value1}
                onChange={value => {
                  console.log(value);
                  setSegment1("");
                  setValues({
                    ...values,
                    value1: value,
                  });
                }}
              />
            }
          >
            <Segment
              options={dateOptions}
              value={segment1}
              onChange={value => {
                setSegment1(value);
                const [start, end] = value.split("~");
                setValues({
                  ...values,
                  value1: [
                    toDateTime(start, { roundUp: false }),
                    toDateTime(end, { roundUp: true }),
                  ],
                });
              }}
            ></Segment>
          </InputAdornment>
        </Form.Item>
        <Form.Item label="日期时间范围选择">
          <InputAdornment
            appearance="pure"
            after={
              <RangePicker
                value={values.value2}
                onChange={value => {
                  console.log(value);
                  setSegment2("");
                  setValues({
                    ...values,
                    value2: value,
                  });
                }}
                showTime
              />
            }
          >
            <Segment
              options={dateTimeOptions}
              value={segment2}
              onChange={value => {
                setSegment2(value);
                const [start, end] = value.split("~");
                setValues({
                  ...values,
                  value2: [
                    toDateTime(start, { roundUp: false }),
                    toDateTime(end, { roundUp: true }),
                  ],
                });
              }}
            ></Segment>
          </InputAdornment>
        </Form.Item>
      </Form>
      <H4>下拉面板</H4>
      <Form style={{ marginTop: "24px" }}>
        <Form.Item label="日期范围选择">
          <RangePicker
            defaultValue={[moment().subtract(1, "days"), moment()]}
            onChange={value => console.log(value)}
            responsive
            showQuickRanges
          />
        </Form.Item>
        <Form.Item label="日期时间范围选择">
          <RangePicker
            defaultValue={[
              moment().subtract(5, "m"),
              moment(),
              { start: "now-5m", end: "now" },
            ]}
            onChange={value => console.log(value)}
            showTime
            responsive
            showQuickRanges
          />
        </Form.Item>
        <Form.Item label="头部快捷选项">
          <RangePicker
            header={
              <Segment
                rimless
                value={segment3}
                options={dateOptions}
                onChange={value => {
                  setSegment3(value);
                  const [start, end] = value.split("~");
                  setValues({
                    ...values,
                    value3: [
                      toDateTime(start, { roundUp: false }),
                      toDateTime(end, { roundUp: true }),
                    ],
                  });
                }}
              />
            }
            value={values.value3}
            onChange={value => {
              console.log(value);
              setSegment3("");
              setValues({
                ...values,
                value3: value,
              });
            }}
          />
        </Form.Item>
        <Form.Item label="自定义头部">
          <RangePicker
            onChange={value => {
              console.log(value);
            }}
            range={[moment("2020-01-01"), null]}
            disabledDate={date => {
              return (
                !date.isAfter(moment(), "day") &&
                !date.isBefore(moment("2020-01-01"), "day")
              );
            }}
            header={
              <Text theme="weak">提示：仅支持选择从 2020-01-01 至今的数据</Text>
            }
          />
        </Form.Item>
      </Form>
    </>
  );
}
