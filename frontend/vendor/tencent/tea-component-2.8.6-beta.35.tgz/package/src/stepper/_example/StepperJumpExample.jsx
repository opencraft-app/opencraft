import React, { useState } from "react";
import { Stepper, Button } from "@tencent/tea-component";

export default function StepperExample() {
  const steps = [
    { id: "prepare", label: "验证备案类型" },
    { id: "info", label: "填写备案信息" },
    { id: "upload", label: "上传资料" },
    { id: "photo", label: "办理拍照" },
    { id: "finish", label: "完成备案" },
  ];

  const [current, setCurrent] = useState("info");
  const currentIndex = current ? steps.findIndex(x => x.id === current) : -1;
  const next = current && steps[currentIndex + 1];
  const prev = current ? steps[currentIndex - 1] : steps[steps.length - 1];

  return (
    <div>
      <Stepper responsive steps={steps} current={current} />
      <section style={{ textAlign: "center" }}>
        <div
          style={{
            height: 100,
            lineHeight: "100px",
            textAlign: "center",
            background: "var(--tea-color-bg-tertiary-default)",
            margin: "20px 0",
          }}
        >
          {steps[currentIndex] ? steps[currentIndex].label : "已完成"}
        </div>
        <Button
          disabled={!prev}
          onClick={() => setCurrent(prev.id)}
          tooltip={prev ? `上一步：${prev.label}` : "已经在第一步"}
        >
          上一步
        </Button>
        <Button
          type="primary"
          disabled={!next && !current}
          onClick={() => setCurrent(next ? next.id : null)}
          style={{ marginLeft: 10 }}
        >
          {next ? `下一步：${next.label}` : "完成"}
        </Button>
      </section>
    </div>
  );
}
