import React from "react";
import { Stepper } from "@tencent/tea-component";

export default function StepperExample() {
  const steps = [
    { id: "prepare", label: "备案类型" },
    { id: "info", label: "备案信息" },
    {
      id: "upload",
      label: "上传资料",
      detail: (
        <>
          <strong>资料审核中</strong>
          <br />
          腾讯云会在 <strong>1 个工作日内</strong>审核完成，请耐心等候。
          <a>催单处理</a>
        </>
      ),
    },
    { id: "photo", label: "办理拍照" },
    { id: "finish", label: "完成备案" },
  ];

  return <Stepper type="process-vertical" steps={steps} />;
}
