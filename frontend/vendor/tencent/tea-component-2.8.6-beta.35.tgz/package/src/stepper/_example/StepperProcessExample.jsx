import React from "react";
import { Stepper } from "@tencent/tea-component";

export default function StepperExample() {
  const steps = [
    { id: "prepare", label: "备案类型" },
    { id: "info", label: "备案信息" },
    { id: "upload", label: "上传资料" },
    { id: "photo", label: "办理拍照" },
    { id: "finish", label: "完成备案" },
  ];

  return <Stepper type="process" steps={steps} />;
}
