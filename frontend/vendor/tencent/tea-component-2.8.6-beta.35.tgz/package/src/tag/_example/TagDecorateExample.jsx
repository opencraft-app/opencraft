import React from "react";
import { Tag } from "@tencent/tea-component";
import { SaveIcon } from "@tencent/tea-icons-react";

export default function TagDecorateExample() {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
      <div style={{ display: "flex", gap: "8px" }}>
        <Tag before={<SaveIcon />}>默认标签</Tag>
        <Tag theme="primary" before={<SaveIcon />}>
          主题标签
        </Tag>
        <Tag variant="solid" before={<SaveIcon />}>
          深色直角标签
        </Tag>
      </div>
      <div style={{ display: "flex", gap: "8px" }}>
        <Tag after={<SaveIcon />}>默认标签</Tag>
        <Tag theme="primary" after={<SaveIcon />}>
          主题标签
        </Tag>
        <Tag variant="solid" after={<SaveIcon />}>
          深色直角标签
        </Tag>
      </div>
      <div style={{ display: "flex", gap: "8px" }}>
        <Tag onClose={() => {}}>默认标签</Tag>
        <Tag theme="primary" onClose={() => {}}>
          主题标签
        </Tag>
        <Tag variant="solid" onClose={() => {}}>
          深色直角标签
        </Tag>
      </div>
    </div>
  );
}
