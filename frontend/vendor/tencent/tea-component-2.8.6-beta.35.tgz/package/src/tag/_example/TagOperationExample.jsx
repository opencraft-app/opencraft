import React from "react";
import { Tag } from "@tencent/tea-component";
import { ChevronRightIcon } from "@tencent/tea-icons-react";

export default function TagOperationExample() {
  const style1 = {
    background: "linear-gradient(90deg, #EDF4FF 1.37%, #D5EAFD 85.87%)",
    color: "#003CAB",
    border: "none",
  };
  const style2 = {
    background:
      "linear-gradient(79deg, #E6E9EF 33.86%, #FFF 68.01%, #E6E9EF 90.37%)",
    border: "0.5px solid #E6E9EF",
    color: "var(--tea-color-palette-bluegray-10)",
  };
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
      <div style={{ display: "flex", gap: "8px" }}>
        <Tag style={style1} shapeType="rounded" after={<ChevronRightIcon />}>
          邀请入会
        </Tag>
        <Tag style={style2} shapeType="rounded">
          PRO
        </Tag>
      </div>
    </div>
  );
}
