import React from "react";
import { Tag } from "@tencent/tea-component";

export default function TagThemeExample() {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
      <div style={{ display: "flex", gap: "8px" }}>
        <Tag theme="primary">这是一个标签</Tag>
        <Tag theme="success">这是一个标签</Tag>
        <Tag theme="warning">这是一个标签</Tag>
        <Tag theme="error">这是一个标签</Tag>
      </div>
    </div>
  );
}
