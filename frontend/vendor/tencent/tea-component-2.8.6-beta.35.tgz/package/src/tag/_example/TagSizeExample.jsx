import React from "react";
import { Tag } from "@tencent/tea-component";

export default function TagSizeExample() {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
      <div style={{ display: "flex", gap: "8px" }}>
        <Tag variant="outlined" size="sm">
          标签
        </Tag>
        <Tag variant="outlined" shapeType="rounded" size="sm">
          描边圆角标签
        </Tag>
        <Tag size="sm">默认标签</Tag>
        <Tag shapeType="rounded" size="sm">
          圆角标签
        </Tag>
        <Tag variant="solid" size="sm">
          深色直角标签
        </Tag>
        <Tag variant="solid" shapeType="rounded" size="sm">
          深色圆角标签
        </Tag>
      </div>
      <div style={{ display: "flex", gap: "8px" }}>
        <Tag variant="outlined" size="md">
          标签
        </Tag>
        <Tag variant="outlined" shapeType="rounded" size="md">
          描边圆角标签
        </Tag>
        <Tag size="md">默认标签</Tag>
        <Tag shapeType="rounded" size="md">
          圆角标签
        </Tag>
        <Tag variant="solid" size="md">
          深色直角标签
        </Tag>
        <Tag variant="solid" shapeType="rounded" size="md">
          深色圆角标签
        </Tag>
      </div>
    </div>
  );
}
