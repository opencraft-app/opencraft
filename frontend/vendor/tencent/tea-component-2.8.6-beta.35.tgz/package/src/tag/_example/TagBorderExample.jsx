import React from "react";
import { Tag } from "@tencent/tea-component";

export default function TagBorderExample() {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
      <div style={{ display: "flex", gap: "8px" }}>
        <Tag variant="outlined">描边直角标签</Tag>
        <Tag variant="outlined" shapeType="rounded">
          描边圆角标签
        </Tag>
        <Tag>默认标签</Tag>
        <Tag shapeType="rounded">圆角标签</Tag>
        <Tag variant="solid">深色直角标签</Tag>
        <Tag variant="solid" shapeType="rounded">
          深色圆角标签
        </Tag>
      </div>
      <div style={{ display: "flex", gap: "8px" }}>
        <Tag theme="success" variant="outlined">
          描边直角标签
        </Tag>
        <Tag theme="success" variant="outlined" shapeType="rounded">
          描边圆角标签
        </Tag>
        <Tag theme="success">默认标签</Tag>
        <Tag theme="success" shapeType="rounded">
          圆角标签
        </Tag>
        <Tag theme="success" variant="solid">
          深色直角标签
        </Tag>
        <Tag theme="success" variant="solid" shapeType="rounded">
          深色圆角标签
        </Tag>
      </div>
    </div>
  );
}
