import React from "react";
import { Breadcrumb } from "@tencent/tea-component";

export default function BreadcrumbResponseExample() {
  return (
    <>
      <Breadcrumb responsable>
        <Breadcrumb.Item>
          <a href="https://cloud.tencent.com/" target="_blank" rel="noreferrer">
            Application 1
          </a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="https://cloud.tencent.com/" target="_blank" rel="noreferrer">
            Application 2
          </a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="https://cloud.tencent.com/" target="_blank" rel="noreferrer">
            Application 3
          </a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="https://cloud.tencent.com/" target="_blank" rel="noreferrer">
            Application 4
          </a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="https://cloud.tencent.com/" target="_blank" rel="noreferrer">
            Application 5
          </a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="https://cloud.tencent.com/" target="_blank" rel="noreferrer">
            Application 6
          </a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="https://cloud.tencent.com/" target="_blank" rel="noreferrer">
            Application 7
          </a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="https://cloud.tencent.com/" target="_blank" rel="noreferrer">
            Application 8
          </a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>About</Breadcrumb.Item>
      </Breadcrumb>
    </>
  );
}
