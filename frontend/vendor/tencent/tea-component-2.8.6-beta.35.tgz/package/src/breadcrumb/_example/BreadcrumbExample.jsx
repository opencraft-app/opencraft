import React from "react";
import { Breadcrumb } from "@tencent/tea-component";

export default function BreadcrumbExample() {
  return (
    <>
      <Breadcrumb>
        <Breadcrumb.Item>
          <a href="">Application 1</a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="">Application 2</a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="">Application 3</a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="">Application 4</a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="">Application 5</a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="">Application 6</a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="">Application 7</a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <a href="">Application 8</a>
        </Breadcrumb.Item>
        <Breadcrumb.Item>About</Breadcrumb.Item>
      </Breadcrumb>
    </>
  );
}
