import React from "react";
import { Timeline } from "@tencent/tea-component";

export default function TimelineTimeLeftExample() {
  return (
    <Timeline mode="vertical-time-left">
      <Timeline.Item label="2020-02-02" title="事件一">
        新特性发布
      </Timeline.Item>
      <Timeline.Item label="2020-02-03" title="事件二">
        新特性发布
      </Timeline.Item>
      <Timeline.Item label="2020-02-04" title="事件三">
        新特性发布
      </Timeline.Item>
    </Timeline>
  );
}
