import React from "react";
import { Timeline } from "@tencent/tea-component";

export default function TimelineExample() {
  return (
    <Timeline>
      <Timeline.Item label="2020-02-02">事件一</Timeline.Item>
      <Timeline.Item label="2020-02-03">事件二</Timeline.Item>
      <Timeline.Item label="2020-02-04">事件三</Timeline.Item>
    </Timeline>
  );
}
