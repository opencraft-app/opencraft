import React from "react";
import { Icon, Timeline } from "@tencent/tea-component";
import { useConfig } from "../../_util/config-context";

export default function TimelineThemeExample() {
  const { classPrefix } = useConfig();
  return (
    <Timeline mode="vertical" dashedLine>
      <Timeline.Item label="2020-02-02" title="事件一">
        新特性发布
      </Timeline.Item>
      <Timeline.Item label="2020-02-03" title="事件二" theme="success">
        新特性发布
      </Timeline.Item>
      <Timeline.Item label="2020-02-04" title="事件三" theme="danger">
        新特性发布
      </Timeline.Item>
      <Timeline.Item label="事件异常" icon={<Icon type="error" />} />

      <Timeline.Item label="事件处理中 ..." icon={<Icon type="loading" />} />
    </Timeline>
  );
}
