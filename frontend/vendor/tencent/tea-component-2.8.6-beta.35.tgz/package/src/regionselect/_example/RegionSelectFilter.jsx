import React, { useState } from "react";
import {
  RegionSelect,
  RegionPanel,
  RegionOption,
  Status,
  Card,
} from "@tencent/tea-component";

const data = [
  {
    groups: [
      {
        name: "中国",
        regions: [
          { value: "gz", label: "广州", num: 20 },
          { value: "sh", label: "上海", num: 20, dot: true },
          { value: "hk", label: "香港" },
        ],
      },
      {
        name: "游戏专区",
        regions: [{ value: "bj", label: "北京" }],
      },
    ],
  },
  {
    groups: [
      {
        name: "亚洲",
        regions: [
          { value: "ia", label: "印度", num: 20 },
          { value: "ko", label: "韩国" },
          { value: "ta", label: "泰国" },
          { value: "sg", label: "新加坡" },
          { value: "jp", label: "日本" },
        ],
      },
    ],
  },
  {
    groups: [
      {
        name: "北美洲",
        regions: [
          { value: "gg", label: "硅谷" },
          { value: "dld", label: "多伦多" },
        ],
      },
    ],
  },
];

export default function RegionSelectFilter() {
  const [region, setRegion] = useState("gz");

  const { Head, Column, Group } = RegionPanel;

  return (
    <RegionSelect
      value={region}
      onChange={value => setRegion(value)}
      moreInfo={region === "all" ? null : "其它地域 20"}
      shortcut={{
        cacheKey: "tea-region-select-demo",
      }}
      supportFilter
    >
      <RegionPanel>
        <Head>全部地域</Head>
        {data.map((column, columnIndex) => (
          <Column key={columnIndex}>
            {column.groups.map((group, groupIndex) => (
              <Group key={groupIndex} name={group.name}>
                {group.regions.map((region, regionIndex) => (
                  <RegionOption
                    key={regionIndex}
                    value={region.value}
                    num={region.num}
                    dot={region.dot}
                  >
                    {region.label}
                  </RegionOption>
                ))}
              </Group>
            ))}
          </Column>
        ))}
      </RegionPanel>
    </RegionSelect>
  );
}
