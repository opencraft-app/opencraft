# AutoComplete 自动补全

提供输入类组件自动补全功能。

## 使用示例

<!-- <Half> -->

### 基本用法

[Example: AutoComplete](./_example/AutoCompleteExample.jsx)

### 异步加载

[Example: AutoCompleteAsync](./_example/AutoCompleteAsyncExample.jsx)

### 输入非空时展示

[Example: AutoCompleteOpen](./_example/AutoCompleteOpenExample.jsx)

<!-- </Half> -->

## 组件属性

[Interface: AutoCompleteProps](./AutoComplete.tsx)
