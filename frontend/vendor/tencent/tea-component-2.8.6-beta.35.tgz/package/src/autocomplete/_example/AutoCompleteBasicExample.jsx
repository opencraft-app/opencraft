import React, { useState } from "react";
import { AutoComplete, Input } from "@tencent/tea-component";

const options = [
  { groupKey: "fruit", value: "strawberry", text: "草莓", tooltip: "甜甜甜" },
  { groupKey: "fruit", value: "cranberry", text: "红莓", disabled: true },
  { groupKey: "fruit", value: "raspberry", text: "树莓" },
  { groupKey: "drink", value: "coca-cola", text: "可口可乐" },
  {
    groupKey: "drink",
    value: "pepsi-cola",
    text: "百事可乐",
    tooltip: "百事可乐为什么比可口可乐好喝？",
  },
];

const groups = {
  fruit: "水果",
  drink: "饮料",
};

export default function AutoCompleteExample() {
  const [inputValue, setInputValue] = useState("");

  return (
    <AutoComplete
      options={options.filter(({ text }) => text.includes(inputValue))}
      groups={groups}
      keyword={inputValue}
      tips="没有匹配的标签"
      onChange={value => {
        const option = options.find(opt => opt.value === value);
        setInputValue(option.text);
        console.log(value);
      }}
      onScrollBottom={event => console.log(event)}
    >
      {ref => (
        <Input
          ref={ref}
          value={inputValue}
          onChange={value => setInputValue(value)}
        />
      )}
    </AutoComplete>
  );
}
