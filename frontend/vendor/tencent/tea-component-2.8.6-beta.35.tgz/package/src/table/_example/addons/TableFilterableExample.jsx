import React, { useState } from "react";
import {
  Input,
  Table,
  DatePicker,
  // Bubble,
  // Icon,
  // ExternalLink,
} from "@tencent/tea-component";
import moment from "moment";

const { RangePicker } = DatePicker;

const { filterable } = Table.addons;

const records = [
  { name: "Mario", stage: "teenager", marriage: 0, birthDate: "2025-06-15" },
  { name: "Luigi", stage: "youth", marriage: 0, birthDate: "2025-07-23" },
  { name: "Koopa", stage: "youth", marriage: 1, birthDate: "2025-08-08" },
  { name: "Yoshi", stage: "youth", marriage: 0, birthDate: "2025-09-30" },
  { name: "Link", stage: "middle-aged", marriage: 2, birthDate: "2025-06-05" },
  { name: "Zelda", stage: "middle-aged", marriage: 1, birthDate: "2025-07-17" },
  { name: "Wario", stage: "elder", marriage: 3, birthDate: "2025-08-22" },
  { name: "Pikachu", stage: "elder", marriage: 4, birthDate: "2025-09-10" },
];
const MARRIAGE_TEXT = ["未婚", "已婚", "离异", "再婚", "丧偶"];
const STAGE_TEXT = {
  teenager: "少年",
  youth: "青年",
  "middle-aged": "中年",
  elder: "老年",
};
const ALL_VALUE = "__ALL__";

export default function TableAddonExample() {
  // 当前排序列
  // 姓名排序值
  const [name, setName] = useState(null);
  // 年龄段筛选值
  const [stage, setStage] = useState(ALL_VALUE);
  // 婚姻状态筛选值
  const [marriages, setMarriages] = useState([]);
  // 出生日期范围筛选值
  const [birthDateRange, setBirthDateRange] = useState(null);

  let filteredRecords = records.slice();

  // 根据年龄段筛选
  if (stage !== ALL_VALUE) {
    filteredRecords = filteredRecords.filter(x => x.stage === stage);
  }

  // 根据婚姻状态
  if (marriages.length > 0) {
    filteredRecords = filteredRecords.filter(
      record => marriages.indexOf(record.marriage) > -1
    );
  }

  // 根据姓名筛选
  if (name) {
    filteredRecords = filteredRecords.filter(
      x => x.name.toLocaleLowerCase() === name.toLocaleLowerCase()
    );
  }

  // 根据出生日期范围筛选
  if (birthDateRange && birthDateRange.length === 2) {
    const [startDate, endDate] = birthDateRange;
    filteredRecords = filteredRecords.filter(record => {
      const recordDate = moment(record.birthDate);
      return (
        recordDate.isSameOrAfter(startDate) &&
        recordDate.isSameOrBefore(endDate)
      );
    });
  }

  return (
    <Table
      records={filteredRecords || []}
      recordKey={x => x.name}
      columns={[
        { key: "name", header: "姓名" },
        {
          key: "stage",
          header: "年龄段",
          // header: () => (
          //   <>
          //     年龄段
          //     <Bubble
          //       content={
          //         <>
          //           <ExternalLink href="https://cloud.tencent.com">
          //             111
          //           </ExternalLink>
          //         </>
          //       }
          //     >
          //       <Icon type="info" />
          //     </Bubble>
          //   </>
          // ),
          render: x => STAGE_TEXT[x.stage],
        },
        {
          key: "birthDate",
          header: "出生年月",
          render: x => x.birthDate,
        },
        {
          key: "marriage",
          header: "婚姻状态",
          render: x => MARRIAGE_TEXT[x.marriage],
        },
      ]}
      addons={[
        // 对 name 列增加排序支持
        filterable({
          type: "custom",
          column: "name",
          renderColumnComponent: ({ onChange: handleChange, value }) => {
            return (
              <Input
                onChange={handleChange}
                placeholder="请输入姓名"
                // 重置后，统一为 null
                value={value || ""}
              />
            );
          },
          value: name, // 重置后，统一为 null
          onChange: value => {
            setName(value);
          },
        }),
        // 对 age 列增加单选过滤支持
        filterable({
          type: "single",
          column: "stage",
          value: stage,
          onChange: value => setStage(value),
          // 增加 "全部" 选项
          all: {
            value: ALL_VALUE,
            text: "全部",
          },
          // 选项列表
          options: [
            { value: "teenager", text: "少年" },
            { value: "youth", text: "青年" },
            { value: "middle-aged", text: "中年" },
            { value: "elder", text: "老年" },
          ],
        }),

        // 对 marriage 列增加多选过滤支持
        filterable({
          type: "multiple",
          column: "marriage",
          searchable: true,
          selectFilteredOnly: true,
          value: marriages.map(x => String(x)),
          onChange: value => {
            setMarriages(value.map(x => Number(x)));
          },
          all: {
            value: ALL_VALUE,
            text: "全部",
          },
          options: MARRIAGE_TEXT.map((text, index) => ({
            value: index.toString(),
            text,
          })),
        }),

        // 对 birthDate 列增加日期范围过滤支持
        filterable({
          type: "custom",
          column: "birthDate",
          renderColumnComponent: ({ onChange: handleChange, value }) => {
            return (
              <RangePicker
                defaultValue={[moment("2025-06-01"), moment("2025-11-11")]}
                value={value || []}
                onChange={handleChange}
                onOpenChange={open => console.log(open ? "open" : "close")}
              />
            );
          },
          value: birthDateRange,
          onChange: value => {
            setBirthDateRange(value);
          },
        }),
      ]}
    />
  );
}
