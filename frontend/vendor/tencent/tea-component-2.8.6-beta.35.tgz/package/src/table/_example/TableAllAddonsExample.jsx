import React, { useState, useMemo } from "react";
import { Table, Button, Modal } from "@tencent/tea-component";

// 导入所有插件
const {
  scrollable,
  sticky,
  groupable,
  mergeable,
  columnsResizable,
  sortable,
  filterable,
  expandable,
  indentable,
  selectable,
  draggable,
  autotip,
  rowtooltip,
  removeable,
  stylize,
  injectable,
  pageable,
} = Table.addons;

// 模拟数据
const generateMockData = () => {
  const departments = [
    { id: "dept1", name: "技术部", type: "department" },
    { id: "dept2", name: "产品部", type: "department" },
    { id: "dept3", name: "运营部", type: "department" },
  ];

  const employees = [
    // 技术部员工
    {
      id: "emp1",
      name: "张三",
      age: 28,
      position: "前端工程师",
      salary: 15000,
      status: "active",
      department: "dept1",
      level: 1,
    },
    {
      id: "emp2",
      name: "李四",
      age: 32,
      position: "后端工程师",
      salary: 18000,
      status: "active",
      department: "dept1",
      level: 1,
    },
    {
      id: "emp3",
      name: "王五",
      age: 35,
      position: "架构师",
      salary: 25000,
      status: "inactive",
      department: "dept1",
      level: 2,
    },

    // 产品部员工
    {
      id: "emp4",
      name: "赵六",
      age: 29,
      position: "产品经理",
      salary: 16000,
      status: "active",
      department: "dept2",
      level: 1,
    },
    {
      id: "emp5",
      name: "钱七",
      age: 26,
      position: "UI设计师",
      salary: 12000,
      status: "active",
      department: "dept2",
      level: 1,
    },

    // 运营部员工
    {
      id: "emp6",
      name: "孙八",
      age: 30,
      position: "运营专员",
      salary: 10000,
      status: "active",
      department: "dept3",
      level: 1,
    },
    {
      id: "emp7",
      name: "周九",
      age: 33,
      position: "运营总监",
      salary: 20000,
      status: "inactive",
      department: "dept3",
      level: 2,
    },
    {
      id: "emp8",
      name: "王十",
      age: 30,
      position: "CEO",
      salary: 50000,
      status: "active",
      department: null, // 不属于任何部门，独立显示
      level: 2,
      type: "independent", // 标记为独立员工
    },
    {
      id: "emp9",
      name: "陈一",
      age: 25,
      position: "顾问",
      salary: 20000,
      status: "active",
      department: null,
      level: 1,
      type: "independent",
    },
    {
      id: "emp10",
      name: "林二",
      age: 45,
      position: "外部专家",
      salary: 35000,
      status: "inactive",
      department: null,
      level: 2,
      type: "independent",
    },
    {
      id: "emp11",
      name: "张三丰",
      age: 28,
      position: "自由职业者",
      salary: 15000,
      status: "active",
      department: null,
      level: 1,
      type: "independent",
    },
  ];

  return [...departments, ...employees];
};

// 状态文本映射
const STATUS_TEXT = {
  active: "在职",
  inactive: "离职",
};

export default function TableAllAddonsExample() {
  // 基础数据状态
  const [records, setRecords] = useState(generateMockData());
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);

  // 排序状态
  const [sorts, setSorts] = useState([]);

  // 筛选状态
  const [statusFilter, setStatusFilter] = useState("all");
  const [levelFilter, setLevelFilter] = useState([]);

  // 展开状态
  const [expandedKeys, setExpandedKeys] = useState(["dept1"]);

  // 选择状态
  const [selectedKeys, setSelectedKeys] = useState([]);

  // 分页状态
  const [pageIndex, setPageIndex] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // 列配置状态
  const [columns, setColumns] = useState([
    {
      key: "name",
      header: "姓名/部门",
      width: 200,
      render: record => record.name,
    },
    {
      key: "age",
      header: "年龄",
      width: 80,
      render: record => (record.type === "department" ? null : record.age),
    },
    {
      key: "position",
      header: "职位",
      width: 150,
      render: record => (record.type === "department" ? null : record.position),
    },
    {
      key: "salary",
      header: "薪资",
      width: 120,
      render: record =>
        record.type === "department" ? null : `${record.salary}元`,
    },
    {
      key: "status",
      header: "状态",
      width: 100,
      render: record =>
        record.type === "department" ? null : STATUS_TEXT[record.status],
    },
    {
      key: "level",
      header: "级别",
      width: 100,
      render: record => {
        if (record.type === "department") {
          return null;
        }
        return record.level === 1 ? "普通员工" : "管理层";
      },
    },
    {
      key: "actions",
      header: "操作",
      width: 150,
      render: record =>
        record.type === "department" ? null : (
          <Button type="link" size="sm">
            编辑
          </Button>
        ),
    },
  ]);

  // 构建层级关系
  const relations = useMemo(() => {
    /**
     * @type {import('@tencent/tea-component/lib/checktree').CheckTreeRelation}
     */
    const rel = {};
    records.forEach(record => {
      // 只有属于部门的员工才建立层级关系，独立员工不参与层级结构
      if (
        record.type !== "department" &&
        record.department &&
        record.type !== "independent"
      ) {
        rel[record.id] = record.department;
      }
    });
    return rel;
  }, [records]);

  // 表头分组配置
  const headerGroups = [
    {
      key: "work",
      title: "工作信息",
      children: ["salary", "status", "level"],
    },
  ];

  // 处理数据筛选 - 显示部门和独立员工
  const filteredRecords = useMemo(() => {
    // 主表格显示部门数据和独立员工（不属于任何部门的员工）
    let filtered = records.filter(
      record =>
        record.type === "department" ||
        record.type === "independent" ||
        record.department === null
    );

    // 对独立员工应用状态和级别筛选
    filtered = filtered.filter(record => {
      // 部门记录始终显示
      if (record.type === "department") {
        return true;
      }

      // 对独立员工应用筛选条件
      let shouldShow = true;

      // 状态筛选
      if (statusFilter !== "all" && record.status !== statusFilter) {
        shouldShow = false;
      }

      // 级别筛选
      if (
        levelFilter.length > 0 &&
        !levelFilter.includes(String(record.level))
      ) {
        shouldShow = false;
      }

      return shouldShow;
    });

    return filtered;
  }, [records, statusFilter, levelFilter]);

  // 获取所有员工数据用于展开显示
  const allEmployees = useMemo(() => {
    let employees = records.filter(record => record.type !== "department");

    // 对员工数据应用筛选
    if (statusFilter !== "all") {
      employees = employees.filter(emp => emp.status === statusFilter);
    }

    if (levelFilter.length > 0) {
      employees = employees.filter(emp =>
        levelFilter.includes(String(emp.level))
      );
    }

    return employees;
  }, [records, statusFilter, levelFilter]);

  // 处理排序
  const sortedRecords = useMemo(() => {
    if (sorts.length === 0) {
      return filteredRecords;
    }
    return [...filteredRecords].sort(sortable.comparer(sorts));
  }, [filteredRecords, sorts]);

  // 处理拖拽
  const handleDragEnd = newRecords => {
    // 确保拖拽后的数据结构完整性
    // 只允许拖拽主表格中显示的记录（部门和独立员工）
    const draggedMainRecords = newRecords.filter(
      record =>
        record.type === "department" ||
        record.type === "independent" ||
        record.department === null
    );

    // 保留所有原始的员工数据（属于部门的员工）
    const departmentEmployees = records.filter(
      record =>
        record.type !== "department" &&
        record.department &&
        record.type !== "independent"
    );

    // 重新组合完整的数据
    const completeRecords = [...draggedMainRecords, ...departmentEmployees];

    // 更新记录顺序
    setRecords(completeRecords);

    // 重置展开状态，因为拖拽可能改变了数据结构
    // 用户需要重新展开他们想要查看的部门
    setExpandedKeys([]);
  };

  // 处理删除
  const handleRemove = rowKey => {
    Modal.confirm({
      message: "确认删除",
      description: "确定要删除这条记录吗？",
      onOk: () => {
        setRecords(prev => prev.filter(record => record.id !== rowKey));
      },
    });
  };

  // 处理分页
  const handlePageChange = ({ pageIndex, pageSize }) => {
    setPageIndex(pageIndex);
    setPageSize(pageSize);
  };

  // 模拟加载
  const handleRefresh = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setRecords(generateMockData());
    }, 2000);
  };

  // 模拟错误
  const handleError = () => {
    setError(true);
    setTimeout(() => setError(false), 3000);
  };

  return (
    <div style={{ padding: 20 }}>
      <div style={{ marginBottom: 16 }}>
        <Button onClick={handleRefresh} disabled={loading}>
          刷新数据
        </Button>
        <Button onClick={handleError} style={{ marginLeft: 8 }}>
          模拟错误
        </Button>
        <span style={{ marginLeft: 16 }}>已选择: {selectedKeys.length} 项</span>
      </div>

      {/* 调试信息 */}
      <div style={{ marginBottom: 16, fontSize: 12, color: "#666" }}>
        <div>原始数据数量: {records.length}</div>
        <div>筛选后数据数量: {filteredRecords.length}</div>
        <div>排序后数据数量: {sortedRecords.length}</div>
        <div>列配置数量: {columns.length}</div>
      </div>

      <Table
        bordered="all"
        records={sortedRecords}
        recordKey="id"
        columns={columns}
        rowDisabled={record => record.status === "inactive"}
        rowClassName={record =>
          record.type === "department" ? "department-row" : "employee-row"
        }
        addons={[
          stylize({
            className: "my-table",
            style: { outline: "2px solid yellow" },
            headClassName: "my-head",
            headStyle: { border: "2px solid green" },
            bodyClassName: "my-body",
          }),
          columnsResizable({
            onResizeEnd: columns => {
              setColumns(columns);
            },
            minWidth: 100,
            maxWidth: 1000,
          }),
          scrollable({
            maxHeight: 500,
            minWidth: 1000,
          }),

          sticky({
            header: true,
            scrollBar: true,
          }),

          sortable({
            columns: ["name", "age", "salary"],
            value: sorts,
            onChange: setSorts,
          }),

          filterable({
            type: "single",
            column: "status",
            value: statusFilter,
            onChange: setStatusFilter,
            all: { value: "all", text: "全部状态" },
            options: [
              { value: "active", text: "在职" },
              { value: "inactive", text: "离职" },
            ],
          }),

          filterable({
            type: "multiple",
            column: "level",
            value: levelFilter,
            onChange: setLevelFilter,
            all: { value: "all", text: "全部级别" },
            options: [
              { value: "1", text: "普通员工" },
              { value: "2", text: "管理层" },
            ],
          }),

          selectable({
            value: selectedKeys,
            onChange: setSelectedKeys,
            rowSelect: true,
          }),

          autotip({
            isLoading: loading,
            isError: error,
            foundKeyword:
              statusFilter !== "all" ? STATUS_TEXT[statusFilter] : undefined,
            emptyText: "暂无员工数据",
          }),

          rowtooltip({
            tooltip: record => {
              if (record.type === "department") {
                const empCount = records.filter(
                  emp => emp.department === record.id
                ).length;
                return `${record.name} - 共${empCount}名员工`;
              }
              return `${record.name} - ${record.position} - ${record.salary}元/月`;
            },
          }),

          injectable({
            row: (props, { record }) => {
              if (!record) {
                return props;
              }

              return {
                ...props,
                onClick: e => {
                  console.log("Row clicked:", record);
                  if (props.onClick) props.onClick(e);
                },
                style: {
                  ...props.style,
                  backgroundColor:
                    record.type === "department"
                      ? "#f0f9ff"
                      : props.style?.backgroundColor,
                },
              };
            },
            cell: (props, { record, column }) => {
              if (!record || !column) {
                return props;
              }

              if (column.key === "salary" && record.type !== "department") {
                return {
                  ...props,
                  style: {
                    ...props.style,
                    color: record.salary > 15000 ? "#52c41a" : "#1890ff",
                    fontWeight: "bold",
                  },
                };
              }
              return props;
            },
          }),

          expandable({
            expandedKeys,
            onExpandedKeysChange: setExpandedKeys,
            shouldRecordExpandable: record => {
              // 只有部门且 expandable 不为 false 的记录才可展开
              return (
                record.type === "department" && record.expandable !== false
              );
            },
            expand: record => {
              if (record.type === "department" && record.expandable !== false) {
                // 确保每次都从最新的 allEmployees 中查找
                const employees = allEmployees.filter(
                  emp => emp.department === record.id
                );
                console.log(`展开部门 ${record.name}，找到员工:`, employees);
                return employees;
              }
              return null;
            },
            // 明确指定目标列
            targetColumnKey: "name",
          }),

          indentable({
            targetColumnKey: "name",
            relations,
            indent: 24,
          }),

          draggable({
            onDragEnd: handleDragEnd,
          }),

          removeable({
            onRemove: handleRemove,
          }),

          groupable({
            headerGroups,
          }),

          // 和多个插件冲突，如expandable、sortable，建议不要同时使用
          // mergeable({
          //   colSpan: (columnIndex, recordIndex, record, column) => {
          //     // 只对状态列进行合并
          //     if (
          //       column &&
          //       column.key === "status" &&
          //       record &&
          //       record.type !== "department"
          //     ) {
          //       const currentStatus = record.status;
          //       let spanCount = 1;

          //       // 向下查找相同状态的连续记录
          //       for (let i = recordIndex + 1; i < sortedRecords.length; i++) {
          //         const nextRecord = sortedRecords[i];
          //         if (
          //           nextRecord &&
          //           nextRecord.type !== "department" &&
          //           nextRecord.status === currentStatus
          //         ) {
          //           spanCount += 1;
          //         } else {
          //           break;
          //         }
          //       }

          //       // 检查是否是合并区域的第一行
          //       let isFirstInGroup = true;
          //       for (let i = recordIndex - 1; i >= 0; i--) {
          //         const prevRecord = sortedRecords[i];
          //         if (
          //           prevRecord &&
          //           prevRecord.type !== "department" &&
          //           prevRecord.status === currentStatus
          //         ) {
          //           isFirstInGroup = false;
          //           break;
          //         } else if (prevRecord && prevRecord.type !== "department") {
          //           break;
          //         }
          //       }

          //       // 只有第一行返回合并数量，其他行返回0（被合并）
          //       return isFirstInGroup ? spanCount : 0;
          //     }
          //     return undefined;
          //   },
          // }),

          pageable({
            pageIndex,
            pageSize,
            recordCount: sortedRecords.length,
            onPagingChange: handlePageChange,
            pageSizeOptions: [5, 10, 20],
          }),
        ]}
      />

      <style
        dangerouslySetInnerHTML={{
          __html: `
          /* 部门行样式 */
          .department-row {
            background-color: #f0f9ff !important;
            font-weight: bold;
          }

          /* 员工行悬停效果 */
          .employee-row:hover {
            background-color: #fafafa !important;
          }
          
          /* 确保薪资列的颜色样式生效 */
          .tea-table td[data-column="salary"] {
            font-weight: bold !important;
          }
        `,
        }}
      />
    </div>
  );
}
