import React, { useState } from "react";
import { Table, Icon, StatusTip } from "@tencent/tea-component";

const { selectable } = Table.addons;

const cvmList = [
  {
    instanceId: "ins-4m99aio4",
    instanceName: "Hongkong VPN",
    status: "running",
    area: "香港一区",
    modal: "标准型 S1",
    publicIP: "119.28.142.24",
    privateIP: "10.144.77.75",
  },
  {
    instanceId: "ins-b3fakzpc",
    instanceName: "Guangzhou 4",
    status: "running",
    area: "广州四区",
    modal: "标准型 S5",
    publicIP: "106.52.244.57",
    privateIP: "172.16.18.40",
  },
  {
    instanceId: "ins-aucm8su6",
    instanceName: "Guangzhou 2",
    status: "running",
    area: "广州二区",
    modal: "标准型 S5",
    publicIP: "106.52.244.66",
    privateIP: "172.16.18.44",
  },
  {
    instanceId: "ins-3e7y5ww3",
    instanceName: "Guangzhou 3",
    status: "stopped",
    area: "广州三区",
    modal: "标准型 S1",
    publicIP: "112.30.42.241",
    privateIP: "10.121.72.123",
  },
];

export default function TableAddonExample() {
  const [selectedKeys, setSelectedKeys] = useState([]);

  return (
    <Table
      records={cvmList}
      recordKey="instanceId"
      rowDisabled={record => record.status === "stopped"}
      columns={[
        {
          key: "instance",
          header: "ID/实例名",
          render: cvm => (
            <>
              <p>
                <a>{cvm.instanceId}</a>
              </p>
              <p>{cvm.instanceName}</p>
            </>
          ),
        },
        {
          key: "status",
          header: "状态",
          width: 100,
          render: cvm => {
            if (cvm.status === "running") {
              return (
                <StatusTip.InstanceTip status="running">
                  运行中
                </StatusTip.InstanceTip>
              );
            }
            if (cvm.status === "stopped") {
              return (
                <StatusTip.InstanceTip status="closed">
                  已关机
                </StatusTip.InstanceTip>
              );
            }
            return cvm.status;
          },
        },
        {
          key: "area",
          header: "可用区域",
        },
        {
          key: "modal",
          header: "主机型号",
        },
        {
          key: "publicIP",
          header: "IP 地址",
          align: "right",
        },
      ]}
      addons={[
        selectable({
          value: selectedKeys,
          onChange: (keys, context) => {
            console.log(keys, context);
            setSelectedKeys(keys);
          },
          rowSelect: true,
          render: (element, { disabled }) => {
            return disabled ? <Icon type="loading" /> : element;
          },
        }),
      ]}
    />
  );
}
