import React, { useCallback, useMemo, useState } from "react";
import { Table, Input } from "@tencent/tea-component";

export default function TableEditExample() {
  const [records, setRecords] = useState([
    {
      id: "1",
      name: "Test",
      desc: "Makabaka",
      desc2: "fdas",
    },
    {
      id: "2",
      name: "Test2",
      desc: "Wuxidixi",
      desc2: "qwet",
    },
  ]);

  const handleSave = useCallback(
    record => {
      setRecords(prevRecords => {
        const newRecords = [...prevRecords];
        const index = newRecords.findIndex(i => record.id === i.id);
        newRecords.splice(index, 1, {
          ...prevRecords[index],
          ...record,
        });
        return newRecords;
      });
    },
    [setRecords]
  );

  const columns = useMemo(() => {
    return [
      {
        key: "id",
        header: "ID",
        shouldCellUpdate: "id",
      },
      {
        key: "name",
        header: "姓名",
        shouldCellUpdate: "name",
        render: record => (
          <Input
            value={record.name}
            onChange={value => {
              handleSave({
                ...record,
                name: value,
              });
            }}
          />
        ),
      },
      {
        key: "desc",
        header: "描述",
        shouldCellUpdate: "desc",
        render: record => (
          <Input
            value={record.desc}
            onChange={value => {
              handleSave({
                ...record,
                desc: value,
              });
            }}
          />
        ),
      },
      {
        key: "desc2",
        header: "描述二",
        shouldCellUpdate: (record, prevRecord) =>
          record.desc2 !== prevRecord.desc2,
        render: record => (
          <Input
            value={record.desc2}
            onChange={value => {
              handleSave({
                ...record,
                desc2: value,
              });
            }}
          />
        ),
      },
    ];
  }, [handleSave]);

  return <Table records={records} recordKey="id" columns={columns} />;
}
