import React from "react";
import {
  Table,
  Justify,
  Button,
  SearchBox,
  Card,
  Layout,
  Bubble,
  Icon,
  StatusTip,
} from "@tencent/tea-component";

const { Body, Content } = Layout;

const cvmList = new Array(100).fill(0).map((_, index) => ({
  instanceId: `ins-3e7y5ww3${String(index)}`,
  instanceName: "Guangzhou Test",
  status: "stopped",
  area: "广州三区",
  modal: "标准型 S1",
  publicIP: "112.30.42.241",
  privateIP: "10.121.72.123",
}));

function TableStickyExample() {
  return (
    <Layout>
      <Body>
        <Content className="table-layout-demo">
          <Content.Body>
            <Table.ActionPanel>
              <Justify
                left={
                  <>
                    <Button type="primary">新建</Button>
                    <Button>开机</Button>
                  </>
                }
                right={
                  <>
                    <SearchBox />
                    <Button icon="setting" />
                    <Button icon="refresh" />
                    <Button icon="download" />
                  </>
                }
              />
            </Table.ActionPanel>
            <Card>
              <Table
                verticalTop
                records={cvmList}
                recordKey="instanceId"
                rowClassName={record => record.status}
                addons={[
                  Table.addons.scrollable({ minWidth: 3000 }),
                  // Table.addons.pageable({
                  //   pageSize: 20,
                  // }),
                  Table.addons.sticky({
                    header: true,
                    scrollBar: true,
                    pagination: true,
                  }),
                ]}
                columns={[
                  {
                    key: "instance",
                    header: "ID/实例名",
                    render: cvm => (
                      <>
                        <p>
                          <a>{cvm.instanceId}</a>
                        </p>
                        <p>{cvm.instanceName}</p>
                      </>
                    ),
                  },
                  {
                    key: "status",
                    header: () => (
                      <>
                        状态
                        <Bubble content="状态描述">
                          <Icon type="info" />
                        </Bubble>
                      </>
                    ),
                    width: 100,
                    render: cvm => {
                      if (cvm.status === "running") {
                        return (
                          <StatusTip.InstanceTip status="running">
                            运行中
                          </StatusTip.InstanceTip>
                        );
                      }
                      if (cvm.status === "stopped") {
                        return (
                          <StatusTip.InstanceTip status="closed">
                            已关机
                          </StatusTip.InstanceTip>
                        );
                      }
                      return cvm.status;
                    },
                  },
                  {
                    key: "area",
                    header: "可用区域",
                  },
                  {
                    key: "modal",
                    header: "主机型号",
                  },
                  {
                    key: "ip",
                    header: "IP 地址",
                    align: "right",
                    render: cvm => (
                      <>
                        <p>{cvm.publicIP} (公)</p>
                        <p>{cvm.privateIP} (内)</p>
                      </>
                    ),
                  },
                ]}
              />
            </Card>
          </Content.Body>
        </Content>
      </Body>
    </Layout>
  );
}

export default function Demo() {
  return (
    <section
      style={{
        height: 520,
        border: "1px solid #ddd",
      }}
    >
      <TableStickyExample />
    </section>
  );
}
