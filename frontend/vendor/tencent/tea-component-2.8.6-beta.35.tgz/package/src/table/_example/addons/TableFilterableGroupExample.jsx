import React, { useState } from "react";
import { Table } from "@tencent/tea-component";

const { filterable } = Table.addons;

const records = [
  { name: "Mario", category: "game", subcategory: "platform", rating: 5 },
  { name: "Luigi", category: "game", subcategory: "platform", rating: 4 },
  { name: "Zelda", category: "game", subcategory: "adventure", rating: 5 },
  { name: "Link", category: "game", subcategory: "adventure", rating: 5 },
  { name: "Pikachu", category: "anime", subcategory: "pokemon", rating: 4 },
  { name: "Naruto", category: "anime", subcategory: "ninja", rating: 4 },
  { name: "Goku", category: "anime", subcategory: "fighter", rating: 5 },
  { name: "Luffy", category: "anime", subcategory: "pirate", rating: 4 },
];

const ALL_VALUE = "__ALL__";

export default function TableFilterableGroupExample() {
  const [selectedCategories, setSelectedCategories] = useState([]);

  let filteredRecords = records.slice();

  // 根据分类筛选
  if (selectedCategories.length > 0) {
    filteredRecords = filteredRecords.filter(
      record => selectedCategories.indexOf(record.subcategory) > -1
    );
  }

  return (
    <Table
      records={filteredRecords || []}
      recordKey={x => x.name}
      columns={[
        { key: "name", header: "名称" },
        { key: "category", header: "主分类" },
        { key: "subcategory", header: "子分类" },
        { key: "rating", header: "评分" },
      ]}
      addons={[
        // 对 subcategory 列增加分组多选过滤支持
        filterable({
          type: "multiple",
          column: "subcategory",
          searchable: true,
          value: selectedCategories,
          onChange: value => {
            setSelectedCategories(value);
          },
          all: {
            value: ALL_VALUE,
            text: "全部",
          },
          // 分组配置
          groups: {
            game: "游戏类",
            anime: "动漫类",
          },
          // 选项列表，包含 groupKey
          options: [
            { groupKey: "game", value: "platform", text: "平台游戏" },
            { groupKey: "game", value: "adventure", text: "冒险游戏" },
            { groupKey: "anime", value: "pokemon", text: "宝可梦" },
            { groupKey: "anime", value: "ninja", text: "忍者" },
            { groupKey: "anime", value: "fighter", text: "格斗" },
            { groupKey: "anime", value: "pirate", text: "海贼" },
          ],
        }),
      ]}
    />
  );
}
