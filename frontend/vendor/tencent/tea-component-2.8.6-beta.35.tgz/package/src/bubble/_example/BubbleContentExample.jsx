import React from "react";
import { BubbleContent } from "@tencent/tea-component";

export default function BubbleExample() {
  const mr5 = { marginRight: 5 };
  return (
    <div style={{ position: "relative", height: 180 }}>
      <BubbleContent style={mr5}>气泡内容</BubbleContent>
      <BubbleContent style={mr5} error>
        异常提示
      </BubbleContent>
      <BubbleContent style={mr5} dark>
        反色提示
      </BubbleContent>
      <section
        style={{
          display: "block",
          marginTop: 12,
        }}
      >
        <BubbleContent style={mr5}>
          <strong>宽度自适应：</strong>
          科学家们发现太阳急速衰老膨胀，短时间内包括地球在内的整个太阳系都将被太阳所吞没。为了自救，人类提出一个名为“流浪地球”的大胆计划，即倾全球之力在地球表面建造上万座发动机和转向发动机，推动地球离开太阳系。
        </BubbleContent>
      </section>
    </div>
  );
}
