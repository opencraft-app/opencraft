import React from "react";
import { Form, Card, Button } from "@tencent/tea-component";

export default function FormReadOnlyExample() {
  return (
    <div className="example-stage">
      <Card>
        <Card.Body
          title="个人信息"
          operation={<Button type="link">修改</Button>}
        >
          <Form readonly>
            <Form.Item label="用户名">
              <Form.Text>Tea</Form.Text>
            </Form.Item>
            <Form.Item label="密码">
              <Form.Text>******</Form.Text>
            </Form.Item>
            <Form.Item label="生效时间">
              <Form.Text>2019-03-27</Form.Text>
            </Form.Item>
          </Form>
        </Card.Body>
      </Card>
    </div>
  );
}
