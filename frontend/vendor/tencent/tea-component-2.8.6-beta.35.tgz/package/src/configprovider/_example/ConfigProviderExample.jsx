/* eslint-disable */
import React from "react";
import { DatePicker, ConfigProvider } from "@tencent/tea-component";

import ja_JP from "@tencent/tea-component/lib/i18n/locale/ja_JP";

export default function ConfigProviderExample() {
  return (
    <ConfigProvider locale={ja_JP}>
      <DatePicker />
    </ConfigProvider>
  );
}
