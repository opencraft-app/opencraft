import React from "react";
import {
  Justify,
  Button,
  SearchBox,
  useClassNames,
} from "@tencent/tea-component";

export default function JustifyExample() {
  const { Margin } = useClassNames();
  return (
    <Justify
      left={
        <>
          <Button type="primary">新建</Button>
          <Button>开机</Button>
        </>
      }
      right={
        <>
          <SearchBox />
          <Button icon="setting" className={Margin.Left["1n"]} />
          <Button icon="refresh" className={Margin.Left["1n"]} />
          <Button icon="download" className={Margin.Left["1n"]} />
        </>
      }
    />
  );
}
