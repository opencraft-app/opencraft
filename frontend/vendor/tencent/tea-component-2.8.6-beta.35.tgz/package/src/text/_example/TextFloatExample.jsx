import React from "react";
import { Text } from "@tencent/tea-component";

export default () => (
  <>
    <div>
      <Text parent="div" float="left" bgTheme="success">
        左浮动
      </Text>
      <Text parent="div" float="right" bgTheme="danger">
        右浮动
      </Text>
    </div>
    <div style={{ clear: "both" }} />
    <Text parent="div" float="clear" bgTheme="warning">
      <Text parent="div" float="left" bgTheme="success">
        左浮动
      </Text>
      <Text parent="div" float="right" bgTheme="danger">
        右浮动
      </Text>
      清除浮动
    </Text>
  </>
);
