import React from "react";
import { Text, Bubble } from "@tencent/tea-component";

export default () => (
  <p>
    <Bubble content="解释说明">
      <Text theme="success" underline>
        23.44
      </Text>
    </Bubble>{" "}
    元/月
  </p>
);
