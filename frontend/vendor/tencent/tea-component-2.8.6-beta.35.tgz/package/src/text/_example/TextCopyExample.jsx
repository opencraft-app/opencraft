import React from "react";
import { Text } from "@tencent/tea-component";

export default () => (
  <>
    <Text copyable>复制内容</Text>
    <br />
    <Text copyable={{ text: "Hello" }}>另行提供复制内容</Text>
    <br />
    <div style={{ width: 200 }}>
      <Text copyable overflow tooltip>
        两只老虎爱跳舞，小兔子乖乖拔萝卜，我和小鸭子学走路，童年是最美的礼物。小螺号呀嘀嘀地吹，我学海鸥展翅飞，不怕风雨不怕累，快快把本领都学会。
      </Text>
    </div>
  </>
);
