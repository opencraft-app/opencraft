import React from "react";
import { Text } from "@tencent/tea-component";

export default () => (
  <>
    <div>
      <Text theme="text">text: 基本文字颜色，如表格中的文字</Text>
    </div>
    <div>
      <Text theme="secondary">secondary: 二级文本色</Text>
    </div>
    <div>
      <Text theme="label">label: 表单标签文本色、Bubble 文本色</Text>
    </div>
    <div>
      <Text theme="weak">weak: 弱化文本、禁用文本中使用</Text>
    </div>
    <div>
      <Text theme="strong">strong: 深颜色文字，用于控件、导航</Text>
    </div>
    <div>
      <Text theme="primary">primary: 主要颜色，会使用在超链接中</Text>
    </div>
    <div>
      <Text theme="success">success: 成功绿</Text>
    </div>
    <div>
      <Text theme="warning">warning: 告警黄</Text>
    </div>
    <div>
      <Text theme="danger">danger: 异常红</Text>
    </div>
    <div>
      <Text theme="cost">cost: 价格文本</Text>
    </div>
  </>
);
