import React from "react";
import { Text } from "@tencent/tea-component";

export default () => (
  <>
    <Text parent="div" align="left">
      文本左对齐
    </Text>
    <Text parent="div" align="center">
      文本居中对齐
    </Text>
    <Text parent="div" align="right">
      文本右对齐
    </Text>
    <Text parent="div" align="justify">
      文本两端对齐：当太阳面临死亡，地球即将被膨胀的太阳大气所淹没，“流浪地球”计划成为了唯一的解决方案：修建上万座行星发动机将地球推出太阳系运行轨道，前往距离地球最近、4.2光年的比邻星，展开2500年的旅程。在冰封的地球，人类躲避在地下城市，一个中国的课堂里，老师问同学什么叫希望？“希望，是这个时代像钻石一样珍贵的东西。”逃课的韩朵朵和主人翁叛逆少年刘启，本来只想离开地下城市到地表上去探险，却一步一步地卷入了拯救人类的最后任务之中。
    </Text>
  </>
);
