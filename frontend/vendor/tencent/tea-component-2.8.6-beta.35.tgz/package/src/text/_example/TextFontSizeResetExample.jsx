import React from "react";
import { Text, Justify } from "@tencent/tea-component";

export default () => (
  <Justify
    left={<Text reset>左侧文字</Text>}
    right={<Text reset>右侧文字</Text>}
  />
);
