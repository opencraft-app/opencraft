import React from "react";
import { Text } from "@tencent/tea-component";

export default () => (
  <>
    <Text parent="div" bgTheme="success">
      success: 成功绿
    </Text>
    <Text parent="div" bgTheme="warning">
      warning: 告警黄
    </Text>
    <Text parent="div" bgTheme="danger">
      danger: 异常红
    </Text>
  </>
);
