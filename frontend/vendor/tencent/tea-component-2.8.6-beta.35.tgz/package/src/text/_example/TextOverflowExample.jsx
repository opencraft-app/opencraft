import React from "react";
import { Text } from "@tencent/tea-component";

const commonStyle = { width: 100, background: "#ffffc1", margin: "5px 0" };

export default () => (
  <>
    <Text parent="div" style={commonStyle}>
      默认情况文本超过一行自动换行
    </Text>
    <Text parent="div" style={commonStyle} overflow tooltip>
      指定 overflow 自动截断过长的文本
    </Text>
    <Text parent="div" style={commonStyle} nowrap>
      指定 nowrap 不换行，溢出到宽度外
    </Text>
  </>
);
