import React from "react";
import { TextEllipsis } from "@tencent/tea-component";

export default () => (
  <>
    <div>
      <TextEllipsis ellipsis>
        舜发于畎亩之中，傅说举于版筑之闲，胶鬲举于鱼盐之中，管夷吾举于士，孙叔敖举于海，百里奚举于市。故天将降大任于是人也，必先苦其心志，劳其筋骨，饿其体肤，空乏其身，行拂乱其所为，所以动心忍性，曾益其所不能。人恒过，然后能改；困于心，衡于虑，而后作；徵于色，发于声，而后喻。入则无法家拂士，出则无敌国外患者，国恒亡。然后知生于忧患而死于安乐也。
      </TextEllipsis>
      <br />
      <TextEllipsis ellipsis={{ rows: 3, tooltip: true }}>
        Shun hair in the field drains, Fu said to lift in the version of the
        idle, Jiao Li lifted in the fish and salt, pipe Yiguo lifted in the Shi,
        Sun Shu Ao lifted in the sea, Thyme lifted in the city.Therefore, the
        heavens will send a great responsibility to be a person, must first
        suffer their hearts and minds, labor their muscles and bones, starve
        their bodies and skin, empty their bodies, line whisking what they do,
        so move the heart and patience, has benefited from its can not.People
        are always over, and then can be changed; trapped in the heart, weighing
        in the consideration, and then make; levied on the color, issued in the
        voice, and then metaphor.When you enter a country, there are no lawyers,
        and when you leave a country, there are no enemies or foreigners, and
        the country will always die.Then we know that we are born in sorrow and
        die in peace and happiness.
      </TextEllipsis>
      <hr />
      <TextEllipsis
        parent="div"
        ellipsis={{
          rows: 2,
          expandable: true,
          defaultExpanded: true,
          onEllipsis: v => console.log("当前是否需要截断", v),
        }}
      >
        舜发于畎亩之中，傅说举于版筑之闲，胶鬲举于鱼盐之中，管夷吾举于士，孙叔敖举于海，百里奚举于市。故天将降大任于是人也，必先苦其心志，劳其筋骨，饿其体肤，空乏其身，行拂乱其所为，所以动心忍性，曾益其所不能。人恒过，然后能改；困于心，衡于虑，而后作；徵于色，发于声，而后喻。入则无法家拂士，出则无敌国外患者，国恒亡。然后知生于忧患而死于安乐也。
      </TextEllipsis>
      <br />
      <TextEllipsis
        parent="div"
        ellipsis={{
          rows: 3,
          expandable: true,
          tooltip: true,
          suffix: expand => {
            return (
              <span
                style={{
                  backgroundColor: "red",
                  color: "var(--tea-color-text-on-bg-brand-default)",
                }}
              >
                {expand ? "自定义收起" : "自定义展开"}
              </span>
            );
          },
          onExpand: (e, s) => {
            console.log(s, e);
          },
        }}
      >
        Shun hair in the field drains, Fu said to lift in the version of the
        idle, Jiao Li lifted in the fish and salt, pipe Yiguo lifted in the Shi,
        Sun Shu Ao lifted in the sea, Thyme lifted in the city.Therefore, the
        heavens will send a great responsibility to be a person, must first
        suffer their hearts and minds, labor their muscles and bones, starve
        their bodies and skin, empty their bodies, line whisking what they do,
        so move the heart and patience, has benefited from its can not.People
        are always over, and then can be changed; trapped in the heart, weighing
        in the consideration, and then make; levied on the color, issued in the
        voice, and then metaphor.When you enter a country, there are no lawyers,
        and when you leave a country, there are no enemies or foreigners, and
        the country will always die.Then we know that we are born in sorrow and
        die in peace and happiness.
      </TextEllipsis>
    </div>
  </>
);
