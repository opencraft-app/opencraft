import React from "react";
import { Text, Button, Checkbox } from "@tencent/tea-component";

export default function TooltipSugarExample() {
  return (
    <>
      <section>
        <Text tooltip="吴雨霏 - 吴哥窟" verticalAlign="middle">
          吴哥窟
        </Text>
        、
        <Text tooltip="张柏芝 - 留给最爱的说话" verticalAlign="middle">
          留给最爱的说话
        </Text>
        <Button
          tooltip="成为 QQ 音乐 VIP 无限播放"
          disabled
          style={{ marginLeft: 10 }}
        >
          ► 播放
        </Button>
      </section>
      <section>
        <Checkbox tooltip="很喜欢吗？">单曲循环</Checkbox>
      </section>
    </>
  );
}
