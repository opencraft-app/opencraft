import React, { useState } from "react";
import {
  Layout,
  Card,
  Text,
  ExternalLink,
  Menu,
  NavMenu,
} from "@tencent/tea-component";

const { Header, Body, Sider, Content } = Layout;

const icon = /** @type {[string, string]} */ ([
  `https://via.placeholder.com/16.png?text=icon`,
  `https://via.placeholder.com/16/006eff/444444`,
]);

export default function LayoutWithLightSiderExample() {
  const [selected, setSelected] = useState("overview");

  const getMenuItemProps = id => ({
    selected: selected === id,
    onClick: () => setSelected(id),
  });

  return (
    <Layout className="demo-layout-l">
      <Header>
        <NavMenu
          left={
            <>
              <NavMenu.Item type="logo">
                <img
                  src="https://via.placeholder.com/32.png?text=LOGO"
                  alt="logo"
                />
              </NavMenu.Item>
              <NavMenu.Item>总览</NavMenu.Item>
            </>
          }
        />
      </Header>
      <Body>
        <Sider>
          <Menu
            back={{
              title: "产品名称产品名称产品名称",
              description: "数据测试",
              tooltip: "产品名称产品名称产品名称 - 数据测试勿删",
              onClick: () => console.log("back"),
            }}
            collapsable
          >
            <Menu.Item
              icon={icon}
              title="一级菜单"
              {...getMenuItemProps("1")}
            />

            <Menu.SubMenu defaultOpened title="一级菜单" icon={icon}>
              <Menu.Item title="二级菜单" {...getMenuItemProps("2-1")} />
              <Menu.Item title="二级菜单" {...getMenuItemProps("2-2")} />
            </Menu.SubMenu>
          </Menu>
        </Sider>
        <Content>
          <Content.Header
            title="内容标题"
            subtitle={
              <>
                说明文字 <Text theme="label">带颜色说明文字</Text>
              </>
            }
            operation={<ExternalLink weak>内容帮助</ExternalLink>}
          />
          <Content.Body>
            {/* 内容区域一般使用 Card 组件显示内容 */}
            <Card>
              <Card.Body>内容卡片</Card.Body>
            </Card>
          </Content.Body>
        </Content>
      </Body>
    </Layout>
  );
}
