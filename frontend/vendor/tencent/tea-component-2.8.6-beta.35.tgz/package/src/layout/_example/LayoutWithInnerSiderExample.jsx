import React, { useState } from "react";
import {
  Layout,
  Card,
  Text,
  ExternalLink,
  Menu,
  NavMenu,
} from "@tencent/tea-component";
import { Badge } from "../../badge";

const { Header, Body, Sider, Content } = Layout;

const icon = /** @type {[string, string]} */ ([
  `https://via.placeholder.com/16.png?text=icon`,
  `https://via.placeholder.com/16/006eff/444444`,
]);

export default function LayoutWithInnerSiderExample() {
  const [selected, setSelected] = useState("overview");
  const [subSelected, setSubSelected] = useState("overview");

  const getMenuItemProps = id => ({
    selected: selected === id,
    onClick: () => setSelected(id),
  });

  const getSubMenuItemProps = id => ({
    selected: subSelected === id,
    onClick: () => setSubSelected(id),
  });

  return (
    <Layout className="demo-layout-l">
      <Header>
        <NavMenu
          left={
            <>
              <NavMenu.Item type="logo">
                <img
                  src="https://via.placeholder.com/32.png?text=LOGO"
                  alt="logo"
                />
              </NavMenu.Item>
              <NavMenu.Item>总览</NavMenu.Item>
            </>
          }
        />
      </Header>
      <Body>
        <Sider>
          <Menu
            collapsable
            theme="dark"
            title="产品名称"
            icon="https://via.placeholder.com/32.png?text=icon"
            tag="NEW"
          >
            <Menu.Item
              icon={icon}
              tag="NEW"
              title="一级菜单"
              {...getMenuItemProps("1")}
            />

            <Menu.SubMenu defaultOpened title="一级菜单" icon={icon}>
              <Menu.Item
                tag="NEW"
                title="二级菜单"
                {...getMenuItemProps("2-1")}
              />
              <Menu.Item
                tag={<Badge theme="success">FREE</Badge>}
                title="二级菜单"
                {...getMenuItemProps("2-2")}
              />
            </Menu.SubMenu>

            <Menu.Group title="菜单分组">
              <Menu.SubMenu title="一级菜单" icon={icon}>
                <Menu.Item
                  title="二级菜单"
                  icon={icon}
                  {...getMenuItemProps("3-1")}
                />
                <Menu.Item title="二级菜单" {...getMenuItemProps("3-2")} />
              </Menu.SubMenu>
              <Menu.Item icon={icon} title="外部链接" external />
            </Menu.Group>
          </Menu>
        </Sider>
        <Sider>
          <Menu
            back={{
              title: "产品名称产品名称产品名称产品名称产品名称产品名称",
              tooltip: "产品名称产品名称产品名称产品名称产品名称产品名称",
              onClick: () => console.log("back"),
            }}
          >
            <Menu.Item
              title="一级菜单"
              {...getSubMenuItemProps("s-1")}
              tag="NEW"
            />
            <Menu.SubMenu defaultOpened title="一级菜单">
              <Menu.Item
                title="二级菜单"
                {...getSubMenuItemProps("s-2-1")}
                tag={<Badge theme="success">FREE</Badge>}
              />
              <Menu.Item title="二级菜单" {...getSubMenuItemProps("s-2-2")} />
            </Menu.SubMenu>
          </Menu>
        </Sider>
        <Content>
          <Content.Header
            title="内容标题"
            subtitle={
              <>
                说明文字 <Text theme="label">带颜色说明文字</Text>
              </>
            }
            operation={<ExternalLink weak>内容帮助</ExternalLink>}
          />
          <Content.Body>
            {/* 内容区域一般使用 Card 组件显示内容 */}
            <Card>
              <Card.Body>内容卡片</Card.Body>
            </Card>
          </Content.Body>
        </Content>
      </Body>
    </Layout>
  );
}
