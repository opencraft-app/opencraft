import React from "react";
import { ImagePreview } from "@tencent/tea-component";

export default function ImagePreviewExample() {
  return (
    <ImagePreview
      previewSrc="https://via.placeholder.com/2000"
      previewTitle="这是一张示例图片"
    >
      {open => <a onClick={open}>查看大图</a>}
    </ImagePreview>
  );
}
