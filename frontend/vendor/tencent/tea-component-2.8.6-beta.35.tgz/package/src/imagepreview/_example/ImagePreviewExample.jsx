import React from "react";
import { ImagePreview } from "@tencent/tea-component";

export default function ImagePreviewExample() {
  return (
    <ImagePreview
      src="https://via.placeholder.com/100"
      previewSrc="https://via.placeholder.com/2000"
      previewTitle="这是一张示例图片"
    />
  );
}
