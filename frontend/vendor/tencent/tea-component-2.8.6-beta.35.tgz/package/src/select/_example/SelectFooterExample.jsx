import React from "react";
import { Select } from "@tencent/tea-component";

const options = Array.from({ length: 10 }).map((_, i) => ({
  value: `${i}`,
  text: `Option ${i}`,
}));

export default function SelectExample() {
  return (
    <Select
      size="m"
      matchButtonWidth
      appearance="button"
      options={options}
      footer={<a>新建选项</a>}
    />
  );
}
