import React from "react";
import { Select, SelectMultiple, Form } from "@tencent/tea-component";

const options = [
  { value: "strawberry", text: "草莓", tooltip: "甜甜甜" },
  { value: "apple", text: "苹果", tooltip: "每日一苹果，医生远离我" },
  { value: "orange", text: "橙子", tooltip: "丰富 VC 含量" },
  { value: "durian", text: "榴莲", disabled: true, tooltip: "榴莲已售罄" },
];

export default function SelectExample() {
  return (
    <Form>
      <Form.Item label="单选">
        <Select
          clearable
          matchButtonWidth
          appearance="button"
          options={options}
          size="m"
        />
      </Form.Item>
      <Form.Item label="多选">
        <SelectMultiple
          clearable
          appearance="button"
          options={[
            { value: "gz", text: "瓜子", tooltip: "百煮入味香" },
            {
              value: "hs",
              text: "花生",
              tooltip: "花生已售罄",
            },
            { value: "bmf", text: "爆米花", tooltip: "焦糖味" },
            { value: "kl", text: "可乐", tooltip: "肥宅快乐水" },
            { value: "pj", text: "啤酒" },
            { value: "kqs", text: "矿泉水" },
            { value: "bbz", text: "八宝粥" },
          ]}
          allOption={{
            value: "all",
            text: "全选",
            tooltip: "我都要",
          }}
          size="m"
        />
      </Form.Item>
    </Form>
  );
}
