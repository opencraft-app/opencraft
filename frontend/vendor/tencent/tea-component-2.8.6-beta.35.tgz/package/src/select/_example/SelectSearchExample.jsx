import React, { useState } from "react";
import { Select, SelectMultiple, Form } from "@tencent/tea-component";

const options = [
  { value: "strawberry", text: "草莓", tooltip: "甜甜甜" },
  { value: "apple", text: "苹果", tooltip: "每日一苹果，医生远离我" },
  { value: "orange", text: "橙子", tooltip: "丰富 VC 含量" },
  { value: "durian", text: "榴莲", disabled: true, tooltip: "榴莲已售罄" },
  { value: "coca-cola", text: "可口可乐" },
  { value: "pepsi-cola", text: "百事可乐" },
];

export default function SelectExample() {
  const [favorite, setFavorite] = useState(null);
  return (
    <Form>
      <Form.Item label="单选">
        <Select
          searchable
          matchButtonWidth
          size="m"
          appearance="button"
          options={options}
          value={favorite}
          onChange={value => setFavorite(value)}
        />
      </Form.Item>
      <Form.Item label="多选">
        <SelectMultiple
          staging={false}
          searchable
          size="m"
          appearance="button"
          options={options}
        />
      </Form.Item>
    </Form>
  );
}
