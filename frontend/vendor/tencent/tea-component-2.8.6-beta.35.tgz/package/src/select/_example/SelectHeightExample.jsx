import React from "react";
import { Select } from "@tencent/tea-component";

const options = Array.from({ length: 5000 }).map((_, i) => ({
  value: `${i}`,
  text: `Option ${i}`,
}));

export default function SelectExample() {
  return (
    <Select
      size="m"
      searchable
      matchButtonWidth
      appearance="button"
      options={options}
      listHeight={600}
    />
  );
}
