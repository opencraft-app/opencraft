import React, { useState } from "react";
import { Select, SelectMultiple, Form } from "@tencent/tea-component";

const options = [
  { groupKey: "fruit", value: "strawberry", text: "草莓", tooltip: "甜甜甜" },
  {
    groupKey: "fruit",
    value: "apple",
    text: "苹果",
    disabled: true,
    tooltip: "每日一苹果，医生远离我",
  },
  { groupKey: "fruit", value: "orange", text: "橙子", tooltip: "丰富 VC 含量" },
  { groupKey: "drink", value: "coca-cola", text: "可口可乐" },
  {
    groupKey: "drink",
    value: "pepsi-cola",
    text: "百事可乐",
    tooltip: "百事可乐为什么比可口可乐好喝？",
  },
  {
    groupKey: "fruit",
    value: "strawberry1",
    text: "草莓1",
    tooltip: "甜甜甜1",
  },
];

const groups = {
  fruit: "水果",
  drink: "饮料",
};

export default function SelectExample() {
  const [favorite, setFavorite] = useState(null);
  const [favorites, setFavorites] = useState([]);

  return (
    <Form>
      <Form.Item label="单选">
        <Select
          groups={groups}
          options={options}
          value={favorite}
          onChange={value => setFavorite(value)}
          placeholder="请选择你最爱的食品"
        />
      </Form.Item>
      <Form.Item label="分割线">
        <Select
          options={options}
          value={favorite}
          onChange={value => setFavorite(value)}
          placeholder="请选择你最爱的食品"
        />
      </Form.Item>
      <Form.Item label="多选">
        <SelectMultiple
          groups={groups}
          options={options}
          value={favorites}
          onChange={value => {
            console.log("value", value);
            setFavorites(value);
          }}
          placeholder="请选择你喜欢的食品"
          allOption={{
            value: "all",
            text: "全选",
            tooltip: "我都要",
          }}
        />
      </Form.Item>
      <Form.Item label="多选分割线">
        <SelectMultiple
          options={options}
          value={favorites}
          onChange={value => setFavorites(value)}
          placeholder="请选择你喜欢的食品"
          allOption={{
            value: "all",
            text: "全选",
            tooltip: "我都要",
          }}
        />
      </Form.Item>
    </Form>
  );
}
