import React, { useState } from "react";
import { Select, Form } from "@tencent/tea-component";

const defaultOptions = [
  { value: "strawberry", text: "草莓", tooltip: "甜甜甜" },
  { value: "apple", text: "苹果", tooltip: "每日一苹果，医生远离我" },
  { value: "orange", text: "橙子", tooltip: "丰富 VC 含量" },
  { value: "durian", text: "榴莲", disabled: true, tooltip: "榴莲已售罄" },
];

export default function SelectExample() {
  const [options, setOptions] = useState(defaultOptions);

  async function getOptions() {
    const options = await new Promise(resolve => {
      setTimeout(() => {
        resolve([
          ...defaultOptions,
          { value: "coca-cola", text: "可口可乐" },
          { value: "pepsi-cola", text: "百事可乐" },
        ]);
      }, 1000);
    });
    setOptions(options);
  }

  return (
    <Form>
      <Form.Item label="模拟下拉">
        <Select
          refreshable
          onRefresh={getOptions}
          appearance="default"
          options={options}
          placeholder="请选择你最爱的水果"
        />
      </Form.Item>
      <Form.Item label="下拉按钮">
        <Select
          refreshable
          onRefresh={getOptions}
          appearance="button"
          options={options}
          placeholder="请选择你最爱的水果"
        />
      </Form.Item>
    </Form>
  );
}
