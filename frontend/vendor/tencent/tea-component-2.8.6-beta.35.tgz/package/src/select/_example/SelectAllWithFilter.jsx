import React, { useState } from "react";
import { SelectMultiple, Form } from "@tencent/tea-component";

const options = [
  { value: "strawberry", text: "草莓", tooltip: "甜甜甜" },
  { value: "apple", text: "苹果", tooltip: "每日一苹果，医生远离我" },
  { value: "apple1", text: "苹果派", tooltip: "每日一苹果，医生远离我" },
  { value: "orange", text: "橙子", tooltip: "丰富 VC 含量" },
  { value: "durian", text: "榴莲", tooltip: "榴莲已售罄" },
  { value: "coca-cola", text: "可口可乐" },
  { value: "pepsi-cola", text: "百事可乐" },
];

export default function SelectAllWithFilter() {
  const [inputValue, setInputValue] = useState("");

  return (
    <Form>
      <Form.Item label="多选">
        <SelectMultiple
          allOption={{
            value: "all",
            text: "全选",
            tooltip: "我都要",
          }}
          searchValue={inputValue}
          staging
          shouldOptionExcludeFromAll={option => {
            const status =
              inputValue &&
              !String(option.text)
                .trim()
                .toLowerCase()
                .includes(
                  String(inputValue)
                    .trim()
                    .toLowerCase()
                );
            return status;
          }}
          searchable
          size="m"
          onlySubmitFilterFromAll
          appearance="button"
          options={options}
          onSearchValueChange={keyword => {
            setInputValue(keyword);
          }}
          onChange={value => {
            console.log("value:", value);
          }}
        />
      </Form.Item>
    </Form>
  );
}
