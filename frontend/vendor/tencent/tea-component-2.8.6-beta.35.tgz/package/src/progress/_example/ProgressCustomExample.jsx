import React, { useState, useEffect } from "react";
import { Progress } from "@tencent/tea-component";

export default function ProgressCircleExample() {
  const [percent, setPercent] = useState(0);

  useEffect(() => {
    const timer = setInterval(
      () => setPercent(percent => (percent % 100) + 10),
      1000
    );
    return () => clearInterval(timer);
  }, []);

  return (
    <>
      <Progress
        percent={percent}
        text={percent => `${percent} %`}
        strokeColor="#faa3c4"
        strokeWidth={16}
      />
      <Progress
        type="circle"
        percent={percent}
        strokeColor="#faa3c4"
        strokeWidth={16}
      />
      <Progress
        type="circle"
        percent={percent}
        strokeColor="#faa3c4"
        strokeWidth={16}
        width={240}
      />
    </>
  );
}
