# Alert 警示

用于给用户显示提示消息。

## 使用示例

### 基本用法

支持多种提示类型。

[Example: AlertExample](./_example/AlertExample.jsx)

### 公告栏

公告栏用于承载产品通知、功能重大调整、计费策略变化、产品策略变更、活动规则说明等内容。

[Example: AlertNoticeExample](./_example/AlertNoticeExample.jsx)

### 可关闭

使用 `defaultVisible` 进行非受控关闭或者使用 `visible` 进行受控关闭。

[Example: AlertCloseExample](./_example/AlertCloseExample.jsx)

### 使用更多 ICON 图标

使用 `prefix` 属性, 结合 [Icon](./icon) 组件，修改默认图标

[Example: 使用AlertIconExample](./_example/AlertIconExample.jsx)


### 轮播

当需要同时提示多条内容时，可使用轮播提示条来承载，避免页面上同时出现多条提示条挤占内容。

[Example: AlertCarouselExample](./_example/AlertCarouselExample.jsx)

### 文字装饰

可以对文字内容做加强、说明、链接等特殊样式

[Example: AlertStyleExample](./_example/AlertStyleExample.jsx)

### 多行形式

#### 自定义排版

可以在提示消息内进行标题、正文、列表等排版内容。

[Example: AlertComposingExample](./_example/AlertComposingExample.jsx)

#### 自动展开

如果文字过长，建议最多显示3行，可以通过`TextEllipsis`组件展开/收起

[Example: AlertWithTextEllipsis](./_example/AlertWithTextEllipsis.jsx)


### 标签型/策略提示

某些特殊场景下使用，如在需要表示计费、合规要求等需要用户明确感知提示内容的场景使用

**💡 注意 **：标签仅允许在 `neutral`和`white`类型上使用

[Example: AlertTagExample](./_example/AlertTagExample.jsx)

### 提示组

某些特殊场景下使用，多条相同类型的提示可以使用提示组，注意：
- 只支持 `neutral` 和 `white` 类型
- `Alert` 中如果对 `visible`,`defaultVisible`,`onClose`,`extra`,`carouselMode`属性有赋值，值将不会生效。
- 提示组支持整体关闭关闭
- 提示组标签长度不一致的情况下，可以开启 `prefixSameWidth`，保证标签区域同宽。

**💡 注意 **：标签仅允许在 `neutral`和`white`类型上使用

[Example: AlertTagExample](./_example/AlertGroupExample.jsx)

## 组件属性

[Interface: AlertProps](./Alert.tsx)

[Interface: AlertStrongProps](./AlertStrong.tsx)

[Interface: AlertNoticeProps](./AlertNotice.tsx)

[Interface: AlertGroupProps](./AlertGroup.tsx)

