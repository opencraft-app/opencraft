import React from "react";
import { Alert } from "@tencent/tea-component";

export default function AlertExample() {
  return (
    <>
      <Alert>
        常规提示，
        <a href="https://cloud.tencent.com" target="_blank" rel="noreferrer">
          链接
        </a>
      </Alert>
      <Alert type="warning" style={{ marginTop: 8 }}>
        告警提示，
        <a href="https://cloud.tencent.com" target="_blank" rel="noreferrer">
          链接
        </a>
      </Alert>
      <Alert type="error" style={{ marginTop: 8 }}>
        异常提示，
        <a href="https://cloud.tencent.com" target="_blank" rel="noreferrer">
          链接
        </a>
      </Alert>
      <Alert type="neutral" style={{ marginTop: 8 }}>
        弱提示，
        <a href="https://cloud.tencent.com" target="_blank" rel="noreferrer">
          链接
        </a>
      </Alert>
      <div
        style={{
          backgroundColor: "var(--tea-color-bg-page-default)",
          padding: "8px",
          marginTop: 8,
        }}
      >
        <Alert type="white" style={{ marginBottom: "0" }}>
          弱提示，
          <a href="https://cloud.tencent.com" target="_blank" rel="noreferrer">
            链接
          </a>
        </Alert>
      </div>
    </>
  );
}
