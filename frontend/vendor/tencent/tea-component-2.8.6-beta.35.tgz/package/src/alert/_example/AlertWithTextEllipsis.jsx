import React from "react";
import { Alert, TextEllipsis } from "@tencent/tea-component";

export default function AlertWithTextEllipsis() {
  return (
    <>
      <Alert type="neutral">
        <TextEllipsis ellipsis={{ rows: 3, expandable: true, tooltip: true }}>
          先帝创业未半而中道崩殂，今天下三分，益州疲弊，此诚危急存亡之秋也。
          <Alert.Strong>然侍卫之臣不懈于内，忠志之士忘身于外者</Alert.Strong>
          ，盖追先帝之殊遇，欲报之于陛下也。诚宜开张圣听，以光先帝遗德，恢弘志士之气，不宜妄自菲薄，引喻失义，以塞忠谏之路也。
          宫中府中，俱为一体；陟罚臧否，不宜异同。若有作奸犯科及为忠善者，宜付有司论其刑赏，以昭陛下平明之理，不宜偏私，使内外异法也。
          侍中、侍郎郭攸之、费祎、董允等，此皆良实，志虑忠纯，是以先帝简拔以遗陛下。愚以为宫中之事，事无大小，悉以咨之，然后施行，必能裨补阙漏，有所广益。
        </TextEllipsis>
      </Alert>

      <Alert type="info">
        <TextEllipsis ellipsis={{ rows: 2, expandable: true, tooltip: true }}>
          先帝创业未半而中道崩殂，今天下三分，益州疲弊，此诚危急存亡之秋也。
          <Alert.Strong>然侍卫之臣不懈于内，忠志之士忘身于外者</Alert.Strong>
          ，盖追先帝之殊遇，欲报之于陛下也。诚宜开张圣听，以光先帝遗德，恢弘志士之气，不宜妄自菲薄，引喻失义，以塞忠谏之路也。
          宫中府中，俱为一体；陟罚臧否，不宜异同。若有作奸犯科及为忠善者，宜付有司论其刑赏，以昭陛下平明之理，不宜偏私，使内外异法也。
          侍中、侍郎郭攸之、费祎、董允等，此皆良实，志虑忠纯，是以先帝简拔以遗陛下。愚以为宫中之事，事无大小，悉以咨之，然后施行，必能裨补阙漏，有所广益。
        </TextEllipsis>
      </Alert>
    </>
  );
}
