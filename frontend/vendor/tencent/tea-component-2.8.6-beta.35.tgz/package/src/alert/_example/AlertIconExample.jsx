import React from "react";
import { Alert, Icon } from "@tencent/tea-component";

export default function AlertIconExample() {
  return (
    <>
      <Alert prefix={<Icon type="chart-line" />}>
        常规提示，
        <a href="https://cloud.tencent.com" target="_blank" rel="noreferrer">
          链接
        </a>
      </Alert>
      <Alert
        type="warning"
        style={{ marginTop: 8 }}
        prefix={<Icon type="setting" />}
      >
        告警提示，
        <a href="https://cloud.tencent.com" target="_blank" rel="noreferrer">
          链接
        </a>
      </Alert>
    </>
  );
}
