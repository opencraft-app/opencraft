import React from "react";
import { Alert, Tag } from "@tencent/tea-component";

export default function AlertGroupExample() {
  return (
    <>
      <Alert.Group defaultVisible type="neutral">
        <Alert prefix={<Tag theme="warning">计费</Tag>}>
          弱提示
          <Alert.Strong>
            这里是加强的文字描述，This is strong text.
          </Alert.Strong>
        </Alert>
        <Alert prefix={<Tag theme="primary">提示</Tag>}>
          弱提示，
          <Alert.Strong>
            这里是加强的文字描述，This is strong text.
          </Alert.Strong>
        </Alert>
      </Alert.Group>
      <hr />
      <Alert.Group defaultVisible type="neutral" prefixSameWidth>
        <Alert prefix={<Tag theme="warning">Billing</Tag>}>
          To ensure you benefit from the best pricing strategy, the resource
          package with a historical period of 30 days supports renewal, and the
          renewal duration is calculated according to the new validity period
          policy. For more details, please refer to the documentation.
        </Alert>
        <Alert prefix={<Tag theme="primary">Compliance</Tag>}>
          Thank you for using Tencent Cloud's high-performance computing cluster
          service.
        </Alert>
      </Alert.Group>
    </>
  );
}
