import React from "react";
import { Alert, Tag } from "@tencent/tea-component";

export default function AlertTagExample() {
  return (
    <>
      <Alert
        type="neutral"
        style={{ marginTop: 8 }}
        prefix={<Tag theme="warning">计费</Tag>}
      >
        弱提示。
        <Alert.Strong>这里是加强的文字描述，This is strong text.</Alert.Strong>
      </Alert>
      <div
        style={{
          backgroundColor: "var(--tea-color-bg-page-default)",
          padding: "8px",
          marginTop: 8,
        }}
      >
        <Alert
          type="white"
          style={{ marginBottom: "0" }}
          prefix={<Tag theme="primary">提示</Tag>}
        >
          弱提示。
          <Alert.Strong>
            这里是加强的文字描述，This is strong text.
          </Alert.Strong>
        </Alert>
      </div>
    </>
  );
}
