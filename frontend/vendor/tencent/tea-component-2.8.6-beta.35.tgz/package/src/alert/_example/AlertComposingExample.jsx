import React from "react";
import { Alert, List, Button, TextEllipsis } from "@tencent/tea-component";

export default function AlertComposingExample() {
  return (
    <>
      <Alert>
        <h4 style={{ marginBottom: 8 }}>重要声明</h4>
        <p>本功能将在 2019 年 2 月 29 日下线，请注意做好下列迁移工作：</p>
        <List type="bullet">
          <List.Item>小程序云服务器有奖内测中，即刻成为产品体验官</List.Item>
          <List.Item>
            云服务器限时秒杀，首购1C1G仅需99元/年，还有多款配置供您选择
          </List.Item>
        </List>
      </Alert>
      <Alert type="warning" carouselMode visible>
        <>
          <h4 style={{ marginBottom: 8 }}>重要声明</h4>
          <List type="bullet">
            <List.Item>小程序云服务器有奖内测中，即刻成为产品体验官</List.Item>
            <List.Item>
              云服务器限时秒杀，首购1C1G仅需99元/年，还有多款配置供您选择
            </List.Item>
          </List>
          <p style={{ marginTop: 8 }}>
            <Button type="link">操作项</Button>
          </p>
        </>
        <>
          <h4 style={{ marginBottom: 8 }}>重要声明</h4>
          <List type="bullet">
            <List.Item>
              云服务器限时秒杀，首购1C1G仅需99元/年，还有多款配置供您选择
            </List.Item>
            <List.Item>小程序云服务器有奖内测中，即刻成为产品体验官</List.Item>
          </List>
          <p style={{ marginTop: 8 }}>
            <Button type="link">操作项</Button>
          </p>
        </>
      </Alert>
    </>
  );
}
