import React from "react";
import { Alert, List } from "@tencent/tea-component";

export default function AlertNoticeExample() {
  return (
    <div
      style={{
        backgroundColor: "var(--tea-color-bg-secondary-default)",
        padding: 20,
      }}
    >
      <Alert.Notice
        defaultOpen
        title="【公告】关于硬盘快照将于2019年7月正式商业化的通知"
      >
        <List type="bullet">
          <List.Item>小程序云服务器有奖内测中，即刻成为产品体验官</List.Item>
          <List.Item>
            云服务器限时秒杀，首购1C1G仅需99元/年，还有多款配置供您选择
          </List.Item>
          <List.Item>
            让企业普惠上云，云服务器最低至2.5折，还有更多产品更低折扣满足您的需求
          </List.Item>
        </List>
      </Alert.Notice>
    </div>
  );
}
