import React from "react";
import { Alert, Text, Bubble } from "@tencent/tea-component";

export default function AlertStyleExample() {
  return (
    <>
      <Alert>
        常规提示。
        <Alert.Strong>加强文字描述</Alert.Strong>
      </Alert>
      <Alert type="warning" style={{ marginTop: 8 }}>
        告警提示，
        <Alert.Strong>加强文字描述</Alert.Strong>
      </Alert>

      <Alert type="neutral" style={{ marginTop: 8 }}>
        弱提示。
        <Bubble content="说明文字">
          <Text underline>带说明文案</Text>
        </Bubble>
      </Alert>

      <div
        style={{
          backgroundColor: "var(--tea-color-bg-page-default)",
          padding: "8px",
          marginTop: 8,
        }}
      >
        <Alert type="white" style={{ marginBottom: "0" }}>
          弱提示。
          <a href="https://cloud.tencent.com" target="_blank" rel="noreferrer">
            这是一个链接
          </a>
        </Alert>
      </div>
    </>
  );
}
