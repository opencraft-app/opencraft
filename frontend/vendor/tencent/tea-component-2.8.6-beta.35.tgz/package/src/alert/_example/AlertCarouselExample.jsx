import React from "react";
import { Alert, List } from "@tencent/tea-component";

export default function AlertCarouselExample() {
  return (
    <Alert carouselMode defaultVisible>
      <>小程序云服务器有奖内测中，即刻成为产品体验官</>
      <>云服务器限时秒杀，首购1C1G仅需99元/年</>
      <>让企业普惠上云，云服务器最低至2.5折</>
    </Alert>
  );
}
