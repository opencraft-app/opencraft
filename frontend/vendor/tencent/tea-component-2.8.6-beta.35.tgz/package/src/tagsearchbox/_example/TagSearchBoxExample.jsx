import React, {
  useCallback,
  useState,
  useEffect,
  useRef,
  useMemo,
} from "react";
import { TagSearchBox, List, Switch } from "@tencent/tea-component";

/**
 * 自定义属性选择渲染组件（分组显示 + 键盘滚动）
 */
function CustomAttributeSelect({
  inputValue,
  attributes,
  onSelect,
  onCancel,
  onOperationalKeyDown,
}) {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const itemRefs = useRef({});
  const listRef = useRef(null);

  // 自定义过滤逻辑
  const filteredList = useMemo(() => {
    return attributes.filter(
      attr =>
        !inputValue ||
        attr.name.toLowerCase().includes(inputValue.toLowerCase())
    );
  }, [attributes, inputValue]);

  // 按类型分组
  const groupedAttributes = useMemo(() => {
    const groups = {
      input: { label: "输入类型", items: [] },
      single: { label: "单选类型", items: [] },
      multiple: { label: "多选类型", items: [] },
      render: { label: "自定义渲染", items: [] },
    };

    filteredList.forEach((attr, originalIndex) => {
      const type = Array.isArray(attr.type) ? attr.type[0] : attr.type;
      if (groups[type]) {
        groups[type].items.push({ attr, flatIndex: originalIndex });
      }
    });

    // 过滤掉空分组，并计算扁平索引
    const result = [];
    let currentFlatIndex = 0;
    Object.entries(groups).forEach(([type, group]) => {
      if (group.items.length > 0) {
        result.push({
          type,
          label: group.label,
          items: group.items.map(item => {
            const idx = currentFlatIndex;
            currentFlatIndex += 1;
            return { ...item, flatIndex: idx };
          }),
        });
      }
    });

    return result;
  }, [filteredList]);

  // 获取扁平列表用于键盘导航
  // 使用 reduce + concat 替代 flatMap 以兼容 ES2019 之前的环境
  const flatList = useMemo(() => {
    return groupedAttributes.reduce(
      (acc, group) => acc.concat(group.items),
      []
    );
  }, [groupedAttributes]);

  // 边界处理
  useEffect(() => {
    if (selectedIndex >= flatList.length) {
      setSelectedIndex(Math.max(0, flatList.length - 1));
    }
  }, [flatList.length, selectedIndex]);

  // 选中项变化时滚动到可见区域
  useEffect(() => {
    const selectedItem = itemRefs.current[selectedIndex];
    if (selectedItem && listRef.current) {
      selectedItem.scrollIntoView({
        behavior: "smooth",
        block: "nearest",
      });
    }
  }, [selectedIndex]);

  // 键盘导航
  onOperationalKeyDown(key => {
    if (key === "down") {
      setSelectedIndex(i => Math.min(i + 1, flatList.length - 1));
    }
    if (key === "up") {
      setSelectedIndex(i => Math.max(i - 1, 0));
    }
    if (key === "enter" && flatList[selectedIndex]) {
      onSelect(flatList[selectedIndex].attr);
    }
    if (key === "esc") {
      onCancel();
    }
  });

  if (flatList.length === 0) {
    return (
      <List type="option">
        <List.StatusTip>无匹配的属性</List.StatusTip>
      </List>
    );
  }

  return (
    <List
      type="option"
      style={{ maxHeight: 300, overflowY: "auto" }}
      ref={listRef}
    >
      <p>自定义分组示例</p>
      {groupedAttributes.map(group => (
        <React.Fragment key={group.type}>
          <div
            style={{
              borderTop: "1px solid #eee",
              paddingTop: 8,
              marginTop: 8,
            }}
          ></div>
          {group.items.map(({ attr, flatIndex }) => (
            <List.Item
              key={attr.key}
              ref={el => {
                itemRefs.current[flatIndex] = el;
              }}
              selected={flatIndex === selectedIndex}
              onClick={() => onSelect(attr)}
              style={{ paddingLeft: 10 }}
            >
              {attr.name}
            </List.Item>
          ))}
        </React.Fragment>
      ))}
    </List>
  );
}

const values = [
  { key: "1", name: "value-1" },
  { key: "2", name: "value-2" },
  { key: "3", name: "value-3" },
  { key: "4", name: "value-4" },
  { key: "5", name: "value-5" },
  { key: "6", name: "value-6" },
  { key: "7", name: "value-7" },
  { key: "8", name: "value-8", style: { color: "red" } },
  { key: "9", name: "value-9" },
  { key: "10", name: "value-10" },
  { key: "11", name: "value-11" },
  { key: "12", name: "value-12" },
  { key: "13", name: "value-13" },
  { key: "14", name: "value-14" },
  { key: "15", name: "value-15" },
];

/**
 * @type {import("@tencent/tea-component/lib/tagsearchbox").TagSearchBoxProps["attributes"]}
 */
const attributes = [
  {
    type: "input",
    key: "1",
    name: "主机名",
  },
  {
    type: "single",
    key: "2",
    name: "云主机ID",
    values,
    removeable: false,
  },
  {
    type: "single",
    key: "3",
    name: "云主机状态",
    values: () => {
      return new Promise(resolve => {
        setTimeout(() => {
          resolve(values);
        }, 1000);
      });
    },
  },
  {
    type: ["multiple", { all: false }],
    key: "4",
    name: "所属项目",
    values,
  },
  {
    type: "multiple",
    key: "5",
    name: "地域",
    values: () => values,
  },
  {
    type: "multiple",
    key: "6",
    name: "可用区",
    values: () => {
      return new Promise(resolve => {
        setTimeout(() => {
          resolve(values);
        }, 1000);
      });
    },
  },
  {
    key: "7",
    type: "render",
    name: "自定义渲染",
    render: ({ inputValue, onOperationalKeyDown, onSelect }) => {
      onOperationalKeyDown(key => {
        console.log(key);
      });
      return (
        <>
          <List type="option">
            {inputValue && <List.StatusTip>{inputValue}</List.StatusTip>}
            <List.Item onClick={() => onSelect([{ key: "1", name: "预付费" }])}>
              预付费
            </List.Item>
            <List.Item onClick={() => onSelect([{ key: "2", name: "后付费" }])}>
              后付费
            </List.Item>
            <List.SubMenu label="更多">
              <List type="option">
                <List.Item disabled>订阅</List.Item>
                <List.Item
                  onClick={() => onSelect([{ key: "3", name: "朋友代付" }])}
                >
                  朋友代付
                </List.Item>
              </List>
            </List.SubMenu>
          </List>
        </>
      );
    },
  },
  {
    type: "multiple",
    key: "8",
    name: "空选项",
    values: () => {
      return new Promise(resolve => {
        setTimeout(() => {
          resolve([]);
        }, 1000);
      });
    },
  },
  {
    type: ["multiple", { emptyText: "请前往添加标签" }],
    key: "9",
    name: "自定义空选项",
    values: () => {
      return new Promise(resolve => {
        setTimeout(() => {
          resolve([]);
        }, 1000);
      });
    },
  },
  {
    type: "multiple",
    key: "10",
    name: "可重复属性",
    values,
    reusable: true,
  },
  {
    type: ["single", { searchable: true }],
    key: "11",
    name: "可搜索",
    values,
  },
  {
    type: ["multiple", { all: true, searchable: true }],
    key: "12",
    name: "可搜索多选",
    values,
  },
];

const defaultValue = [
  {
    attr: attributes[1],
    values: [attributes[1].values[1]],
  },
  {
    attr: null,
    values: [
      { key: "1", name: "test-1" },
      { key: "2", name: "test-2" },
    ],
  },
];

export default function TagSearchBoxExample() {
  const [value, setValue] = useState([
    {
      attr: attributes[1],
      values: [{ key: "1", name: "value-1" }],
    },
  ]);
  const [tagHighlight, setTagHighlight] = useState(false);

  const onChange = useCallback(value => {
    console.log(value);
    setValue(value);
  }, []);

  return (
    <div>
      <p style={{ marginBottom: "16px" }}>
        <Switch onChange={e => setTagHighlight(e)}>标签高亮</Switch>
      </p>
      <span>非受控使用：</span>
      <TagSearchBox
        tagHighlight={tagHighlight}
        attributes={attributes}
        minWidth="100%"
        defaultValue={defaultValue}
        onChange={tags => console.log("change", tags)}
      />
      <div style={{ marginTop: 32 }}>
        <span>受控组件使用：</span>
        <TagSearchBox
          tagHighlight={tagHighlight}
          attributes={attributes}
          minWidth="100%"
          value={value}
          onChange={onChange}
        />
      </div>

      <div style={{ marginTop: 32 }}>
        <span>禁用根据输入值过滤资源属性：</span>
        <TagSearchBox
          tagHighlight={tagHighlight}
          disableAttributesFilter
          attributes={attributes}
          minWidth="100%"
          defaultValue={defaultValue}
          onChange={tags => console.log("change", tags)}
          onAttributeChange={(i, payload) =>
            console.log("attr-change", i, payload)
          }
        />
      </div>

      <div style={{ marginTop: 32 }}>
        <span>删除标签时，自定义是否阻止：</span>
        <TagSearchBox
          tagHighlight={tagHighlight}
          minWidth="100%"
          attributes={attributes}
          onChange={tags => console.log("change", tags)}
          onDeleteTag={async tag => {
            if (tag.values[0].name === "cvm") {
              alert("主机名为cvm的不能删除");
              return false;
            }
            return true;
          }}
        />
      </div>

      <div style={{ marginTop: 32 }}>
        <span>自定义属性选择下拉框渲染：</span>
        <TagSearchBox
          minWidth="100%"
          attributes={attributes}
          onChange={tags => console.log("change", tags)}
          attributesSelectRender={props => <CustomAttributeSelect {...props} />}
        />
      </div>
    </div>
  );
}
