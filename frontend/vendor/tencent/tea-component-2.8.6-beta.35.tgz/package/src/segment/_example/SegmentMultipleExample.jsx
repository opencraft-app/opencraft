import React, { useState } from "react";
import { SegmentMultiple } from "@tencent/tea-component";

export default function SegmentMultipleExample() {
  const [value, setValue] = useState([2, 4]);

  return (
    <SegmentMultiple
      value={value.map(String)}
      onChange={value => setValue(value.map(x => parseInt(x, 10)))}
      options={[
        { text: "日", value: "0", disabled: true, tooltip: "仅支持工作日" },
        { text: "一", value: "1" },
        { text: "二", value: "2" },
        { text: "三", value: "3" },
        { text: "四", value: "4" },
        { text: "五", value: "5" },
        { text: "六", value: "6", disabled: true, tooltip: "仅支持工作日" },
      ]}
    />
  );
}
