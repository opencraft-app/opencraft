import React, { useState } from "react";
import { CheckboxGroup, Switch } from "@tencent/tea-component";

export default function SwitchTreeExample() {
  const [selected, setSelected] = useState([]);

  return (
    <CheckboxGroup
      value={selected}
      onChange={value => {
        console.log(value);
        setSelected(value);
      }}
    >
      <Switch name="gz">广州市</Switch>
      <Switch name="sz">深圳市</Switch>
      <Switch name="fs">佛山市</Switch>
    </CheckboxGroup>
  );
}
