import React from "react";
import { Switch } from "@tencent/tea-component";

export default function SwitchExample() {
  return (
    <>
      <p>
        <Switch onClick={() => console.log(1)}>我是个开关</Switch>
      </p>
      <p>
        <Switch disabled value tooltip="禁用">
          禁止关闭
        </Switch>
      </p>
      <p>
        <Switch disabled value={false} tooltip="禁用">
          禁止打开
        </Switch>
      </p>
      <p>
        <Switch loading value>
          打开中
        </Switch>
      </p>
      <p>
        <Switch loading value={false}>
          关闭中
        </Switch>
      </p>
    </>
  );
}
