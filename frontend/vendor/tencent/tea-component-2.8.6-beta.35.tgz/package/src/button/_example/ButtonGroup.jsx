import React from "react";
import {
  Button,
  Popover,
  DropdownBox,
  List,
  Switch,
  Dropdown,
} from "@tencent/tea-component";
import { ChevronDownIcon, MoreIcon } from "@tencent/tea-icons-react";

export default function ButtonGroupExample() {
  const [disabled, setDisabled] = React.useState(false);
  const [loading, setLoading] = React.useState(false);

  return (
    <>
      <Switch value={disabled} onChange={v => setDisabled(v)}>
        禁用状态
      </Switch>
      <Switch value={loading} onChange={v => setLoading(v)}>
        加载状态
      </Switch>
      <hr />
      <h3>按钮组</h3>
      <br />
      <Button.Group disabled={disabled} style={{ marginRight: "20px" }}>
        <Button loading={loading}>次要按钮</Button>
        <Button>次要按钮</Button>
        <Button>次要按钮</Button>
      </Button.Group>
      <Button.Group disabled={disabled}>
        <Button loading={loading}>次要按钮</Button>
        <Button>次要按钮</Button>
        <Button>次要按钮</Button>
        <Popover
          placement="bottom-start"
          trigger="click"
          overlay={
            <DropdownBox>
              <List type="plain">
                <List.Item>
                  <List.ItemButton>操作项二</List.ItemButton>
                </List.Item>
                <List.Item>
                  <List.ItemButton>操作项三</List.ItemButton>
                </List.Item>
                <List.Item>
                  <List.ItemButton>操作项四</List.ItemButton>
                </List.Item>
              </List>
            </DropdownBox>
          }
        >
          <Button shape="square" disabled={disabled}>
            <ChevronDownIcon size={16} />
          </Button>
        </Popover>
      </Button.Group>

      <hr />
      <h3>分隔按钮（hover触发） </h3>
      <p>按钮可直接点击操作,下拉项数量最多不超过5项</p>
      <br />
      <Button.Group
        theme="brand"
        variant="solid"
        disabled={disabled}
        style={{ marginRight: "20px" }}
      >
        <Button loading={loading}>操作项一</Button>
        <Popover
          placement="bottom-start"
          trigger="hover"
          overlay={
            <DropdownBox>
              <List type="plain">
                <List.Item>
                  <List.ItemButton>操作项二</List.ItemButton>
                </List.Item>
                <List.Item>
                  <List.ItemButton>操作项三</List.ItemButton>
                </List.Item>
                <List.Item>
                  <List.ItemButton>操作项四</List.ItemButton>
                </List.Item>
              </List>
            </DropdownBox>
          }
        >
          <Button
            shape="square"
            variant="solid"
            theme="brand"
            disabled={disabled || loading}
          >
            <MoreIcon size={16} />
          </Button>
        </Popover>
      </Button.Group>
      <Button.Group variant="outlined" disabled={disabled}>
        <Button loading={loading}>操作项一</Button>
        <Popover
          placement="bottom-start"
          trigger="hover"
          overlay={
            <DropdownBox>
              <List type="plain">
                <List.Item>
                  <List.ItemButton>操作项二</List.ItemButton>
                </List.Item>
                <List.Item>
                  <List.ItemButton>操作项三</List.ItemButton>
                </List.Item>
                <List.Item>
                  <List.ItemButton>操作项四</List.ItemButton>
                </List.Item>
              </List>
            </DropdownBox>
          }
        >
          <Button shape="square" disabled={disabled || loading}>
            <MoreIcon size={16} />
          </Button>
        </Popover>
      </Button.Group>
      <hr />
      <h3>菜单按钮 （点击触发）</h3>
      <p>集合主题点击只可展开，不包含任何操作,下拉项数量最大不超过5项</p>
      <br />
      <Dropdown
        button="菜单按钮"
        appearance="solidBrand"
        style={{ marginRight: "20px" }}
        disabled={disabled}
      >
        <List type="plain">
          <List.Item>
            <List.ItemButton>操作项二</List.ItemButton>
          </List.Item>
          <List.Item>
            <List.ItemButton>操作项三</List.ItemButton>
          </List.Item>
          <List.Item>
            <List.ItemButton>操作项四</List.ItemButton>
          </List.Item>
        </List>
      </Dropdown>
      <Dropdown button="菜单按钮" appearance="button" disabled={disabled}>
        <List type="plain">
          <List.Item>
            <List.ItemButton>操作项二</List.ItemButton>
          </List.Item>
          <List.Item>
            <List.ItemButton>操作项三</List.ItemButton>
          </List.Item>
          <List.Item>
            <List.ItemButton>操作项四</List.ItemButton>
          </List.Item>
        </List>
      </Dropdown>
    </>
  );
}
