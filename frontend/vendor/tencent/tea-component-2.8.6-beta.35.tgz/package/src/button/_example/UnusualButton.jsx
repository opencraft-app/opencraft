﻿import React from "react";
import { Button, Form, Tag } from "@tencent/tea-component";
import { HomeIcon } from "@tencent/tea-icons-react";
import { BadgeContainer } from "../../badge/BadgeContainer";

export default function UnusualButtonExample() {
  const style = { marginRight: 5 };
  return (
    <Form>
      <Form.Item label="支付按钮" align="middle">
        <Button variant="solid" theme="warning" style={style}>
          支付按钮
        </Button>
        <Button variant="solid" theme="warning" loading style={style}>
          支付按钮
        </Button>
        <Button variant="solid" theme="warning" disabled style={style}>
          支付按钮
        </Button>
      </Form.Item>
      <Form.Item label="警示按钮" align="middle">
        <Button variant="solid" theme="error" style={style}>
          次要按钮
        </Button>
        <Button variant="solid" theme="error" loading style={style}>
          次要按钮
        </Button>
        <Button variant="solid" theme="error" disabled style={style}>
          次要按钮
        </Button>
      </Form.Item>
      <Form.Item label="功能按钮" align="middle">
        <BadgeContainer
          style={style}
          offset={[-33, 8]}
          content={
            <Tag variant="soft" theme="warning" size="sm">
              3.5折
            </Tag>
          }
        >
          <Button variant="outlined" theme="neutral">
            <HomeIcon size={16} />
            功能增值
          </Button>
        </BadgeContainer>
        <BadgeContainer
          style={style}
          offset={[-33, 8]}
          content={
            <Tag variant="soft" theme="warning" size="sm">
              3.5折
            </Tag>
          }
        >
          <Button variant="outlined" theme="neutral" loading>
            <HomeIcon size={16} />
            功能增值
          </Button>
        </BadgeContainer>
        <BadgeContainer
          style={style}
          offset={[-33, 8]}
          content={
            <Tag variant="soft" theme="warning" size="sm">
              3.5折
            </Tag>
          }
        >
          <Button variant="outlined" theme="neutral" disabled>
            <HomeIcon size={16} />
            功能增值
          </Button>
        </BadgeContainer>
      </Form.Item>
    </Form>
  );
}
