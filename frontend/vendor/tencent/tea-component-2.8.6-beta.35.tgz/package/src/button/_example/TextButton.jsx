﻿import React from "react";
import { Button, Form } from "@tencent/tea-component";

export default function TextButtonExample() {
  const style = { marginRight: 5 };
  return (
    <Form>
      <Form.Item label="文本按钮" align="middle">
        <Button variant="plain" theme="neutral" style={style}>
          文本按钮
        </Button>
        <Button variant="plain" theme="neutral" disabled style={style}>
          文本按钮
        </Button>
      </Form.Item>
      <Form.Item label="文本按钮（强化）" align="middle">
        <Button variant="plain" theme="brand" style={style}>
          文本按钮
        </Button>
        <Button variant="plain" theme="brand" disabled style={style}>
          文本按钮
        </Button>
      </Form.Item>
      <hr />
      <Form.Item label="链接按钮" align="middle">
        <Button variant="link" theme="neutral" style={style}>
          文本按钮
        </Button>
        <Button variant="link" theme="neutral" disabled style={style}>
          文本按钮
        </Button>
      </Form.Item>
      <Form.Item label="链接按钮（强化）" align="middle">
        <Button variant="link" theme="brand" style={style}>
          文本按钮
        </Button>
        <Button variant="link" theme="brand" disabled style={style}>
          文本按钮
        </Button>
      </Form.Item>
    </Form>
  );
}
