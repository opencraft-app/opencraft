﻿import React from "react";
import { Button, Form } from "@tencent/tea-component";
import { MonitorIcon } from "@tencent/tea-icons-react";

export default function IconButtonExample() {
  const style = { marginRight: 5 };
  return (
    <Form>
      <Form.Item label="普通" align="middle">
        <Button icon="monitor" title="监控" style={style} />
        <Button icon="monitor" title="监控" loading style={style} />
        <Button icon="monitor" title="监控" disabled style={style} />
        <Button title="监控" variant="plain" style={style}>
          <MonitorIcon size={16} />
          按钮
        </Button>
        <Button title="监控" variant="plain" disabled style={style}>
          <MonitorIcon size={16} />
          按钮
        </Button>
      </Form.Item>
      <Form.Item label="带框" align="middle">
        <Button
          icon="monitor"
          shape="square"
          variant="outlined"
          theme="neutral"
          title="监控"
          style={style}
        />
        <Button
          icon="monitor"
          shape="square"
          variant="outlined"
          theme="neutral"
          title="监控"
          loading
          style={style}
        />
        <Button
          icon="monitor"
          shape="square"
          variant="outlined"
          theme="neutral"
          title="监控"
          disabled
          style={style}
        />
        <Button title="监控" style={style}>
          <MonitorIcon size={16} />
          按钮
        </Button>

        <Button title="监控" disabled style={style}>
          <MonitorIcon size={16} />
          按钮
        </Button>
      </Form.Item>
      <Form.Item label="加强" align="middle">
        <Button
          icon="monitor"
          shape="square"
          variant="solid"
          theme="brand"
          title="监控"
          style={style}
        />
        <Button
          icon="monitor"
          shape="square"
          variant="solid"
          theme="brand"
          title="监控"
          loading
          style={style}
        />
        <Button
          icon="monitor"
          shape="square"
          variant="solid"
          theme="brand"
          title="监控"
          disabled
          style={style}
        />
        <Button title="监控" variant="solid" theme="brand" style={style}>
          <MonitorIcon size={16} />
          按钮
        </Button>
        <Button
          title="监控"
          variant="solid"
          theme="brand"
          disabled
          style={style}
        >
          <MonitorIcon size={16} />
          按钮
        </Button>
      </Form.Item>
    </Form>
  );
}
