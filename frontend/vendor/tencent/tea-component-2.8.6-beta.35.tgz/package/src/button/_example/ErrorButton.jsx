﻿import React from "react";
import { Button } from "@tencent/tea-component";

export default function WeakButtonExample() {
  const style = { marginRight: 5 };
  return (
    <>
      <Button type="error" style={style}>
        错误按钮
      </Button>
      <Button type="error" style={style} loading>
        错误按钮
      </Button>
      <Button type="error" style={style} disabled>
        禁用
      </Button>
      <hr />
      <Button variant="solid" theme="error" style={style}>
        支付按钮
      </Button>
      <Button variant="solid" theme="error" loading style={style}>
        支付按钮
      </Button>
      <Button variant="solid" theme="error" disabled style={style}>
        支付按钮
      </Button>
    </>
  );
}
