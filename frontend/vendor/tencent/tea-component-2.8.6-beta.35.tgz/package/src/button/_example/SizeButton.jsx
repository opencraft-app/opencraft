﻿import React from "react";
import { Button } from "@tencent/tea-component";

export default function SizeButtonExample() {
  const style = { marginRight: 5 };
  return (
    <>
      <Button variant="solid" theme="brand" size="sm" style={style}>
        按钮
      </Button>
      <Button variant="outlined" size="sm" style={style}>
        按钮
      </Button>
      <Button
        variant="outlined"
        size="sm"
        style={style}
        icon="viewgrid"
      ></Button>
      <Button variant="plain" theme="neutral" size="sm" style={style}>
        按钮
      </Button>
      <Button variant="link" theme="brand" size="sm" style={style}>
        按钮
      </Button>

      <hr style={{ margin: "12px 0" }} />
      <Button variant="solid" theme="brand" style={style}>
        按钮
      </Button>
      <Button variant="outlined" style={style}>
        按钮
      </Button>
      <Button variant="outlined" style={style} icon="viewgrid"></Button>
      <Button variant="plain" theme="neutral" style={style}>
        按钮
      </Button>
      <Button variant="link" theme="brand" style={style}>
        按钮
      </Button>

      <hr style={{ margin: "12px 0" }} />
      <Button variant="solid" theme="brand" size="lg" style={style}>
        按钮
      </Button>
      <Button variant="outlined" size="lg" style={style}>
        按钮
      </Button>
      <Button
        variant="outlined"
        size="lg"
        style={style}
        icon="viewgrid"
      ></Button>
      <Button variant="plain" theme="neutral" size="lg" style={style}>
        按钮
      </Button>
      <Button variant="link" theme="brand" size="lg" style={style}>
        按钮
      </Button>
    </>
  );
}
