﻿import React from "react";
import { Button } from "@tencent/tea-component";

export default function WeakButtonExample() {
  const style = { marginRight: 5 };
  return (
    <>
      <Button type="weak" style={style}>
        次要按钮
      </Button>
      <Button type="weak" style={style} loading>
        次要按钮
      </Button>
      <Button type="weak" style={style} disabled>
        禁用
      </Button>
      <hr />
      <Button style={style}>次要按钮</Button>
      <Button style={style} loading>
        次要按钮
      </Button>
      <Button style={style} disabled>
        次要按钮
      </Button>
    </>
  );
}
