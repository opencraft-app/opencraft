import React from "react";
import { Button } from "@tencent/tea-component";

export default function ButtonThemeVariantExample() {
  const style = { marginRight: 10, marginBottom: 10 };
  return (
    <>
      <Button type="primary" style={style}>
        primary button
      </Button>
      <Button type="error" style={style}>
        error button
      </Button>
      <Button type="pay" style={style}>
        pay button
      </Button>
      <Button type="link" style={style}>
        link button
      </Button>
      <Button type="text" style={style}>
        text button
      </Button>
      <Button type="weak" style={style}>
        weak
      </Button>
      <Button icon="shopcart" style={style}>
        icon
      </Button>
    </>
  );
}
