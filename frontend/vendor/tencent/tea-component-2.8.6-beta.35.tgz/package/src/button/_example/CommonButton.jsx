﻿import React from "react";
import { Button, Form } from "@tencent/tea-component";

export default function CommonButtonExample() {
  const style = { marginRight: 5 };
  return (
    <Form>
      <Form.Item label="主要按钮" align="middle">
        <Button variant="solid" theme="brand" style={style}>
          主要按钮
        </Button>
        <Button variant="solid" theme="brand" loading style={style}>
          主要按钮
        </Button>
        <Button variant="solid" theme="brand" disabled style={style}>
          主要按钮
        </Button>
      </Form.Item>
      <Form.Item label="次要按钮" align="middle">
        <Button variant="outlined" style={style}>
          次要按钮
        </Button>
        <Button variant="outlined" loading style={style}>
          次要按钮
        </Button>
        <Button variant="outlined" disabled style={style}>
          次要按钮
        </Button>
      </Form.Item>
    </Form>
  );
}
