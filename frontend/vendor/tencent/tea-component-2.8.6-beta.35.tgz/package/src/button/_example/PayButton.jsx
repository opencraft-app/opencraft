﻿import React from "react";
import { Button } from "@tencent/tea-component";

export default function PayButtonExample() {
  const style = { marginRight: 5 };
  return (
    <>
      <Button type="pay" style={style}>
        支付按钮
      </Button>
      <Button type="pay" style={style} loading>
        支付按钮
      </Button>
      <Button type="pay" style={style} disabled>
        禁用
      </Button>
      <hr />
      <Button variant="solid" theme="warning" style={style}>
        支付按钮
      </Button>
      <Button variant="solid" theme="warning" loading style={style}>
        支付按钮
      </Button>
      <Button variant="solid" theme="warning" disabled style={style}>
        支付按钮
      </Button>
    </>
  );
}
