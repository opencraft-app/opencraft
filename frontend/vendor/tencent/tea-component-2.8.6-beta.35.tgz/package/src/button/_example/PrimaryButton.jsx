﻿import React from "react";
import { Button } from "@tencent/tea-component";

export default function PrimaryButtonExample() {
  const style = { marginRight: 5 };
  return (
    <>
      <Button type="primary" style={style}>
        主要按钮
      </Button>
      <Button type="primary" style={style} loading>
        主要按钮
      </Button>
      <Button type="primary" style={style} disabled>
        禁用
      </Button>
      <hr />
      <Button variant="solid" theme="brand" style={style}>
        主要按钮
      </Button>
      <Button variant="solid" theme="brand" loading style={style}>
        主要按钮
      </Button>
      <Button variant="solid" theme="brand" disabled style={style}>
        主要按钮
      </Button>
    </>
  );
}
