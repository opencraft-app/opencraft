import React, { useState } from "react";
import { Upload, Button, Text } from "@tencent/tea-component";

export default function SingleFileUploadExample() {
  const [fileList, setFileList] = useState([]);
  const [uploading, setUploading] = useState(null);

  function handleStart() {
    setUploading(true);
  }

  function handleSuccess(result, { file }) {
    setFileList(fileList => [
      ...fileList,
      { name: file.name, status: "success" },
    ]);
    setUploading(false);
    console.log(result);
  }

  function handleError(error, { file }) {
    setFileList(fileList => [
      ...fileList,
      { name: file.name, status: "danger" },
    ]);
    setUploading(false);
    console.error(error);
  }

  return (
    <>
      <Upload
        action="https://run.mocky.io/v3/68ed7204-0487-4135-857d-0e4366b2cfad"
        onStart={handleStart}
        onSuccess={handleSuccess}
        onError={handleError}
      >
        <Button loading={uploading}>点击上传</Button>
      </Upload>
      {!!fileList.length && <hr />}
      {fileList.map((file, index) => (
        <p key={index}>
          <Text theme={file.status}>{file.name}</Text>
        </p>
      ))}
    </>
  );
}
