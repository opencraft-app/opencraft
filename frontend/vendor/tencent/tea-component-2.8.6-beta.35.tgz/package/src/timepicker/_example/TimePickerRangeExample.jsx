import React, { useState } from "react";
import moment from "moment";
import { TimePicker } from "@tencent/tea-component";

export default () => {
  const [time, setTime] = useState(null);

  return (
    <TimePicker
      value={time}
      range={[moment("09:30:00", "HH:mm:ss"), moment("17:30:00", "HH:mm:ss")]}
      onChange={value => {
        setTime(value);
        console.log(value.format("HH:mm:ss"));
      }}
    />
  );
};
