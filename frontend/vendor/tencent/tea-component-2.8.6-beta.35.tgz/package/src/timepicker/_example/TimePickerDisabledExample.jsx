import React from "react";
import { TimePicker } from "@tencent/tea-component";

const range = (s, t) =>
  Array(t - s + 1)
    .fill(0)
    .map((_, i) => s + i);

export default () => {
  return (
    <TimePicker
      secondStep={30}
      disabledHours={() => [...range(0, 8), ...range(13, 14), ...range(18, 23)]}
      disabledMinutes={hour => (hour === 12 ? range(30, 59) : [])}
      onChange={value => console.log(value.format("HH:mm:ss"))}
    />
  );
};
