import React from "react";
import { Copy } from "@tencent/tea-component";

export default function CopyExample() {
  return (
    <Copy text="测试内容">
      <a>复制</a>
    </Copy>
  );
}
