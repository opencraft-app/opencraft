import React, { useState } from "react";
import {
  MediaObject,
  Segment,
  Switch,
  H4,
  useClassNames,
} from "@tencent/tea-component";

const media = <img src="//placehold.it/64x64" alt="Generic placeholder" />;

export default function MediaObjectExample() {
  const [align, setAlign] = useState("top");
  const [reverse, setReverse] = useState(false);
  const { Margin } = useClassNames();

  const content = (
    <>
      <H4 className={Margin.Bottom["2n"]}>Media heading</H4>
      <p>
        Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque
        ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at,
        tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate
        fringilla. Donec lacinia congue felis in faucibus. Cras sit amet nibh
        libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin
        commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra
        turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec
        lacinia congue felis in faucibus.
      </p>
    </>
  );

  return (
    <>
      <MediaObject
        media={media}
        // @ts-ignore
        align={align}
        reverse={reverse}
      >
        {content}
      </MediaObject>
      <section>
        对齐方式：
        <Segment
          options={[{ value: "top" }, { value: "middle" }, { value: "bottom" }]}
          value={align}
          onChange={value => setAlign(value)}
        />
      </section>
      <section>
        反置：
        <Switch value={reverse} onChange={value => setReverse(value)} />
      </section>
    </>
  );
}
