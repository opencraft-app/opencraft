import React from "react";
import * as monaco from "monaco-editor/esm/vs/editor/editor.api";
import { MonacoEditor } from "@tencent/tea-component";

const { DiffEditor } = MonacoEditor;

const code1 = `function hello() {
	alert('Hello world!');
}
`;

const code2 = `function hello() {
	console.log('Hello world!');
}
`;

export default function MonacoEditorExample() {
  return (
    <DiffEditor
      monaco={monaco}
      height={400}
      language="javascript"
      original={code1}
      defaultValue={code2}
    />
  );
}
