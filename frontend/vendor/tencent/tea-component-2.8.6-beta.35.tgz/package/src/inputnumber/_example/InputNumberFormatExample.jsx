import React from "react";
import { InputNumber } from "@tencent/tea-component";

export default function InputNumberFormatExample() {
  return (
    <>
      <InputNumber
        onChange={value => {
          console.log(value);
        }}
        min={0}
        step={100}
        size="l"
        formatter={value => `¥ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ",")}
        parser={value => Number(value.replace(/¥\s?|(,*)/g, ""))}
      />
      <hr />
      <InputNumber
        onChange={value => {
          console.log(value);
        }}
        min={0}
        max={100}
        step={1}
        formatter={value => `${value}%`}
        parser={value => Number(value.replace("%", ""))}
      />
    </>
  );
}
