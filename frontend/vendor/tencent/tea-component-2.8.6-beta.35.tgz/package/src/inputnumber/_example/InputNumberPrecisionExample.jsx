import React from "react";
import { InputNumber } from "@tencent/tea-component";

export default function InputNumberPrecisionExample() {
  return (
    <>
      <InputNumber
        onChange={value => {
          console.log(value);
        }}
        min={0}
        step={0.01}
        size="l"
      />
      <hr />
      <InputNumber
        min={0}
        max={100}
        size="l"
        precision={2}
        onChange={value => {
          console.log(value);
        }}
        formatter={value => `${value}%`}
        parser={value => Number(value.replace("%", ""))}
      />
    </>
  );
}
