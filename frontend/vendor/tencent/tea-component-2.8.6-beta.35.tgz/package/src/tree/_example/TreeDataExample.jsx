import React, { useState } from "react";
import { Tree } from "@tencent/tea-component";

const data = [
  {
    id: "0-0",
    content: "0-0",
    children: [
      {
        id: "0-0-0",
        content: "0-0-0",
        children: [
          { id: "0-0-0-0", content: "0-0-0-0" },
          { id: "0-0-0-1", content: "0-0-0-1" },
        ],
      },
      {
        id: "0-0-1",
        content: "0-0-1",
        children: [
          { id: "0-0-1-0", content: "0-0-1-0" },
          { id: "0-0-1-1", content: "0-0-1-1" },
          { id: "0-0-1-2", content: "0-0-1-2" },
        ],
      },
    ],
  },
];

export default function TreeExample() {
  const [selectIds, setSelectIds] = useState(["0-0-0-1"]);
  return (
    <Tree
      data={data}
      selectable
      selectedIds={selectIds}
      onSelect={(value, context) => {
        console.log(value, context);
        setSelectIds(value);
      }}
      defaultExpandedIds={["0-0", "0-0-0"]}
    />
  );
}
