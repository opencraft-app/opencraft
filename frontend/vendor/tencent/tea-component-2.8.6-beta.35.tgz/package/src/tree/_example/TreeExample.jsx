import React, { useState } from "react";
import { Tree } from "@tencent/tea-component";

export default function TreeExample() {
  const [selectIds, setSelectIds] = useState(["0-0-0-1"]);
  return (
    <Tree
      selectable
      selectedIds={selectIds}
      onSelect={(value, context) => {
        console.log(value, context);
        setSelectIds(value);
      }}
      defaultExpandedIds={["0-0-0"]}
    >
      <Tree.Node id="0-0" content="0-0">
        <Tree.Node id="0-0-0" content="0-0-0">
          <Tree.Node id="0-0-0-0" content="0-0-0-0" />
          <Tree.Node id="0-0-0-1" content="0-0-0-1" />
        </Tree.Node>
        <Tree.Node id="0-0-1" content="0-0-1">
          <Tree.Node id="0-0-1-0" content="0-0-1-0" />
          <Tree.Node id="0-0-1-1" content="0-0-1-1" />
          <Tree.Node id="0-0-1-2" content="0-0-1-2" />
        </Tree.Node>
      </Tree.Node>
      <Tree.Node id="0-1" content="0-1" />
    </Tree>
  );
}
