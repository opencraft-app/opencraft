import React, { useState } from "react";
import { Tree } from "@tencent/tea-component";

const data = [
  {
    id: "0-0",
    content: "0-0",
    children: [
      {
        id: "0-0-0",
        content: "0-0-0",
        onClick: () => console.log("0-0-0 clicked"),
        onDragStart: () => console.log("0-0-0 dragstart"),
        children: [
          {
            id: "0-0-0-0",
            content: "0-0-0-0",
            onClick: () => console.log("0-0-0-0 clicked"),
            onDragStart: () => console.log("0-0-0-0 dragstart"),
          },
          {
            id: "0-0-0-1",
            content: "0-0-0-1",
            onClick: () => console.log("0-0-0-1 clicked"),
          },
        ],
      },
      {
        id: "0-0-1",
        content: "0-0-1",
        children: [
          { id: "0-0-1-0", content: "0-0-1-0" },
          { id: "0-0-1-1", content: "0-0-1-1" },
          { id: "0-0-1-2", content: "0-0-1-2" },
        ],
      },
    ],
  },
];

export default function TreeDataClickExample() {
  return <Tree data={data} defaultExpandedIds={["0-0", "0-0-0"]} />;
}
