import React, { useState } from "react";
import { Status, Form, Segment, Card, Button } from "@tencent/tea-component";

export default function StatusExample() {
  const [icon, setIcon] = useState("blank");
  const [title, setTitle] = useState("暂无数据");
  const [size, setSize] = useState("l");

  return (
    <>
      <Form style={{ marginBottom: 20 }}>
        <Form.Item label="图标">
          <Segment
            value={icon}
            onChange={icon => {
              setIcon(icon);
              if (icon === "blank") {
                setTitle("暂无数据");
              } else if (icon === "chart") {
                setTitle("图表暂无数据");
              } else if (icon === "loading") {
                setTitle("加载中");
              } else if (icon === "network") {
                setTitle("网络异常");
              } else if (icon === "no-permission") {
                setTitle("暂无权限");
              } else if (icon === "pay") {
                setTitle("暂无支付数据");
              } else if (icon === "search") {
                setTitle("搜索无结果");
              } else if (icon === "upload") {
                setTitle("上传内容");
              } else if (icon === "error") {
                setTitle("出错状态");
              } else if (icon === "positive") {
                setTitle("正向反馈");
              }
            }}
            options={[
              { value: "blank", bubble: "暂无数据" },
              { value: "chart", bubble: "图表暂无数据" },
              { value: "loading", bubble: "加载中" },
              { value: "network", bubble: "网络异常" },
              { value: "no-permission", bubble: "暂无权限" },
              { value: "pay", bubble: "暂无支付数据" },
              { value: "search", bubble: "搜索无结果" },
              { value: "upload", bubble: "上传内容" },
              { value: "error", bubble: "出错状态" },
              { value: "positive", bubble: "正向反馈" },
            ]}
          />
        </Form.Item>
        <Form.Item label="尺寸">
          <Segment
            value={size}
            onChange={size => setSize(size)}
            options={[
              { value: "l" },
              { value: "m" },
              { value: "s" },
              { value: "xs" },
            ]}
          />
        </Form.Item>
      </Form>

      <div className="example-stage">
        <Card>
          <Status
            // @ts-ignore
            icon={icon}
            // @ts-ignore
            size={size}
            title={size === "l" && title}
            description="该状态的详细描述"
            operation={
              <>
                <Button variant="link" theme="brand">
                  操作按钮
                </Button>
              </>
            }
          />
        </Card>
      </div>
    </>
  );
}
