import React, { useState } from "react";
import {
  LightMode,
  DarkMode,
  Drawer,
  Button,
  CssToken,
} from "@tencent/tea-component";

const CustomDiv = ({ children, style }) => {
  return <div style={style}>{children}</div>;
};

export default () => {
  const [visible, setVisible] = useState(false);
  /** @type {React.CSSProperties} */
  const customDivStyle = {
    borderColor: CssToken.colorBorderPrimaryDefault,
    color: CssToken.colorTextPrimary,
    background: CssToken.colorBgPrimaryDefault,
    height: 26,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flex: 1,
  };
  return (
    <>
      <section style={{ display: "flex", gap: 12, alignItems: "center" }}>
        <LightMode>
          <CustomDiv style={customDivStyle}>浅色</CustomDiv>
        </LightMode>
        <DarkMode>
          <CustomDiv style={customDivStyle}>深色</CustomDiv>
        </DarkMode>
        <Button onClick={() => setVisible(true)}>打开深色抽屉</Button>
      </section>
      <DarkMode>
        <Drawer
          visible={visible}
          title="Title"
          onClose={() => setVisible(false)}
        >
          注入theme-mode
        </Drawer>
      </DarkMode>
    </>
  );
};
