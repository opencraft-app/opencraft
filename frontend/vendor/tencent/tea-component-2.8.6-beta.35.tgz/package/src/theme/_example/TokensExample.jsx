import React, { useLayoutEffect, useMemo, useRef, useState } from "react";
import {
  CssToken,
  Table,
  Copy,
  Tag,
  Text,
  Segment,
  SearchBox,
} from "@tencent/tea-component";
import { FileCopyIcon } from "@tencent/tea-icons-react";

const renderShadow = shadow => (
  <div
    style={{
      padding: "var(--tea-space-500)",
      borderRadius: "var(--tea-border-radius-100)",
      background: "var(--tea-color-bg-page-default)",
    }}
  >
    <div
      style={{
        borderRadius: "var(--tea-border-radius-100)",
        minHeight: "50px",
        background: "var(--tea-color-bg-primary-default)",
        boxShadow: shadow.cssValue,
      }}
    ></div>
  </div>
);

const renderBorder = border => {
  const { tokenName, cssValue } = border;
  if (tokenName.startsWith("borderRadius")) {
    return (
      <div
        style={{
          width: 20,
          aspectRatio: "1/1",
          borderRadius: cssValue,
          background: "var(--tea-color-text-primary)",
        }}
      ></div>
    );
  }
  if (tokenName.startsWith("borderWidth")) {
    return (
      <div
        style={{
          height: "100%",
          display: "flex",
          alignItems: "center",
        }}
      >
        <div
          style={{
            flex: 1,
            height: cssValue,
            background: "var(--tea-color-text-primary)",
          }}
        ></div>
      </div>
    );
  }
  return null;
};

const renderSpace = space => {
  return (
    <div
      style={{
        height: "50px",
        display: "flex",
        alignItems: "center",
      }}
    >
      <div
        style={{
          minHeight: "10px",
          aspectRatio: "1/1",
          background: "var(--tea-color-text-primary)",
          borderRadius: "var(--tea-border-radius-full)",
        }}
      ></div>
      <div
        style={{
          minHeight: "30px",
          background: "var(--tea-color-text-tertiary)",
          width: space.cssValue,
        }}
      ></div>
      <div
        style={{
          minHeight: "10px",
          aspectRatio: "1/1",
          background: "var(--tea-color-text-primary)",
          borderRadius: "var(--tea-border-radius-full)",
        }}
      ></div>
    </div>
  );
};

const renderFont = font => {
  const { tokenName, cssValue } = font;
  if (tokenName.startsWith("fontSize")) {
    return (
      <div
        style={{
          display: "flex",
          alignItems: "center",
          fontSize: cssValue,
          color: "var(--tea-color-text-primary)",
        }}
      >
        Aa
      </div>
    );
  }
  if (tokenName.startsWith("fontWeight")) {
    return (
      <div
        style={{
          display: "flex",
          alignItems: "center",
          fontWeight: cssValue,
          color: "var(--tea-color-text-primary)",
        }}
      >
        Aa
      </div>
    );
  }
  if (tokenName.startsWith("fontFamily")) {
    return (
      <div
        style={{
          display: "flex",
          alignItems: "center",
          fontFamily: cssValue,
          color: "var(--tea-color-text-primary)",
        }}
      >
        Tencent
      </div>
    );
  }
  if (tokenName.startsWith("fontLineHeight")) {
    return (
      <div
        style={{
          display: "flex",
          alignItems: "center",
          lineHeight: cssValue,
          color: "var(--tea-color-text-primary)",
        }}
      >
        Tea makes design more enjoyable and easier to build
        <br />
        Tea makes life better with a good UI toolkit
      </div>
    );
  }
  return null;
};

const renderTypography = typography => {
  const { cssValue } = typography;
  return (
    <div
      style={{
        font: cssValue,
      }}
    >
      Tea makes design more enjoyable and easier to build
    </div>
  );
};

const TOKEN_TYPE_NAMES = {
  all: "全部",
  color: "颜色",
  shadow: "阴影",
  border: "边框",
  space: "间距",
  font: "字体",
  typography: "排版",
  palette: "色板",
};

/**
 * @param {string} tokenName
 * @returns {(keyof typeof TOKEN_TYPE_NAMES) | 'other'}
 * */
function getTokenType(tokenName) {
  if (tokenName.startsWith("colorPalette")) {
    return "palette";
  }
  if (tokenName.startsWith("color") || tokenName.startsWith("formColor")) {
    return "color";
  }
  if (
    ["shadowXs", "shadowSm", "shadowMd", "shadowLg", "shadowXl"].includes(
      tokenName
    )
  ) {
    return "shadow";
  }
  for (const type of ["border", "space", "font"]) {
    if (tokenName.startsWith(type)) {
      // @ts-ignore
      return type;
    }
  }
  const isTypographyItem = name => {
    const typographyItems = [
      "FontFamily",
      "FontSize",
      "LineHeight",
      "FontWeight",
    ];
    return typographyItems.some(item => name.endsWith(item));
  };
  if (tokenName.startsWith("typography") && !isTypographyItem(tokenName)) {
    return "typography";
  }
  return "other";
}

const TOKEN_RECORDS = Object.entries(CssToken)
  .map(([tokenName, tokenValue]) => {
    const tokenType = getTokenType(tokenName);
    const tokenTypeName = TOKEN_TYPE_NAMES[tokenType];
    const jsValue = `CssToken.${tokenName}`;
    const cssValue = CssToken[tokenName];
    return {
      tokenName,
      tokenValue,
      tokenType,
      tokenTypeName,
      jsValue,
      cssValue,
    };
  })
  .filter(x => x.tokenType !== "other");
export default () => {
  const [keyword, setKeyword] = useState("");
  const [filterType, setFilterType] = useState("color");

  const keywordActivated = keyword.trim().length > 2;

  const filteredRecords = useMemo(() => {
    if (keywordActivated) {
      return TOKEN_RECORDS.filter(x =>
        x.tokenName
          .toLocaleLowerCase()
          .includes(keyword.trim().toLocaleLowerCase())
      );
    }
    if (filterType !== "all") {
      return TOKEN_RECORDS.filter(x => x.tokenType === filterType);
    }
    return TOKEN_RECORDS;
  }, [keyword, keywordActivated, filterType]);

  return (
    <>
      <Table.ActionPanel
        style={{ display: "flex", alignItems: "center", gap: 12 }}
      >
        <SearchBox
          placeholder="快速查找 (3 字符以上)"
          size="m"
          value={keyword}
          onChange={setKeyword}
          autoFocus
        />
        <Segment
          options={Object.entries(TOKEN_TYPE_NAMES).map(([type, name]) => ({
            value: type,
            text: name,
          }))}
          value={keywordActivated ? "all" : filterType}
          onChange={setFilterType}
          disabled={keywordActivated}
        />
      </Table.ActionPanel>
      <Table
        compact
        bordered
        records={filteredRecords}
        addons={[
          Table.addons.autotip({
            foundKeyword: keyword,
            isFound: keywordActivated,
          }),
        ]}
        columns={[
          {
            key: "preview",
            header: "效果预览",
            render: x => {
              switch (x.tokenType) {
                case "color":
                case "palette":
                  return <ColorPreview color={x.cssValue} />;
                case "border":
                  return renderBorder(x);
                case "font":
                  return renderFont(x);
                case "shadow":
                  return renderShadow(x);
                case "space":
                  return renderSpace(x);
                case "typography":
                  return renderTypography(x);
              }
              return "暂不支持";
            },
          },
          {
            key: "var",
            header: "Token",
            width: 300,
            render: x => <Text theme="primary">{x.tokenName}</Text>,
          },
          {
            key: "copy",
            header: "复制",
            width: 250,
            render: x => (
              <>
                <Copy
                  text={x.jsValue}
                  tips={copied => (
                    <div
                      style={{ display: "flex", alignItems: "center", gap: 4 }}
                    >
                      <Tag className="tea-tag--unlimited-width" theme="primary">
                        {x.jsValue}
                      </Tag>
                      {copied ? "已复制" : "点击复制"}
                    </div>
                  )}
                  placement="left"
                >
                  <Tag className="tea-tag--unlimited-width" theme="primary">
                    <FileCopyIcon />
                    JS 变量
                  </Tag>
                </Copy>

                <Copy
                  text={x.cssValue}
                  placement="right"
                  tips={copied => (
                    <div
                      style={{ display: "flex", alignItems: "center", gap: 4 }}
                    >
                      {copied ? "已复制" : "点击复制"}
                      <Tag className="tea-tag--unlimited-width" theme="warning">
                        {x.cssValue}
                      </Tag>
                    </div>
                  )}
                >
                  <Tag
                    className="tea-tag--unlimited-width"
                    theme="warning"
                    style={{ marginLeft: 4 }}
                  >
                    <FileCopyIcon /> CSS 变量
                  </Tag>
                </Copy>
              </>
            ),
          },
        ]}
      />
    </>
  );
};

function ColorPreview({ color }) {
  return (
    <div
      style={{
        backgroundColor: color,
        display: "block",
        height: 20,
        border: "1px solid #ccc",
      }}
    ></div>
  );
}
