import React from "react";
import { CssToken } from "@tencent/tea-component";

export default () => (
  <div
    style={{
      color: CssToken.colorTextBrandDefault,
      background: CssToken.colorBgPageDefault,
      height: "50px",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
    }}
  >
    我是主题文字
  </div>
);
