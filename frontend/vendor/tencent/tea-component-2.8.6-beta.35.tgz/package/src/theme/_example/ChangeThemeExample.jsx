import React, { useState } from "react";
import { CssToken, Switch, Text, ThemeMode } from "@tencent/tea-component";

export default () => {
  const [darkMode, setDarkMode] = useState(false);

  return (
    <>
      <div style={{ marginBottom: "12px" }}>
        <Switch value={darkMode} onChange={setDarkMode}>
          深色主题
        </Switch>
      </div>
      <ThemeMode mode={darkMode ? "dark" : "light"}>
        <div
          style={{
            border: "1px solid",
            borderColor: CssToken.colorBorderPrimaryDefault,
            color: CssToken.colorBgBrandDefault,
            background: CssToken.colorBgPrimaryDefault,
            height: "50px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          Tea design makes it easy to build a beautiful UI
        </div>
        <p style={{ marginTop: 12 }}>
          📢 注意：
          <Text theme="warning">
            控制台业务，框架统一控制深浅模式，无需包裹 ThemeMode
          </Text>
        </p>
      </ThemeMode>
    </>
  );
};
