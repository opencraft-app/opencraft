import React from "react";
import { message, Button } from "@tencent/tea-component";

export default function NotificationExample() {
  return (
    <>
      <Button
        onClick={() =>
          message.success({
            content: "这是一条成功提示",
          })
        }
      >
        Success
      </Button>
      <Button
        onClick={() =>
          message.warning({
            content: "这是一条警告提示",
          })
        }
      >
        Warning
      </Button>
      <Button
        onClick={() =>
          message.error({
            content: "这是一条异常提示",
          })
        }
      >
        Error
      </Button>
      <Button
        onClick={() =>
          message.loading({
            content: "加载中 ...",
          })
        }
      >
        Loading
      </Button>
    </>
  );
}
