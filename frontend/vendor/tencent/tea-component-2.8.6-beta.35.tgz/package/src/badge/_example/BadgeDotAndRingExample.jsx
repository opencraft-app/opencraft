import React from "react";
import { Badge } from "@tencent/tea-component";

export default function BadgeExample() {
  return (
    <>
      <div style={{ display: "flex", gap: "8px" }}>
        <Badge dot />
        <Badge dot theme="success" />
        <Badge dot theme="warning" />
        <Badge dot theme="danger" />

        <Badge ring />
        <Badge ring theme="success" />
        <Badge ring theme="warning" />
        <Badge ring theme="danger" />
      </div>
    </>
  );
}
