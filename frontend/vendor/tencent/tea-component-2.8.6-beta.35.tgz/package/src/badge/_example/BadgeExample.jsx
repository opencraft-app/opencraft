import React from "react";
import { Badge } from "@tencent/tea-component";

export default function BadgeExample() {
  return (
    <div style={{ display: "flex", gap: "8px", flexDirection: "column" }}>
      <Badge.Container variant="dot">默认</Badge.Container>
      <Badge.Container variant="standard" content={99}>
        默认
      </Badge.Container>
    </div>
  );
}
