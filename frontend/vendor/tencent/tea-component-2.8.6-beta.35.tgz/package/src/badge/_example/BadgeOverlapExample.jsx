import React from "react";
import { Badge, Avatar } from "@tencent/tea-component";
import { NotificationIcon } from "@tencent/tea-icons-react";

export default function BadgeOverlapExample() {
  return (
    <div style={{ display: "flex", gap: "8px", flexDirection: "column" }}>
      <Badge.Container variant="dot">默认</Badge.Container>
      <Badge.Container variant="standard" content={99}>
        默认
      </Badge.Container>
      <Badge.Container variant="dot" overlap="square">
        <NotificationIcon />
      </Badge.Container>
      <Badge.Container variant="standard" overlap="square" content={99}>
        <NotificationIcon />
      </Badge.Container>
      <Badge.Container variant="dot" overlap="circular">
        <Avatar color={Avatar.Color.Blue} text="T" />
      </Badge.Container>
      <Badge.Container variant="standard" overlap="circular" content={99}>
        <Avatar color={Avatar.Color.Blue} text="T" />
      </Badge.Container>
    </div>
  );
}
