import React, { useState } from "react";
import { Badge, Switch } from "@tencent/tea-component";

export default function BadgeZeroExample() {
  const [showZero, setShowZero] = useState(true);
  return (
    <div style={{ display: "flex", gap: "16px", flexDirection: "column" }}>
      <Badge.Container variant="standard" content={0} showZero={showZero}>
        消息提醒
      </Badge.Container>
      <Switch value={showZero} onChange={v => setShowZero(v)}>
        是否显示数目为0的徽章
      </Switch>
    </div>
  );
}
