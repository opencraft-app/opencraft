import React, { useState } from "react";
import { Segment, Badge } from "@tencent/tea-component";

export default function BadgeSegmentExample() {
  const [value, setValue] = useState(2);

  return (
    <Segment
      value={value.toString()}
      onChange={value => setValue(parseInt(value, 10))}
      options={[
        { text: "1个月", value: "1" },
        { text: "2个月", value: "2" },
        {
          text: (
            <>
              <Badge.Container content="8.8折">3个月</Badge.Container>
            </>
          ),
          value: "3",
        },
        { text: "半年", value: "6" },
      ]}
    />
  );
}
