import React, { useState } from "react";
import { Badge, Switch } from "@tencent/tea-component";

export default function BadgeInvisibleExample() {
  const [invisible, setInvisible] = useState(false);
  return (
    <div style={{ display: "flex", gap: "16px", flexDirection: "column" }}>
      <Badge.Container variant="standard" content={99} invisible={invisible}>
        消息提醒
      </Badge.Container>
      <Switch value={invisible} onChange={v => setInvisible(v)}>
        是否隐藏徽章
      </Switch>
    </div>
  );
}
