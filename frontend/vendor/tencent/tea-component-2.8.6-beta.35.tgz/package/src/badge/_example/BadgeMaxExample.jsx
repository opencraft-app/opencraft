import React from "react";
import { Badge } from "@tencent/tea-component";

export default function BadgeMaxExample() {
  return (
    <div style={{ display: "flex", gap: "8px", flexDirection: "column" }}>
      <Badge.Container variant="standard" content={100} max={99}>
        默认
      </Badge.Container>
    </div>
  );
}
