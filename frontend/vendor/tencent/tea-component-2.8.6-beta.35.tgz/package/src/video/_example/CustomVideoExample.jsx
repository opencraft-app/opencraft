import React from "react";
import { Video, Card } from "@tencent/tea-component";

export default function VideoExample() {
  return (
    <Video
      content={
        <>
          {/* eslint-disable-next-line jsx-a11y/media-has-caption */}
          <video controls width="700" height="500">
            <source
              src="https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.webm"
              type="video/webm"
            />
            <source
              src="https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4"
              type="video/mp4"
            />
            Sorry, your browser doesn&apos;t support embedded videos.
          </video>
        </>
      }
      title="自定义弹窗"
    >
      <Card style={{ maxWidth: 300 }}>
        <img
          style={{ width: "100%", display: "block" }}
          src="https://mc.qcloudimg.com/static/img/b43aa57660525ebd16bae0ff1da69c86/image.png"
          alt="bg"
        />
        <Card.Body>自定义弹窗 标题</Card.Body>
      </Card>
    </Video>
  );
}
