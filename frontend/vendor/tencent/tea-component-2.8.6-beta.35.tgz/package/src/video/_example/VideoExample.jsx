import React from "react";
import { Video, Card } from "@tencent/tea-component";

export default function VideoExample() {
  return (
    <Video
      src="https://cloud.tencent.com/edu/learning/quick-play/1795-20219?auto=1&source=gw.pro.media"
      title="腾讯云 CVM 简介"
    >
      <Card style={{ maxWidth: 300 }}>
        <img
          style={{ width: "100%", display: "block" }}
          src="https://mc.qcloudimg.com/static/img/b43aa57660525ebd16bae0ff1da69c86/image.png"
          alt="bg"
        />
        <Card.Body>腾讯云 CVM 简介</Card.Body>
      </Card>
    </Video>
  );
}
