import React from "react";
import { H1, H2, H3, H4, H5, H6 } from "@tencent/tea-component";

export default function HeadingExample() {
  return (
    <>
      <H1>一级标题</H1>
      <H2>二级标题</H2>
      <H3>三级标题</H3>
      <H4>四级标题</H4>
      <H5>五级标题</H5>
      <H6>六级标题</H6>
    </>
  );
}
