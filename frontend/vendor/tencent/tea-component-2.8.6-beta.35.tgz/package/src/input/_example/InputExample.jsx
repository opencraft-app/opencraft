import React, { useState } from "react";
import { Switch, Select, Input } from "@tencent/tea-component";

const { TextArea } = Input;

export default function InputExample() {
  const [size, setSize] = useState(null);
  const [disabled, setDisabled] = useState(false);
  const [readonly, setReadonly] = useState(false);
  const [showCount, setShowCount] = useState(false);

  const [text, setText] = useState("");

  return (
    <>
      {/* Demo 演示区 */}
      <div>
        <Input
          size={size}
          value={text}
          onChange={(value, context) => {
            setText(value);
            console.log(value, context);
          }}
          placeholder="输入文本内容"
          disabled={disabled}
          readonly={readonly}
          onPressEnter={console.log}
        />
      </div>
      <div style={{ marginTop: 10 }}>
        <TextArea
          showCount={showCount}
          size={size}
          value={text}
          onChange={(value, context) => {
            setText(value);
            console.log(value, context);
          }}
          placeholder="输入文本内容"
          disabled={disabled}
          readonly={readonly}
          onPressEnter={console.log}
        />
      </div>
      <div style={{ marginTop: 10 }}>
        <TextArea
          showCount={showCount}
          autoSize={{ maxRows: 10, minRows: 1 }}
          // autoSize
          size={size}
          value={text}
          onChange={(value, context) => {
            setText(value);
            console.log(value, context);
          }}
          placeholder="输入文本内容"
          disabled={disabled}
          readonly={readonly}
          onPressEnter={console.log}
        />
      </div>
      <hr />
      {/* Demo 配置区 */}
      <section>
        <Select
          type="simulate"
          style={{ width: "auto", marginRight: 10 }}
          value={size}
          onChange={value => setSize(value)}
          placeholder="尺寸"
          options={[
            { value: "xs", text: "xs - 极窄" },
            { value: "s", text: "s - 窄" },
            { value: "m", text: "m - 默认" },
            { value: "l", text: "l - 大宽度" },
            { value: "full", text: "full - 全宽" },
          ]}
        />
        <Switch value={disabled} onChange={value => setDisabled(value)}>
          禁用
        </Switch>
        <Switch value={readonly} onChange={value => setReadonly(value)}>
          只读
        </Switch>
        <Switch value={showCount} onChange={value => setShowCount(value)}>
          显示字数统计
        </Switch>
      </section>
    </>
  );
}
