import React from "react";
import { Input } from "@tencent/tea-component";

const { Password } = Input;

export default function InputPasswordExample() {
  return (
    <Password onChange={(value, { valid }) => console.log(value, valid)} />
  );
}
