import React from "react";
import { InputAdornment, Input } from "@tencent/tea-component";

export default function InputAdornmentExample() {
  return (
    <>
      <section>
        <InputAdornment before="www.">
          <Input />
        </InputAdornment>
      </section>

      <section>
        <InputAdornment before="$" after=".00">
          <Input size="s" />
        </InputAdornment>
      </section>
    </>
  );
}
