import React from "react";
import { Collapse, Icon } from "@tencent/tea-component";

export default function CollapseExample() {
  return (
    <Collapse
      icon={active => <Icon type={active ? "minus" : "plus"} />}
      iconPosition="right"
    >
      <Collapse.Panel id="1" title="高级设置">
        <div
          style={{
            height: 40,
            padding: 4,
            backgroundColor: "var(--tea-color-bg-secondary-default)",
          }}
        >
          内容
        </div>
      </Collapse.Panel>
    </Collapse>
  );
}
