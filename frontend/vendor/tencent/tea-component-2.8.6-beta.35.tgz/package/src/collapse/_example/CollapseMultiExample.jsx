import React from "react";
import { Collapse } from "@tencent/tea-component";

export default function CollapseMultiExample() {
  const content = (
    <div
      style={{
        height: 40,
        padding: 4,
        backgroundColor: "var(--tea-color-bg-secondary-default)",
      }}
    >
      内容
    </div>
  );
  return (
    <Collapse defaultActiveIds={["1", "2"]}>
      <Collapse.Panel id="1" title="高级设置 1">
        {content}
      </Collapse.Panel>
      <Collapse.Panel id="2" title="高级设置 2">
        {content}
      </Collapse.Panel>
      <Collapse.Panel id="3" title="高级设置 3">
        {content}
      </Collapse.Panel>
      <Collapse.Panel id="4" title="高级设置 4">
        {content}
      </Collapse.Panel>
    </Collapse>
  );
}
