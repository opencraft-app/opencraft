import React from "react";
import { Row, Col } from "@tencent/tea-component";

export default function GridSplitLineExample() {
  return (
    <Row showSplitLine>
      <Col span={6}>
        <Box>col-6</Box>
      </Col>
      <Col span={6}>
        <Box>col-6</Box>
      </Col>
      <Col span={6}>
        <Box>col-6</Box>
      </Col>
      <Col span={6}>
        <Box>col-6</Box>
      </Col>
    </Row>
  );
}

function Box({ children }) {
  return <div className="demo-grid-box">{children}</div>;
}
