import React from "react";
import { Row, Col } from "@tencent/tea-component";

export default function GridEqualExample() {
  return (
    <Row>
      <Col>
        <Box>一花</Box>
      </Col>
      <Col>
        <Box>二乃</Box>
      </Col>
      <Col>
        <Box>三玖</Box>
      </Col>
      <Col>
        <Box>四叶</Box>
      </Col>
      <Col>
        <Box>五月</Box>
      </Col>
    </Row>
  );
}

function Box({ children }) {
  return <div className="demo-grid-box">{children}</div>;
}
