import React, { useState } from "react";
import {
  Layout,
  Card,
  Text,
  ExternalLink,
  Menu,
  Icon,
} from "@tencent/tea-component";

const { Body, Sider, Content } = Layout;

export default function MenuExample() {
  const [selected, setSelected] = useState("2-1");

  const getMenuItemProps = id => ({
    selected: selected === id,
    onClick: () => setSelected(id),
  });

  return (
    <Layout className="demo-layout-l">
      <Body>
        <Sider>
          <Menu
            back={{
              title: "产品名称产品名称产品名称",
              description: "数据测试",
              tooltip: "产品名称产品名称产品名称 - 数据测试勿删",
              onClick: () => console.log("back"),
            }}
          >
            <Menu.Item title="一级菜单" {...getMenuItemProps("1")} />
            <Menu.SubMenu title="一级菜单">
              <Menu.Item title="二级菜单" {...getMenuItemProps("2-1")} />
              <Menu.Item title="二级菜单" {...getMenuItemProps("2-2")} />
            </Menu.SubMenu>
            <Menu.Group title="菜单分组">
              <Menu.Item
                title={
                  <>
                    一级菜单
                    <Icon type="externallink" />
                  </>
                }
                {...getMenuItemProps("3")}
              />
            </Menu.Group>

            <Menu.Group title="菜单分组">
              <Menu.SubMenu title="一级菜单">
                <Menu.Item title="二级菜单" {...getMenuItemProps("4-1")} />
                <Menu.Item title="二级菜单" {...getMenuItemProps("4-2")} />
              </Menu.SubMenu>
            </Menu.Group>
          </Menu>
        </Sider>
        <Content>
          <Content.Header
            title="内容标题"
            subtitle={
              <>
                说明文字 <Text theme="label">带颜色说明文字</Text>
              </>
            }
            operation={<ExternalLink weak>内容帮助</ExternalLink>}
          />
          <Content.Body>
            {/* 内容区域一般使用 Card 组件显示内容 */}
            <Card>
              <Card.Body>内容卡片</Card.Body>
            </Card>
          </Content.Body>
        </Content>
      </Body>
    </Layout>
  );
}
