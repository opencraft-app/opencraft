import React from "react";
import { Space, Button } from "@tencent/tea-component";

export default function SplitSpace() {
  // 默认分割
  const defaultSplit = (
    <span
      style={{
        display: "block",
        width: 1,
        height: 20,
        background: "red",
      }}
    ></span>
  );
  return (
    <Space split={defaultSplit}>
      <Button>主按钮</Button>
      <Button>主按钮</Button>
      <>纯文字 看对齐</>
      <img src="https://via.placeholder.com/60" alt=""></img>
    </Space>
  );
}
