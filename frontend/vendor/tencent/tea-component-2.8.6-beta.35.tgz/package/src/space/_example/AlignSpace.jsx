import React from "react";
import { Space, Button, Text } from "@tencent/tea-component";

export default function AlignSpace() {
  return (
    <>
      <div
        style={{
          margin: 15,
        }}
      >
        <h4> 默认 </h4>
        <Space>
          <Button>主按钮</Button>
          <Button>主按钮</Button>
          <>纯文字 看对齐</>
          <img src="https://via.placeholder.com/60" alt=""></img>
        </Space>
      </div>
      <div
        style={{
          margin: 15,
        }}
      >
        <h4> start </h4>
        <Space align="start">
          <Button>主按钮</Button>
          <Button>主按钮</Button>
          <>纯文字 看对齐</>
          <img src="https://via.placeholder.com/60" alt=""></img>
        </Space>
      </div>
      <div
        style={{
          margin: 15,
        }}
      >
        <h4> end </h4>
        <Space align="end">
          <Button>主按钮</Button>
          <Button>主按钮</Button>
          <>纯文字 看对齐</>
          <img src="https://via.placeholder.com/60" alt=""></img>
        </Space>
      </div>
      <div
        style={{
          margin: 15,
        }}
      >
        <h4> baseline </h4>
        <Space align="baseline">
          <Button>主按钮</Button>
          <Button>主按钮</Button>
          <>纯文字 看对齐</>
          <img src="https://via.placeholder.com/60" alt=""></img>
        </Space>
      </div>
    </>
  );
}
