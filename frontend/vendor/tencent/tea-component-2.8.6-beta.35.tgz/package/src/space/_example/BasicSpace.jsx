import React from "react";
import { Space, Button } from "@tencent/tea-component";

export default function BasicSpace() {
  return (
    <Space>
      <Button>主按钮</Button>
      <Button>主按钮</Button>
      <>纯文字 看对齐</>
      <img src="https://via.placeholder.com/60" alt=""></img>
    </Space>
  );
}
