import React, { useMemo, useState } from "react";
import {
  List,
  Dropdown,
  Text,
  Status,
  StatusTip,
} from "@tencent/tea-component";
import {
  BrowseIcon,
  PoweroffIcon,
  DashboardIcon,
  RefreshIcon,
  CloudUploadIcon,
  LockOnIcon,
  DesktopIcon,
  MirrorIcon,
  FileIcon,
  DeleteIcon,
} from "@tencent/tea-icons-react";

const listData = [
  {
    type: "item",
    icon: <BrowseIcon />,
    text: "查看详情",
  },
  {
    type: "item",
    icon: <PoweroffIcon />,
    text: "关机",
  },
  {
    type: "item",
    icon: <RefreshIcon />,
    text: "重启",
  },
  {
    type: "item",
    icon: <DashboardIcon />,
    text: "实例自助检测",
  },
  {
    type: "separator",
  },
  {
    type: "item",
    icon: <LockOnIcon />,
    text: "重置密码",
  },
  {
    type: "item",
    icon: <DesktopIcon />,
    text: "重装系统",
  },
  {
    type: "separator",
  },
  {
    type: "item",
    icon: <MirrorIcon />,
    text: "制作镜像",
  },
  {
    type: "item",
    icon: <FileIcon />,
    text: "导入文件",
  },
  {
    type: "item",
    icon: <CloudUploadIcon />,
    text: "升级镜像",
  },
  {
    type: "separator",
  },
  {
    type: "item",
    icon: <DeleteIcon />,
    text: "退还/销毁",
  },
];

export default function SearchableExample() {
  const fullCmds = useMemo(() => {
    return (
      <>
        {listData.map((item, index) => {
          if (item.type === "separator") {
            return <List.ListDivider />;
          }
          if (item.type === "item") {
            return (
              <List.Item key={index}>
                <List.ItemButton>
                  <List.ItemDecorator>{item.icon}</List.ItemDecorator>
                  <List.ItemContent>{item.text}</List.ItemContent>
                </List.ItemButton>
              </List.Item>
            );
          }
          return null;
        })}
      </>
    );
  }, []);
  const [searchText, setSearchText] = useState("");

  const filtedCmds = useMemo(() => {
    if (!searchText) {
      return fullCmds;
    }
    const filtedListData = listData.filter(item => {
      if (item.type === "separator") {
        return false;
      }
      if (item.type === "item") {
        return item.text.includes(searchText);
      }
      return false;
    });
    return (
      <>
        {filtedListData.length <= 0 ? (
          <List.StatusTip>暂无数据</List.StatusTip>
        ) : (
          filtedListData.map((item, index) => {
            const keyIndex = item.text.indexOf(searchText);
            return (
              <List.Item key={index}>
                <List.ItemButton>
                  <List.ItemDecorator>{item.icon}</List.ItemDecorator>
                  <List.ItemContent>
                    <span>
                      {item.text.slice(0, keyIndex)}
                      <Text theme="primary">{searchText}</Text>
                      {item.text.slice(keyIndex + searchText.length)}
                    </span>
                  </List.ItemContent>
                </List.ItemButton>
              </List.Item>
            );
          })
        )}
      </>
    );
  }, [fullCmds, searchText]);

  return (
    <div
      style={{
        display: "flex",
        gap: "10px",
      }}
    >
      <section>
        <Dropdown
          button="带搜索框菜单"
          appearance="button"
          clickClose={false}
          boxStyle={{ width: "175px" }}
        >
          {close => (
            <List type="plain">
              <List.Item>
                <List.SearchBox
                  placeholder="搜索功能或命令..."
                  onClear={() => {
                    setSearchText("");
                  }}
                  onChange={text => {
                    setSearchText(text.trim());
                  }}
                />
              </List.Item>
              {searchText ? filtedCmds : fullCmds}
            </List>
          )}
        </Dropdown>
      </section>
    </div>
  );
}
