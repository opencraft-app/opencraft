import React from "react";
import {
  List,
  Dropdown,
  Tag,
  Text,
  Switch,
  SearchBox,
} from "@tencent/tea-component";
import {
  BrowseIcon,
  PoweroffIcon,
  DashboardIcon,
  RecoverIcon,
  RefreshIcon,
  CloudUploadIcon,
  LockOnIcon,
  DesktopIcon,
  HourglassIcon,
  MirrorIcon,
  FileIcon,
  DeleteIcon,
} from "@tencent/tea-icons-react";

export default function ListExample() {
  return (
    <div
      style={{
        display: "flex",
        gap: "10px",
      }}
    >
      <section>
        <Dropdown button="带图标菜单" appearance="button" clickClose={false}>
          {close => (
            <List type="plain">
              <List.Item>
                <List.ItemButton>
                  <List.ItemDecorator>
                    <BrowseIcon />
                  </List.ItemDecorator>
                  <List.ItemContent>查看详情</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemDecorator>
                    <PoweroffIcon />
                  </List.ItemDecorator>
                  <List.ItemContent>关机</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemDecorator>
                    <RefreshIcon />
                  </List.ItemDecorator>
                  <List.ItemContent>重启</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemDecorator>
                    <DashboardIcon />
                  </List.ItemDecorator>
                  <List.ItemContent>实例自助检测</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.ListDivider />
              <List.Item>
                <List.ItemButton>
                  <List.ItemDecorator>
                    <LockOnIcon />
                  </List.ItemDecorator>
                  <List.ItemContent>重置密码</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemDecorator>
                    <DesktopIcon />
                  </List.ItemDecorator>
                  <List.ItemContent>重装系统</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.ListDivider />
              <List.Item>
                <List.ItemButton>
                  <List.ItemDecorator>
                    <MirrorIcon />
                  </List.ItemDecorator>
                  <List.ItemContent>制作镜像</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemDecorator>
                    <FileIcon />
                  </List.ItemDecorator>
                  <List.ItemContent>导入文件</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemDecorator>
                    <CloudUploadIcon />
                  </List.ItemDecorator>
                  <List.ItemContent>升级镜像</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.ListDivider />
              <List.Item>
                <List.ItemButton>
                  <List.ItemDecorator>
                    <DeleteIcon />
                  </List.ItemDecorator>
                  <List.ItemContent>退换/销毁</List.ItemContent>
                </List.ItemButton>
              </List.Item>
            </List>
          )}
        </Dropdown>
      </section>
      <section>
        <Dropdown button="带注释菜单" appearance="button" clickClose={false}>
          {close => (
            <List type="plain">
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>查看详情</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>关机</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>重启</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>实例自助检测</List.ItemContent>
                  <Text theme="label">⌘ ⌥ A</Text>
                </List.ItemButton>
              </List.Item>
              <List.ListDivider />
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>重置密码</List.ItemContent>
                  <Text theme="label">建议每周更换</Text>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>重装系统</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.ListDivider />
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>制作镜像</List.ItemContent>
                  <Text theme="label">⌘ R</Text>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>导入文件</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>升级镜像</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.ListDivider />
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>退换/销毁</List.ItemContent>
                </List.ItemButton>
              </List.Item>
            </List>
          )}
        </Dropdown>
      </section>
      <section style={{ display: "none" }}>
        <Dropdown
          button="带分类名菜单（推荐搭配图标使用）"
          appearance="button"
          clickClose={false}
        >
          {close => (
            <List type="plain">
              {/* <List.GroupTitle>实例状态</List.GroupTitle> */}
              <List.Item disabled>
                <List.ItemButton>
                  <List.ItemDecorator>
                    <BrowseIcon />
                  </List.ItemDecorator>
                  <List.ItemContent>查看详情</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemDecorator>
                    <PoweroffIcon />
                  </List.ItemDecorator>
                  <List.ItemContent>关机</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemDecorator>
                    <RefreshIcon />
                  </List.ItemDecorator>
                  <List.ItemContent>重启</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemDecorator>
                    <DashboardIcon />
                  </List.ItemDecorator>
                  <List.ItemContent>实例自助检测</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.ListDivider />
              {/* <List.GroupTitle>资源调整</List.GroupTitle> */}
              <List.Item>
                <List.ItemButton>
                  <List.ItemDecorator>
                    <LockOnIcon />
                  </List.ItemDecorator>
                  <List.ItemContent>重置密码</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemDecorator>
                    <DesktopIcon />
                  </List.ItemDecorator>
                  <List.ItemContent>重装系统</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.ListDivider />
              <List.Item>
                <List.ItemButton>
                  <List.ItemDecorator>
                    <MirrorIcon />
                  </List.ItemDecorator>
                  <List.ItemContent>制作镜像</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemDecorator>
                    <FileIcon />
                  </List.ItemDecorator>
                  <List.ItemContent>导入文件</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemDecorator>
                    <CloudUploadIcon />
                  </List.ItemDecorator>
                  <List.ItemContent>升级镜像</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.ListDivider />
              <List.Item>
                <List.ItemButton>
                  <List.ItemDecorator>
                    <DeleteIcon />
                  </List.ItemDecorator>
                  <List.ItemContent>退换/销毁</List.ItemContent>
                </List.ItemButton>
              </List.Item>
            </List>
          )}
        </Dropdown>
      </section>
      <section>
        <Dropdown
          button="带标签菜单（运营/上新）"
          appearance="button"
          clickClose={false}
        >
          {close => (
            <List type="plain">
              {/* <List.GroupLabel>实例状态</List.GroupLabel> */}
              <List.Item disabled>
                <List.ItemButton>
                  <List.ItemContent>查看详情</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>关机</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>重启</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>实例自助检测</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.ListDivider />
              {/* <List.GroupTitle>实例状态</List.GroupTitle> */}
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>重置密码</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>
                    重装系统<Tag size="sm">BETA</Tag>
                  </List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.ListDivider />
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>制作镜像</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>
                    导入文件
                    <Tag theme="warning" size="sm">
                      PRD
                    </Tag>
                  </List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>
                    升级镜像
                    <Tag theme="warning" size="sm">
                      PRD
                    </Tag>
                  </List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.ListDivider />
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>退换/销毁</List.ItemContent>
                </List.ItemButton>
              </List.Item>
            </List>
          )}
        </Dropdown>
      </section>
      <section>
        <Dropdown
          button="带操作菜单（用在开通功能）"
          appearance="button"
          clickClose={false}
        >
          {close => (
            <List type="plain">
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>查看详情</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>关机</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>重启</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>实例自助检测</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.ListDivider />
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>重置密码</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>重装系统</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.ListDivider />
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>制作镜像</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>自动续费</List.ItemContent>
                  <Switch />
                </List.ItemButton>
              </List.Item>
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>升级镜像</List.ItemContent>
                </List.ItemButton>
              </List.Item>
              <List.ListDivider />
              <List.Item>
                <List.ItemButton>
                  <List.ItemContent>退换/销毁</List.ItemContent>
                </List.ItemButton>
              </List.Item>
            </List>
          )}
        </Dropdown>
      </section>
    </div>
  );
}
