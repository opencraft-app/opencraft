import React from "react";
import { List, Row, Col } from "@tencent/tea-component";

function Title({ children }) {
  return <h4 style={{ margin: "20px 0" }}>{children}</h4>;
}

export default function ListExample() {
  return (
    <>
      <Row>
        <Col>
          <Title>普通列表</Title>
          <List>
            <List.Item>打开冰箱</List.Item>
            <List.Item>把大象放到冰箱里</List.Item>
            <List.Item>关闭冰箱门</List.Item>
          </List>
        </Col>
        <Col>
          <Title>无序列表</Title>
          <List type="bullet">
            <List.Item>打开冰箱</List.Item>
            <List.Item>把大象放到冰箱里</List.Item>
            <List.Item>关闭冰箱门</List.Item>
          </List>
        </Col>
        <Col>
          <Title>有序列表</Title>
          <List type="number">
            <List.Item>打开冰箱</List.Item>
            <List.Item>把大象放到冰箱里</List.Item>
            <List.Item>关闭冰箱门</List.Item>
          </List>
        </Col>
      </Row>
      <Row>
        <Col>
          <Title>分割线</Title>
          <List split="divide">
            <List.Item>打开冰箱</List.Item>
            <List.Item>把大象放到冰箱里</List.Item>
            <List.Item>关闭冰箱门</List.Item>
          </List>
        </Col>
        <Col>
          <Title>分割条纹</Title>
          <List split="stripe">
            <List.Item>打开冰箱</List.Item>
            <List.Item>把大象放到冰箱里</List.Item>
            <List.Item>关闭冰箱门</List.Item>
          </List>
        </Col>
        <Col>
          <Title>列表嵌套</Title>
          <List type="number">
            <List.Item>
              打开冰箱
              <List type="bullet">
                <List.Item>西门子冰箱</List.Item>
                <List.Item>双手打开</List.Item>
              </List>
            </List.Item>
            <List.Item>把大象放到冰箱里</List.Item>
            <List.Item>关闭冰箱门</List.Item>
          </List>
        </Col>
      </Row>
    </>
  );
}
