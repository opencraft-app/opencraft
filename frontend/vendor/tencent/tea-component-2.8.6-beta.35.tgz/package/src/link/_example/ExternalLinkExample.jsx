import React from "react";
import { ExternalLink } from "@tencent/tea-component";

export default function ExternalLinkExample() {
  return (
    <>
      <ExternalLink
        href="https://cloud.tencent.com"
        style={{ marginRight: 10 }}
      >
        官网
      </ExternalLink>
      <ExternalLink href="https://console.cloud.tencent.com" weak>
        控制台
      </ExternalLink>
    </>
  );
}
