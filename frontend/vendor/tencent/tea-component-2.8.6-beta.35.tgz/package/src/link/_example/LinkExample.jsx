import React from "react";

export default function ExternalLinkExample() {
  return <a href="/component/button">Button 组件</a>;
}
