import React from "react";
import { TagSelect } from "@tencent/tea-component";

const options = [
  { groupKey: "fruit", value: "strawberry", text: "草莓", tooltip: "甜甜甜" },
  {
    groupKey: "fruit",
    value: "apple",
    text: "苹果",
    disabled: true,
    tooltip: "每日一苹果，医生远离我",
  },
  { groupKey: "fruit", value: "orange", text: "橙子", tooltip: "丰富 VC 含量" },
  { groupKey: "drink", value: "coca-cola", text: "可口可乐" },
  {
    groupKey: "drink",
    value: "pepsi-cola",
    text: "百事可乐",
    tooltip: "百事可乐为什么比可口可乐好喝？",
  },
];

const groups = {
  fruit: "水果",
  drink: "饮料",
};

export default function TagSelectExample() {
  return (
    <TagSelect
      optionsOnly
      groups={groups}
      options={options}
      defaultValue={["pepsi-cola"]}
      onChange={tags => console.log(tags)}
    />
  );
}
