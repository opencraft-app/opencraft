import React from "react";
import { Popover, Tag, TagSelect, Tooltip } from "@tencent/tea-component";

const tagSelectValue = [];

const options = [
  { text: "link", value: "link" },
  { text: "zelda", value: "zelda" },
  { text: "mario", value: "mario" },
  { text: "peach", value: "peach" },
  { name: "luigi", value: "luigi" },
  { text: "ganon", value: "ganon" },
  { text: "kirby", value: "kirby" },
  { text: "falco", value: "falco" },
  { text: "fox", value: "fox" },
  { text: "pikachu", value: "pikachu" },
  { text: "samus", value: "samus" },
  { text: "yoshi", value: "yoshi" },
  { text: "donkey kong", value: "donkey kong" },
];

export default function TagSelectExample() {
  return (
    <>
      <section>
        <p>折叠后的默认标签：</p>
        <TagSelect
          optionsOnly
          options={options}
          defaultValue={tagSelectValue}
          onChange={tags => console.log(tags)}
          maxTagCount={2}
        />
      </section>
      <section>
        <p>折叠后的自定义标签：</p>
        <TagSelect
          options={options}
          optionsOnly
          defaultValue={tagSelectValue}
          onChange={tags => console.log(tags)}
          maxTagCount={2}
          maxTagRender={tags => {
            return (
              <Tooltip title={tags.map(tag => tag.value).join("；")}>
                <Tag key="maxTag">More({tags.length})</Tag>
              </Tooltip>
            );
          }}
        />
      </section>
      <section>
        <p>自适应收起个数（性能有消耗，请谨慎使用）：</p>
        <TagSelect
          options={options}
          optionsOnly
          defaultValue={tagSelectValue}
          onChange={tags => console.log(tags)}
          maxTagCount="responsive"
          onScrollBottom={p => {
            console.log("onScrollBottom");
          }}
          maxTagRender={tags => {
            return (
              <Tooltip title={tags.map(tag => tag.value).join("；")}>
                <Tag key="maxTag">More({tags.length})</Tag>
              </Tooltip>
            );
          }}
        />
      </section>
    </>
  );
}
