import React, { useState, useRef } from "react";
import { TagSelect, StatusTip } from "@tencent/tea-component";

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

export default function TagSelectDynamicExample() {
  const [status, setStatus] = useState(null);
  const [options, setOptions] = useState([]);

  const timerRef = useRef(null);
  const keywordRef = useRef("");

  const fetch = (inputValue = "") => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
    keywordRef.current = inputValue;

    setStatus("loading");
    setOptions([]);

    const mock = async () => {
      setStatus("loading");
      setOptions([]);
      await sleep(800);
      // 模拟失败
      if (Math.random() > 0.8) {
        setStatus("error");
        return;
      }
      if (keywordRef.current === inputValue) {
        setStatus(null);
        setOptions([
          { value: `${inputValue}1`, text: `${inputValue} - 1` },
          { value: `${inputValue}2`, text: `${inputValue} - 2` },
          { value: `${inputValue}3`, text: `${inputValue} - 3` },
        ]);
      }
    };

    timerRef.current = setTimeout(mock, 300);
  };

  return (
    <TagSelect
      optionsOnly
      onSearch={fetch}
      options={options}
      onChange={value => {
        console.log(value);
        setOptions([]);
      }}
      placeholder="输入关键词搜索"
      tips={
        status && (
          <StatusTip
            status={status}
            onRetry={() => fetch(keywordRef.current)}
            emptyText="输入关键词搜索"
          />
        )
      }
    />
  );
}
