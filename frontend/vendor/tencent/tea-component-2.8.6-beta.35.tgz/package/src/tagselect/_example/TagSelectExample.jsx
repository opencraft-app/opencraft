import React from "react";
import { TagSelect } from "@tencent/tea-component";

const tagSelectValue = ["link"];

const options = [
  { text: "link", value: "link" },
  { text: "zelda", value: "zelda" },
  { text: "mario", value: "mario" },
  { text: "peach", value: "peach", disabled: true },
  { name: "luigi", value: "luigi" },
];

export default function TagSelectExample() {
  return (
    <TagSelect
      // optionsOnly
      options={options}
      defaultValue={tagSelectValue}
      onChange={tags => console.log(tags)}
    />
  );
}
