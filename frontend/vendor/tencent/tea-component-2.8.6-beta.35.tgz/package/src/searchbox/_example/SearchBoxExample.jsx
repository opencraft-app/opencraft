import React, { useState } from "react";
import { SearchBox, Switch } from "@tencent/tea-component";

export default function SearchBoxExample() {
  const [loading, setLoading] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [multiline, setMultiline] = useState(false);
  const [isSimple, setIsSimple] = useState(false);
  const [isDisabled, setIsDisabled] = useState(false);
  const [hideSearchBtn, setHideSearchBtn] = useState(false);
  return (
    <>
      <section>
        <SearchBox
          placeholder="请输入关键字"
          disabled={isDisabled}
          loading={loading}
          showHelp={showHelp}
          multiline={multiline}
          hideButton={hideSearchBtn}
          simple={isSimple}
          onSearch={console.log}
          onClear={() => console.log("clear")}
          onHelp={() => console.log("help")}
        />
      </section>
      <hr />
      <section>
        <Switch value={multiline} onChange={value => setMultiline(value)}>
          多行搜索
        </Switch>
        <Switch value={showHelp} onChange={value => setShowHelp(value)}>
          显示帮助按钮
        </Switch>
        <Switch value={loading} onChange={value => setLoading(value)}>
          Loading 状态
        </Switch>

        <Switch value={isSimple} onChange={value => setIsSimple(value)}>
          simple 模式
        </Switch>

        <Switch
          value={hideSearchBtn}
          onChange={value => setHideSearchBtn(value)}
        >
          隐藏搜索按钮
        </Switch>
        <Switch value={isDisabled} onChange={value => setIsDisabled(value)}>
          禁用状态
        </Switch>
      </section>
    </>
  );
}
