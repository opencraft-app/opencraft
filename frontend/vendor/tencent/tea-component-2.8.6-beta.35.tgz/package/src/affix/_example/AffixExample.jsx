import React, { useEffect, useRef } from "react";
import { Layout, Card, Affix, Button } from "@tencent/tea-component";

const { Body, Content } = Layout;

function LayoutContentExample() {
  // 处理外层滚动
  const topAffixRef = useRef(null);
  const bottomAffixRef = useRef(null);
  useEffect(() => {
    const handleScroll = () => {
      topAffixRef.current.update();
      bottomAffixRef.current.update();
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <Layout>
      <Body>
        <Content className="affix-target">
          <Content.Header title="内容标题" />
          <Content.Body>
            {/* 内容区域一般使用 Card 组件显示内容 */}
            <Card style={{ height: 1200 }}>
              <Card.Body>
                <Affix
                  ref={topAffixRef}
                  offsetTop={20}
                  target={() => document.querySelector(".affix-target")}
                >
                  <Button>钉在顶部</Button>
                </Affix>
              </Card.Body>
            </Card>
            <Affix
              ref={bottomAffixRef}
              offsetBottom={0}
              target={() => document.querySelector(".affix-target")}
            >
              <Card>
                <Card.Body>
                  <Button type="primary">钉在底部</Button>
                </Card.Body>
              </Card>
            </Affix>
          </Content.Body>
          <Content.Footer>
            <div className="demo-layout-footer">
              (可选项)自定义页脚
              <br />
              京公网安备 11010802017518 粤B2-20090059-1
            </div>
          </Content.Footer>
        </Content>
      </Body>
    </Layout>
  );
}

export default function Demo() {
  return (
    <section
      style={{
        height: 360,
        // border: "1px solid #ddd",
      }}
    >
      <LayoutContentExample />
    </section>
  );
}
