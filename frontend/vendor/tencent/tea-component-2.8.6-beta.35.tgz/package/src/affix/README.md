# Affix 固钉

将元素固定在可视范围。

## 基本用法

### 基本用法

[Example: AffixExample](./_example/AffixExample.jsx)

<!-- ## 注意

如需使用绝对定位，可以为 Affix 设置绝对定位样式：

```jsx
<Affix style={{ position: "absolute", top: 0 }}>
  <MyComponent />
</Affix>
``` -->

## 组件属性

[Interface: AffixProps](./AffixProps.tsx)

