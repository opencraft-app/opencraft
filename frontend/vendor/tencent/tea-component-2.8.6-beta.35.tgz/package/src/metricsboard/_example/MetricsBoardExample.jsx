import React from "react";
import {
  Row,
  Col,
  Card,
  MetricsBoard,
  Icon,
  Text,
} from "@tencent/tea-component";
import { ArrowFlatIcon } from "@tencent/tea-icons-react";

export default function MetricsBoardExample() {
  return (
    <Card>
      <Card.Body title="昨日数据">
        <Row showSplitLine>
          <Col>
            <MetricsBoard
              title="语音时长"
              unit="分钟"
              value={7890}
              infos={[
                <>
                  比较前天 <Icon type="trenddown" /> 0%
                </>,
              ]}
              onClick={event => console.log(event)}
            />
          </Col>
          <Col>
            <MetricsBoard
              title="语音 DAU 总人数"
              value={456}
              infos={[
                <>
                  比较前天 <Icon type="trendup" /> 0%
                </>,
                <>
                  比较上周 <Icon type="trenddown" /> 0%
                </>,
                <>
                  比较上月 <ArrowFlatIcon /> 0%
                </>,
              ]}
            />
          </Col>
          <Col>
            <MetricsBoard
              title="语音 DAU 总人数"
              value={789}
              infos={[
                <>
                  <MetricsBoard.InfoLabel>标清</MetricsBoard.InfoLabel>
                  <MetricsBoard.InfoKey>
                    <Text theme="danger">23</Text>
                  </MetricsBoard.InfoKey>
                </>,
                <>
                  <MetricsBoard.InfoLabel>高清</MetricsBoard.InfoLabel>
                  <MetricsBoard.InfoKey>23</MetricsBoard.InfoKey>
                </>,
                <>
                  <MetricsBoard.InfoLabel>1080P</MetricsBoard.InfoLabel>
                  <MetricsBoard.InfoKey>23</MetricsBoard.InfoKey>
                </>,
              ]}
            />
          </Col>
          <Col>
            <MetricsBoard
              title="语音 DAU 总人数"
              value="00"
              infos={[
                <>
                  比较前天 <Icon type="trendup" /> 0%
                </>,
              ]}
            />
          </Col>
        </Row>
      </Card.Body>
    </Card>
  );
}
