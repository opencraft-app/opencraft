import React, { useState } from "react";
import { StatusTip, Radio } from "@tencent/tea-component";

export default function StatusTipExample() {
  const [value, setValue] = useState("loading");
  return (
    <>
      <StatusTip
        // @ts-ignore
        status={value}
        onClear={() => console.log("onClear")}
        onRetry={() => console.log("onRetry")}
      />
      <section>
        <Radio.Group value={value} onChange={value => setValue(value)}>
          <Radio name="loading">loading</Radio>
          <Radio name="empty">empty</Radio>
          <Radio name="found">found</Radio>
          <Radio name="error">error</Radio>
        </Radio.Group>
      </section>
    </>
  );
}
