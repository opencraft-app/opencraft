import React from "react";
import { StatusTip, Text } from "@tencent/tea-component";

export default function StatusTipExample() {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        gap: 12,
      }}
    >
      <StatusTip.InstanceTip status="running">运行中</StatusTip.InstanceTip>
      <StatusTip.InstanceTip status="operating">关机中</StatusTip.InstanceTip>
      <StatusTip.InstanceTip status="closed">已关机</StatusTip.InstanceTip>
      <StatusTip.InstanceTip status="warning">
        <Text underline>救援模式</Text>
      </StatusTip.InstanceTip>
      <StatusTip.InstanceTip status="error">待回收</StatusTip.InstanceTip>
    </div>
  );
}
