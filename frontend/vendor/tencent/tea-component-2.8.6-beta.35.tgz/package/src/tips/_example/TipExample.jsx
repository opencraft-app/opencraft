import React from "react";
import { StatusTip } from "@tencent/tea-component";

const { LoadingTip, FoundTip, EmptyTip, ErrorTip } = StatusTip;

export default function StatusTipExample() {
  return (
    <>
      <p>
        <LoadingTip />
      </p>
      <p>
        <EmptyTip />
      </p>
      <p>
        <FoundTip onClear={() => console.log("onClear")} />
      </p>
      <p>
        <ErrorTip onRetry={() => console.log("onRetry")} />
      </p>
    </>
  );
}
