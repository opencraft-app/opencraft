import React from "react";
import { Card } from "@tencent/tea-component";

export default function CardExample() {
  return (
    <div className="example-stage">
      <Card style={{ maxWidth: 400 }}>
        <img
          style={{ width: "100%", display: "block" }}
          src="////main.qcloudimg.com/raw/6c8fd423cd9bdd7a77b0e99725e04fff.png"
          alt="bg"
        />
      </Card>
    </div>
  );
}
