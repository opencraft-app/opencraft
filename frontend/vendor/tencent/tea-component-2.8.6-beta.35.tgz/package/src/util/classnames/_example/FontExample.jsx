import React from "react";
import { useClassNames, Justify } from "@tencent/tea-component";

export default function Demo() {
  const { FontSizeReset } = useClassNames();
  return <Justify right={<a className={FontSizeReset}>测试</a>} />;
}
