import React from "react";
import classNames from "classnames";
import { useClassNames } from "@tencent/tea-component";

export default function Demo() {
  const { Padding, Margin } = useClassNames();
  return [1, 2, 3, 4, 5].map(i => (
    <div
      key={i}
      className={classNames(Padding[`${i}n`], Margin.Left["1n"])}
      style={{
        background: "var(--tea-color-bg-primary-default)",
        width: 60,
        display: "inline-block",
      }}
    >
      <div
        style={{
          background: "var(--tea-color-bg-secondary-default)",
          height: 60,
        }}
      />
    </div>
  ));
}
