import React from "react";
import { useClassNames } from "@tencent/tea-component";

export default function Demo() {
  const { Margin } = useClassNames();
  return [1, 2, 3, 4, 5].map(i => (
    <div
      key={i}
      className={Margin.Left["1n"]}
      style={{
        background: "var(--tea-color-bg-secondary-default)",
        width: 60,
        display: "inline-block",
      }}
    >
      <div
        className={Margin[`${i}n`]}
        style={{
          background: "var(--tea-color-bg-primary-default)",
          height: 60,
        }}
      />
    </div>
  ));
}
