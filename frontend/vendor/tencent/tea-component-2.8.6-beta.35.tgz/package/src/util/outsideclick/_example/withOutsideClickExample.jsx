// import React, { Component } from "react";
// import { withOutsideClick } from "@tencent/tea-component";

// @withOutsideClick("click")
// export default class Demo extends Component {
//   state = {
//     count: 0,
//   };

//   click = () => {
//     this.setState(({ count }) => ({ count: count + 1 }));
//   };

//   render() {
//     return <div>Demo</div>;
//   }
// }
