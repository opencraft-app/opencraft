import React from "react";
import { Avatar } from "@tencent/tea-component";

export default function AvatarExample() {
  return (
    <>
      <Avatar color={Avatar.Color.Blue} text="T" />
      <Avatar color={Avatar.Color.SkyBlue} text="T" />
      <Avatar color={Avatar.Color.Turquoise} text="T" />
      <Avatar color={Avatar.Color.Green} text="T" />
      <Avatar color={Avatar.Color.Purple} text="T" />
      <Avatar color={Avatar.Color.Pink} text="T" />
      <Avatar color={Avatar.Color.Orange} text="T" />
      <Avatar color={Avatar.Color.Red} text="T" />
      <Avatar color={Avatar.Color.DarkRed} text="T" />
      <Avatar color={Avatar.Color.DarkPurple} text="T" />
      <Avatar color={Avatar.Color.LakeBlue} text="T" />
      <Avatar color={Avatar.Color.LightLakeBlue} text="T" />
      <Avatar color={Avatar.Color.LightSkyBlue} text="T" />
      <Avatar color={Avatar.Color.LightGreen} text="T" />
      <Avatar color="#000000" text="T" />
      <Avatar color="100013414624" text="T" badge />
      <Avatar color="100033414613" text="T" />
    </>
  );
}
