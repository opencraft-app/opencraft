# Avatar 头像

标准的头像组件

## 使用示例

### 基本用法

[Example: AvatarExample](./_example/AvatarExample.jsx)

## 组件属性

[Interface: AvatarProps](./Avatar.tsx)
