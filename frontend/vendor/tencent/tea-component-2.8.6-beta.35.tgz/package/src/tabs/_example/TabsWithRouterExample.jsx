import React from "react";
import { Tabs, TabPanel } from "@tencent/tea-component";

// eslint-disable-next-line import/no-extraneous-dependencies
import { HashRouter, Route, Link } from "react-router-dom";

export default function TabsWithRouterExample() {
  const tabs = [
    { id: "basic", label: "基本信息" },
    { id: "network", label: "弹性网卡" },
    { id: "monitor", label: "监控信息" },
    { id: "sg", label: "安全组" },
    { id: "oplog", label: "操作日志" },
  ];

  return (
    <HashRouter>
      <Route path="/:tab">
        {({ match }) => {
          const activeId =
            (match && match.params && match.params.tab) || "basic";
          return (
            <Tabs
              tabs={tabs}
              activeId={activeId}
              tabBarRender={(children, tab) => (
                <Link to={`/${tab.id}`}>{children}</Link>
              )}
            >
              {tabs.map(tab => (
                <TabPanel key={tab.id} id={tab.id}>
                  <Route
                    path={`/${tab.id}`}
                    render={() => <div>已路由到：{tab.label}</div>}
                  />
                </TabPanel>
              ))}
            </Tabs>
          );
        }}
      </Route>
    </HashRouter>
  );
}
