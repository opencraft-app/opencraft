import React, { useState } from "react";

export const BlockList = ({ children }) => (
  <div
    style={{
      display: "flex",
      flexDirection: "column",
      gap: 32,
    }}
  >
    {children}
  </div>
);

export const Block = ({ children }) => (
  <div
    style={{
      display: "flex",
      flexDirection: "column",
      gap: 20,
    }}
  >
    {children}
  </div>
);

export const DemoContainer = ({ children }) => (
  <div
    style={{
      backgroundColor: "var(--tea-color-bg-page-default)",
      padding: 20,
    }}
  >
    {children}
  </div>
);

export const PanelInner = ({ children }) => (
  <div
    style={{
      padding: 20,
    }}
  >
    {children}
  </div>
);

export function useSwitch(defaultChecked = false) {
  const [value, onChange] = useState(defaultChecked);
  return { value, onChange: value => onChange(value) };
}
