import React, { useState } from "react";
import { Tabs, TabPanel, H3, Switch, Card } from "@tencent/tea-component";
import {
  Block,
  BlockList,
  DemoContainer,
  PanelInner,
  useSwitch,
} from "./Components";

export default function TabsExample() {
  const [tabs, setTabs] = useState([
    { id: "basic", label: "Tab1" },
    { id: "network", label: "Tab2" },
    { id: "monitor", label: "Tab3", disabled: true },
    { id: "sg", label: "Tab4" },
  ]);

  const switchProps = useSwitch(false);

  return (
    <BlockList>
      <Block>
        <H3>横向Tabs</H3>
        <Switch {...switchProps}>开启Switcher</Switch>
        <DemoContainer>
          <Card>
            <Tabs
              tabs={tabs}
              showSwitcher={switchProps.value}
              switcherFilter={(tab, key) => {
                return tab.label.includes(key);
              }}
            >
              {tabs.map(tab => (
                <TabPanel id={tab.id} key={tab.id}>
                  <PanelInner>{tab.label}</PanelInner>
                </TabPanel>
              ))}
            </Tabs>
          </Card>
        </DemoContainer>
      </Block>

      <Block>
        <H3>纵向Tabs</H3>
        <DemoContainer>
          <Card
            style={{
              paddingLeft: 32,
            }}
          >
            <Tabs tabs={tabs} placement="left">
              {tabs.map(tab => (
                <TabPanel id={tab.id} key={tab.id}>
                  <PanelInner>{tab.label}</PanelInner>
                </TabPanel>
              ))}
            </Tabs>
          </Card>
        </DemoContainer>
      </Block>
    </BlockList>
  );
}
