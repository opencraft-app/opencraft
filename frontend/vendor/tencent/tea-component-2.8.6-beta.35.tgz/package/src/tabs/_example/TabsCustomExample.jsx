import React, { useState } from "react";
import {
  Tabs,
  TabPanel,
  useTabsSwitcher,
  List,
  Space,
  Text,
  Button,
  Switch,
  Card,
  Form,
  Radio,
} from "@tencent/tea-component";
import { Block, DemoContainer, PanelInner, useSwitch } from "./Components";

function CustomSwitcherList() {
  const { group, selectTab, activeId } = useTabsSwitcher();
  return (
    <List type="plain">
      {(group[0] || []).map(pinnedItem => (
        <List.Item
          key={pinnedItem.id}
          selected={activeId === pinnedItem.id}
          disabled={pinnedItem.disabled}
          onClick={
            pinnedItem.disabled
              ? undefined
              : () => {
                  selectTab(pinnedItem);
                }
          }
        >
          <List.ItemButton>
            <List.ItemContent>{pinnedItem.label}</List.ItemContent>
          </List.ItemButton>
        </List.Item>
      ))}
      {(group[1] || []).map(normalItem => (
        <List.Item
          key={normalItem.id}
          selected={activeId === normalItem.id}
          disabled={normalItem.disabled}
          onClick={
            normalItem.disabled
              ? undefined
              : () => {
                  selectTab(normalItem);
                }
          }
        >
          <List.ItemButton>
            <List.ItemContent>{normalItem.label}</List.ItemContent>
            <Text theme="weak">{normalItem.id}</Text>
          </List.ItemButton>
        </List.Item>
      ))}
    </List>
  );
}

export default function TabsCustomExample() {
  const [tabs, setTabs] = useState([
    { id: "basic", label: "Tab1" },
    { id: "network", label: "Tab2" },
    { id: "monitor", label: "Tab3" },
    { id: "sg", label: "Tab4", disabled: true },
    { id: "oplog", label: "Tab5" },
  ]);

  const addableSWitch = useSwitch();
  const sortableSwitch = useSwitch();
  const showSwitcher = useSwitch();
  const showCustomSwitch = useSwitch();
  const [activeId, setActiveId] = useState();

  const [variant, setVariant] = useState("normal");

  function remove({ id }, e) {
    e.preventDefault();
    e.stopPropagation();

    setTabs(tabs => tabs.filter(tab => tab.id !== id));
  }

  function add() {
    const activeId = String(Date.now());
    setTabs(tabs => [
      ...tabs,
      { id: activeId, label: `Tab ${activeId}`, onClose: remove },
    ]);
    setActiveId(activeId);
  }

  return (
    <>
      <Block>
        <div>
          <Form>
            <Form.Item label="Tabs变体">
              <Radio.Group defaultValue={variant} onChange={v => setVariant(v)}>
                <Radio name="normal">线式Tabs - 默认</Radio>
                <Radio name="plain">线式Tabs - 无底边</Radio>
                <Radio name="segment">滑块式Tabs</Radio>
                <Radio name="card-outline">卡片式Tabs - 默认</Radio>
                <Radio name="card-soft">卡片式Tabs - 灰底</Radio>
              </Radio.Group>
            </Form.Item>
            <Form.Item label="显示切换列表">
              <Switch {...showSwitcher}></Switch>
            </Form.Item>
            <Form.Item label="自定义切换列表">
              <Switch {...showCustomSwitch}></Switch>
            </Form.Item>
            <Form.Item label="可添加Tab">
              <Switch {...addableSWitch}></Switch>
            </Form.Item>
            <Form.Item label="可拖拽排序">
              <Switch {...sortableSwitch}></Switch>
            </Form.Item>
          </Form>
        </div>
        <DemoContainer>
          <Tabs
            tabs={tabs}
            variant={variant}
            isSortable={sortableSwitch.value}
            isAddable={addableSWitch.value}
            showSwitcher={showSwitcher.value}
            activeId={activeId}
            customSwitcher={
              showCustomSwitch.value ? <CustomSwitcherList /> : undefined
            }
            onAdd={add}
            onActive={tab => setActiveId(tab.id)}
          ></Tabs>
        </DemoContainer>
      </Block>
    </>
  );
}
