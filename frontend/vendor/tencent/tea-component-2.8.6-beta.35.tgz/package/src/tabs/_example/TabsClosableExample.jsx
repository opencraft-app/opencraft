import React, { useState } from "react";
import { Tabs, TabPanel, Switch, Card } from "@tencent/tea-component";
import { Block, DemoContainer, PanelInner } from "./Components";

export default function TabsExample() {
  const [tabs, setTabs] = useState([
    { id: "basic", label: "基本信息", onClose: remove },
    { id: "network", label: "弹性网卡", onClose: remove },
    { id: "monitor", label: "监控信息", onClose: remove },
    { id: "sg", label: "安全组", disabled: true, onClose: remove },
    { id: "oplog", label: "操作日志", onClose: remove },
  ]);
  function remove({ id }, e) {
    e.preventDefault();
    e.stopPropagation();

    setTabs(tabs => tabs.filter(tab => tab.id !== id));
  }
  const [activeId, setActiveId] = useState();

  function add() {
    const activeId = String(Date.now());
    setTabs(tabs => [
      ...tabs,
      { id: activeId, label: `Tab ${activeId}`, onClose: remove },
    ]);
    setActiveId(activeId);
  }

  return (
    <>
      <Block>
        <DemoContainer>
          <Card>
            <Card.Body>
              <Tabs
                tabs={tabs}
                isAddable
                onAdd={add}
                onActive={tab => setActiveId(tab.id)}
                activeId={activeId}
              >
                {tabs.map(tab => (
                  <TabPanel id={tab.id} key={tab.id}>
                    <PanelInner>{tab.label}</PanelInner>
                  </TabPanel>
                ))}
              </Tabs>
            </Card.Body>
          </Card>
        </DemoContainer>
      </Block>
    </>
  );
}
