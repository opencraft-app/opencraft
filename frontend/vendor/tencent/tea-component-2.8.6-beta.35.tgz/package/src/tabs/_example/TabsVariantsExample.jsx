import React, { useState } from "react";
import {
  Tabs,
  TabPanel,
  Switch,
  Select,
  Button,
  Radio,
  Card,
  H3,
  Text,
} from "@tencent/tea-component";
import { Block, BlockList, DemoContainer, PanelInner } from "./Components";

export default function TabsVariantsExample() {
  const [tabs, setTabs] = useState([
    { id: "basic", label: "Tab1" },
    { id: "network", label: "Tab2" },
    { id: "monitor", label: "Tab3" },
    { id: "oplog", label: "Tab4" },
  ]);

  const [activeId, setActiveId] = useState();
  const [cardVariant, setCardVariant] = useState("card-outline");

  return (
    <BlockList>
      <Text>
        在线式Tabs的基础上，我们针对横向Tabs进行了拓展，引入了多种变体，旨在迎合控制台中各种复杂场景的实际需求
      </Text>
      <Block>
        <H3>线条式Tabs</H3>
        <div
          style={{
            lineHeight: "20px",
          }}
        >
          <Text parent="p">线条式 Tabs 默认不带背景色：</Text>
          <Text parent="p">
            1）与标题栏结合使用时，即应用在标题栏的白色背景之上；
          </Text>
          <Text parent="p">2）与二级导航搭配使用，常用于控制台背景色之上;</Text>
        </div>
        <DemoContainer>
          <Card>
            <Tabs tabs={tabs} defaultActiveId={tabs[0].id}></Tabs>
          </Card>
        </DemoContainer>
      </Block>
      <Block>
        <H3>滑块式Tabs</H3>
        <DemoContainer>
          <Tabs
            tabs={tabs}
            variant="segment"
            defaultActiveId={tabs[0].id}
          ></Tabs>
        </DemoContainer>
      </Block>
      <Block>
        <H3>卡片式Tabs</H3>
        <Radio.Group value={cardVariant} onChange={v => setCardVariant(v)}>
          <Radio name="card-outline">默认样式</Radio>
          <Radio name="card-soft">
            强调样式（仅适用于「地域切换」、「教学指引类」场景）
          </Radio>
        </Radio.Group>
        <DemoContainer>
          <Tabs
            tabs={tabs}
            variant={cardVariant}
            defaultActiveId={tabs[0].id}
            animated={false}
          >
            {tabs.map(tab => (
              <TabPanel id={tab.id} key={tab.id}>
                <Card>
                  <Card.Body>{tab.label}</Card.Body>
                </Card>
              </TabPanel>
            ))}
          </Tabs>
        </DemoContainer>
      </Block>
      {/* <div
        style={{
          backgroundColor: "var(--tea-color-bg-page-default)",
          padding: 20,
        }}
      >
        <Card>
          <Card.Body title="我是标题">
            <Tabs tabs={tabs} variant="plain" defaultActiveId={tabs[0].id}>
              {tabs.map(tab => (
                <TabPanel id={tab.id} key={tab.id}>
                  {tab.label}
                </TabPanel>
              ))}
            </Tabs>
          </Card.Body>
        </Card>
      </div> */}
    </BlockList>
  );
}
