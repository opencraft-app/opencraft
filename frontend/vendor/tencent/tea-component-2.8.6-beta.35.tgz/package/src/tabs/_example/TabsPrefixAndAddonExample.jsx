import React, { useState } from "react";
import { Tabs, TabPanel, Card, Button, Checkbox } from "@tencent/tea-component";
import { DownloadIcon, RefreshIcon } from "@tencent/tea-icons-react";
import {
  Block,
  BlockList,
  DemoContainer,
  PanelInner,
  useSwitch,
} from "./Components";

export default function TabsPrefixAndAddonExample() {
  const [tabs, setTabs] = useState([
    { id: "basic", label: "Tab1" },
    { id: "network", label: "Tab2" },
    { id: "monitor", label: "Tab3" },
    { id: "oplog", label: "Tab4" },
  ]);

  // const left = useSwitch(true);
  const right = useSwitch(true);

  return (
    <BlockList>
      <Block>
        <div>
          {/* <Checkbox {...left}>Left</Checkbox> */}
          <Checkbox {...right}>Right</Checkbox>
        </div>
        <DemoContainer>
          <Card>
            <Tabs
              tabs={tabs}
              // prefix={
              //   left.value && (
              //     <Button type="icon">
              //       <HomeIcon />
              //     </Button>
              //   )
              // }
              addon={
                right.value && (
                  <div
                    style={{ display: "flex", alignItems: "center", gap: 12 }}
                  >
                    <Button type="icon" size="sm">
                      <DownloadIcon />
                    </Button>
                    <Button type="icon" size="sm">
                      <RefreshIcon />
                    </Button>
                  </div>
                )
              }
            ></Tabs>
          </Card>
        </DemoContainer>
      </Block>
    </BlockList>
  );
}
