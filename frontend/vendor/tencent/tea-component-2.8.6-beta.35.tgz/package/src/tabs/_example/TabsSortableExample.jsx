import React, { useState } from "react";
import { Tabs, TabPanel, Card } from "@tencent/tea-component";
import { Block, BlockList, DemoContainer, PanelInner } from "./Components";

export default function TabsSortableExample() {
  const [tabs, setTabs] = useState([
    { id: "basic", label: "Tab1" },
    { id: "network", label: "Tab2" },
    { id: "monitor", label: "Tab3" },
    { id: "oplog", label: "Tab4" },
  ]);

  return (
    <BlockList>
      <Block>
        <DemoContainer>
          <Card>
            <Tabs tabs={tabs} isSortable></Tabs>
          </Card>
        </DemoContainer>
      </Block>
    </BlockList>
  );
}
