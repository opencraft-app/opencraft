import React from "react";
import { Rate } from "@tencent/tea-component";

export default function RateReadonlyExample() {
  return <Rate readonly defaultValue={3} />;
}
