import React from "react";
import { Rate } from "@tencent/tea-component";

export default function RateExample() {
  return <Rate defaultValue={3} onChange={value => console.log(value)} />;
}
