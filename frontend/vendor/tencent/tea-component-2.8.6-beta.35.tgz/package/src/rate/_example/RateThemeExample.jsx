import React from "react";
import { Rate } from "@tencent/tea-component";

export default function RateThemeExample() {
  return <Rate allowHalf theme="primary" defaultValue={3.5} />;
}
