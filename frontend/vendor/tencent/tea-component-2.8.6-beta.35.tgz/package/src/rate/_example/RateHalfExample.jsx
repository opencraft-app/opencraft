import React from "react";
import { Rate } from "@tencent/tea-component";

export default function RateHalfExample() {
  return (
    <Rate allowHalf defaultValue={3.5} onChange={value => console.log(value)} />
  );
}
