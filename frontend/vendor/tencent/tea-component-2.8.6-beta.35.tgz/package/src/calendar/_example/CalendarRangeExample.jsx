import React from "react";
import moment from "moment";
import { Calendar } from "@tencent/tea-component";

export default () => {
  return (
    <Calendar
      range={[moment("2019-01-01"), moment("2020-01-01")]}
      onChange={value => console.log(value.format("YYYY/MM/DD"), value)}
    />
  );
};
