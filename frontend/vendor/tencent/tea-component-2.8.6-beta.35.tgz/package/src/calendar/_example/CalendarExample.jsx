import React from "react";
import { Calendar } from "@tencent/tea-component";

export default () => {
  return (
    <Calendar
      onChange={value => console.log(value.format("YYYY/MM/DD"), value)}
    />
  );
};
