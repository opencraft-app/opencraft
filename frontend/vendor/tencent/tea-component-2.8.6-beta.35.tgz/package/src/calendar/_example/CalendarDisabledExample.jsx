import React from "react";
import moment from "moment";
import { Calendar } from "@tencent/tea-component";

export default () => {
  return (
    <Calendar
      disabledDate={date => !date.isAfter(moment())}
      onChange={value => console.log(value.format("YYYY/MM/DD"), value)}
    />
  );
};
