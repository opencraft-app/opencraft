import React, { useState } from "react";
import { PopConfirm, Button } from "@tencent/tea-component";

export default function PopConfirmExample() {
  return (
    <PopConfirm
      title="确定要解除关联？"
      message="解除后，配置将不再生效，也不做关联。"
      footer={close => (
        <>
          <Button
            type="link"
            onClick={() => {
              close();
              console.log("已解除");
            }}
          >
            解除
          </Button>
          <Button
            type="text"
            onClick={() => {
              close();
              console.log("已取消");
            }}
          >
            取消
          </Button>
        </>
      )}
      placement="top-start"
    >
      <Button type="text">解除关联</Button>
    </PopConfirm>
  );
}
