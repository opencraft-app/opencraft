import React from "react";
import { Popover } from "@tencent/tea-component";

export default function PopoverExample() {
  return (
    <Popover
      placement="top-start"
      overlay={
        <div
          style={{
            display: "inline-block",
            background: "red",
            color: "yellow",
            padding: 2,
          }}
        >
          这是浮层内容
        </div>
      }
    >
      鼠标上来
    </Popover>
  );
}
