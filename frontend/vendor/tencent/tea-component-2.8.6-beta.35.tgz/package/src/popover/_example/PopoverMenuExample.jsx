import React, { useState } from "react";
import { List, Popover, DropdownBox } from "@tencent/tea-component";

export default function PopoverExample() {
  const [visible, setVisible] = useState(false);
  return (
    <Popover
      visible={visible}
      onVisibleChange={visible => setVisible(visible)}
      placement="bottom-start"
      trigger="contextMenu"
      overlay={
        <DropdownBox>
          <List type="option">
            <List.Item
              onClick={() => {
                console.log("点击菜单项");
                setVisible(false);
              }}
            >
              菜单项
            </List.Item>
          </List>
        </DropdownBox>
      }
    >
      右键菜单
    </Popover>
  );
}
