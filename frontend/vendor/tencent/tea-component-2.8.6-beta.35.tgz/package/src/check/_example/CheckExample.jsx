import React from "react";
import { Check } from "@tencent/tea-component";

export default function CheckExample() {
  return (
    <Check type="checkbox" indeterminate>
      勾选
    </Check>
  );
}
