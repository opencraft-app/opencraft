import React from "react";
import { Checkbox } from "@tencent/tea-component";

export default function CheckboxControlledExample() {
  return (
    <>
      <Checkbox display="block" value={false}>
        未选中
      </Checkbox>
      <Checkbox display="block" value>
        已选中
      </Checkbox>
      <Checkbox display="block" value={false} disabled>
        禁用未选中
      </Checkbox>
      <Checkbox display="block" value disabled>
        禁用已选中
      </Checkbox>
      <Checkbox display="block" indeterminate>
        半选状态
      </Checkbox>
      <Checkbox display="block" indeterminate disabled>
        半选状态已禁用
      </Checkbox>
    </>
  );
}
