import React, { useState } from "react";
import { Checkbox } from "@tencent/tea-component";

export default function CheckboxColumnExample() {
  const [paymode, setPaymode] = useState([]);

  return (
    <>
      <Checkbox.Group
        value={paymode}
        onChange={value => setPaymode(value)}
        layout="column"
      >
        <Checkbox name="prepaid" tooltip="给了钱再用">
          预付费
        </Checkbox>
        <Checkbox name="billing" tooltip="用了再给钱">
          后付费
        </Checkbox>
        <Checkbox name="subscription" tooltip="每个月自动扣钱">
          订阅模式
        </Checkbox>
        <Checkbox name="friend" disabled tooltip="Yomee 帮你给钱">
          朋友代付
        </Checkbox>
      </Checkbox.Group>
    </>
  );
}
