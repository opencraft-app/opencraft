import React, { useState } from "react";
import { Checkbox } from "@tencent/tea-component";

export default function CheckboxExample() {
  const [taste, setTaste] = useState([]);

  return (
    <>
      <p>
        已选中 {taste.length} 个口味要求：{taste.join(", ")}
      </p>
      <section>
        <Checkbox.Group value={taste} onChange={value => setTaste(value)}>
          <Checkbox name="la">加辣</Checkbox>
          <Checkbox name="ma">加麻</Checkbox>
          <Checkbox name="nocong">不要葱花</Checkbox>
        </Checkbox.Group>
      </section>
    </>
  );
}
