# @tencent/tea-component

## 2.8.6-beta.35

### Patch Changes

- 1ae1a27: fix(cascader): 修复 expandTrigger 为 hover 时，鼠标移到无子级选项时二级面板不消失的问题
  fix(list): 修复 Cascader hover 展开子菜单点击选项后子菜单位置跳动的问题

## 2.8.6-beta.34

### Patch Changes

- e708e6d: 修复 FormItem 中 typeof null === "object" 导致的 "Cannot use 'in' operator" 错误

## 2.8.6-beta.33

### Patch Changes

- fe80a05: 更新@tencent/tea-icons-react 版本, 入口文件改为/lite 支持 tree-shaking

## 2.8.6-beta.32

### Patch Changes

- 6da06a0: 更新@tencent/tea-icons-react 版本

## 2.8.6-beta.31

### Patch Changes

- d8f9797: tag 组件支持 onAttributeChange 和 attributesSelectRender 属性

## 2.8.6-beta.30

### Patch Changes

- b0a6052: Table:

  - Sticky 插件支持分页吸底，仅限使用分页插件的分页；

  TagSearchbox:

  - 支持标签高亮

  Dropdown/Select:

  - 支持自定义前缀

  Drawer

  - 支持自定义尺寸、

- b9c65fd: 给 Dropdonw 组件增加 stopPropagation 入参，用以阻止下拉面板中的冒泡事件

## 2.8.6-beta.29

### Patch Changes

- 579ec3d: 增加 i18n 翻译脚本
- 4df30e2: modal 增加 destroyOnRoute 属性，默认开启

## 2.8.6-beta.28

### Patch Changes

- 19a2131: notification 容器增加滚动条 stable 样式

## 2.8.6-beta.27

### Patch Changes

- eda1afe: notification 样式优化

## 2.8.6-beta.26

### Patch Changes

- 72c65c4: notification 组件堆叠优化，增加展开全部和关闭全部按钮

## 2.8.6-beta.25

### Patch Changes

- 03b22e3: 部分语言文案翻译

## 2.8.6-beta.24

### Patch Changes

- b1da854: Notification

  - 背景增加渐变；
  - 没有内容时，不渲染 body 节点；

  Message

  - 增加背景和边框色；
  - 图标改为填充图标；
  - 增加投影；
  - 高度调整为 40px；
  - 位置调整为距顶 64px；

  Table

  - 过滤后图标更新为蓝色；

  Menu

  - 修复 dark 失效的问题；

  Space

  - 修复属性无法透传的问题

  Status

  - 图标去掉 display-p3 的用法

## 2.8.6-beta.23

### Patch Changes

- 7e8bacd: fix(tea-component): modal api 切换路由销毁

## 2.8.6-beta.22

### Patch Changes

- fc169d6: RangePicker 开始和结束时间月份相同支持显示本月和下个月
- 16088fc: RangePicker 集成面板中文输入法下异常修复和选择时间显示优化
- b3507e7: RangePicker 集成面板支持可选择范围和相对时间选项过滤

## 2.8.6-beta.21

### Patch Changes

- 9b8c25e: fix: externallink 事件冒泡导致链接无法打开问题

## 2.8.6-beta.20

### Patch Changes

- b074efd: 较新的 nodejs 版本从 moment 导入 ISO_8601 异常修复

## 2.8.6-beta.19

### Patch Changes

- 7875272: tea 组件移除中文日志

## 2.8.6-beta.18

### Patch Changes

- cde0959: 日期时间范围组件优化（支持快捷时间、相对时间等拓展功能）

## 2.8.6-beta.17

### Patch Changes

- 4208fcc: TagSelect：
  1. 支持超出指定数量的内容折叠；
  2. 支持自适应的内容折叠；
  3. 下拉面板元素选中后，选中态调整；
  4. 增加下拉箭头；
  5. 修复 disabled 状态下，下拉依然可以被激活的 bug；

## 2.8.6-beta.16

### Patch Changes

- dc46ed8: notification 组件修复 dureation 为 0 的时候自动关闭

## 2.8.6-beta.15

### Patch Changes

- cb15932: feat(tea-component): drawer 增加参数控制 outsideclose 非外部组件

## 2.8.6-beta.14

### Patch Changes

- 4dc0f51: 更改 multiline 为 true 时，hideButton 默认 false

## 2.8.6-beta.13

### Patch Changes

- 27a2042: fix: 级联组件增加参数控制事件冒泡

## 2.8.6-beta.12

### Patch Changes

- 36a9057: select 组件支持分组聚合；table filter 插件自定义组件 value 收控

## 2.8.6-beta.11

### Patch Changes

- 48145ca: table 筛选插件多选时，支持 selectFilteredOnly 默认只全选筛选后的语法糖

## 2.8.6-beta.10

### Patch Changes

- c5491fd: 修复 table 修复使用 maskloading 时，表格出现横向滚动条后，遮照无法居中的问题

## 2.8.6-beta.9

### Patch Changes

- 2f4ad87: feat 级联选择全选 fix vite dev base

## 2.8.6-beta.8

### Patch Changes

- dd50252: 修复 table 组件在某些情况下无法正确算出 tablebody 宽度问题

## 2.8.6-beta.7

### Patch Changes

- a017d04: table filter 插件支持自定义筛选组件

## 2.8.6-beta.6

### Patch Changes

- 179b082: table filter 插件支持自定义筛选组件
- 01e10ca: 一批改动
  - 日期选择器部分日期显示格式调整
  - textarea 增加高度自适应属性 autoSize
  - Text 新增 theme `secondary`

## 2.8.6-beta.5

### Patch Changes

- ee8e94f: 更新 tabs 组件 switcherFilter 属性说明

## 2.8.6-beta.4

### Patch Changes

- 2916c53: 修复 table 插件 groupable 的分组计算规则

## 2.8.6-beta.3

### Patch Changes

- b66feda: 修复 Table groupable 计算 head tr 时，没有考虑同级别的分组情况

## 3.0.0-beta.2

### Major Changes

- 31e8de9: 替换 CDN 域名
- 31e8de9: 替换 cdn 域名

### Patch Changes

- 9b7b0e2: 修复 cdn 替换

## 2.8.6-beta.1

### Patch Changes

- 4c17ce6: 组件 InputNumber OnChange context 增加值变化类型

## 2.8.6-beta.0

### Patch Changes

- edf1bab: 组件 Video 支持 maskClosable 属性
- da6d048: 修复 TagSelect option 设置 removeable 为 false 时可通过键盘删除

## 2.8.5

### Patch Changes

- 9b2bb4c: Select 组件 autoWrap 默认为 false
- f8d470b: notification 组件消失后默认占位高度移除
- fdf697a: 一批优化
- dadafd0: 修复 tree 过滤循环卡死问题
- e2e69f3: 使 TagSelect 不再在点击 tag 的时候就失去对 TagSelect 的焦点，现在只有点击 TagSelect 以外的区域时才会失去组件的焦点了
- 45fa21e: NavMenu 支持设置菜单主题
- a300249: icon 组件渲染为超链接时事件触发两次修复
- e58fd47: 样式包更新
  - 度设置移动到 notification-item 上，防止控制台 wrap 的前缀在未知情况下会变成业务的前缀
  - notification 兼容无标题情况；footer 增加容器包裹，增加默认手型
  - 修复表格左右 padding 调整后，导致的拖拽列 hover 异常的问题
  - 优化地域选择器搜索样式
  - 按钮的动画只给背景颜色/边框颜色/文字颜色，防止清除按钮带来的动画延迟
  - 地域选择器数字加粗；去掉最近访问的默认底色
  - 级联选择下的 tab 样式优化
  - list 拥有二级菜单的情况下，右侧留出图标的位置
- 1d865dd: 修复 status 文案传入 null 时，仍然渲染一个图片问题
- 64e189d: 地域选择支持 CustomHead、CustomHead.Title、CustomHead.Content 组件
- add14d6: 地域选择支持 CustomHead、CustomHead.Title、CustomHead.Content 组件
- 27551b3: TreeNode 支持传入事件，并绑定在 li 上
- 2736c5e: TagSelect 支持折叠选中标签
- 4cb7bd4: 升级 resize Observer
- 2c0c56e: 面包屑支持响应式
- 69df8f6: notification 样式更新，没有 title 的时候对齐 desc
- d8f0c51: 移除 array-move 包
- 5a0c863: 面包屑支持响应式+样式包更新
- 1ed2801: 修复 drawer 逻辑问题
- e6a7e83: 修复了月份选择器 disabledMonth 时不提供初始月份的问题
- aed6bff: 表格排序和列宽调整同时出现时，避免顺序导致的列宽调整把手位置异常
- 120f2a0: fix: table head props

## 2.8.5-beta.19

### Patch Changes

- e2e69f3: 使 TagSelect 不再在点击 tag 的时候就失去对 TagSelect 的焦点，现在只有点击 TagSelect 以外的区域时才会失去组件的焦点了

## 2.8.5-beta.18

### Patch Changes

- 9b2bb4c: Select 组件 autoWrap 默认为 false

## 2.8.5-beta.17

### Patch Changes

- fdf697a: 一批优化
- Modal 增加 scrollable 类型；
- 🌈 Modal 尺寸优化：420>480 ; 550>560 ; 950>960 ;
- 🌈 Menu 非中文语境宽度调整为 240；
- 🌈 Menu 非中文语境标题允许折行，并去掉分割线；
- 🌈 Menu 中文语境下不在限制高度，超过 2 行(不推荐)高度自动撑开；
- Form 增加 flex 布局，相当于定宽，label 宽度可以用 fixedLabelWidth 来控制；
- Alert 新增 samePrefixWidth 属性，支持 AlertGroup 在标签长度不一样的情况，设置同宽；
- 🌈 MetricsBoard 标题不允许换行了；
- 🌈 支持自定义滚动条的 class 和 mixin 用法，支持默认显示滚动条和 hover 显示；
- 🌈 国际化优化的样式默认打入 tea-themeable.css；
- Select 支持选项文字多行；

## 2.8.5-beta.16

### Patch Changes

- 64e189d: 地域选择支持 CustomHead、CustomHead.Title、CustomHead.Content 组件

## 2.8.5-beta.15

### Patch Changes

- add14d6: 地域选择支持 CustomHead、CustomHead.Title、CustomHead.Content 组件
- 4cb7bd4: 升级 resize Observer

## 2.8.5-beta.14

### Patch Changes

- 5a0c863: 面包屑支持响应式+样式包更新

## 2.8.5-beta.13

### Patch Changes

- 2c0c56e: 面包屑支持响应式

## 2.8.5-beta.12

### Patch Changes

- 27551b3: TreeNode 支持传入事件，并绑定在 li 上

## 2.8.5-beta.11

### Patch Changes

- a300249: icon 组件渲染为超链接时事件触发两次修复
- 2736c5e: TagSelect 支持折叠选中标签

## 2.8.5-beta.10

### Patch Changes

- e58fd47: 样式包更新
  - 度设置移动到 notification-item 上，防止控制台 wrap 的前缀在未知情况下会变成业务的前缀
  - notification 兼容无标题情况；footer 增加容器包裹，增加默认手型
  - 修复表格左右 padding 调整后，导致的拖拽列 hover 异常的问题
  - 优化地域选择器搜索样式
  - 按钮的动画只给背景颜色/边框颜色/文字颜色，防止清除按钮带来的动画延迟
  - 地域选择器数字加粗；去掉最近访问的默认底色
  - 级联选择下的 tab 样式优化
  - list 拥有二级菜单的情况下，右侧留出图标的位置

## 2.8.5-beta.9

### Patch Changes

- f8d470b: notification 组件消失后默认占位高度移除

## 2.8.5-beta.8

### Patch Changes

- 69df8f6: notification 样式更新，没有 title 的时候对齐 desc

## 2.8.5-beta.7

### Patch Changes

- e6a7e83: 修复了月份选择器 disabledMonth 时不提供初始月份的问题

## 2.8.5-beta.6

### Patch Changes

- 45fa21e: NavMenu 支持设置菜单主题

## 2.8.5-beta.5

### Patch Changes

- dadafd0: 修复 tree 过滤循环卡死问题

## 2.8.5-beta.4

### Patch Changes

- 1d865dd: 修复 status 文案传入 null 时，仍然渲染一个图片问题

## 2.8.5-beta.3

### Patch Changes

- 120f2a0: fix: table head props

## 2.8.5-beta.2

### Patch Changes

- aed6bff: 表格排序和列宽调整同时出现时，避免顺序导致的列宽调整把手位置异常

## 2.8.5-beta.1

### Patch Changes

- 1ed2801: 修复 drawer 逻辑问题

## 2.8.5-beta.0

### Patch Changes

- d8f0c51: 移除 array-move 包

## 2.8.4

### Patch Changes

- 4407628: #### 主要变化

  - RegionSelect
    - 🆕 supportFilter 新增 supportFilter 属性，支持地域筛选

  #### 破坏性变化

  - SearchBox
    - 💄 默认搜索 Icon 前置，可能会影响业务样式，需要特别注意
      - 💄 原后置 Icon，改为「搜索」按钮
      - 🆕 新增 hideButton 属性，隐藏后置的「搜索」按钮

- 71e78f9: 地域组件支持搜索
- 7c1771d: 通知组件样式更新
- 4285f7d: notification 样式优化
- de01c3f: notification 样式修改
- 2fc6714: 文档补充 since
- 9c64c5b: 改动
  - tea-component 升级样式包为@tencent/tea-style@1.1.9
  - tea-app RequestOptions json 参数补充说明
- 2488aac: 地域组件支持筛选
- 57151c6: 类型修复
- 8304db9: isChildOfType 兼容 displayName 判断
- 35a3447: fix: Tree 组件过滤下展开时导致节点丢失补充 Icon 组件 color 属性的起始版本说明 fix: SelectMultiple 组件默认值不为数据报错 Tab 组件新增参数控制过渡动画 fix: RangePicker 手动输入时，可以选择非法范围
- 02b2c3b: Drawer 组件支持 l、xl 大小
- 3d282aa: tagsearchbox 的 help 弹窗里的中国地域等敏感词
- a316613: TagSearchBox 默认隐藏检索按钮，支持 hideButton 属性
- 9bef0ed: 修复 useClassName 缺少 n
- 0fabe18: table 组件支持翻页插件支持 disabled
- cfb029b: button 和 Status 组件更新

  Button 按钮组件修改点：

  - 💄 调整为 inline-flex；
  - 💄 新增两种尺寸；
  - ✨ 新增按钮组；✓
  - ✨ 新增特殊功能拓展，支持前后自定义内容；✓
  - 变体扩展与兼容；✓
  - 文档内容调整；✓
  - 相关组件内使用了按钮，受尺寸调整影响的兼容；✓

  Dropdown 组件

  - Dropdown 扩展 solidBrand 类型

  Status 组件

  - ✨ 新增 error 和 positive 类型
  - 💄 图标 UI 风格升级

- 8217576: notification hover 的时候整体堆叠暂停计时
- 81d9555: searchBox 默认隐藏搜索按钮
- 47b3c8c: notification 组件更新交互和 ui，支持动态变化通知类型
- b8c9ce1: - Table - 新增灰色表头的样式；✓ - 表头文字颜色调整；✓ - 加载状态添加蒙版；✓ - 顶部利用提示条来显示信息，增加提示条在 Table 下的适配；✓ - 两种行高，以及横向和纵向的间距调整；✓ - 有操作的表头 hover 加底色； ✓ - 列宽调整样式优化；✓ - (fix)表格合并之后，hover 颜色状态不对；✓ - 深色主题下，border-primary/secondary 调整；✓ - 【组件】StatusTip 同步调整，新增实例状态子组件；✓
  - Searchbox/Tagsearchbox
    - 放大镜图标调整为文字按钮；✓
    - 增加默认前置装饰图标；✓
    - 区分 tagsearch 和普通 searchbox 的前置图标；✓
    - ‘检索’按钮对齐，以及 hover/focus/active 等状态调整；✓
    - 清除图标更新为 x，表单相关清除图标同步修改；✓
  - badge
    - 支持徽章基本功能（容器右上角显示红点或 tag）；✓
    - 支持位置自定义偏移量；✓
    - 支持数字最大限制；✓
    - 支持自定义红点或标识；✓
  - 新增颜色色板 token
    - 增加 orange/amber 色板以及相关 token；✓
    - 组件修改后相关 token 的新增和值的调整；✓

## 2.8.4-beta.21

### Patch Changes

- 9c64c5b: 改动
  - tea-component 升级样式包为@tencent/tea-style@1.1.9
  - tea-app RequestOptions json 参数补充说明

## 2.8.4-beta.20

### Patch Changes

- 9bef0ed: 修复 useClassName 缺少 n

## 2.8.4-beta.19

### Patch Changes

- 35a3447: fix: Tree 组件过滤下展开时导致节点丢失补充 Icon 组件 color 属性的起始版本说明 fix: SelectMultiple 组件默认值不为数据报错 Tab 组件新增参数控制过渡动画 fix: RangePicker 手动输入时，可以选择非法范围

## 2.8.4-beta.18

### Patch Changes

- a316613: TagSearchBox 默认隐藏检索按钮，支持 hideButton 属性

## 2.8.4-beta.17

### Patch Changes

- 3d282aa: tagsearchbox 的 help 弹窗里的中国地域等敏感词

## 2.8.4-beta.16

### Patch Changes

- 8217576: notification hover 的时候整体堆叠暂停计时

## 2.8.4-beta.15

### Patch Changes

- 02b2c3b: Drawer 组件支持 l、xl 大小

## 2.8.4-beta.14

### Patch Changes

- 7c1771d: 通知组件样式更新

## 2.8.4-beta.12

### Patch Changes

- notification 样式优化

## 2.8.4-beta.11

### Patch Changes

- notification 样式修改

## 2.8.4-beta.10

### Patch Changes

- 47b3c8c: notification 组件更新交互和 ui，支持动态变化通知类型

## 2.8.4-beta.9

### Patch Changes

- 0fabe18: table 组件支持翻页插件支持 disabled

## 2.8.4-beta.8

### Patch Changes

- isChildOfType 兼容 displayName 判断

## 2.8.4-beta.7

### Patch Changes

- 71e78f9: 地域组件支持搜索

## 2.8.4-beta.6

### Patch Changes

- 2fc6714: 文档补充 since

## 2.8.4-beta.5

### Patch Changes

- cfb029b: button 和 Status 组件更新

  Button 按钮组件修改点：

  - 💄 调整为 inline-flex；
  - 💄 新增两种尺寸；
  - ✨ 新增按钮组；✓
  - ✨ 新增特殊功能拓展，支持前后自定义内容；✓
  - 变体扩展与兼容；✓
  - 文档内容调整；✓
  - 相关组件内使用了按钮，受尺寸调整影响的兼容；✓

  Dropdown 组件

  - Dropdown 扩展 solidBrand 类型

  Status 组件

  - ✨ 新增 error 和 positive 类型
  - 💄 图标 UI 风格升级

## 2.8.4-beta.4

### Patch Changes

- 57151c6: 类型修复

## 2.8.4-beta.3

### Patch Changes

- 81d9555: searchBox 默认隐藏搜索按钮

## 2.8.4-beta.2

### Patch Changes

- 4407628: #### 主要变化

  - RegionSelect
    - 🆕 supportFilter 新增 supportFilter 属性，支持地域筛选

  #### 破坏性变化

  - SearchBox
    - 💄 默认搜索 Icon 前置，可能会影响业务样式，需要特别注意
      - 💄 原后置 Icon，改为「搜索」按钮
      - 🆕 新增 hideButton 属性，隐藏后置的「搜索」按钮

- 2488aac: 地域组件支持筛选

## 2.8.4-beta.0

### Patch Changes

- b8c9ce1: 一批改动
- Table
  - 新增灰色表头的样式；✓
  - 表头文字颜色调整；✓
  - 加载状态添加蒙版；✓
  - 顶部利用提示条来显示信息，增加提示条在 Table 下的适配；✓
  - 两种行高，以及横向和纵向的间距调整；✓
  - 有操作的表头 hover 加底色； ✓
  - 列宽调整样式优化；✓
  - (fix)表格合并之后，hover 颜色状态不对；✓
  - 深色主题下，border-primary/secondary 调整；✓
  - 【组件】StatusTip 同步调整，新增实例状态子组件；✓
- Searchbox/Tagsearchbox
  - 放大镜图标调整为文字按钮；✓
  - 增加默认前置装饰图标；✓
  - 区分 tagsearch 和普通 searchbox 的前置图标；✓
  - ‘检索’按钮对齐，以及 hover/focus/active 等状态调整；✓
  - 清除图标更新为 x，表单相关清除图标同步修改；✓
- badge
  - 支持徽章基本功能（容器右上角显示红点或 tag）；✓
  - 支持位置自定义偏移量；✓
  - 支持数字最大限制；✓
  - 支持自定义红点或标识；✓
- 新增颜色色板 token
  - 增加 orange/amber 色板以及相关 token；✓
  - 组件修改后相关 token 的新增和值的调整；✓
