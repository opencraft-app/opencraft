module.exports = {
  setupFilesAfterEnv: ["./test/setup-framework.js"],
  transform: {
    "^.+\\.(j|t)sx?$": "babel-jest",
  },
  transformIgnorePatterns: ["node_modules/?!(popper.js)"],
  testPathIgnorePatterns: [
    "/node_modules/",
    "/dist/style/", // 排除从 tea-style 复制过来的测试文件
  ],
  verbose: false,
  moduleNameMapper: {
    // 测试工具便捷引入
    "^@test/(.*)": "<rootDir>/test/$1",
    // 组件 alias
    "^@tea/component(.*)": "<rootDir>/src$1",
    "^@tencent/tea-component": "<rootDir>/src",
    "^@tencent/tea-component/lib(.*)": "<rootDir>/src$1",
  },
  moduleFileExtensions: ["ts", "tsx", "js", "jsx", "json", "node"],
  collectCoverage: true,
  coverageReporters: ["json-summary", "html"],
};
