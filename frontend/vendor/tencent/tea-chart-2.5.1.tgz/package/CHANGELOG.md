# @tencent/tea-chart

## 2.5.0

### Patch Changes

- 3e764c6: 修复 basicmap 无法隐藏 legend & eslint 修复

## 2.5.0-beta.9

### Patch Changes

- 3e764c6: 修复 basicmap 无法隐藏 legend & eslint 修复
