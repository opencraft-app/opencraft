# Tea 框架 - 图标库

## 文档 & 示例

组件用法可参考 http://tea.tencent.com/chart

## 组件目录

<!--<ComponentTOC>-->

- 折线图
  - [x] [BasicLine](./src/basicline) - 基本折线图
  - [x] [SimpleLine](./src/simpleline) - 极简折线图
  - [x] [CompareLine](./src/compareline) - 对比折线图
- 面积图
  - [x] [BasicArea](./src/basicarea) - 基本面积图
- 柱状图
  - [x] [BasicBar](./src/basicbar) - 基本柱状图
  - [x] [StackBar](./src/stackbar) - 堆叠柱状图
- 饼图
  - [x] [BasicPie](./src/basicpie) - 基本饼图
- 地图
  - [x] [BasicMap](./src/basicmap) - 基本地图
  - [x] [WorldMap](./src/worldmap) - 世界地图
- 工具
  - [x] [Annotation](./src/annotation) - 注释
- 交互
  - [x] [Zoom](./src/interaction/zoom) - 缩放
  - [x] [Brush](./src/interaction/brush) - 框选
  - [x] [Select](./src/interaction/select) - 选择
- 其他
  - [x] [ConfigProvider](./src/configprovider) - 全局配置

<!--</ComponentTOC>-->

## 开发

### 本地开发

前往 `tea-web` 目录，执行 `npm install` 完成依赖安装，然后执行 `npm run start`，即可在本地运行起 Tea 文档站点。

#### 新建组件

如需新建组件，请先在上文 **组件目录** 中添加组件说明，并建立相对应的目录。

#### README.md

网站中组件示例由 `tea-chart/src/` 下各组件目录中 `README.md` 生成。

### git 相关

#### 分支

请基于 `release` 分支来进行开发，开发完成后请提交 [Merge Request](https://git.woa.com/CFETeam/tea2/merge_requests) 到该分支。

#### 提交注释

请参考[提交注释规范](https://www.conventionalcommits.org/zh)

## 发布

### 构建

执行 `npm run build` 进行构建。

### 版本号更新

执行 `npm version patch` 更新末位版本号。

如需发布非 `@latest` 版本，请修改对应标签版本号，如 `2.0.0-beta.1`。

### 发布至 TNPM

执行 `tnpm publish` 发布包。

如需发布非 `@latest` 版本，请添加 `--tag` 参数，如 `tnpm publish --tag beta`。
