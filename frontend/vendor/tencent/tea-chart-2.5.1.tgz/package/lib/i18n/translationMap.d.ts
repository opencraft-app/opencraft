import { zh_cn } from "./locale/zh_cn";
declare type Locale = typeof zh_cn;
export interface Translation extends Locale {
}
export declare const translationMap: {
    zh_cn: Translation;
    zh: Translation;
    en_us: Translation;
    en: Translation;
    ja: Translation;
    jp: Translation;
    ko: Translation;
};
export {};
