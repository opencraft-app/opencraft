import { Translation } from "./translationMap";
export declare function setLocale(): void;
export declare function useTranslation(moment?: typeof import("moment")): Translation;
export interface WithTranslationProps {
    /**
     * @ignore
     */
    t?: Translation;
}
