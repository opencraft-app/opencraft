export declare const zh_cn: {
    locale: string;
    resetText: string;
    noData: string;
};
