export declare const ja: {
    locale: string;
    resetText: string;
    noData: string;
};
