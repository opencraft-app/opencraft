export declare const ko: {
    locale: string;
    resetText: string;
    noData: string;
};
