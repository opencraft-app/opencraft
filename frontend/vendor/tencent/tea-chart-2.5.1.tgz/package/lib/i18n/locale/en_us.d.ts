export declare const en_us: {
    locale: string;
    resetText: string;
    noData: string;
};
