/// <reference types="react" />
import { RectProps } from "../_chart/type/chart";
import { AreaStyle } from "../_chart/shapes";
import { Omit } from "../_type";
export interface BasicAreaProps extends Omit<RectProps, "dataLabels"> {
    /**
     * 折线的粗细
     *
     * @default 3
     */
    size?: number;
    /**
     * 是否连接空值
     * @default true
     * @since 2.0
     */
    connectNulls?: boolean;
    /**
     * 是否为平滑曲线
     */
    smooth?: boolean;
    /**
     * 样式设置
     */
    areaStyle?: AreaStyle;
}
export declare function BasicArea(props: BasicAreaProps): JSX.Element;
