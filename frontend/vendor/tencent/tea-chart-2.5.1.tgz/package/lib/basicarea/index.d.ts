export { BasicArea, BasicAreaProps } from "./BasicArea";
