/// <reference types="react" />
import { BasicMapProps } from "../basicmap";
export interface WorldMapProps extends Omit<BasicMapProps, "mapType"> {
}
export declare function WorldMap(props: WorldMapProps): JSX.Element;
