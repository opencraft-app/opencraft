/// <reference types="react" />
import { PolarProps } from "../_chart/type/chart";
export interface BasicPieProps extends PolarProps {
    /**
     * 是否为环形图，若设置了 `coord` 则此属性不生效
     * @default false
     */
    circle?: boolean;
}
export declare function BasicPie(props: BasicPieProps): JSX.Element;
