import React from "react";
import { ConfigProps as Config } from "../_util/config-context/config-context";
export declare function setConfig(config?: Config): void;
export interface ConfigProviderProps extends Config {
    children: React.ReactNode;
}
export declare function ConfigProvider({ children, ...configProps }: ConfigProviderProps): JSX.Element;
