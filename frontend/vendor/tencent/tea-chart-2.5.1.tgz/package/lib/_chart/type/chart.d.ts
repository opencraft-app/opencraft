/// <reference types="react" />
import { PieArcDatum } from "d3";
import { AxisOptions, ScaleOptions, TooltipOptions, LegendOptions, ShapeOptions, ZoomOptions, InteractionType, InteractionOptions } from "./options";
import { DataSource, EventData, DataLeaf } from "./data";
import { Theme } from "./theme";
/**
 * 图表组件的通用属性
 */
export interface ChartProps {
    /**
     * 图表的宽度
     *
     * @default auto
     * @since 2.0
     */
    width?: number;
    /**
     * 图表的高度
     * @since 2.0
     */
    height: number;
    /**
     * 图表的数据源
     *
     * @default []
     * @since 2.0
     */
    dataSource: DataSource;
    /**
     * 图表主题配置
     * @since 2.0
     */
    theme?: Theme;
    /**
     * X 轴与 Y 轴的数据映射。(X 轴属性名)*(Y 轴属性名)，属性名对应 dataSource 中的属性名
     * @since 2.0
     */
    position: string;
    /**
     * 使用颜色来区分数据系列，可以自定义颜色
     * @since 2.0
     */
    color?: string | Color | string[];
    /**
     * 列定义
     * @since 2.0
     */
    scale?: {
        [key: string]: ScaleOptions;
    };
    /**
     * 提示框
     * @default true
     * @since 2.0
     */
    tooltip?: boolean | TooltipOptions;
    /**
     * 图例
     * @since 2.0
     */
    legend?: boolean | LegendOptions;
    /**
     * 数据文本配置
     * @since 2.0
     */
    dataLabels?: boolean | ShapeOptions["dataLabels"];
    /**
     * 图表实例引用
     * @since 2.0
     */
    chartRef?: (chart: ChartRef) => void;
    /**
     * 注释等其他工具
     */
    children?: React.ReactElement;
    /**
     * 状态提示，可使用 StatusTip 相关组件
     */
    tips?: React.ReactNode;
    /**
     * Tips 遮罩层样式
     */
    tipsStyle?: React.CSSProperties;
    /**
     * 是否启用选择。已废弃，请使用 [interaction]
     * @deprecated
     */
    selection?: boolean;
    /**
     * 开启的交互事件
     */
    interaction?: InteractionType[] | InteractionOptions;
}
/**
 * 图表实例引用
 * @since 2.0
 */
export interface ChartRef {
    /**
     * 监听事件，目前支持："click"
     * @since 2.0
     */
    on?: (name: string, evt?: any) => void;
    /**
     * 发送事件，目前支持："legend.hover "与 "legend.left"
     * @since 2.0
     */
    emit?: (name: string, evt?: any) => void;
    /**
     * 获取指定 x 坐标数据
     */
    getData?: (x: number) => EventData;
}
/**
 * 数据映射（颜色）
 */
export interface Color {
    /**
     * 数据映射的属性名
     * @since 2.0
     */
    key?: string;
    /**
     * 颜色列表
     * @default Tea主题
     * @since 2.0
     */
    colors?: string[] | ((key: string, index: number, isLast: boolean) => string);
    /**
     * 格式化处理，优先级大于颜色列表
     * @since 2.0
     */
    formatter?: (datum: DataLeaf | PieArcDatum<string>) => string | void;
}
/**
 * 直角坐标系通用属性
 */
export interface RectProps extends ChartProps {
    /**
     *  X 轴
     * @default true
     * @since 2.0
     */
    xAxis?: boolean | AxisOptions;
    /**
     *  Y 轴
     * @default true
     * @since 2.0
     */
    yAxis?: boolean | AxisOptions;
    /**
     * 是否启用缩放。已废弃，请使用 [interaction]
     * @deprecated
     */
    zoom?: boolean | ZoomOptions;
}
/**
 * 极坐标通用属性
 */
export interface PolarProps extends ChartProps {
    /**
     * 坐标系相关设置。`innerRadius` 若为小于 1 的数值代表百分比，其他为具体的数值
     * @since 2.0
     */
    coord?: {
        innerRadius?: number;
    };
}
