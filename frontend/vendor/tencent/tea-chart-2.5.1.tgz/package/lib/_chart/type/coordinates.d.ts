import { RectCoordinate } from "../coordinates/rect-coord";
import { PolarCoordinate } from "../coordinates/polar-coord";
/**
 * 坐标系实例集合
 * @todo 待补齐 RectCoordinate，PolarCoordinate
 */
export interface Coordinates {
    rect?: RectCoordinate;
    polar?: PolarCoordinate;
}
