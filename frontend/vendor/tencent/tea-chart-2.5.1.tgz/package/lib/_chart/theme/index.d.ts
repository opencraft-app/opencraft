export { getConfig as Tea } from "./tea";
