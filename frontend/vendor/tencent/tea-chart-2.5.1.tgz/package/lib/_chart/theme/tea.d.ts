import { Theme } from "../type/theme";
/**
 * Tea Chart 的默认主题
 * @version 1.0.0
 */
export declare function getConfig(): Theme;
