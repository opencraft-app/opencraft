import { Context } from "./context";
import { Helpers } from "./type/helpers";
/**
 * 图表事件管理对象
 * @since 2.0
 */
export declare class Events {
    private ctx;
    private helpers;
    /**
     * 是否为点击事件
     */
    private isClick;
    /**
     * 鼠标按下到抬起的时间，用以判断是否为点击事件
     */
    private mousedownTimer;
    constructor(ctx: Context, helpers: Helpers);
    /**
     * 事件初始化
     */
    private init;
    /**
     * 全局事件
     * @since 2.3
     */
    private initGlobalEvents;
    /**
     * HTML 根元素事件
     * @since 2.0
     */
    private initContainerEvents;
    /**
     * 初始化鼠标事件
     *
     * @since 2.0
     */
    private initPlotEvents;
}
