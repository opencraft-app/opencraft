import EventEmitter from "eventemitter3";
import { Selection } from "d3";
import { AxisOptions, LegendOptions, TooltipOptions, ScaleOptions, ConnectNullsOptions, InteractionOptions } from "./type/options";
import { Theme } from "./type/theme";
import { DataSource } from "./type/data";
/**
 * 图表的配置信息
 */
export interface ContextOptions {
    /**
     * 坐标轴配置
     * @since 2.0
     * @todo 支持多 X 轴与多 Y 轴分开定义
     */
    axis: {
        xAxis: AxisOptions;
        yAxis: AxisOptions;
    };
    /**
     * 图例配置
     * @since 2.0
     */
    legend: LegendOptions;
    /**
     * 提示框配置
     * @since 2.0
     */
    tooltip: TooltipOptions;
    /**
     * 数据比例尺配置
     * @since 2.0
     */
    scale: {
        [key: string]: ScaleOptions;
    };
    /**
     * 连接空值的配置
     * @since 2.0
     */
    connectNulls: ConnectNullsOptions;
    /**
     * 交互事件
     *
     * @since 2.1.0
     */
    interaction: InteractionOptions;
}
/**
 * TeaChart 全局上下文
 * 其中 options 只能通过 getOption 和 setOption 来进行读取
 *
 * @extends eventemitter3
 */
export declare class Context extends EventEmitter {
    /**
     * Chart ID
     * @since 2.0
     */
    id: string;
    /**
     * Tea Chart 主题配置
     * @since 2.0
     */
    theme: Theme;
    /**
     * 默认的 class 前缀
     * @since 2.0
     */
    classPrefix: string;
    /**
     * HTML 根元素
     * @since 2.0
     */
    container: HTMLElement;
    /**
     * 图形区 SVG
     * @since 2.0
     */
    root: Selection<SVGElement, {}, HTMLElement, {}>;
    /**
     * 图表背景
     * @since 2.0
     */
    background: Selection<SVGGElement, {}, HTMLElement, {}>;
    /**
     * 绘图区（线，柱，饼等）背景
     * @since 2.0
     */
    plotBackgound: Selection<SVGGElement, {}, HTMLElement, {}>;
    /**
     * 绘图区遮罩 Mask
     * @since 2.0
     */
    plotMask: Selection<SVGRectElement, {}, HTMLElement, {}>;
    /**
     * 配置项
     * @since 2.0
     */
    options: ContextOptions;
    /**
     * 原始数据
     * @since 2.0
     */
    dataSource: DataSource;
    /**
     * 初始化 Context
     * @param container 根元素
     * @param customTheme 主题配置
     */
    constructor(id: string, container: HTMLElement, customTheme?: Theme);
    /**
     * 获取配置信息
     * @param optionKey 获取配置信息的 key
     * @param defaultValue 默认值
     * @returns 返回配置的值
     *
     * @since 2.0
     */
    getOption(optionKey: string, defaultValue?: any): any;
    /**
     * 设置配置信息
     * @param optionKey 待设置配置的 key
     * @param value 新的值
     *
     * @since 2.0
     */
    setOption(optionKey: string, value: any): ContextOptions;
    /**
     * 设置主题配置
     * @param customTheme 用户自定义主题配置
     *
     * @since 2.0
     */
    setTheme(customTheme: Theme): void;
    /**
     * 更新原始数据
     * @param dataSource 原始数据
     */
    setDataSource(dataSource: DataSource): void;
    /**
     * 获取图表宽度
     * @since 2.1.0
     */
    getBackgroundWidth(): number;
    /**
     * 获取图表高度
     */
    getBackgroundHeight(): number;
    /**
     * 获取绘图层宽度
     * @since 2.1.0
     */
    getPlotWidth(): number;
    /**
     * 获取绘图层高度
     */
    getPlotHeight(): number;
}
