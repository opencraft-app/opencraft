import { BaseType, Selection } from "d3";
export declare function getLabelMaxWidth(nodes: BaseType[]): number;
export declare function getLabelMinWidth(nodes: BaseType[]): number;
export declare function getLabelMaxHeight(nodes: BaseType[]): number;
export declare function nodeWidth(node: SVGGraphicsElement): number;
export declare function nodeHeight(node: SVGGraphicsElement): number;
export declare function textSize(text: string, style?: string): {
    width: number;
    height: number;
};
export declare function textWrap(text: Selection<SVGElement, {}, BaseType, {}>, invert: boolean, barWidth: number): void;
export declare function findTextColor(colorValue: string): false | "#000000" | "#ffffff";
/**
 * 转换字体颜色
 *
 * @param {array} rgbArr rgb数组
 */
export declare function resBgColor(rgbArr: number[]): "#000000" | "#ffffff";
