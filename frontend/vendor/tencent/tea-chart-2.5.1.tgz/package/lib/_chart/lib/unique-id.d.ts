/**
 * 生成唯一 ID
 * @param prefix 前缀
 * @returns 唯一 ID
 */
export declare function uniqueId(prefix?: string): string;
