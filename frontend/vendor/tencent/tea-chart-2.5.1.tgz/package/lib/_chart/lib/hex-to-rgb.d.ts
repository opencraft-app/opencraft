export declare function hexToRGB(hex: string, alpha?: number): string;
