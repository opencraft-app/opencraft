import { ScalePoint, ScaleBand } from "d3";
/**
 * 通过 X 坐标获取对应的分类索引
 * @param x x 坐标
 * @param scale 分类比例尺
 * @param scaleType 分类比例尺类型
 */
export declare function getCategoryIndex(x: number, scale: ScalePoint<string> | ScaleBand<string>, scaleType?: "Point" | "Band"): number;
