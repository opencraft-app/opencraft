export declare function deepMerge(destination: any, ...sources: any[]): any;
