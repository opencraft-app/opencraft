export declare function escapeHTML(content: string): string;
