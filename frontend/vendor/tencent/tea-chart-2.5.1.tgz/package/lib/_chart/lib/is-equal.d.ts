export declare function isDeepEqual(x: any, y: any): any;
export declare function isArrayDeepEqual(x: any[], y: any[]): boolean;
