export declare function comparePropsEqual(prev: any, next: any, compareKeys?: string[]): boolean;
