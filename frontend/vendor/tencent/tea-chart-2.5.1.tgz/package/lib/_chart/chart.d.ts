import { Context } from "./context";
import { Line } from "./shapes/line";
import { DataSource } from "./type/data";
import { Theme } from "./type/theme";
import { ScaleOptions, TooltipOptions, LegendOptions, InteractionType } from "./type/options";
import { Bar } from "./shapes/bar";
import { Pie } from "./shapes/pie";
import { Annotation } from "./helpers/annotation";
import { Area, Map } from "./shapes";
export declare class Chart {
    /**
     * 图表实例 ID
     * @since 2.0
     */
    id: string;
    /**
     * 全局上下文
     * @since 2.0
     */
    ctx: Context;
    /**
     * 坐标系实例
     * @since 2.0
     */
    private coordinates;
    /**
     * 图形实例集合
     * @since 2.0
     */
    private shape;
    /**
     * 辅助图层/功能实例集合
     * @since 2.0
     */
    private helpers;
    /**
     * 图表事件管理对象
     * @since 2.0
     */
    private events;
    /**
     * 注释管理对象
     * @since 2.0
     */
    private annotations;
    /**
     * Resize 的时间计时器
     * @since 2.0
     */
    private resizeTimer;
    /**
     * 初始化图表
     * @param container HTML 根元素
     * @param customTheme 主题配置
     */
    constructor(container: HTMLElement, customTheme?: Theme, context?: Context);
    /**
     * 设置数据源
     * @param dataSource 原始数据源
     * @since 2.0
     */
    source(dataSource: DataSource): this;
    /**
     * 设置主题
     * @param config 主题选项
     * @since 2.0
     */
    theme(config: Theme): this;
    /**
     * 设置数据源的列
     * @param scaleCfg 列定义
     * @since 2.0
     */
    scale(scaleCfg: ScaleOptions): this;
    /**
     * 设置提示框
     * @param enable 是否显示提示框
     * @param TooltipCfg 提示框配置
     * @since 2.0
     */
    tooltip(enable: boolean | TooltipOptions, TooltipCfg?: TooltipOptions): this;
    /**
     * 设置图例
     * @param enable 是否显示图例
     * @param legendCfg 图例配置
     * @since 2.0
     */
    legend(enable: boolean | LegendOptions, legendCfg?: LegendOptions): this;
    /**
     * 交互事件
     * @param type 交互类型
     * @param extra 交互类型额外参数
     * @since 2.1.0
     */
    interaction(type: InteractionType, extra?: any): this;
    /**
     * 注释
     *
     * @since 2.1.0
     */
    annotation(): Annotation;
    line(): Line;
    area(): Area;
    bar(): Bar;
    pie(): Pie;
    map(): Map;
    /**
     * 开始渲染
     * @since 2.0
     */
    render(): void;
    /**
     * 销毁图表实例
     * @since 2.0
     */
    destroy(): void;
    /**
     * 监听事件
     * @param eventName 事件名
     * @param callback 事件回调函数
     * @callback TeaChart.EventListenerCallback
     * @since 2.0
     */
    on(eventName: string, callback?: () => void): void;
    /**
     * 发送事件
     * @param eventName 事件名
     * @param eventData 事件数据
     * @since 2.0
     */
    emit(eventName: string, eventData?: any): void;
    /**
     * 监听事件
     * @param eventName 事件名
     * @param callback 事件回调函数
     * @callback TeaChart.EventListenerCallback
     * @since 2.0
     */
    once(eventName: string, callback?: () => void): void;
    /**
     * 删除事件绑定
     * @param eventName 事件名
     * @param callback 事件回调函数
     * @callback TeaChart.EventListenerCallback
     * @since 2.3
     */
    off(eventName: string, callback?: () => void): void;
    /**
     * 重置尺寸
     * @since 2.0
     */
    resize(): void;
    /**
     * 更新图表尺寸
     * @private
     * @event chart.sizeUpdated
     * @since 2.0
     */
    private updateSize;
    /**
     * 重新按照元素的 data-z-index 属性排列各个图层
     * @since 2.0
     */
    private reorder;
}
