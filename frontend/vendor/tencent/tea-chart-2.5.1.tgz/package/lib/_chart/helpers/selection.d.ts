import { Selection as D3Selection } from "d3";
import { Context } from "../context";
export declare class Selection {
    /**
     * 全局上下文
     * @since 2.0
     */
    private ctx;
    /**
     * 缩放区对象
     */
    selection: D3Selection<SVGRectElement, {}, HTMLElement, {}>;
    private data;
    private enable;
    constructor(ctx: Context);
    setEnable(enable: boolean): void;
    private initMouseEvent;
    /**
     * 绘制选择框
     * @param x 当前 x 的坐标
     */
    private drawSelectionMarker;
    private draw;
    private remove;
}
