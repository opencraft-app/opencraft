import { ScaleOrdinal } from "d3";
import { Context } from "../context";
import { ShapeType } from "../type/data";
import { DataModel } from "../data-model";
export declare class Legend {
    /**
     * 过滤的数据系列名
     * @since 2.0
     */
    disabledKeys: string[];
    /**
     * 全局上下文
     * @since 2.0
     */
    private ctx;
    /**
     * 图例对象
     * @since 2.0
     */
    private group;
    /**
     * 图例项对象
     * @since 2.0
     */
    private itemGroup;
    /**
     * 图例盒子对象
     * @since 2.0
     */
    private box;
    /**
     * 整个图例的高度
     * @since 2.0
     */
    height: number;
    /**
     * 整个图例区的宽度
     * @since 2.0
     */
    width: number;
    /**
     * 图例外层容器对象
     * @since 2.5
     */
    private container;
    /**
     * 图例svg对象的高度
     * @since 2.5
     */
    groupHeight: number;
    /**
     * 图例svg对象的宽度
     * @since 2.5
     */
    groupWidth: number;
    constructor(ctx: Context);
    /**
     *
     * @param serieScale 数据系列比例尺
     * @param valueKey
     */
    update(serieScale: ScaleOrdinal<string, string>, valueKey: string, type: ShapeType, model: DataModel): void;
    /**
     * 清空图例
     * @private
     */
    private clear;
    private draw;
    /**
     * 更新图例区的位置
     * @since 2.0
     */
    private setPosition;
    private onLegendItemHover;
    private onLegendItemLeft;
    private onLegendItemClick;
}
