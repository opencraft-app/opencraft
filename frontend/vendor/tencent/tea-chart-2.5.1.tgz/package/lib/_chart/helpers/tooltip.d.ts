import { Context } from "../context";
import { EventData, MetaData, DataLeaf } from "../type/data";
export declare class Tooltip {
    /**
     * 全局上下文
     * @since 2.0
     */
    private ctx;
    /**
     * overlay 根元素
     */
    private overlay;
    /**
     * 排序箭头方向
     */
    private arrow;
    /**
     * 提示框对象
     */
    private group;
    constructor(ctx: Context);
    private selectGroup;
    /**
     * 数据排序
     * @param metaDatas legend展示的数据
     */
    sortData(metaDatas: MetaData[]): MetaData[];
    show(eventData: EventData, allData: DataLeaf[][], scrollTop?: number): void;
    private getVirtualListMetaData;
    private clearTimer;
    hide(): void;
}
export declare function getTooltipContent(label: string, metaData: MetaData[], arrowType: "up" | "down", enableSort?: boolean, typeText?: string, valueText?: string, indexRange?: {
    start: undefined | number;
    end: undefined | number;
}): string;
