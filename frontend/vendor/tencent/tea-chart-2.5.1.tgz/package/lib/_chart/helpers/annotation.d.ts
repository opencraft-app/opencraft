import { Context } from "../context";
/**
 * 注释
 */
export interface AnnotationBaseOptions {
    /**
     * 元素样式
     */
    textStyle?: string;
    /**
     * x 偏移量
     */
    offsetX?: number;
    /**
     * y 偏移量
     */
    offsetY?: number;
}
/**
 *  Annotation 位置相关属性的类型定义
 */
export declare type AnnotationPosition = [string | number, string | number];
export interface AnnotationLabelOptions extends AnnotationBaseOptions {
    /**
     * 文本内容
     */
    content?: string | number;
    /**
     * 位置
     */
    position?: AnnotationPosition;
}
export interface AnnotationLineOptions {
    /**
     * 起点位置
     */
    start: [number, number];
    /**
     * 终点位置
     */
    end: [number, number];
    /**
     * 样式
     */
    style?: {
        stroke?: string;
        lineWidth?: number;
        lineDash?: number[];
    };
    /**
     * 文本标签
     */
    text?: {
        position?: "start" | "end" | "center";
        textStyle?: string;
        content?: string;
        offsetX?: number;
        offsetY?: number;
        textAnchor?: "start" | "end" | "middle";
    };
}
export declare class Annotation {
    private ctx;
    private group;
    private labels;
    private shapes;
    private labelOptions;
    private lineOptions;
    constructor(ctx: Context);
    label(key: string, cfg: AnnotationLabelOptions): this;
    line(key: string, cfg: AnnotationLineOptions): this;
    private drawTimer;
    draw(): void;
    drawLabels(cfg: AnnotationLabelOptions): void;
    drawLines(cfg: AnnotationLineOptions): void;
}
