import { Selection, ScalePoint, ScaleBand, ScaleLinear } from "d3";
import { Coordinate, CategoryScaleType } from "./coordinate";
import { Context } from "../context";
import { Helpers } from "../type/helpers";
/**
 * 直角坐标系
 * @since 2.0
 *
 * @todo 支持多轴
 */
export declare class RectCoordinate extends Coordinate {
    /**
     * X 轴栅格
     * @since 2.0
     */
    xAxisGrid: Selection<SVGGElement, {}, HTMLElement, {}>;
    /**
     * Y 轴栅格
     * @since 2.0
     */
    yAxisGrid: Selection<SVGGElement, {}, HTMLElement, {}>;
    /**
     * X 轴坐标轴刻度
     * @since 2.0
     */
    xAxis: Selection<SVGGElement, {}, HTMLElement, {}>;
    /**
     * Y 轴坐标轴刻度
     * @since 2.0
     */
    yAxis: Selection<SVGGElement, {}, HTMLElement, {}>;
    /**
     * X 轴标签
     * @since 2.0
     */
    xAxisLabels: Selection<SVGGElement, {}, HTMLElement, {}>;
    /**
     * Y 轴标签
     * @since 2.0
     */
    yAxisLabels: Selection<SVGGElement, {}, HTMLElement, {}>;
    /**
     * X 轴标题
     * @since 2.3
     */
    xAxisTitle: Selection<SVGTextElement, {}, HTMLElement, {}>;
    /**
     * X 轴标题
     * @since 2.3
     */
    yAxisTitle: Selection<SVGTextElement, {}, HTMLElement, {}>;
    /**
     * 重置缩放按钮
     */
    zoomResetButton: Selection<SVGGElement, {}, HTMLElement, {}>;
    /**
     * 分类轴比例尺
     * @since 2.0
     * @todo 未来支持多个
     */
    private categoryScale;
    /**
     * 分类轴数据比例尺类型
     * @since 2.0
     */
    private categoryScaleType;
    /**
     * 数据轴比例尺
     * @since 2.0
     * @todo 未来支持多个
     */
    private valueScale;
    /**
     * 是否为反转坐标轴
     * @since 2.0
     */
    private invert;
    /**
     * X 轴的高度，根据是不是显示来控制
     * @since 2.0
     */
    private xAxisHeight;
    /**
     * 坐标轴的高度
     * @since 2.0
     */
    height: number;
    /**
     * 坐标轴宽度
     * @since 2.0
     */
    width: number;
    constructor(ctx: Context, helpers: Helpers);
    /**
     * 绘制坐标轴
     * @param valueScale 数据比例尺
     * @param categroryScale 分类比例尺
     * @param categoryScaleType 分类比例尺类型
     * @param invert 是否为坐标轴反转
     *
     * @since 2.0
     */
    draw(valueScale: ScaleLinear<number, number>, categroryScale: ScalePoint<string> | [ScaleBand<string>, ScaleBand<string>], categoryScaleType: CategoryScaleType, invert: boolean): void;
    /**
     * 绘制 Y 轴
     * @since 2.0
     * @todo 轴标题
     */
    private drawYAxis;
    /**
     * 绘制 X 轴
     * @since 2.0
     */
    private drawXAxis;
    /**
     * 处理缩放
     * @param start 选择区域的起始点 X 坐标
     * @param end 选择区域的终点 X 坐标
     */
    private onZoomEvents;
    /**
     * 绘制缩放重置的按钮
     *
     * @since 2.0
     */
    private drawZoomResetButton;
    private clearGrid;
    private clearLabels;
    private drawTitles;
}
