import { ScalePoint, ScaleBand, ScaleLinear } from "d3";
import { Context } from "../context";
import { Helpers } from "../type/helpers";
export declare type CategoryScale = ScalePoint<string> | [ScaleBand<string>, // 分类比例尺
ScaleBand<string>];
export declare type ValueScale = ScaleLinear<number, number>;
export declare type CategoryScaleType = "Point" | "Band";
/**
 * 所有坐标系的基类
 */
export declare abstract class Coordinate {
    /**
     * 上下文对象
     * @since 2.0
     */
    ctx: Context;
    /**
     * 图标的辅助图层
     * @since 2.0
     */
    helpers: Helpers;
    /**
     * @contructor
     * @param ctx 全局上下文
     * @param model 数据模型
     */
    constructor(ctx: Context, helpers: Helpers);
    /**
     * 开始绘图
     * @since 2.0
     */
    abstract draw(valueScale: ValueScale, categroryScale?: CategoryScale, categroryScaleType?: CategoryScaleType, invert?: boolean): void;
}
