import { Coordinate } from "./coordinate";
/**
 * 极坐标系
 * @since 2.0
 *
 * @todo 支持多轴
 */
export declare class PolarCoordinate extends Coordinate {
    /**
     * 坐标轴的高度
     * @since 2.0
     */
    height: number;
    /**
     * 坐标轴宽度
     * @since 2.0
     */
    width: number;
    draw(): void;
}
