import { DataSource, DataLeaf } from "./type/data";
/**
 * 图表数据模型
 */
export declare class DataModel {
    /**
     * 原始数据
     * @since 2.0
     */
    raw: DataSource;
    /**
     * 原始数据中作为行字段的 key 值
     * 行字段的值在直角坐标系中一般作为 X 轴的值
     * @since 2.0
     */
    categoryKey: string;
    /**
     * 原始数据中作为列字段的 key 值
     * @since 2.0
     */
    serieKey: string;
    /**
     * 原始数据中作为值字段的 key 值
     * @since 2.0
     */
    valueKey: string;
    /**
     * 原始数据中作为颜色字段的 key 值
     * @since 2.0
     */
    colorKey: string;
    /**
     * 是否为堆叠数据
     * @since 2.0
     */
    stack: boolean;
    /**
     * 堆叠的类型
     * @since 2.0
     */
    stackType: "stack" | "percent";
    /**
     * 行字段值排序
     * @since 2.0
     */
    sortKeys: (a: string, b: string) => number;
    /**
     * 行列式数据生成器
     * @private
     * @since 2.0
     */
    private determinantOperator;
    /**
     * 被行列式数据生成器加工后的数据表
     * @private
     * @since 2.0
     */
    private dataTable;
    /**
     * 过滤的列名
     * @private
     * @since 2.0
     */
    private filterColumnNames;
    /**
     * 过滤后的数据表
     * @private
     * @since 2.0
     */
    private filterDataTable;
    /**
     * 分类的范围，用于数据缩放
     * @private
     * @since 2.0
     */
    private categoryRange;
    /**
     * 值域的缓存
     * @private
     * @since 2.0
     */
    private extentCache;
    /**
     * 定义数据模型，根据 Key 生成对应的行列式生成器
     *
     * @param categoryKey 原始字段用作行的字段名，对应 category
     * @param valueKey 原始数据中作为值的字段名，对应 value
     * @param serieKey 原始字段中作为列的字段名，用于分类，对应 series
     * @param sortKeys 行字段值的排序方式
     * @param stack 是否为堆积图
     *
     * @since 2.0
     */
    define(categoryKey: string, valueKey: string, serieKey: string, colorKey: string, sortKeys?: (a: string, b: string) => number, stack?: boolean, stackType?: "stack" | "percent"): void;
    /**
     * 修改原始数据
     * @param dataSource 原始数据
     * @since 2.0
     */
    source(dataSource?: DataSource): void;
    /**
     * 根据列字段值过滤数据表
     * @param serieNames 保留数据的列字段值
     * @since 2.0
     */
    filterColumns(serieNames: string[]): void;
    /**
     * 设置保留的行
     * @param categories 保留的行
     * @since 2.0
     */
    range(categories: string[]): void;
    /**
     * 获取列名
     * @param getAll 是否包含过滤的列
     * @since 2.0
     */
    getSerieNames(getAll?: boolean): string[];
    /**
     * 获取行名
     * @since 2.0
     */
    getCategoryNames(allData?: boolean): string[];
    /**
     * 根据字段名获取原始数据中所有的字段值
     * @param key 字段名
     */
    getKeyNames(key: string): string[];
    /**
     * 计算值域
     * @param autoFit 是否获取最接近的阈值而非从 0 开始
     * @since 2.0
     */
    getExtent(autoFit?: boolean): [number, number];
    /**
     * 获取指定行列的值
     * @param categoryKey 行字段值
     * @param serieKey 列字段值
     * @param originValue 显示原始值
     * @param allData 使用全部的数据
     * @since 2.0
     */
    get(categoryKey: string, serieKey: string, originValue?: boolean): any;
    /**
     * 获取指定行列的值
     * @param categoryKey 行字段值
     * @param serieKey 列字段值
     * @param originValue 显示原始值
     * @param allData 使用全部的数据
     * @since 2.0
     */
    getByAll(categoryKey: string, serieKey: string, originValue?: boolean): any;
    /**
     * 根据行字段的值获取某行数据
     * @param categoryKey 行字段值
     *
     * @todo 数据缓存
     */
    getDataFromCategoryName(categoryKey: string, withPercent?: boolean, allData?: boolean): DataLeaf[];
    /**
     * 根据列字段的值获取某列数据
     * @param serieKey 列字段值
     *
     * @todo 数据缓存
     */
    getDataFromSerieName(serieKey: string): DataLeaf[];
    /**
     * 获取当前生效的全部数据
     */
    getAllData(): DataLeaf[][];
}
