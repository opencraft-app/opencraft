import { Shape, Datum } from "./shape";
import { Color } from "../type/chart";
import { ContextOptions, Context } from "../context";
import { RectCoordinate } from "../coordinates/rect-coord";
import { Helpers } from "../type/helpers";
import { MetaData, EventData } from "../type/data";
export declare class Bar extends Shape {
    /**
     * 每个 X 轴点对应柱形的最大宽度
     * @since 2.0
     */
    private maxBarWidth;
    /**
     * 分类轴数据比例尺类型
     * @since 2.0
     */
    private categoryScaleType;
    /**
     * Crosshair
     * @since 2.0
     */
    private crosshair;
    /**
     * 高亮的元素
     * @since 2.3
     */
    private highlightElements;
    constructor(ctx: Context, coord: RectCoordinate, helpers: Helpers, maxBarWidth?: number);
    /**
     * @implements Shape
     * @param pos 数据映射关系
     * @since 2.0
     */
    position(pos: string): this;
    /**
     * @implements
     * @param {string} color 作为数据系列映射字段
     * @param {Color} color 以 Color 的配置来设置颜色与数据系列映射关系
     * @since 2.0
     */
    color(color: string | Color | string[]): this;
    size(size: number): this;
    /**
     * 每个 X 轴点对应柱形的最大宽度
     * @param {number} maxBarWidth 最大宽度
     * @since 2.0
     */
    maxWidth(maxBarWidth: number): this;
    /**
     * 设置坐标轴配置
     * @param axis 坐标轴配置
     * @since 2.0
     */
    axis(axis: ContextOptions["axis"]): this;
    /**
     * @implements
     * @since 2.0
     */
    updateModel(): void;
    /**
     * 更新颜色比例尺
     * @implements
     * @since 2.0
     */
    updateColorScale(): void;
    /**
     * 更新数据比例尺
     * @implements
     * @since 2.0
     */
    updateDataScale(): void;
    /**
     * 开始绘图
     * @implements
     * @since 2.0
     */
    draw(updateModel?: boolean): void;
    /**
     * 绘制柱状图
     * @since 2.0
     */
    drawSeries(): void;
    /**
     *
     * 绘制堆叠数据值文本
     * @param datum 数据
     * @param barWidth 柱子的宽度
     */
    drawStackLabels(datum: Datum, barWidth: number): void;
    /**
     * 绘制数据值文本
     * @param datum 数据
     * @param barWidth 柱子的宽度
     */
    drawDataLabels(datum: Datum, barWidth: number): void;
    private onMouseMove;
    /**
     * 根据坐标获取数据
     * @since 2.0
     * @param x x 坐标
     * @param y y 坐标
     */
    getData(x: number, y?: number): EventData;
    /**
     * 通过分类坐标名获取数据
     * @param category
     */
    getDataFromCategory(category: string): MetaData[];
    /**
     * 通过值获取坐标
     * @param category 分类值
     * @param value 数据值
     */
    getPosition(category: string, value: number): any[];
    /**
     * 绘制标记线和标记点
     * @param eventData 当前数据点信息
     * @since 2.0
     * @todo 修复最后一个点不显示的问题
     */
    private drawHover;
    /**
     * 隐藏标记线和标记点
     * @since 2.0
     */
    private removeHover;
    /**
     * 监听图例事件
     * @param legendData LegendData
     */
    private onLegendItemHover;
    /**
     * 监听图例事件
     * @param legendData LegendData
     */
    private onLegendItemLeft;
    /**
     * 图例点击事件
     * @param legendData 被点击的图例信息
     * @param disabled 改图例元素是否是禁用状态
     */
    private onLegendClick;
    private onClick;
    private onZoom;
    private onZoomReset;
}
