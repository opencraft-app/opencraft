import { ScaleOrdinal, Selection } from "d3";
import { Context } from "../context";
import { DataModel } from "../data-model";
import { RectCoordinate } from "../coordinates/rect-coord";
import { Helpers } from "../type/helpers";
import { Color } from "../type/chart";
import { CategoryScale, ValueScale } from "../coordinates/coordinate";
import { PolarCoordinate } from "../coordinates/polar-coord";
import { ShapeOptions } from "../type/options";
import { DataLeaf } from "../type";
export interface DatumPoint {
    value: number;
    x: number;
    y: number;
    color: string;
    metric: number;
    originValue: number;
    category: string;
    dataLeaf: DataLeaf;
}
export interface Datum {
    [key: string]: DatumPoint[];
}
export interface DataMarker {
    position: [string, number];
    text: {
        content: string;
        style?: string;
    };
    line?: {
        length?: number;
        color?: string;
        width?: number;
    };
}
/**
 * 所有图形的基类
 * @since 2.0
 */
export declare abstract class Shape {
    /**
     * 图形 ID
     */
    id: string;
    /**
     * 全局上下文
     * @since 2.0
     */
    ctx: Context;
    /**
     * 数据模型
     * @since 2.0
     */
    model: DataModel;
    /**
     * 当前图表的辅助图层
     * @since 2.0
     */
    helpers: Helpers;
    /**
     * 图形绘制区
     * @since 2.0
     */
    seriesGroup: Selection<SVGGElement, {}, HTMLElement, {}>;
    /**
     * 坐标轴实例
     * @since 2.0
     */
    coordinate: RectCoordinate | PolarCoordinate;
    /**
     * 数据映射字段 key
     * @since 2.0
     */
    valueKey: string;
    /**
     * 数据系列映射字段 key
     *
     * 数据系列字段通常对应颜色分类
     *
     * @since 2.0
     */
    serieKey: string;
    /**
     * 颜色映射字段
     *
     * @since 2.0.1
     */
    colorKey: string;
    /**
     * 分类映射字段 key
     *
     * 分类映射字段通常对应直角坐标系的 X 轴
     *
     * @since 2.0
     */
    categoryKey: string;
    /**
     * 颜色比例尺
     * @since 2.0
     */
    colorScale: ScaleOrdinal<string, string>;
    /**
     * 颜色映射回调函数
     * @since 2.1.2
     */
    colorAttrCallback: Color["formatter"];
    /**
     * 分类比例尺
     * 直角坐标系：X 轴
     * @since 2.0
     */
    categoryScale: CategoryScale;
    /**
     * 数据比例尺
     * @since 2.0
     */
    valueScale: ValueScale;
    /**
     * 图形尺寸
     * @since 2.0
     */
    shapeSize: number;
    /**
     * 坐标轴翻转
     */
    invert: boolean;
    /**
     * 当前 Hover 的索引
     */
    currentHoverIndex: number;
    /**
     * 过滤的数据系列名
     * @since 2.0
     */
    disabledKeys: string[];
    /**
     * 图形设置
     */
    options: ShapeOptions;
    /**
     * @constructor
     * @param ctx 上下文
     * @since 2.0
     */
    constructor(ctx: Context, coord: RectCoordinate | PolarCoordinate, helpers: Helpers);
    /**
     * 设置数据映射关系
     * @param pos 数据映射关系
     * @since 2.0
     */
    abstract position(pos: string): this;
    /**
     * 以颜色作为数据映射
     * @param {string} colorCfg 作为数据系列映射字段
     * @param {Color} colorCfg 以 Color 的配置来设置颜色与数据系列映射关系
     * @since 2.0
     */
    abstract color(colorCfg: string | Color | string[]): this;
    shape(cfg: ShapeOptions): this;
    /**
     * 更新数据模型
     * @since 2.0
     */
    abstract updateModel(): void;
    /**
     * 更新颜色比例尺
     * @since 2.0
     */
    abstract updateColorScale(): void;
    /**
     * 绘图
     * @since 2.0
     */
    abstract draw(): void;
    /**
     * 绘制图形
     * @since 2.0
     */
    abstract drawSeries(): void;
}
