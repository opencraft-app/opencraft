import { Shape } from "./shape";
import { Color } from "../type/chart";
import { ContextOptions, Context } from "../context";
import { RectCoordinate } from "../coordinates/rect-coord";
import { Helpers } from "../type/helpers";
import { MetaData, EventData } from "../type/data";
export declare class Line extends Shape {
    /**
     * 分类轴数据比例尺类型
     * @since 2.0
     */
    private categoryScaleType;
    /**
     * Crosshair
     * @since 2.0
     */
    private crosshair;
    private allCategoryScale;
    private canvasMode;
    private highlightKey;
    constructor(ctx: Context, coord: RectCoordinate, helpers: Helpers);
    /**
     * @implements Shape
     * @param pos 数据映射关系
     * @since 2.0
     */
    position(pos: string): this;
    /**
     * @implements
     * @param {string} color 作为数据系列映射字段
     * @param {Color} color 以 Color 的配置来设置颜色与数据系列映射关系
     * @since 2.0
     */
    color(color: string | Color | string[]): this;
    size(size: number): this;
    /**
     * 设置坐标轴配置
     * @param axis 坐标轴配置
     * @since 2.0
     */
    axis(axis: ContextOptions["axis"]): this;
    /**
     * 设置图例
     * @param enable 是否显示图例
     * @param connectNullsCfg 连接空值配置
     * @since 2.0
     */
    connectNulls(enable: boolean | ContextOptions["connectNulls"], connectNullsCfg?: ContextOptions["connectNulls"]): this;
    /**
     * @implements
     * @since 2.0
     */
    updateModel(): void;
    /**
     * 更新颜色比例尺
     * @implements
     * @since 2.0
     */
    updateColorScale(): void;
    /**
     * 更新数据比例尺
     * @implements
     * @since 2.0
     */
    updateDataScale(): void;
    /**
     * 开始绘图
     * @implements
     * @since 2.0
     */
    draw(updateModel?: boolean, updateColorScale?: boolean, updateDataScale?: boolean): void;
    /**
     * 绘制折线图
     * @since 2.0
     */
    drawSeries(): void;
    private timer;
    private onMouseMove;
    /**
     * 根据坐标获取数据
     * @since 2.0
     * @param x x 坐标
     * @param y y 坐标
     */
    getData(x: number, y?: number): EventData;
    /**
     * 通过分类坐标名获取数据
     * @param category
     */
    getDataFromCategory(category: string): MetaData[];
    /**
     * 通过值获取坐标
     * @param category 分类值
     * @param value 数据值
     */
    getPosition(category: string, value: number): number[];
    /**
     * 绘制标记线和标记点
     * @param eventData 当前数据点信息
     * @since 2.0
     * @todo 修复最后一个点不显示的问题
     */
    private drawHover;
    /**
     * 隐藏标记线和标记点
     * @since 2.0
     */
    private removeHover;
    /**
     * 监听图例事件
     * @param legendData LegendData
     */
    private onLegendItemHover;
    /**
     * 监听图例事件
     * @param legendData LegendData
     */
    private onLegendItemLeft;
    /**
     * 图例点击事件
     * @param legendData 被点击的图例信息
     * @param disabled 改图例元素是否是禁用状态
     */
    private onLegendClick;
    private onClick;
    private onZoom;
    private onZoomReset;
}
