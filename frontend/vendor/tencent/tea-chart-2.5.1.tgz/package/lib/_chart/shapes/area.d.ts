import { Line } from "./line";
export interface AreaStyle {
    /**
     * 填充色透明度
     */
    fillOpacity?: number;
}
export declare class Area extends Line {
    private areaStyle;
    style(cfg: AreaStyle): this;
    /**
     * 绘制折线图
     * @since 2.0
     */
    drawSeries(): void;
}
