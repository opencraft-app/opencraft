import { PieArcDatum } from "d3";
import { Shape } from "./shape";
import { Color, PolarProps } from "../type/chart";
import { PolarCoordinate } from "../coordinates/polar-coord";
import { Context } from "../context";
import { Helpers } from "../type/helpers";
export declare class Pie extends Shape {
    private radius;
    private innerRadius;
    private arcInstance;
    private hoverArcInstance;
    private labelTextHeight;
    constructor(ctx: Context, coord: PolarCoordinate, helpers: Helpers);
    /**
     * 开始监听事件
     */
    private start;
    position(pos: string): this;
    color(color: string | Color | string[]): this;
    coord(cfg: PolarProps["coord"]): this;
    updateModel(): void;
    updateColorScale(): void;
    draw(updateModel?: boolean): void;
    drawSeries(): this;
    drawDataLabels(data: PieArcDatum<string>[]): void;
    private onClick;
    private drawSelected;
    /**
     * 显示辅助点
     */
    private showHover;
    /**
     * 隐藏辅助点
     */
    private hideHover;
    private onLegendItemHover;
    private onLegendItemLeft;
    /**
     * 图例点击事件
     * @param legendData 被点击的图例信息
     * @param disabled 改图例元素是否是禁用状态
     */
    private onLegendClick;
}
