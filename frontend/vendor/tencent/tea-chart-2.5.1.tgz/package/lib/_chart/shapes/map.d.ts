import { Selection, ScaleLinear } from "d3";
import { Context } from "../context";
import { Helpers, Color, ShapeOptions, MapType, Language } from "../type";
import { DataModel } from "../data-model";
export declare class Map {
    /**
     * 图形 ID
     */
    id: string;
    /**
     * 地图类型
     */
    mapType: MapType;
    /**
     * geo数据链接
     */
    geoJsonUrl: string;
    /**
     * 语言类型，目前仅中英文
     */
    mapLanguage: Language;
    /**
     * 全局上下文
     * @since 2.3
     */
    ctx: Context;
    /**
     * 数据模型
     * @since 2.3
     */
    model: DataModel;
    /**
     * 当前图表的辅助图层
     * @since 2.3
     */
    helpers: Helpers;
    /**
     * 图形绘制区
     * @since 2.3
     */
    seriesGroup: Selection<SVGGElement, {}, HTMLElement, {}>;
    /**
     * 地图路径
     * @since 2.3
     */
    mapPathGroup: Selection<SVGPathElement, {}, SVGGElement, {}>;
    /**
     * 数据映射字段 key
     * @since 2.3
     */
    valueKey: string;
    /**
     * 数据系列映射字段 key
     *
     * 数据系列字段通常对应颜色分类
     *
     * @since 2.3
     */
    serieKey: string;
    /**
     * 分类映射字段
     *
     * @since 2.3
     */
    categoryKey: string;
    /**
     * 颜色比例尺
     */
    colorScale: ScaleLinear<string, string>;
    /**
     * 颜色映射回调函数
     * @since 2.1.2
     */
    colorAttrCallback: Color["formatter"];
    /**
     * 图形设置
     */
    options: ShapeOptions;
    /**
     * 地图数据
     * @since 2.3
     */
    private geoJSON;
    /**
     * 当前geo数据类型
     */
    private geoJsonType;
    /**
     * 渐变矩形条
     */
    private gradientRect;
    /**
     * 渐变定义
     */
    private gradientDefs;
    constructor(ctx: Context, helpers: Helpers);
    /**
     * @implements Shape
     * @param pos 数据映射关系
     * @since 2.0
     */
    position(pos: string): this;
    color(color: string[] | Color): this;
    registerMap(geoJSON: any): this;
    updateModel(): void;
    /**
     * 更新颜色比例尺
     * @since 2.3
     */
    updateColorScale(): void;
    draw(): this;
    private downLoadGeoJSON;
    drawMap(): void;
    shape(cfg: ShapeOptions): this;
    setMapType(mapType: MapType): this;
    setGeoJsonUrl(geoJsonUrl: string): this;
    language(language: Language): this;
    private drawGradientRect;
}
