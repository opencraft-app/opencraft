/// <reference types="react" />
import { RectProps } from "../_chart/type/chart";
export interface BasicBarProps extends RectProps {
    /**
     * 每个 X 轴点对应柱形的总宽度
     */
    size?: number;
    /**
     * 每个 X 轴点对应柱形的最大宽度，如果同时定义了size则优先使用size
     * @default 60
     * @since 2.0
     */
    maxBarWidth?: number;
}
export declare function BasicBar(props: BasicBarProps): JSX.Element;
