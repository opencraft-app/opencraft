/// <reference types="react" />
import { RectProps } from "../_chart/type/chart";
import { Omit } from "../_type";
export interface BasicLineProps extends Omit<RectProps, "dataLabels"> {
    /**
     * 折线的粗细
     *
     * @default 3
     */
    size?: number;
    /**
     * 是否连接空值
     * @default true
     * @since 2.0
     */
    connectNulls?: boolean;
    /**
     * 是否为平滑曲线
     */
    smooth?: boolean;
    /**
     * 支持开启Canvas，优化大数据卡顿问题
     */
    canvasMode?: boolean;
}
export declare function BasicLine(props: BasicLineProps): JSX.Element;
