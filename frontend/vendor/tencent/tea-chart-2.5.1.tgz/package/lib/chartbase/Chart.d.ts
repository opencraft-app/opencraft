import React from "react";
import { Chart } from "../_chart";
import { ChartProps } from "../_chart/type/chart";
import { ZoomOptions } from "../_chart/type";
export interface ChartBaseProps extends Omit<ChartProps, "chartRef"> {
    /**
     * 是否启用缩放。已废弃，请使用 [interaction]
     * @deprecated
     */
    zoom?: boolean | ZoomOptions;
}
/**
 * ChartBase 是所有图形组件底层组件，用以生成图表实例 chart，并负责所有 chart 的属性变更操作
 */
export declare const ChartBase: React.ForwardRefExoticComponent<ChartBaseProps & React.RefAttributes<Chart>>;
