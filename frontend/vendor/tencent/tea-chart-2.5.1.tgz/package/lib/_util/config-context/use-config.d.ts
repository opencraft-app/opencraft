export declare function useConfig(): {
    classPrefix: string;
    locale: "en" | "zh" | "ko" | "ja";
};
