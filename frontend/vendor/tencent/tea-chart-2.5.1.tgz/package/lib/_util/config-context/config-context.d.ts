/// <reference types="react" />
export declare const DEFAULT_CLASS_PREFIX: string;
export declare const DEFAULT_LOCALE: "en" | "zh" | "ko" | "ja";
export interface ConfigProps {
    /**
     * 组件类名前缀
     *
     * @default "tea"
     */
    classPrefix?: string;
    /**
     * 组件语言版本
     *
     * @default "zh"
     */
    locale?: "zh" | "en" | "ko" | "ja";
}
export declare const ConfigContext: import("react").Context<ConfigProps>;
