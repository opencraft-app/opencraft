import React from "react";
import { ConfigProps } from "./config-context";
export interface WithConfigProps {
    /**
     * @ignore
     */
    config?: ConfigProps;
}
export declare function withConfig<C extends React.ComponentType<any>>(WrappedComponent: C): C;
