import React from "react";
import { AnnotationLine } from "./Line";
import { Chart } from "../_chart";
import { Annotation as AnnotationType } from "../_chart/helpers/annotation";
export * from "./Label";
export * from "./Line";
export interface AnnotationOptions {
    children?: React.ReactNode;
}
export interface AnnotationProps extends AnnotationOptions {
    chart: Chart;
    annotation: AnnotationType;
}
export declare function Annotation(props: AnnotationOptions): any;
export declare namespace Annotation {
    var Label: typeof import("./Label").Label;
    var Line: typeof AnnotationLine;
}
