import { AnnotationLabelOptions } from "../_chart/helpers/annotation";
export interface AnnotationLabelProps extends AnnotationLabelOptions {
}
export declare function Label(props: AnnotationLabelOptions): any;
