import { AnnotationLineOptions } from "../_chart/helpers/annotation";
export interface AnnotationLineProps extends AnnotationLineOptions {
}
export declare function AnnotationLine(props: AnnotationLineOptions): any;
