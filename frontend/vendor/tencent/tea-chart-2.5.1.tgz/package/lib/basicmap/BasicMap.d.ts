/// <reference types="react" />
import { ChartProps, Color } from "../_chart/type/chart";
import { Omit } from "../_type";
import { MapType, Language } from "../_chart/type/options";
export interface BasicMapProps extends Omit<ChartProps, "color" | "dataSource"> {
    /**
     * language为zh时，可传中文地区/国家名称、地区编码，例如, type: "中国" | type: "156"
     * language为en时，可传英文地区名称、地区编码，例如, type: "China" | type: "156"
     * 国家地区编码表：https://zh.wikipedia.org/wiki/ISO_3166-1
     * 中国一级地区编码表：https://zh.wikipedia.org/wiki/%E4%B8%AD%E5%8D%8E%E4%BA%BA%E6%B0%91%E5%85%B1%E5%92%8C%E5%9B%BD%E8%A1%8C%E6%94%BF%E5%8C%BA%E5%88%92%E4%BB%A3%E7%A0%81
     */
    dataSource: {
        /**
         * 地区维度值
         */
        type: string;
        /**
         * 数值
         */
        value: number;
    }[];
    color: string[] | Color;
    /**
     * 地图类型
     * @default "china"
     */
    mapType?: MapType;
    /**
     * geoJson链接地址
     */
    geoJsonUrl?: string;
    /**
     * 语言类型，默认中文
     * @default "zh"
     */
    language?: Language;
}
export declare function BasicMap(props: BasicMapProps): JSX.Element;
