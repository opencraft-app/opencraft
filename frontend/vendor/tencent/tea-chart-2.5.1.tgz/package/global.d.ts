/**
 * Webpack 注入
 */
declare const TEA_CLASS_PREFIX: string;
declare const WEBPACK_BUILD_LOCALE: "zh" | "en" | "ko" | "ja";
