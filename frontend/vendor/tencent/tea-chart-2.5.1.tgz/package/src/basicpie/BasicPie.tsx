import React, {
  useRef,
  useEffect,
  useImperativeHandle,
  useState,
  useMemo,
} from "react";
import { PolarProps } from "../_chart/type/chart";
import { Chart } from "../_chart";
import { Pie } from "../_chart/shapes/pie";
import { ChartBase } from "../chartbase";
import { comparePropsEqual } from "../_chart/lib/compare-props-equal";

export interface BasicPieProps extends PolarProps {
  /**
   * 是否为环形图，若设置了 `coord` 则此属性不生效
   * @default false
   */
  circle?: boolean;
}

export function BasicPie(props: BasicPieProps) {
  const { chartRef: ref } = props;
  const chartRef = useRef<Chart>();
  const [newProps, updateProps] = useState(props);
  const shapeRef = useRef<Pie>();

  useEffect(() => {
    if (chartRef.current) {
      shapeRef.current = chartRef.current.pie();
    }
  }, [chartRef]);

  useImperativeHandle(ref, () => ({
    on: (...args) => {
      if (chartRef.current) {
        chartRef.current.on(...args);
      }
    },
    once: (eventName: string, callback) => {
      if (chartRef.current) {
        chartRef.current.once(eventName, callback);
      }
    },
    off: (eventName: string, callback) => {
      if (chartRef.current) {
        chartRef.current.off(eventName, callback);
      }
    },
    emit: (...args) => {
      if (chartRef.current) {
        chartRef.current.emit(...args);
      }
    },
  }));

  useEffect(() => {
    if (!comparePropsEqual(newProps, props)) {
      updateProps(props);
    }
  }, [newProps, props]);

  useEffect(() => {
    const { position, color, coord, circle, dataLabels } = newProps;
    const shapeOpts =
      typeof dataLabels === "boolean"
        ? { dataLabels: { enable: dataLabels } }
        : { dataLabels: { ...dataLabels } };
    shapeRef.current
      .position(position)
      .color(color)
      .coord(coord || { innerRadius: circle ? 0.6 : 0 })
      .shape(shapeOpts);
  }, [newProps]);

  return useMemo(() => {
    return <ChartBase {...newProps} ref={chartRef} />;
  }, [newProps]);
}
