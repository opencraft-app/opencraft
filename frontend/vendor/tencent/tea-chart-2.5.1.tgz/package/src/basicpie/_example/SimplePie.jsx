import React, { Fragment } from "react";
import { Row, Col } from "@tencent/tea-component";
import { BasicPie } from "@tencent/tea-chart/lib/basicpie";

export default function SimpleBasicPieExample() {
  const data = [
    { type: "防止主机瘫痪", value: 291 },
    { type: "避免数据泄露", value: 302 },
    { type: "防止页面篡改", value: 82 },
  ];

  return (
    <Fragment>
      <Row>
        <Col span={12}>
          <BasicPie
            height={250}
            dataSource={data}
            position="value"
            color="type"
          />
        </Col>
        <Col span={12}>
          <BasicPie
            circle
            height={250}
            dataSource={data}
            position="value"
            color="type"
          />
        </Col>
      </Row>
    </Fragment>
  );
}
