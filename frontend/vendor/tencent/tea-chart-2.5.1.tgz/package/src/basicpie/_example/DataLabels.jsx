import React, { Fragment } from "react";
import { Row, Col } from "@tencent/tea-component";
import { BasicPie } from "@tencent/tea-chart/lib/basicpie";

export default function SimpleBasicPieExample() {
  const data = [
    { type: "防止主机瘫痪", value: 183 },
    { type: "避免数据泄露", value: 23 },
    { type: "防止页面篡改", value: 8 },
    { type: "防止DDOS攻击", value: 8 },
    { type: "防止XSS攻击", value: 4 },
  ];

  return (
    <Fragment>
      <Row>
        <Col span={12}>
          <BasicPie
            height={250}
            dataSource={data}
            position="value"
            color="type"
            dataLabels
          />
        </Col>
        <Col span={12}>
          <BasicPie
            circle
            height={250}
            dataSource={data}
            position="value"
            color="type"
            dataLabels={{
              enable: true,
              formatter: (value, index, data) => {
                return `${data.serieName}: ${data.percent}%`;
              },
            }}
          />
        </Col>
      </Row>
    </Fragment>
  );
}
