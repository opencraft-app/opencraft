# BasicPie 基本饼图

基本饼图是其他折线组件的基础组件，包含几乎全部属性，但是意味着使用起来会较为复杂。建议选择特定场景的组件来使用。

## 使用示例

对于最简单的使用只需要配置少量参数即可

[Example: 基本使用](./_example/SimplePie.jsx)

可以显示数据标签

[Example: 数据标签](./_example/DataLabels.jsx)


## 组件属性

[Interface: BasicPieProps](./BasicPie.tsx)
