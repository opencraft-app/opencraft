import { useEffect } from "react";
import {
  Annotation,
  AnnotationLineOptions,
} from "../_chart/helpers/annotation";

export interface AnnotationLineProps extends AnnotationLineOptions {}

interface LineProps extends AnnotationLineProps {
  annotation: Annotation;
  index: number;
}

export function AnnotationLine(props: AnnotationLineOptions) {
  const { annotation, index } = props as LineProps;
  useEffect(() => {
    setTimeout(() => {
      if (annotation) {
        annotation.line(`annotation-line-${index}`, props).draw();
      }
    });
  }, [annotation, index, props]);
  return null;
}
