# Annotation 注释

注释通常用于标记某些数据点或者阈值线等标记行为；

## 使用示例

可以在环形图中自定义显示文本

[Example: 基本使用](./_example/Pie.jsx)

可以在折线图或者柱状图中定义辅助线

[Example: 基本使用](./_example/Line.jsx)

## 组件属性

[Interface: AnnotationLabelProps](./Label.tsx)

[Interface: AnnotationLineProps](./Line.tsx)