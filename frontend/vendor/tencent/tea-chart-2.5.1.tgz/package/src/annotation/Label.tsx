import { useEffect } from "react";
import {
  AnnotationLabelOptions,
  Annotation,
} from "../_chart/helpers/annotation";

export interface AnnotationLabelProps extends AnnotationLabelOptions {}

interface LabelProps extends AnnotationLabelProps {
  annotation: Annotation;
  index: number;
}

export function Label(props: AnnotationLabelOptions) {
  const { annotation, index } = props as LabelProps;
  useEffect(() => {
    setTimeout(() => {
      if (annotation) {
        annotation.label(`annotation-label-${index}`, props).draw();
      }
    });
  }, [annotation, index, props]);
  return null;
}
