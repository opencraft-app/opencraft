import React, { Fragment, useRef, useEffect, useState } from "react";
import { BasicPie } from "@tencent/tea-chart/lib/basicpie";
import { Annotation } from "@tencent/tea-chart/lib/annotation";

export default function SimpleBasicPieExample() {
  const chartRef = useRef(null);
  const [label, setLabel] = useState({
    title: "防止主机瘫痪",
    valueText: "291",
  });
  const data = [
    { type: "防止主机瘫痪", value: 291 },
    { type: "避免数据泄露", value: 302 },
    { type: "防止页面篡改", value: 82 },
  ];

  useEffect(() => {
    chartRef.current.on("interaction.hover", meta => {
      const [{ title, valueText }] = meta;
      setLabel({ title, valueText });
    });
  }, []);

  return (
    <Fragment>
      <BasicPie
        circle
        interaction={["element-hover"]}
        height={250}
        dataSource={data}
        position="value"
        color="type"
        chartRef={ref => {
          chartRef.current = ref;
        }}
      >
        {label && (
          <Annotation>
            <Annotation.Label
              content={label.title}
              position={["50%", "50%"]}
              offsetY={-10}
              textStyle="font-size:16px;font-weight:600;"
            />
            <Annotation.Label
              content={label.valueText}
              position={["50%", "50%"]}
              offsetX={-10}
              offsetY={35}
              textStyle="font-size:16px;color:red;"
            />
            <Annotation.Label
              content="台"
              position={["50%", "50%"]}
              offsetX={20}
              offsetY={35}
              textStyle="font-size:16px;"
            />
          </Annotation>
        )}
      </BasicPie>
    </Fragment>
  );
}
