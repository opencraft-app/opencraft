import React, { Fragment, useRef, useState, useEffect } from "react";
import { BasicLine } from "@tencent/tea-chart/lib/basicline";
import { Annotation } from "@tencent/tea-chart/lib/annotation";

const data = [
  { time: "0:00", value: 10 },
  { time: "1:00", value: 20 },
  { time: "2:00", value: 50 },
  { time: "3:00", value: 60 },
  { time: "4:00", value: 20 },
  { time: "5:00", value: 72 },
  { time: "6:00", value: 98 },
  { time: "7:00", value: 60 },
  { time: "8:00", value: 70 },
  { time: "9:00", value: 58 },
  { time: "10:00", value: 22 },
  { time: "11:00", value: 68 },
  { time: "12:00", value: 83 },
];

export default function SimpleLineExample() {
  const chartRef = useRef(null);
  const [start, setStart] = useState([]);
  const [end, setEnd] = useState([]);
  const [verticalStart, setVerticalStart] = useState([]);
  const [verticalEnd, setVerticalEnd] = useState([]);

  useEffect(() => {
    if (chartRef.current) {
      chartRef.current.once("chart.rendered", () => {
        const start = chartRef.current.getPosition("0:00", 85);
        const end = chartRef.current.getPosition("12:00", 85);
        setStart(start);
        setEnd(end);
        // 如果不确定上限可以把值设置的大一些
        const vStart = chartRef.current.getPosition("6:00", 200);
        const vEnd = chartRef.current.getPosition("6:00", 0);
        setVerticalStart(vStart);
        setVerticalEnd(vEnd);
      });
    }
  }, []);

  return (
    <Fragment>
      <BasicLine
        height={250}
        position="time*value"
        dataSource={data}
        chartRef={ref => {
          chartRef.current = ref;
        }}
      >
        <Annotation>
          <Annotation.Line
            start={start}
            end={end}
            style={{
              stroke: "red",
            }}
            text={{
              position: "start",
              content: "阈值线",
              textStyle: "color:red;",
              offsetY: -5,
            }}
          />
          <Annotation.Line
            start={verticalStart}
            end={verticalEnd}
            style={{
              stroke: "blue",
              lineDash: [3, 3],
              lineWidth: 2,
            }}
          />
        </Annotation>
      </BasicLine>
    </Fragment>
  );
}
