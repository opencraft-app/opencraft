import React from "react";
import { Label } from "./Label";
import { AnnotationLine } from "./Line";
import { Chart } from "../_chart";
import { Annotation as AnnotationType } from "../_chart/helpers/annotation";

export * from "./Label";
export * from "./Line";

export interface AnnotationOptions {
  children?: React.ReactNode;
}

export interface AnnotationProps extends AnnotationOptions {
  chart: Chart;
  annotation: AnnotationType;
}

export function Annotation(props: AnnotationOptions) {
  const { children, annotation } = props as AnnotationProps;

  return React.Children.map(children, (child, index) => {
    return React.cloneElement(child as any, {
      annotation,
      index,
    });
  }) as any;
}

Annotation.Label = Label;
Annotation.Line = AnnotationLine;
