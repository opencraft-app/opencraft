import { useContext } from "react";
import {
  ConfigContext,
  DEFAULT_CLASS_PREFIX,
  DEFAULT_LOCALE,
} from "./config-context";

export function useConfig() {
  const context = useContext(ConfigContext) || {};
  return {
    classPrefix: DEFAULT_CLASS_PREFIX,
    locale: DEFAULT_LOCALE,
    ...context,
  };
}
