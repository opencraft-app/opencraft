import React from "react";
import { useConfig } from "./use-config";
import { ConfigProps } from "./config-context";

export interface WithConfigProps {
  /**
   * @ignore
   */
  config?: ConfigProps;
}

export function withConfig<C extends React.ComponentType<any>>(
  WrappedComponent: C
): C {
  return (React.forwardRef(
    (props, ref: React.LegacyRef<React.Component<any>>) => {
      const config = useConfig();
      return React.createElement(WrappedComponent, { ...props, ref, config });
    }
  ) as any) as C;
}
