import { createContext } from "react";

// 支持 webpack 注入
export const DEFAULT_CLASS_PREFIX =
  typeof TEA_CLASS_PREFIX !== "undefined" ? TEA_CLASS_PREFIX : "tea";
export const DEFAULT_LOCALE =
  typeof WEBPACK_BUILD_LOCALE !== "undefined" ? WEBPACK_BUILD_LOCALE : "zh";

export interface ConfigProps {
  /**
   * 组件类名前缀
   *
   * @default "tea"
   */
  classPrefix?: string;

  /**
   * 组件语言版本
   *
   * @default "zh"
   */
  locale?: "zh" | "en" | "ko" | "ja";
}

export const ConfigContext = createContext<ConfigProps>({
  classPrefix: DEFAULT_CLASS_PREFIX,
  locale: DEFAULT_LOCALE,
});
