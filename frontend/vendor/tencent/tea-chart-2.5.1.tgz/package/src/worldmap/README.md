# WorldMap 世界地图

目前地图只支持热力图

## 使用示例

通过颜色渐变将数据映射至国家

[Example: 基本使用](./_example/WorldMapExample.jsx)


## 组件属性

[Interface: WorldMapProps](./WorldMap.tsx)
