import React from "react";
import { BasicMapProps, BasicMap } from "../basicmap";

export interface WorldMapProps extends Omit<BasicMapProps, "mapType"> {}

export function WorldMap(props: WorldMapProps) {
  return <BasicMap mapType="world" {...props} />;
}
