import React, { Fragment, useRef, useEffect } from "react";
import { WorldMap } from "@tencent/tea-chart/lib/worldmap";

export default function WorldMapExample() {
  const chartRef = useRef(null);
  const data = [
    { type: "156", value: 291 },
    { type: "840", value: 302 },
    { type: "643", value: 82 },
    { type: "英国", value: 400 },
  ];

  useEffect(() => {
    if (chartRef.current) {
      chartRef.current.on("interaction.selected", data => {
        console.log(data);
      });
    }
  });

  return (
    <Fragment>
      <WorldMap
        language="zh"
        chartRef={ref => {
          chartRef.current = ref;
        }}
        interaction={["element-select"]}
        height={400}
        position="type*value"
        dataSource={data}
        scale={{
          value: {
            alias: "人数",
            domain: [0, 500],
          },
        }}
        color={["#EBF4FF", "#006eff"]}
      />
    </Fragment>
  );
}
