import React from "react";
import { Card, MetricsBoard } from "@tencent/tea-component";
import { SimpleLine } from "@tencent/tea-chart/lib/simpleline";

export default function SimpleBasicLineExample() {
  const dataCount = 100;
  const data1 = [];
  const data2 = [];
  const date = new Date();
  for (let i = 0; i < dataCount; i++) {
    data1.push({
      time: `${date.getHours()}:${date.getMinutes()}`,
      value: Math.floor(Math.random() * 100),
    });
    data2.push({
      time: `${date.getHours()}:${date.getMinutes()}`,
      value: Math.floor(Math.random() * 100),
    });
    const dateTime = date.getTime();
    date.setTime(dateTime + 60000);
  }

  return (
    <Card>
      <Card.Body title="指标视图">
        <MetricsBoard
          title="平均 CPU 负载"
          unit="%"
          value={33}
          infos={[
            <SimpleLine
              yAxis
              tooltip
              height={100}
              position="time*value"
              dataSource={data1}
            />,
          ]}
        />
        <MetricsBoard
          title="平均内存负载"
          unit="%"
          value={55}
          infos={[
            <SimpleLine
              yAxis
              tooltip
              height={100}
              position="time*value"
              dataSource={data2}
            />,
          ]}
        />
      </Card.Body>
    </Card>
  );
}
