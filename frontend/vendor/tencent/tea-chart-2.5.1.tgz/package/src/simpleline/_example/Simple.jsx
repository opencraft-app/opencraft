import React from "react";
import { Row, Col, Card, MetricsBoard } from "@tencent/tea-component";
import { SimpleLine } from "@tencent/tea-chart/lib/simpleline";

export default function SimpleBasicLineExample() {
  const data = [
    { time: "0:00", value: 10 },
    { time: "1:00", value: 20 },
    { time: "2:00", value: 50 },
    { time: "3:00", value: 60 },
    { time: "4:00", value: 20 },
    { time: "5:00", value: 72 },
    { time: "6:00", value: 98 },
    { time: "7:00", value: 60 },
    { time: "8:00", value: 70 },
    { time: "9:00", value: 58 },
    { time: "10:00", value: 22 },
    { time: "11:00", value: 68 },
    { time: "12:00", value: 83 },
  ];

  const dataCount = 30;
  const data1 = [];
  const date = new Date();
  for (let i = 0; i < dataCount; i++) {
    data1.push({
      time: `${date.getHours()}:${date.getMinutes()}`,
      value: Math.floor(Math.random() * 5000),
    });
    const dateTime = date.getTime();
    date.setTime(dateTime + 60000);
  }

  return (
    <Card>
      <Card.Body title="指标视图">
        <Row showSplitLine>
          <Col>
            <MetricsBoard
              title="平均 CPU 负载"
              unit="%"
              value={33}
              infos={[
                <SimpleLine
                  height={100}
                  position="time*value"
                  dataSource={data}
                />,
              ]}
            />
          </Col>
          <Col>
            <MetricsBoard
              title="平均内存负载"
              unit="%"
              value={55}
              infos={[
                <SimpleLine
                  height={100}
                  position="time*value"
                  dataSource={data1}
                />,
              ]}
            />
          </Col>
        </Row>
      </Card.Body>
    </Card>
  );
}
