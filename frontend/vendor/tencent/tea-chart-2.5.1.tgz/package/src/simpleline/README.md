# SimpleLine 极简折线

极简折线图，通常用于指标展示场景。

## 使用示例

可以结合统计面板，输出更有表现力的数据

[Example: 基本使用](./_example/Simple.jsx)

也可以显示 Y 轴

[Example: 基本使用](./_example/Tooltip.jsx)

## 组件属性

[Interface: SimpleLineProps](./SimpleLine.tsx)