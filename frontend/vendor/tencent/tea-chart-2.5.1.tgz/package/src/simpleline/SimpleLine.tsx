import React from "react";
import { Omit } from "../_type";
import { BasicLineProps, BasicLine } from "../basicline";

/**
 * SimpleLine 组件支持的属性。
 */
export interface SimpleLineProps
  extends Omit<
    BasicLineProps,
    "xAxis" | "color" | "scale" | "legend" | "yAxis" | "tooltip"
  > {
  /**
   *  Y 轴
   * @default false
   */
  yAxis?: boolean | BasicLineProps["yAxis"];

  /**
   * 提示框
   * @default false
   */
  tooltip?: BasicLineProps["tooltip"];
}

export function SimpleLine(props: SimpleLineProps) {
  const {
    height,
    width,
    dataSource,
    position,
    size = 3,
    tooltip = false,
    yAxis = false,
    tips,
    zoom,
    selection,
  } = props;

  return (
    <BasicLine
      zoom={zoom}
      selection={selection}
      xAxis={false}
      legend={false}
      height={height}
      width={width}
      dataSource={dataSource}
      position={position}
      size={size}
      tooltip={tooltip}
      yAxis={yAxis}
      theme={{ yAxis: { grindLineWidth: 0 } }}
      tips={tips}
    />
  );
}
