import { Theme } from "../type/theme";

/**
 * Tea Chart 的默认主题
 * @version 1.0.0
 */

export function getConfig(): Theme {
  return {
    classPrefix: "tea",
    height: 250,
    color: [
      "#2d70f6",
      "#6fd598",
      "#f6ca54",
      "#eb6455",
      "#8b4bd2",
      "#5dbdca",
      "#94d553",
      "#f1a03f",
      "#d34a83",
      "#6360de",
      "#71c860",
      "#af40b1",
    ],
    defaultColor: [
      "#2d70f6",
      "#6fd598",
      "#f6ca54",
      "#eb6455",
      "#8b4bd2",
      "#5dbdca",
      "#94d553",
      "#f1a03f",
      "#d34a83",
      "#6360de",
      "#71c860",
      "#af40b1",
    ],
    disabledColor: "#CECECE",
    backgroundColor: "#FFFFFF",
    padding: {
      left: 0,
      top: 20,
      bottom: 15,
      right: 5,
    },
    yAxis: {
      gridLineColor: "#ECECEC",
      majorGridLineColor: "#CECECE",
      tickLength: 6,
      tickColor: "#CECECE",
      labelColor: "#B0B0B0",
      labelFontSize: "12px",
      grindLineWidth: 1,
    },
    xAxis: {
      gridLineColor: "#ECECEC",
      majorGridLineColor: "#CECECE",
      tickLength: 6,
      tickColor: "#CECECE",
      labelColor: "#B0B0B0",
      labelFontSize: "12px",
      grindLineWidth: 0,
    },
    legend: {
      height: 20,
      rect: {
        width: 16,
        height: 5,
      },
      circle: {
        radius: 6,
      },
      square: {
        width: 10,
      },
      text: {
        fontSize: 12,
        color: "#2B2B2B",
        disabledColor: "#CECECE",
      },
    },
    interaction: {
      selected: {
        opacity: 0.3,
      },
    },
  };
}
