import EventEmitter from "eventemitter3";
import get from "lodash.get";
import set from "lodash.set";
import { Selection, select } from "d3";
import { Tea } from "./theme";
import {
  AxisOptions,
  LegendOptions,
  TooltipOptions,
  ScaleOptions,
  ConnectNullsOptions,
  InteractionOptions,
} from "./type/options";
import { Theme } from "./type/theme";
import { DataSource } from "./type/data";
import { deepMerge } from "./lib/deep-merge";

/**
 * 图表的配置信息
 */
export interface ContextOptions {
  /**
   * 坐标轴配置
   * @since 2.0
   * @todo 支持多 X 轴与多 Y 轴分开定义
   */
  axis: {
    xAxis: AxisOptions;
    yAxis: AxisOptions;
  };

  /**
   * 图例配置
   * @since 2.0
   */
  legend: LegendOptions;

  /**
   * 提示框配置
   * @since 2.0
   */
  tooltip: TooltipOptions;

  /**
   * 数据比例尺配置
   * @since 2.0
   */
  scale: {
    [key: string]: ScaleOptions;
  };

  /**
   * 连接空值的配置
   * @since 2.0
   */
  connectNulls: ConnectNullsOptions;

  /**
   * 交互事件
   *
   * @since 2.1.0
   */
  interaction: InteractionOptions;
}

/**
 * TeaChart 全局上下文
 * 其中 options 只能通过 getOption 和 setOption 来进行读取
 *
 * @extends eventemitter3
 */
export class Context extends EventEmitter {
  /**
   * Chart ID
   * @since 2.0
   */
  public id: string;

  /**
   * Tea Chart 主题配置
   * @since 2.0
   */
  public theme: Theme = Tea();

  /**
   * 默认的 class 前缀
   * @since 2.0
   */
  public classPrefix: string;

  /**
   * HTML 根元素
   * @since 2.0
   */
  public container: HTMLElement;

  /**
   * 图形区 SVG
   * @since 2.0
   */
  public root: Selection<SVGElement, {}, HTMLElement, {}>;

  /**
   * 图表背景
   * @since 2.0
   */
  public background: Selection<SVGGElement, {}, HTMLElement, {}>;

  /**
   * 绘图区（线，柱，饼等）背景
   * @since 2.0
   */
  public plotBackgound: Selection<SVGGElement, {}, HTMLElement, {}>;

  /**
   * 绘图区遮罩 Mask
   * @since 2.0
   */
  public plotMask: Selection<SVGRectElement, {}, HTMLElement, {}>;

  /**
   * 配置项
   * @since 2.0
   */
  public options: ContextOptions = {
    axis: {
      xAxis: {
        enable: true,
      },
      yAxis: {
        enable: true,
      },
    },
    legend: {
      enable: true,
      align: "bottom",
    },
    tooltip: {
      enable: true,
    },
    scale: {},
    connectNulls: {
      enable: true,
    },
    interaction: {},
  };

  /**
   * 原始数据
   * @since 2.0
   */
  public dataSource: DataSource;

  /**
   * 初始化 Context
   * @param container 根元素
   * @param customTheme 主题配置
   */
  public constructor(id: string, container: HTMLElement, customTheme?: Theme) {
    super();
    this.id = id;
    // 更新主题
    if (typeof customTheme === "object") {
      for (const key in customTheme) {
        if (Object.prototype.hasOwnProperty.call(customTheme, key)) {
          this.theme[key] = customTheme[key];
        }
      }
    }
    const { classPrefix, backgroundColor } = this.theme;
    this.container = container;
    this.classPrefix = classPrefix;

    // 创建 SVG 根节点
    this.root = select(this.container)
      .append("svg")
      .attr("class", `${classPrefix}-chart-root`)
      .attr("version", "1.1")
      .attr("xmlns", "http://www.w3.org/2000/svg")
      .attr("data-chart-id", id)
      .style("-webkit-user-select", "none")
      .style("-moz-user-select", "none")
      .style("-ms-user-select", "none")
      .style("user-select", "none");

    // 创建绘图区遮罩
    this.plotMask = this.root
      .append("defs")
      .append("clipPath")
      .attr("id", this.id)
      .append("rect")
      .attr("x", 0)
      .attr("y", 0)
      .attr("fill", "none");

    // 创建背景
    this.background = this.root
      .append("rect")
      .attr("class", `${classPrefix}-chart-background`)
      .attr("fill", backgroundColor);

    // 创建绘图区背景
    this.plotBackgound = this.root
      .append("rect")
      .attr("class", `${classPrefix}-chart-plot-background`)
      .attr("fill", "none");
  }

  /**
   * 获取配置信息
   * @param optionKey 获取配置信息的 key
   * @param defaultValue 默认值
   * @returns 返回配置的值
   *
   * @since 2.0
   */
  public getOption(optionKey: string, defaultValue?: any) {
    return get(this.options, optionKey, defaultValue);
  }

  /**
   * 设置配置信息
   * @param optionKey 待设置配置的 key
   * @param value 新的值
   *
   * @since 2.0
   */
  public setOption(optionKey: string, value: any) {
    const prev = this.getOption(optionKey);
    if (prev === undefined) {
      return set(this.options, optionKey, value);
    }
    return set(this.options, optionKey, deepMerge(prev, value));
  }

  /**
   * 设置主题配置
   * @param customTheme 用户自定义主题配置
   *
   * @since 2.0
   */
  public setTheme(customTheme: Theme) {
    deepMerge(this.theme, customTheme);
  }

  /**
   * 更新原始数据
   * @param dataSource 原始数据
   */
  public setDataSource(dataSource: DataSource) {
    this.dataSource = dataSource;
  }

  /**
   * 获取图表宽度
   * @since 2.1.0
   */
  public getBackgroundWidth() {
    return parseInt(this.root.attr("width"), 10);
  }

  /**
   * 获取图表高度
   */
  public getBackgroundHeight() {
    return parseInt(this.root.attr("height"), 10);
  }

  /**
   * 获取绘图层宽度
   * @since 2.1.0
   */
  public getPlotWidth() {
    return parseInt(this.plotBackgound.attr("width"), 10);
  }

  /**
   * 获取绘图层高度
   */
  public getPlotHeight() {
    return parseInt(this.plotBackgound.attr("height"), 10);
  }
}
