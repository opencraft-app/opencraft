import { isDeepEqual, isArrayDeepEqual } from "../is-equal";

test("isDeepEqual", () => {
  expect(isDeepEqual(null, null)).toBe(true);
  expect(
    isDeepEqual(
      () => {},
      () => {}
    )
  ).toBe(true);
  expect(isDeepEqual(/test/, /test/)).toBe(true);
  expect(isDeepEqual(10, 10)).toBe(true);
  expect(isDeepEqual([10], [10, 11])).toBe(false);
  expect(isDeepEqual(new Date(), Number())).toBe(false);
  expect(isDeepEqual(new Date(), new Date())).toBe(true);
  expect(isDeepEqual({ a: 1 }, { a: 1 })).toBe(true);
  expect(isDeepEqual({ a: [1] }, { a: [1] })).toBe(true);
  expect(isDeepEqual({ a: 1 }, { a: 2 })).toBe(false);
  expect(isDeepEqual("a", {})).toBe(false);
  expect(isDeepEqual({ a: { b: 1 } }, { a: { b: 1 } })).toBe(true);
});

test("isArrayDeepEqual", () => {
  expect(isArrayDeepEqual([], [])).toBe(true);
  expect(isArrayDeepEqual(null, [])).toBe(false);
  expect(isArrayDeepEqual([1], [2, 3])).toBe(false);
  expect(isArrayDeepEqual([{ a: 1 }], [{ a: 1 }])).toBe(true);
  expect(isArrayDeepEqual([{ a: 1 }], [{ a: 2 }])).toBe(false);
});
