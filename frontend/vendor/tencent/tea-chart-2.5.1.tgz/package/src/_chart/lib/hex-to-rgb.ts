export function hexToRGB(hex: string, alpha: number = 1) {
  const colorString = hex.startsWith("#") ? hex.slice(1) : hex;
  const red = colorString.slice(0, 2);
  const green = colorString.slice(2, 4);
  const blue = colorString.slice(4, 6);
  return `rgba(${parseInt(`0x${red}`, 16)}, ${parseInt(
    `0x${green}`,
    16
  )}, ${parseInt(`0x${blue}`, 16)}, ${alpha})`;
}
