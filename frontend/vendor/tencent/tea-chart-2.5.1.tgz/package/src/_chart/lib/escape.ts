import { filterXSS, escapeAttrValue } from "xss";

export function escapeHTML(content: string) {
  return filterXSS(content, {
    onIgnoreTagAttr: (tag, name, value) => {
      if (name === "style" || name === "class") {
        return `${name}="${escapeAttrValue(value)}"`;
      }
      if (tag === "a" && name === "href") {
        return `href="${escapeAttrValue(value)}"`;
      }
      return undefined;
    },
  });
}
