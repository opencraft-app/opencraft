export function isDeepEqual(x: any, y: any) {
  if (x === null || x === undefined || y === null || y === undefined) {
    return x === y;
  }
  // after this just checking type of one would be enough
  if (x.constructor !== y.constructor) {
    return false;
  }
  // if they are functions, they should exactly refer to same one (because of closures)
  if (x instanceof Function) {
    return x.toString() === y.toString();
  }
  // if they are regexps, they should exactly refer to same one (it is hard to better equality check on current ES)
  if (x instanceof RegExp) {
    return x.toString() === y.toString();
  }
  if (x === y || x.valueOf() === y.valueOf()) {
    return true;
  }

  if (Array.isArray(x) && x.length !== y.length) {
    return isArrayDeepEqual(x, y);
  }

  // if they are dates, they must had equal valueOf
  if (x instanceof Date) {
    return false;
  }

  // if they are strictly equal, they both need to be object at least
  if (!(x instanceof Object)) {
    return false;
  }
  if (!(y instanceof Object)) {
    return false;
  }

  // recursive object equality check
  const p = Object.keys(x);
  return (
    Object.keys(y).every(i => {
      return p.indexOf(i) !== -1;
    }) &&
    p.every(i => {
      if (Array.isArray(x[i]) && Array.isArray(y[i])) {
        return isArrayDeepEqual(x[i], y[i]);
      }
      return isDeepEqual(x[i], y[i]);
    })
  );
}

export function isArrayDeepEqual(x: any[], y: any[]) {
  if (!Array.isArray(x) || !Array.isArray(y)) {
    return false;
  }

  if (x.length !== y.length) {
    return false;
  }

  for (let i = 0; i < x.length; i++) {
    if (!isDeepEqual(x[i], y[i])) {
      return false;
    }
  }

  return true;
}
