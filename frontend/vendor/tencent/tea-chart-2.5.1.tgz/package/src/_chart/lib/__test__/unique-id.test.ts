import { uniqueId } from "../unique-id";

test("uniqueId", () => {
  expect(uniqueId()).toBe("g1");
  expect(uniqueId()).toBe("g2");
  expect(uniqueId("pre")).toBe("pre1");
  expect(uniqueId("pre")).toBe("pre2");
});
