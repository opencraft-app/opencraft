export function deepMerge(destination: any, ...sources: any[]) {
  for (const source of sources) {
    singleMerge(destination, source);
  }
  return destination;
}

function singleMerge(
  destination: any = {},
  source: any = {},
  arrayMerge = false
) {
  for (const key in source) {
    if (Object.prototype.hasOwnProperty.call(source, key)) {
      const dest = destination[key];
      const src = source[key];
      if (Array.isArray(dest)) {
        if (Array.isArray(src)) {
          destination[key] = arrayMerge ? dest.concat(src) : src;
        } else {
          // 如果目的值是数组，而新的数据为非数组，则使用新数据
          destination[key] = src;
        }
      } else if (destination === null) {
        destination[key] = src;
      } else if (typeof dest === "object") {
        singleMerge(destination[key], src);
      } else {
        destination[key] = src;
      }
    }
  }
}
