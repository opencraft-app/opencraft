import { isDeepEqual } from "./is-equal";

// 浅比对的 key
const ignoreKeys = ["dataSource", "chartRef", "tips"];

export function comparePropsEqual(
  prev: any,
  next: any,
  compareKeys?: string[]
) {
  const keys = compareKeys || Object.keys(prev).concat(Object.keys(next));
  for (const key of keys) {
    if (!ignoreKeys.includes(key)) {
      if (!isDeepEqual(prev[key], next[key])) {
        return false;
      }
    }
    if (prev[key] !== next[key]) return false;
  }
  return true;
}
