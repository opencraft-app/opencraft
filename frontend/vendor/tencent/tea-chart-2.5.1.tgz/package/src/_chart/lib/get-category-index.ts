import { ScalePoint, ScaleBand, range as d3Range, bisectRight } from "d3";

/**
 * 通过 X 坐标获取对应的分类索引
 * @param x x 坐标
 * @param scale 分类比例尺
 * @param scaleType 分类比例尺类型
 */
export function getCategoryIndex(
  x: number,
  scale: ScalePoint<string> | ScaleBand<string>,
  scaleType: "Point" | "Band" = "Point"
) {
  let index: number;
  const domain = scale.domain();
  if (scaleType === "Point") {
    const range = scale.range();
    const rangePoints = d3Range(range[0], range[1], scale.step()); // 得到每个数据点 X 值
    // 有时候 range[1] 刚好和 scale.step() 相同，则只会出现一个点
    if (rangePoints.length === 1 && domain.length > 1) {
      rangePoints.push(range[1]);
    }
    // 如果只有一个数据点的情况下，默认 index 为 0
    if (rangePoints.length === 1) {
      index = 0;
    } else {
      index = bisectRight(rangePoints, x);
      // 计算更接近的数据点
      if (
        Math.abs((rangePoints[index] || range[1]) - x) >
        Math.abs(rangePoints[index - 1] - x)
      ) {
        index -= 1;
      }
    }
  } else {
    const offset = scale(domain[0]);
    index = Math.abs(Math.floor((x - offset) / scale.step()));
  }

  return index;
}
