import { BaseType, select, Selection } from "d3";

export function getLabelMaxWidth(nodes: BaseType[]) {
  let max = 0;
  for (const node of nodes) {
    if (node) {
      const { width } = (node as SVGElement).getBoundingClientRect();
      if (max < width) max = width;
    }
  }
  return Math.round(max);
}

export function getLabelMinWidth(nodes: BaseType[]) {
  let min = 0;
  for (const node of nodes) {
    if (node) {
      const { width } = (node as SVGElement).getBoundingClientRect();
      if (min > width) min = width;
    }
  }
  return Math.floor(min);
}

export function getLabelMaxHeight(nodes: BaseType[]) {
  let max = 0;
  for (const node of nodes) {
    if (node) {
      const { height } = (node as SVGElement).getBoundingClientRect();
      if (max < height) max = height;
    }
  }
  return Math.round(max);
}

export function nodeWidth(node: SVGGraphicsElement) {
  // firefox 环境下 getBBox 方法会报错
  try {
    return node.getBBox().width;
  } catch (e) {
    return 0;
  }
}

export function nodeHeight(node: SVGGraphicsElement) {
  // firefox 环境下 getBBox 方法会报错
  try {
    return node.getBBox().height;
  } catch (e) {
    return 0;
  }
}

export function textSize(text: string, style?: string) {
  const t = select("body").append("span");
  const textNode: HTMLElement = t
    .text(text)
    .attr("style", style)
    .node();
  if (textNode) {
    const { width, height } = textNode.getBoundingClientRect();
    t.remove();
    return { width: Math.round(width), height: Math.round(height) };
  }
  return { width: 0, height: 0 };
}

export function textWrap(
  text: Selection<SVGElement, {}, BaseType, {}>,
  invert: boolean,
  barWidth: number
) {
  text.each(function wrap(data: any) {
    const width = invert ? data.metric : barWidth;
    const text = select(this);
    const words = text
      .text()
      .split("")
      .reverse();

    let word = words.pop();
    let line = [];
    let lineNumber = 0;
    const lineHeight = 1.3; // ems
    const y = text.attr("y");

    let wrapTSpan = text
      .text(null)
      .append("tspan")
      .attr("x", 0)
      .attr("y", y)
      .attr("fill", "#fff")
      .attr("stroke", "#fff")
      .attr("stroke-width", "2px")
      .attr("stroke-linejoin", "round");

    let tspan = text
      .append("tspan")
      .attr("x", 0)
      .attr("y", y);

    while (word) {
      if (word === "\n") {
        lineNumber += 1;
        line = [];
        tspan = text
          .append("tspan")
          .attr("x", 0)
          .attr("y", y)
          .attr("dy", `${lineNumber * lineHeight}em`)
          .text("");
      } else {
        line.push(word);
        tspan.text(line.join(""));
        wrapTSpan.text(line.join(""));

        const node = tspan.node();
        const nodeExist = document.body.contains(node);

        if (nodeExist && node.getComputedTextLength() > width) {
          lineNumber += 1;
          line.pop();
          tspan.text(line.join(""));
          line = [word];

          wrapTSpan = text
            .append("tspan")
            .attr("x", 0)
            .attr("y", y)
            .attr("dy", `${lineNumber * lineHeight}em`)
            .attr("fill", "#fff")
            .attr("stroke", "#fff")
            .attr("stroke-width", "2px")
            .attr("stroke-linejoin", "round")
            .text(word);

          tspan = text
            .append("tspan")
            .attr("x", 0)
            .attr("y", y)
            .attr("dy", `${lineNumber * lineHeight}em`)
            .text(word);
        }
      }
      word = words.pop();
    }
  });
}

export function findTextColor(colorValue: string) {
  // #123456或者rgb(12,34,56)转为rgb数组[12,34,56]
  const reg = /^#([0-9a-fA-f]{3}|[0-9a-fA-f]{6})$/;
  const that = colorValue;
  if (/^(rgb|RGB)/.test(that)) {
    // 处理rgb转为数组
    const aColor = that
      .replace(/(?:\(|\)|rgb|RGB)*/g, "")
      .split(",")
      .map(i => Number(i));
    return resBgColor(aColor);
  }
  if (reg.test(that)) {
    // 处理十六进制色值
    let sColor = colorValue.toLowerCase();
    if (sColor && reg.test(sColor)) {
      if (sColor.length === 4) {
        let sColorNew = "#";
        for (let i = 1; i < 4; i += 1) {
          sColorNew += sColor.slice(i, i + 1).concat(sColor.slice(i, i + 1));
        }
        sColor = sColorNew;
      }
      // 处理六位的颜色值
      const sColorChange = [];
      for (let i = 1; i < 7; i += 2) {
        sColorChange.push(parseInt(`0x${sColor.slice(i, i + 2)}`, 16));
      }
      return resBgColor(sColorChange);
    }
    return false;
  }
  return false;
}

/**
 * 转换字体颜色
 *
 * @param {array} rgbArr rgb数组
 */
export function resBgColor(rgbArr: number[]) {
  // 当color值大于128时,color值偏向255,即#ffffff,此时字体颜色应为#000000
  // 当color值小于128时,color值偏向0,即#000000,此时字体颜色应为#ffffff
  const color =
    0.213 * rgbArr[0] + 0.715 * rgbArr[1] + 0.072 * rgbArr[2] > 255 / 2;
  return color ? "#000000" : "#ffffff";
}
