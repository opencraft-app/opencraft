import { Coordinate } from "./coordinate";
import { LegendOptions } from "../type/options";

/**
 * 极坐标系
 * @since 2.0
 *
 * @todo 支持多轴
 */
export class PolarCoordinate extends Coordinate {
  /**
   * 坐标轴的高度
   * @since 2.0
   */
  public height: number;

  /**
   * 坐标轴宽度
   * @since 2.0
   */
  public width: number;

  public draw() {
    const { left, top } = this.ctx.theme.padding;
    const { align } = this.ctx.getOption("legend") as LegendOptions;

    const backgroundHeight = parseInt(this.ctx.background.attr("height"), 10);
    this.width = parseInt(this.ctx.background.attr("width"), 10);
    // 24 = x轴标签高度（font-size） + 10
    this.height = backgroundHeight;

    if (align === "bottom") {
      this.height -= this.helpers.legend.height + 20;
    } else if (align === "right") {
      this.width -= this.helpers.legend.width + 20;
    }

    // 更新绘图区背景
    this.ctx.plotBackgound
      .attr("x", 0)
      .attr("y", 0)
      .attr("height", this.height)
      .attr("width", this.width);

    this.ctx.plotMask
      .attr("x", left - 5)
      .attr("y", top - 5)
      .attr("height", this.height + 5)
      .attr("width", this.width + 10);
  }
}
