/* eslint-disable no-unused-expressions */
import {
  Selection,
  ScalePoint,
  ScaleBand,
  ScaleLinear,
  select,
  format as d3Format,
  event,
} from "d3";
import {
  Coordinate,
  CategoryScale,
  ValueScale,
  CategoryScaleType,
} from "./coordinate";
import { Context } from "../context";
import { Helpers } from "../type/helpers";
import {
  nodeWidth,
  getLabelMaxWidth,
  textSize,
  nodeHeight,
} from "../lib/svg-helper";
import { LegendOptions, AxisOptions } from "../type/options";
import { getCategoryIndex } from "../lib/get-category-index";

// 轴线与字体间距
const TEXT_GAP = 12;

/**
 * 直角坐标系
 * @since 2.0
 *
 * @todo 支持多轴
 */
export class RectCoordinate extends Coordinate {
  /**
   * X 轴栅格
   * @since 2.0
   */
  public xAxisGrid: Selection<SVGGElement, {}, HTMLElement, {}>;

  /**
   * Y 轴栅格
   * @since 2.0
   */
  public yAxisGrid: Selection<SVGGElement, {}, HTMLElement, {}>;

  /**
   * X 轴坐标轴刻度
   * @since 2.0
   */
  public xAxis: Selection<SVGGElement, {}, HTMLElement, {}>;

  /**
   * Y 轴坐标轴刻度
   * @since 2.0
   */
  public yAxis: Selection<SVGGElement, {}, HTMLElement, {}>;

  /**
   * X 轴标签
   * @since 2.0
   */
  public xAxisLabels: Selection<SVGGElement, {}, HTMLElement, {}>;

  /**
   * Y 轴标签
   * @since 2.0
   */
  public yAxisLabels: Selection<SVGGElement, {}, HTMLElement, {}>;

  /**
   * X 轴标题
   * @since 2.3
   */
  public xAxisTitle: Selection<SVGTextElement, {}, HTMLElement, {}>;

  /**
   * X 轴标题
   * @since 2.3
   */
  public yAxisTitle: Selection<SVGTextElement, {}, HTMLElement, {}>;

  /**
   * 重置缩放按钮
   */
  public zoomResetButton: Selection<SVGGElement, {}, HTMLElement, {}>;

  /**
   * 分类轴比例尺
   * @since 2.0
   * @todo 未来支持多个
   */
  private categoryScale: CategoryScale;

  /**
   * 分类轴数据比例尺类型
   * @since 2.0
   */
  private categoryScaleType: CategoryScaleType = "Point";

  /**
   * 数据轴比例尺
   * @since 2.0
   * @todo 未来支持多个
   */
  private valueScale: ValueScale;

  /**
   * 是否为反转坐标轴
   * @since 2.0
   */
  private invert: boolean;

  /**
   * X 轴的高度，根据是不是显示来控制
   * @since 2.0
   */
  private xAxisHeight: number = 24;

  /**
   * 坐标轴的高度
   * @since 2.0
   */
  public height: number;

  /**
   * 坐标轴宽度
   * @since 2.0
   */
  public width: number;

  public constructor(ctx: Context, helpers: Helpers) {
    super(ctx, helpers);
    const { root, classPrefix } = this.ctx;

    this.xAxisGrid = root
      .append("g")
      .attr(
        "class",
        `${classPrefix}-chart-axis ${classPrefix}-chart-xaxis-grid`
      )
      .attr("data-z-index", "1");

    this.yAxisGrid = root
      .append("g")
      .attr(
        "class",
        `${classPrefix}-chart-axis ${classPrefix}-chart-yaxis-grid`
      )
      .attr("data-z-index", "1");

    this.xAxis = root
      .append("g")
      .attr("class", `${classPrefix}-chart-axis ${classPrefix}-chart-xaxis`)
      .attr("data-z-index", "2");

    this.yAxis = root
      .append("g")
      .attr("class", `${classPrefix}-chart-axis ${classPrefix}-chart-yaxis`)
      .attr("data-z-index", "2");

    this.xAxisLabels = root
      .append("g")
      .attr(
        "class",
        `${classPrefix}-chart-axis-labels ${classPrefix}-chart-xaxis-labels`
      )
      .attr("data-z-index", "7");

    this.yAxisLabels = root
      .append("g")
      .attr(
        "class",
        `${classPrefix}-chart-axis-labels ${classPrefix}-chart-yaxis-labels`
      )
      .attr("data-z-index", "7");

    this.xAxisTitle = this.xAxis
      .append("text")
      .attr("class", `${classPrefix}-axis-title`)
      .attr("data-z-index", 7)
      .attr("text-anchor", "middle")
      .attr("transform", "translate(0,0)");

    this.yAxisTitle = this.yAxis
      .append("text")
      .attr("class", `${classPrefix}-axis-title`)
      .attr("data-z-index", 7)
      .attr("text-anchor", "middle");

    // 监听选择事件，处理缩放事件
    this.ctx.on("selection.end", this.onZoomEvents, this);
  }

  /**
   * 绘制坐标轴
   * @param valueScale 数据比例尺
   * @param categroryScale 分类比例尺
   * @param categoryScaleType 分类比例尺类型
   * @param invert 是否为坐标轴反转
   *
   * @since 2.0
   */
  public draw(
    valueScale: ScaleLinear<number, number>,
    categroryScale: ScalePoint<string> | [ScaleBand<string>, ScaleBand<string>],
    categoryScaleType: CategoryScaleType,
    invert: boolean
  ) {
    const xAxisEnable = this.ctx.getOption("axis.xAxis.enable");
    const yAxisEnable = this.ctx.getOption("axis.yAxis.enable");
    const { align } = this.ctx.getOption("legend") as LegendOptions;
    const {
      padding: { right, top, bottom, left },
    } = this.ctx.theme;
    this.categoryScale = categroryScale;
    this.valueScale = valueScale;
    this.categoryScaleType = categoryScaleType;
    this.invert = invert;
    this.xAxisHeight = xAxisEnable ? 24 : 0;

    // 更新整个坐标轴的高度和宽度
    this.width = parseInt(this.ctx.background.attr("width"), 10) - left - right;
    this.height =
      parseInt(this.ctx.background.attr("height"), 10) - bottom - top;

    if (align === "bottom") {
      this.height -= this.helpers.legend.height;
    } else if (align === "right") {
      this.width -= this.helpers.legend.width;
    }

    // 清除所有的栅格线和标签
    this.clearGrid();
    this.clearLabels();

    // 绘制标题
    this.drawTitles();

    // 绘制 Y 轴
    this.drawYAxis();

    const yAxisLabelWidth = yAxisEnable
      ? Math.round(nodeWidth(this.yAxisLabels.node())) + 14
      : 6;

    this.drawXAxis(yAxisLabelWidth);

    // 更新绘图区背景
    this.ctx.plotBackgound
      .attr("x", yAxisLabelWidth + left)
      .attr("y", top)
      .attr("height", Math.abs(this.height - this.xAxisHeight))
      .attr("width", Math.abs(this.width - yAxisLabelWidth));
    // 更新遮罩
    this.ctx.plotMask
      .attr("x", left + yAxisLabelWidth - 5)
      .attr("y", top - 5)
      .attr("height", Math.abs(this.height - this.xAxisHeight + 5))
      .attr("width", Math.abs(this.width - yAxisLabelWidth + 10));
  }

  /**
   * 绘制 Y 轴
   * @since 2.0
   * @todo 轴标题
   */
  private drawYAxis() {
    const {
      classPrefix,
      theme,
      theme: {
        padding: { top },
      },
    } = this.ctx;
    const xAxisEnable = this.ctx.getOption("axis.xAxis.enable", true);
    const yAxisOptions: AxisOptions = this.ctx.getOption("axis.yAxis", {});
    const yScale = this.invert ? this.categoryScale[0] : this.valueScale;
    yScale.range([this.height + top - this.xAxisHeight, top]);

    // 修改左边距包含标题
    const titleHeight = nodeHeight(this.yAxisTitle.node());
    const fixTheme = Object.assign({}, theme);
    fixTheme.padding = Object.assign({}, theme.padding);
    fixTheme.padding.left =
      theme.padding.left + titleHeight > 0 ? titleHeight + 6 : 0;

    if (!yAxisOptions.enable) return;

    if (this.invert) {
      if (this.categoryScaleType === "Band") {
        this.categoryScale[1].range([0, yScale.bandwidth()]);
      }
      drawCategoryAxis(
        this.yAxisGrid,
        this.yAxisLabels,
        yScale,
        this.categoryScaleType,
        this.height - this.xAxisHeight,
        this.width,
        true,
        classPrefix,
        fixTheme,
        yAxisOptions
      );
    } else {
      drawValueAxis(
        this.yAxisGrid,
        this.yAxisLabels,
        yScale,
        this.height - this.xAxisHeight,
        this.width,
        false,
        classPrefix,
        fixTheme,
        yAxisOptions,
        !xAxisEnable
      );
    }
  }

  /**
   * 绘制 X 轴
   * @since 2.0
   */
  private drawXAxis(yAxisLabelWidth: number) {
    const {
      classPrefix,
      theme,
      theme: {
        padding: { left },
      },
    } = this.ctx;
    const xAixsOptions: AxisOptions = this.ctx.getOption("axis.xAxis");
    const leftEdge = yAxisLabelWidth + left;
    const rightEdge = this.width + left;
    if (this.invert) {
      this.valueScale.range([leftEdge, rightEdge]);

      if (!xAixsOptions.enable) return;

      drawValueAxis(
        this.xAxisGrid,
        this.xAxisLabels,
        this.valueScale,
        this.height - this.xAxisHeight,
        this.width,
        true,
        classPrefix,
        theme,
        xAixsOptions
      );
    } else {
      let axisScale;
      if (this.categoryScaleType === "Point") {
        axisScale = (this.categoryScale as ScalePoint<string>).range([
          leftEdge,
          rightEdge,
        ]);
      } else {
        axisScale = this.categoryScale[0].range([leftEdge, rightEdge]);
        this.categoryScale[1].range([0, axisScale.bandwidth()]);
      }

      if (!xAixsOptions.enable) return;

      drawCategoryAxis(
        this.xAxisGrid,
        this.xAxisLabels,
        axisScale,
        this.categoryScaleType,
        this.height - this.xAxisHeight,
        this.width,
        false,
        classPrefix,
        theme,
        xAixsOptions
      );
    }
  }

  /**
   * 处理缩放
   * @param start 选择区域的起始点 X 坐标
   * @param end 选择区域的终点 X 坐标
   */
  private onZoomEvents(start: number, end: number) {
    const enable = this.ctx.getOption("interaction.zoom");
    if (enable) {
      const xScale =
        this.categoryScaleType === "Point"
          ? this.categoryScale
          : this.categoryScale[0];
      const domain: string[] = xScale.domain();

      const startIndex = getCategoryIndex(
        start,
        xScale,
        this.categoryScaleType
      );
      const endIndex = getCategoryIndex(end, xScale, this.categoryScaleType);

      const range = domain.slice(startIndex, endIndex + 1);
      this.ctx.emit("coord.zoom.zooming", range, start, end);
      this.ctx.emit("zoom.end", range[0], range[range.length - 1]);
      if (!this.zoomResetButton) {
        this.drawZoomResetButton();
      }
    }
  }

  /**
   * 绘制缩放重置的按钮
   *
   * @since 2.0
   */
  private drawZoomResetButton() {
    const bgWidth = parseInt(this.ctx.background.attr("width"), 10);
    const { root, classPrefix } = this.ctx;
    const resetText = this.ctx.getOption("interaction.zoom.resetText", "");

    this.zoomResetButton = root
      .append("g")
      .attr(
        "class",
        `${classPrefix}-chart-button ${classPrefix}-chart-reset-zoom`
      )
      .attr("data-z-index", "6")
      .attr("transform", `translate(${bgWidth - 84}, 10)`)
      .on("click", () => {
        event && event.preventDefault();
        event && event.stopPropagation();
        this.ctx.emit("coord.zoom.reset");
        this.zoomResetButton.remove();
        this.zoomResetButton = null;
      });

    this.zoomResetButton
      .append("rect")
      .attr("class", `${classPrefix}-chart-button-box`)
      .attr("fill", "#f2f2f2")
      .attr("stroke-width", 1)
      .attr("stroke", "#dddddd")
      .attr("height", 30)
      .attr("style", "cursor:pointer;");

    this.zoomResetButton
      .append("text")
      .attr("data-z-index", 1)
      .attr(
        "style",
        "font-weight:normal;cursor:pointer;color:#000000;fill:#000000;font-size: 12px"
      )
      .attr("x", 8)
      .attr("y", 20)
      .append("tspan")
      .text(resetText);

    const textWidth = getLabelMaxWidth(
      this.zoomResetButton.selectAll("text").nodes()
    );

    this.zoomResetButton.select("rect").attr("width", textWidth + 16);
  }

  private clearGrid() {
    const { classPrefix } = this.ctx;
    this.xAxisGrid.selectAll(`.${classPrefix}-chart-tick`).remove();
    this.xAxisGrid.selectAll(`.${classPrefix}-chart-grid-line`).remove();
    this.yAxisGrid.selectAll(`.${classPrefix}-chart-tick`).remove();
    this.yAxisGrid.selectAll(`.${classPrefix}-chart-grid-line`).remove();
  }

  private clearLabels() {
    this.xAxisLabels.selectAll("text").remove();
    this.yAxisLabels.selectAll("text").remove();
  }

  private drawTitles() {
    const xAixsOptions: AxisOptions = this.ctx.getOption("axis.xAxis");
    const yAixsOptions: AxisOptions = this.ctx.getOption("axis.yAxis");
    const {
      padding: { left },
    } = this.ctx.theme;

    this.xAxisTitle.selectAll("tspan").remove();
    this.yAxisTitle.selectAll("tspan").remove();

    if (xAixsOptions.title && xAixsOptions.title.text) {
      const size = textSize(xAixsOptions.title.text);
      drawAxisTitle(
        this.xAxisTitle,
        xAixsOptions.title.text,
        xAixsOptions.title.style,
        (this.width + left) / 2,
        this.height + this.xAxisHeight - size.height / 2
      );
      this.height -= this.helpers.legend.height;
    }

    if (yAixsOptions.title && yAixsOptions.title.text) {
      const size = textSize(yAixsOptions.title.text);
      drawAxisTitle(
        this.yAxisTitle,
        yAixsOptions.title.text,
        yAixsOptions.title.style,
        left + size.height,
        (this.height - size.height) / 2,
        true
      );
      this.height -= nodeHeight(this.xAxisTitle.node());
    }
  }
}

/**
 * 绘制分类轴
 *
 * @since 2.0
 *
 * @param grid 轴的栅格线对象
 * @param labels 轴的标签对象
 * @param scale 轴的比例尺
 * @param scaleType 轴类型，Band 或者 Point
 * @param height 坐标轴的高度
 * @param width 坐标轴的宽度
 * @param vertical 是否是垂直方向
 * @param classPrefix 样式类前缀
 * @param theme 主题
 * @param options 轴选项
 */
function drawCategoryAxis(
  grid: Selection<SVGGElement, {}, HTMLElement, {}>,
  labels: Selection<SVGGElement, {}, HTMLElement, {}>,
  scale: ScalePoint<string> | ScaleBand<string>,
  scaleType: "Band" | "Point",
  height: number,
  width: number,
  vertical: boolean = false,
  classPrefix: string,
  theme: Context["theme"],
  options: AxisOptions
) {
  const {
    xAxis: { tickColor, tickLength, labelColor, labelFontSize },
    padding: { left, top, right },
  } = theme;
  const offset = 14; // Y 轴标签右边距
  let maxLabelWidth = 0;
  let maxLabelHeight = 0;
  let texts = scale.domain().map((v, i) => {
    const { axisLabel = {} } = options;
    const text = axisLabel.formatter
      ? axisLabel.formatter(String(v), i, v)
      : String(v);
    // 顺便计算文本最大宽度与高度
    const { width, height: textHeight } = textSize(text);
    const textWidth = width + offset;
    maxLabelWidth = textWidth > maxLabelWidth ? textWidth : maxLabelWidth;
    maxLabelHeight = textHeight > maxLabelHeight ? textHeight : maxLabelHeight;

    const position =
      scaleType === "Point" ? scale(v) : scale(v) + scale.bandwidth() / 2;

    return {
      text,
      position,
      height: textHeight,
      width: textWidth,
    };
  });
  const { axisTick = {} } = options;
  const { interval } = axisTick;

  // 上一个标签文本的末端位置
  let lastLabelEndPos = 0;

  texts = texts.filter(
    ({ position, height: textHeight, width: textWidth }, i) => {
      if (interval) return i % interval === 0;

      const offset = vertical ? textHeight : textWidth;
      if (vertical) {
        if (i === 0 || position + offset < lastLabelEndPos) {
          lastLabelEndPos = position - offset / 2;
          return true;
        }
      } else if (i === 0 || position - offset > lastLabelEndPos) {
        lastLabelEndPos = position + offset / 2;
        return true;
      }
      return false;
    }
  );

  const textNodes = labels
    .selectAll("text")
    .data(texts)
    .join("text")
    .attr("font-size", labelFontSize)
    .attr("fill", labelColor)
    .attr("text-anchor", () => {
      if (vertical) return "end";
      return "middle";
    })
    .attr("transform", "translate(0,0)")
    .attr("opacity", 1)
    .text(v => v.text);

  textNodes
    .attr("x", function getX({ position: x }, i) {
      if (vertical) return maxLabelWidth + left - offset;

      // 如果文本超出边界需要重定位
      const textWidth = nodeWidth(select(this).node() as SVGGraphicsElement);
      if (i === 0) {
        if (x - textWidth / 2 < 0) return left + textWidth / 2 + 10;
      } else if (i === texts.length - 1) {
        if (x + textWidth / 2 > width + right) return x - textWidth / 2;
      }

      return x;
    })
    .attr("y", ({ position: y }) => {
      if (vertical) {
        return y + maxLabelHeight / 4;
      }
      return height + tickLength + offset + top;
    });

  grid
    .selectAll(`.${classPrefix}-chart-tick`)
    .data(texts)
    .join("path")
    .attr("fill", "none")
    .attr("class", `${classPrefix}-chart-tick`)
    .attr("stroke", tickColor)
    .attr("stroke-width", 1)
    .attr("d", ({ position }) => {
      if (vertical) {
        return `M ${maxLabelWidth + left} ${position} L ${maxLabelWidth +
          left -
          tickLength} ${position}`;
      }
      return `M ${position} ${height + top} L ${position} ${height +
        tickLength +
        top}`;
    });
}

/**
 * 绘制值轴
 *
 * @since 2.0
 *
 * @param grid 轴的栅格线对象
 * @param labels 轴的标签对象
 * @param scale 轴的比例尺
 * @param height 坐标轴的高度
 * @param width 坐标轴的宽度
 * @param vertical 是否是垂直方向
 * @param classPrefix 样式类前缀
 * @param theme 主题
 * @param options 轴选项
 * @param showFirstLabel 是否显示第一个标签
 */
function drawValueAxis(
  grid: Selection<SVGGElement, {}, HTMLElement, {}>,
  labels: Selection<SVGGElement, {}, HTMLElement, {}>,
  scale: ValueScale,
  height: number,
  width: number,
  vertical: boolean = false,
  classPrefix: string,
  theme: Context["theme"],
  options: AxisOptions,
  showFirstLabel: boolean = false
) {
  const {
    padding: { left, top },
    yAxis: {
      labelColor,
      labelFontSize,
      majorGridLineColor,
      gridLineColor,
      grindLineWidth,
    },
  } = theme;
  const { axisTick = {} } = options;
  const { interval } = axisTick;
  let maxLabelSize = 0; // 轴标签文本的最大尺寸，垂直轴时为宽度，水平轴时为高度

  // 计算最大尺寸
  const ticks = scale
    .domain()
    // 格式化
    .map((v, i) => {
      const { axisLabel = {} } = options;
      const label = d3Format(",")(v);
      const text = axisLabel.formatter
        ? axisLabel.formatter(label, i, v)
        : label;
      const { width: textWidth, height: textHeight } = textSize(text);
      const size = vertical ? textWidth : textHeight;
      if (size + TEXT_GAP > maxLabelSize) maxLabelSize = size + TEXT_GAP;
      return text;
    });

  let filteredTicks = [];
  if (interval !== undefined) {
    filteredTicks = ticks.filter((_, i) => {
      if (i === 0 || i === ticks.length - 1) return true;
      return i % interval === 0;
    });
  } else {
    let ticksLen = vertical
      ? Math.floor(width / maxLabelSize)
      : Math.floor(height / maxLabelSize);
    if (ticksLen > 5) {
      ticksLen = 5;
    } else if (ticksLen < 1) {
      ticksLen = 1;
    }
    filteredTicks = scale.nice(ticksLen).ticks(ticksLen);
  }

  grid
    .selectAll(`.${classPrefix}-chart-grid-line`)
    .data(filteredTicks)
    .join("path")
    .attr("class", `${classPrefix}-chart-grid-line`)
    .attr("fill", "none")
    .attr("stroke", (_, i) => {
      const color = i === 0 ? majorGridLineColor : gridLineColor;
      return color;
    })
    .attr("stroke-width", grindLineWidth)
    .attr("d", v => {
      const pos = scale(v);
      if (vertical) return `M ${pos} ${top} L ${pos} ${height + top}`;
      return `M ${left} ${pos} L ${width + left} ${pos}`;
    });

  labels
    .selectAll("text")
    .data(filteredTicks)
    .join("text")
    .attr("font-size", labelFontSize)
    .attr("fill", labelColor)
    .attr("text-anchor", (_, i) => {
      if (vertical) {
        return i === filteredTicks.length - 1 ? "end" : "middle";
      }
      return "start";
    })
    .attr("transform", "translate(0,0)")
    .attr("opacity", (_, i) => {
      return i !== 0 || showFirstLabel || vertical ? 1 : 0;
    })
    .attr("x", v => {
      if (vertical) return scale(v);
      return 4 + left;
    })
    .attr("y", v => {
      if (vertical) return height + top + 14;
      const offset = showFirstLabel ? 4 : 12;
      return scale(v) + offset;
    })
    .text((v, i) => {
      const { axisLabel = {} } = options;
      const label = d3Format(",")(v);
      const text = axisLabel.formatter
        ? axisLabel.formatter(label, i, v)
        : label;
      return text;
    });
}

/**
 * 绘制标题
 *
 * @since 2.3
 *
 * @param title 标题对象
 * @param text 标题文本
 * @param vertical 是否为垂直
 */
function drawAxisTitle(
  title: Selection<SVGTextElement, {}, HTMLElement, {}>,
  text: string,
  style: string = "",
  x: number,
  y: number,
  vertical?: boolean
) {
  title
    .attr("x", x)
    .attr("y", y)
    .attr("style", `color:#666666;fill:#666666;${style}`)
    .attr(
      "transform",
      `translate(0,0) ${vertical ? `rotate(270, ${x}, ${y})` : ""}`
    )
    .append("tspan")
    .text(text);
}
