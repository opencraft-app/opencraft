import { ScalePoint, select, curveCatmullRom, line, area } from "d3";
import { Line } from "./line";

export interface AreaStyle {
  /**
   * 填充色透明度
   */
  fillOpacity?: number;
}

export class Area extends Line {
  private areaStyle: AreaStyle = {
    fillOpacity: 0.3,
  };

  public style(cfg: AreaStyle) {
    this.areaStyle = {
      ...this.areaStyle,
      ...cfg,
    };
    return this;
  }

  /**
   * 绘制折线图
   * @since 2.0
   */
  public drawSeries() {
    const { classPrefix, id } = this.ctx;
    const { smooth } = this.options;
    const series = this.model.getSerieNames();
    const categories = this.model.getCategoryNames();
    const categoryScale = this.categoryScale as ScalePoint<string>;
    const serieCls = `${classPrefix}-chart-series ${classPrefix}-chart-line-series`;
    const markersCls = `${classPrefix}-chart-markers ${classPrefix}-chart-line-series`;
    const shape = this;
    this.seriesGroup.selectAll("g").remove();
    const datum = {};
    for (const serieName of series) {
      datum[serieName] = [];
      for (const cat of categories) {
        const value: number = shape.model.get(cat, serieName);
        const x: number = categoryScale(cat);
        const y: number = shape.valueScale(value);
        const color: string = shape.colorScale(serieName);
        datum[serieName].push({ value, x, y, color });
      }
    }

    this.seriesGroup
      .selectAll(`.${serieCls}`)
      .data(series)
      .join("g")
      .attr("class", (_, i) => `${serieCls} ${classPrefix}-chart-series-${i}`)
      .attr("data-z-index", (_, i) => series.length - i - 1)
      .attr("clip-path", `url(#${id})`)
      .call(g => {
        const { valueScale, model, areaStyle } = this;
        const { enable: connectNulls } = this.ctx.getOption("connectNulls");
        const { colorAttrCallback } = this;
        g.each(function serie(serieName) {
          const serieGroup = select(this);
          const data = datum[serieName];
          const defaultColor = colorAttrCallback
            ? colorAttrCallback(data)
            : data && data[0] && data[0].color;
          // 绘制可见折线
          serieGroup
            .append("path")
            .attr("fill", "none")
            .attr("class", `${classPrefix}-chart-shape-missing`)
            .attr("data-z-index", "1")
            .attr("stroke", defaultColor)
            .attr("stroke-width", shape.shapeSize)
            .attr("stroke-linejoin", "round")
            .attr("stroke-linecap", "round")
            .attr("d", () => {
              const lineGenerator = line<any>().defined(({ value }) =>
                connectNulls ? true : typeof value === "number"
              );
              if (smooth) {
                lineGenerator.curve(curveCatmullRom.alpha(0.3));
              }
              return lineGenerator.x(({ x }) => x).y(({ y }) => y)(
                connectNulls
                  ? data.filter(({ value }) => typeof value === "number")
                  : data
              );
            });

          // 绘制面积
          serieGroup
            .append("path")
            .attr("fill", "none")
            .attr("class", `${classPrefix}-chart-shape-missing`)
            .attr("data-z-index", "1")
            .attr("fill", defaultColor)
            .attr("fill-opacity", areaStyle.fillOpacity)
            .attr("stroke-linejoin", "round")
            .attr("stroke-linecap", "round")
            .attr("d", () => {
              const lineGenerator = area<any>().defined(({ value }) =>
                connectNulls ? true : typeof value === "number"
              );
              if (smooth) {
                lineGenerator.curve(curveCatmullRom.alpha(0.3));
              }

              const [min] = model.getExtent();

              return lineGenerator
                .x(({ x }, i) => {
                  const offsetX =
                    shape.shapeSize === 0 ? 0 : shape.shapeSize / 2;
                  if (i === 0) return x - offsetX;
                  if (i === data.length - 1) return x + offsetX;
                  return x;
                })
                .y1(() => valueScale(min))
                .y0(({ y }) => y)(
                connectNulls
                  ? data.filter(({ value }) => typeof value === "number")
                  : data
              );
            });

          // 绘制追踪线
          serieGroup
            .append("path")
            .attr("fill", "none")
            .attr("class", `${classPrefix}-chart-tracker-line`)
            .attr("data-z-index", "2")
            .attr("stroke", "rgba(192,192,192,0.0001)")
            .attr("stroke-width", "24")
            .attr("stroke-linejoin", "round")
            .attr("stroke-linecap", "round")
            .attr("d", () => {
              // @ts-ignore
              return line<any>()
                .defined(({ value }) => typeof value === "number")
                .x(({ x }) => x)
                .y(({ y }) => y)(data);
            });
        });
      });

    this.seriesGroup
      .selectAll(`.${markersCls}`)
      .data(series)
      .join("g")
      .attr("class", (_, i) => `${markersCls} ${classPrefix}-chart-series-${i}`)
      .attr("data-z-index", (_, i) => series.length - i - 1);

    const maxSerieIndex = series.length;
    for (let start = 0; start <= maxSerieIndex; start++) {
      this.seriesGroup
        .selectAll(`.${classPrefix}-chart-series-${start}`)
        .raise();
    }
  }
}
