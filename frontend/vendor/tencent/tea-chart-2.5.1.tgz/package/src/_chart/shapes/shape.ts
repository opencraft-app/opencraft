import { ScaleOrdinal, Selection } from "d3";
import { Context } from "../context";
import { DataModel } from "../data-model";
import { RectCoordinate } from "../coordinates/rect-coord";
import { uniqueId } from "../lib/unique-id";
import { Helpers } from "../type/helpers";
import { Color } from "../type/chart";
import { CategoryScale, ValueScale } from "../coordinates/coordinate";
import { PolarCoordinate } from "../coordinates/polar-coord";
import { ShapeOptions } from "../type/options";
import { DataLeaf } from "../type";

export interface DatumPoint {
  value: number;
  x: number;
  y: number;
  color: string;
  metric: number;
  originValue: number;
  category: string;
  dataLeaf: DataLeaf;
}

export interface Datum {
  [key: string]: DatumPoint[];
}

export interface DataMarker {
  position: [string, number];
  text: {
    content: string;
    style?: string;
  };
  line?: {
    length?: number;
    color?: string;
    width?: number;
  };
}

/**
 * 所有图形的基类
 * @since 2.0
 */
export abstract class Shape {
  /**
   * 图形 ID
   */
  public id: string;

  /**
   * 全局上下文
   * @since 2.0
   */
  public ctx: Context;

  /**
   * 数据模型
   * @since 2.0
   */
  public model: DataModel;

  /**
   * 当前图表的辅助图层
   * @since 2.0
   */
  public helpers: Helpers;

  /**
   * 图形绘制区
   * @since 2.0
   */
  public seriesGroup: Selection<SVGGElement, {}, HTMLElement, {}>;

  /**
   * 坐标轴实例
   * @since 2.0
   */
  public coordinate: RectCoordinate | PolarCoordinate;

  /**
   * 数据映射字段 key
   * @since 2.0
   */
  public valueKey: string;

  /**
   * 数据系列映射字段 key
   *
   * 数据系列字段通常对应颜色分类
   *
   * @since 2.0
   */
  public serieKey: string;

  /**
   * 颜色映射字段
   *
   * @since 2.0.1
   */
  public colorKey: string;

  /**
   * 分类映射字段 key
   *
   * 分类映射字段通常对应直角坐标系的 X 轴
   *
   * @since 2.0
   */
  public categoryKey: string;

  /**
   * 颜色比例尺
   * @since 2.0
   */
  public colorScale: ScaleOrdinal<string, string>;

  /**
   * 颜色映射回调函数
   * @since 2.1.2
   */
  public colorAttrCallback: Color["formatter"];

  /**
   * 分类比例尺
   * 直角坐标系：X 轴
   * @since 2.0
   */
  public categoryScale: CategoryScale;

  /**
   * 数据比例尺
   * @since 2.0
   */
  public valueScale: ValueScale;

  /**
   * 图形尺寸
   * @since 2.0
   */
  public shapeSize: number;

  /**
   * 坐标轴翻转
   */
  public invert: boolean;

  /**
   * 当前 Hover 的索引
   */
  public currentHoverIndex: number;

  /**
   * 过滤的数据系列名
   * @since 2.0
   */
  public disabledKeys: string[] = [];

  /**
   * 图形设置
   */
  public options: ShapeOptions = {
    dataLabels: {
      enable: false,
    },
  };

  /**
   * @constructor
   * @param ctx 上下文
   * @since 2.0
   */
  public constructor(
    ctx: Context,
    coord: RectCoordinate | PolarCoordinate,
    helpers: Helpers
  ) {
    const cls = `${ctx.classPrefix}-chart-series-group`;
    this.id = uniqueId("shape_");
    this.ctx = ctx;
    this.model = new DataModel();
    this.coordinate = coord;
    this.helpers = helpers;
    // 如果图形绘制区默认先使用已存在的绘制区，如果没有则创建一个
    this.seriesGroup = this.ctx.root.select(`.${cls}`);
    if (!this.seriesGroup.node()) {
      this.seriesGroup = this.ctx.root
        .append("g")
        .attr("class", cls)
        .attr("data-z-index", "3");
    }
  }

  /**
   * 设置数据映射关系
   * @param pos 数据映射关系
   * @since 2.0
   */
  abstract position(pos: string): this;

  /**
   * 以颜色作为数据映射
   * @param {string} colorCfg 作为数据系列映射字段
   * @param {Color} colorCfg 以 Color 的配置来设置颜色与数据系列映射关系
   * @since 2.0
   */
  abstract color(colorCfg: string | Color | string[]): this;

  public shape(cfg: ShapeOptions) {
    this.options = cfg;
    return this;
  }

  /**
   * 更新数据模型
   * @since 2.0
   */
  abstract updateModel(): void;

  /**
   * 更新颜色比例尺
   * @since 2.0
   */
  abstract updateColorScale(): void;

  /**
   * 绘图
   * @since 2.0
   */
  abstract draw(): void;

  /**
   * 绘制图形
   * @since 2.0
   */
  abstract drawSeries(): void;
}
