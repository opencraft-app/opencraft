import {
  Selection,
  geoMercator,
  geoPath,
  ScaleLinear,
  scaleLinear,
  json,
  select,
  format,
  event,
} from "d3";
import { Context } from "../context";
import {
  Helpers,
  Color,
  ShapeOptions,
  MetaData,
  MapType,
  Language,
} from "../type";
import { DataModel } from "../data-model";
import {
  dictionaryMap,
  countryCode,
  provinceCode,
} from "../../i18n/constants/dictionaryMap";

export class Map {
  /**
   * 图形 ID
   */
  public id: string;

  /**
   * 地图类型
   */
  public mapType: MapType = "china";

  /**
   * geo数据链接
   */
  public geoJsonUrl: string = "";

  /**
   * 语言类型，目前仅中英文
   */
  public mapLanguage: Language = "zh";

  /**
   * 全局上下文
   * @since 2.3
   */
  public ctx: Context;

  /**
   * 数据模型
   * @since 2.3
   */
  public model: DataModel;

  /**
   * 当前图表的辅助图层
   * @since 2.3
   */
  public helpers: Helpers;

  /**
   * 图形绘制区
   * @since 2.3
   */
  public seriesGroup: Selection<SVGGElement, {}, HTMLElement, {}>;

  /**
   * 地图路径
   * @since 2.3
   */
  public mapPathGroup: Selection<SVGPathElement, {}, SVGGElement, {}>;

  /**
   * 数据映射字段 key
   * @since 2.3
   */
  public valueKey: string;

  /**
   * 数据系列映射字段 key
   *
   * 数据系列字段通常对应颜色分类
   *
   * @since 2.3
   */
  public serieKey: string;

  /**
   * 分类映射字段
   *
   * @since 2.3
   */
  public categoryKey: string;

  /**
   * 颜色比例尺
   */
  public colorScale: ScaleLinear<string, string>;

  /**
   * 颜色映射回调函数
   * @since 2.1.2
   */
  public colorAttrCallback: Color["formatter"];

  /**
   * 图形设置
   */
  public options: ShapeOptions = {
    dataLabels: {
      enable: false,
    },
  };

  /**
   * 地图数据
   * @since 2.3
   */
  private geoJSON: any;

  /**
   * 当前geo数据类型
   */
  private geoJsonType: string = "";

  /**
   * 渐变矩形条
   */
  private gradientRect: Selection<SVGGElement, {}, HTMLElement, {}>;

  /**
   * 渐变定义
   */
  private gradientDefs: Selection<SVGDefsElement, {}, HTMLElement, {}>;

  public constructor(ctx: Context, helpers: Helpers) {
    const cls = `${ctx.classPrefix}-chart-series-group`;
    this.ctx = ctx;
    this.helpers = helpers;
    this.model = new DataModel();
    this.gradientDefs = this.ctx.root.append("defs");
    this.gradientRect = this.ctx.root.append("g");
    // 如果图形绘制区默认先使用已存在的绘制区，如果没有则创建一个
    this.seriesGroup = this.ctx.root.select(`.${cls}`);
    if (!this.seriesGroup.node()) {
      this.seriesGroup = this.ctx.root
        .append("g")
        .attr("class", cls)
        .attr("data-z-index", "3");
    }
  }

  /**
   * @implements Shape
   * @param pos 数据映射关系
   * @since 2.0
   */
  public position(pos: string) {
    const language = this.mapLanguage;
    const dataSource = this.ctx.dataSource.map(item => {
      let { type } = item;
      if (this.mapType === "world") {
        type =
          countryCode[language] && countryCode[language][type]
            ? countryCode[language][type]
            : type;
      }
      if (this.mapType === "china") {
        type =
          provinceCode[language] && provinceCode[language][type]
            ? provinceCode[language][type]
            : type;
      }
      item.type = type;
      return item;
    });
    this.model.source(dataSource);
    if (typeof pos === "string") {
      [this.categoryKey, this.valueKey] = pos.split("*");
    }
    return this;
  }

  public color(color: string[] | Color) {
    if (Array.isArray(color)) {
      this.ctx.theme.color = color;
    } else if (typeof color === "object" && color !== null) {
      const { formatter, colors } = color;
      if (colors) {
        this.ctx.theme.color = colors;
      } else {
        this.ctx.theme.color = null;
      }
      if (formatter) {
        this.colorAttrCallback = formatter;
      }
    }
    return this;
  }

  public registerMap(geoJSON: any) {
    this.geoJSON = geoJSON;
    return this;
  }

  public updateModel() {
    this.model.define(this.categoryKey, this.valueKey, "default", "default");
  }

  /**
   * 更新颜色比例尺
   * @since 2.3
   */
  public updateColorScale() {
    const { domain } = this.ctx.getOption(`scale.${this.valueKey}`, {
      domain: null,
    });
    const autofit = domain === "autofit";
    const valueDomain = Array.isArray(domain)
      ? domain
      : this.model.getExtent(autofit);
    const [min, max] = valueDomain;
    const { color, defaultColor } = this.ctx.theme;
    let colorRange: string[] = [];
    if (Array.isArray(color)) {
      colorRange = color;
    } else {
      colorRange = defaultColor;
    }
    this.colorScale = scaleLinear<string, string>()
      .domain([min, max])
      .range(colorRange);
  }

  public draw() {
    this.updateModel();
    this.updateColorScale();
    // 获取地图的 legend.enable
    const enable = this.ctx.getOption("legend.enable", true);
    this.downLoadGeoJSON(this.geoJsonUrl).then(() => {
      this.drawMap();
      // enable 为 true 绘制地图的 legend
      if (enable) {
        this.drawGradientRect();
      }
    });
    return this;
  }

  private async downLoadGeoJSON(geoJsonUrl: string = "") {
    if (!this.geoJSON || this.geoJsonType !== this.mapType) {
      this.geoJsonType = this.mapType;
      this.geoJSON = await fetchGeoJSON(this.mapType, geoJsonUrl);
      const dictionary = dictionaryMap[this.mapLanguage];
      this.geoJSON.features.map(item => {
        let { name } = item.properties;
        name = dictionary[name] ? dictionary[name] : name;
        item.properties.name = name;

        return item;
      });
    }
  }

  public drawMap() {
    const { classPrefix } = this.ctx;
    const cls = `${classPrefix}-chart-map`;
    const height = this.ctx.getBackgroundHeight();
    const width = this.ctx.getBackgroundWidth();

    const projection = geoMercator().fitSize([width, height], this.geoJSON);
    const path = geoPath().projection(projection);

    this.seriesGroup.selectAll(`path.${cls}`).remove();
    const that = this;

    let tooltipTimer: NodeJS.Timeout;
    let tooltipActived = false;

    if (this.geoJSON && this.geoJSON.features) {
      this.mapPathGroup = this.seriesGroup
        .selectAll(`path.${cls}`)
        .data(this.geoJSON.features)
        .enter()
        .append("path")
        .classed(cls, true)
        .attr("stroke", (d: any) => {
          const { name } = d.properties;
          if (["", "海南省", "台湾省"].includes(name)) return "#b2b2b2";
          return "#FFFFFF";
        })
        .attr("data-name", (d: any) => d.properties.name)
        .attr("d", path)
        .style("cursor", "pointer")
        .attr("fill", (d: any) => {
          const { name } = d.properties;
          const alias = this.ctx.getOption(`scale.${this.valueKey}.alias`);
          const values = this.model.getDataFromCategoryName(name, false, false);
          const { serieName, value = null, origin } = values[0] || {};
          const metaData: MetaData = {
            title: name,
            label: alias || this.valueKey,
            serieName,
            valueText: typeof value === "number" ? format(",")(value) : "-",
            color: this.colorScale(value),
            value,
            row: origin,
          };
          d.meta = metaData;
          return metaData.color;
        })
        .on("mouseenter", function enter() {
          const ele = select(this);
          ele.style("fill", "#FFF2CF");
        })
        .on("mouseleave", function leave(d: any) {
          const ele = select(this);
          const { color } = d.meta;
          ele.style("fill", color);
          clearTimeout(tooltipTimer);
          tooltipActived = false;
          tooltipTimer = setTimeout(() => {
            if (tooltipActived === false) {
              that.helpers.tooltip.hide();
            }
          }, 300);
        })
        .on("mousemove", function move(d: any) {
          const tooltipEnable = that.ctx.getOption("tooltip.enable");
          const { meta } = d;
          if (tooltipEnable === false) return;
          const data = {
            x: event && event.offsetX,
            y: event && event.offsetY,
            category: meta.title,
            metaData: [meta],
            index: 0,
          };
          that.helpers.tooltip.show(data, that.model.getAllData());
          tooltipActived = true;
        })
        .on("click", (d: any) => {
          const selectEnable = this.ctx.getOption("interaction.element-select");
          if (selectEnable) {
            that.ctx.emit("interaction.selected", d.meta);
          }
        });
    }
  }

  public shape(cfg: ShapeOptions) {
    this.options = cfg;
    return this;
  }

  public setMapType(mapType: MapType) {
    if (mapType) {
      this.mapType = mapType;
    }

    return this;
  }

  public setGeoJsonUrl(geoJsonUrl: string) {
    if (geoJsonUrl) {
      this.geoJsonUrl = geoJsonUrl;
    }

    return this;
  }

  public language(language: Language) {
    if (language) {
      this.mapLanguage = language;
    }

    return this;
  }

  private drawGradientRect() {
    const { domain } = this.ctx.getOption(`scale.${this.valueKey}`, {
      domain: null,
    });
    const autofit = domain === "autofit";
    const valueDomain = Array.isArray(domain)
      ? domain
      : this.model.getExtent(autofit);
    const [min, max] = valueDomain;
    const { padding, xAxis } = this.ctx.theme;
    const height = this.ctx.getBackgroundHeight();
    this.gradientDefs.select("linearGradient").remove();
    this.gradientRect.select("rect").remove();
    this.gradientRect.selectAll("text").remove();
    let x = padding.left;

    if (this.seriesGroup.node()) {
      const {
        x: groupX,
        width,
      } = this.seriesGroup.node().getBoundingClientRect();
      if (groupX) {
        x = groupX - width + 100;
      }
    }

    const linearGradient = this.gradientDefs
      .append("linearGradient")
      .attr("id", "linearColor")
      .attr("x1", "0%")
      .attr("y1", "100%")
      .attr("x2", "0%")
      .attr("y2", "0%");

    // 设置矩形条开始颜色
    linearGradient
      .append("stop")
      .attr("offset", "0%")
      .attr("stop-color", this.colorScale(min));

    // 设置结束颜色
    linearGradient
      .append("stop")
      .attr("offset", "100%")
      .attr("stop-color", this.colorScale(max));

    this.gradientRect
      .append("rect")
      .attr("x", x)
      .attr("y", height - 83 - padding.bottom)
      .attr("width", 16)
      .attr("height", 83)
      .style("fill", `url(#${linearGradient.attr("id")})`);
    this.gradientRect
      .append("text")
      .attr("x", x + 20)
      .attr("y", height - padding.bottom)
      .text(String(min))
      .attr("fill", xAxis.labelColor)
      .classed("linear-text", true);
    this.gradientRect
      .append("text")
      .attr("x", x + 20)
      .attr("y", height - 83 - padding.bottom + 8)
      .text(String(max))
      .attr("fill", xAxis.labelColor)
      .classed("linear-text", true);
  }
}

/**
 * 按地图类型获取GeoJson数据
 *
 * @param type 地图类型
 */
async function fetchGeoJSON(type: MapType, geoUrl: string) {
  // 用户自定义设置geoJson链接地址
  let geoJsonUrl = geoUrl;
  if (geoJsonUrl) {
    return json(geoJsonUrl);
  }

  /**
   * 开发环境可用(china)： "http://127.0.0.1:4314/static/china_map_geojson.202007211628.json";
   * 开发环境可用(world)： "http://127.0.0.1:4314/static/world_map_geojson.202012091746.json";
   */
  switch (type) {
    case "china":
      geoJsonUrl =
        "//cloudcache.tencent-cloud.com/qcloud/tea-chart/geojson/china_map_geojson.202007211628.json";
      break;
    case "world":
      geoJsonUrl =
        "//cloudcache.tencent-cloud.com/qcloud/tea-chart/geojson/world_map_geojson.202012091746.json";
      break;
    default:
      geoJsonUrl =
        "//cloudcache.tencent-cloud.com/qcloud/tea-chart/geojson/china_map_geojson.202007211628.json";
  }

  return json(geoJsonUrl);
}
