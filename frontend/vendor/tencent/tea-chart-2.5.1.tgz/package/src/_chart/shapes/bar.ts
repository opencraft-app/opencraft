import {
  ascending,
  scaleOrdinal,
  scaleBand,
  scaleLinear,
  select,
  format,
  Selection,
  extent,
  sum,
} from "d3";
import moment from "moment";
import { Shape, Datum, DatumPoint } from "./shape";
import { Color } from "../type/chart";
import { ContextOptions, Context } from "../context";
import { CategoryScaleType } from "../coordinates/coordinate";
import { RectCoordinate } from "../coordinates/rect-coord";
import { Helpers } from "../type/helpers";
import { MetaData, EventData, LegendData } from "../type/data";
import {
  textWrap,
  getLabelMaxWidth,
  getLabelMaxHeight,
} from "../lib/svg-helper";
import { getCategoryIndex } from "../lib/get-category-index";
import { InteractionOptions } from "../type";

export class Bar extends Shape {
  /**
   * 每个 X 轴点对应柱形的最大宽度
   * @since 2.0
   */
  private maxBarWidth: number;

  /**
   * 分类轴数据比例尺类型
   * @since 2.0
   */
  private categoryScaleType: CategoryScaleType = "Band";

  /**
   * Crosshair
   * @since 2.0
   */
  private crosshair: Selection<SVGPathElement, {}, HTMLElement, {}>;

  /**
   * 高亮的元素
   * @since 2.3
   */
  private highlightElements: Selection<
    SVGElement,
    DatumPoint,
    HTMLElement,
    {}
  >[] = [];

  public constructor(
    ctx: Context,
    coord: RectCoordinate,
    helpers: Helpers,
    maxBarWidth?: number
  ) {
    super(ctx, coord, helpers);
    this.maxBarWidth = maxBarWidth;
    this.crosshair = this.ctx.root
      .append("path")
      .attr("class", `${this.ctx.classPrefix}-chart-crosshair`)
      .attr("data-z-index", "2")
      .attr("stroke", "#000")
      .attr("stroke-width", 1)
      .attr("opacity", 0.05)
      .attr("style", "pointer-events:none;")
      .attr("visibility", "hidden");

    this.ctx.on("plot.mouse.move", this.onMouseMove, this);
    this.ctx.on("plot.mouse.left", this.removeHover, this);
    this.ctx.on("plot.mouse.click", this.onClick, this);

    this.ctx.on("legend.hover", this.onLegendItemHover, this);
    this.ctx.on("legend.left", this.onLegendItemLeft, this);
    this.ctx.on("legend.clicked", this.onLegendClick, this);

    this.ctx.on("coord.zoom.zooming", this.onZoom, this);
    this.ctx.on("coord.zoom.reset", this.onZoomReset, this);
  }

  /**
   * @implements Shape
   * @param pos 数据映射关系
   * @since 2.0
   */
  public position(pos: string) {
    this.model.source(this.ctx.dataSource);
    const [first = {}] = this.ctx.dataSource;
    if (typeof pos === "string") {
      const [x, y] = pos.split("*");
      if (typeof first[y] === "number" || first[y] === null) {
        this.categoryKey = x;
        this.valueKey = y;
        this.invert = false;
      } else {
        this.categoryKey = y;
        this.valueKey = x;
        this.invert = true;
      }
    }
    return this;
  }

  /**
   * @implements
   * @param {string} color 作为数据系列映射字段
   * @param {Color} color 以 Color 的配置来设置颜色与数据系列映射关系
   * @since 2.0
   */
  public color(color: string | Color | string[]) {
    let key: string;
    if (typeof color === "string") {
      key = color;
    } else if (Array.isArray(color)) {
      this.ctx.theme.color = color;
    } else if (typeof color === "object" && color !== null) {
      const { formatter, colors } = color;
      ({ key } = color);
      if (colors) {
        this.ctx.theme.color = colors;
      } else {
        this.ctx.theme.color = null;
      }
      if (formatter) {
        this.colorAttrCallback = formatter;
      }
    } else {
      this.colorKey = null;
      this.serieKey = null;
    }

    if (key !== this.categoryKey) {
      this.serieKey = key;
    }

    this.colorKey = key;
    return this;
  }

  public size(size: number) {
    this.shapeSize = size;
    return this;
  }

  /**
   * 每个 X 轴点对应柱形的最大宽度
   * @param {number} maxBarWidth 最大宽度
   * @since 2.0
   */
  public maxWidth(maxBarWidth: number) {
    this.maxBarWidth = maxBarWidth;
    return this;
  }

  /**
   * 设置坐标轴配置
   * @param axis 坐标轴配置
   * @since 2.0
   */
  public axis(axis: ContextOptions["axis"]) {
    if (axis.xAxis) {
      this.ctx.setOption("axis.xAxis", axis.xAxis);
    }
    if (axis.yAxis) {
      this.ctx.setOption("axis.yAxis", axis.yAxis);
    }
    return this;
  }

  /**
   * @implements
   * @since 2.0
   */
  public updateModel() {
    let xSort = null;
    const { type, timeParseFormat } = this.ctx.getOption(
      `scale.${this.categoryKey}`,
      {
        type: "category",
        timeParseFormat: false,
      }
    );
    if (type === "time") {
      xSort = (a: string, b: string) => {
        return ascending(
          moment(a, timeParseFormat).valueOf(),
          moment(b, timeParseFormat).valueOf()
        );
      };
    }
    const { stack } = this.ctx.getOption(`scale.${this.valueKey}`, {
      stack: false,
    });
    this.model.define(
      this.categoryKey,
      this.valueKey,
      this.serieKey,
      this.colorKey,
      xSort,
      !!stack,
      stack === "percent" ? stack : "stack"
    );
  }

  /**
   * 更新颜色比例尺
   * @implements
   * @since 2.0
   */
  public updateColorScale() {
    const colorDomain = this.model.getKeyNames(this.colorKey);
    const { color, defaultColor } = this.ctx.theme;
    let colorRange: string[] = [];
    if (typeof color === "function") {
      for (let i = 0; i < colorDomain.length; i++) {
        colorRange.push(color(colorDomain[i], i, i === colorDomain.length - 1));
      }
    } else if (Array.isArray(color)) {
      colorRange = color;
    } else {
      colorRange = defaultColor;
    }
    this.colorScale = scaleOrdinal<string>()
      .domain(colorDomain)
      .range(colorRange);
  }

  /**
   * 更新数据比例尺
   * @implements
   * @since 2.0
   */
  public updateDataScale() {
    const seriesDomain = this.model.getSerieNames();
    const categoryDomain = this.model.getCategoryNames();
    this.categoryScale = [
      scaleBand()
        .domain(categoryDomain)
        .paddingInner(0.1)
        .align(0.5),
      scaleBand()
        .domain(seriesDomain)
        .paddingInner(0.05)
        .align(0.5),
    ];

    const { domain, stack } = this.ctx.getOption(`scale.${this.valueKey}`, {
      domain: null,
    });
    if (stack && stack === "percent") {
      this.valueScale = scaleLinear().domain([0, 100]);
    } else {
      const autofit = domain === "autofit";
      const valueDomain = Array.isArray(domain)
        ? domain
        : this.model.getExtent(autofit);
      this.valueScale = scaleLinear()
        .domain(valueDomain)
        .nice(10);
    }
  }

  /**
   * 开始绘图
   * @implements
   * @since 2.0
   */
  public draw(updateModel = true) {
    if (updateModel) this.updateModel();
    this.updateColorScale();
    this.updateDataScale();

    // 先更新图例的位置
    this.helpers.legend.update(
      this.colorScale,
      this.valueKey,
      "line",
      this.model
    );

    // 更新坐标轴
    this.coordinate.draw(
      this.valueScale,
      this.categoryScale,
      this.categoryScaleType,
      this.invert
    );

    this.drawSeries();

    const { brush, zoom }: InteractionOptions = this.ctx.getOption(
      "interaction"
    );
    this.helpers.selection.setEnable(!!brush || !!zoom);
  }

  /**
   * 绘制柱状图
   * @since 2.0
   */
  public drawSeries() {
    const { ctx } = this;
    const { classPrefix, id } = this.ctx;
    const series = this.model.getSerieNames();
    const categories = this.model.getCategoryNames();
    const [categoryScale, serieScale] = this.categoryScale;
    const serieCls = `${classPrefix}-chart-series ${classPrefix}-chart-bar-series`;
    const markersCls = `${classPrefix}-chart-markers ${classPrefix}-chart-bar-series`;
    const shape = this;
    this.seriesGroup.selectAll("g").remove();
    let useMaxWidth = false;

    if (this.shapeSize) {
      serieScale.range([0, this.shapeSize * series.length]);
    } else if (
      (!this.model.stack && serieScale.bandwidth() > this.maxBarWidth) ||
      (this.model.stack && categoryScale.bandwidth() > this.maxBarWidth)
    ) {
      serieScale.range([0, this.maxBarWidth * series.length]);
      useMaxWidth = true;
    }

    const domain = this.valueScale.domain(); // 值轴值域
    const min = domain[0];
    const max = domain[1];
    const zeroPos = this.valueScale(min < 0 ? 0 : min); // 值轴 0 值位置

    const datum: Datum = {};
    const isStack = !!this.model.stack; // 是否为堆叠图
    const isPercentStack =
      this.model.stack && this.model.stackType === "percent";
    for (const category of categories) {
      const dataPoints = this.model.getDataFromCategoryName(category, true);
      for (const point of dataPoints) {
        const {
          stackPercent,
          value,
          stackValue,
          percent,
          category,
          serieName,
          colorName,
        } = point;
        const color = this.colorScale(colorName);
        const rawValue = isPercentStack ? percent : value;
        const isNegative = rawValue < 0;
        // 计算值轴位置
        let posValue = value; // 映射在值轴的值
        if (isStack) {
          posValue = posValue < 0 ? stackValue - value : stackValue;
        } else {
          posValue = posValue < 0 ? 0 : value;
        }
        if (posValue > max) posValue = max;
        if (posValue < min) posValue = min;

        const valueMapPos = this.valueScale(
          isPercentStack ? stackPercent : posValue
        ); // 矩形顶部映射在图形的 y 值（如果是横向坐标轴则是右侧 X 轴的值）

        let metric = 0; // 映射为高度或者宽度
        if (rawValue !== null) {
          if (isStack) {
            if (isNegative) {
              metric = Math.abs(this.valueScale(rawValue) - zeroPos);
            } else {
              // 如果是堆叠图
              metric = Math.abs(zeroPos - this.valueScale(rawValue));
            }
          } else {
            // 如果为非堆叠图，则基本高度为 Y 坐标 - Y 轴 0 值坐标
            metric = Math.abs(this.valueScale(rawValue) - zeroPos);
          }
        }

        // 计算分类轴坐标
        let catPos: number = categoryScale(category) || 0;
        if (this.shapeSize) {
          catPos += categoryScale.bandwidth() / 2 - this.shapeSize / 2;
        } else if (!isStack && useMaxWidth) {
          catPos +=
            categoryScale.bandwidth() / 2 -
            (this.maxBarWidth * series.length) / 2;
        } else if (isStack && useMaxWidth) {
          catPos += categoryScale.bandwidth() / 2 - this.maxBarWidth / 2;
        }
        if (!isStack) catPos += serieScale(serieName);
        if (!datum[serieName]) datum[serieName] = [];

        datum[serieName].push({
          x: this.invert ? valueMapPos - metric : catPos,
          y: this.invert ? catPos : valueMapPos,
          category,
          value,
          color,
          metric,
          originValue: value,
          dataLeaf: point,
        });
      }
    }

    // eslint-disable-next-line no-nested-ternary
    const barWidth = useMaxWidth
      ? this.maxBarWidth
      : isStack
      ? categoryScale.bandwidth()
      : serieScale.bandwidth();

    const rectWidth = shape.shapeSize || barWidth;
    const selectEnable = this.ctx.getOption("interaction.element-select");
    const bar = this;

    this.seriesGroup
      .selectAll(`.${serieCls}`)
      .data(series)
      .join("g")
      .attr("class", (_, i) => `${serieCls} ${classPrefix}-chart-series-${i}`)
      .attr("clip-path", `url(#${id})`)
      .call(g => {
        const { invert, colorAttrCallback } = this;
        g.each(function serie(serieName) {
          const serieGroup = select(this);
          const data = datum[serieName];
          // 绘制柱形图
          serieGroup
            .selectAll("rect")
            .data(data)
            .join("rect")
            .attr("style", d => {
              const cursor = selectEnable ? "pointer" : "normal";
              let { color = "none" } = d || {};
              if (colorAttrCallback) {
                color = colorAttrCallback(d.dataLeaf) || d.color;
              }
              return `fill:${color};cursor:${cursor};`;
            })
            .attr("class", `${classPrefix}-chart-point`)
            .attr("width", ({ metric }) => {
              if (invert) return metric;
              return rectWidth;
            })
            .attr("x", ({ x }) => x)
            .attr("y", ({ y }) => y)
            .attr("height", ({ metric }) => {
              if (invert) return rectWidth;
              return metric;
            })
            .call(g => {
              bar.highlightElements = [];
              g.each(function rect(data) {
                const rectElement: Selection<
                  SVGRectElement,
                  DatumPoint,
                  HTMLElement,
                  {}
                > = select(this as SVGRectElement);
                const { interaction = { selected: {} } } = ctx.theme || {};
                const { selected } = interaction;
                // 处理 element-select 交互事件
                rectElement.on("click", () => {
                  if (selectEnable) {
                    bar.highlightElements.forEach(r => {
                      const [data] = r.data();
                      if (data.color) {
                        r.style("fill", data.color);
                      }
                      r.style("opacity", 1);
                    });
                    const mappedData = bar.getData(data.x, data.y);
                    ctx.emit("interaction.selected", mappedData, data);
                    if (selected.fill) {
                      rectElement.style("fill", selected.fill);
                    }
                    if (selected.opacity) {
                      rectElement.style("opacity", selected.opacity);
                    }
                    // 目前只支持单个元素点击
                    bar.highlightElements = [rectElement];
                  }
                });
              });
            });
        });
      });

    this.seriesGroup
      .selectAll(`.${markersCls}`)
      .data(series)
      .join("g")
      .attr(
        "class",
        (_, i) => `${markersCls} ${classPrefix}-chart-series-${i}`
      );

    const maxSerieIndex = series.length;
    for (let start = 0; start <= maxSerieIndex; start++) {
      this.seriesGroup
        .selectAll(`.${classPrefix}-chart-series-${start}`)
        .raise();
    }

    /**
     * @todo 从 drawSeries 移除出去
     */
    const dataLabelEnable = this.options.dataLabels.enable;
    const stackLabelEnable = this.ctx.getOption(
      `scale.${this.valueKey}.stackLabels.enable`
    );
    this.ctx.root.selectAll(`.${classPrefix}-chart-data-labels`).remove();
    this.ctx.root.selectAll(`.${classPrefix}-chart-stack-labels`).remove();
    if (stackLabelEnable) {
      this.drawStackLabels(datum, rectWidth);
    }
    if (dataLabelEnable) {
      this.drawDataLabels(datum, rectWidth);
    }
  }

  /**
   *
   * 绘制堆叠数据值文本
   * @param datum 数据
   * @param barWidth 柱子的宽度
   */
  public drawStackLabels(datum: Datum, barWidth: number) {
    const { root, classPrefix } = this.ctx;
    const series = this.model.getSerieNames();
    const labelGroup = root
      .append("g")
      .attr("class", `${classPrefix}-chart-stack-labels`)
      .attr("data-z-index", 6);
    const labels = labelGroup
      .selectAll("g")
      .data(this.categoryScale[0].domain())
      .join("g")
      .attr(
        "class",
        `${classPrefix}-chart-label ${classPrefix}-chart-stack-label`
      );
    const text = labels
      .append("text")
      .attr("y", 11)
      .attr("text-anchor", "start")
      .attr("class", "font-size:11px;font-weight:bold;color:gray;fill:gray;")
      .attr("data-z-index", 1);
    text.append("tspan").text(category => {
      const categoriesDatum = [];
      for (const serie of series) {
        const data = datum[serie].find(d => d.category === category);
        if (data) {
          categoriesDatum.push(data);
        }
      }
      return format(",")(sum(categoriesDatum.map(d => d.originValue)));
    });

    const { invert } = this;

    labels.attr("transform", function transform(category) {
      const categoriesDatum = [];
      for (const serie of series) {
        const data = datum[serie].find(d => d.category === category);
        if (data) {
          categoriesDatum.push(data);
        }
      }
      let x: number;
      let y: number;
      if (invert) {
        [, x] = extent(categoriesDatum.map(d => d.x + d.metric));
        [{ y }] = categoriesDatum;
        const height = getLabelMaxHeight(select(this).nodes());
        y = y + barWidth / 2 - height / 2;
      } else {
        const [minY] = extent(categoriesDatum.map(d => d.y));
        [{ x }] = categoriesDatum;
        const width = getLabelMaxWidth(select(this).nodes());
        x = x + barWidth / 2 - width / 2;
        y = minY - 15;
      }
      return `translate(${x},${y})`;
    });
  }

  /**
   * 绘制数据值文本
   * @param datum 数据
   * @param barWidth 柱子的宽度
   */
  public drawDataLabels(datum: Datum, barWidth: number) {
    const { root, classPrefix } = this.ctx;
    const series = this.model.getSerieNames();
    const labelFormatter = this.options.dataLabels.formatter;

    const lablesGroup = root
      .selectAll(`.${classPrefix}-chart-data-labels`)
      .data(series)
      .join("g")
      .attr(
        "class",
        (_, i) =>
          `${classPrefix}-chart-data-labels ${classPrefix}-chart-series-${i}`
      )
      .attr("data-z-index", 6);
    const labels = lablesGroup
      .selectAll(`.${classPrefix}-chart-label ${classPrefix}-data-label`)
      .data(d => datum[d])
      .join("g")
      .attr("class", `${classPrefix}-chart-label ${classPrefix}-data-label`)
      .attr("data-z-index", 1);

    labels
      .append("text")
      .attr("data-z-index", 1)
      .attr("x", 0)
      .attr("y", this.invert ? 5 : 16)
      .attr("text-anchor", "middle")
      .attr("style", () => {
        return `font-size:11px;font-weight:bold;color:#000;fill:#000;`;
      })
      .text(({ originValue, dataLeaf }, i) => {
        if (typeof labelFormatter === "function") {
          return labelFormatter(originValue, i, dataLeaf);
        }
        return format(",")(originValue);
      })
      .call(textWrap, this.invert, barWidth);

    const { invert } = this;
    labels.attr("transform", function transform({ x, y, metric }) {
      const maxTextWidth = getLabelMaxWidth(select(this).nodes());
      const maxTextHeight = getLabelMaxHeight(select(this).nodes());
      if (invert) {
        return `translate(${x + metric / 2 - maxTextWidth / 2}, ${y +
          barWidth / 2 -
          maxTextHeight / 2 +
          4})`;
      }
      return `translate(${x +
        barWidth / 2}, ${y + metric / 2 - maxTextHeight / 2 - 4})`;
    });
  }

  private onMouseMove(x: number, y: number) {
    const tooltipEnable = this.ctx.getOption("tooltip.enable");
    if (tooltipEnable === false) return;
    const data = this.getData(x, y);
    if (data) {
      const allData = this.model.getAllData();
      this.drawHover(data);
      this.helpers.tooltip.show(data, allData);
      if (this.ctx.getOption("interaction.element-hover")) {
        if (this.currentHoverIndex !== data.index) {
          this.ctx.emit("interaction.hover", data.metaData);
          this.currentHoverIndex = data.index;
        }
      }
    } else {
      this.removeHover();
    }
  }

  /**
   * 根据坐标获取数据
   * @since 2.0
   * @param x x 坐标
   * @param y y 坐标
   */
  public getData(x: number, y?: number): EventData {
    const cat = this.invert ? y : x;
    const [axisScale] = this.categoryScale;
    const domain = axisScale.domain();
    let index = getCategoryIndex(cat, axisScale, "Band");
    const dValue = domain[index];
    const pos = axisScale(dValue) + axisScale.bandwidth() / 2;

    if (index < 0 || Number.isNaN(index) || dValue === undefined) return null;

    if (index > domain.length - 1) {
      index = domain.length - 1;
    }

    const alias = this.ctx.getOption(`scale.${this.valueKey}.alias`);
    const metaData: MetaData[] = [];

    for (const {
      serieName,
      colorName,
      value,
      origin,
      percent,
    } of this.model.getDataFromCategoryName(dValue, true)) {
      metaData.push({
        title: dValue,
        label: alias || (serieName === "default" ? this.valueKey : serieName),
        serieName,
        valueText: typeof value === "number" ? format(",")(value) : "-",
        color: this.colorScale(colorName),
        value,
        row: origin,
        percentage:
          this.model.stack && this.model.stackType === "percent"
            ? Number(Number(percent).toFixed(2))
            : undefined,
      });
    }

    return {
      x: this.invert ? x : pos,
      y: this.invert ? pos : y,
      category: dValue,
      metaData,
      index,
    };
  }

  /**
   * 通过分类坐标名获取数据
   * @param category
   */
  public getDataFromCategory(category: string): MetaData[] {
    const alias = this.ctx.getOption(`scale.${this.valueKey}.alias`);
    const metaData: MetaData[] = [];

    for (const {
      serieName,
      colorName,
      value,
      origin,
      percent,
    } of this.model.getDataFromCategoryName(category, true)) {
      metaData.push({
        title: category,
        label: alias || (serieName === "default" ? this.valueKey : serieName),
        serieName,
        valueText: typeof value === "number" ? format(",")(value) : "-",
        color: this.colorScale(colorName),
        value,
        row: origin,
        percentage:
          this.model.stack && this.model.stackType === "percent"
            ? Number(Number(percent).toFixed(2))
            : undefined,
      });
    }

    return metaData;
  }

  /**
   * 通过值获取坐标
   * @param category 分类值
   * @param value 数据值
   */
  public getPosition(category: string, value: number) {
    const categoryScale = this.categoryScale[0];
    return [categoryScale(category), this.valueScale(value)];
  }

  /**
   * 绘制标记线和标记点
   * @param eventData 当前数据点信息
   * @since 2.0
   * @todo 修复最后一个点不显示的问题
   */
  private drawHover(eventData: EventData) {
    const {
      padding: { left },
    } = this.ctx.theme;
    const [axisScale] = this.categoryScale;
    const { x, y } = eventData;
    const offsetX = parseInt(this.ctx.plotBackgound.attr("x"), 10);
    const offsetY = parseInt(this.ctx.plotBackgound.attr("y"), 10);
    const height = parseInt(this.ctx.plotBackgound.attr("height"), 10);
    const width = parseInt(this.ctx.plotBackgound.attr("width"), 10);
    const bandwidth = axisScale.bandwidth();
    const padding = axisScale.padding() * bandwidth;
    const strokeWidth: number =
      bandwidth < padding ? bandwidth : bandwidth + padding;

    // 绘制标记线
    this.crosshair
      .attr("stroke-width", strokeWidth)
      .attr("d", () => {
        if (this.invert) {
          return `M${offsetX + left},${y}L${width + offsetX},${y}`;
        }
        return `M${x},${offsetY}L${x},${height + offsetY}`;
      })
      .attr("visibility", "visible");
  }

  /**
   * 隐藏标记线和标记点
   * @since 2.0
   */
  private removeHover() {
    this.crosshair.attr("visibility", "hidden");
    this.seriesGroup
      .selectAll(`.${this.ctx.classPrefix}-chart-markers circle`)
      .attr("opacity", "0");
    this.helpers.tooltip.hide();
  }

  /**
   * 监听图例事件
   * @param legendData LegendData
   */
  private onLegendItemHover({ index }) {
    this.ctx.root
      .selectAll(`.${this.ctx.classPrefix}-chart-series`)
      .attr("opacity", 0.1);
    this.ctx.root
      .selectAll(`.${this.ctx.classPrefix}-chart-data-labels`)
      .attr("opacity", 0.1);

    this.ctx.root
      .selectAll(`.${this.ctx.classPrefix}-chart-series-${index}`)
      .attr("opacity", 1);
  }

  /**
   * 监听图例事件
   * @param legendData LegendData
   */
  private onLegendItemLeft() {
    this.ctx.root
      .selectAll(`.${this.ctx.classPrefix}-chart-series`)
      .attr("opacity", 1);
    this.ctx.root
      .selectAll(`.${this.ctx.classPrefix}-chart-data-labels`)
      .attr("opacity", 1);
  }

  /**
   * 图例点击事件
   * @param legendData 被点击的图例信息
   * @param disabled 改图例元素是否是禁用状态
   */
  private onLegendClick(legendData: LegendData, disabled: boolean) {
    const { key } = legendData;
    if (disabled) {
      this.disabledKeys.push(key);
    } else {
      this.disabledKeys = this.disabledKeys.filter(d => d !== key);
    }
    this.model.filterColumns(this.disabledKeys);
    this.draw(false);
  }

  private onClick(x: number, y: number) {
    const mappedData = this.getData(x, y);
    // 兼容以前的，想要以后去掉
    if (mappedData) {
      this.ctx.emit("click", mappedData);
    }
  }

  private onZoom(range: string[]) {
    this.model.range(range);
    this.draw(false);
  }

  private onZoomReset() {
    this.draw();
  }
}
