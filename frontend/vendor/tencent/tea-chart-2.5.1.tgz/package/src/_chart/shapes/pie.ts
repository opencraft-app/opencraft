import {
  pie,
  arc,
  event,
  select,
  PieArcDatum,
  scaleOrdinal,
  format,
  Arc,
  line,
} from "d3";
import { Shape } from "./shape";
import { Color, PolarProps } from "../type/chart";
import { PolarCoordinate } from "../coordinates/polar-coord";
import { Context } from "../context";
import { Helpers } from "../type/helpers";
import { LegendData } from "../type/data";
import { nodeWidth, nodeHeight } from "../lib/svg-helper";

const DEFAULT_LABEL_TEXT_HEIGHT = 14;

export class Pie extends Shape {
  private radius: number = 0;

  private innerRadius: number = 0;

  private arcInstance: Arc<any, PieArcDatum<string>>;

  private hoverArcInstance: Arc<any, PieArcDatum<string>>;

  private labelTextHeight: number = 0;

  public constructor(ctx: Context, coord: PolarCoordinate, helpers: Helpers) {
    super(ctx, coord, helpers);
    const { width, height } = this.coordinate;
    this.radius = Math.min(width, height) / 2;
    this.ctx.on("legend.hover", this.onLegendItemHover, this);
    this.ctx.on("legend.left", this.onLegendItemLeft, this);
    this.ctx.on("legend.clicked", this.onLegendClick, this);

    this.ctx.on("plot.mouse.left", () => {
      this.helpers.tooltip.hide();
    });
  }

  /**
   * 开始监听事件
   */
  private start() {
    const { classPrefix } = this.ctx.theme;
    if ("ontouchstart" in document) {
      this.seriesGroup
        .selectAll(`.${this.ctx.classPrefix}-chart-series`)
        .selectAll("path")
        .style("-webkit-tap-highlight-color", "transparent")
        .on("touchmove", this.showHover.bind(this))
        .on("touchend", this.hideHover.bind(this))
        .on("click", this.onClick.bind(this));

      this.seriesGroup.on("touchend", () => {
        if (
          event &&
          event.relatedTarget &&
          event.relatedTarget.className !== `${classPrefix}-chart-tooltip`
        ) {
          this.helpers.tooltip.hide();
        }
      });
    } else {
      this.seriesGroup
        .selectAll(`.${this.ctx.classPrefix}-chart-series`)
        .selectAll("path")
        .on("mousemove", this.showHover.bind(this))
        .on("mouseleave", this.hideHover.bind(this))
        .on("click", this.onClick.bind(this));
      this.seriesGroup.on("mouseleave", () => {
        if (
          event.relatedTarget &&
          event.relatedTarget.className !== `${classPrefix}-chart-tooltip`
        ) {
          this.helpers.tooltip.hide();
        }
      });
    }
  }

  public position(pos: string) {
    this.model.source(this.ctx.dataSource);
    if (typeof pos === "string") {
      this.valueKey = pos;
    }
    return this;
  }

  public color(color: string | Color | string[]) {
    if (typeof color === "string") {
      this.serieKey = color;
    } else if (Array.isArray(color)) {
      this.ctx.theme.color = color;
    } else if (typeof color === "object" && color !== null && color.key) {
      const { key, formatter, colors } = color;
      this.serieKey = key;
      if (colors) {
        this.ctx.theme.color = colors;
      } else {
        this.ctx.theme.color = null;
      }
      if (formatter) {
        this.colorAttrCallback = formatter;
      }
    } else {
      this.serieKey = null;
    }
    this.colorKey = this.serieKey;
    return this;
  }

  public coord(cfg: PolarProps["coord"]) {
    const { innerRadius } = cfg;
    // 如果 innerRadius 是小于 1 的数字或百分比的字符串，代表是百分比系数，否则则认为是具体的数值
    if (typeof innerRadius === "number") {
      this.innerRadius = innerRadius;
    }
    return this;
  }

  public updateModel() {
    this.model.define("default", this.valueKey, this.serieKey, this.colorKey);
  }

  public updateColorScale() {
    let colorDomain = this.model.getKeyNames(this.colorKey);

    // series 需要按照值大小排序
    colorDomain = colorDomain.sort((a, b) => {
      const prev = this.model.getByAll("default", a);
      const next = this.model.getByAll("default", b);
      return next - prev;
    });

    // 设置每个系列的颜色
    const { color, defaultColor } = this.ctx.theme;
    let colorRange: string[] = [];
    if (typeof color === "function") {
      for (let i = 0; i < colorDomain.length; i++) {
        colorRange.push(color(colorDomain[i], i, i === colorDomain.length - 1));
      }
    } else if (Array.isArray(color)) {
      colorRange = color;
    } else {
      colorRange = defaultColor;
    }
    this.colorScale = scaleOrdinal<string>()
      .domain(colorDomain)
      .range(colorRange);
  }

  public draw(updateModel = true) {
    if (updateModel) this.updateModel();
    this.updateColorScale();

    // 先更新图例的位置
    this.helpers.legend.update(
      this.colorScale,
      this.valueKey,
      "pie",
      this.model
    );

    (this.coordinate as PolarCoordinate).draw();

    this.drawSeries();

    this.start();
  }

  public drawSeries() {
    const enable = this.ctx.getOption("interaction.element-select");
    const { width, height } = this.coordinate;
    this.radius = Math.min(width, height) / 2;

    // series 需要按照值大小排序
    const seriesDomain = this.model.getSerieNames().sort((a, b) => {
      const prev = this.model.getByAll("default", a);
      const next = this.model.getByAll("default", b);
      return next - prev;
    });

    const pieInstance = pie<string>()
      .value(col => {
        return this.model.get("default", col);
      })
      .sort(null);
    let buildData = pieInstance(seriesDomain);

    // 这里处理下所有值都为空的情况
    const totalCount = buildData.reduce((pre, data) => pre + data.value, 0);
    if (totalCount === 0) {
      const seriesDomainCount = seriesDomain.length;
      const emptyShowData = Array(seriesDomainCount).fill(1);
      const emptyPieInstance = pie<string>()(emptyShowData);
      buildData = buildData.map((item, index) => {
        item.startAngle = emptyPieInstance[index].startAngle;
        item.endAngle = emptyPieInstance[index].endAngle;
        return item;
      });
    }

    this.seriesGroup.selectAll("g").remove();

    this.seriesGroup
      .attr("transform", `translate(${width / 2},${height / 2})`)
      .append("g")
      .attr(
        "class",
        `${this.ctx.classPrefix}-chart-series ${this.ctx.classPrefix}-chart-pie-series`
      )
      .call(g => {
        this.arcInstance = arc<PieArcDatum<string>>()
          .innerRadius(
            this.innerRadius < 1
              ? this.radius * this.innerRadius
              : this.innerRadius
          )
          .outerRadius(this.radius * 0.82);
        g.selectAll("path")
          .data(buildData)
          .join("path")
          .style("cursor", enable ? "pointer" : "normal")
          .transition()
          .duration(500)
          .attr(
            "class",
            d => `${this.ctx.classPrefix}-chart-point color-${d.index}`
          )
          .attr("d", this.arcInstance)
          .attr("fill", d => this.colorScale(d.data));
      });

    // 绘制 Hover 图形
    this.hoverArcInstance = arc<PieArcDatum<string>>()
      .innerRadius(this.radius * 0.82)
      .outerRadius(this.radius * 0.9);
    this.seriesGroup
      .append("g")
      .attr(
        "class",
        `${this.ctx.classPrefix}-chart-series ${this.ctx.classPrefix}-chart-pie-series`
      )
      .call(g => {
        g.selectAll("path")
          .data(buildData)
          .join("path")
          .attr(
            "class",
            d => `${this.ctx.classPrefix}-chart-halo color-${d.index}`
          )
          .attr("data-index", d => d.index)
          .attr("d", this.hoverArcInstance)
          .attr("fill", d => {
            let color;
            if (this.colorAttrCallback) {
              color = this.colorAttrCallback(d);
            }
            return color || this.colorScale(d.data);
          })
          .style("opacity", "0");
      });

    this.drawDataLabels(buildData);
    return this;
  }

  public drawDataLabels(data: PieArcDatum<string>[]) {
    const { enable, formatter } = this.options.dataLabels;
    const labelArcInstance = arc<PieArcDatum<string>>()
      .innerRadius(this.radius * 0.9)
      .outerRadius(this.radius * 0.9);

    const { root, classPrefix } = this.ctx;
    const labelGroup = root
      .selectAll(`.${classPrefix}-chart-data-labels`)
      .data(data)
      .join("g")
      .attr(
        "class",
        (_, i) =>
          `${classPrefix}-chart-data-labels ${classPrefix}-chart-series-${i}`
      )
      .attr("data-z-index", 6)
      .attr("transform", this.seriesGroup.attr("transform"));

    labelGroup.selectAll("g").remove();
    labelGroup.selectAll("path").remove();

    if (!enable) return;

    const midAngle = (d: PieArcDatum<string>) => {
      return d.startAngle + (d.endAngle - d.startAngle) / 2;
    };

    const labels = labelGroup
      .append("g")
      .attr("class", `${classPrefix}-chart-label ${classPrefix}-data-label`)
      .attr("data-z-index", 1);
    const totalCount = data.reduce((pre, d) => pre + d.value, 0);
    labels
      .append("text")
      .attr("data-z-index", 1)
      .attr("dy", "0.35em")
      .style("text-anchor", d => {
        return midAngle(d) < Math.PI ? "start" : "end";
      })
      .style("font-size", "11px")
      .style("font-weight", "bold")
      .text((d, i) => {
        const percentage =
          totalCount === 0 ? 0 : getPercentage(d.startAngle, d.endAngle);
        if (typeof formatter === "function") {
          return formatter(d.value, i, {
            value: d.value,
            percent:
              totalCount === 0 ? 0 : getPercentage(d.startAngle, d.endAngle),
            serieName: d.data,
            colorName: this.colorScale(d.data),
          });
        }
        return `${d.value} (${percentage}%)`;
      });

    // 获取label高度
    const labelNodes = labels.nodes();
    if (labelNodes && labelNodes.length > 0 && !this.labelTextHeight) {
      this.labelTextHeight = Math.ceil(nodeHeight(labelNodes[0]));
    } else {
      this.labelTextHeight = DEFAULT_LABEL_TEXT_HEIGHT;
    }

    // 调整label位置
    const yAxiesValues = {};
    const dataLength = data.length;
    let lastYAxiesValue: number | undefined;
    for (let i = dataLength - 1; i > 0; i--) {
      const pos = labelArcInstance.centroid(data[i]);
      const x = this.radius * (midAngle(data[i]) < Math.PI ? 1 : -1);
      if (i === dataLength - 1) {
        // eslint-disable-next-line prefer-destructuring
        lastYAxiesValue = pos[1];
      } else if (x < 0 && pos[1] - lastYAxiesValue < this.labelTextHeight) {
        lastYAxiesValue += this.labelTextHeight;
        yAxiesValues[i] = lastYAxiesValue;
      }
    }

    labels.attr("transform", (d, index) => {
      const pos = labelArcInstance.centroid(d);
      const x = this.radius * (midAngle(d) < Math.PI ? 1 : -1);
      const y =
        typeof yAxiesValues[index] !== "undefined"
          ? yAxiesValues[index]
          : pos[1];
      return `translate(${x}, ${y})`;
    });
    labelGroup
      .append("path")
      .attr("class", `${classPrefix}-data-connector`)
      .attr("d", (d, index) => {
        const firstPoint = this.arcInstance.centroid(d);
        let secondPoint = labelArcInstance.centroid(d);
        const threePoint = labelArcInstance.centroid(d);
        threePoint[0] = this.radius * 0.95 * (midAngle(d) < Math.PI ? 1 : -1);
        if (typeof yAxiesValues[index] !== "undefined") {
          threePoint[1] = yAxiesValues[index];
          const endAngle = d.startAngle + (d.endAngle - d.startAngle) / 2;
          const fitSecondPointData = Object.assign({}, d, { endAngle });
          secondPoint = labelArcInstance.centroid(fitSecondPointData);
        }
        return line()([firstPoint, secondPoint, threePoint]);
      })
      .attr("fill", "none")
      .attr("stroke", d => {
        return this.colorScale(d.data);
      })
      .attr("stroke-width", 1);
  }

  private onClick({ data, index, value, endAngle, startAngle }) {
    // eslint-disable-next-line no-unused-expressions
    event && event.preventDefault();
    const enable = this.ctx.getOption("interaction.element-select");
    if (enable) {
      this.drawSelected(index);
      const x = event && event.layerX;
      const y = event && event.layerY;
      const { valueKey, model, colorScale, serieKey } = this;
      const alias = this.ctx.getOption(`scale.${valueKey}.alias`);
      const label = alias || data.key === "default" ? valueKey : data;
      this.ctx.emit("interaction.selected", {
        x,
        y,
        xPos: x,
        index,
        metaData: [
          {
            value,
            title: label,
            color: colorScale(data),
            percentage: getPercentage(startAngle, endAngle),
            row: model
              .getDataFromCategoryName("default")
              .find(d => d[serieKey] === data),
          },
        ],
      });
    }
  }

  private drawSelected(index: number) {
    this.seriesGroup
      .selectAll(`.${this.ctx.classPrefix}-chart-point`)
      .transition()
      .duration(500)
      .attr("d", this.arcInstance);
    const arcInstance = arc<PieArcDatum<string>>()
      .innerRadius(
        this.innerRadius < 1 ? this.radius * this.innerRadius : this.innerRadius
      )
      .outerRadius(this.radius * 0.9);
    this.seriesGroup
      .select(`.${this.ctx.classPrefix}-chart-point.color-${index}`)
      .transition()
      .duration(500)
      .attr("d", arcInstance);
  }

  /**
   * 显示辅助点
   */
  private showHover({ data, index, value, endAngle, startAngle }) {
    this.seriesGroup
      .selectAll(`.${this.ctx.classPrefix}-chart-series`)
      .selectAll(`.${this.ctx.classPrefix}-chart-halo`)
      .style("opacity", 0);
    this.seriesGroup
      .selectAll(`.${this.ctx.classPrefix}-chart-series`)
      .select(`.${this.ctx.classPrefix}-chart-halo[data-index="${index}"]`)
      .style("opacity", 0.3);
    // eslint-disable-next-line no-unused-expressions
    event && event.preventDefault();
    const x = event && event.offsetX;
    const y = event && event.offsetY;
    const { valueKey, model, colorScale, serieKey } = this;
    const alias = this.ctx.getOption(`scale.${valueKey}.alias`);
    const label = alias || data.key === "default" ? valueKey : data;
    const dataLeaf = model
      .getDataFromCategoryName("default")
      .find(d => d[serieKey] === data);
    const metaData = [
      {
        value,
        valueText: typeof value === "number" ? format(",")(value) : "-",
        title: label,
        color: colorScale(data),
        percentage: value === 0 ? 0 : getPercentage(startAngle, endAngle),
        row: dataLeaf ? dataLeaf.origin : null,
      },
    ];

    const tooltipEnable = this.ctx.getOption("tooltip.enable");
    if (tooltipEnable) {
      const allData = this.model.getAllData();
      this.helpers.tooltip.show(
        {
          x,
          y,
          category: undefined,
          index,
          metaData,
        },
        allData
      );
    }

    if (this.ctx.getOption("interaction.element-hover")) {
      if (this.currentHoverIndex !== index) {
        this.ctx.emit("interaction.hover", metaData);
        this.currentHoverIndex = index;
      }
    }
  }

  /**
   * 隐藏辅助点
   */
  private hideHover() {
    this.seriesGroup
      .selectAll(`.${this.ctx.classPrefix}-chart-halo`)
      .style("opacity", "0");
    this.currentHoverIndex = null;
  }

  private onLegendItemHover({ key }) {
    this.seriesGroup
      .selectAll(`.${this.ctx.classPrefix}-chart-series`)
      .selectAll("path")
      .call(g => {
        g.each(function highlight({ data }) {
          const ele = select(this);
          if (data === key) {
            ele.attr("opacity", 1);
          } else {
            ele.attr("opacity", 0.3);
          }
        });
      });
  }

  private onLegendItemLeft() {
    this.seriesGroup
      .selectAll(`.${this.ctx.classPrefix}-chart-series`)
      .selectAll("path")
      .call(g => {
        g.each(function highlight() {
          const ele = select(this);
          ele.attr("opacity", 1);
        });
      });
  }

  /**
   * 图例点击事件
   * @param legendData 被点击的图例信息
   * @param disabled 改图例元素是否是禁用状态
   */
  private onLegendClick(legendData: LegendData, disabled: boolean) {
    const { key } = legendData;
    if (disabled) {
      this.disabledKeys.push(key);
    } else {
      this.disabledKeys = this.disabledKeys.filter(d => d !== key);
    }
    this.model.filterColumns(this.disabledKeys);
    this.draw(false);
  }
}

function getPercentage(startAngle, endAngle, fixed = 2) {
  return parseFloat(
    (((endAngle - startAngle) / (2 * Math.PI)) * 100).toFixed(fixed)
  );
}
