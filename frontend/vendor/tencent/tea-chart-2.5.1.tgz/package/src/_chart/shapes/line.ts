import {
  ascending,
  scaleOrdinal,
  scalePoint,
  scaleLinear,
  ScalePoint,
  select,
  line,
  format,
  Selection,
  curveMonotoneX,
  curveLinear,
} from "d3";
import moment from "moment";
import { Shape, Datum } from "./shape";
import { Color } from "../type/chart";
import { ContextOptions, Context } from "../context";
import { CategoryScaleType } from "../coordinates/coordinate";
import { RectCoordinate } from "../coordinates/rect-coord";
import { Helpers } from "../type/helpers";
import { MetaData, EventData, LegendData } from "../type/data";
import { getCategoryIndex } from "../lib/get-category-index";
import { InteractionOptions } from "../type/options";
import { hexToRGB } from "../lib/hex-to-rgb";

export class Line extends Shape {
  /**
   * 分类轴数据比例尺类型
   * @since 2.0
   */
  private categoryScaleType: CategoryScaleType = "Point";

  /**
   * Crosshair
   * @since 2.0
   */
  private crosshair: Selection<SVGPathElement, {}, HTMLElement, {}>;

  private allCategoryScale: ScalePoint<string>;

  private canvasMode: boolean = false;

  private highlightKey: string;

  public constructor(ctx: Context, coord: RectCoordinate, helpers: Helpers) {
    super(ctx, coord, helpers);
    this.crosshair = this.ctx.root
      .append("path")
      .attr("class", `${this.ctx.classPrefix}-chart-crosshair`)
      .attr("data-z-index", "2")
      .attr("stroke", "#ECECEC")
      .attr("stroke-width", 1)
      .attr("style", "pointer-events:none;")
      .attr("visibility", "hidden");

    this.ctx.on("plot.mouse.move", this.onMouseMove, this);
    this.ctx.on("plot.mouse.left", this.removeHover, this);
    this.ctx.on("plot.mouse.click", this.onClick, this);

    this.ctx.on("legend.hover", this.onLegendItemHover, this);
    this.ctx.on("legend.left", this.onLegendItemLeft, this);
    this.ctx.on("legend.clicked", this.onLegendClick, this);

    this.ctx.on("coord.zoom.zooming", this.onZoom, this);
    this.ctx.on("coord.zoom.reset", this.onZoomReset, this);
  }

  /**
   * @implements Shape
   * @param pos 数据映射关系
   * @since 2.0
   */
  public position(pos: string) {
    this.model.source(this.ctx.dataSource);
    if (typeof pos === "string") {
      [this.categoryKey, this.valueKey] = pos.split("*");
    }
    return this;
  }

  /**
   * @implements
   * @param {string} color 作为数据系列映射字段
   * @param {Color} color 以 Color 的配置来设置颜色与数据系列映射关系
   * @since 2.0
   */
  public color(color: string | Color | string[]) {
    if (typeof color === "string") {
      this.serieKey = color;
    } else if (Array.isArray(color)) {
      this.ctx.theme.color = color;
    } else if (typeof color === "object" && color !== null) {
      const { key, formatter, colors } = color;
      this.serieKey = key;
      if (colors) {
        this.ctx.theme.color = colors;
      } else {
        this.ctx.theme.color = null;
      }
      if (formatter) {
        this.colorAttrCallback = formatter;
      }
    } else {
      this.serieKey = null;
    }

    this.colorKey = this.serieKey;

    return this;
  }

  public size(size: number) {
    this.shapeSize = size;
    return this;
  }

  /**
   * 设置坐标轴配置
   * @param axis 坐标轴配置
   * @since 2.0
   */
  public axis(axis: ContextOptions["axis"]) {
    if (axis.xAxis) {
      this.ctx.setOption("axis.xAxis", axis.xAxis);
    }
    if (axis.yAxis) {
      this.ctx.setOption("axis.yAxis", axis.yAxis);
    }
    return this;
  }

  /**
   * 设置图例
   * @param enable 是否显示图例
   * @param connectNullsCfg 连接空值配置
   * @since 2.0
   */
  public connectNulls(
    enable: boolean | ContextOptions["connectNulls"],
    connectNullsCfg: ContextOptions["connectNulls"] = {}
  ) {
    const cfg: ContextOptions["connectNulls"] =
      typeof enable === "boolean"
        ? { enable, ...connectNullsCfg }
        : { ...enable };
    cfg.enable = typeof cfg.enable === "boolean" ? cfg.enable : true;
    this.ctx.setOption("connectNulls", cfg);
    return this;
  }

  /**
   * @implements
   * @since 2.0
   */
  public updateModel() {
    let xSort = null;
    const { type, timeParseFormat } = this.ctx.getOption(
      `scale.${this.categoryKey}`,
      {
        type: "category",
        timeParseFormat: false,
      }
    );
    if (type === "time") {
      xSort = (a: string, b: string) => {
        return ascending(
          moment(a, timeParseFormat).valueOf(),
          moment(b, timeParseFormat).valueOf()
        );
      };
    }
    const maxCount = Number(this.ctx.background.attr("width"));
    const { stack } = this.ctx.getOption(`scale.${this.valueKey}`, {
      stack: false,
    });
    this.model.define(
      this.categoryKey,
      this.valueKey,
      this.serieKey,
      this.colorKey,
      xSort,
      stack,
      "stack"
    );

    const len = this.model.getCategoryNames().length;
    const interval = Math.floor(len / maxCount);
    const { canvasMode } = this.options;
    this.canvasMode =
      typeof canvasMode === "boolean"
        ? canvasMode
        : !!(maxCount && len > maxCount && interval);
  }

  /**
   * 更新颜色比例尺
   * @implements
   * @since 2.0
   */
  public updateColorScale() {
    const colorDomain = this.model.getKeyNames(this.colorKey);
    const { color, defaultColor } = this.ctx.theme;
    let colorRange: string[] = [];
    if (typeof color === "function") {
      for (let i = 0; i < colorDomain.length; i++) {
        colorRange.push(color(colorDomain[i], i, i === colorDomain.length - 1));
      }
    } else if (Array.isArray(color)) {
      colorRange = color;
    } else {
      colorRange = defaultColor;
    }
    this.colorScale = scaleOrdinal<string>()
      .domain(colorDomain)
      .range(colorRange);
  }

  /**
   * 更新数据比例尺
   * @implements
   * @since 2.0
   */
  public updateDataScale() {
    this.categoryScale = scalePoint().domain(this.model.getCategoryNames());

    const { domain } = this.ctx.getOption(`scale.${this.valueKey}`, {
      domain: null,
    });
    const autofit = domain === "autofit";
    const valueDomain = Array.isArray(domain)
      ? domain
      : this.model.getExtent(autofit);
    this.valueScale = scaleLinear()
      .domain(valueDomain)
      .nice(5);
  }

  /**
   * 开始绘图
   * @implements
   * @since 2.0
   */
  public draw(
    updateModel = true,
    updateColorScale = true,
    updateDataScale = true
  ) {
    if (updateModel) this.updateModel();
    if (updateColorScale) this.updateColorScale();
    if (updateDataScale) this.updateDataScale();

    // 先更新图例的位置
    this.helpers.legend.update(
      this.colorScale,
      this.valueKey,
      "line",
      this.model
    );

    // 更新坐标轴
    this.coordinate.draw(
      this.valueScale,
      this.categoryScale,
      this.categoryScaleType,
      this.invert
    );

    // 全部的分类比例尺
    this.allCategoryScale = (Object.assign(
      {},
      this.categoryScale
    ) as ScalePoint<string>).domain(this.model.getCategoryNames(true));

    this.drawSeries();

    const { brush, zoom }: InteractionOptions = this.ctx.getOption(
      "interaction"
    );
    this.helpers.selection.setEnable(!!brush || !!zoom);
  }

  /**
   * 绘制折线图
   * @since 2.0
   */
  public drawSeries() {
    const { classPrefix, id } = this.ctx;
    const { smooth } = this.options;
    const series = this.model.getSerieNames();
    const categories = this.model.getCategoryNames(true);
    const categoryScale = this.allCategoryScale as ScalePoint<string>;
    const serieCls = `${classPrefix}-chart-series ${classPrefix}-chart-line-series`;
    const markersCls = `${classPrefix}-chart-markers ${classPrefix}-chart-line-series`;
    const shape = this;
    this.seriesGroup.selectAll("g").remove();

    const datum: Datum = {};
    for (const cat of categories) {
      const dataPoints = this.model.getDataFromCategoryName(cat, false, true);
      for (const point of dataPoints) {
        const { category, serieName, colorName } = point;
        const value = shape.model.get(cat, serieName);
        const x: number = categoryScale(cat);
        const y: number = shape.valueScale(value);
        const color: string = shape.colorScale(colorName);
        if (!datum[serieName]) datum[serieName] = [];
        datum[serieName].push({
          value,
          x,
          y,
          color,
          metric: null,
          category,
          originValue: value,
          dataLeaf: point,
        });
      }
    }

    const { enable: connectNulls } = this.ctx.getOption("connectNulls");
    const { colorAttrCallback, ctx } = this;

    // 大数据模式使用 Canvas
    if (this.canvasMode) {
      this.seriesGroup.selectAll("g").remove();
      const imageGroup = this.seriesGroup
        .append("g")
        .attr("class", `${serieCls} ${classPrefix}-chart-series-0`)
        .attr("data-z-index", 0)
        .attr("clip-path", `url(#${id})`);
      const canvas = document.createElement("canvas");
      const width = Number(ctx.background.attr("width"));
      const height = Number(ctx.background.attr("height"));
      canvas.width = width * window.devicePixelRatio;
      canvas.height = height * window.devicePixelRatio;
      canvas.setAttribute("style", `width:${width}px;height:${height}px`);

      const canvasCtx = canvas.getContext("2d");
      canvasCtx.scale(window.devicePixelRatio, window.devicePixelRatio);
      canvasCtx.translate(0, 0);

      for (const serieName of series) {
        const data = datum[serieName] || [];
        let defaultColor;
        const { dataLeaf, color: dColor = "none" } = data[0] || {};
        if (colorAttrCallback) {
          defaultColor = colorAttrCallback(dataLeaf);
        }
        defaultColor = defaultColor || dColor;

        const lineData = connectNulls
          ? data.filter(({ value }) => typeof value === "number")
          : data;

        const lineGenerator = line<any>()
          .defined(({ value }) =>
            connectNulls ? true : typeof value === "number"
          )
          .x(({ x }) => x)
          .y(({ y }) => y)
          .curve(smooth ? curveMonotoneX : curveLinear);
        canvasCtx.beginPath();
        lineGenerator.context(canvasCtx);
        lineGenerator(lineData);
        canvasCtx.lineWidth = shape.shapeSize;
        canvasCtx.strokeStyle = hexToRGB(
          defaultColor,
          this.highlightKey && this.highlightKey !== serieName ? 0.1 : 1
        );
        canvasCtx.stroke();
      }
      imageGroup
        .append("image")
        .attr("class", `${classPrefix}-chart-shape-canvas`)
        .attr("x", 0)
        .attr("y", 0)
        .attr("width", width)
        .attr("height", height)
        .attr("href", canvas.toDataURL())
        .attr(
          "style",
          `pointer-events:none;mixed-blend-mode:normal;opacity:${1};`
        );
    } else {
      this.seriesGroup
        .selectAll(`.${serieCls}`)
        .data(series)
        .join("g")
        .attr("class", (_, i) => `${serieCls} ${classPrefix}-chart-series-${i}`)
        .attr("data-z-index", (_, i) => series.length - i - 1)
        .attr("clip-path", `url(#${id})`)
        .call(g => {
          g.each(function serie(serieName) {
            const serieGroup = select(this);
            const data = datum[serieName] || [];
            let defaultColor;
            const { dataLeaf, color: dColor = "none" } = data[0] || {};
            if (colorAttrCallback) {
              defaultColor = colorAttrCallback(dataLeaf);
            }
            defaultColor = defaultColor || dColor;

            const lineData = connectNulls
              ? data.filter(({ value }) => typeof value === "number")
              : data;

            const lineGenerator = line<any>()
              .defined(({ value }) =>
                connectNulls ? true : typeof value === "number"
              )
              .x(({ x }) => x)
              .y(({ y }) => y)
              .curve(smooth ? curveMonotoneX : curveLinear);

            // 绘制可见折线
            serieGroup
              .append("path")
              .attr("fill", "none")
              .attr("class", `${classPrefix}-chart-shape-missing`)
              .attr("data-z-index", "1")
              .attr("stroke", defaultColor)
              .attr("stroke-width", shape.shapeSize)
              .attr("stroke-linejoin", "round")
              .attr("stroke-linecap", "round")
              .attr("d", () => lineGenerator(lineData));
          });
        });
    }

    this.seriesGroup
      .selectAll(`.${markersCls}`)
      .data(series)
      .join("g")
      .attr("class", (_, i) => `${markersCls} ${classPrefix}-chart-series-${i}`)
      .attr("data-z-index", (_, i) => series.length - i - 1);

    const maxSerieIndex = series.length;
    for (let start = 0; start <= maxSerieIndex; start++) {
      this.seriesGroup
        .selectAll(`.${classPrefix}-chart-series-${start}`)
        .raise();
    }
  }

  private timer: NodeJS.Timeout;

  private onMouseMove(x: number, y: number) {
    const tooltipEnable = this.ctx.getOption("tooltip.enable");
    if (tooltipEnable === false) return;
    const data = this.getData(x, y);
    if (data) {
      const allData = this.model.getAllData();
      this.helpers.tooltip.show(data, allData);
      clearTimeout(this.timer);
      this.drawHover(data);

      if (this.ctx.getOption("interaction.element-hover")) {
        if (this.currentHoverIndex !== data.index) {
          this.ctx.emit("interaction.hover", data.metaData);
          this.currentHoverIndex = data.index;
        }
      }
    } else {
      this.removeHover();
    }
  }

  /**
   * 根据坐标获取数据
   * @since 2.0
   * @param x x 坐标
   * @param y y 坐标
   */
  public getData(x: number, y?: number): EventData {
    const scale = this.allCategoryScale as ScalePoint<string>;
    if (!scale) {
      return {
        x: 0,
        y: 0,
        metaData: [],
        index: 0,
        category: "default",
      };
    }

    const domain = scale.domain();
    let index = getCategoryIndex(x, scale, "Point");
    const xValue = domain[index];
    const xPos = xValue ? scale(xValue) : x;

    if (index < 0 || Number.isNaN(index)) return null;

    if (index > domain.length - 1) {
      index = domain.length - 1;
    }

    const alias = this.ctx.getOption(`scale.${this.valueKey}.alias`);
    const metaData: MetaData[] = [];

    const values = this.model.getDataFromCategoryName(xValue, false, false);
    if (values.length === 0) return null;

    for (const { serieName, value, origin, colorName } of values) {
      metaData.push({
        title: xValue,
        label: alias || (this.serieKey === null ? this.valueKey : serieName),
        serieName,
        valueText: typeof value === "number" ? format(",")(value) : "-",
        color: this.colorScale(colorName),
        value,
        row: origin,
      });
    }

    const [{ value }] = values;

    return {
      x: xPos,
      y: y === undefined ? this.valueScale(value) : y,
      category: xValue,
      metaData,
      index,
    };
  }

  /**
   * 通过分类坐标名获取数据
   * @param category
   */
  public getDataFromCategory(category: string): MetaData[] {
    const alias = this.ctx.getOption(`scale.${this.valueKey}.alias`);
    const metaData: MetaData[] = [];

    const values = this.model.getDataFromCategoryName(category, false, false);
    if (values.length === 0) return null;

    for (const { serieName, value, origin, colorName } of values) {
      metaData.push({
        title: category,
        label: alias || (serieName === "default" ? this.valueKey : serieName),
        serieName,
        valueText: typeof value === "number" ? format(",")(value) : "-",
        color: this.colorScale(colorName),
        value,
        row: origin,
      });
    }

    return metaData;
  }

  /**
   * 通过值获取坐标
   * @param category 分类值
   * @param value 数据值
   */
  public getPosition(category: string, value: number) {
    const categoryScale = this.categoryScale as ScalePoint<string>;
    return [categoryScale(category), this.valueScale(value)];
  }

  /**
   * 绘制标记线和标记点
   * @param eventData 当前数据点信息
   * @since 2.0
   * @todo 修复最后一个点不显示的问题
   */
  private drawHover(eventData: EventData) {
    const { x, category, metaData } = eventData;
    const offsetY = parseInt(this.ctx.plotBackgound.attr("y"), 10);
    const height = parseInt(this.ctx.plotBackgound.attr("height"), 10);

    clearTimeout(this.timer);

    this.timer = setTimeout(() => {
      // 绘制标记线
      this.crosshair
        .attr("d", `M${x},${offsetY}L${x},${height + offsetY}`)
        .attr("visibility", "visible");
      const markers = this.seriesGroup.selectAll(
        `.${this.ctx.classPrefix}-chart-markers`
      );
      markers.selectAll("circle").attr("opacity", 0);
      markers
        .selectAll("circle")
        .data(metaData)
        .join("circle")
        .attr("class", `${this.ctx.classPrefix}-chart-point`)
        .attr("r", 4)
        .attr("stroke", ({ color }) => color)
        .attr("fill", "#FFF")
        .attr("stroke-width", 2)
        .attr("opacity", 1)
        .attr("visibility", ({ value }) =>
          value === null ? "hidden" : "visible"
        )
        .attr("transform", ({ serieName }) => {
          const x = (this.allCategoryScale as ScalePoint<string>)(category);
          const value = this.model.get(category, serieName);
          const y = this.valueScale(value);
          return `translate(${x}, ${y})`;
        });
    }, 0);
  }

  /**
   * 隐藏标记线和标记点
   * @since 2.0
   */
  private removeHover() {
    this.crosshair.attr("visibility", "hidden");
    this.seriesGroup
      .selectAll(`.${this.ctx.classPrefix}-chart-markers circle`)
      .attr("opacity", "0");
    this.helpers.tooltip.hide();
  }

  /**
   * 监听图例事件
   * @param legendData LegendData
   */
  private onLegendItemHover({ key }) {
    this.highlightKey = key;
    if (this.canvasMode) {
      this.drawSeries();
    } else {
      this.seriesGroup
        .selectAll(`.${this.ctx.classPrefix}-chart-series`)
        .call(g => {
          g.each(function highlight(groupKey) {
            const ele = select(this);
            if (groupKey === key) {
              ele.attr("opacity", 1);
            } else {
              ele.attr("opacity", 0.1);
            }
          });
        });
    }
  }

  /**
   * 监听图例事件
   * @param legendData LegendData
   */
  private onLegendItemLeft() {
    this.highlightKey = null;
    if (this.canvasMode) {
      this.drawSeries();
    } else {
      this.seriesGroup
        .selectAll(`.${this.ctx.classPrefix}-chart-series`)
        .call(g => {
          g.each(function highlight() {
            const ele = select(this);
            ele.attr("opacity", 1);
          });
        });
    }
  }

  /**
   * 图例点击事件
   * @param legendData 被点击的图例信息
   * @param disabled 改图例元素是否是禁用状态
   */
  private onLegendClick(legendData: LegendData, disabled: boolean) {
    const { key } = legendData;
    if (disabled) {
      this.disabledKeys.push(key);
    } else {
      this.disabledKeys = this.disabledKeys.filter(d => d !== key);
    }
    this.model.filterColumns(this.disabledKeys);
    this.draw(false);
  }

  private onClick(x: number, y: number) {
    const mappedData = this.getData(x, y);
    if (mappedData) {
      this.ctx.emit("click", mappedData);
    }
  }

  private onZoom(range: string[]) {
    this.model.range(range);
    this.draw(false, false, true);
  }

  private onZoomReset() {
    this.draw();
  }
}
