import { Context } from "./context";
import { uniqueId } from "./lib/unique-id";
import { RectCoordinate } from "./coordinates/rect-coord";
import { Line } from "./shapes/line";
import { Legend } from "./helpers/legend";
import { Helpers } from "./type/helpers";
import { DataSource } from "./type/data";
import { Theme } from "./type/theme";
import {
  ScaleOptions,
  TooltipOptions,
  LegendOptions,
  InteractionType,
} from "./type/options";
import { Coordinates } from "./type/coordinates";
import { Tooltip } from "./helpers/tooltip";
import { Bar } from "./shapes/bar";
import { Pie } from "./shapes/pie";
import { PolarCoordinate } from "./coordinates/polar-coord";
import { Selection } from "./helpers/selection";
import { Events } from "./event";
import { Annotation } from "./helpers/annotation";
import { Area, Map } from "./shapes";

const noop = () => {};

export class Chart {
  /**
   * 图表实例 ID
   * @since 2.0
   */
  public id: string;

  /**
   * 全局上下文
   * @since 2.0
   */
  public ctx: Context;

  /**
   * 坐标系实例
   * @since 2.0
   */
  private coordinates: Coordinates = {};

  /**
   * 图形实例集合
   * @since 2.0
   */
  private shape: Line | Bar | Pie | Map;

  /**
   * 辅助图层/功能实例集合
   * @since 2.0
   */
  private helpers: Helpers = {};

  /**
   * 图表事件管理对象
   * @since 2.0
   */
  private events: Events;

  /**
   * 注释管理对象
   * @since 2.0
   */
  private annotations: Annotation;

  /**
   * Resize 的时间计时器
   * @since 2.0
   */
  private resizeTimer: NodeJS.Timeout;

  /**
   * 初始化图表
   * @param container HTML 根元素
   * @param customTheme 主题配置
   */
  public constructor(
    container: HTMLElement,
    customTheme?: Theme,
    context?: Context
  ) {
    this.id = uniqueId("chart_");
    this.ctx = context || new Context(this.id, container, customTheme);
    this.helpers.legend = new Legend(this.ctx);
    this.helpers.tooltip = new Tooltip(this.ctx);
    this.helpers.selection = new Selection(this.ctx);
    this.helpers.annotation = new Annotation(this.ctx);
    this.events = new Events(this.ctx, this.helpers);
  }

  /**
   * 设置数据源
   * @param dataSource 原始数据源
   * @since 2.0
   */
  public source(dataSource: DataSource) {
    this.ctx.setDataSource(dataSource);
    return this;
  }

  /**
   * 设置主题
   * @param config 主题选项
   * @since 2.0
   */
  public theme(config: Theme) {
    if (typeof config === "object" && !Array.isArray(config)) {
      this.ctx.setTheme(config);
    }
    return this;
  }

  /**
   * 设置数据源的列
   * @param scaleCfg 列定义
   * @since 2.0
   */
  public scale(scaleCfg: ScaleOptions) {
    if (scaleCfg) {
      this.ctx.setOption("scale", scaleCfg);
    }
    return this;
  }

  /**
   * 设置提示框
   * @param enable 是否显示提示框
   * @param TooltipCfg 提示框配置
   * @since 2.0
   */
  public tooltip(
    enable: boolean | TooltipOptions,
    TooltipCfg: TooltipOptions = {}
  ) {
    const cfg: TooltipOptions =
      typeof enable === "boolean" ? { enable, ...TooltipCfg } : { ...enable };
    cfg.enable = typeof cfg.enable === "boolean" ? cfg.enable : true;
    this.ctx.setOption("tooltip", cfg);
    return this;
  }

  /**
   * 设置图例
   * @param enable 是否显示图例
   * @param legendCfg 图例配置
   * @since 2.0
   */
  public legend(
    enable: boolean | LegendOptions,
    legendCfg: LegendOptions = {}
  ) {
    const cfg: LegendOptions =
      typeof enable === "boolean" ? { enable, ...legendCfg } : { ...enable };
    cfg.enable = typeof cfg.enable === "boolean" ? cfg.enable : true;
    this.ctx.setOption("legend", cfg);
    return this;
  }

  /**
   * 交互事件
   * @param type 交互类型
   * @param extra 交互类型额外参数
   * @since 2.1.0
   */
  public interaction(type: InteractionType, extra: any = {}) {
    this.ctx.setOption(`interaction.${type}`, extra);
    return this;
  }

  /**
   * 注释
   *
   * @since 2.1.0
   */
  public annotation() {
    return this.helpers.annotation;
  }

  public line() {
    if (!this.coordinates.rect) {
      this.coordinates.rect = new RectCoordinate(this.ctx, this.helpers);
    }
    const line = new Line(this.ctx, this.coordinates.rect, this.helpers);
    this.shape = line;
    return line;
  }

  public area() {
    if (!this.coordinates.rect) {
      this.coordinates.rect = new RectCoordinate(this.ctx, this.helpers);
    }
    const area = new Area(this.ctx, this.coordinates.rect, this.helpers);
    this.shape = area;
    return area;
  }

  public bar() {
    if (!this.coordinates.rect) {
      this.coordinates.rect = new RectCoordinate(this.ctx, this.helpers);
    }
    const bar = new Bar(this.ctx, this.coordinates.rect, this.helpers);
    this.shape = bar;
    return bar;
  }

  public pie() {
    if (!this.coordinates.polar) {
      this.coordinates.polar = new PolarCoordinate(this.ctx, this.helpers);
    }
    const pie = new Pie(this.ctx, this.coordinates.polar, this.helpers);
    this.shape = pie;
    return pie;
  }

  public map() {
    const map = new Map(this.ctx, this.helpers);
    this.shape = map;
    return map;
  }

  /**
   * 开始渲染
   * @since 2.0
   */
  public render() {
    const { width: widthStr, height: heightStr } = window.getComputedStyle(
      this.ctx.container
    );
    const width = widthStr === "auto" ? 0 : parseInt(widthStr, 10);
    const height = heightStr === "auto" ? 0 : parseInt(heightStr, 10);

    if (Number.isNaN(width) || Number.isNaN(height)) return;

    this.updateSize(width, height);
    if (this.shape) {
      this.shape.draw();
      this.helpers.annotation.draw();
      this.reorder();
      this.ctx.emit("chart.rendered");
    }
  }

  /**
   * 销毁图表实例
   * @since 2.0
   */
  public destroy() {
    // this.ctx.container.innerHTML = "";
    this.helpers.tooltip.hide();
    // this.ctx.removeAllListeners();
    // this.ctx.setOption("interaction", {});
  }

  /**
   * 监听事件
   * @param eventName 事件名
   * @param callback 事件回调函数
   * @callback TeaChart.EventListenerCallback
   * @since 2.0
   */
  public on(eventName: string, callback = noop) {
    this.ctx.addListener(eventName, callback);
  }

  /**
   * 发送事件
   * @param eventName 事件名
   * @param eventData 事件数据
   * @since 2.0
   */
  public emit(eventName: string, eventData?: any) {
    this.ctx.emit(eventName, eventData);
  }

  /**
   * 监听事件
   * @param eventName 事件名
   * @param callback 事件回调函数
   * @callback TeaChart.EventListenerCallback
   * @since 2.0
   */
  public once(eventName: string, callback = noop) {
    this.ctx.once(eventName, callback);
  }

  /**
   * 删除事件绑定
   * @param eventName 事件名
   * @param callback 事件回调函数
   * @callback TeaChart.EventListenerCallback
   * @since 2.3
   */
  public off(eventName: string, callback = noop) {
    this.ctx.off(eventName, callback);
  }

  /**
   * 重置尺寸
   * @since 2.0
   */
  public resize() {
    clearTimeout(this.resizeTimer);
    this.resizeTimer = setTimeout(() => {
      this.render();
    }, 500);
  }

  /**
   * 更新图表尺寸
   * @private
   * @event chart.sizeUpdated
   * @since 2.0
   */
  private updateSize(width: number, height: number) {
    this.ctx.root
      .attr("width", width)
      .attr("height", height)
      .attr("viewBox", `0 0 ${width} ${height}`);

    this.ctx.background
      .attr("x", 0)
      .attr("y", 0)
      .attr("width", width)
      .attr("height", height);

    this.ctx.emit("chart.sizeUpdated", { width, height });
  }

  /**
   * 重新按照元素的 data-z-index 属性排列各个图层
   * @since 2.0
   */
  private reorder() {
    const maxIndex = 7;
    for (let start = 0; start <= maxIndex; start++) {
      this.ctx.root.selectAll(`[data-z-index="${start}"]`).raise();
    }
  }
}
