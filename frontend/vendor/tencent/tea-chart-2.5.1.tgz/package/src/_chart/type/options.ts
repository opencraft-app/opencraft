import { MetaData, DataLeaf, LegendData } from "./data";
import { AxisTick, AxisLabel } from "./axis";

/**
 * 坐标轴
 */
export interface AxisOptions {
  /**
   * 是否显示坐标轴
   * @since 2.0
   */
  enable?: boolean;

  /**
   * 坐标轴标题
   * @since 2.0
   */
  title?: {
    /**
     * 文本内容
     */
    text?: string;

    /**
     * 样式
     */
    style?: string;
  };

  /**
   * 坐标轴标签格式化（废弃，请使用 axisLabel.formatter）
   * @since 2.0
   * @param label 标签文本
   * @param index 当前标签的索引值
   *
   * @returns 修改后的标签文本
   *
   * @deprecated 2.0
   */
  formatter?: (
    label: string | number | { valueOf(): number },
    index: number,
    value: string | number
  ) => string;

  /**
   * 坐标轴刻度设置
   * @since 2.0
   */
  axisTick?: AxisTick;

  /**
   * 坐标轴标签设置
   * @since 2.0
   */
  axisLabel?: AxisLabel;
}

/**
 * 图例
 */
export interface LegendOptions {
  /**
   * 是否显示图例
   * @since 2.0
   */
  enable?: boolean;
  /**
   * 图例区位置
   * @since 2.0
   * @default bottom
   */
  align?: "right" | "bottom";
  /**
   * 图例标签格式化
   * @since 2.0
   * @param label 图例的文本
   * @param index 当前图例的索引值
   * @isLast 是否为最后一个图例
   *
   * @returns 修改后的图例文本
   */
  formatter?: (
    label: string,
    index: number,
    isLast: boolean,
    values: LegendData[]
  ) => string;
  /**
   * 自定义图例，图例数据会通过回调函数传递
   *
   * @since 2.4
   * @param legendData 图例数据
   */
  custom?: (legendData: LegendData[]) => void;

  /**
   * 图例区域最大宽度
   * @since 2.5
   */
  maxWidth?: string | number;
  /**
   * 图例区域最大高度
   * @since 2.5
   */
  maxHeight?: string | number;
  /**
   * 图例区域指定宽度
   * @since 2.5
   */
  width?: string | number;
  /**
   * 图例区域指定高度
   * @since 2.5
   */
  height?: string | number;

  /**
   * 图例上移高度
   * @since 2.5
   */
  shiftUp?: number;
}

/**
 * 提示框
 */
export interface TooltipOptions {
  /**
   * 是否显示提示框
   * @since 2.0
   */
  enable?: boolean;
  /**
   * 数据格式化
   * @since 2.0
   * @param values 当前列的元信息列表
   * @param index 当前列的列索引值
   *
   * @returns 修改后的元信息或 HTML 文本字符串
   */
  formatter?: (
    values: MetaData[],
    index: number,
    allData: DataLeaf[][]
  ) => MetaData[] | string;

  /**
   * 宽度
   * @since 2.4.5
   */
  width?: number;

  /**
   * 高度
   * @since 2.4
   */
  height?: number;

  /**
   * 最大高度
   * @since 2.4
   */
  maxHeight?: number;

  /**
   * 支持虚拟滚动，大数据量时可开启
   * @since 2.4.5
   */
  virtualizedScroll?: boolean;

  /**
   * tooltips的zIndex设置，默认1002，大于modal的1001
   * @default 1002
   */
  zIndex?: number;

  /**
   * 支持排序功能
   */
  enableSort?: boolean;

  /**
   * 排序表头文本字段
   */
  header?: {
    /**
     * 类型描述文本
     */
    typeText?: string;

    /**
     * 值描述文本
     */
    valueText?: string;
  };
}

/**
 * 列定义
 */
export interface ScaleOptions {
  /**
   * 系列别名
   * @since 2.0
   */
  alias?: string;
  /**
   * 数据的值域，值域的值尽量设置为 5 或 10 的整数倍，请勿将 domain 设置为 [0, 0]
   *
   * @default auto
   * @since 2.0
   */
  domain?: [number, number] | "autofit";
  /**
   * 是否为堆叠
   * @default false
   * @since 2.0
   */
  stack?: boolean | "stack" | "percent";

  /**
   * 指定比例尺类型，若指定为 time，则坐标轴会自动按时间排序
   *  @default "category"
   * @since 2.0
   */
  type?: "category" | "time";

  /**
   * 若 `type` 指定为 time，则需要指定时间解析格式，例如： "HH:mm"，同 Momentjs
   * @since 2.0
   */
  timeParseFormat?: string;

  /**
   * 显示堆叠总数
   */
  stackLabels?: {
    enable?: boolean;
  };
}

/**
 * 连接空值的配置
 * @since 2.0
 */
export interface ConnectNullsOptions {
  /**
   * 是否连接空值
   * @since 2.0
   */
  enable?: boolean;
}

export interface DataLabels {
  /**
   * 是否显示数据标签
   * @since 2.0
   * @default false
   */
  enable?: boolean;

  /**
   * 数据标签格式化
   */
  formatter?: (value: number, index: number, datum: DataLeaf) => string;
}

export interface ShapeOptions {
  /**
   * 数据标签
   */
  dataLabels?: DataLabels;

  /**
   * 是否为平滑曲线
   * @type line
   * @since 2.10
   */
  smooth?: boolean;

  /**
   * 支持开启Canvas，优化大数据卡顿问题
   */
  canvasMode?: boolean;
}

export interface ZoomOptions {
  /**
   * 重置按钮的文本（默认已加入 i18n）
   * @since 2.0
   */
  resetText?: string;
}

/**
 * 交互事件类型
 */
export type InteractionType =
  | "element-select"
  | "element-hover"
  | "zoom"
  | "brush";

/**
 * 交互事件类型选项
 */
export type InteractionOptions = {
  [type in InteractionType]?: {
    [option: string]: ZoomOptions | any;
  };
};

/**
 * 地图类型
 */
export type MapType = "china" | "world";

/**
 * 语言类型, 目前仅支持中英文
 */
export type Language = "en" | "zh";
