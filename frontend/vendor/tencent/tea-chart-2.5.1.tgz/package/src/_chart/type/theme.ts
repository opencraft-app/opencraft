export interface Theme {
  /**
   * 样式类前缀
   * @since 2.0
   */
  classPrefix?: string;

  /**
   * 图表高度
   * @since 2.0
   */
  height?: number;

  /**
   * 图表颜色序列
   * @since 2.0
   */
  color?: string[] | ((key: string, index: number, isLast: boolean) => string);

  /**
   * 默认颜色
   * @since 2.0
   */
  defaultColor?: string[];

  /**
   * 禁用状态的颜色
   * @since 2.0
   */
  disabledColor?: string;

  /**
   * 背景色
   * @since 2.4
   */
  backgroundColor?: string;

  /**
   * X 轴
   * @since 2.0
   */
  xAxis?: AxisTheme;

  /**
   * Y 轴
   * @since 2.0
   */
  yAxis?: AxisTheme;

  /**
   * 边距
   * @since 2.0
   */
  padding?: {
    top: number;
    left: number;
    bottom: number;
    right: number;
  };

  legend?: {
    height?: number;
    rect?: {
      height: number;
      width: number;
    };
    circle?: {
      radius: number;
    };
    square?: {
      width: number;
    };
    text?: {
      fontSize: number;
      color: string;
      disabledColor: string;
    };
  };

  /**
   * 交互样式
   * @since 2.3.0
   */
  interaction?: InteractionStyle;
}

export interface AxisTheme {
  /**
   * 栅格线颜色
   * @since 2.0
   */
  gridLineColor?: string;

  /**
   * 栅格线宽度
   * @since 2.0
   */
  grindLineWidth?: number;
  /**
   * 主轴线颜色
   * @since 2.0
   */
  majorGridLineColor?: string;
  /**
   * 刻度颜色
   * @since 2.0
   */
  tickColor?: string;
  /**
   * 刻度长度
   * @since 2.0
   */
  tickLength?: number;
  /**
   * 标签文本颜色
   */
  labelColor?: string;
  /**
   * 标签文本字体大小
   */
  labelFontSize?: string;
}

/**
 * 交互状态样式
 */
export interface InteractionStyle {
  /**
   * 选中样式
   */
  selected?: {
    /**
     * 填充颜色
     */
    fill?: string;
    /**
     * 透明度
     */
    opacity?: number;
  };
}
