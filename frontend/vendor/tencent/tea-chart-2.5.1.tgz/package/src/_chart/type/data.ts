export type ShapeType = "line" | "bar" | "pie";

/**
 * 指定的数据点元信息
 */
export interface MetaData {
  /**
   * 数据值
   * @since 2.0
   */
  value: number;
  /**
   * 数据文本
   */
  valueText: string;
  /**
   * 数据点颜色
   * @since 2.0
   */
  color?: string;
  /**
   * 数据点标签文本
   * @since 2.0
   */
  label?: string;
  /**
   * 系列名
   * @since 2.0
   */
  serieName?: string;
  /**
   * 标题
   * @since 2.0
   */
  title?: string;
  /**
   * 若作为占比，则为该数据点的占比值
   * @since 2.0
   */
  percentage?: number;
  /**
   * 该行数据的值信息
   * @since 2.0
   */
  row?: Data;
}

/**
 * 事件数据
 */
export interface EventData {
  /**
   * x 位置
   * @since 2.0
   */
  x: number;
  /**
   * y 位置
   * @since 2.0
   */
  y: number;
  /**
   * 分类数据
   */
  category: string;
  /**
   * 该点的元信息
   * @since 2.0
   */
  metaData: MetaData[];
  /**
   * 索引
   * @since 2.0
   */
  index: number;
}

/**
 * 原始数据行
 * @since 2.0
 */
export interface Data {
  [key: string]: number | string | null;
}

/**
 * 原始数据
 * @since 2.0
 */
export type DataSource = Data[];

/**
 * 加工成行列式的数据节点
 * @since 2.0
 */
export interface DataLeaf {
  /**
   * 原始值
   * @since 2.0
   */
  value: number;
  /**
   * 数据堆叠后的值
   * @since 2.0
   */
  stackValue?: number;
  /**
   * 行名
   * @since 2.0
   */
  category?: string;
  /**
   * 颜色名
   */
  colorName: string;
  /**
   * 列名
   * @since 2.0
   */
  serieName: string;
  /**
   * 原始数据
   * @since 2.0
   */
  origin?: Data;

  /**
   * 按分类的百分比
   * @since 2.0
   */
  percent?: number;

  /**
   * 百分比堆叠后的值
   * @since 2.0
   */
  stackPercent?: number;
}

/**
 * 图例数据
 * @since 2.0
 */
export interface LegendData {
  /**
   * 图例文本
   * @since 2.0
   */
  label: string;
  /**
   * 图例颜色
   * @since 2.0
   */
  color: string;
  /**
   * 图例对应的字段名
   * @since 2.0
   */
  key: string;
  /**
   * 图例映射的数据系列类型，如折线、柱状图
   * @since 2.0
   */
  type: ShapeType;

  /**
   * 索引
   * @since 2.0
   */
  index: number;

  /**
   * 当前数据系列的数据
   */
  values: DataLeaf[];

  /**
   * 统计数据
   */
  stat: {
    /**
     * 该数据系列的值之和
     */
    sum: number;
    /**
     * 该数据系列的值占比
     */
    percent: number;
  };
}
