/**
 * 坐标轴刻度设置
 * @since 2.0
 */
export interface AxisTick {
  /**
   * 坐标轴刻度间隔
   * @since 2.0
   */
  interval?: number;
}

/**
 * 坐标轴刻度设置
 * @since 2.0
 */
export interface AxisLabel {
  /**
   * 坐标轴标签格式化
   * @since 2.0
   * @param label 标签文本
   * @param index 当前标签的索引值
   * @param value 数据源原始值
   *
   * @returns 修改后的标签文本
   */
  formatter?: (
    label: string | number | { valueOf(): number },
    index: number,
    value: string | number
  ) => string;
}
