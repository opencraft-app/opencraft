import { Legend } from "../helpers/legend";
import { Tooltip } from "../helpers/tooltip";
import { Selection } from "../helpers/selection";
import { Annotation } from "../helpers/annotation";

/**
 * 所有辅助图层/功能区
 * @todo 待补齐 Label, Legend, Tooltip, Selection, annotation
 */
export interface Helpers {
  label?: any;
  legend?: Legend;
  tooltip?: Tooltip;
  selection?: Selection;
  annotation?: Annotation;
}
