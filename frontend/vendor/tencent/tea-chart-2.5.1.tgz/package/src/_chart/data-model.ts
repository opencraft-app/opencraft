import { Nest, NestedObject, nest, sum } from "d3";
import { DataSource, Data, DataLeaf } from "./type/data";

/**
 * 图表数据模型
 */
export class DataModel {
  /**
   * 原始数据
   * @since 2.0
   */
  public raw: DataSource = [];

  /**
   * 原始数据中作为行字段的 key 值
   * 行字段的值在直角坐标系中一般作为 X 轴的值
   * @since 2.0
   */
  public categoryKey: string;

  /**
   * 原始数据中作为列字段的 key 值
   * @since 2.0
   */
  public serieKey: string;

  /**
   * 原始数据中作为值字段的 key 值
   * @since 2.0
   */
  public valueKey: string;

  /**
   * 原始数据中作为颜色字段的 key 值
   * @since 2.0
   */
  public colorKey: string;

  /**
   * 是否为堆叠数据
   * @since 2.0
   */
  public stack: boolean = false;

  /**
   * 堆叠的类型
   * @since 2.0
   */
  public stackType: "stack" | "percent" = "stack";

  /**
   * 行字段值排序
   * @since 2.0
   */
  public sortKeys: (a: string, b: string) => number;

  /**
   * 行列式数据生成器
   * @private
   * @since 2.0
   */
  private determinantOperator: Nest<Data, DataLeaf>;

  /**
   * 被行列式数据生成器加工后的数据表
   * @private
   * @since 2.0
   */
  private dataTable: NestedObject<Data, DataLeaf>;

  /**
   * 过滤的列名
   * @private
   * @since 2.0
   */
  private filterColumnNames: string[] = [];

  /**
   * 过滤后的数据表
   * @private
   * @since 2.0
   */
  private filterDataTable: NestedObject<Data, DataLeaf>;

  /**
   * 分类的范围，用于数据缩放
   * @private
   * @since 2.0
   */
  private categoryRange: string[] = [];

  /**
   * 值域的缓存
   * @private
   * @since 2.0
   */
  private extentCache: [number, number] = null;

  /**
   * 定义数据模型，根据 Key 生成对应的行列式生成器
   *
   * @param categoryKey 原始字段用作行的字段名，对应 category
   * @param valueKey 原始数据中作为值的字段名，对应 value
   * @param serieKey 原始字段中作为列的字段名，用于分类，对应 series
   * @param sortKeys 行字段值的排序方式
   * @param stack 是否为堆积图
   *
   * @since 2.0
   */
  public define(
    categoryKey: string,
    valueKey: string,
    serieKey: string,
    colorKey: string,
    sortKeys?: (a: string, b: string) => number,
    stack: boolean = false,
    stackType: "stack" | "percent" = "stack"
  ) {
    this.valueKey = valueKey;
    this.serieKey = serieKey;
    this.categoryKey = categoryKey;
    this.colorKey = colorKey;
    this.sortKeys = sortKeys;
    this.stack = stack;
    this.stackType = stackType;

    let currentRow: string;
    let positive = 0;
    let negative = 0;

    // 生成行列式数据生成器
    this.determinantOperator = nest<Data, DataLeaf>()
      .key(v => {
        if (v && typeof v[categoryKey] !== "undefined") {
          return String(v[categoryKey]);
        }
        return "default";
      })
      .key(v => {
        if (v && typeof v[serieKey] !== "undefined") {
          return String(v[serieKey]);
        }
        return "default";
      })
      // 处理每个数据点
      .rollup(leaves => {
        const [first = {}] = leaves || [];
        const category = String(first[this.categoryKey]) || "default";
        const isFirst = currentRow !== category;
        const value =
          typeof first[this.valueKey] === "number"
            ? Number(first[this.valueKey])
            : null;
        let stackValue = value;
        if (isFirst) {
          currentRow = category;
          positive = 0;
          negative = 0;
        }
        if (value >= 0) {
          stackValue = value + positive;
          positive = stackValue;
        } else {
          stackValue = value + negative;
          negative = stackValue;
        }
        return {
          value,
          stackValue,
          category,
          serieName:
            typeof first[this.serieKey] !== "undefined"
              ? String(first[this.serieKey])
              : "default",
          origin: first,
          colorName:
            typeof first[this.colorKey] !== "undefined"
              ? String(first[this.colorKey])
              : "default",
        };
      });

    this.dataTable = this.determinantOperator.object(this.raw);
    this.filterDataTable = Object.assign({}, this.dataTable);
    this.extentCache = null;

    // 每次调用 determinantOperator 需要重置累计值
    currentRow = null;
    positive = 0;
    negative = 0;
  }

  /**
   * 修改原始数据
   * @param dataSource 原始数据
   * @since 2.0
   */
  public source(dataSource?: DataSource) {
    if (dataSource && Array.isArray(dataSource)) {
      // 过滤掉无效数据
      this.raw = dataSource.filter(i => !!i);
    }
  }

  /**
   * 根据列字段值过滤数据表
   * @param serieNames 保留数据的列字段值
   * @since 2.0
   */
  public filterColumns(serieNames: string[]) {
    this.filterColumnNames = serieNames;
    const filterDataSource = this.raw.filter(
      item => !this.filterColumnNames.includes(String(item[this.serieKey]))
    );
    this.filterDataTable = this.determinantOperator.object(filterDataSource);
    if (this.categoryRange) {
      // 重新设置过滤的时候还需要处理 Range
      this.range(this.categoryRange);
    }
    this.extentCache = null;
  }

  /**
   * 设置保留的行
   * @param categories 保留的行
   * @since 2.0
   */
  public range(categories: string[]) {
    this.categoryRange = categories;
    if (Array.isArray(categories) && categories.length > 0) {
      const newDataTable = {};
      this.filterDataTable = {};
      for (let i = 0; i < categories.length; i++) {
        const key = categories[i];
        if (this.dataTable[key]) {
          newDataTable[key] = this.dataTable[key];
        }
        this.filterDataTable[key] = newDataTable[key];
      }
      this.dataTable = newDataTable;
      this.extentCache = null;
    }
  }

  /**
   * 获取列名
   * @param getAll 是否包含过滤的列
   * @since 2.0
   */
  public getSerieNames(getAll?: boolean) {
    const cols = nest()
      .key(d =>
        typeof d[this.serieKey] !== "undefined"
          ? String(d[this.serieKey])
          : "default"
      )
      .entries(this.raw)
      .map(col => col.key);

    if (getAll) return cols;

    return cols.filter(col => !this.filterColumnNames.includes(col));
  }

  /**
   * 获取行名
   * @since 2.0
   */
  public getCategoryNames(allData?: boolean) {
    const rows = Object.keys(allData ? this.dataTable : this.filterDataTable);
    if (typeof this.sortKeys === "function") {
      // 优先使用 sortKeys 排序
      return rows.sort(this.sortKeys);
    }
    // row 已无序(Object.keys 以任意顺序返回 keys), 这里使用原始顺序
    // this.dataTable/filterDataTable 从 determinantOperator.object(this.raw)
    // 调用中而来, 我们以相同的生成步骤处理 raw 得到语义相同且顺序一致的结构
    const originRows = this.determinantOperator
      .entries(this.raw)
      .map(row => row.key);
    // 保证使用部分数据时, 元素的顺序仍然是稳定的
    return rows.sort((a, b) => originRows.indexOf(a) - originRows.indexOf(b));
  }

  /**
   * 根据字段名获取原始数据中所有的字段值
   * @param key 字段名
   */
  public getKeyNames(key: string) {
    const cols = nest()
      .key(d => (typeof d[key] !== "undefined" ? String(d[key]) : "default"))
      .object(this.raw);

    return Object.keys(cols);
  }

  /**
   * 计算值域
   * @param autoFit 是否获取最接近的阈值而非从 0 开始
   * @since 2.0
   */
  public getExtent(autoFit?: boolean) {
    if (this.extentCache !== null) return this.extentCache;
    let extentMin = autoFit ? null : 0;
    let extentMax = 0;
    const rows = Object.values(this.filterDataTable);
    for (const row of rows) {
      if (row) {
        const cols = Object.values(row);
        for (const col of cols) {
          const { value, stackValue } = col;
          const v = this.stack ? stackValue : value;
          if (v > extentMax) extentMax = v;
          if ((v < extentMin || extentMin === null) && v !== null)
            extentMin = v;
        }
      }
    }
    if (extentMin === extentMax) {
      extentMin = 0;
    }
    if (autoFit) {
      extentMin -= Math.round(extentMin * 0.1);
    }
    this.extentCache = [
      // 如果是自动适应或者最小值小于 0 则使用自适应值，否则以 0 作为最小值
      autoFit || extentMin < 0 ? extentMin || 0 : 0,
      extentMax || 10,
    ];
    return this.extentCache;
  }

  /**
   * 获取指定行列的值
   * @param categoryKey 行字段值
   * @param serieKey 列字段值
   * @param originValue 显示原始值
   * @param allData 使用全部的数据
   * @since 2.0
   */
  public get(categoryKey: string, serieKey: string, originValue?: boolean) {
    if (this.filterDataTable[categoryKey] === undefined) return null;
    const { value = null, stackValue = null } =
      this.filterDataTable[categoryKey][serieKey] || {};
    return this.stack && !originValue ? stackValue : value;
  }

  /**
   * 获取指定行列的值
   * @param categoryKey 行字段值
   * @param serieKey 列字段值
   * @param originValue 显示原始值
   * @param allData 使用全部的数据
   * @since 2.0
   */
  public getByAll(
    categoryKey: string,
    serieKey: string,
    originValue?: boolean
  ) {
    if (this.dataTable[categoryKey] === undefined) return null;
    const { value = null, stackValue = null } =
      this.dataTable[categoryKey][serieKey] || {};
    return this.stack && !originValue ? stackValue : value;
  }

  /**
   * 根据行字段的值获取某行数据
   * @param categoryKey 行字段值
   *
   * @todo 数据缓存
   */
  public getDataFromCategoryName(
    categoryKey: string,
    withPercent?: boolean,
    allData?: boolean
  ): DataLeaf[] {
    let values = [];
    const dataTable = allData ? this.dataTable : this.filterDataTable;
    if (dataTable[categoryKey]) {
      values = Object.values(dataTable[categoryKey]);
    }
    const total = sum(
      values.map((data: DataLeaf) => {
        return typeof data.value === "number" ? data.value : 0;
      })
    );
    if (withPercent) {
      let stackPercent = 0;
      return values.map((leaf: DataLeaf) => {
        const percent = (leaf.value / total) * 100;
        stackPercent += percent;
        return {
          ...leaf,
          percent,
          stackPercent,
        };
      });
    }
    return values;
  }

  /**
   * 根据列字段的值获取某列数据
   * @param serieKey 列字段值
   *
   * @todo 数据缓存
   */
  public getDataFromSerieName(serieKey: string): DataLeaf[] {
    const values = [];
    const cateValues = Object.values(this.dataTable);
    for (const v of cateValues) {
      if (v[serieKey]) {
        values.push(v[serieKey]);
      }
    }

    return values;
  }

  /**
   * 获取当前生效的全部数据
   */
  public getAllData(): DataLeaf[][] {
    const values = [];
    const serieNames = this.getSerieNames();
    for (const serie of serieNames) {
      values.push(this.getDataFromSerieName(serie));
    }
    return values;
  }
}
