import { select, event } from "d3";
import { Context } from "./context";
import { Helpers } from "./type/helpers";

/**
 * 图表事件管理对象
 * @since 2.0
 */
export class Events {
  private ctx: Context;

  private helpers: Helpers;

  /**
   * 是否为点击事件
   */
  private isClick: boolean = false;

  /**
   * 鼠标按下到抬起的时间，用以判断是否为点击事件
   */
  private mousedownTimer: number;

  public constructor(ctx: Context, helpers: Helpers) {
    this.ctx = ctx;
    this.helpers = helpers;
    this.init();
  }

  /**
   * 事件初始化
   */
  private init() {
    this.initGlobalEvents();
    this.initContainerEvents();
    this.initPlotEvents();
  }

  /**
   * 全局事件
   * @since 2.3
   */
  private initGlobalEvents() {
    select(window).on("wheel", () => {
      const { classPrefix } = this.ctx.theme;
      if (
        event &&
        event.relatedTarget &&
        event.relatedTarget.className !== `${classPrefix}-chart-tooltip`
      ) {
        this.ctx.emit("container.mouse.left", event.offsetX, event.offsetY);
      }
    });
  }

  /**
   * HTML 根元素事件
   * @since 2.0
   */
  private initContainerEvents() {
    // 根元素鼠标事件
    select(this.ctx.container)
      .on("mousemove touchmove", () => {
        // eslint-disable-next-line no-unused-expressions
        event && event.preventDefault();
        this.ctx.emit(
          "container.mouse.move",
          event && event.offsetX,
          event && event.offsetY
        );
      })
      .on("mouseleave touchend", () => {
        const { classPrefix } = this.ctx.theme;
        if (
          event &&
          event.relatedTarget &&
          event.relatedTarget.className !== `${classPrefix}-chart-tooltip`
        ) {
          this.ctx.emit("container.mouse.left", event.offsetX, event.offsetY);
        }
      })
      .on("mousedown", () => {
        this.mousedownTimer = new Date().valueOf();
        this.ctx.emit(
          "container.mouse.down",
          event && event.offsetX,
          event && event.offsetY
        );
      })
      .on("mouseup", () => {
        this.ctx.emit(
          "container.mouse.up",
          event && event.offsetX,
          event && event.offsetY
        );
        const timer = new Date().valueOf();
        if (timer - this.mousedownTimer < 200) {
          this.isClick = true;
        }
      })
      .on("click", () => {
        // eslint-disable-next-line no-unused-expressions
        event && event.preventDefault();
        if (this.isClick) {
          this.ctx.emit(
            "container.mouse.click",
            event && event.offsetX,
            event && event.offsetY
          );
          this.isClick = false;
        }
      });
  }

  /**
   * 初始化鼠标事件
   *
   * @since 2.0
   */
  private initPlotEvents() {
    // 监听鼠标移动事件
    this.ctx.on("container.mouse.move", (x: number, y: number) => {
      // 如果 hover 到了非 svg 元素上需要忽略
      if (typeof event.target.className === "string") return;

      const plotX = Number(this.ctx.plotBackgound.attr("x"));
      const plotY = Number(this.ctx.plotBackgound.attr("y"));
      const plotWidth = Number(this.ctx.plotBackgound.attr("width"));
      const plotHeight = Number(this.ctx.plotBackgound.attr("height"));
      const outBound =
        y > plotY + plotHeight ||
        y < plotY ||
        x > plotX + plotWidth ||
        x < plotX;

      if (outBound) {
        this.ctx.emit("plot.mouse.left");
      } else {
        this.ctx.emit("plot.mouse.move", x, y);
      }
    });
    // 监听鼠标离开事件
    this.ctx.on("container.mouse.left", () => {
      this.ctx.emit("plot.mouse.left");
    });
    // 监听鼠标点击事件
    this.ctx.on("container.mouse.click", (x: number, y: number) => {
      const plotX = Number(this.ctx.plotBackgound.attr("x"));
      const plotY = Number(this.ctx.plotBackgound.attr("y"));
      const plotWidth = Number(this.ctx.plotBackgound.attr("width"));
      const plotHeight = Number(this.ctx.plotBackgound.attr("height"));
      const outBound = y > plotY + plotHeight || x > plotX + plotWidth;
      if (!outBound) {
        this.ctx.emit("plot.mouse.click", x, y);
      }
    });
  }
}
