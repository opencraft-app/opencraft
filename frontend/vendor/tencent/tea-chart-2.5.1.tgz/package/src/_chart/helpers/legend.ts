import { Selection, ScaleOrdinal, select, event, sum } from "d3";
import { Context } from "../context";
import { LegendData, ShapeType } from "../type/data";
import { nodeWidth, nodeHeight } from "../lib/svg-helper";
import { LegendOptions } from "../type/options";
import { DataModel } from "../data-model";

export class Legend {
  /**
   * 过滤的数据系列名
   * @since 2.0
   */
  public disabledKeys: string[] = [];

  /**
   * 全局上下文
   * @since 2.0
   */
  private ctx: Context;

  /**
   * 图例对象
   * @since 2.0
   */
  private group: Selection<SVGGElement, {}, HTMLElement, {}>;

  /**
   * 图例项对象
   * @since 2.0
   */
  private itemGroup: Selection<SVGGElement, {}, HTMLElement, {}>;

  /**
   * 图例盒子对象
   * @since 2.0
   */
  private box: Selection<SVGRectElement, {}, HTMLElement, {}>;

  /**
   * 整个图例的高度
   * @since 2.0
   */
  public height: number = 0;

  /**
   * 整个图例区的宽度
   * @since 2.0
   */
  public width: number = 0;

  /**
   * 图例外层容器对象
   * @since 2.5
   */
  private container: Selection<HTMLElement, {}, HTMLElement, {}>;

  /**
   * 图例svg对象的高度
   * @since 2.5
   */
  public groupHeight: number = 0;

  /**
   * 图例svg对象的宽度
   * @since 2.5
   */
  public groupWidth: number = 0;

  public constructor(ctx: Context) {
    this.ctx = ctx;
    const { classPrefix, root, container } = this.ctx;
    this.container = select(container)
      .append("div")
      .style("overflow", "hidden auto")
      .style("position", `relative`);
    this.group = this.container
      .append("svg")
      .attr("data-z-index", "7")
      .attr("version", "1.1")
      .attr("xmlns", "http://www.w3.org/2000/svg")
      .style("-webkit-user-select", "none")
      .style("-moz-user-select", "none")
      .style("-ms-user-select", "none")
      .style("user-select", "none")
      .style("display", "block")
      .style("margin", "0 auto");
    this.box = this.group
      .append("rect")
      .attr("class", `${classPrefix}-chart-legend-box`)
      .attr("rx", "0")
      .attr("ry", "0")
      .attr("x", "0")
      .attr("y", "0")
      .attr("visibility", "visible")
      .attr("fill", "none");
    this.itemGroup = this.group.append("g").attr("data-z-index", "1");
  }

  /**
   *
   * @param serieScale 数据系列比例尺
   * @param valueKey
   */
  public update(
    serieScale: ScaleOrdinal<string, string>,
    valueKey: string,
    type: ShapeType,
    model: DataModel
  ) {
    const enable = this.ctx.getOption("legend.enable", true);
    const customLegend = this.ctx.getOption("legend.custom");
    const isCustom = typeof customLegend === "function";
    if (enable || isCustom) {
      const alias = this.ctx.getOption(`scale.${valueKey}.alias`);
      let legendData: LegendData[] = [];
      const domain = serieScale.domain();
      let total = 0;
      for (let i = 0; i < domain.length; i++) {
        const col = domain[i];
        const values = model.getDataFromSerieName(col);
        const valueSum = sum(values.map(i => i.value));
        total += valueSum;
        legendData.push({
          label: alias || (valueKey === "default" ? valueKey : col),
          color: serieScale(col),
          key: col,
          type,
          index: i,
          values,
          stat: {
            sum: valueSum,
            percent: 0,
          },
        });
      }
      legendData = legendData.map(i => {
        i.stat.percent = i.stat.sum / total;
        return i;
      });

      if (isCustom) {
        customLegend(legendData);
      }

      if (enable) {
        this.draw(legendData);
      } else {
        this.clear();
      }
    } else {
      this.clear();
    }
  }

  /**
   * 清空图例
   * @private
   */
  private clear() {
    const { classPrefix } = this.ctx;
    this.groupHeight = 0;
    this.height = 0;
    this.box.attr("height", this.groupHeight);
    this.group.attr("height", this.groupHeight);
    this.group.attr("viewBox", `0 0 ${this.groupWidth} ${this.groupHeight}`);
    this.itemGroup.selectAll(`.${classPrefix}-chart-legend-item`).remove();
  }

  private draw(legendData: LegendData[]) {
    const { classPrefix, theme } = this.ctx;
    const { text } = theme.legend;
    const chartWidth = parseInt(this.ctx.background.attr("width"), 10);
    const { formatter } = this.ctx.getOption("legend", {});
    const cls = `${classPrefix}-chart-legend-item`;

    // 清除所有的图例项
    this.itemGroup.selectAll(`.${cls}`).remove();

    const items = this.itemGroup.selectAll(`.${cls}`).data(legendData);

    let maxTextWidth = 0;
    const enter = items
      .enter()
      .append("g")
      .attr("class", (d: LegendData) => {
        return `${cls} ${classPrefix}-chart-${d.type}-series`;
      })
      .call(g => {
        // 图例的色块
        g.each(function node(d, i) {
          const legendItemGroup = select(this).style("cursor", "pointer");
          const generateText = () => {
            let text = d.label;
            if (formatter) {
              text = formatter(
                d.label,
                i,
                legendData.length - 1 === i,
                legendData
              );
            }
            return text;
          };

          // title气泡
          legendItemGroup.append("title").text(generateText);

          if (d.type === "line") {
            legendItemGroup
              .append("path")
              .attr("d", `M 0 11 L 16 11`)
              .attr("fill", "none")
              .attr("stroke", d.color)
              .attr("stroke-width", "2");
          }

          if (d.type === "pie") {
            legendItemGroup
              .append("rect")
              .attr("width", 12)
              .attr("height", 12)
              .attr("rx", 6)
              .attr("ry", 6)
              .attr("fill", d.color)
              .attr("y", 5);
          }

          legendItemGroup
            .append("text")
            .attr("x", 21)
            .attr("y", 15)
            .attr("text-anchor", "start")
            .attr("data-z-index", "2")
            .style("font-size", `${text.fontSize}px`)
            .style("color", text.color)
            .style("fill", text.color)
            .append("tspan")
            .text(generateText);

          const textWidth = nodeWidth(legendItemGroup.node());
          maxTextWidth = textWidth > maxTextWidth ? textWidth : maxTextWidth;
        });
      });

    const firstXOffset = 8;
    let xOffset = firstXOffset; // 每个图例项的 X 偏移量
    let yOffset = 3; // 每个图例项的 Y 偏移量
    const align = this.ctx.getOption("legend.align");
    items
      .merge(enter)
      .attr("transform", function setItemOffset() {
        if (align === "bottom") {
          const x = xOffset;
          xOffset += maxTextWidth + 20;
          if (xOffset > chartWidth) {
            xOffset = firstXOffset + maxTextWidth + 20;
            yOffset += text.fontSize * 2;
            return `translate(${firstXOffset}, ${yOffset})`;
          }
          return `translate(${x}, ${yOffset})`;
        }
        const x = xOffset;
        const y = yOffset;
        yOffset += text.fontSize * 2;
        return `translate(${x}, ${y})`;
      })
      .on("mouseenter", this.onLegendItemHover.bind(this))
      .on("mouseleave", this.onLegendItemLeft.bind(this))
      .on("click", this.onLegendItemClick.bind(this))
      .call(g => {
        g.selectAll("path").attr("fill", (d: LegendData) =>
          this.disabledKeys.find(k => k === d.key)
            ? text.disabledColor
            : d.color
        );
        g.selectAll("text").style("fill", (d: LegendData) =>
          this.disabledKeys.find(k => k === d.key)
            ? text.disabledColor
            : text.color
        );
      });

    this.groupWidth = Math.round(nodeWidth(this.itemGroup.node()) + 28);
    this.groupHeight = Math.round(nodeHeight(this.itemGroup.node()) + 6);
    this.box.attr("width", this.groupWidth);
    this.box.attr("height", this.groupHeight);
    this.group.attr("width", this.groupWidth);
    this.group.attr("height", this.groupHeight);
    this.group.attr("viewBox", `0 0 ${this.groupWidth} ${this.groupHeight}`);

    this.setPosition();
  }

  /**
   * 更新图例区的位置
   * @since 2.0
   */
  private setPosition() {
    const {
      align,
      width,
      height,
      maxWidth,
      maxHeight,
      shiftUp,
    } = this.ctx.getOption("legend") as LegendOptions;
    const { bottom, right, top } = this.ctx.theme.padding;
    const chartWidth = parseInt(this.ctx.background.attr("width"), 10);
    const chartHeight = parseInt(this.ctx.background.attr("height"), 10);
    let x: number;
    let y: number;
    // 设置 container 的 width, height, maxWidth, maxHeight
    this.container.style(
      "max-width",
      typeof maxWidth === "number"
        ? `${maxWidth}px`
        : maxWidth ??
            `${
              align === "bottom"
                ? chartWidth // 图例在下方，最大宽度需要默认撑开到最大，避免滚动条也居中了。
                : Math.min(this.groupWidth, chartWidth) // 图例在右方，最大宽度默认是图表实际宽度即可。
            }px`
    );
    this.container.style(
      "max-height",
      typeof maxHeight === "number"
        ? `${maxHeight}px`
        : maxHeight ?? `${Math.min(this.groupHeight, chartHeight)}px`
    );
    this.container.style(
      "width",
      typeof width === "number" ? `${width}px` : width ?? null
    );
    this.container.style(
      "height",
      typeof height === "number" ? `${height}px` : height ?? null
    );
    // 获取 container 实际高度，更新到 width, height
    const {
      width: containerWidth,
      height: containerHeight,
    } = this.container.node().getBoundingClientRect();
    this.width = containerWidth;
    this.height = containerHeight;

    if (align === "bottom") {
      x = Math.floor(chartWidth / 2) - Math.floor(this.width / 2);
      y = -bottom - this.height;
    } else if (align === "right") {
      x = chartWidth - right - this.width;

      // 图例高度小于图表高度，竖直居中
      if (this.height < chartHeight) {
        y =
          -chartHeight +
          Math.floor((chartHeight - top - bottom) / 2) -
          Math.floor(this.height / 2);
      } else {
        // 图例高度大于图表高度，顶到最高即可，展示滚动条
        y = -chartHeight;
      }
    }
    if (shiftUp) {
      y -= shiftUp;
    }

    this.container.style("left", `${x}px`);
    this.container.style("top", `${y}px`);
  }

  private onLegendItemHover(legendData: LegendData) {
    // 被禁用的元素不需要触发 Hover 事件
    if (this.disabledKeys.includes(legendData.key)) return;
    this.ctx.emit("legend.hover", legendData);
  }

  private onLegendItemLeft(legendData: LegendData) {
    this.ctx.emit("legend.left", legendData);
  }

  private onLegendItemClick(legendData: LegendData) {
    // eslint-disable-next-line no-unused-expressions
    event && event.stopPropagation();
    const { key } = legendData;
    const disabled = this.disabledKeys.findIndex(k => k === key) !== -1;
    const data = this.itemGroup
      .selectAll(`.${this.ctx.classPrefix}-chart-legend-item`)
      .data() as LegendData[];
    const index = data.findIndex(d => d.key === key);
    if (disabled) {
      this.disabledKeys = this.disabledKeys.filter(k => k !== key);
    } else {
      this.disabledKeys.push(key);
    }
    this.draw(data);
    this.ctx.emit("legend.clicked", data[index], !disabled);
    this.onLegendItemLeft(legendData);
  }
}
