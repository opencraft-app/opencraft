import { Selection } from "d3";
import { Context } from "../context";

/**
 * 注释
 */
export interface AnnotationBaseOptions {
  /**
   * 元素样式
   */
  textStyle?: string;

  /**
   * x 偏移量
   */
  offsetX?: number;

  /**
   * y 偏移量
   */
  offsetY?: number;
}

/**
 *  Annotation 位置相关属性的类型定义
 */
export type AnnotationPosition = [string | number, string | number];

export interface AnnotationLabelOptions extends AnnotationBaseOptions {
  /**
   * 文本内容
   */
  content?: string | number;

  /**
   * 位置
   */
  position?: AnnotationPosition;
}

export interface AnnotationLineOptions {
  /**
   * 起点位置
   */
  start: [number, number];
  /**
   * 终点位置
   */
  end: [number, number];
  /**
   * 样式
   */
  style?: {
    stroke?: string;
    lineWidth?: number;
    lineDash?: number[];
  };
  /**
   * 文本标签
   */
  text?: {
    position?: "start" | "end" | "center";
    textStyle?: string;
    content?: string;
    offsetX?: number;
    offsetY?: number;
    textAnchor?: "start" | "end" | "middle";
  };
}

export class Annotation {
  private ctx: Context;

  private group: Selection<SVGGElement, {}, HTMLElement, {}>;

  private labels: Selection<SVGGElement, {}, HTMLElement, {}>;

  private shapes: Selection<SVGGElement, {}, HTMLElement, {}>;

  private labelOptions: { [key: string]: AnnotationLabelOptions } = {};

  private lineOptions: { [key: string]: AnnotationLineOptions } = {};

  public constructor(ctx: Context) {
    this.ctx = ctx;
    const { classPrefix, root, id } = this.ctx;
    this.group = root
      .append("g")
      .attr("class", `${classPrefix}-chart-annotation`)
      .attr("data-z-index", "6")
      .attr("clip-path", `url(#${id})`)
      .attr("transform", "translate(0, 0)");

    this.labels = this.group
      .append("g")
      .attr("class", `${classPrefix}-chart-annotation-labels`)
      .attr("transform", "translate(0, 0)");

    this.shapes = this.group
      .append("g")
      .attr("class", `${classPrefix}-chart-annotation-shapes`)
      .attr("transform", "translate(0, 0)");
  }

  public label(key: string, cfg: AnnotationLabelOptions) {
    this.labelOptions[key] = cfg;
    return this;
  }

  public line(key: string, cfg: AnnotationLineOptions) {
    this.lineOptions[key] = cfg;
    return this;
  }

  private drawTimer: NodeJS.Timeout;

  public draw() {
    clearTimeout(this.drawTimer);
    this.drawTimer = setTimeout(() => {
      this.shapes.selectAll("g").remove();
      this.labels.selectAll("g").remove();
      Object.values(this.labelOptions).forEach(cfg => {
        this.drawLabels(cfg);
      });
      Object.values(this.lineOptions).forEach(cfg => {
        this.drawLines(cfg);
      });
    }, 10);
  }

  public drawLabels(cfg: AnnotationLabelOptions) {
    const { classPrefix } = this.ctx;
    const label = this.labels
      .append("g")
      .attr(
        "class",
        `${classPrefix}-chart-label ${classPrefix}-chart-annotation-label`
      );
    const { position, content, offsetX, offsetY, textStyle } = cfg;
    const [x = 0, y = 0] = position || [];

    label
      .append("text")
      .attr("text-anchor", "middle")
      .attr("style", replaceSVGStyleToHTML(textStyle))
      .attr("transform", () => {
        const width = this.ctx.getPlotWidth();
        const height = this.ctx.getPlotHeight();
        const xPos = typeof x === "number" ? x : (parseFloat(x) / 100) * width;
        const yPos = typeof y === "number" ? y : (parseFloat(y) / 100) * height;
        return `translate(${xPos},${yPos})`;
      })
      .attr("dx", offsetX)
      .attr("dy", offsetY)
      .append("tspan")
      .text(content);
  }

  public drawLines(cfg: AnnotationLineOptions) {
    const { classPrefix } = this.ctx;
    const line = this.shapes
      .append("g")
      .attr("class", `${classPrefix}-chart-annotation-line`);

    const { start = [], end = [], style = {}, text = {} } = cfg;
    const [x1 = 0, y1 = 0] = start;
    const [x2 = 0, y2 = 0] = end;
    const { stroke = "#bbbbbb", lineDash = [], lineWidth } = style;
    const {
      content,
      textStyle = "",
      position = "start",
      offsetX = 0,
      offsetY = 0,
      textAnchor = "start",
    } = text;
    line
      .append("line")
      .attr("x1", x1)
      .attr("y1", y1)
      .attr("x2", x2)
      .attr("y2", y2)
      .attr("stroke", stroke)
      .attr("stroke-width", lineWidth)
      .attr("stroke-dasharray", lineDash.join(","));

    if (content) {
      const label = this.labels
        .append("g")
        .attr(
          "class",
          `${classPrefix}-chart-label ${classPrefix}-chart-annotation-label`
        );

      label
        .append("text")
        .attr("text-anchor", textAnchor)
        .attr("style", replaceSVGStyleToHTML(textStyle))
        .attr("transform", () => {
          if (position === "end") {
            return `translate(${x2},${y2})`;
          }
          if (position === "center") {
            const offsetX = Math.abs(x2 - x1) / 2;
            const offsetY = Math.abs(y2 - y1) / 2;
            return `translate(${x1 + offsetX},${y1 + offsetY})`;
          }
          return `translate(${x1},${y1})`;
        })
        .attr("dx", offsetX)
        .attr("dy", offsetY)
        .append("tspan")
        .text(content);
    }
  }
}

function replaceSVGStyleToHTML(style: string) {
  return style
    .replace(/color:/, "fill:")
    .replace(/background-color:/, "stroke");
}
