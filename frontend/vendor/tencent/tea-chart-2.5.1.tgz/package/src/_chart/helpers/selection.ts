import { Selection as D3Selection } from "d3";
import { Context } from "../context";

// 选择区域最小位移，小于这个值不会触发选择
const MIN_LIMIT = 10;

export class Selection {
  /**
   * 全局上下文
   * @since 2.0
   */
  private ctx: Context;

  /**
   * 缩放区对象
   */
  public selection: D3Selection<SVGRectElement, {}, HTMLElement, {}> = null;

  private data = {
    selecting: false,
    start: 0,
    end: 0,
  };

  // 是否启用选择
  private enable: boolean = false;

  public constructor(ctx: Context) {
    this.ctx = ctx;
    this.initMouseEvent();
  }

  public setEnable(enable: boolean) {
    if (typeof enable === "boolean") {
      this.enable = enable;
      if (this.enable) {
        this.ctx.root.style("cursor", "crosshair");
      } else {
        this.ctx.root.style("cursor", "normal");
      }
    }
  }

  private initMouseEvent() {
    // 监听鼠标拖拽事件
    this.ctx.on("container.mouse.down", (x: number) => {
      if (this.enable) {
        this.ctx.emit("selection.start", x);
        this.data.start = x;
        this.data.selecting = true;
      }
    });

    this.ctx.on("container.mouse.up", (x: number) => {
      if (this.enable) {
        // 发送结束事件，传递 X 的范围
        if (this.data.start < x) {
          this.data.end = x;
        } else {
          this.data.end = this.data.start;
          this.data.start = x;
        }
        this.data.selecting = false;
        this.remove();

        if (this.data.end - this.data.start > MIN_LIMIT) {
          this.ctx.emit("selection.end", this.data.start, this.data.end);
        }
      }
    });

    this.ctx.on("plot.mouse.move", (x: number) => {
      if (
        this.enable &&
        this.data.selecting &&
        Math.abs(x - this.data.start) > MIN_LIMIT
      ) {
        this.drawSelectionMarker(x);
      }
    });
  }

  /**
   * 绘制选择框
   * @param x 当前 x 的坐标
   */
  private drawSelectionMarker(x: number) {
    const plotY = parseInt(this.ctx.plotBackgound.attr("y"), 10);
    const plotHeight = parseInt(this.ctx.plotBackgound.attr("height"), 10);

    const start: [number, number] = [this.data.start, plotY];
    const end: [number, number] = [x, plotHeight + plotY];

    this.draw(start, end);
  }

  private draw(start: [number, number], end: [number, number]) {
    const { root, classPrefix } = this.ctx;
    if (!this.selection) {
      this.selection = root
        .append("rect")
        .attr("class", `${classPrefix}-chart-selection-marker`)
        .attr("fill", "rgba(51, 92, 173, 0.25)")
        .attr("data-z-index", "7");
    }

    const [startX, startY] = start;
    const [endX, endY] = end;

    this.selection
      .attr("x", startX > endX ? endX : startX)
      .attr("y", startY > endY ? endY : startY)
      .attr("height", Math.abs(startY - endY))
      .attr("width", Math.abs(startX - endX));
  }

  private remove() {
    if (this.selection) {
      this.selection.remove();
      this.selection = null;
    }
  }
}
