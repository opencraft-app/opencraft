import { Selection, select, event } from "d3";
import { Context } from "../context";
import { EventData, MetaData, DataLeaf } from "../type/data";
import { escapeHTML } from "../lib/escape";

const ITEM_SIZE = 20;
export class Tooltip {
  /**
   * 全局上下文
   * @since 2.0
   */
  private ctx: Context;

  /**
   * overlay 根元素
   */
  private overlay: Selection<HTMLDivElement, {}, HTMLElement, {}>;

  /**
   * 排序箭头方向
   */
  private arrow: "up" | "down" = "down";

  /**
   * 提示框对象
   */
  private group: Selection<HTMLDivElement, {}, HTMLElement, {}>;

  public constructor(ctx: Context) {
    this.ctx = ctx;
    const { classPrefix } = this.ctx;
    this.overlay = select(`.${classPrefix}-chart-overlay`);
    if (this.overlay.empty()) {
      this.overlay = select("body")
        .append("div")
        .attr("class", `${classPrefix}-chart-overlay`)
        .style("position", "absolute")
        .style("top", 0)
        .style("left", 0)
        .style("z-index", 1002);
    } else {
      this.overlay.selectAll("div").remove();
    }

    this.ctx.on(
      "tooltip.scroll",
      (eventData: EventData, allData: DataLeaf[][], scrollTop: number) => {
        this.show(eventData, allData, scrollTop);
      }
    );
  }

  private selectGroup() {
    this.group = this.overlay.select(`[data-id="${this.ctx.id}"]`);

    const { height, maxHeight, zIndex, width } = this.ctx.getOption("tooltip");
    if (zIndex) {
      this.overlay.style("z-index", zIndex);
    }

    if (this.group.empty()) {
      this.group = this.overlay
        .append("div")
        .attr("class", `${this.ctx.classPrefix}-chart-tooltip`)
        .attr("data-id", this.ctx.id)
        .style("position", "fixed")
        .style("display", "block")
        .style("padding", "15px")
        .style("z-index", 99)
        .style("background", "#FFF")
        .style("white-space", "nowrap")
        .style("box-shadow", "0px 4px 8px 0px rgba(0, 0, 0, 0.15)")
        .style(
          "transition",
          "visibility 0.6s cubic-bezier(0.23, 1, 0.32, 1) 0s, left 0.6s cubic-bezier(0.23, 1, 0.32, 1) 0s, top 0.6s cubic-bezier(0.23, 1, 0.32, 1) 0s"
        );

      if (height) {
        this.group.style("overflow", "auto").style("height", `${height}px`);
      }
      if (maxHeight) {
        this.group.style("overflow", "auto").style("maxHeight", `${height}px`);
      }
      if (width) {
        this.group.style("width", `${width}px`);
      }
    }

    this.group.on("mouseleave touchend", () => {
      this.ctx.emit("plot.mouse.left");
    });
  }

  /**
   * 数据排序
   * @param metaDatas legend展示的数据
   */
  public sortData(metaDatas: MetaData[]): MetaData[] {
    let data = [];
    if (metaDatas && Array.isArray(metaDatas)) {
      if (this.arrow === "up") {
        data = metaDatas.sort((a, b) => {
          return a.value > b.value ? 1 : -1;
        });
      } else {
        data = metaDatas.sort((a, b) => {
          return a.value < b.value ? 1 : -1;
        });
      }
    }

    return data;
  }

  public show(
    eventData: EventData,
    allData: DataLeaf[][],
    scrollTop: number = 0
  ) {
    const { index, x, y } = eventData;
    const {
      formatter,
      enableSort,
      header = {},
      virtualizedScroll,
    } = this.ctx.getOption("tooltip");
    const tmpMetaData = eventData.metaData.slice();
    const metaData = enableSort ? this.sortData(tmpMetaData) : tmpMetaData;

    if (metaData.length === 0) return;

    this.selectGroup();

    // 启用虚拟滚动时
    let indexRange = { start: undefined, end: undefined };
    if (virtualizedScroll) {
      this.group.on("scroll", () => {
        // eslint-disable-next-line no-restricted-globals
        const targetElement: any = event && event.target;
        this.ctx.emit(
          "tooltip.scroll",
          eventData,
          allData,
          targetElement.scrollTop
        );
      });

      indexRange = this.getVirtualListMetaData(metaData, scrollTop);
    }

    const [{ title }] = metaData;
    let content = getTooltipContent(
      title,
      metaData,
      this.arrow,
      enableSort,
      header.typeText,
      header.valueText,
      indexRange
    );

    if (typeof formatter === "function") {
      const formatted = formatter(metaData, index, allData);
      if (typeof formatted === "string") {
        content = formatted;
      } else {
        const [{ title }] = formatted;
        content = getTooltipContent(
          title,
          formatted,
          this.arrow,
          enableSort,
          header.typeText,
          header.valueText
        );
      }
    }
    this.group.html(escapeHTML(content));

    if (enableSort) {
      this.group.select("i").on("click", () => {
        this.arrow = this.arrow === "up" ? "down" : "up";
        this.show(eventData, allData);
      });
    }

    const offset = 15;
    const { width, height } = this.group.node().getBoundingClientRect();
    const { top, left } = this.ctx.root.node().getBoundingClientRect();
    const plotWidth = parseInt(this.ctx.background.attr("width"), 10);
    const plotHeight = parseInt(this.ctx.background.attr("height"), 10);

    // 设置水平方向位置
    if (x + width > plotWidth) {
      this.group.style("left", `${x + left - offset - width}px`);
    } else {
      this.group.style("left", `${x + left + offset}px`);
    }
    // 设置垂直方向位置
    if (y + height > plotHeight) {
      this.group.style("top", `${y + top - height - offset}px`);
    } else {
      this.group.style("top", `${y + offset + top}px`);
    }
  }

  private getVirtualListMetaData(
    metaData: EventData["metaData"],
    scrollTop: number
  ) {
    const { height = 200 } = this.ctx.getOption("tooltip");
    const { enableSort } = this.ctx.getOption("tooltip");

    // 虚拟滚动容器高度需减少tooltip头部标题部分高度，这部分是固定值
    const tooltipHeadHeight = !enableSort ? 46 : 83;
    let startIndex;
    if (scrollTop > tooltipHeadHeight) {
      startIndex = Math.floor((scrollTop - tooltipHeadHeight) / ITEM_SIZE);
    } else {
      startIndex = 0;
    }
    const endIndex = Math.floor(
      (height + scrollTop - tooltipHeadHeight) / ITEM_SIZE
    );

    return { start: startIndex, end: endIndex };
  }

  private clearTimer = null;

  public hide() {
    // 确保 tooltip 一定会被销毁
    clearTimeout(this.clearTimer);
    this.clearTimer = setTimeout(() => {
      if (this.group) {
        this.group.remove();
      }
    }, 300);
  }
}

/**
 * 获取列表项样式
 * @param index 列表数据下标值
 * @param tooltipHeadHeight tooltip头部高度
 */
function getItemStyle(index: number, tooltipHeadHeight: number) {
  return `position: absolute; top: ${tooltipHeadHeight + index * ITEM_SIZE}px;`;
}

export function getTooltipContent(
  label: string,
  metaData: MetaData[],
  arrowType: "up" | "down",
  enableSort?: boolean,
  typeText?: string,
  valueText?: string,
  indexRange?: { start: undefined | number; end: undefined | number }
) {
  const title = `<h4 style="font-size:14px;color:#333;padding-bottom:10px">${label}</h4>`;
  const arrowUpBackgroundStyle =
    "background-image:url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxNiIgaGVpZ2h0PSIxNiI+PHBhdGggZmlsbD0iIzg4OCIgZD0iTTEyIDdMOCAzIDQgN2gzdjZoMlY3eiIvPjwvc3ZnPg==);";
  const arrowDownBackgroundStyle =
    "background-image:url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxNiIgaGVpZ2h0PSIxNiI+PHBhdGggZmlsbD0iIzg4OCIgZD0iTTkgOVYzSDd2Nkg0bDQgNCA0LTR6Ii8+PC9zdmc+);";
  const arrowStyle =
    arrowType === "down" ? arrowDownBackgroundStyle : arrowUpBackgroundStyle;
  const typeDescription = typeText || "series";
  const valueDescription = valueText || "value";
  const tooltipHead = enableSort
    ? `<h4 style="margin-bottom:10px;font-size:14px;color:#888888;padding-bottom:5px;border-bottom: 1px solid #ECECEC;"><span>${typeDescription}</span><span style="float:right;">${valueDescription}<i style="cursor: pointer;width: 16px;height: 16px;display: inline-block;vertical-align: middle;background-repeat: no-repeat;background-position: inherit;font-size: 0;${arrowStyle}"></i></span></h4>`
    : "";
  let seriesText = "";
  const isVirtualList =
    indexRange &&
    typeof indexRange.start !== "undefined" &&
    typeof indexRange.end !== "undefined";
  const tooltipHeadHeight = !enableSort ? 46 : 83;
  for (let i = 0; i < metaData.length; i++) {
    if (isVirtualList && (i < indexRange.start || i > indexRange.end)) {
      // eslint-disable-next-line no-continue
      continue;
    }
    const virtualizedStyle = isVirtualList
      ? getItemStyle(i, tooltipHeadHeight)
      : "";
    const hasLabel = !!metaData[i].label;

    seriesText += `
    <p style="height:20px;line-height:20px;display:table-row;${virtualizedStyle}">
      <span style="display:table-cell;line-height:20px;vertical-align:middle;padding-right:10px;">
        <i style="display:inline-block;height:4px;width:16px;background:${
          metaData[i].color
        };"></i>
      </span>
      <span style="display:table-cell;font-size:14px;color:#333;">${
        hasLabel ? metaData[i].label : ""
      }</span>
      <span style="display:table-cell;font-weight:600;color:#333;font-size:14px;padding-left:15px;text-align:right;">${
        metaData[i].valueText
      }
      ${metaData[i].percentage ? `(${metaData[i].percentage}%)` : ""}</span>
    </p>`;
  }

  return `
  ${title}
  ${tooltipHead}
  <div style="display:table;">
    ${seriesText}
  </div>
  `;
}
