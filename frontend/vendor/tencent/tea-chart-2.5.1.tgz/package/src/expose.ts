import * as TeaChart from "./index";

/**
 * 输出到 TeaChart 全局变量
 */
window["TeaChart"] = TeaChart; // eslint-disable-line dot-notation
