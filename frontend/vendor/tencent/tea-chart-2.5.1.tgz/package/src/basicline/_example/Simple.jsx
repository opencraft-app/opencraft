import React, { Fragment, useRef, useEffect } from "react";
import { BasicLine } from "@tencent/tea-chart/lib/basicline";

export default function SimpleLineExample() {
  const lineA = useRef(null);
  const lineB = useRef(null);

  const data = [
    { time: "0:00", value: 10 },
    { time: "1:00", value: 20 },
    { time: "2:00", value: 50 },
    { time: "3:00", value: 60 },
    { time: "4:00", value: 20 },
    { time: "5:00", value: 72 },
    { time: "6:00", value: 98 },
    { time: "7:00", value: 60 },
    { time: "8:00", value: 70 },
    { time: "9:00", value: 58 },
    { time: "10:00", value: 22 },
    { time: "11:00", value: 68 },
    { time: "12:00", value: 83 },
  ];

  useEffect(() => {
    if (lineA.current && lineB.current) {
      lineA.current.on("plot.mouse.move", (x, y) => {
        lineB.current.emit("plot.mouse.move", x, y);
      });
      lineA.current.on("plot.mouse.left", (x, y) => {
        lineB.current.emit("plot.mouse.left", x, y);
      });
    }
  });

  return (
    <Fragment>
      <h3>折线</h3>
      <BasicLine
        height={250}
        position="time*value"
        dataSource={data}
        xAxis={{
          title: {
            text: "时间",
          },
        }}
        yAxis={{
          title: {
            text: "数值",
          },
        }}
        chartRef={ref => {
          lineA.current = ref;
        }}
      />

      <h3>平滑曲线</h3>
      <BasicLine
        smooth
        height={250}
        position="time*value"
        dataSource={data}
        chartRef={ref => {
          lineB.current = ref;
        }}
      />
    </Fragment>
  );
}
