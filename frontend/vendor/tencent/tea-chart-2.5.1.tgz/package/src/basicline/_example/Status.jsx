import React, { Fragment, useState } from "react";
import { BasicLine } from "@tencent/tea-chart/lib/basicline";
import { Button, StatusTip } from "@tencent/tea-component";

export default function StatusBasicLineExample() {
  const [data, setData] = useState([]);
  const [status, setStatus] = useState(null);

  const refresh = () => {
    setStatus("loading");
    setTimeout(() => {
      const dataCount = 10000;
      const data = [];
      const date = new Date();
      for (let i = 0; i < dataCount; i++) {
        data.push({
          time: `${date.getHours()}:${date.getMinutes()}`,
          value: Math.floor(Math.random() * 5000),
        });
        const dateTime = date.getTime();
        date.setTime(dateTime + 60000);
      }
      setData(data);
      setStatus(null);
    }, 2000);
  };

  return (
    <Fragment>
      <Button onClick={refresh}>点击刷新</Button>
      <BasicLine
        height={250}
        position="time*value"
        dataSource={data}
        size={1}
        tips={status && <StatusTip status={status} />}
      />
    </Fragment>
  );
}
