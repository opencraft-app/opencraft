import React, { Fragment } from "react";
import { BasicLine } from "@tencent/tea-chart/lib/basicline";

export default function LineWidthExample() {
  const dataCount = 1000;
  const data = [];
  const date = new Date();
  for (let i = 0; i < dataCount; i++) {
    data.push({
      time: `${date.getHours()}:${date.getMinutes()}`,
      value: Math.floor(Math.random() * 5000),
    });
    const dateTime = date.getTime();
    date.setTime(dateTime + 60000);
  }

  return (
    <Fragment>
      <BasicLine
        height={250}
        position="time*value"
        size={1}
        dataSource={data}
      />
    </Fragment>
  );
}
