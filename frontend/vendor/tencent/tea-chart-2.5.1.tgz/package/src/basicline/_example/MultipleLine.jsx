import React, { Fragment, useState } from "react";
import { BasicLine } from "@tencent/tea-chart/lib/basicline";
import { Switch } from "@tencent/tea-component";

export default function MultipleLineExample() {
  const [stack, setStack] = useState(false);
  const [connectNulls, setConnectNulls] = useState(true);
  const data = Array(52)
    .fill(null)
    .map((_, index) => {
      const i = index % 13;
      const value = Math.floor(Math.random() * 100);
      const instanceId = Math.floor(index / 13);
      return {
        time: i >= 10 ? `${i}:00` : `0${i}:00`,
        value,
        instance: `ins-bmwh${instanceId}`,
      };
    });

  return (
    <Fragment>
      <section>
        <Switch value={stack} onChange={value => setStack(value)}>
          是否堆叠
        </Switch>
        <Switch
          value={connectNulls}
          onChange={value => {
            setConnectNulls(value);
          }}
        >
          是否连接空值
        </Switch>
      </section>
      <BasicLine
        connectNulls={connectNulls}
        height={250}
        position="time*value"
        dataSource={data}
        yAxis={{
          title: {
            text: "数值数值数值数值",
          },
        }}
        color="instance"
        tooltip={{
          enableSort: true,
          header: { typeText: "类型", valueText: "值" },
          maxHeight: 400,
          height: 200,
          // width: 200,
          // virtualizedScroll: true,
        }}
        canvasMode
        scale={{
          time: {
            type: "time",
            timeParseFormat: "HH:mm",
          },
          value: { stack },
        }}
      />
    </Fragment>
  );
}
