import React, { Fragment } from "react";
import { BasicLine } from "@tencent/tea-chart/lib/basicline";

export default function MultipleLineExample() {
  const data = [
    { time: "0:00", value: 10, instance: "ins-bmwh571" },
    { time: "1:00", value: 20, instance: "ins-bmwh571" },
    { time: "2:00", value: 60, instance: "ins-bmwh571" },
    { time: "3:00", value: 60, instance: "ins-bmwh571" },
    { time: "4:00", value: 20, instance: "ins-bmwh571" },
    { time: "5:00", value: 72, instance: "ins-bmwh571" },
    { time: "6:00", value: 98, instance: "ins-bmwh571" },
    { time: "7:00", value: 60, instance: "ins-bmwh571" },
    { time: "8:00", value: 70, instance: "ins-bmwh571" },
    { time: "9:00", value: 58, instance: "ins-bmwh571" },
    { time: "10:00", value: 22, instance: "ins-bmwh571" },
    { time: "11:00", value: 68, instance: "ins-bmwh571" },
    { time: "12:00", value: 83, instance: "ins-bmwh571" },
    { time: "0:00", value: 10, instance: "ins-bmwh57a12" },
    { time: "1:00", value: 20, instance: "ins-bmwh57a12" },
    { time: "2:00", value: 110, instance: "ins-bmwh57a12" },
    { time: "3:00", value: 60, instance: "ins-bmwh57a12" },
    { time: "4:00", value: 20, instance: "ins-bmwh57a12" },
    { time: "5:00", value: 56, instance: "ins-bmwh57a12" },
    { time: "6:00", value: 98, instance: "ins-bmwh57a12" },
    { time: "7:00", value: 20, instance: "ins-bmwh57a12" },
    { time: "8:00", value: 33, instance: "ins-bmwh57a12" },
    { time: "9:00", value: 58, instance: "ins-bmwh57a12" },
    { time: "10:00", value: 63, instance: "ins-bmwh57a12" },
    { time: "11:00", value: 22, instance: "ins-bmwh57a12" },
    { time: "12:00", value: 123, instance: "ins-bmwh57a12" },
    { time: "0:00", value: 20, instance: "ins-besd5532" },
    { time: "1:00", value: 136, instance: "ins-besd5532" },
    { time: "2:00", value: 110, instance: "ins-besd5532" },
    { time: "3:00", value: 20, instance: "ins-besd5532" },
    { time: "4:00", value: 60, instance: "ins-besd5532" },
    { time: "5:00", value: 26, instance: "ins-besd5532" },
    { time: "6:00", value: 88, instance: "ins-besd5532" },
    { time: "7:00", value: 120, instance: "ins-besd5532" },
    { time: "8:00", value: 63, instance: "ins-besd5532" },
    { time: "9:00", value: 58, instance: "ins-besd5532" },
    { time: "10:00", value: 23, instance: "ins-besd5532" },
    { time: "11:00", value: 82, instance: "ins-besd5532" },
    { time: "12:00", value: 13, instance: "ins-besd5532" },
  ];

  return (
    <Fragment>
      <BasicLine
        height={250}
        position="time*value"
        dataSource={data}
        color="instance"
        theme={{ color: ["#eb6455"] }}
      />
    </Fragment>
  );
}
