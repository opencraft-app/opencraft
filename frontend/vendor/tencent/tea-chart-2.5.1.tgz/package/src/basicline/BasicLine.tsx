import React, {
  useRef,
  useEffect,
  useImperativeHandle,
  useState,
  useMemo,
} from "react";
import { RectProps } from "../_chart/type/chart";
import { Chart } from "../_chart";
import { Line } from "../_chart/shapes";
import { ChartBase } from "../chartbase";
import { comparePropsEqual } from "../_chart/lib/compare-props-equal";
import { Omit } from "../_type";

export interface BasicLineProps extends Omit<RectProps, "dataLabels"> {
  /**
   * 折线的粗细
   *
   * @default 3
   */
  size?: number;

  /**
   * 是否连接空值
   * @default true
   * @since 2.0
   */
  connectNulls?: boolean;

  /**
   * 是否为平滑曲线
   */
  smooth?: boolean;

  /**
   * 支持开启Canvas，优化大数据卡顿问题
   */
  canvasMode?: boolean;
}

export function BasicLine(props: BasicLineProps) {
  const { chartRef: ref } = props;
  const chartRef = useRef<Chart>();
  const [newProps, updateProps] = useState(props);
  const shapeRef = useRef<Line>();

  useEffect(() => {
    if (chartRef.current) {
      shapeRef.current = chartRef.current.line();
    }
  }, [chartRef]);

  useImperativeHandle(ref, () => ({
    on: (...args) => {
      if (chartRef.current) {
        chartRef.current.on(...args);
      }
    },
    once: (eventName: string, callback) => {
      if (chartRef.current) {
        chartRef.current.once(eventName, callback);
      }
    },
    off: (eventName: string, callback) => {
      if (chartRef.current) {
        chartRef.current.off(eventName, callback);
      }
    },
    emit: (...args) => {
      if (chartRef.current) {
        chartRef.current.emit(...args);
      }
    },
    getData: (x: number) => {
      return shapeRef.current.getData(x);
    },

    getDataFromCategory: (category: string) => {
      return shapeRef.current.getDataFromCategory(category);
    },

    getPosition: (category: string, value: number) => {
      return shapeRef.current.getPosition(category, value);
    },
  }));

  useEffect(() => {
    if (!comparePropsEqual(newProps, props)) {
      updateProps(props);
    }
  }, [newProps, props]);

  useEffect(() => {
    const {
      position,
      size = 3,
      color,
      xAxis = true,
      yAxis = true,
      connectNulls,
      smooth,
      canvasMode,
    } = newProps;
    const xAxes = typeof xAxis === "boolean" ? { enable: xAxis } : xAxis;
    const yAxes = typeof yAxis === "boolean" ? { enable: yAxis } : yAxis;
    const connectNull =
      typeof connectNulls === "boolean"
        ? { enable: connectNulls }
        : connectNulls;

    shapeRef.current
      .position(position)
      .color(color)
      .size(size)
      .axis({ xAxis: xAxes, yAxis: yAxes })
      .connectNulls(connectNull)
      .shape({ smooth, canvasMode });
  }, [newProps]);

  return useMemo(() => {
    return <ChartBase {...newProps} ref={chartRef} />;
  }, [newProps]);
}
