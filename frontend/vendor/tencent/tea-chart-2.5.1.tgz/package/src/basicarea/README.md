# BasicArea 基本面积图

基本面积图是其他面积图的基础组件，包含几乎全部属性，但是意味着使用起来会较为复杂。建议选择特定场景的组件来使用。

## 使用示例

对于最简单的使用只需要配置少量参数即可

[Example: 基本使用](./_example/Simple.jsx)

堆叠面积图

[Example: 堆叠](./_example/MultipleLine.jsx)

自定义样式

[Example: 自定义样式](./_example/Color.jsx)

## 组件属性

[Interface: BasicAreaProps](./BasicArea.tsx)
