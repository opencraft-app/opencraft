import React, {
  useRef,
  useEffect,
  useImperativeHandle,
  useState,
  useMemo,
} from "react";
import { RectProps } from "../_chart/type/chart";
import { Chart } from "../_chart";
import { Area, AreaStyle } from "../_chart/shapes";
import { ChartBase } from "../chartbase";
import { comparePropsEqual } from "../_chart/lib/compare-props-equal";
import { Omit } from "../_type";

export interface BasicAreaProps extends Omit<RectProps, "dataLabels"> {
  /**
   * 折线的粗细
   *
   * @default 3
   */
  size?: number;

  /**
   * 是否连接空值
   * @default true
   * @since 2.0
   */
  connectNulls?: boolean;

  /**
   * 是否为平滑曲线
   */
  smooth?: boolean;

  /**
   * 样式设置
   */
  areaStyle?: AreaStyle;
}

export function BasicArea(props: BasicAreaProps) {
  const { chartRef: ref } = props;
  const chartRef = useRef<Chart>();
  const [newProps, updateProps] = useState(props);
  const shapeRef = useRef<Area>();

  useEffect(() => {
    if (chartRef.current) {
      shapeRef.current = chartRef.current.area();
    }
  }, [chartRef]);

  useImperativeHandle(ref, () => ({
    on: (...args) => {
      if (chartRef.current) {
        chartRef.current.on(...args);
      }
    },
    emit: (...args) => {
      if (chartRef.current) {
        chartRef.current.emit(...args);
      }
    },
    getData: (x: number) => {
      return shapeRef.current.getData(x);
    },
  }));

  useEffect(() => {
    if (!comparePropsEqual(newProps, props)) {
      updateProps(props);
    }
  }, [newProps, props]);

  useEffect(() => {
    const {
      position,
      size = 2,
      color,
      xAxis = true,
      yAxis = true,
      connectNulls,
      smooth,
      areaStyle = {},
    } = newProps;
    const xAxes = typeof xAxis === "boolean" ? { enable: xAxis } : xAxis;
    const yAxes = typeof yAxis === "boolean" ? { enable: yAxis } : yAxis;
    const connectNull =
      typeof connectNulls === "boolean"
        ? { enable: connectNulls }
        : connectNulls;

    shapeRef.current
      .position(position)
      .color(color)
      .size(size)
      .axis({ xAxis: xAxes, yAxis: yAxes })
      .connectNulls(connectNull)
      .shape({ smooth })
      .style(areaStyle);
  }, [newProps]);

  return useMemo(() => {
    return <ChartBase {...newProps} ref={chartRef} />;
  }, [newProps]);
}
