import React, { Fragment } from "react";
import { BasicArea } from "@tencent/tea-chart/lib/basicarea";

export default function MultipleLineExample() {
  const data = [
    { time: "00:00", value: 10, instance: "ins-bmwh571" },
    { time: "01:00", value: 20, instance: "ins-bmwh571" },
    { time: "02:00", value: 60, instance: "ins-bmwh571" },
    { time: "03:00", value: 60, instance: "ins-bmwh571" },
    { time: "04:00", value: 20, instance: "ins-bmwh571" },
    { time: "05:00", value: 72, instance: "ins-bmwh571" },
    { time: "06:00", value: 98, instance: "ins-bmwh571" },
    { time: "07:00", value: 60, instance: "ins-bmwh571" },
    { time: "08:00", value: 70, instance: "ins-bmwh571" },
    { time: "09:00", value: 58, instance: "ins-bmwh571" },
    { time: "10:00", value: 22, instance: "ins-bmwh571" },
    { time: "11:00", value: 68, instance: "ins-bmwh571" },
    { time: "12:00", value: 83, instance: "ins-bmwh571" },

    { time: "00:00", value: 10, instance: "ins-bmwh57a12" },
    { time: "01:00", value: 20, instance: "ins-bmwh57a12" },
    { time: "02:00", value: 110, instance: "ins-bmwh57a12" },
    { time: "03:00", value: 60, instance: "ins-bmwh57a12" },
    { time: "04:00", value: 50, instance: "ins-bmwh57a12" },
    { time: "05:00", value: 88, instance: "ins-bmwh57a12" },
    { time: "06:00", value: 98, instance: "ins-bmwh57a12" },
    { time: "07:00", value: 20, instance: "ins-bmwh57a12" },
    { time: "08:00", value: 33, instance: "ins-bmwh57a12" },
    { time: "09:00", value: 58, instance: "ins-bmwh57a12" },
    { time: "10:00", value: 63, instance: "ins-bmwh57a12" },
    { time: "11:00", value: 22, instance: "ins-bmwh57a12" },
    { time: "12:00", value: 123, instance: "ins-bmwh57a12" },

    { time: "00:00", value: 20, instance: "ins-besd5532" },
    { time: "01:00", value: 136, instance: "ins-besd5532" },
    { time: "02:00", value: 110, instance: "ins-besd5532" },
    { time: "03:00", value: 60, instance: "ins-besd5532" },
    { time: "04:00", value: 90, instance: "ins-besd5532" },
    { time: "05:00", value: 26, instance: "ins-besd5532" },
    { time: "06:00", value: 88, instance: "ins-besd5532" },
    { time: "07:00", value: 120, instance: "ins-besd5532" },
    { time: "08:00", value: 63, instance: "ins-besd5532" },
    { time: "09:00", value: 58, instance: "ins-besd5532" },
    { time: "10:00", value: 23, instance: "ins-besd5532" },
    { time: "11:00", value: 82, instance: "ins-besd5532" },
    { time: "12:00", value: 13, instance: "ins-besd5532" },
  ];

  return (
    <Fragment>
      <BasicArea
        height={250}
        position="time*value"
        dataSource={data}
        color="instance"
        scale={{
          value: { stack: true },
        }}
      />
    </Fragment>
  );
}
