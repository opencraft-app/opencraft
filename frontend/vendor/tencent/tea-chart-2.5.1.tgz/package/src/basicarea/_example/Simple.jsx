import React, { Fragment } from "react";
import { Row, Col } from "@tencent/tea-component";
import { BasicArea } from "@tencent/tea-chart/lib/basicarea";

export default function SimpleLineExample() {
  const data = [
    { time: "0:00", value: 10 },
    { time: "1:00", value: 20 },
    { time: "2:00", value: 50 },
    { time: "3:00", value: 60 },
    { time: "4:00", value: 20 },
    { time: "5:00", value: 72 },
    { time: "6:00", value: 98 },
    { time: "7:00", value: 60 },
    { time: "8:00", value: 70 },
    { time: "9:00", value: 58 },
    { time: "10:00", value: 22 },
    { time: "11:00", value: 68 },
    { time: "12:00", value: 83 },
  ];

  return (
    <Fragment>
      <Row>
        <Col span={12}>
          <h3>折线</h3>
          <BasicArea height={250} position="time*value" dataSource={data} />
        </Col>
        <Col span={12}>
          <h3>平滑曲线</h3>
          <BasicArea
            smooth
            height={250}
            position="time*value"
            dataSource={data}
          />
        </Col>
      </Row>
    </Fragment>
  );
}
