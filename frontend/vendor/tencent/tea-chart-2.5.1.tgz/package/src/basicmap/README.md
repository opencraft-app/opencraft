# BasicMap 中国地图

目前地图只支持热力图

## 使用示例

通过颜色渐变将数据映射至中国省份

[Example: 基本使用](./_example/SimpleMap.jsx)


## 组件属性

[Interface: BasicMapProps](./BasicMap.tsx)
