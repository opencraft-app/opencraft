import React, { Fragment, useRef, useEffect } from "react";
import { BasicMap } from "@tencent/tea-chart/lib/basicmap";

export default function SimpleBasicMapExample() {
  const chartRef = useRef(null);
  const data = [
    { type: "广东省", value: 291 },
    { type: "四川省", value: 302 },
    { type: "江西省", value: 82 },
  ];

  useEffect(() => {
    if (chartRef.current) {
      chartRef.current.on("interaction.selected", data => {
        console.log(data);
      });
    }
  });

  return (
    <Fragment>
      <BasicMap
        chartRef={ref => {
          chartRef.current = ref;
        }}
        interaction={["element-select"]}
        height={400}
        position="type*value"
        dataSource={data}
        scale={{
          value: {
            alias: "人数",
            domain: [0, 500],
          },
        }}
        color={["#EBF4FF", "#006eff"]}
      />
    </Fragment>
  );
}
