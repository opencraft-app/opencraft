# 国际化（i18n）

Tea 组件内置了 4 个语言：zh, en, ko, jp，使用 `ConfigProvider` 方法设置组件的语言。

## 使用示例

[Example: ConfigProviderExample](../configprovider/_example/ConfigProviderExample.jsx)
