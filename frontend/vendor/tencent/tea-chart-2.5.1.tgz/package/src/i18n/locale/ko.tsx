// prettier-ignore
// eslint-disable-next-line
export const ko = {
  locale: 'ko',


  // 操作：确定按钮
  resetText: (
    'Reset'
  ),

  // 暂无数据
  noData: (
    'No Data Found'
  ),
};
