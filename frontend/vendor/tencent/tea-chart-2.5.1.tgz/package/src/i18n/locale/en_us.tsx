// prettier-ignore
// eslint-disable-next-line
export const en_us = {
  locale: 'en_us',

  // 操作：确定按钮
  resetText: (
    'Reset'
  ),

  // 暂无数据
  noData: (
    'No Data Found'
  ),
};
