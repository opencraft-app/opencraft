// prettier-ignore
// eslint-disable-next-line
export const zh_cn = {
  locale: 'zh_cn',

  // 操作：确定按钮
  resetText: (
    '重置'
  ),

  // 暂无数据
  noData: (
    '暂无数据'
  ),
};
