import React, { ComponentClass } from "react";
import { useTranslation } from "./translation";

export function withTranslation<C extends ComponentClass<any>>(
  WrappedComponent: C
): C {
  return (React.forwardRef(
    (props, ref: React.LegacyRef<React.Component<any>>) => {
      const t = useTranslation();
      return React.createElement(WrappedComponent, { ...props, ref, t });
    }
  ) as any) as C;
}
