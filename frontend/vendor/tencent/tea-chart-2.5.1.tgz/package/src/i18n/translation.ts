/* eslint-disable @typescript-eslint/camelcase */
import { useEffect, useState } from "react";
import { zh_cn } from "./locale/zh_cn";
import { useConfig } from "../_util/config-context";
import { translationMap, Translation } from "./translationMap";

// 约定中语言名不规范
const lngs = {
  zh: "zh_cn",
  en: "en_us",
  jp: "ja",
};

export function setLocale() {
  console.error("`setLocale()` 方法已废弃");
}

export function useTranslation(moment?: typeof import("moment")): Translation {
  const { locale: configLocale } = useConfig();
  const t = translationMap[configLocale] || zh_cn;
  const locale = lngs[t.locale] || t.locale;

  useState(() => {
    if (moment) {
      moment.locale(locale);
    }
  });
  useEffect(() => {
    if (moment) {
      moment.locale(locale);
    }
  }, [locale]); // eslint-disable-line react-hooks/exhaustive-deps

  return t;
}

export interface WithTranslationProps {
  /**
   * @ignore
   */
  t?: Translation;
}
/* eslint-enable @typescript-eslint/camelcase */
