/* eslint-disable */
import { zh_cn } from "./locale/zh_cn";
import { en_us } from "./locale/en_us";
import { ja } from "./locale/ja";
import { ko } from "./locale/ko";

type Locale = typeof zh_cn;
export interface Translation extends Locale {}

export const translationMap = {
  zh_cn: zh_cn as Translation,
  zh: zh_cn as Translation,
  en_us: { ...zh_cn, ...en_us } as Translation,
  en: { ...zh_cn, ...en_us } as Translation,
  ja: { ...zh_cn, ...en_us, ...ja } as Translation,
  jp: { ...zh_cn, ...en_us, ...ja } as Translation,
  ko: { ...zh_cn, ...en_us, ...ko } as Translation,
};
/* eslint-enable */
