import React from "react";
import { BasicBar, BasicBarProps } from "../basicbar";

/**
 * StackBar 组件支持的属性。
 */
export interface StackBarProps extends BasicBarProps {
  /**
   * 是否为百分比堆叠
   * @default false
   * @since 2.0
   */
  percent: boolean;

  /**
   * 是否显示堆叠总数标签
   * @default false
   * @since 2.0
   */
  stackLabels: boolean;

  /**
   * 作为值的字段名，用于水平柱状图
   */
  valueKey?: string;
}

export function StackBar(props: StackBarProps) {
  const { position = "", scale = {}, percent, stackLabels, valueKey } = props;

  const key = valueKey || position.split("*")[1];
  const valueScale = scale[key] || {};

  valueScale.stack = percent ? "percent" : true;
  valueScale.stackLabels = {
    ...valueScale.stackLabels,
    enable: stackLabels,
  };

  const propsCopy = Object.assign({}, props, {
    scale: {
      [key]: valueScale,
    },
  });

  return <BasicBar {...propsCopy} />;
}
