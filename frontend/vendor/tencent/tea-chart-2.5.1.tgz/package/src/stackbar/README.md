# StackBar 堆叠柱状图

## 使用示例
使用颜色来区分多条数据系列

[Example: 基本使用](./_example/MultipleBar.jsx)

使用百分比柱状图

[Example: 基本使用](./_example/Percent.jsx)

## 组件属性

[Interface: StackBarProps](./StackBar.tsx)
