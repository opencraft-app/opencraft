import React, { useRef, useEffect, forwardRef, useState } from "react";
import { useConfig } from "../_util/config-context";
import { useResize } from "../_util/use-resize";
import { Chart } from "../_chart";
import { useTranslation } from "../i18n";
import { ChartProps } from "../_chart/type/chart";
import { ZoomOptions, InteractionType } from "../_chart/type";

export interface ChartBaseProps extends Omit<ChartProps, "chartRef"> {
  /**
   * 是否启用缩放。已废弃，请使用 [interaction]
   * @deprecated
   */
  zoom?: boolean | ZoomOptions;
}

/**
 * ChartBase 是所有图形组件底层组件，用以生成图表实例 chart，并负责所有 chart 的属性变更操作
 */

export const ChartBase = forwardRef(
  (props: ChartBaseProps, chartRef: React.MutableRefObject<Chart>) => {
    const { height, width, tips, tipsStyle, dataSource, children } = props;
    const container = useRef(null);
    const [annotation, setAnnotation] = useState(null);
    const [chart, setChart] = useState(null);
    const contextConfig = useConfig();
    const theme = Object.assign({}, contextConfig, props.theme);
    const { classPrefix } = theme;
    const t = useTranslation();
    useEffect(() => {
      if (!chartRef.current) {
        chartRef.current = new Chart(container.current, {
          height,
          ...theme,
        });
        setChart(chartRef.current);
        setAnnotation(chartRef.current.annotation());
      }

      return () => {
        chartRef.current.destroy();
      };
    }, [chartRef, height, theme, width]);

    useEffect(() => {
      if (chartRef.current) {
        chartRef.current.render();
      }
    }, [chartRef, height, width]);

    useEffect(() => {
      const {
        dataSource,
        color,
        scale,
        tooltip = true,
        legend = !!color,
        selection,
        zoom,
        interaction,
      } = props;

      // 即将废弃
      if (selection !== undefined) {
        console.error("[selection] 属性即将废弃，能力已迁移至 [interaction]");
        if (Array.isArray(interaction)) {
          interaction.push("brush");
        } else {
          interaction.brush = {};
        }
      }

      // 即将废弃
      if (zoom !== undefined) {
        console.error("[zoom] 属性即将废弃，能力已迁移至 [interaction]");
        if (Array.isArray(interaction)) {
          interaction.push("zoom");
        } else {
          interaction.zoom = { resetText: t.resetText };
        }
      }

      chartRef.current
        .theme(theme)
        .source(dataSource)
        .scale(scale)
        .tooltip(tooltip)
        .legend(legend);

      if (Array.isArray(interaction)) {
        for (const action of interaction) {
          if (action === "zoom") {
            chartRef.current.interaction(action, { resetText: t.resetText });
          } else {
            chartRef.current.interaction(action);
          }
        }
      } else if (typeof interaction === "object") {
        Object.keys(interaction).forEach((key: InteractionType) => {
          chartRef.current.interaction(key, interaction[key]);
        });
      }

      // 为了配合 Annotation
      setTimeout(() => {
        chartRef.current.render();
      });
    }, [chartRef, props, t.resetText, theme]);

    useResize(() => {
      chartRef.current.resize();
    });

    const showStatus =
      tips || !Array.isArray(dataSource) || dataSource.length === 0;

    return (
      <div
        style={{
          position: "relative",
          width: width || "100%",
          height: height || "100%",
          fontSize: "14px",
        }}
      >
        {showStatus && (
          <div
            className={`${classPrefix}-chart-status`}
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              textAlign: "center",
              lineHeight: `${height}px`,
              background: "#F8F8F8",
              zIndex: 9,
              width: width || "100%",
              height: height || "100%",
              ...tipsStyle,
            }}
          >
            {tips || t.noData}
          </div>
        )}
        <div
          style={{
            width: width || "100%",
            height: height || "100%",
            position: "relative",
          }}
          ref={container}
        />
        {React.Children.map(children, child => {
          return React.cloneElement(child, { chart, annotation });
        })}
      </div>
    );
  }
);
