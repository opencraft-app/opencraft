import React, { Fragment, useState } from "react";
import { BasicBar } from "@tencent/tea-chart/lib/basicbar";
import { Switch } from "@tencent/tea-component";

export default function SimpleBasicBarExample() {
  const [label, setLabel] = useState(false);
  const data = [
    { week: "周一", value: 10, province: "深圳" },
    { week: "周二", value: 20, province: "深圳" },
    { week: "周三", value: 70, province: "深圳" },
    { week: "周四", value: 60, province: "深圳" },
    { week: "周五", value: 42, province: "深圳" },
    { week: "周六", value: 72, province: "深圳" },
    { week: "周日", value: 98, province: "深圳" },
    { week: "周一", value: 10, province: "广州" },
    { week: "周二", value: -110, province: "广州" },
    { week: "周三", value: 50, province: "广州" },
    { week: "周四", value: 60, province: "广州" },
    { week: "周五", value: 23, province: "广州" },
    { week: "周六", value: 72, province: "广州" },
    { week: "周日", value: 98, province: "广州" },
    { week: "周一", value: 10, province: "香港" },
    { week: "周二", value: -110, province: "香港" },
    { week: "周三", value: 50, province: "香港" },
    { week: "周四", value: null, province: "香港" },
    { week: "周五", value: 20, province: "香港" },
    { week: "周六", value: 72, province: "香港" },
    { week: "周日", value: 98, province: "香港" },
  ];

  return (
    <Fragment>
      <section>
        <Switch value={label} onChange={value => setLabel(value)}>
          是否显示数据文本
        </Switch>
      </section>
      <BasicBar
        height={250}
        position="week*value"
        color="province"
        dataSource={data}
        dataLabels={label}
      />
    </Fragment>
  );
}
