import React, { Fragment, useState } from "react";
import { Switch } from "@tencent/tea-component";
import { BasicBar } from "@tencent/tea-chart/lib/basicbar";

export default function SimpleBasicBarExample() {
  const [invert, setInvert] = useState(false);

  const data = [
    { week: "周一", value: 10 },
    { week: "周二", value: 20 },
    { week: "周三", value: 50 },
    { week: "周四", value: 60 },
    { week: "周五", value: 20 },
    { week: "周六", value: 72 },
    { week: "周日", value: 98 },
  ];

  return (
    <Fragment>
      <section>
        <Switch value={invert} onChange={setInvert}>
          切换坐标轴
        </Switch>
      </section>
      <BasicBar
        height={250}
        position={invert ? "value*week" : "week*value"}
        dataSource={data}
      />
    </Fragment>
  );
}
