import React, { Fragment } from "react";
import { BasicBar } from "@tencent/tea-chart/lib/basicbar";

export default function LargeExample() {
  const dataCount = 500;
  const data = [];
  const date = new Date();
  for (let i = 0; i < dataCount; i++) {
    data.push({
      time: `${date.getHours()}:${date.getMinutes()}`,
      value: Math.floor(Math.random() * 5000),
    });
    const dateTime = date.getTime();
    date.setTime(dateTime + 60000);
  }

  return (
    <Fragment>
      <BasicBar height={250} position="time*value" dataSource={data} />
    </Fragment>
  );
}
