import React, {
  useRef,
  useEffect,
  useImperativeHandle,
  useState,
  useMemo,
} from "react";
import { RectProps } from "../_chart/type/chart";
import { Chart } from "../_chart";
import { Bar } from "../_chart/shapes/bar";
import { ChartBase } from "../chartbase";
import { comparePropsEqual } from "../_chart/lib/compare-props-equal";

export interface BasicBarProps extends RectProps {
  /**
   * 每个 X 轴点对应柱形的总宽度
   */
  size?: number;
  /**
   * 每个 X 轴点对应柱形的最大宽度，如果同时定义了size则优先使用size
   * @default 60
   * @since 2.0
   */
  maxBarWidth?: number;
}

export function BasicBar(props: BasicBarProps) {
  const { chartRef: ref } = props;
  const chartRef = useRef<Chart>();
  const [newProps, updateProps] = useState(props);
  const shapeRef = useRef<Bar>();

  useEffect(() => {
    if (chartRef.current) {
      shapeRef.current = chartRef.current.bar();
    }
  }, [chartRef]);

  useImperativeHandle(ref, () => ({
    on: (...args) => {
      if (chartRef.current) {
        chartRef.current.on(...args);
      }
    },
    once: (eventName: string, callback) => {
      if (chartRef.current) {
        chartRef.current.once(eventName, callback);
      }
    },
    off: (eventName: string, callback) => {
      if (chartRef.current) {
        chartRef.current.off(eventName, callback);
      }
    },
    emit: (...args) => {
      if (chartRef.current) {
        chartRef.current.emit(...args);
      }
    },

    getData: (x: number) => {
      return shapeRef.current.getData(x);
    },

    getDataFromCategory: (category: string) => {
      return shapeRef.current.getDataFromCategory(category);
    },

    getPosition: (category: string, value: number) => {
      return shapeRef.current.getPosition(category, value);
    },
  }));

  useEffect(() => {
    if (!comparePropsEqual(newProps, props)) {
      updateProps(props);
    }
  }, [newProps, props]);

  useEffect(() => {
    const {
      position,
      size,
      color,
      xAxis = true,
      yAxis = true,
      dataLabels,
      maxBarWidth = 60,
    } = newProps;
    const xAxes = typeof xAxis === "boolean" ? { enable: xAxis } : xAxis;
    const yAxes = typeof yAxis === "boolean" ? { enable: yAxis } : yAxis;
    const shapeOpts =
      typeof dataLabels === "boolean"
        ? { dataLabels: { enable: dataLabels } }
        : { dataLabels: { ...dataLabels } };

    shapeRef.current
      .maxWidth(maxBarWidth)
      .position(position)
      .color(color)
      .size(size)
      .axis({ xAxis: xAxes, yAxis: yAxes })
      .shape(shapeOpts);
  }, [newProps]);

  return useMemo(() => {
    return <ChartBase {...newProps} ref={chartRef} />;
  }, [newProps]);
}
