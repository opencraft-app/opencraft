import React from "react";
import { Text, Card } from "@tencent/tea-component";
import { CompareLine } from "@tencent/tea-chart/lib/compareline";

export default function SimpleBasicLineExample() {
  const data = [
    { time: "0:00", value: 10, date: "2018-10-10" },
    { time: "1:00", value: 20, date: "2018-10-10" },
    { time: "2:00", value: 110, date: "2018-10-10" },
    { time: "3:00", value: 60, date: "2018-10-10" },
    { time: "4:00", value: 20, date: "2018-10-10" },
    { time: "5:00", value: 56, date: "2018-10-10" },
    { time: "6:00", value: 98, date: "2018-10-10" },
    { time: "7:00", value: 20, date: "2018-10-10" },
    { time: "8:00", value: 33, date: "2018-10-10" },
    { time: "9:00", value: 58, date: "2018-10-10" },
    { time: "10:00", value: 63, date: "2018-10-10" },
    { time: "11:00", value: 22, date: "2018-10-10" },
    { time: "12:00", value: 123, date: "2018-10-10" },
    { time: "0:00", value: 10, date: "2018-10-11" },
    { time: "1:00", value: 20, date: "2018-10-11" },
    { time: "2:00", value: 60, date: "2018-10-11" },
    { time: "3:00", value: 60, date: "2018-10-11" },
    { time: "4:00", value: 20, date: "2018-10-11" },
    { time: "5:00", value: 72, date: "2018-10-11" },
    { time: "6:00", value: null, date: "2018-10-11" },
    { time: "7:00", value: 60, date: "2018-10-11" },
    { time: "8:00", value: 70, date: "2018-10-11" },
    { time: "9:00", value: 58, date: "2018-10-11" },
    { time: "10:00", value: 22, date: "2018-10-11" },
    { time: "11:00", value: 68, date: "2018-10-11" },
    { time: "12:00", value: 83, date: "2018-10-11" },
  ];

  const tooltipFormatter = series => {
    return series.map((item, index) => {
      return {
        ...item,
        label: `${item.label} (${index === 0 ? "昨天" : "今天"})`,
      };
    });
  };

  const legendFormatter = (label, index) => {
    return `${label} (${index === 0 ? "昨天" : "今天"})`;
  };

  return (
    <Card>
      <Card.Body title="数据对比">
        <div>
          <Text theme="label" style={{ fontSize: 14 }}>
            指标：12363收到客户端 commit0x42 消息，IP 数：20个 统计方式：平均值
          </Text>
        </div>
        <CompareLine
          height={250}
          dataSource={data}
          position="time*value"
          color="date"
          tooltip={{ formatter: tooltipFormatter }}
          legend={{ formatter: legendFormatter }}
        />
      </Card.Body>
    </Card>
  );
}
