import React from "react";
import { Text, Card } from "@tencent/tea-component";
import { CompareLine } from "@tencent/tea-chart/lib/compareline";

export default function SimpleBasicLineExample() {
  const ips = [
    "10.0.0.1",
    "10.0.0.2",
    "10.0.0.3",
    "10.0.0.4",
    "10.0.0.5",
    "10.0.0.6",
    "10.0.0.7",
    "10.0.0.8",
    "10.0.0.9",
  ];

  const dataCount = 24;
  const data = [];
  const date = new Date();
  for (let i = 0; i < dataCount; i++) {
    for (const ip of ips) {
      data.push({
        time: `${date.getHours()}:${date.getMinutes()}`,
        value: Math.floor(Math.random() * (70 - 40) + 40),
        ip,
      });
    }
    const dateTime = date.getTime();
    date.setTime(dateTime + 60000);
  }

  return (
    <Card>
      <Card.Body title="数据对比">
        <div>
          <Text theme="label" style={{ fontSize: 14 }}>
            指标：12363收到客户端 commit0x42 消息，IP 数：20个 统计方式：平均值
          </Text>
        </div>
        <CompareLine
          height={250}
          dataSource={data}
          position="time*value"
          color="ip"
          legend={false}
          scale={{
            value: {
              domain: [0, 100],
            },
          }}
        />
      </Card.Body>
    </Card>
  );
}
