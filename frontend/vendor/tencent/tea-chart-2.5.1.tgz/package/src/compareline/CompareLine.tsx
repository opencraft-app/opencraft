import React from "react";
import { BasicLine, BasicLineProps } from "../basicline";
import { Omit } from "../_type";

/**
 * CompareLine 组件支持的属性。
 */
export interface CompareLineProps extends Omit<BasicLineProps, "color"> {
  /**
   * 使用颜色来区分的数据系列（属性名）
   */
  color?: string;
}

export function CompareLine(props: CompareLineProps) {
  const { color } = props;

  const colorFormatter = (_, i: number) => {
    if (i === 0) return "#2d70f6";
    return "#B8D6FF";
  };

  const propsCopy: BasicLineProps = Object.assign(
    {
      size: 2,
    },
    props,
    {
      color: { key: color, colors: colorFormatter },
    }
  );

  return <BasicLine {...propsCopy} />;
}
