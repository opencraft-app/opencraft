# CompareLine 对比折线

对比折线图适用于多条数据系列之间进行对比的场景。

## 使用示例

可用于同比环比的数据对比

[Example: 基本使用](./_example/Simple.jsx)

当有大量对比数据时，可以隐藏图例和图标

[Example: 基本使用](./_example/Multiple.jsx)

## 组件属性

[Interface: CompareLineProps](./CompareLine.tsx)
