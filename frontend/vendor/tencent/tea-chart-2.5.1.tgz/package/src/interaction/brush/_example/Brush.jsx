import React, { Fragment, useEffect, useRef } from "react";
import { BasicLine } from "@tencent/tea-chart/lib/basicline";
import { BasicBar } from "@tencent/tea-chart/lib/basicbar";

export default function ZoomExample() {
  const lineChart = useRef(null);
  const barChart = useRef(null);

  const dataCount = 1000;
  const data = [];
  const date = new Date();
  for (let i = 0; i < dataCount; i++) {
    data.push({
      time: `${date.getHours()}:${date.getMinutes()}`,
      // 设值域为 [3000, 5000]
      value: Math.floor(Math.random() * (5000 - 4000) + 4000),
    });
    const dateTime = date.getTime();
    date.setTime(dateTime + 60000);
  }

  useEffect(() => {
    // 通过监听 selection.end 事件可以获得框选范围起始点和结束点的数据
    lineChart.current.on("selection.end", (start, end) => {
      console.log(lineChart.current.getData(start));
      console.log(lineChart.current.getData(end));
    });

    // 通过监听 selection.end 事件可以获得框选范围起始点和结束点的数据
    barChart.current.on("selection.end", (start, end) => {
      console.log(barChart.current.getData(start));
      console.log(barChart.current.getData(end));
    });
  }, [lineChart, barChart]);

  return (
    <Fragment>
      <h3>折线图</h3>
      <BasicLine
        interaction={["brush"]}
        height={250}
        position="time*value"
        size={1}
        dataSource={data}
        scale={{
          value: {
            domain: "autofit",
          },
        }}
        chartRef={ref => {
          lineChart.current = ref;
        }}
      />
      <h3>柱状图</h3>
      <BasicBar
        interaction={["brush"]}
        height={250}
        position="time*value"
        dataSource={data}
        scale={{
          value: {
            domain: "autofit",
          },
        }}
        chartRef={ref => {
          barChart.current = ref;
        }}
      />
    </Fragment>
  );
}
