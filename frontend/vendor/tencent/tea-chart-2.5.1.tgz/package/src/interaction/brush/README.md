# Brush 框选

## 使用示例

直角坐标系的图形可以进行框选

[Example: 框选](./_example/Brush.jsx)

