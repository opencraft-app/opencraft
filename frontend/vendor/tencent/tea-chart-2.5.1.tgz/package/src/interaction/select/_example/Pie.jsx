import React, { Fragment, useRef, useEffect } from "react";
import { Row, Col } from "@tencent/tea-component";
import { BasicPie } from "@tencent/tea-chart/lib/basicpie";

export default function SelectPieExample() {
  const pie1 = useRef(null);
  const pie2 = useRef(null);

  const data = [
    { type: "防止主机瘫痪", value: 291 },
    { type: "避免数据泄露", value: 302 },
    { type: "防止页面篡改", value: 82 },
  ];

  useEffect(() => {
    pie1.current.on("interaction.selected", data => {
      console.log(data);
    });

    pie2.current.on("interaction.selected", data => {
      console.log(data);
    });
  }, []);

  return (
    <Fragment>
      <Row>
        <Col span={12}>
          <BasicPie
            interaction={["element-select"]}
            height={250}
            dataSource={data}
            position="value"
            color="type"
            chartRef={r => {
              pie1.current = r;
            }}
          />
        </Col>
        <Col span={12}>
          <BasicPie
            interaction={["element-select"]}
            circle
            height={250}
            dataSource={data}
            position="value"
            color="type"
            chartRef={r => {
              pie2.current = r;
            }}
          />
        </Col>
      </Row>
    </Fragment>
  );
}
