import React, { Fragment, useRef, useEffect } from "react";
import { BasicBar } from "@tencent/tea-chart/lib/basicbar";

export default function SelectPieExample() {
  const barRef = useRef(null);

  const data = [
    { week: "周一", value: 10, province: "深圳" },
    { week: "周二", value: 20, province: "深圳" },
    { week: "周三", value: 70, province: "深圳" },
    { week: "周四", value: 60, province: "深圳" },
    { week: "周五", value: 42, province: "深圳" },
    { week: "周六", value: 72, province: "深圳" },
    { week: "周日", value: 98, province: "深圳" },
    { week: "周一", value: 10, province: "广州" },
    { week: "周二", value: -110, province: "广州" },
    { week: "周三", value: 50, province: "广州" },
    { week: "周四", value: 60, province: "广州" },
    { week: "周五", value: 23, province: "广州" },
    { week: "周六", value: 72, province: "广州" },
    { week: "周日", value: 98, province: "广州" },
    { week: "周一", value: 10, province: "香港" },
    { week: "周二", value: -110, province: "香港" },
    { week: "周三", value: 50, province: "香港" },
    { week: "周四", value: null, province: "香港" },
    { week: "周五", value: 20, province: "香港" },
    { week: "周六", value: 72, province: "香港" },
    { week: "周日", value: 98, province: "香港" },
  ];

  useEffect(() => {
    barRef.current.on("interaction.selected", (group, item) => {
      console.log(group, item);
    });
  }, []);

  return (
    <Fragment>
      <BasicBar
        // theme={{ interaction: { selected: { fill: "red", opacity: 1 } } }}
        interaction={["element-select"]}
        chartRef={ref => {
          barRef.current = ref;
        }}
        height={250}
        position="week*value"
        color="province"
        dataSource={data}
      />
    </Fragment>
  );
}
