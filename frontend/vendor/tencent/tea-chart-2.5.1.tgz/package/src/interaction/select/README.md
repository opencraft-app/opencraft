# Select 选中元素

## 使用示例

对饼图和环形图可以设置选中事件

[Example: 饼图](./_example/Pie.jsx)

对柱状图也可以设置选中事件

[Example: 饼图](./_example/Bar.jsx)

