# Zoom 缩放

## 使用示例

直角坐标系的图形可以进行缩放

[Example: 缩放](./_example/Zoom.jsx)

可以设置重置按钮的文本

[Example: 缩放](./_example/ResetButton.jsx)

