import React, { Fragment } from "react";
import { BasicLine } from "@tencent/tea-chart/lib/basicline";

export default function ZoomExample() {
  const dataCount = 1000;
  const data = [];
  const date = new Date();
  for (let i = 0; i < dataCount; i++) {
    data.push({
      time: `${date.getHours()}:${date.getMinutes()}`,
      // 设值域为 [3000, 5000]
      value: Math.floor(Math.random() * (5000 - 4000) + 4000),
    });
    const dateTime = date.getTime();
    date.setTime(dateTime + 60000);
  }

  return (
    <Fragment>
      <BasicLine
        interaction={{
          zoom: { resetText: "Reset" },
        }}
        height={250}
        position="time*value"
        size={1}
        dataSource={data}
        scale={{
          value: {
            domain: "autofit",
          },
        }}
      />
    </Fragment>
  );
}
