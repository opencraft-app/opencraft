import React from "react";
import { ConfigProvider } from "@tencent/tea-chart/lib/configprovider";
import { BasicLine } from "@tencent/tea-chart/lib/basicline";

export default function ConfigProviderExample() {
  const data = [
    { time: "0:00", value: 10 },
    { time: "1:00", value: 20 },
    { time: "2:00", value: 50 },
    { time: "3:00", value: 60 },
    { time: "4:00", value: 20 },
    { time: "5:00", value: 72 },
    { time: "6:00", value: 98 },
    { time: "7:00", value: 60 },
    { time: "8:00", value: 70 },
    { time: "9:00", value: 58 },
    { time: "10:00", value: 22 },
    { time: "11:00", value: 68 },
    { time: "12:00", value: 83 },
  ];

  return (
    <ConfigProvider locale="zh" classPrefix="tea2">
      <h3>折线</h3>
      <BasicLine
        height={250}
        position="time*value"
        dataSource={data}
        theme={{
          classPrefix: "tea3",
        }}
        xAxis={{
          title: {
            text: "时间",
          },
        }}
        yAxis={{
          title: {
            text: "数值",
          },
        }}
      />
    </ConfigProvider>
  );
}
