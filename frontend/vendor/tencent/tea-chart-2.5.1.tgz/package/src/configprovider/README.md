# ConfigProvider 全局配置

为组件提供全局配置。

## 使用示例

### 基本用法

[Example: ConfigProviderExample](./_example/ConfigProviderExample.jsx)

<!-- ## 跨 Provider 配置

组件库提供了 `setConfig` 配置方法，可设置项目中所有 ConfigProvider 的配置（这种用法下无需直接在某个 ConfigProvider 传入 props）。

注意：ConfigProvider 中 props 传入配置优先级高于 `setConfig` 的全局配置。 -->

## 组件属性

[Interface: ConfigProps](../_util/config-context/config-context.tsx)
