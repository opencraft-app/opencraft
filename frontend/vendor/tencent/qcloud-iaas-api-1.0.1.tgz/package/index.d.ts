declare module "@tencent/qcloud-iaas-api" {
  export function capiRequest<TResult = any, TParam = any, TOpts = any>(
    param: APIRequestParam<TParam>,
    opts?: APIRequestOpts & TOpts
  ): Promise<TResult>;
  export { capiRequest as apiRequest }
  export function request<TResult = any, TParam = any, TOpts = any>(
    url: string,
    param: RequestParam & TParam,
    opts?: RequestOpts & TOpts
  ): Promise<TResult>;
  export function gqlRequest<TResult = any, TParam = any, TOpts = any>(
    param: GQLRequestParam<TParam>,
    opts?: APIRequestOpts & TOpts
  ): Promise<GQLRequestResult<TResult>>;
  export function singleGqlRequest<TResult = any, TParam = any, TOpts = any>(
    param: GQLSingleRequestParam<TParam>,
    opts?: APIRequestOpts & TOpts
  ): Promise<GQLSingleRequestResult<TResult>>;
  export function getGqlData(pathArray: string[], data: any);
  export function getGqlError(pathArray: string[], errors: GQLRequestError[]);
  export function ready(): Promise<PostSend>;
  export const codes: {
    needLogin: CodeMap;
    noAuth: CodeMap;
    camRefused: CodeMap;
  };

  export type PostSend = (url: string, param: any, opts: any) => Promise<any>;
  // ---------------- request接口 -------------------
  export interface RequestParam {}
  export interface RequestOpts {
    /** 是否显示全局加载条 默认true */
    global?: boolean;
    /** 是否显示失败提示 默认true */
    tipErr?: boolean;
    /** 是否使用经典的 json 回包(code=0, 表示成功, 其他表示失败) 默认true */
    classicResponse?: boolean;
    /** 是否v3接口，云apiv3 无code，直接返回  默认false */
    v3?: boolean;
    /** 指定v3接口的Version字段，默认为"2017-03-12" */
    Version?: string
  }

  // --------------- apiRequest接口 ------------------
  export interface APIRequestParam<T> extends RequestParam {
    /** 云API 服务类别 */
    serviceType: string;
    /** 云API Action，与`data.Action`二选一，必须指定一个 */
    action?: string;
    /** 云API请求地域，与`data.Region`二选一，必须指定一个 */
    regionId?: number;
    /**
     * 兼容 console 云 api 接口透传参数名，当没有`action`参数时使用它作为云API Action
     * @deprecated
     */
    cmd?: string;
    data?: T & {
      Region?: string;
      Action?: string;
    };
  }
  export interface APIRequestOpts extends RequestOpts {
    /** cam鉴权失败时, 是否提示 默认true*/
    camTips?: boolean;
    /** cam 失败时, 可选弹框提示，默认dialog */
    camTipsType?: "dialog";
  }

  // --------------- gqlRequest ----------------
  export interface GQLRequestParam<T> {
    regionId: number;
    variables: T;
    operationName: string;
    query: string;
  }
  export interface GQLRequestResult<T> {
    /** 如果有此值且不为0，则表示有错误 */
    code?: any;
    data?: T;
    errors?: GQLRequestError[];
  }
  export interface GQLRequestError {
    path: string[];
    message: string;
  }

  // ------------- singleGqlRequest --------------
  export interface GQLSingleRequestParam<T> {
    regionId: number;
    /** 请求的路径，例如 ['resource', 'loadbalance', 'list'] */
    path: string[];
    /** 返回格式，例如 "{totalCount nodes{ id name, vpcId @include(if:$getVpc) }}" */
    schema: string;
    /** 请求参数，例如 {offset:0, limit:20} */
    params?: T;
    /** 支持的参数，例如 { offset: 'Int', limit: 'Int' } */
    paramsSchema?: { [key in keyof T]?: string };
    /** 用户自定义参数，用于schema中使用条件语句，例如 { getVpc: 'Boolean' } */
    localParamsSchema?: { [key in keyof T]?: string };
  }
  export interface GQLSingleRequestResult<T> extends GQLRequestResult<T> {
    error?: GQLRequestError;
  }
  // --------------- codes ----------------
  export interface CodeMap {
    [stringCode: string]: 1
    [numberCode: number]: 1
  }
}
