var defaultDomain = window.QCBASE_HOST || "iaas." + document.domain;
var request = (exports.request = (function (root) {
  var proxyReady = function (opts) {
    var id = (opts && opts.id) || "qcbase-proxy";
    var iframe;
    var domain = (opts && opts.domain) || defaultDomain;
    return new Promise(function (resolve, reject) {
      iframe = document.getElementById(id);
      if (iframe) {
        // iframe 中的 domain 可能还没生效
        try {
          if (iframe.contentWindow.postSend) {
            return resolve(iframe.contentWindow.postSend);
          }
        } catch (e) {}
      } else {
        iframe = document.createElement("iframe");
        iframe.id = id;
        iframe.style.display = "none";
        iframe.src = "//" + domain + "/proxy.html";
        document.body.appendChild(iframe);
      }
      iframe.addEventListener("load", function () {
        try {
          resolve(iframe.contentWindow.postSend);
        } catch (e) {
          reject(e);
        }
      });
      iframe.addEventListener("error", reject);
    });
  };

  var request = function (url, params, opts) {
    opts = opts || {};
    return proxyReady(opts)
      .then(function (postSend) {
        return postSend(url, params, opts);
      })
      .then(
        function (data) {
          if (opts.classicResponse === false) {
            return data;
          } else {
            if (data.code == 0) {
              return data.data;
            } else {
              throw data;
            }
          }
        },
        function (e) {
          throw e;
        }
      );
  };

  return request;
})(this));

/**
 * 云 api 代理
 * @param {Object} data { serviceType: "vpc", action: "DescribeVpc", regionId: 1, data: {offset:0, limit:10} }
 * @param {Object} [opts] 配置项
 * @return {Promise<Object>}
 */
exports.capiRequest = exports.apiRequest = function capiRequest(data, opts) {
  opts = opts || {};
  //data.cmd: 兼容 console 云 api 接口透传参数名
  if (data.cmd && !data.action) {
    data.action = data.cmd;
  }
  var action = (data.data && data.data.Action) || data.action || "";

  data.data = data.data || {};
  if (opts.v3 && !data.data.Version) {
    data.data.Version = opts.Version || "2017-03-12";
  }

  return request(
    "/cgi/capi?i=" + data.serviceType + "/" + action,
    data,
    opts
  ).then(function (data) {
    if (opts.v3) {
      var Response = data && data.Response;
      if (Response && Response.Error) {
        throw Response.Error;
      }
      return Response;
    }
    return data;
  });
};

/**
 * 通用的错误码，自行处理，例如包装公共方法
 * import {request, codes} from '@tencent/qcloud-iaas-api'
 * function errorHandler(e){
 *  if(e.code in codes.needLogin){ login.show() }
 *  throw e
 * }
 *
 * function myRequest(...){
 *  return request(...).catch(errorHandler)
 * }
 *
 */
var codes = (exports.codes = {
  /** 登录失效 */
  needLogin: {
    VERIFY_LOGIN_FAILED: 1,
  },
  /** 未实名 */
  noAuth: {
    800200: 1,
  },
  /** CAM错误 */
  camRefused: {
    4102: 1,
    42: 1,
  },
});

/**
 * GraphQL请求
 * @param {*} data { regionId:1, operationName: "list", query: `query list ($limit: Int){ ... }`  }
 * @param {*} opts
 * @return {Promise<{ data, errors }>} result 建议使用getGqlData和getGqlError来进行层级提取
 */
function gqlRequest(data, opts) {
  return request("/cgi/graphql", data, opts);
}
exports.gqlRequest = gqlRequest;

/**
 * 获取graphql层级里指定的属性
 * 例如
 * @param {*} pathArray 如 ['resource', 'loadbalance', 'list']
 * @param {*} data 如 { resource: { loadbalance: { list: {...} } } }
 * @return {*} 返回对应层级的数据，如果没有此层级，返回null
 */
exports.getGqlData = function getGqlData(pathArray, data) {
  var o = data,
    i,
    key;
  for (i = 0; i < pathArray.length; i++) {
    key = pathArray[i];
    if (o && key in o) {
      o = o[key];
    } else {
      return null;
    }
  }
  return o;
};

/**
 * 获取 graphql 错误提示
 * @param {Array} pathArray 数据路径
 * @param {Array} errors graphql接口返回的错误列表
 * @return {*} error
 */
exports.getGqlError = function getGqlError(pathArray, errors) {
  pathArray = pathArray || [];
  var path = pathArray.join(".");
  errors = errors || [];
  var i, e;
  for (i = 0; i < errors.length; i++) {
    e = errors[i];
    if ((e.path || []).join(".") == path) {
      return JSON.parse(e.message);
    }
  }
  return null;
};

function wrapSchema(schema, paths, thisParams) {
  var out;
  out =
    "{" +
    paths[0] +
    (paths.length > 1 ? wrapSchema(schema, paths.slice(1)) : schema) +
    "}";
  if (thisParams) {
    out = "(" + thisParams + ")" + out;
  }
  return out;
}

/**
 * 简化的gql请求，用于请求单个gql节点
 * @param {Object} data
 *  {Number} data.regionId
 *  {String[]} data.path 请求的路径，例如 ['resource', 'loadbalance', 'list']
 *  {String} data.schema 返回格式，例如 "{totalCount nodes{ id name, vpcId @include(if:$getVpc) }}"
 *  {Object} data.[params] 请求参数，例如 {offset:0, limit:20}
 *  {Object} data.[paramsSchema] 支持的参数，例如 { offset: 'Int', limit: 'Int' }
 *  {Object} data.[localParamsSchema] 用户自定义参数，用于schema中使用条件语句，例如 { getVpc: 'Boolean' }
 * @return { data, error, errors } 返回数据，如果是当前层级的错误，会放在error中。
 */
exports.singleGqlRequest = function singleGqlRequest(data, opts) {
  data = data || {};
  var regionId = data.regionId;
  var pathArray = data.path;
  var schema = data.schema;
  var queryData = data.params;
  var params = data.paramsSchema;
  var localParams = data.localParamsSchema;

  var paramKeys = Object.keys(params || {});
  var fullParams = $.extend({}, params, localParams);
  // 参数类型定义
  var paramsDefine = Object.keys(fullParams)
    .map(function (key) {
      return "$" + key + ": " + fullParams[key];
    })
    .join(", ");
  if (paramsDefine) {
    paramsDefine = "(" + paramsDefine + ")";
  }
  // Schema中的参数映射
  var paramsMap = paramKeys
    .map(function (key) {
      return "" + key + ": $" + key;
    })
    .join(", ");
  if (paramsMap) {
    paramsMap = "(" + paramsMap + ")";
  }
  // schema拼装
  var querySchema = wrapSchema(paramsMap + schema, pathArray);
  return gqlRequest(
    {
      regionId: regionId,
      variables: queryData,
      operationName: null,
      query: "query " + paramsDefine + querySchema,
    },
    opts
  ).then(
    function (response) {
      if (response.code) {
        return {
          error: response,
        };
      }
      var errors = response.errors;
      var result = getGqlData(pathArray, response.data);
      return {
        data: result,
        error: getGqlError(pathArray, errors) || (errors && errors[0]),
        errors: errors,
      };
    },
    function (e) {
      return {
        data: null,
        error: e,
        errors: [
          {
            path: pathArray,
            message: JSON.stringify(e),
          },
        ],
      };
    }
  );
};
