# 简介
iaas.qcloud.com的接口封装
仅限qcloud.com及cloud.tencent.com域或子域下页面使用，引入的页面需要有JSON及Promise
（私有化项目需要处于iaas.xxx同级子域名，例如console.xxx）
目前提供云api及graphql请求接口

适用于比较独立的购买页等页面使用

# 源码
http://git.code.oa.com/cluezhang/qcloud-iaas-api

# 用法
```
tnpm i @tencent/qcloud-iaas-api -S
```

```js
import { request, capiRequest, gqlRequest, getGqlData, getGqlError, singleGqlRequest } from '@tencent/qcloud-iaas-api'
// 云api请求
capiRequest({
    regionId: 1, 
    serviceType: "vpc", 
    action: "DescribeVpc",  
    data: {offset:0, limit:10} 
}).then(function(data){

})

// graphql请求
async function getData(filter){
    const { data, errors } = await gqlRequest({
        regionId: filter.regionId,
        variables: {
            offset: (filter.page - 1) * filter.count,
            limit: filter.count,
            keyword: filter.keyword
        },
        query: `
            query hsmList($offset: Int!, $limit: Int!, $keyword: String) {
              resource {
                hsm {
                  list(offset: $offset, limit: $limit, keyword: $keyword) {
                    totalCount
                    nodes {
                      regionId
                      id
                      name
                      zoneId
                      zone {
                        name
                      }
                    }
                  }
                }
              }
            }`
    });
    const paths = ["resource", "hsm", "list"];
    const result = getGqlData(paths, data);
    if (!result) {
        throw getGqlError(paths, errors) || "查询HSM列表失败";
    }
    return {
        totalCount: result.totalCount,
        list: result.nodes
    }
}


// 简化版的graphql请求
// 做公共错误处理时请注意，singleGqlRequest不会throw错误，而是统一在 result.error 中返回
singleGqlRequest({
    regionId: 1,
    path: ['resource', 'loadbalance', 'vips'], 
    schema: '{totalCount nodes{id vip name}}',
    paramsSchema: {
        type: 'Int'
    },
    params : {
        type: 2
    }
    localParamsSchema {}
}).then(function({ data, error, errors }){
    
})

```
# 帮助 FAQ
如有问题，可以骚扰@cluezhang