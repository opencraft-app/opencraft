# 目的
为了使iaas-common的逻辑能通用于各个平台（公有云控制台、购买页、TCE、TCE运营端等），将平台的能力抽离到此目录下

在项目使用中，可以在tsconfig中配置映射，将 @tencent/iaas-common/inject/* 映射到不同的目录下，当然未来还可考虑直接发布适配包

# 注意事项
请使用 `@tencent/iaas-common/inject/xxx` 来引用此目录下的模块，否则无法在项目使用中实现统一替换（相对路径无法配置alias）