import { app } from '@tencent/tea-app'
export default {
  setRegionId(rid) {
    try {
      return app.user.setLastRegionId(rid)
    } catch {
      return seajs.require('appUtil').setRegionId(rid)
    }
  },
  getRegionId() {
    try {
      return app.user.getLastRegionId()
    } catch {
      return seajs.require('appUtil').getRegionId()
    }
  }
}
