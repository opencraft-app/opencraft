export default function getOwnerUin() {
  return seajs.require('util').getOwnerUin()
}