import iaas from '@tencent/iaas-common/inject/iaas'
import { app } from "@tencent/tea-app";
import buildConfig from '../buildConfig';

async function apiRequest<TResult = any, TParam = any>(
    params: APIRequestParam<TParam>,
    opts: APIRequestOpts = {},
): Promise<TResult> {
    const result = await app.capi.requestV3(
        {
            ...params,
            regionId: +params.regionId,
            data: {
                ...params.data,
            },
            cmd: params.cmd || params.action,
        },
        {
            ...opts,
            withLanguage: true,

        },
    );
    return result.data;
}

const requestApi = buildConfig?.useTeaApiRequest ? apiRequest : iaas.apiRequest
export default requestApi