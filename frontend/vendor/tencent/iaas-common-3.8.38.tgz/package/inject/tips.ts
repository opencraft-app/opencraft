export default {
  error(...args: any[]) {
    return seajs.require('tips').error(...args)
  },
  success(...args: any[]) {
    return seajs.require('tips').success(...args)
  },
  showLoading(...args: any[]) {
    return seajs.require('tips').showLoading(...args)
  },
  flash(...args: any[]) {
    return seajs.require('tips').flash(...args)
  },
  stopLoading(){
    return seajs.require('tips').stopLoading()
  }
}