interface RegionMaps {
  /** 1 => 'gz' */
  idToShortId: Record<number, string>
  /** 1 => '广州' */
  idToName: Record<number, string>
  /** 1 => 'ap-guangzhou' */
  idToV3Id: Record<number, string>
  /** 'ap-guangzhou' => 1 */
  v3IdToId: Record<string, number>
  /** 'ap-guangzhou' => {name:'广州',area:'华南地区'}  */
  v3IdToInfo: Record<string, { name: string; area: string }>
}
/**
 * 获取平台/CVM配置的地域映射
 */
export default function useRegionMaps(): RegionMaps {
  let constants = seajs?.require('constants') as C
  if (!constants) {
    // 如果取不到，预期是专有云
    constants = getTceMockConstants()
  }

  return {
    idToShortId: constants?.REGIONMAP || {},
    idToName: constants?.REGIONNAMES || {},
    idToV3Id: constants?.REGIONIDMAP || {},
    get v3IdToId(){
      const v3IdToId = {}
      for(const [id, v3Id] of Object.entries(constants?.REGIONIDMAP || {})){
        v3IdToId[v3Id] = +id
      }
      return v3IdToId
    },
    v3IdToInfo: constants?.REGIONAREAMAP || {}
  }
}

interface ZoneMaps {
  /** 100002 => '广州二区' */
  idToName: Record<number, string>
  /** 100002 => 'ap-guangzhou-2' */
  idToV3Id: Record<number, string>
  /** 100002 => 1 */
  idToRegionId: Record<number, number>
  /** 100002 => 'ap-guangzhou' */
  idToRegionV3Id: Record<number, string>
  /** ap-guangzhou-2 => '广州二区' */
  v3IdToName: Record<string, string>
  /** 'ap-guangzhou-2' = 100002 */
  v3IdToId: Record<string, number>
}
/**
 * 获取平台/CVM配置的可用区映射
 */
export function useZoneMaps(): ZoneMaps {
  const constants = seajs?.require('constants') as C

  return {
    idToName: constants?.ZONENAMEMAP || {},
    idToV3Id: constants?.ZONEIDMAP || {},
    idToRegionId: toNumber(constants?.ZONETOREGIONMAP || {}),
    idToRegionV3Id: constants?.ZONETOREGIONMAPV3 || {},
    v3IdToName: constants?.ZONEIDV3TONAMEMAP || {},
    v3IdToId: toNumber(constants?.ZONEV3TOZONEIDMAP || {})
  }
}

function toNumber(o: Record<string, string>) {
  const ret: Record<string, number> = {}
  for (const [k, v] of Object.entries(o)) {
    ret[k] = +v
  }
  return ret
}

interface C {
  /** REGIONMAP['1'] = 'gz' */
  REGIONMAP: Record<string, string>
  /** REGIONIDMAP['1'] = 'ap-guangzhou' */
  REGIONIDMAP: Record<string, string>
  /** ZONEIDMAP['100002'] = 'ap-guangzhou-2' */
  ZONEIDMAP: Record<string, string>
  /** ZONENAMEMAP['100002'] = '广州二区' */
  ZONENAMEMAP: Record<string, string>
  /** REGIONNAMES['1'] = '广州' */
  REGIONNAMES: Record<string, string>
  /** ZONETOREGIONMAP['100002'] = '1' */
  ZONETOREGIONMAP: Record<string, string>
  /** ZONETOREGIONMAPV3['100002'] = 'ap-guangzhou' */
  ZONETOREGIONMAPV3: Record<string, string>

  /** ZONEIDV3TONAMEMAP['ap-guangzhou-2'] = '广州二区' */
  ZONEIDV3TONAMEMAP: Record<string, string>

  /** REGIONAREAMAP['ap-guangzhou'] = {name:'广州',area:'华南地区'} */
  REGIONAREAMAP: Record<string, { name: string; area: string }>

  /** ZONEV3TOZONEIDMAP['ap-guangzhou-2'] = 100002 */
  ZONEV3TOZONEIDMAP: Record<string, string>
}

export function getTceMockConstants(): C {
  try {
    const tceSdk = require('@tencent/tce-sdk')
    const regionList: Region[] = tceSdk.region.getRegionListSync();
    const REGIONMAP = {}
    const REGIONIDMAP = {}
    const ZONEIDMAP = {}
    const ZONENAMEMAP = {}
    const REGIONNAMES = {}
    const ZONETOREGIONMAP = {}
    const ZONETOREGIONMAPV3 = {}
    const ZONEIDV3TONAMEMAP = {}
    const REGIONAREAMAP = {}
    const ZONEV3TOZONEIDMAP = {}
    for (const region of regionList) {
      // REGIONMAP['1'] = 'gz'
      REGIONMAP[region.regionId] = region.region
      // REGIONIDMAP['1'] = 'ap-guangzhou'
      REGIONIDMAP[region.regionId] = region.region
      // REGIONNAMES['1'] = '广州'
      REGIONNAMES[region.regionId] = region.regionName
      // REGIONAREAMAP['ap-guangzhou'] = {name:'广州',area:'华南地区'}
      REGIONAREAMAP[region.region] = { name: region.regionName, area: '' }
      for (const zone of region.zoneList) {
        // ZONEIDMAP['100002'] = 'ap-guangzhou-2'
        ZONEIDMAP[zone.zoneId] = zone.zone
        // ZONENAMEMAP['100002'] = '广州二区'
        ZONENAMEMAP[zone.zoneId] = zone.zoneName
        // ZONETOREGIONMAP['100002'] = '1'
        ZONETOREGIONMAP[zone.zoneId] = region.regionId
        // ZONETOREGIONMAPV3['100002'] = 'ap-guangzhou'
        ZONETOREGIONMAPV3[zone.zoneId] = region.region
        // ZONEIDV3TONAMEMAP['ap-guangzhou-2'] = '广州二区'
        ZONEIDV3TONAMEMAP[zone.zone] = zone.zoneName
        // ZONEV3TOZONEIDMAP['ap-guangzhou-2'] = 100002
        ZONEV3TOZONEIDMAP[zone.zone] = zone.zoneId
      }
    }
    return {
      REGIONMAP,
      REGIONIDMAP,
      ZONEIDMAP,
      ZONENAMEMAP,
      REGIONNAMES,
      ZONETOREGIONMAP,
      ZONETOREGIONMAPV3,
      ZONEIDV3TONAMEMAP,
      REGIONAREAMAP,
      ZONEV3TOZONEIDMAP,
    }
  } catch { }
}

export interface Region {
  /**
   * regionId，数字格式的
   */
  regionId: number;
  /**
   * region
   */
  region: string;
  /**
   * regionName: 根据不同语言返回的地域名称
   */
  regionName: string;
  zoneList: Zone[];
}
export interface Zone {
  /**
   * 地区ID
   */
  zoneId: number;
  /**
   * 地区【字符串类型】
   */
  zone: string;
  /**
   * 地区名称【根据不同语言返回的地域名称】
   */
  zoneName: string;
}