function getMainHost(): string {
  return window['QCMAIN_HOST'] || window['TCE_DOMAIN'] || window['TCE_GLOBAL_CONSTANT']?.baseHost || document.domain
}

/**
  * 公有云根域名获取（QCLOUD_ROOT_HOST）
  * 
  * 在window.QCLOUD_ROOT_HOST地基础上对旧国际站域名intl.cloud.tencent.com做特殊处理
  */
function getRootHost(): string {
  const mainHost = getMainHost()
  const rootHost = window['QCLOUD_ROOT_HOST'] || getMainHost()
  if (mainHost === 'intl.cloud.tencent.com') {
    return mainHost
  }
  return rootHost
}

const regexStartWithDash = /^\//
const regexDocument = /^\/document\/product\//
const regexUrlParams = /\?/

/**
 * 
 * 仅用在匹配国际站域名场景，intl 匹配旧国际站域名，tencentcloud.com 为新域名
 */
const regexIntl = /(^intl\.|tencentcloud\.com$)/

/**
 * 保证路径是 / 起始
 * @param path
 */
function fix(path: string) {
  if (path && !regexStartWithDash.test(path)) {
    return '/' + path
  }
  return path || ''
}

/**
 * 移除 ReplaceDomainLoader 插件，使用方法统一生成链接地址进行兼容
 */
const links = {
  /**
   * 生成到主站的链接，对应公有云的 //cloud.tencent.com/path 或 //www.qcloud.com/path
   * @param path
   * @param autoRedirect 国际站是否添加自动跳转表示
   */
  main(v: string, autoRedirect:boolean = true) {
    let path = fix(v)
    // 是否存在intl
    if (regexIntl.test(getMainHost())) {
      // 是否是文档链接
      if (autoRedirect && path && regexDocument.test(path)) {
        if (regexUrlParams.test(path)) {
          path = path + '&from_cn_redirect=1'
        } else {
          path = path + '?from_cn_redirect=1'
        }
      }
    }
    return `//${getMainHost()}${path}`
  },
  /**
   * 生成到控制台的链接，对应公有云的 //console.cloud.tencent.com/path 或 //console.qcloud.com/path
   * @param path
   */
  console(path: string) {
    return `//${window['QCCONSOLE_HOST'] || window['TCE_GLOBAL_CONSTANT']?.consoleHost || `console.${getRootHost()}`}${fix(path)}`
  },
  /**
   * 生成到运营端的链接，对应私有云的 //cmgt.xxxx.xxx
   * @param path
   */
  cmgt(path: string) {
    return `//cmgt.${getMainHost()}${fix(path)}`
  },
  /**
   * 生成到购买页的链接，对应公有云的 //buy.cloud.tencent.com/path 或 //buy.qcloud.com/path
   * @param path
   */
  buy(path: string) {
    return `//${window['QCBUY_HOST'] || window['TCE_GLOBAL_CONSTANT']?.buyHost || `buy.${getRootHost()}`}${fix(path)}`
  },
  /**
   * 生成到qcbase的链接，对应公有云的 //iaas.cloud.tencent.com/path 或 //iaas.qcloud.com/path
   * @param path
   */
  iaas(path: string) {
    return `//${window['QCBASE_HOST'] || window['TCE_GLOBAL_CONSTANT']?.qcbaseHost || `iaas.${getRootHost()}`}${fix(path)}`
  },
  mainHost: getMainHost,
  /**
   * 生成到cdn表态资源的地址
   */
  cdn(path: string) {
    return `//${window['QCCDN_HOST'] || window['QCIMGCACHE_HOST'] || window['TCE_GLOBAL_CONSTANT']?.imgcacheHost}${fix(path)}`
  },
  getRootHost
}

export default links
