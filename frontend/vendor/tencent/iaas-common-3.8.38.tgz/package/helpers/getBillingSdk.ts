/**
 * 获取计费SDK
 *
 * 给billing-sdk添加声明
 */

export default async function getBillingSdk(): Promise<BillingSdk> {
  return (await seajs.require('lib/billing-sdk-importer').ready()) as BillingSdk
}

// cluezhang: 只声明了部分接口，有需要的自行补充
export interface BillingSdk {
  queryPrice: <TGoodsData>(
    params: Params<QueryPriceParams<TGoodsData>>
  ) => Promise<QueryPriceResponse>
  directToCheck: (params: Params<OrderParams>) => Promise<any>
}

export interface Params<T> {
  /** 商品码(productCode)，如`cvm`、`cloud_kafka` */
  business: string
  version: SDK_VERSION
  params: T
}

export interface QueryPriceParams<TGoodsData = GoodsData> {
  resInfo: TGoodsData[]
}
/**
 * 商品参数（对应后台接口的`goods`字段）
 */
export interface GoodsData<TGoodsDetail = GoodsDetail> {
  /**
   * 业务操作ID：代表一个业务（商品码）的一个具体操作(新购、续费、变配等)。业务侧需要在panshi管理端做好配置，接口传goodsCategoryId参数询价（ 不要填成cid,tcb单研发审核后会生成 ），计费能解析出具体的业务和操作类型。
   *
   * 例如：
   *  - 100001： 是云搜的新购
   *  - 100002: 是云搜的续费
   */
  goodsCategoryId: number
  /**
   * 币种：CNY人民币,USD美元,如果不传，会根据ownerUin的国内站、国际站属性决定 CNY 还是 USD。如果要传，业务侧就需要区分 用户的国内站和国际站属性
   */
  currency?: CURRENCY
  /** 项目ID，没有项目概念则传0 */
  projectId: number
  /** 商品归属地域ID： 映射表,不区分地域的产品传:1(默认:广州),不传可能会导致其他未知问题 */
  regionId: number
  /** 商品归属区域ID： 映射表,不区分地域的产品传: 100001(默认:广州一区),不传可能会导致其他未知问题 */
  zoneId: number
  /** 资源实例个数：跟产品规格不一样，比如购买2核的机器一台,此处为1, 几个goodsNum发货后需要返回几个resourceid */
  goodsNum: number
  /** 付费模式：0表示按需计费/后付费，1表示预付费 2表示预留实例模式 */
  payMode: PAY_MODE
  /** 活动ID：（查寻活动折扣相关参数） */
  activityId?: number
  /** 商品详情 */
  goodsDetail: TGoodsDetail
}

export interface GoodsDetailBase {
  /**
   * 价格ID：每个商品的都会在计费对应一条价格策略ID，由业务的产品经理在计费配置,可以是组合商品,也可以是基础商品.
   *
   * 价格ID有两种类型：
   *  - 基础pid(基础商品)：定义具体一个组件的价格信息，主要包括价格模式(指定价、阶梯价、线性价等)、价格、询价参数等信息。
   *  - 组合pid(组合商品)：由多个基础商品构成，多个基础商品的价格加起来就是整个商品的价格。
   * 注:如果是对组合商品询价，这里必须传组合pid，如果只是对一个组件询价，可以传基础pid, pid查看地址和权限申请
   */
  pid: number
}

/** 新版4层价格定义 */
export interface GoodsDetailV2 {
  /** 产品标签，例如 p_cvm */
  productCode: string
  /** 子产品标签，例如 sp_cvm_s1 */
  subProductCode: string
}

/** 新购、续费需要传的参数 */
export interface GoodsDetailTimeSpan {
  /** 商品的时间单位：y:年；m:月；d:日；h:小时；M:分钟；s:秒; p:与计费周期无关,一次性购买的产品传p */
  timeUnit: TIME_UNIT
  /** 商品的时间大小（一次性售卖固定传1） */
  timeSpan: number
}

/** 续费/变配时需要传resourceId/curDeadline */
export interface GoodsDetailResource {
  resourceId: string
  curDeadline: string
}

/** 其它选填的参数 */
export interface GoodsDetail extends GoodsDetailBase {
  productInfo?: ProductInfoItem[]
  /** 老商品码(折扣相关参数)：老产品后付费必传参数,子商品码查询页面 例如cos产品 是 “cos”,不传则会使用goodsConfig中配置的老商品码，如果goodsConfig也没配置老商品码，则默认使用goodCategoryId的goodsName作为老商品码，但是部分后付费产品goodsName并非是他的老商品码，所以建议传正确的老商品码 */
  goodsType?: string
  /** 老子商品码(折扣相关参数)：老产品后付费必传参数,子商品码查询页面 例如cos的某款产品 “cos_bw_xregion” */
  goodsSubType?: string
  /** cvm机型相关参数，用于查相关机型折扣 */
  deviceClass?: string
  /** 预留实例模式下必传， 预留实例付费类型 1： 预付全部费用 2：预付部分费用 3：预付0元费用 （一期只支持了预付全部费用） */
  riType?: number
  /** 预留实例模式下必传， 预留实例付费周期：h:每小时周期费用； p:一次性预付费用 */
  riPayTimeUnit?: string
  /** 预留实例模式下必传， 预留实例付费周期：s 标准; c 可转换 */
  riMode?: string
  /** 是否自动续费 */
  autoRenewFlag?: number
}
export interface ProductInfoItem {
  name: string
  value: string
}

export type QueryPriceResponse = QueryPriceResponseItem[]
export interface QueryPriceResponseItem {
  /** 商品的单价,比如一台cvm一个时间单位的价格，单位：分 */
  price: number
  /** 总费用，不包含优惠，单位：分,= price*timeSpan∗goodsNum */
  totalCost: number
  /** 优惠后总费用, 单位: 分,例如用户享有折扣 =totalCost *$discount */
  realTotalCost: number
  timeUnit: TIME_UNIT
  timeSpan: number
  goodsNum: number
  /** 总的折扣，100表示100%不打折 */
  policy: number
  /** 计费公式 */
  formula?: string
}

type SDK_VERSION = '1.0' | '2.0'
export enum CURRENCY {
  CNY = 'CNY',
  USD = 'USD'
}
export enum PAY_MODE {
  /** 按量计费/后付费 */
  POSTPAY = 0,
  /** 预付费 */
  PREPAY = 1,
  /** 预留实例模式 */
  RESERVED = 2
}
export enum TIME_UNIT {
  YEAR = 'y',
  MONTH = 'm',
  DAY = 'd',
  HOUR = 'h',
  MINUTE = 'M',
  SECOND = 's',
  /** 一次性预付费用 */
  PERMANENT = 'p'
}

export interface OrderParams {
  /** 可选参数（MTA上报，需联系计费侧单独配置） */
  productFrom?: string
  /** 为 OrderParamsItemDetails 对象进行 JSON.stringify 序列化后的字符串 */
  itemDetails: string
}

// --------- 以下为整理的各种订单的声明，暂不包括退费 ----------
/** 新购 */
export interface GoodsDataCreate<TBusinessProps>
  extends GoodsData<GoodsDetailCreate & TBusinessProps> { }
/** 续费 */
export interface GoodsDataRenew<TBusinessProps>
  extends GoodsData<GoodsDetailRenew & TBusinessProps> { }

/** 升配 */
export interface GoodsDataUpgrade<TBusinessProps>
  extends GoodsData<GoodsDetailUpgrade<TBusinessProps>> { }
/** 降配 */
export interface GoodsDataDowngrade<TBusinessProps>
  extends GoodsData<GoodsDetailDowngrade<TBusinessProps>> { }

export interface GoodsDetailCreate extends GoodsDetail, GoodsDetailTimeSpan { }
export interface GoodsDetailRenew
  extends GoodsDetail,
  GoodsDetailTimeSpan,
  GoodsDetailResource { }

/** 变配时需要传的参数 */
export interface GoodsDetailUpgrade<T> extends GoodsDetailResource {
  oldConfig: GoodsDetailBase & T
  newConfig: GoodsDetailBase & T
  productInfo?: ProductInfoItem[]
}
export interface GoodsDetailDowngrade<T> extends GoodsDetailResource {
  oldConfig: T
  newConfig: T & { modifyMode: 'down' }
  productInfo?: ProductInfoItem[]
}
