import Semaphore from 'semaphore-async-await'
/**
 * 改写 Semaphore，扩展周期内限流的能力
 */
interface RateLimitParams {
  permits: number
  period?: number
}
export default class RateLimit {
  private semaphore: Semaphore
  period: number
  constructor(params: RateLimitParams) {
    const { permits, period } = params
    this.semaphore = new Semaphore(permits)
    this.period = period
  }

  /**
   * 上并发锁，如果设置了周期，会在周期后解锁
   */
  async acquire() {
    await this.semaphore.acquire()
    if (typeof this.period === "number") {
      setTimeout(() => {
        this.semaphore.release()
      }, this.period)
    }
  }

  /**
   * 释放信号量
   */
  release() {
    // 如果设置了周期，不需要手动释放信号量
    if (typeof this.period === "number") {
      return
    }
    this.semaphore.release()
  }
}
