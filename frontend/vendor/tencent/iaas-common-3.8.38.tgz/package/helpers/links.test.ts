import links from './links'

function getRandomHost() {
  return Math.random().toString(36).slice(2) + '.com'
}
const params = '?from_cn_redirect=1'
const hasParams = '&from_cn_redirect=1'

it('国际站文档处理', () => {
 
  const host = 'intl.cloud.tencent.com/document/product/xxx'

  global.window = {
    QCMAIN_HOST: 'intl.cloud.tencent.com'
  } as any

  expect(links.main('/document/product/xxx')).toStrictEqual(`//${host}${params}`)
  expect(links.main('document/product/xxx')).toStrictEqual(`//${host}${params}`)
  expect(links.main('/document/product/xxx?rid=1')).toStrictEqual(`//${host}?rid=1${hasParams}`)
  expect(links.main('document/product/xxx?rid=1')).toStrictEqual(`//${host}?rid=1${hasParams}`)
  expect(links.main('ckafka?rid=1')).toStrictEqual(`//intl.cloud.tencent.com/ckafka?rid=1`)
})
it('国内站文档处理', () => {
  const params = '?from_cn_redirect=1'
  const hasParams = '&from_cn_redirect=1'
  const host = 'cloud.tencent.com/document/product/xxx'

  global.window = {
    QCMAIN_HOST: 'cloud.tencent.com'
  } as any

  expect(links.main('/document/product/xxx')).toStrictEqual(`//${host}`)
  expect(links.main('/document/product/xxx?rid=1')).toStrictEqual(`//${host}?rid=1`)
  expect(links.main('ckafka?rid=1')).toStrictEqual(`//cloud.tencent.com/ckafka?rid=1`)
})

it('使用QCMAIN_HOST拼接', () => {
  const host = getRandomHost()
  // jest.spyOn(mockWindow, 'QCMAIN_HOST', 'get').mockImplementation(() => host)
  // mockWindow.QCMAIN_HOST = host
  global.window = {
    QCMAIN_HOST: host
  } as any

  expect(links.buy('ckafka?rid=1')).toStrictEqual(`//buy.${host}/ckafka?rid=1`)
  expect(links.console('ckafka?rid=1')).toStrictEqual(`//console.${host}/ckafka?rid=1`)
  expect(links.iaas('ckafka?rid=1')).toStrictEqual(`//iaas.${host}/ckafka?rid=1`)
  expect(links.main('ckafka?rid=1')).toStrictEqual(`//${host}/ckafka?rid=1`)
})

it('QCLOUD_ROOT_HOST比QCMAIN_HOST更优先',  () => {
  const host = getRandomHost()
  const rootHost = getRandomHost()
  // jest.spyOn(mockWindow, 'QCMAIN_HOST', 'get').mockImplementation(() => host)
  // mockWindow.QCMAIN_HOST = host
  global.window = {
    QCMAIN_HOST: host,
    QCLOUD_ROOT_HOST: rootHost
  } as any

  expect(links.buy('ckafka?rid=1')).toStrictEqual(`//buy.${rootHost}/ckafka?rid=1`)
  expect(links.console('ckafka?rid=1')).toStrictEqual(`//console.${rootHost}/ckafka?rid=1`)
  expect(links.iaas('ckafka?rid=1')).toStrictEqual(`//iaas.${rootHost}/ckafka?rid=1`)
  expect(links.main('ckafka?rid=1')).toStrictEqual(`//${host}/ckafka?rid=1`)
})


it('更优先使用QCBUY_HOST等域名', () => {
  const host = getRandomHost()
  const buyHost = getRandomHost()
  const iaasHost = getRandomHost()
  const consoleHost = getRandomHost()
  global.window = {
    QCMAIN_HOST: host,
    QCBUY_HOST: buyHost,
    QCBASE_HOST: iaasHost,
    QCCONSOLE_HOST: consoleHost
  } as any

  expect(links.buy('ckafka')).toStrictEqual(`//${buyHost}/ckafka`)
  expect(links.iaas('ckafka')).toStrictEqual(`//${iaasHost}/ckafka`)
  expect(links.console('ckafka')).toStrictEqual(`//${consoleHost}/ckafka`)
})

it('TCE兼容', () => {
  const host = getRandomHost()
  const tceHost = getRandomHost()
  global.window = {
    QCMAIN_HOST: host,
    TCE_DOMAIN: tceHost
  } as any
  expect(links.cmgt('ckafka')).toStrictEqual(`//cmgt.${host}/ckafka`)

  global.window = {
    TCE_DOMAIN: tceHost
  } as any
  expect(links.cmgt('ckafka')).toStrictEqual(`//cmgt.${tceHost}/ckafka`)
})

it('TCE/TCS新版兼容', () => {
  const o = {
    baseHost: getRandomHost(),
    consoleHost: getRandomHost(),
    imgcacheHost: getRandomHost(),
  }
  global.window = {
    TCE_GLOBAL_CONSTANT: o
  } as any
  expect(links.main('ckafka')).toStrictEqual(`//${o.baseHost}/ckafka`)
  expect(links.console('ckafka')).toStrictEqual(`//${o.consoleHost}/ckafka`)
  expect(links.cdn('ckafka')).toStrictEqual(`//${o.imgcacheHost}/ckafka`)
})

it('容错处理', () => {
  const host = getRandomHost()
  global.window = {
    QCMAIN_HOST: host,
  } as any
  expect(links.console.apply(links, [])).toStrictEqual(`//console.${host}`)
  expect(links.console('ckafka')).toStrictEqual(`//console.${host}/ckafka`)
  expect(links.console('/ckafka')).toStrictEqual(`//console.${host}/ckafka`)
})


it('getRootHost兼容旧国际站', () => {
  global.window = {
    QCMAIN_HOST: 'intl.cloud.tencent.com',
    QCLOUD_ROOT_HOST: 'cloud.tencent.com'
  } as any

  expect(links.getRootHost()).toStrictEqual(`intl.cloud.tencent.com`)
  expect(links.iaas('ckafka?rid=1')).toStrictEqual(`//iaas.intl.cloud.tencent.com/ckafka?rid=1`)
  expect(links.main('/document/product/xxx?rid=1')).toStrictEqual(`//intl.cloud.tencent.com/document/product/xxx?rid=1${hasParams}`)
  expect(links.main('ckafka?rid=1')).toStrictEqual(`//intl.cloud.tencent.com/ckafka?rid=1`)
})

it('getRootHost兼容新国际站', ()=>{
  global.window = {
    QCMAIN_HOST: 'www.tencentcloud.com',
    QCLOUD_ROOT_HOST: 'tencentcloud.com'
  } as any

  expect(links.getRootHost()).toStrictEqual(`tencentcloud.com`)
  expect(links.iaas('ckafka?rid=1')).toStrictEqual(`//iaas.tencentcloud.com/ckafka?rid=1`)
  expect(links.main('/document/product/xxx?rid=1')).toStrictEqual(`//www.tencentcloud.com/document/product/xxx?rid=1${hasParams}`)
  expect(links.main('ckafka?rid=1')).toStrictEqual(`//www.tencentcloud.com/ckafka?rid=1`)
})