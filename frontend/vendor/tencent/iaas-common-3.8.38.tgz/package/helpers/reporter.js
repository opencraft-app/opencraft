/**
 * tcss 统计上报
 */

const reportAttr = 'data-report'

//https://h5s.qzone.qq.com/proxy/domain/pinghot.qq.com/pingd?dm=console.qcloud.com.hot&url=/hottag/&tt=-&hottag=securitygroup.sgattachinstance&hotx=9999&hoty=9999&_=0.30167207934513995
function report(key) {
  let url = 'https://h5s.qzone.qq.com/proxy/domain/pinghot.qq.com/pingd?'

  let param = {
    dm: 'console.qcloud.com.hot',
    url: '/hottag/',
    tt: '-',
    hottag: key,
    hotx: 9999,
    hoty: 9999,
    _: Math.random()
  }

  url += $.param(param)

  sender(url)
}

//页面测速 h5.isd.com
// speedParams = {21972-1-1-28: 1234, }
function reportSpeed(speedParams) {
    let url = location.protocol + '//report.huatuo.qq.com/report.cgi?'

    let param = {
        appid: 20375,
        platform: 'pc',
        speedparams: encodeURIComponent($.param(speedParams)),
        _: Math.random()
    }

    url += $.param(param)

    sender(url)
}

// http 是开发环境. 只有 https 才会上报
function sender(url) {
  if (location.protocol == 'https:') {
    let img = new Image()
    img.src = url
  }
}

/**
 * 点击带有 `data-report` 属性的元素会自动上报
 */
export function init() {
  $('body').on('click', `[${reportAttr}]`, e => {
    const key = $(e.currentTarget).attr(reportAttr)

    report(key)
  })
}

export function click(key) {
  report(key)
}

export function speed(param) {
  reportSpeed(param)
}
