/**
 * qcbase 请求
 */

function getCookie(name) {
  var r = new RegExp('(?:^|;+|\\s+)' + name + '=([^;]*)'),
    m = document.cookie.match(r)

  return !m ? '' : m[1]
}

//简易 guid
function guid() {
  function s4() {
    return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1)
  }
  return (
    s4() +
    s4() +
    '-' +
    s4() +
    '-' +
    s4() +
    '-' +
    s4() +
    '-' +
    s4() +
    s4() +
    s4()
  )
}

var getACSRFToken = function(skey) {
  if (!skey) {
    return ''
  }
  var hash = 5381
  for (var i = 0, len = skey.length; i < len; ++i) {
    hash += (hash << 5) + skey.charCodeAt(i)
  }
  return hash & 0x7fffffff
}

function request(url, data, opts) {
  return Promise.resolve(
    $.ajax(
      Object.assign(
        {
          type: 'post',
          url: url,
          headers: {
            'X-SeqId': guid(),
            'X-Referer': parent.location.href,
            'X-CsrfCode': getACSRFToken(
              getCookie('skey') || getCookie('p_skey')
            )
          },
          data: JSON.stringify(data),
          dataType: 'json',
          contentType: 'application/json; charset=utf-8'
        },
        opts
      )
    )
  )
}

function apiRequest(data = {}, opts) {}

exports.request = request
