import RateLimit from './RateLimit'
import { RevisedOmit } from './../types'
import { t } from '@tencent/tea-app/lib/i18n';
/**
 * 全量拉取列表，支持在 opts 中配置 period 参数进行限流
 * @param fetchFun 注：模板函数需要支持 limit,offset 参数
 * @param opts 可选参数
 */
export default function getAllList<
  TParam extends { limit?: number; offset?: number },
  TResult,
  TFormattedResult extends GetAllListRes<any> = GetAllListRes<TResult>
>(
  fetchFun: (regionId: number, params: TParam) => Promise<TResult>,
  opts?: GetAllListOpts<TResult, TFormattedResult>
) {
  const {
    limit = 50,
    permits = 20,
    period,
    resFormater = ((v: TResult) => v as unknown as TFormattedResult) as (
      res: TResult
    ) => TFormattedResult
  } = opts || {}
  return async function (
    regionId: number,
    params: RevisedOmit<TParam, 'offset' | 'limit'>
  ) {
    let offset = 0
    // 首次查询，获取 totalCount
    const firstResult = await fetchFun(regionId, {
      ...params,
      offset,
      limit
    } as TParam)

    const formatFirstResult = resFormater(firstResult)

    if (
      !!formatFirstResult &&
      (!('totalCount' in formatFirstResult) || !('list' in formatFirstResult))
    ) {
      throw new Error(
        t('如不配置resFormater，默认按照接口结果返回，检测缺少 totalCount 或 list 属性，请配置resFormater')
      )
    }

    const totalCount = formatFirstResult?.totalCount
    const fullList = formatFirstResult?.list || []
    offset += limit

    // 剩余量，并发查询
    const ratelimit = new RateLimit({ permits, period })
    const queries: Promise<Array<any>>[] = []

    for (; offset < totalCount; offset += limit) {
      queries.push(
        (async offset => {
          await ratelimit.acquire()

          const result = await fetchFun(regionId, {
            ...params,
            offset,
            limit
          } as TParam)

          ratelimit.release()

          const formatResult = resFormater(result)
          return formatResult?.list
        })(offset)
      )
    }
    const results = await Promise.all(queries)
    return {
      list: results.reduce(
        (list, i) => list.concat(i || []),
        fullList
      ) as TFormattedResult['list'],
      totalCount
    }
  }
}

export interface GetAllListOpts<TResult, TFormattedResult> {
  /**
   * 格式化出参，如果外部没有传，默认按照接口返回格式处理列表
   * @param res
   * @returns
   */
  resFormater?: (res: TResult) => TFormattedResult
  /**
   * 指定每次请求的 limit
   */
  limit?: number
  /**
   * 并发周期，用于限流控制，可以在指定周期内限制并发请求个数，默认不设置
   * @unit ms
   */
  period?: number
  /**
   * 并发数量，默认为 20
   */
  permits?: number
}

/**
 * 推断list数组元素的结构，保留其类型
 */
export type ExtractList<TResult> = {
  [K in keyof TResult]: TResult[K] extends Array<infer U> ? U : never
}[keyof TResult]

export interface GetAllListRes<TResult> {
  list: Array<ExtractList<TResult>>
  totalCount: number
}
