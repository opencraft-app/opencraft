import { app, useBeforeDestroy } from '@tencent/tea-app'
const iaas = seajs.require('models/iaas')

/** 主动数据上报 */
type reportData = {
  namespace: string
  [key: string]: string | number
}
export const reporterCreator = function (opts: {
  // 上报最长间隔时间，60 秒
  maxWaitingTime?: number
  // 上报队列缓冲长度
  bufferSize?: number
  // 上报数据预处理
  reportDataProcess?: (data: unknown[]) => reportData[]
}) {
  const {
    maxWaitingTime = 1000 * 60,
    bufferSize = 50,
    reportDataProcess = function (data) {
      return {
        reportTime: new Date().getTime(),
        ...data
      }
    }
  } = opts
  // 待上报数据列表
  let reportList = []
  // 计时器
  let reportTimer = null

  // 页面销毁事件监听，需要 tea2 支持
  useBeforeDestroy(() => {
    doReport()
  })
  // 浏览器自带关闭事件
  window.addEventListener('beforeunload', e => {})

  // 上报数据
  function doReport() {
    const list = reportList.splice(0)

    sendReport(list)
    if (reportTimer) {
      clearTimeout(reportTimer)
    }
    // 定时上报
    reportTimer = setTimeout(() => {
      doReport()
    }, maxWaitingTime)
  }

  // 上报方法
  return function reporter(data: reportData | reportData[]) {
    data instanceof Array
      ? (reportList = reportList.concat(data.map(reportDataProcess)))
      : reportList.push(reportDataProcess(data))

    if (reportList.length >= bufferSize) {
      // 日志攒够缓冲长度之后集中上报
      doReport()
    }
  }
}

// 发送请求，发送失败会进行重试
function sendReport(
  // 日志列表
  data: unknown[],
  // 失败重试时间，多次重试时间会指数增长
  retryStep = 1000
) {
  if (!data || !data.length) {
    return
  }
  iaas.request('/cgi/reporter', { data }).catch(e => {
    setTimeout(() => {
      sendReport(data, retryStep * 3)
    }, retryStep)
  })
}
