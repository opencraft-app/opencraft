import getBillingSdk, {
  BillingSdk,
  GoodsDetail,
  Params,
  OrderParams,
  GoodsDataCreate,
  GoodsDataRenew,
  GoodsDataUpgrade,
  GoodsDataDowngrade,
  GoodsData,
  QueryPriceParams
} from './getBillingSdk'
/**
 * 获取billing-sdk ts声明优化版
 *
 * **并非原始接口！**带部分类型声明与转换（避免原SDK的JSON序列化导致类型约束丢失）
 */
export default async function getBillingInjectedSdk() {
  return injectSdk(await getBillingSdk())
}

/**
 * 对原接口进行一次转换，以保证保留TS类型校验
 */
function injectSdk(sdk: BillingSdk) {
  const injectedSdk = {
    // /** TODO 查询新购价格 */
    queryPriceCreate<T>(params: Params<QueryPriceParams<GoodsDataCreate<T>>>) {
      return sdk.queryPrice(params)
    },
    queryPriceRenew<T>(params: Params<QueryPriceParams<GoodsDataRenew<T>>>) {
      return sdk.queryPrice(params)
    },
    queryPriceUpgrade<T>(
      params: Params<QueryPriceParams<GoodsDataUpgrade<T>>>
    ) {
      return sdk.queryPrice(params)
    },
    queryPriceDowngrade<T>(
      params: Params<QueryPriceParams<GoodsDataDowngrade<T>>>
    ) {
      return sdk.queryPrice(params)
    },
    // /** TODO 查询续费价格 */
    // queryRenewPrice,
    // queryReturnPrice,
    // queryModifyPrice,
    directToCheck<TGoodsDetail>(params: Params<TSOrderParams<TGoodsDetail>>) {
      const transformedParams: Params<OrderParams> = {
        ...params,
        params: transformOrderParams(params.params)
      }
      return sdk.directToCheck(transformedParams)
    },
    directToCheckCreate<T>(params: Params<TSOrderParams<GoodsDataCreate<T>>>) {
      return injectedSdk.directToCheck(params)
    },
    directToCheckRenew<T>(params: Params<TSOrderParams<GoodsDataRenew<T>>>) {
      return injectedSdk.directToCheck(params)
    },
    directToCheckUpgrade<T>(
      params: Params<TSOrderParams<GoodsDataUpgrade<T>>>
    ) {
      return injectedSdk.directToCheck(params)
    },
    directToCheckDowngrade<T>(
      params: Params<TSOrderParams<GoodsDataDowngrade<T>>>
    ) {
      return injectedSdk.directToCheck(params)
    }
  }
  return injectedSdk
}

function transformOrderParams<TGoodsDetail>(
  data: TSOrderParams<TGoodsDetail>
): OrderParams {
  return {
    ...data,
    itemDetails: JSON.stringify(data.itemDetails)
  }
}

// interface BillingSdkInject {
//   directToCheck: <T extends GoodsDetail>(
//     params: Params<TSOrderParams<T>>
//   ) => Promise<any>
// }

export interface TSOrderParams<TGoodsDetail>
  extends Omit<OrderParams, 'itemDetails'> {
  itemDetails: OrderParamsItemDetails<TGoodsDetail>
}

export interface OrderParamsItemDetails<TGoodsData = GoodsData> {
  /** 鉴权参数（可选），对应后台接口的`auth`字段 */
  extParams?: any
  raw_goodsData: TGoodsData[]
}
