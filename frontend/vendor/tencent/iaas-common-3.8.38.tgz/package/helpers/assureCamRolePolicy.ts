import { once } from './cacheable'
import * as cam from '../models/cam'
import { warn } from './log'
import { app } from '@tencent/tea-app'
import pagingFetch from './pagingFetch'
import apiRequest from '../models/apiRequest'


// 兼容qcloud-ccs copy过来的代码
function sendCapiRequest<R, T extends Object = any>(
  serviceType: string,
  action: string,
  data: T,
  regionId: number = 1,
  opts: any = {}
): Promise<R> {
  return apiRequest(
    {
      regionId,
      serviceType,
      action,
      data
    },
    opts
  )
}

// ------------------ 以下是从qcloud-ccs复制过来的代码 -----------------------
// http://git.code.oa.com/CFETeam/qcloud-ccs/blob/master/modules/log/WebAPI.ts
/**
 * 判断是否已经创建好角色并且已经绑定号了策略
 */
export async function checkUserIsCreateRoleAndAttachPolicy(
  roleName: string,
  policyName: string,
  dockerUin: string
) {
  let isCreateAndAttach = false

  // 判断是否已经创建过角色
  let hasCreateRole = await checktUserIsCreateRole(roleName)
  if (!hasCreateRole) {
    // 如果没有创建过，则去创建一个角色，再绑定策略
    let roleId = await createRole(roleName, dockerUin)
    if (roleId) {
      hasCreateRole = true
    }
  }

  if (hasCreateRole) {
    // 判断是否已经绑定了策略
    let hasAttachRolePolicies = await checkUserIsAttachRolePolicies(
      roleName,
      policyName
    )
    if (!hasAttachRolePolicies) {
      // 如果没有绑定过策略，则去绑定策略
      let attachRole = await attachPolicyForRole(roleName, policyName)
      if (attachRole) {
        isCreateAndAttach = true
      }
    } else {
      isCreateAndAttach = true
    }
  }

  return isCreateAndAttach
}

/**
 * 判断某个用户是否已经创建过相关的角色
 */
export async function checktUserIsCreateRole(roleName: string) {
  try {
    let response = await sendCapiRequest<{ code: number }>(
      'cam',
      'GetRole',
      { roleName },
      1,
      {
        tipErr: false
      }
    )

    if (response.code === 0) {
      return true
    }
  } catch (error) {
    if (
      error.code === 4000 &&
      error.data.codeDesc === 'InvalidParameter.role.NotExist'
    ) {
      return false
    }
  }
}

/**
 * 判断某个用户是否已经创建过相关的策略
 * @api ListAttachedRolePolicies
 * @param roleName: string
 * @param page: num
 * @param rp: num
 *
 * @return totalNum: int
 *         list: array
 */
export async function checkUserIsAttachRolePolicies(
  roleName: string,
  policyName: string
) {
  // tipErr 是为了在qcconsole 代理层那一块对错误不进行处理，不把错误暴露出来
  let params = {
    roleName,
    page: 1,
    rp: 20
  }
  let response = await sendCapiRequest<{ code: number; data: { list: any[] } }>(
    'cam',
    'ListAttachedRolePolicies',
    params,
    1,
    { tipErr: false }
  )

  let hasAttachPolicy = false

  if (response.code === 0) {
    response.data.list.forEach(item => {
      if (item.policyName === policyName) {
        hasAttachPolicy = true
      }
    })
  }

  return hasAttachPolicy
}

/**
 * 用户创建某角色
 * @api CreateRole
 * @param roleName: string
 * @param policyDocument: string
 *
 * @return roleId: string
 */
export async function createRole(roleName: string, uin: string) {
  let qcs = ['qcs::cam::uin/' + uin + ':root']
  let policyDocument = {
    version: '2.0',
    statement: [
      {
        action: 'sts:AssumeRole',
        effect: 'allow',
        principal: {
          qcs
        }
      }
    ]
  }

  let params = {
    roleName,
    policyDocument: JSON.stringify(policyDocument)
  }

  let response = await sendCapiRequest<{ code: number; data: { roleId: any } }>(
    'cam',
    'CreateRole',
    params
  )

  if (response.code === 0) {
    return response.data.roleId
  }
}

/**
 * 用户根据roleName和 policy进行bangding
 */
export async function attachPolicyForRole(
  roleName: string,
  policyName: string
) {
  let params = {
    roleName,
    policyName
  }

  try {
    let response = await sendCapiRequest<{ code: number }>(
      'cam',
      'AttachRolePolicy',
      params
    )

    if (response.code === 0) {
      return true
    }
  } catch (error) {
    return false
  }
}

// ------------------------------
// 带缓存功能的判断接口
/**
 * @deprecated v2接口，静默授权，不推荐使用，请切换 assureCamRolePolicyV3
 */
const assureCamRolePolicy = once(checkUserIsCreateRoleAndAttachPolicy)
export default assureCamRolePolicy

// 新版授权方法
// 文档： http://tapd.oa.com/tcp_access/markdown_wikis/0#1020399462011082337
// serviceType与roleDesc参数已经不再需要了
export interface CamRoleGrantOptions {
  /** 角色名，例如："TKE_QCSRole" 或 "cosCkafka_QCSRole" */
  role: string
  /** 策略名，可以有多个，例如："QcloudAccessForTKERole" 或 ["QcloudCOSAccessForCkafkaRole"] */
  policy: string | string[]
  /**
   * 角色载体，例如：{"service": "ccs.qcloud.com"} 或 {"qcs":["qcs::cam::uin/91000000031:root"]}
   */
  principal: any
  /** 描述授权是为了使用什么功能。 */
  functionDesc: string
}
export interface CamRoleLinkedGrantOptions {
  /** 角色名，例如："TKE_QCSRole" 或 "cosCkafka_QCSRole" */
  role: string
  /** 描述授权是为了使用什么功能。 */
  functionDesc: string
  /** 自动关联角色相关的服务、策略 */
  serviceLinkedRole: true
}

async function useCamSdk() {
  return await app.sdk.use('cam-sdk')
}

/** 弹窗进行Cam角色授权，返回Promise对象 */
export async function waitCamRoleGrant(
  opts: CamRoleGrantOptions | CamRoleLinkedGrantOptions
) {
  const cam = await useCamSdk()
  if ('serviceLinkedRole' in opts) {
    return await cam.showRoleGrantDialog({
      roleName: opts.role,
      functionDesc: opts.functionDesc,
      serviceLinkedRole: 1
    })
  }
  return await cam.showRoleGrantDialog({
    roleName: opts.role,
    policyName: [].concat(opts.policy).join(','),
    principal: opts.principal,
    functionDesc: opts.functionDesc
  })
}

export async function assureCamRolePolicyV3(
  opts: CamRoleGrantOptions | CamRoleLinkedGrantOptions
) {
  const sdk = await useCamSdk()

  // 检查角色
  const roleResult = await sdk.haveRole({ roleName: opts.role })
  // 0: 正常 -1: 没有角色 -2: GetRole无权限 -3: 其它错误
  switch (roleResult.code) {
    case 0:
      break
    case -1:
      return await waitCamRoleGrant(opts)
    default:
      app.tips.error(roleResult.message)
      return false
  }

  // 检查策略
  if ('serviceLinkedRole' in opts) {
    return true
  }
  const policyResult = await sdk.havePolicies({
    roleName: opts.role,
    policies: [].concat(opts.policy)
  })
  switch (policyResult.code) {
    case 0:
      break
    case -1:
      return await waitCamRoleGrant(opts)
    default:
      app.tips.error(policyResult.message)
      return false
  }

  return true
}

/** 该方法不检查策略，但检查role  */
export async function assureCamRoleV3(
  opts: CamRoleGrantOptions | CamRoleLinkedGrantOptions
) {
  const sdk = await useCamSdk()

  // 检查角色
  const roleResult = await sdk.haveRole({ roleName: opts.role })
  // 0: 正常 -1: 没有角色 -2: GetRole无权限 -3: 其它错误
  switch (roleResult.code) {
    case 0:
      break
    case -1:
      return await waitCamRoleGrant(opts)
    default:
      app.tips.error(roleResult.message)
      return false
  }
  return true
}

/**
 * 判断某个用户是否已经创建过相关的角色（API v3）
 */
export async function checktUserIsCreateRoleV3(roleName: string) {
  try {
    await cam.GetRole(
      1,
      { RoleName: roleName },
      {
        tipErr: false
      }
    )
    return true
  } catch (error) {
    return false
  }
}

export async function checkUserIsAttachRolePoliciesV3(
  roleName: string,
  policyName: string
) {
  // tipErr 是为了在qcconsole 代理层那一块对错误不进行处理，不把错误暴露出来
  let params = {
    roleName,
    page: 1,
    rp: 20
  }

  const policies = await pagingFetch<cam.AttachedPolicyOfRole>(
    async (offset: number, limit: number) => {
      const result = await cam.ListAttachedRolePolicies(1, {
        RoleName: roleName,
        Page: Math.floor(offset / limit) + 1,
        Rp: limit
      })
      return {
        list: result.List,
        totalCount: result.TotalNum
      }
    },
    {
      maxLimit: 200
    }
  )

  let hasAttachPolicy = false

  policies.forEach(item => {
    if (item.PolicyName === policyName) {
      hasAttachPolicy = true
    }
  })

  return hasAttachPolicy
}

/**
 * 用户创建某角色（API v3）
 * @api CreateRole
 * @param roleName: string
 * @param policyDocument: string
 *
 * @return roleId: string
 */

type ParamPrincipal = {
  type: 'uin' | 'service'
  value: string
}

export async function createRoleV3(
  roleName: string,
  principal: ParamPrincipal
) {
  let policyDocument = {
    version: '2.0',
    statement: [
      {
        action: 'sts:AssumeRole',
        effect: 'allow',
        principal: {}
      }
    ]
  }

  switch (principal.type) {
    case 'service':
      ; (policyDocument.statement[0].principal as any).service = principal.value
      break
    case 'uin':
      let qcs = ['qcs::cam::uin/' + principal.value + ':root']
        ; (policyDocument.statement[0].principal as any).qcs = qcs
      break
  }

  return await cam.CreateRole(1, {
    RoleName: roleName,
    PolicyDocument: JSON.stringify(policyDocument)
  })
}

export async function AttachRolePolicyV3(roleName: string, policyName: string) {
  try {
    await cam.AttachRolePolicy(1, {
      AttachRoleName: roleName,
      PolicyName: policyName
    })
    return true
  } catch (error) {
    return false
  }
}

/** 该方法用来控制台业务方调接口创建角色，创建策略并配置策略  */
export async function checkUserIsCreateRoleAndAttachPolicyV3(
  roleName: string,
  policyName: string,
  principal: ParamPrincipal
) {
  let isCreateAndAttach = false

  // 判断是否已经创建过角色
  let hasCreateRole = await checktUserIsCreateRoleV3(roleName)
  if (!hasCreateRole) {
    // 如果没有创建过，则去创建一个角色，再绑定策略
    let result = await createRoleV3(roleName, principal)
    if (result.RoleId) {
      hasCreateRole = true
    }
  }

  if (hasCreateRole) {
    // 判断是否已经绑定了策略
    let hasAttachRolePolicies = await checkUserIsAttachRolePoliciesV3(
      roleName,
      policyName
    )
    if (!hasAttachRolePolicies) {
      // 如果没有绑定过策略，则去绑定策略
      let attachRole = await AttachRolePolicyV3(roleName, policyName)

      if (attachRole) {
        isCreateAndAttach = true
      }
    } else {
      isCreateAndAttach = true
    }
  }

  return isCreateAndAttach
}
