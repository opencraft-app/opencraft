/**
 * 在redux-saga中有一种场景，需要监听action，同时又希望只在值变化时才触发
 * @author cluezhang
 */
export { watchLatest, runAndWatchLatest } from 'redux-saga-catch'
export { resolvePromise } from 'saga-duck/helper'
