function getGlobal () {
  if (typeof self !== 'undefined') { return self; }
  if (typeof window !== 'undefined') { return window; }
  if (typeof global !== 'undefined') { return global; }
  return null
};

const globalThis = getGlobal();

function getDefaultCacheMethod<T>(desc: string = '') {
  const defaultCacheMap: Record<string, T> = {}
  const hostedCacheKey = `_cacheable_${desc}_${Math.random()}`
  return function cache(args: any[], result?: T) {
    let cacheMap: Record<string, T> = defaultCacheMap
    // 如果this不是默认的全局，表示为类成员，这时要把缓存放到类实例上，避免不同类实例之前串数据
    // 如果是箭头函数，this是为undefined的
    if (this && this !== globalThis) {
      if (!this[hostedCacheKey]) {
        Object.defineProperty(this, hostedCacheKey, {
          enumerable: false,
          value: {}
        })
      }
      cacheMap = this[hostedCacheKey]
    }
    const key = JSON.stringify(args)
    if (arguments.length > 1) {
      cacheMap[key] = result
    }
    return cacheMap[key]
  }
}

interface CacheMethod<T> {
  /**
   * @param args 调用参数
   * @param result 调用结果，传入时表示保存到缓存中，不传时表示尝试读取缓存结果
   */
  (args: any[], result?: T)
}

/** 防重入，注意传入的参数必须可以JSON.stringify序列化 */
export function once<TFunction extends (...args: any[]) => any>(
  f: TFunction,
  cache?: CacheMethod<ReturnType<TFunction>>
): TFunction {
  if (!cache) {
    cache = getDefaultCacheMethod()
  }
  return function (...args: any[]) {
    let result = cache.call(this, args)
    if (result === undefined) {
      result = cache.call(this, args, f.apply(this, args))
    }
    return result
  } as TFunction
}

/**
 * 设置有效期，使用方法：
 * 
 * @example
  ```js
  const cacheFn = once(fn, ttl(5000)) // 直接用法
  class Test{
    @cacheableWith(ttl(5000)) // 装饰器用法
    foo(){}
  }
  ```
 */
export function ttl<T>(ms = 5 * 60 * 1000, cache = getDefaultCacheMethod()): CacheMethod<T> {
  return function (args: any[], result: T) {
    if (result !== undefined) {
      setTimeout(() => {
        cache.call(this, args, undefined)
      }, ms)
    }
    return cache.apply(this, arguments)
  }
}

/**
 * 类似memoize-once，仅缓存最后一个结果，如果参数有变化则清空
 */
export function untilChange<T>(): CacheMethod<T> {
  const cache = getDefaultCacheMethod()
  const lastSignatureKey = [Symbol('last call signatures')]
  return function (args: any[], ...rest): T {
    const result = rest[0]
    const signature = JSON.stringify(args)
    if (result) {
      // 保留上次调用结果
      cache.call(this, lastSignatureKey, signature)
    } else {
      // 如果调用参数不同，则清空缓存
      const lastSignature = cache.call(this, lastSignatureKey)
      if (signature !== lastSignature) {
        cache.call(this, args, undefined)
      }
    }
    return cache.call(this, args, ...rest)
  }
}

/**
 * 不缓存失败的Promise结果
 * 
 * 还可以使用 noRejected(ttl(5000)) 的方式组合
 */
export function noRejected<T extends Promise<any>>(cache: CacheMethod<T> = getDefaultCacheMethod()): CacheMethod<T> {
  return function (args: any[], ...rest) {
    const result = rest[0]
    if (result) {
      // Promise出错时清空缓存
      result.catch(e => {
        cache.call(this, args, undefined)
      })
    }
    return cache.call(this, args, ...rest)
  }
}


/**
 * Decorator版缓存，设计为class method使用，也可以直接调用来包装function
 * 注意： decorator标准只为class设计，所以应避免在function上使用，而应该直接调用once
 */
export const cacheable = cacheableWith(null)

/**
 * Decorator构造器
 */
export function cacheableWith<T>(cacheMethod: CacheMethod<T>) {
  return function cacheable(
    target,
    propertyKey: string,
    descriptor: PropertyDescriptor
  ) {
    if (propertyKey && descriptor === undefined) {
      descriptor = Object.getOwnPropertyDescriptor(target, propertyKey)
    }
    let cache = cacheMethod
    if (!cache) {
      cache = getDefaultCacheMethod(propertyKey)
    }
    // 缓存放在实例上
    if ('value' in descriptor) {
      const originalFn = descriptor.value
      descriptor.value = once(originalFn, cache)
    } else if ('get' in descriptor) {
      const originalFn = descriptor.get
      descriptor.get = once(originalFn, cache)
    }
    return descriptor
  }
}
