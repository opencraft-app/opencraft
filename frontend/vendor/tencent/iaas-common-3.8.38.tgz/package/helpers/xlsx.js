/**
 * XLSX导出相关
 * Created by royhyang on 2017/8/3.
 */
import { t } from '@tencent/tea-app/lib/i18n'
const CHROME_MAX_SIZE = 2 * 1024 * 1024
// Chrome data URI 目前最大支持2M，超出的会下载失败

function datenum(v, date1904) {
  if (date1904) v += 1462
  var epoch = Date.parse(v)
  return (epoch - new Date(Date.UTC(1899, 11, 30))) / (24 * 60 * 60 * 1000)
}

export default {
  generator: function() {
    var _this = this
    nmcLoad('xlsx.js', function() {
      seajs.use('xlsx.js', function(xlsx) {
        _this.xlsx = xlsx
      })
    })
    return this
  },
  /**
   * colimns renderer
   * @callback renderer
   * @param {*} val - 字段值
   * @param {Object} - 列表item对象
   * @param {number} - 列表索引
   * @param {Object} - 额外信息
   * @returns {string}
   */

  /**
   * 将列表数据转成[[]]格式，使用类似grid columns配置进行列定义。
   * @param {Object[]} list 列表数据
   * @param {Object[]} columns 列定义，格式示例：
   * @param {string} columns.0.name 列名称
   * @param {string} columns.0.key 列字段名
   * @param {renderer} [columns.0.renderer] - 渲染函数，用于复杂结构转换
   * @param {Object} meta - 额外信息，会传递给column.renderer
   * @returns {string}
   */
  format: function(list, columns, meta) {
    var arr = []
    // 表头
    arr.push(
      columns.map(function(col) {
        return col.name
      })
    )
    // 列表
    arr = arr.concat(
      list.map(function(item) {
        return columns.map(function(col, index) {
          var value = item[col.key]
          return col.renderer ? col.renderer(value, item, index, meta) : value
        })
      })
    )
    return arr
  },
  sheet_from_array_of_arrays: function(data) {
    var ws = {}
    var range = { s: { c: 10000000, r: 10000000 }, e: { c: 0, r: 0 } }
    for (var R = 0; R !== data.length; ++R) {
      for (var C = 0; C !== data[R].length; ++C) {
        if (range.s.r > R) range.s.r = R
        if (range.s.c > C) range.s.c = C
        if (range.e.r < R) range.e.r = R
        if (range.e.c < C) range.e.c = C
        var cell = { v: data[R][C] }
        if (cell.v === null) continue
        var cell_ref = this.xlsx.utils.encode_cell({ c: C, r: R })

        if (typeof cell.v === 'number') cell.t = 'n'
        else if (typeof cell.v === 'boolean') cell.t = 'b'
        else if (cell.v instanceof Date) {
          cell.t = 'n'
          cell.z = this.xlsx.SSF._table[14]
          cell.v = datenum(cell.v)
        } else cell.t = 's'

        ws[cell_ref] = cell
      }
    }
    if (range.s.c < 10000000) ws['!ref'] = this.xlsx.utils.encode_range(range)
    return ws
  },
  s2ab: function(s) {
    var buf = new ArrayBuffer(s.length)
    var view = new Uint8Array(buf)
    for (var i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xff
    return buf
  },
  /**
   * 是否支持下载
   */
  isSupportSave: function() {
    return !/MSIE [1-9]\./.test(navigator.userAgent)
  },

  createXlsx: function(sheetName, content) {
    var Sheets = {}
    Sheets[sheetName] = this.sheet_from_array_of_arrays(content)
    return this.xlsx.write(
      {
        SheetNames: [sheetName],
        Sheets: Sheets
      },
      {
        bookType: 'xlsx',
        type: 'binary',
        bookSST: false
      }
    )
  },

  /**
   * 保存文件，纯客户端实现
   * 需要IE10+
   */
  save: function(fileName, workbook, onExceedTruncate) {
    onExceedTruncate = onExceedTruncate == undefined ? true : onExceedTruncate

    var blob = new Blob([this.s2ab(workbook)], {
      type: 'application/octet-binary'
    })

    if (window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveOrOpenBlob(blob, fileName)
    } else {
      var dataURI = URL.createObjectURL(blob)
      var message
      // 人为限定2M？chrome只支持这个数
      if (
        /Chrome\/\d+/.test(navigator.userAgent) &&
        dataURI.length > CHROME_MAX_SIZE
      ) {
        message = t('因为浏览器限制，此文件仅保存了部分内容')
        if (!onExceedTruncate) {
          return message
        }
        dataURI = dataURI.slice(0, CHROME_MAX_SIZE)
      }
      var a = document.createElement('a')
      a.href = dataURI
      a.target = '_blank'
      a.download = fileName
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)

      return message
    }
  },

  /**
   * @param opts {Object} 生成文件参数
   *      columns: {name: String, key: String}[]
   *      list: any[]
   *      fileName: String    文件名称
   *      sheetName: String   表格文件 sheet 名称
   *      onFaild: function   失败回调
   *      onSuccess: function 成功回调
   */
  saveBigFile: function(opts) {
    var me = this
    var totalLineNum = opts.list.length // 总行数
    var savedLineNum = 0 // 已保存行数
    var window = totalLineNum // 单次生成文件的行数大小
    try {
      while (savedLineNum < totalLineNum) {
        var lineToSave = opts.list.slice(savedLineNum, savedLineNum + window) // 本次要保存的行
        var formatedList = me.format(lineToSave, opts.columns)
        var file = me.createXlsx(opts.sheetName, formatedList)
        var exceed = me.save(opts.fileName, file, false)
        if (exceed) {
          // 文件超出大小限制
          window = Math.ceil(window / 2)
        } else {
          savedLineNum += window
        }
      }
      opts.onSuccess && opts.onSuccess()
    } catch (e) {
      opts.onFaild && opts.onFaild(e)
    }
  }
}
