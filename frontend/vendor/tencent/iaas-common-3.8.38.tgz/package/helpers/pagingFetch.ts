/**
 * 通用的分页接口一次拉取工具方法，支持并发限制
 * @param fetch 分页接口
 * @param opts 查询配置
 */
export default async function pagingFetch<T>(
  fetch: Fetch<T>,
  opts?: PagingOptions
): Promise<T[]> {
  const { maxLimit = 50, semaphore } = opts || {}
  let offset = 0
  let fullList: T[] = []
  let totalCount: number = 0
  // --- 串行方案
  //   do {
  //     const result = await fetch(offset, maxLimit)
  //     totalCount = totalCount || result.totalCount
  //     offset += maxLimit

  //     fullList = fullList.concat(result.list)
  //   } while (offset < totalCount)

  // --- 并行方案
  // 首次查询
  const firstResult = await fetch(offset, maxLimit)
  totalCount = firstResult.totalCount
  fullList = firstResult.list
  offset += maxLimit

  // 剩余量，并发查询
  const queries: Promise<T[]>[] = []
  for (; offset < totalCount; offset += maxLimit) {
    queries.push(
      (async offset => {
        // 并发锁
        if (semaphore) {
          await semaphore.acquire()
        }

        const result = await fetch(offset, maxLimit)

        if (semaphore) {
          semaphore.release()
        }

        return result.list
      })(offset)
    )
  }

  const results = await Promise.all(queries)

  return results.reduce((list, i) => list.concat(i || []), fullList)
}

export type Fetch<T> = (
  offset: number,
  limit: number
) => Promise<PagingResult<T>>

export interface PagingResult<T> {
  totalCount: number
  list: T[]
}

export interface PagingOptions {
  /** 每页查询条数上限 */
  maxLimit: number
  /** 并发查询限制 */
  semaphore?: Semaphore
}

export interface Semaphore {
  acquire(): Promise<any>
  release(): void
}
