import { checkConsoleFtCloudUser, getGroupRegionWhiteList, getGroupRegionFilterFunction, getGroupZoneFilterFunction } from './checkGroupConstraint'

const autoDrivingMockConsole = {
    QCLOUD_BUY_CONFIG: undefined,
    ftCloudRegions: [],
    isGroupCloudUser: async () => {
        return false
    },
    isAutoDrivingCloudUser: async () => {
        return true
    },
    autoDrivingCloudRegions: [
        {
            "id": 78,
            "region": "ap-shanghai-adc",
            "regionName": "华东地区（上海自动驾驶云）",
            "regionNameEn": "East China (ap-shanghai-adc)",
            "regionPrefix": "shadc",
            "zoneList": [
                {
                    "zoneId": 780001,
                    "zoneCode": "ap-shanghai-adc-1",
                    "zoneName": "上海自动驾驶云一区"
                }
            ]
        },
        {
            "id": 79,
            "region": "ap-shanghai-adc",
            "regionName": "华东地区（上海自动驾驶云）",
            "regionNameEn": "East China (ap-shanghai-adc)",
            "regionPrefix": "shadc",
            "zoneList": [
                {
                    "zoneId": 780002,
                    "zoneCode": "ap-shanghai-adc-1",
                    "zoneName": "上海自动驾驶云一区"
                }
            ]
        }
    ],
} as any
const autoDrivingMockBuy = {
    QCLOUD_BUY_CONFIG: {
        isGroupCloudUser: false,
        ftCloudRegions: [],
        autoDrivingCloudRegions: [
            {
                "id": "78",
                "fullName": "华东地区（上海自动驾驶云）",
                "name": "上海自动驾驶云",
                "enFullName": "East China （Shanghai Autopilot Cloud）（Shanghai Autopilot Cloud）",
                "enName": "Shanghai Autopilot Cloud",
                "apCode": "ap-shanghai-adc",
                "remark": "",
                "shortName": "shadc",
                "area": "华东地区",
                "zones": [
                    {
                        "zone_code": "ap-shanghai-adc-1",
                        "id": "113",
                        "zone_id": "780001",
                        "name_cn": "上海自动驾驶云一区",
                        "name_en": "Shanghai Autopilot Cloud Zone 1",
                        "region_code": "shadc",
                        "region_id": "78",
                        "support_ft_cloud": "0",
                        "white_list": "SHADC_ZONE1_WHITELIST"
                    }
                ],
                "supportFtCloud": false,
                "white_list": "SHADC_ZONE1_WHITELIST"
            },
            {
                "id": "79",
                "fullName": "华东地区（上海自动驾驶云）",
                "name": "上海自动驾驶云",
                "enFullName": "East China （Shanghai Autopilot Cloud）（Shanghai Autopilot Cloud）",
                "enName": "Shanghai Autopilot Cloud",
                "apCode": "ap-shanghai-adc",
                "remark": "",
                "shortName": "shadc",
                "area": "华东地区",
                "zones": [
                    {
                        "zone_code": "ap-shanghai-adc-1",
                        "id": "113",
                        "zone_id": "780002",
                        "name_cn": "上海自动驾驶云一区",
                        "name_en": "Shanghai Autopilot Cloud Zone 1",
                        "region_code": "shadc",
                        "region_id": "79",
                        "support_ft_cloud": "0",
                        "white_list": "SHADC_ZONE1_WHITELIST"
                    }
                ],
                "supportFtCloud": false,
                "white_list": "SHADC_ZONE1_WHITELIST"
            },


        ]
        ,
        isAutoDrivingCloudUser: true
    },
    ftCloudRegions: [],
    isGroupCloudUser: async () => {
        return false
    },
    isAutoDrivingCloudUser: async () => {
        return true
    },
    autoDrivingCloudRegions: [
        {
            "id": 78,
            "region": "ap-shanghai-adc",
            "regionName": "华东地区（上海自动驾驶云）",
            "regionNameEn": "East China (ap-shanghai-adc)",
            "regionPrefix": "shadc",
            "zoneList": [
                {
                    "zoneId": 780001,
                    "zoneCode": "ap-shanghai-adc-1",
                    "zoneName": "上海自动驾驶云一区"
                }
            ]
        },
        {
            "id": 79,
            "region": "ap-shanghai-adc",
            "regionName": "华东地区（上海自动驾驶云）",
            "regionNameEn": "East China (ap-shanghai-adc)",
            "regionPrefix": "shadc",
            "zoneList": [
                {
                    "zoneId": 780002,
                    "zoneCode": "ap-shanghai-adc-1",
                    "zoneName": "上海自动驾驶云一区"
                }
            ]
        }
    ],
} as any
const regionIsNull = {
    QCLOUD_BUY_CONFIG: {
        isGroupCloudUser: false,
        ftCloudRegions: [1, 2],
        autoDrivingCloudRegions: [3, 4],
        isAutoDrivingCloudUser: false
    },
    ftCloudRegions: [1, 2],
    isGroupCloudUser: async () => {
        return true
    },
    isAutoDrivingCloudUser: async () => {
        return false
    },
    autoDrivingCloudRegions: [3, 4],
} as any

afterEach(() => {
    jest.resetModules()
})

describe('团体云', () => {
    it('in the buy ft whitelist', async () => {
        global.window = {
            QCLOUD_BUY_CONFIG: {
                isGroupCloudUser: true,
                ftCloudRegions: [{ "id": "11", "fullName": "华南地区（深圳金融）", "name": "深圳金融", "enFullName": "South China (Shenzhen Finance)（Shenzhen Finance）", "enName": "Shenzhen Finance", "apCode": "ap-shenzhen-fsi", "remark": "", "shortName": "szjr", "area": "华南地区", "zones": [{ "zone_code": "ap-shenzhen-fsi-1", "id": "27", "zone_id": "110001", "name_cn": "深圳金融一区", "name_en": "Shenzhen Finance Zone 1", "region_code": "szjr", "region_id": "11", "support_ft_cloud": "1", "white_list": "" }, { "zone_code": "ap-shenzhen-fsi-3", "id": "29", "zone_id": "110003", "name_cn": "深圳金融三区", "name_en": "Shenzhen Finance Zone 3", "region_code": "szjr", "region_id": "11", "support_ft_cloud": "1", "white_list": "" }], "supportFtCloud": true, "white_list": "" }, { "id": "7", "fullName": "华东地区（上海金融）", "name": "上海金融", "enFullName": "East China (Shanghai Finance)（Shanghai Finance）", "enName": "Shanghai Finance", "apCode": "ap-shanghai-fsi", "remark": "", "shortName": "shjr", "area": "华东地区", "zones": [{ "zone_code": "ap-shanghai-fsi-2", "id": "18", "zone_id": "700002", "name_cn": "上海金融二区", "name_en": "Shanghai Finance Zone 2", "region_code": "shjr", "region_id": "7", "support_ft_cloud": "1", "white_list": "" }], "supportFtCloud": true, "white_list": "" }]
                ,
                autoDrivingCloudRegions: [3, 4],
                isAutoDrivingCloudUser: false
            },
            ftCloudRegions: async () => {
                return [1, 2]
            },
            isFtCloudUser: true,
            isAutoDrivingCloudUser: false,
            autoDrivingCloudRegions: async () => {
                return [3, 4]
            },
        } as any

        expect(await checkConsoleFtCloudUser()).toBe('isFtCloudUser')
        expect(await getGroupRegionWhiteList()).toStrictEqual([11, 7])
        const regionFilter = await getGroupRegionFilterFunction()
        expect(await regionFilter(11)).toBe(true)
        expect(await regionFilter(88)).toBe(false)
        const zoneFilter = await getGroupZoneFilterFunction()
        expect(await zoneFilter('110001')).toBe(true)
        expect(await zoneFilter('780008')).toBe(false)


    })
    it('not in the console  whitelist', async () => {
        jest.mock('@tencent/tea-app', () => ({
            app: {
                user: {
                    isFtCloudUser: async () => {
                        return false
                    },
                    isAutoDrivingCloudUser: async () => {
                        return false
                    },
                }

            },
        }));

        global.window = regionIsNull
        expect(await checkConsoleFtCloudUser()).toBe(false)
        expect(await getGroupRegionWhiteList()).toStrictEqual([])
        const regionFilter = await getGroupRegionFilterFunction()
        expect(await regionFilter(78)).toBe(true)
        const zoneFilter = await getGroupZoneFilterFunction()
        expect(await zoneFilter('780001')).toBe(true)
    })

    it('isAutoDrivingCloudUser or isGroupCloudUser error', async () => {

        jest.mock('@tencent/tea-app', () => ({
            app: {
                user: {
                    isFtCloudUser: async () => {
                        throw new Error()
                    },
                    isAutoDrivingCloudUser: async () => {
                        return false
                    },
                }

            },
        }));

        global.window = {
            QCLOUD_BUY_CONFIG: undefined,
            ftCloudRegions: async () => {
                return [1, 2]
            },
            isGroupCloudUser: true,
            isAutoDrivingCloudUser: false,
            autoDrivingCloudRegions: async () => {
                return [3, 4]
            },
        } as any
        expect(await checkConsoleFtCloudUser()).toBe(false)
    })


    it('in the console ft whitelist', async () => {
        jest.mock('@tencent/tea-app', () => ({
            app: {
                user: {
                    isFtCloudUser: async () => {
                        return true
                    },
                    isAutoDrivingCloudUser: async () => {
                        return false
                    },
                }

            },
        }));

        global.window = {
            QCLOUD_BUY_CONFIG: undefined,
            ftCloudRegions: [
                {
                    "id": 78,
                    "region": "ap-shanghai-adc",
                    "regionName": "华东地区（上海自动驾驶云）",
                    "regionNameEn": "East China (ap-shanghai-adc)",
                    "regionPrefix": "shadc",
                    "zoneList": [
                        {
                            "zoneId": 780001,
                            "zoneCode": "ap-shanghai-adc-1",
                            "zoneName": "上海自动驾驶云一区"
                        }
                    ]
                }
            ],
            autoDrivingCloudRegions: [],
        } as any
        expect(await checkConsoleFtCloudUser()).toBe('isFtCloudUser')
        expect(await getGroupRegionWhiteList()).toStrictEqual([78])
        const regionFilter = await getGroupRegionFilterFunction()
        expect(await regionFilter(78)).toBe(true)
        expect(await regionFilter(88)).toBe(false)
        const zoneFilter = await getGroupZoneFilterFunction()
        expect(await zoneFilter('780001')).toBe(true)
        expect(await zoneFilter('780008')).toBe(false)
    })

})
describe('自动驾驶云', () => {
    it('user in console autoDriving white', async () => {
        jest.mock('@tencent/tea-app', () => ({
            app: {
                user: {
                    isFtCloudUser: async () => {
                        return false
                    },
                    isAutoDrivingCloudUser: async () => {
                        return true
                    },
                }

            },
        }));
        global.window = autoDrivingMockConsole
        expect(await checkConsoleFtCloudUser()).toBe('isAutoDrivingCloudUser')
        expect(await getGroupRegionWhiteList()).toStrictEqual([78, 79])
        const regionFilter = await getGroupRegionFilterFunction()
        expect(await regionFilter(78)).toBe(true)
        expect(await regionFilter(88)).toBe(false)
        const zoneFilter = await getGroupZoneFilterFunction()
        expect(await zoneFilter('780001')).toBe(true)
        expect(await zoneFilter('780008')).toBe(false)
    })

    it('user in buy autoDriving white', async () => {
        global.window = autoDrivingMockBuy
        expect(await checkConsoleFtCloudUser()).toBe('isAutoDrivingCloudUser')
        expect(await getGroupRegionWhiteList()).toStrictEqual([78, 79])
        const regionFilter = await getGroupRegionFilterFunction()
        expect(await regionFilter(78)).toBe(true)
        expect(await regionFilter(88)).toBe(false)
        const zoneFilter = await getGroupZoneFilterFunction()
        expect(await zoneFilter('780001')).toBe(true)
        expect(await zoneFilter('780008')).toBe(false)

    })

})


