import { delay } from 'redux-saga-catch'
import { once, cacheable, ttl, cacheableWith, untilChange, noRejected } from './cacheable'

describe('once', () => {
  it('保留可选入参', cb => {
    function test(a: number, b?: string) { }
    const foo = once(test)

    foo(1)
    foo(1, '')

    cb()
  })
  it('保留返回类型', cb => {
    const value = Math.random()
    function test() {
      return value
    }
    const foo = once(test)

    // 保证是数字
    foo().toExponential()
    expect(foo()).toBe(value)
    cb()
  })
})

describe('cacheable', () => {
  it('正确缓存', async () => {
    class Parent {
      count = 0
      @cacheable
      async test() {
        this.count++
        return Math.random()
      }
    }
    const p = new Parent()
    const [a, b] = await Promise.all([p.test(), p.test()])
    expect(a).toStrictEqual(b)
    expect(p.count).toBe(1)
  })
  it('不同实例不影响', async () => {
    class Parent {
      @cacheable
      async test() {
        return Math.random()
      }
    }
    const a = new Parent()
    const b = new Parent()
    expect(await a.test()).not.toStrictEqual(await b.test())
  })
  it('cacheable继承不影响', async () => {
    class Parent {
      parentValue = Math.random()
      @cacheable
      async test() {
        return this.parentValue
      }
    }
    class Child extends Parent {
      childValue = Math.random()
      @cacheable
      async test() {
        return this.childValue
      }
      async invokeParent() {
        return await super.test()
      }
    }
    const c = new Child()
    // 先调用一次父类的test方法
    expect(await c.invokeParent()).toStrictEqual(c.parentValue)
    // 再调用子类的方法，不能被父类的缓存影响
    expect(await c.test()).toStrictEqual(c.childValue)
  })
  it('支持getter', async () => {
    class Test {
      count = 0
      @cacheable
      get value() {
        this.count++
        return Math.random()
      }
    }
    const test = new Test()
    expect(test.value).toStrictEqual(test.value)
    expect(test.count).toBe(1)
  })
})

describe('ttl', () => {
  const time = 100
  async function check(test) {
    const origin = test()
    expect(origin).toStrictEqual(test())
    await delay(time + 10)
    const fresh = test()
    expect(origin !== fresh).toBeTruthy()
    expect(fresh).toStrictEqual(test())
  }
  it('普通函数有效', async () => {
    const test = once(() => Math.random(), ttl(time))

    check(test)
  })

  it('成员函数有效', async () => {
    const time = 100
    class Test {
      @cacheableWith(ttl(time))
      foo() {
        return Math.random()
      }
    }
    const o = new Test()
    const test = () => o.foo()
    check(test)
  })
  it('成员函数有实例隔离', async () => {
    const time = 100
    class Test {
      @cacheableWith(ttl(time))
      foo() {
        return Math.random()
      }
    }
    const a = new Test()
    const b = new Test()
    expect(a.foo() !== b.foo()).toBeTruthy()
    check(() => a.foo())
    check(() => b.foo())
  })
})

describe('utilChange', () => {
  function check(test) {
    const args1 = [Math.random()]
    const args2 = [Math.random()]

    const result1 = test(args1)
    expect(test(args1)).toStrictEqual(result1)
    const result2 = test(args2)
    expect(test(args2)).toStrictEqual(result2)
    expect(result1 !== result2).toBeTruthy()
  }

  it('普通函数', cb => {
    check(once(() => Math.random(), untilChange()))
    cb()
  })

  it('成员函数', cb => {
    class Test {
      @cacheableWith(untilChange())
      foo() {
        return Math.random()
      }
    }
    const o = new Test()
    check((...args) => o.foo.apply(o, args))
    cb()
  })

  it('成员函数实例对象隔离', cb => {
    class Test {
      @cacheableWith(untilChange())
      foo() {
        return Math.random()
      }
    }

    const a = new Test()
    const b = new Test()
    expect(a.foo() !== b.foo()).toBeTruthy()
    check((...args) => a.foo.apply(a, args))
    check((...args) => b.foo.apply(b, args))

    cb()
  })
})

describe("noRejected", () => {
  const time = 100
  function resolve(ms = time) {
    return delay(ms).then(v => Math.random())
  }
  function reject(ms = time) {
    return delay(ms).then(v => {
      throw Math.random()
    })
  }
  function createFn(createResults: (() => Promise<any>)[]) {
    let i = 0
    return function () {
      const createResult = createResults[i]
      i = (i + 1) % createResults.length
      return createResult()
    }
  }
  it('正确的请求被缓存', async () => {
    const test = once(createFn([resolve]), noRejected())
    const result1 = test()
    await delay(time - 1)
    const result2 = test()
    // Promise未resolve时缓存（防并发）
    expect(result2).toStrictEqual(result1)
    await delay(time)
    const result3 = test()
    // Promise已resolve后也继续缓存
    expect(result3).toStrictEqual(result2)
  })
  it('出错的请求不缓存', async () => {
    const test = once(createFn([reject]), noRejected())
    let result1, result2
    try {
      await test()
    } catch (e) {
      result1 = e
    }
    try {
      await test()
    } catch (e) {
      result2 = e
    }
    expect(result1 !== result2).toBeTruthy()
  })
  it('能配合ttl使用', async () => {
    const ttlTime = time + 100
    const test = once(createFn([resolve]), noRejected(ttl(ttlTime)))
    const result1 = test()
    await delay(ttlTime - 1)
    const result2 = test()
    // ttl内，值仍被缓存
    expect(result2).toStrictEqual(result1)
    await delay(2)
    const result3 = test()
    // ttl外，重新请求
    expect(result3 !== result2).toBeTruthy()
  })
  it('能用于成员函数', async () => {
    class Test {
      @cacheableWith(noRejected())
      reject() {
        return reject()
      }
      @cacheableWith(noRejected())
      resolve() {
        return resolve()
      }
    }
    const o = new Test()
    // 成功的值一直缓存
    const resolve1 = o.resolve()
    await delay(time)
    const resolve2 = o.resolve()
    expect(resolve2).toStrictEqual(resolve1)
    // 失败的值不缓存
    const reject1 = o.reject()
    await delay(time)
    const reject2 = o.reject()
    expect(reject1 !== reject2).toBeTruthy()
  })
})