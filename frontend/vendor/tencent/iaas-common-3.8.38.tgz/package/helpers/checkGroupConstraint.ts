import { once, ttl } from './cacheable'
import { getWhiteList } from '../model'
import buildConfig from '../buildConfig'


const cacheGetWhiteList = once(getWhiteList, ttl(5 * 60 * 1000));

/**
 * 获取团体云地域列表
 * 
 * **请注意，此接口不判断是否为团体云用户**
 * @returns 
 */
export function getFtCloudRegions(): GroupUserRegion[] {
  // 控制台
  if (window.ftCloudRegions) {
    return window.ftCloudRegions
  }
  // 购买页
  if (window.QCLOUD_BUY_CONFIG) {
    const list = window.QCLOUD_BUY_CONFIG.ftCloudRegions || []
    return list.map(o => ({
      id: +o.id,
      region: o.apCode,
      zoneList: o.zones?.map(o => ({
        zoneId: +o.zone_id,
        zoneName: o.name_cn
      }))
    }))
  }
  return []
}
/**
 * 获取定制云地域列表
 * 
 * **请注意，此接口不判断是否为定制云用户**
 * @returns 
 */
export function getWhiteCloudRegions(keys: string | false): GroupUserRegion[] {
  if (!keys) {
    return []
  }
  // 购买页
  if (window.QCLOUD_BUY_CONFIG) {
    const list = window?.QCLOUD_BUY_CONFIG[REGION_WHITE_LIST[keys].getRegionKey] || []
    return list.map(o => ({
      id: +o.id,
      region: o.apCode,
      zoneList: o.zones?.map(o => ({
        zoneId: +o.zone_id,
        zoneName: o.name_cn
      }))
    }))
  }
  // 控制台
  return window[REGION_WHITE_LIST[keys].getRegionKey as string] || []
}

/** 
 * 团体云改造-传入地域Id，并根据是否在团体云地域列表内决定是否该展示给用户
 * 
 * **请注意，此接口不判断是否为团体云用户**
 * @param regionId 如 1、"1"、"ap-guangzhou"
 * @returns true表示展示，false不展示。
 */
export function checkGroupUserRegion(regionId: string | number) {
  if (typeof regionId !== 'string' && typeof regionId !== 'number')
    throw 'regionId should be string or number'
  return getFtCloudRegions().some(item => Number(item.id) === Number(regionId) || item.region === regionId)
}
/**
 * 团体云改造-传入zoneId，并根据在团体云地域列表决定是否该展示给用户
 * 
 * **请注意，此接口不判断是否为团体云用户**
 * @param zoneId 如 100001、"100001"，**不支持"ap-guangzhou-1"的格式**（平台没给这个字段）
 * @returns true表示展示，false不展示。
 */
export function checkGroupUserZone(zoneId: string | number) {
  if (typeof zoneId !== 'string' && typeof zoneId !== 'number')
    throw 'zoneId should be string or number'
  return getFtCloudRegions().some(item => item.zoneList.some(zone => Number(zone.zoneId) === Number(zoneId))
  )
}

const GroupUserWhiteKey = 'GROUP_CLOUD_JR_WHITELIST'

export const cacheableCheckConsoleFtCloudUser = once(
  checkConsoleFtCloudUser,
  ttl(30 * 60 * 1000)
)

/**
 * 判断是否为定制云用户
 * @returns 
 */
export async function checkConsoleFtCloudUser() {
  const regionWhiteKey = Object.keys(REGION_WHITE_LIST)
  const { app } = require('@tencent/tea-app') as typeof import('@tencent/tea-app')
  for (const key of regionWhiteKey) {
    if (window.QCLOUD_BUY_CONFIG) {
      if (window.QCLOUD_BUY_CONFIG[REGION_WHITE_LIST[key]?.buyKey]) {
        return key
      }

    } else {
      try {
        const checkConsole = await app?.user?.[key]()
        if (checkConsole) {
          return key
        }
      } catch {
        return false
      }
    }
    // 检查是否在用户白名单
    // 如果白名单功能未开启，这里应该当作默认关闭
    if (buildConfig.noWhiteList) {
      return false
    }
    try {
      const inWhiteList = await cacheGetWhiteList([REGION_WHITE_LIST[key]?.userWhiteList])
      if (inWhiteList[REGION_WHITE_LIST[key]?.userWhiteList]?.length > 0) {
        return key
      }
    } catch (error) {

    }

  }
  return false


}

export async function getGroupRegionFilterFunction(): Promise<
  (regionId: string | number) => boolean
> {
  const keys = await checkConsoleFtCloudUser()
  if (keys) {
    return (regionId: string | number) => {
      if (typeof regionId !== 'string' && typeof regionId !== 'number')
        throw 'regionId should be string or number'
      return getWhiteCloudRegions(keys).some(item => Number(item.id) === Number(regionId) || item.region === regionId)
    }
    //控制台
  }
  return (regionId) => true
}
export async function getGroupZoneFilterFunction(): Promise<
  (zoneId: string | number) => boolean
> {
  const keys = await checkConsoleFtCloudUser()
  if (keys) {
    return (zoneId: string | number) => {
      if (typeof zoneId !== 'string' && typeof zoneId !== 'number')
        throw 'zoneId should be string or number'
      return getWhiteCloudRegions(keys).some(item => item.zoneList.some(zone => Number(zone.zoneId) === Number(zoneId)))
    }
    //控制台
  }
  return zoneId => true
}

/** 获取定制云地域白名单，注意，如果不是定制云用户，此接口会返回空数组，代表全放通（同 ducks/Region # getWhiteList 逻辑） */
export async function getGroupRegionWhiteList(): Promise<number[]> {
  const keys = await checkConsoleFtCloudUser()
  if (!keys) {
    return []
  }
  return getWhiteCloudRegions(keys).map(o => Number(o.id))
}


/** 
 * 先配置 regionWhiteListKey 的Key，再配置 REGION_WHITE_LIST 结构
 * userWhiteList 用户白名单的Key
 * getRegionKey 获取地域的Key
 * 
 */


export enum regionWhiteListKey {
  isFtCloudUser = 'isFtCloudUser',
  isAutoDrivingCloudUser = 'isAutoDrivingCloudUser',
}

interface WhiteListOption {
  userWhiteList: string
  getRegionKey: string
  buyKey: string
}

export const REGION_WHITE_LIST: Record<regionWhiteListKey, WhiteListOption> = {
  [regionWhiteListKey.isFtCloudUser]: {
    userWhiteList: 'GROUP_CLOUD_JR_WHITELIST',
    getRegionKey: 'ftCloudRegions',
    buyKey: 'isGroupCloudUser'
  },
  [regionWhiteListKey.isAutoDrivingCloudUser]: {
    userWhiteList: 'ADC_SINGEL_ADC_WHITELIST',
    getRegionKey: 'autoDrivingCloudRegions',
    buyKey: 'isAutoDrivingCloudUser'
  },
}