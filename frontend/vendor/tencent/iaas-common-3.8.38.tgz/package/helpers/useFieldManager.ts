import * as React from 'react'
import { Column } from '../ducks/GridPage'
import { ColumnField } from '../duckComponents/FieldManager'

/**
 * 搭配FieldManagerButton使用
 * 参数：columns: 所有的Column数组，key: localStorage的缓存key 
 * 返回：key: localStorage的缓存key, filterColumns: 筛选过的columns,
 *  fullColumns: 所有的columns, reload: 刷新columns数组
 */

/**
 * 用例
 * const { filterColumns, reload, fullColumns, key } = useFieldManager(
    columns,
    'cacheKey',
  )
 * <FieldManagerButton fields={fullColumns}
 *  onChange={reload} cacheKey={key}></FieldManagerButton>
 */

export function useFieldManager<T>(columns: Column<T>[], key: string) {
  const [filterColumns, setFilterColumns] = React.useState(columns)
  const [flag, setFlag] =  React.useState(Symbol())
  const list = localStorage.getItem(key)?.split(',')
  const set = new Set(list)
  React.useEffect(() => {
    if (!list) {
      setFilterColumns(columns)
      return
    }
    setFilterColumns(columns.filter(x => set.has(x.key)))
  }, [columns, flag])
  React.useEffect(() => {
    const columnsStringKey = `${key}_columnString`
    const columnsString = localStorage.getItem(columnsStringKey)
    const newColumnsString = columns.map(item => item.key).join(',')
    if (!columnsString || columnsString !== newColumnsString) {
      localStorage.setItem(key, newColumnsString)
    }
    localStorage.setItem(columnsStringKey, newColumnsString)
  }, [columns])
  return {
    key,
    filterColumns,
    fullColumns: columns.map(item => ({ ...item, id: item.key, headTitle: item.header })) as ColumnField[],
    reload: () => {
      setFlag(Symbol())
    },
  }
}
