/**
 * 合并多个 actionTypes
 */
// export function mergeActionTypes() {
//   return Object.assing(...arguments)
// }

export function findByCondition<T>(collection: T[], condition: (item: T) => boolean) : T {
  for (let i = 0; i < collection.length; i++) {
      if (condition(collection[i])) {
          return collection[i];
      }
  }
  return null;
}