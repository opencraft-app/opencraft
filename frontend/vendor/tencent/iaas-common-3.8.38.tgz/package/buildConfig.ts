// 兼容私有云及独立版代码
export interface IaasCommonBuildConfig {
  /** 是否展示地域 */
  showRegion?: boolean
  /** TCE使用平台公共的地域查询（qcbase的queryConsoleRegion接口在TCE不存在） */
  usePlatformRegions?: boolean
  /** 是否禁用地域分组，即不使用RegionSelect组件 */
  noRegionGroup?: boolean
  /** 如果不展示地域，则默认的regionId */
  fixedRegionId?: number
  /** 是否将所有白名单全量（不请求白名单接口） */
  noWhiteList?: boolean
  /** 是否使用tea的请求 */
  useTeaApiRequest?: boolean
}

let iaasCommonBuildConfig: IaasCommonBuildConfig = {
  showRegion: true,
  noWhiteList: false,
  useTeaApiRequest: true
}
const env = process.env.TEA_IAAS_COMMON_BUILD_CONFIG || process.env.IAAS_COMMON_BUILD_CONFIG
if (env) {
  let envConfig
  if (typeof env === 'string') {
    try {
      envConfig = JSON.parse(env)
    } catch (e) { }
  } else if (typeof env === 'object') {
    envConfig = env
  }
  if (envConfig) {
    Object.assign(iaasCommonBuildConfig, envConfig)
  }
}

export default iaasCommonBuildConfig
