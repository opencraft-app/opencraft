import { once } from './helpers/cacheable'
import buildConfig from './buildConfig'
import { t, Trans } from '@tencent/tea-app/lib/i18n'
import apiRequest from './models/apiRequest'
import iaas from '@tencent/iaas-common/inject/iaas'
import getOwnerUin from '@tencent/iaas-common/inject/getOwnerUin'
import { app } from '@tencent/tea-app'
import { OnceDescribeRegionsAndZones } from './models/regionMap'

/**
 * @deprecated 请切换v3接口，使用 models/vpc 内的 DescribeVpcs
 */
export async function DescribeVpcEx(regionId: number, opts?: APIRequestOpts) {
  const result = await apiRequest<DescribeVpcExResult>(
    {
      regionId,
      action: 'DescribeVpcEx',
      serviceType: 'vpc',
      data: {
        offset: 0,
        limit: 999
      }
    },
    opts
  )
  result.data.forEach(vpc => {
    vpc.numId = parseInt(('' + vpc.vpcId).replace(/^\w+_\w+_/, ''), 10)
  })
  return result
}
export interface DescribeVpcExResult {
  data: VpcEx[]
}
export interface VpcEx {
  /** gz_vpc_xxxx  */
  vpcId: string
  /** vpc-xxxxxxxx */
  unVpcId: string
  numId: number
  vpcName: string
  cidrBlock: string
}

/**
 * 获取白名单高级接口（内部云 API 接口）
 * @see https://tcloud4api.woa.com/document/product/1023/56644?!preview&!document=1
 */

export async function getWhiteList(
  keys: string[],
  opts: GetWhiteListOpt = {}
): Promise<GetWhiteListResult> {
  if (buildConfig.noWhiteList) {
    return keys.reduce((o, key) => {
      o[key] = ['USER-ALL', 'REGION-ALL']
      return o
    }, {})
  }
  const {
    type,
    withRegion,
    regionFormat,
    withSingleRegionAll,
    regionIdAllLowercase
  } = opts
  const userList = []
  let userKey = ''

  switch (type) {
    case 'appid':
      userKey = '' + app.user.appId
      break
    case 'uin':
      userKey = '' + app.user.loginUin
      break
    case 'owneruin':
      userKey = '' + app.user.ownerUin
      break
    case 'anonymous': {
      // 匿名用户使用固定串查询，除非白名单全量，否则检查结果均为无权限
      // (除非在白名单中加入这个特殊字符串)
      userKey = 'notLoggedInUser_vpzinmwqb'
    }
    default:
      userKey = '' + app.user.ownerUin
  }
  userList.push(userKey)

  if (withRegion) {
    // 查询地域白名单时，用户列表传入当前所有的地域数字ID列表
    const regionMap = await OnceDescribeRegionsAndZones()
    // 这里合并用户key，是为了方便用户+地域灰度一起获取
    // 添加USER-ALL与REGION-ALL，方便未来单独全量地域或用户（保留另一个灰度）
    switch (regionFormat) {
      case 'regionId':
        userList.push(...regionMap.map(item => item.Region))
        break
      case 'number':
        userList.push(...regionMap.map(item => item.RegionId))
        break
      case 'REGION-INTL-number':
        userList.push(...regionMap.map(item => `REGION-INTL-${item.RegionId}`))
        break
      case 'REGION-number':
      default:
        userList.push(...regionMap.map(item => `REGION-${item.RegionId}`))
    }
    userList.push('USER-ALL', 'REGION-ALL')
  }

  // 某个地域用户全量，形如'REGION-1-ALL'
  if (withSingleRegionAll) {
    const regionMap = await OnceDescribeRegionsAndZones()
    let singeRegionKeyList
    switch (regionFormat) {
      case 'regionId':
        singeRegionKeyList = regionMap.map(item =>
          regionIdAllLowercase ? `${item.Region}-all` : `${item.Region}-ALL`
        )
        break
      case 'number':
        singeRegionKeyList = regionMap.map(item => `${item.RegionId}-ALL`)
        break
      case 'REGION-INTL-number':
        singeRegionKeyList = regionMap.map(
          item => `REGION-INTL-${item.RegionId}-ALL`
        )
        break
      case 'REGION-number':
      default:
        singeRegionKeyList = regionMap.map(
          item => `REGION-${item.RegionId}-ALL`
        )
    }
    userList.push(...singeRegionKeyList)
  }

  try {
    const { Response } = await apiRequest({
      /**
       * @see https://tcloud4api.woa.com/document/product/1023/56644?!preview&!document=1
       */
      action: 'BatchCheckWhitelist',
      serviceType: 'account',
      data: {
        Platform: 0,
        WhitelistKeyList: keys,
        WhitelistUinList: userList,
        Version: '2018-12-25'
      },
      // 不分地域
      regionId: 1
    })
    const result = {}
    Response.MatchedWhitelist.forEach(item => {
      result[item.WhitelistKey] = item.WhitelistUinList
    })

    /**
     * 支持简单的调试，例如临时开启某个地域灰度：
      ```javascript
      devmode?.enter() // 仅在开发模式下生效
      sessionStorage.DEBUG_WHITELISTS = JSON.stringify({'CKAFKA_REGIONS': ['REGION-36']})
      ```
    */
    if (
      window.sessionStorage &&
      (!window['devmode'] || window['devmode'].getStatus() === 'on')
    ) {
      const debugPatchStr = sessionStorage.getItem('DEBUG_WHITELISTS')
      try {
        const debugPatch = JSON.parse(debugPatchStr)
        if (debugPatch) {
          Object.keys(debugPatch).forEach(whiteKey => {
            const patch = debugPatch[whiteKey]
            if (!Array.isArray(patch)) {
              return
            }
            const list = result[whiteKey] || (result[whiteKey] = [])
            list.push(...patch)
          })
        }
      } catch (e) {}
    }
    return result
  } catch (err) {
    iaas.errorHandler({ camTips: false, tipErr: false })?.(err)
    throw err
  }
}
export interface GetWhiteListOpt {
  type?: 'anonymous' | 'appid' | 'uin' | 'owneruin'
  /** 查询白名单时，同时查询地域白名单，默认为false。当type为anonymous时，此参数无效（性能及防刷考虑） */
  withRegion?: boolean
  regionFormat?: 'REGION-number' | 'REGION-INTL-number' | 'number' | 'regionId'
  /** 是否类似ap-guangzhou-all */
  withSingleRegionAll?: boolean
  /** all白名单只允许ap-guangzhou-all小写 */
  regionIdAllLowercase?: boolean
}
interface GetWhiteListResult {
  [key: string]: string[]
}

export function parseGreyInfo(
  result: GetWhiteListResult,
  whiteKey: string,
  regionFormat: GetWhiteListOpt['regionFormat']
): GetGreyInfoResult {
  const list = result[whiteKey] || []
  const regions = []
  const regionSet = new Set<number | string>()
  const regionAllSet = new Set<string>()
  let userInGrey = false
  list.forEach(x => {
    const match = String(x).match(/^REGION-([0-9]+)$/)
    const intlMatch = String(x).match(/^REGION-INTL-([0-9]+)$/)
    const regionIdAllMatch = String(x).match(/^([a-z-]+)-all$/)
    const regionIdMatch = !regionIdAllMatch && String(x).match(/^([a-z-]+)$/)
    if (match) {
      const regionId = parseInt(match[1], 10)
      regions.push(regionId)
      regionSet.add(regionId)
    } else if (regionFormat === 'REGION-INTL-number' && intlMatch) {
      const regionId = parseInt(intlMatch[1], 10)
      regions.push(regionId)
      regionSet.add(regionId)
    } else if (regionFormat === 'regionId' && regionIdMatch) {
      const regionId = String(x)
      regions.push(regionId)
      regionSet.add(regionId)
    } else if (regionFormat === 'regionId' && regionIdAllMatch) {
      const regionId = String(regionIdAllMatch[1])
      regionAllSet.add(regionId)
    } else if (x === 'REGION-ALL') {
      // 地域全量标记
      const regionIds: number[] = buildConfig.showRegion
        ? Object.keys(
            seajs.require('config/constants').REGIONMAP || { 1: 1 }
          ).map(x => parseInt(x, 10))
        : [buildConfig.fixedRegionId]
      regionIds.forEach(regionId => {
        regions.push(regionId)
        regionSet.add(regionId)
      })
    } else if (x === 'USER-ALL') {
      // 用户全量标记
      userInGrey = true
    } else if (getOwnerUin() == x) {
      userInGrey = true
    }
  })
  return {
    whiteKey,
    user: userInGrey,
    regions,
    regionSet,
    regionAllSet
  }
}

/** 获取业务及地域白名单的接口，自动合并请求并缓存 */
export const cacheGetGreyInfo = (function () {
  // 这里好想用rxjs...
  const cache = new Map<string, Promise<GetGreyInfoResult>>()
  let queue: {
    key: string
    regionFormat: GetWhiteListOpt['regionFormat']
    resolve: (r: GetGreyInfoResult) => any
    reject: (e: any) => any
  }[] = []
  let timer: number

  function flush() {
    timer = null
    const list = queue
    queue = []
    const regionFormatSet = new Set<string>()
    list.map(
      x =>
        !regionFormatSet.has(x.regionFormat) &&
        regionFormatSet.add(x.regionFormat)
    )

    Array.from(regionFormatSet).map(async format => {
      const filterList = list.filter(x => x.regionFormat === format)
      await getWhiteList(
        filterList.map(x => x.key),
        {
          withRegion: true,
          withSingleRegionAll: true,
          regionIdAllLowercase: true,
          regionFormat: format as GetWhiteListOpt['regionFormat']
        }
      ).then(
        r => {
          filterList.forEach(x =>
            x.resolve(
              parseGreyInfo(r, x.key, format as GetWhiteListOpt['regionFormat'])
            )
          )
        },
        e => {
          filterList.forEach(x => x.reject(e))
        }
      )
    })
  }

  return function (
    key: string,
    format: GetWhiteListOpt['regionFormat'] = 'REGION-number'
  ) {
    let task: Promise<GetGreyInfoResult>
    if (cache.has(key)) {
      task = cache.get(key)
    } else {
      task = new Promise((resolve, reject) => {
        queue.push({
          key,
          regionFormat: format,
          resolve,
          reject: e => {
            cache.delete(key)
            reject(e)
          }
        })
        if (timer) {
          clearTimeout(timer)
        }
        timer = window.setTimeout(flush, 10)
      })

      cache.set(key, task)
    }
    return task
  }
})()
export interface GetGreyInfoResult {
  /** 业务白名单key */
  whiteKey: string
  /** 当前用户是否在此业务白名单中 */
  user: boolean
  /** 当前地域灰度列表 */
  regions: number[]
  /** 地域灰度Set，方便快速查找 */
  regionSet: Set<number | string>
  /** 某个地域全量，类似ap-guangzhou-all */
  regionAllSet?: Set<string>
}

// 项目获取接口
function _getProjects() {
  return new Promise<{ isShowAll: boolean; data: Project[] }>(
    (resolve, reject) => {
      seajs.require('manager').getProjects(resolve)
    }
  )
}
const cacheGetProject = once(_getProjects)
export async function getProjects(params: getProjectsParam) {
  const data = await cacheGetProject()
  let list: Project[] = []
  // 是否展示“所有项目”
  // 当配置展示 并且 （有所有项目权限 或 接入了CAM）
  if (params.showAll && (data.isShowAll || params.cam)) {
    list.push({
      projectId: -1,
      name: t('所有项目')
    })
  }
  return list.concat(data.data)
}
export interface Project {
  projectId: number
  name: string
  /** 描述 */
  info?: string
  /** 是否为默认项目 */
  isDefault?: number
  /** 格式： 2018-09-05 00:15:46 */
  createTime?: string
}
export interface getProjectsParam {
  /** 是否展示“全部项目”，前提是业务支持 */
  showAll: boolean
  /** 业务是否接入了CAM，如果接入了，则`showAll`开启后必定展示“全部项目” */
  cam?: boolean
}

/** 获取标签 Key  @deprecated 请切换 models/tag 下的v3 DescribeTagKeys接口 */
export function GetTagKeys() {
  return apiRequest({
    action: 'GetTagKeys',
    serviceType: 'tag',
    data: {
      page: 1,
      rp: 1000
    }
  }).then(result => {
    return result.data
  })
}

/** 根据标签 Key 获取 标签 @deprecated 请切换 models/tag 下的v3 DescribeTags接口 */
export function GetTags(tagKeys) {
  return apiRequest({
    action: 'GetTags',
    serviceType: 'tag',
    data: {
      tagKeys: tagKeys,
      page: 1,
      rp: 1000
    }
  }).then(result => {
    return result.data
  })
}
