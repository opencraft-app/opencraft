export type RevisedOmit<T, K> = Exclude<keyof T, K> extends never ? Record<string, never> : Omit<T, K>
