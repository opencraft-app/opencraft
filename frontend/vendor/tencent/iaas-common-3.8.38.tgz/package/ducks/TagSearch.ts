import { ComposableDuck, reduceFromPayload, createToPayload } from 'saga-duck'
import { takeLatest, runAndTakeLatest } from 'redux-saga-catch'
import { select, put } from 'redux-saga/effects'
import { KVAttribute, stringify } from '../components/KVTagSearchBox'

export interface TagAttribute<T, K extends Extract<keyof T, string> = any>
  extends KVAttribute<T, K> {
  /**
   * 哪些actionType表示此值变更了
   * 如果没有定义，则默认取 creator(null).type
   */
  watchTypes?: string[]
  /**
   * 如何获取参数对应的值
   */
  selector: (globalState: any) => T[K]
  /**
   * 如何创建Action通知参数变更。
   */
  creator: (v: T[K]) => any
}

export type TagAttributes<T extends object> = Array<TagAttribute<T>>

/**
 * 标签搜索框/KVTagSearchBox 相关逻辑
 * 
 * 代码参考模板：http://code.qcm.oa.com/?tpl=gridpage&addons=tag-search&patchOnly=1
 */
export default class TagSearch extends ComposableDuck {
  /**
   * KVTagSearchBox的值
   */
  Values: any
  get quickTypes() {
    /*
    尝试一种action type约定
    普通的action修改state，通常为SET_XXX
    仅用于响应外部操作的action为 FIRE_XXX
    仅用于外部监听的action为 EVENT_XXX
    */
    enum TYPE {
      FIRE_SET_VALUES,
      FIRE_SET_ATTRIBUTES,
      SET_ATTRIBUTES,
      SET_CONDITION
    }
    return {
      ...super.quickTypes,
      ...TYPE
    }
  }
  get reducers() {
    return {
      ...super.reducers,
      attributes: reduceFromPayload<TagAttributes<this['Values']>>(
        this.types.SET_ATTRIBUTES,
        []
      ),
      condition: reduceFromPayload(this.types.SET_CONDITION, null)
    }
  }
  get rawSelectors() {
    type State = this['State']
    type Values = this['Values']
    return {
      ...super.rawSelectors,
      /**
       * 供KVTagSearchBox组件使用的属性列表
       */
      attributes: (state: State) => {
        return state.attributes
      },
      /**
       * 标签搜索框的值，对应KVTagSearchBox的value
       *
       * 为了能使用外部的全局selector，需额外传入全局state，即这样使用：
       *
       * ```typescript
       * // in saga
       * const values = tagDuck.selectors.values(yield select(), yield select())
       * // in React
       * const values = tagDuck.selectors.values(store, store)
       * ```
       */
      values: (state: State, globalState: any) => {
        const { attributes } = state
        const values: Values = {} as any
        for (const attr of attributes) {
          values[attr.key] = attr.selector(globalState)
        }
        return values
      },
      /**
       * 序列化后的条件，例如搜索关键字test+标签clue：
       * test、标签:clue
       */
      // 因为values是要额外传globalState的，无法在原有的searchCondition中即时使用计算，只能放在state中维护了
      condition: (state: State) => state.condition
    }
  }
  get creators() {
    const { types } = this
    type Attributes<TRefState> = TagAttributes<this['Values']>
    return {
      ...super.creators,
      /**
       * 可配置属性列表，对应对应KVTagSearchBox的attributes
       */
      setAttributes: createToPayload<TagAttributes<this['Values']>>(
        types.FIRE_SET_ATTRIBUTES
      ),
      /**
       * 值更新，对应KVTagSearchBox的onChange
       */
      setValues: createToPayload<this['Values']>(types.FIRE_SET_VALUES)
    }
  }
  *saga() {
    yield* super.saga()
    yield* this.sagaSetAttributesWatch()
    yield* this.sagaSetValuesWatch()
    yield* this.sagaConditionWatch()
  }
  // 同步查询条件
  protected *sagaConditionWatch() {
    const duck = this
    const { types, selector, selectors } = this
    yield runAndTakeLatest(types.SET_ATTRIBUTES, function*() {
      // 有时候条件并没有通过tagSearch来改变，这时就需要主动监听了
      const { attributes } = selector(yield select())
      let watchTypes = []
      for (const attr of attributes) {
        if (attr.watchTypes) {
          watchTypes = watchTypes.concat(attr.watchTypes)
        } else {
          watchTypes.push(attr.creator(null).type)
        }
      }
      yield runAndTakeLatest(
        [types.FIRE_SET_VALUES, ...watchTypes],
        [duck, duck.sagaUpdateCondition]
      )
    })
  }
  protected *sagaUpdateCondition() {
    const { types } = this
    yield put({
      type: types.SET_CONDITION,
      payload: yield* this.getSearchCondition()
    })
  }
  /**
   * 获取当前的搜索条件，同步的！避免state中的searchCondition更新晚一个时序
   * 
   * saga版对外接口，用于duck间调用
   */
  public *getSearchCondition(){
    const { selectors } = this
    const values = selectors.values(yield select(), yield select())
    const attributes = selectors.attributes(yield select())
    return stringify(values, attributes)
  }
  protected *sagaSetAttributesWatch() {
    const duck = this
    yield takeLatest(this.types.FIRE_SET_ATTRIBUTES, function*(action) {
      yield* duck.setAttributes(action.payload)
    })
  }
  /**
   * 设置KVTagSearchBox的属性列表
   *
   * saga版对外接口，用于duck间调用
   * @param attributes
   */
  public *setAttributes(attributes: TagAttributes<this['Values']>) {
    yield put({
      type: this.types.SET_ATTRIBUTES,
      payload: attributes
    })
  }
  // 反向同步值
  protected *sagaSetValuesWatch() {
    const duck = this
    yield takeLatest(this.types.FIRE_SET_VALUES, function*(action) {
      yield* duck.setValues(action.payload)
    })
  }
  /**
   * 设置KVTagSearchBox的值
   *
   * saga版对外接口，用于duck内部调用
   * @param values
   */
  public *setValues(values: this['Values']) {
    const { attributes } = this.selector(yield select())
    for (const attr of attributes) {
      let newValue = values[attr.key]
      if (newValue === undefined) {
        newValue = attr.defaults
      }
      const oldValue = attr.selector(yield select())
      // 值不同时才更新
      if (newValue !== oldValue) {
        yield put(attr.creator(newValue))
      }
    }
  }
}
