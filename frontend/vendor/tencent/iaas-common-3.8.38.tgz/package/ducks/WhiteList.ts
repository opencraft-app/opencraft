/**
 * 判断有没有在白名单内，state可能有以下值
 * null 查询未完成，未知白名单状态
 * {[key]: true} 在白名单内，可以访问
 * {[key]: false} 不在白名单，需要展示内测申请页
 */
import { app } from '@tencent/tea-app'
import { put, call, select } from 'redux-saga/effects'
import { BaseDuck } from 'saga-duck'
import { resolvePromise } from 'saga-duck/build/helper'
import buildConfig from '../buildConfig'

enum Types {
  DONE
}
interface Map {
  [key: string]: boolean
}

// 简单缓存
const cache = {}
export default class WhiteListDuck extends BaseDuck {
  get quickTypes() {
    return {
      ...super.quickTypes,
      ...Types
    }
  }
  get reducer() {
    const { types } = this
    return (state = null, action): Map => {
      //   if (!state) {
      //     state = {}
      //     whiteKeys.forEach(key => {
      //       state[key] = null
      //     })
      //   }
      switch (action.type) {
        case types.DONE:
          return action.payload
        default:
          return state
      }
    }
  }
  *saga() {
    yield* super.saga()
    yield this.ready()
  }
  /**
   * 等待白名单加载完成再继续
   * @return {SagaEffect<whiteListMap>}
   */
  ready() {
    return call(this.waitReady, this)
  }
  *waitReady({ types, selector, whiteKeys }: this) {
    let map = yield select(selector)
    if (!map) {
      const cacheKey = whiteKeys.join(',')
      if (!cache[cacheKey]) {
        if (buildConfig.noWhiteList) {
          const map = whiteKeys.reduce((map, key) => {
            map[key] = true
            return map
          }, {})
          cache[cacheKey] = map
        } else {
          const map = {}
          const data = yield* resolvePromise(
            app.user.checkWhitelistBatch(whiteKeys)
          )
          whiteKeys.forEach(key => {
            map[key] = !!data[key]
          })
          cache[cacheKey] = map
        }
      }
      map = yield cache[cacheKey]
      yield put({ type: types.DONE, payload: map })
    }
    return map
  }
  /**
   * 要加载的白名单列表
   */
  get whiteKeys() {
    return ['TEST']
  }
}
