// 项目单选
// 可配置“所有项目”项，同时有些用户是不支持的 done
// 更新当前选中项到localStorage/cookie中 done
import Base from '../ducks/AsyncSelect'
import Fetcher from '../ducks/Fetcher'
import { PageParam } from '../ducks/Page'
import { put, select, takeEvery, all, call, fork } from 'redux-saga/effects'
import { t } from '@tencent/tea-app/lib/i18n'

const manager = seajs.require('manager')
const appUtil = seajs.require('appUtil')

type TID = number
interface TParam {
  showAll: boolean
  cam: boolean
}
interface State {}
enum Types {}
interface Creators {}
interface Selectors {
  visible: boolean
}
export default class Duck extends Base {
  ID: TID
  Item: Project
  Param: TParam
  get Fetcher() {
    return ProjectFetcher
  }
  getId(item: Project): TID {
    // -1表示所有项目，0表示默认项目
    return item ? item.projectId : 0
  }
  /** 是否同步到localStorage/cookie中，保证切换页面也能保持地域。默认为true，可重写 */
  get syncCookie(): boolean {
    return true
  }
  /** 是否展示“所有项目”项（如果有权限） */
  get showAll(): boolean {
    return false
  }
  /** 资源是否接入了CAM，此时就算协作者没有项目权限，但有项目下资源权限，所以还是可以选“所有项目” */
  get cam(): boolean {
    return false
  }
  get rawSelectors() {
    type State = this['State']
    return {
      ...super.rawSelectors,
      // 如果除开“所有项目”外时，列表为空或只有一个默认项目，则不展示
      // 或者说，如果有任何为“所有项目”或默认项目外的项，则展示
      visible: ({ list }: State) => {
        return list && list.some(o => o.projectId !== -1 && o.projectId !== 0)
      }
    }
  }
  *saga() {
    yield* super.saga()
    yield fork([this, this.sagaSyncCookie])
  }
  // 初始加载
  *sagaInitFetch() {
    const duck = this
    yield put(
      duck.ducks.fetcher.creators.fetch({
        showAll: duck.showAll,
        cam: duck.cam
      })
    )
  }
  // 选中项目时，同步到localStorage中
  *sagaSyncCookie() {
    const duck = this
    if (!duck.syncCookie) {
      return
    }
    yield takeEvery(duck.types.SELECT, function*() {
      appUtil.setProjectId(duck.selector(yield select()).id)
    })
  }
  get defaultId() {
    return -1
  }
  /**
   * 供与Route组合时使用
   */
  getRouteParam(opts?: Partial<PageParam<number>>): PageParam<number> {
    return {
      key: 'pid',
      order: -1,
      defaults: () => this.defaultId,
      parse: v => {
        const i = parseInt(v, 10)
        return isNaN(i) ? this.defaultId : i
      },
      type: this.types.SELECT,
      selector: v => this.selector(v).id,
      ...opts
    }
  }
}

class ProjectFetcher extends Fetcher {
  Param: TParam
  Data: Project[]
  async getDataAsync(params: TParam) {
    const data = await new Promise<{ isShowAll: boolean; data: Project[] }>(
      (resolve, reject) => {
        manager.getProjects(resolve)
      }
    )
    let list: Project[] = []
    // 是否展示“所有项目”
    // 当配置展示 并且 （有所有项目权限 或 接入了CAM）
    if (params.showAll && (data.isShowAll || params.cam)) {
      list.push({
        projectId: -1,
        name: t('所有项目')
      })
    }
    return list.concat(data.data)
  }
}

export interface Project {
  projectId: number
  name: string
  isDefault?: number
}
