/**
 * 拉取标签数据，可以带缓存
 * @author yuemingliu
 */
import { GetTags } from '../model'
import { DescribeTagKeys, DescribeTagKeysInstances } from '../models/tag'
import { put, select, call, all, fork } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga-catch'
import { DuckMap } from 'saga-duck'

let tagKeys: string[] = null
let tagValueMap: { [tagKey: string]: string[] } = {}

export default class TagDuck extends DuckMap {
  // 是否使用全局缓存
  get withCache() {
    return false
  }
  get quickTypes() {
    return {
      ...super.quickTypes,
      FETCH_TAG_KEYS: 'FETCH_TAG_KEYS',
      FETCH_TAG_VALUES: 'FETCH_TAG_VALUES',
      UPDATE_TAG_KEYS: 'UPDATE_TAG_KEYS',
      UPDATE_TAG_VALUES: 'UPDATE_TAG_VALUES'
    }
  }
  get creators() {
    const { types } = this
    return {
      ...super.creators,
      fetchTagKeys: () => ({ type: types.FETCH_TAG_KEYS }),
      fetchTagValues: tagKeys => ({
        type: types.FETCH_TAG_VALUES,
        payload: tagKeys
      })
    }
  }
  get reducers() {
    const { types } = this
    return {
      ...super.reducers,
      tagKeys: (state = [], action) =>
        action.type === types.UPDATE_TAG_KEYS ? action.payload : state,
      tagValueMap: (state = {}, action) =>
        action.type === types.UPDATE_TAG_VALUES ? action.payload : state
    }
  }
  get rawSelectors() {
    return {
      ...super.rawSelectors
    }
  }
  *saga() {
    yield* super.saga()
    yield fork([this, this.fetchTagKeys])
    yield fork([this, this.fetchTagValues])
  }
  *fetchTagKeys() {
    const { types, withCache } = this
    yield takeLatest([types.FETCH_TAG_KEYS], function* () {
      if (!withCache || !tagKeys) {
        const {
          Response: { Tags }
        } = yield DescribeTagKeysInstances(null)
        tagKeys = Tags
      }
      yield put({ type: types.UPDATE_TAG_KEYS, payload: tagKeys.map(x => x) })
    })
  }
  *fetchTagValues() {
    const { types, withCache } = this
    yield takeLatest([types.FETCH_TAG_VALUES], function* (action) {
      const tagKeys = action.payload
      if (!withCache || tagKeys.some(key => !tagValueMap[key])) {
        const { rows } = yield GetTags(tagKeys)
        tagValueMap = {
          ...tagValueMap,
          ...rows.reduce((pre, cur) => {
            if (pre[cur.tagKey]) {
              pre[cur.tagKey].push(cur.tagValue)
            } else {
              pre[cur.tagKey] = [cur.tagValue]
            }
            return pre
          }, {})
        }
      }
      yield put({
        type: types.UPDATE_TAG_VALUES,
        payload: { ...tagValueMap }
      })
    })
  }
}
