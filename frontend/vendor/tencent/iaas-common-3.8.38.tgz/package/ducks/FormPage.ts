/**
 * page的表单，子duck调用 CREATE_INIT ，数据初始化
 */
import { DuckMap } from 'saga-duck'
import { select, put, call, take, fork, cancel } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga-catch'
import { isCamRefused } from '../components/Cam'
import Form from '../ducks/Form'
import getErrorMessage from '../util/getErrorMessage'

import tips from '@tencent/iaas-common/inject/tips'
interface FormClass {
  new (...any: any[]): Form
}

enum Types {
  'CREATE_INIT',
  'SHOW',
  'UPDATE',
  'SET_DISABLED',
  'SUBMIT',
  'SUBMIT_DONE',
  'SUBMIT_FAIL',
  'HIDE'
}

export default abstract class FormPage extends DuckMap {
  // abstract FormValues
  get FormValues(): InstanceType<this['Form']>['Values'] {
    return null
  }
  /** 初始化数据类型定义 */
  Data
  /** SUBMIT payload 类型定义 */
  SubmitData
  /** 提交逻辑 - 子类扩展实现 */
  abstract onSubmit(values: this['FormValues'], initialValues: this['Data'])
  /** 对应的表单Duck - 子类扩展实现 */
  abstract get Form(): FormClass
  get quickTypes() {
    return {
      ...super.quickTypes,
      ...Types
    }
  }
  get quickDucks() {
    return {
      ...super.quickDucks,
      form: this.Form
    }
  }
  get reducers() {
    const { types } = this
    return {
      ...super.reducers,
      data: (state: this['Data'] = {}, action): this['Data'] => {
        switch (action.type) {
          case types.CREATE_INIT:
            return action.payload
          case types.SHOW:
            return action.payload
          case types.UPDATE:
            return Object.assign({}, state, action.payload)
          default:
            return state
        }
      },
      visible: (state = true, action): boolean => {
        switch (action.type) {
          case types.SHOW:
            return true
          case types.HIDE:
            return false
          default:
            return state
        }
      },
      submitting: (state = false, action): boolean => {
        switch (action.type) {
          case types.SUBMIT:
            return true
          case types.SUBMIT_DONE:
          case types.SUBMIT_FAIL:
            return false
          default:
            return state
        }
      },
      disabled: (state = false, action): boolean => {
        switch (action.type) {
          case types.SET_DISABLED:
            return action.payload
          case types.SHOW:
            return false
          default:
            return state
        }
      }
      // remove: dialogReducer(types.REMOVE),
    }
  }
  get creators() {
    const { types } = this
    return {
      ...super.creators,
      createInit: payload => ({ type: types.CREATE_INIT, payload }),
      show: payload => ({ type: types.SHOW, payload }),
      update: payload => ({ type: types.UPDATE, payload }),
      submit: payload => ({ type: types.SUBMIT, payload }),
      hide: () => ({ type: types.HIDE }),
      setDisabled: payload => ({ type: types.SET_DISABLED, payload })
    }
  }
  get rawSelectors() {
    type State = this['State']
    return {
      ...super.rawSelectors,
      /** 是否可见 */
      visible: (state: State) => state.visible,
      /** 是否加载中 */
      loading: (state: State) => state.submitting,
      /** 能否提交 */
      canSubmit: (state: State) => !state.submitting && !state.disabled,
      /** 入参 */
      data: (state: State): this['Data'] => state.data
    }
  }
  /**
   * 展示对话框
   * @param {*} data 传入数据
   * @param {*} doSave 保存流程，可以是async或saga
   * @return SagaEffect<finished>
   */
  *show(
    data: Partial<this['Data']>,
    doSave: (submitData: this['SubmitData'], data: this['Data']) => any
  ) {
    return yield* this.withDialog(this, data, doSave)
  }
  /**
   * 展示中的时候处理的任务，隐藏时自动取消
   */
  *onShow(): any {
    const duck = this
    const { selector, ducks } = duck
    const { data } = selector(yield select())
    yield put(ducks.form.creators.setAllTouched(false))
    yield put(ducks.form.creators.setValues(data, true))
  }

  *withDialog(
    duck: this,
    data: Partial<this['Data']>,
    doSave: (submitData: this['SubmitData'], data: this['Data']) => any
  ) {
    const { types, selectors, creators, options, tipError, beforeSubmit } = duck
    // 显示
    yield put(creators.show(data))
    const showingTask = yield fork([duck, duck.onShow])
    // 等待提交，除非用户中止或被其它人抢占，否则这里永远不结束
    try {
      while (1) {
        const action = yield take([types.SUBMIT, types.SHOW, types.HIDE])
        // 被抢占或用户取消
        if (action.type !== types.SUBMIT) {
          return false
        }
        try {
          // 如果前置逻辑未通过，则不继续
          yield call([this, beforeSubmit])
          yield call(doSave, action.payload, data)
          yield put({ type: types.SUBMIT_DONE })
          // 默认完成后都关闭
          yield put(creators.hide())
          // 成功
          return true
        } catch (e) {
          // 提示错误
          if (tipError) {
            const message =  (e.code ? '[' + e.code + '] ' : '') + getErrorMessage(e)
            tips.error(message)
          }
          yield put({ type: types.SUBMIT_FAIL, payload: e })
          // 如果是cam错误，关闭dialog
          //  isCamRefused(e) ? yield put({ type: types.HIDE }) : null
        }
      }
    } finally {
      yield cancel(showingTask)
    }
  }
  *execute(data: Partial<this['Data']>) {
    const duck = this
    const { selector } = duck
    return yield this.show(data, function*() {
      const state = selector(yield select())
      const values = state.form.values
      yield call([duck, duck.onSubmit], values, data)
    })
  }
  /** 在提交出错时，是否使用tips.error展示错误，默认为false */
  get tipError(): boolean {
    return false
  }
  // 有错误不提交
  *beforeSubmit() {
    const {
      ducks: { form }
    } = this
    const { creators, selectors } = form as Form
    const invalid = selectors.firstInvalid(yield select())
    if (invalid) {
      yield put(creators.setAllTouched())
      throw invalid
    }
  }
  *saga() {
    yield* super.saga()
    yield fork([this, this.sagaInit])
  }
  //提供初始化action出口，方便初始化，不用在子duck写一堆action
  *sagaInit() {
    const duck = this
    const { types } = duck
    yield takeLatest([types.CREATE_INIT], function*(action) {
      yield duck.execute(action.payload)
    })
  }
}
