// TODO ComposableDuck ts版 代码模板
import {
  DuckMap as Base,
  reduceFromPayload,
  createToPayload
} from 'saga-duck'
import { select, put, call, take, fork, join } from 'redux-saga/effects'
import { takeLatest, takeEvery, delay } from 'redux-saga-catch'

enum Types {}

export default class Duck extends Base {
  get quickTypes(){
    return {
      ...super.quickTypes,
      ...Types
    }
  }
  get reducers(){
    const {types}=this
    return {
      ...super.reducers,
      // foo: reduceFromPayload<string>(types.FOO, null)
    }
  }
  get creators(){
    const {types}=this
    return {
      ...super.creators,
      // foo: createToPayload<string>(types.FOO)
    } 
  }
  get rawSelectors(){
    type State = this['State']
    return {
      ...super.rawSelectors,
      // foo: (state: State)=>state.foo,
      // bar: (state: State)=>this.rawSelectors.foo(state)
    }
  }
  get quickDucks(){
    return {
      ...super.quickDucks,
      // foo: Foo
    }
  }
  *saga(){
    yield* super.saga()
    // yield fork([this, this.sagaExample])
  }
}
