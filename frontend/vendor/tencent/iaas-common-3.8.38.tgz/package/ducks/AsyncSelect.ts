import { asResult, reduceFromPayload, createToPayload } from 'saga-duck'
import { select, put, call, take } from 'redux-saga/effects'
import { takeLatest, runAndTakeLatest, takeEvery } from 'redux-saga-catch'
import Fetcher from './Fetcher'
import Base from './Select'

interface MyFetcher<TData, TParam> extends Fetcher {
  Param: TParam
  Data: TData
}
type FetcherType<TData, TParam> = {
  new (...any: any[]): MyFetcher<TData, TParam>
}
/**
 * 动态单选，关联一个fetcher，需要使用者扩展指定
 */
export default abstract class Duck extends Base {
  /** Fetcher使用的入参类型定义 */
  GetDataParam
  /** 快速定义方法，不需要再定义Fetcher */
  async getData(param: this['GetDataParam']): Promise<this['Item'][]> {
    return []
  }
  /** 也可以使用 getData 替代 */
  get Fetcher(): FetcherType<this['Item'][], this['GetDataParam']> {
    return null
  }
  get creators() {
    return {
      ...super.creators,
      fetch: this.ducks.fetcher.creators.fetch
    }
  }
  get quickDucks() {
    const duck = this
    type Param = this['GetDataParam']
    type Data = this['Item'][]
    class MyFetcher extends Fetcher {
      Param: Param
      Data: Data
      async getDataAsync(param: MyFetcher['Param']) {
        return duck.getData(param)
      }
    }
    return {
      ...super.quickDucks,
      fetcher: (this.Fetcher || MyFetcher) as this['Fetcher']
    }
  }
  *saga() {
    yield* super.saga()
    yield* this.sagaSyncList()
  }
  /** 同步fetcher数据到list */
  *sagaSyncList(duck = this) {
    const {
      types,
      creators,
      ducks: { fetcher }
    } = duck
    // 加载成功、失败、重置时，更新列表
    yield takeLatest(
      [fetcher.types.FETCH_DONE, fetcher.types.FETCH_FAIL, fetcher.types.RESET],
      function* () {
        const state = fetcher.selector(yield select())
        yield put(creators.setList(state.data || []))
      }
    )
  }
  *sagaAssureSelection() {
    const {
      list,
      fetcher: { data }
    } = this.selector(yield select())
    // 当列表没有加载时，不执行自动修正
    if ((!list || !list.length) && data !== list) {
      return
    }
    return yield* super.sagaAssureSelection()
  }
}

// 测试/示例代码
if (process.env.NEVER_RUN) {
  interface Param {
    offset: number
  }
  interface Item {
    text: string
    value: string
  }
  class Test extends Duck {
    ID: string
    Item: Item
    // get Fetcher() {
    //   return TestFetcher
    // }
    async getData(param: this['GetDataParam']) {
      return []
    }
  }

  const test = new Test()
  test.ducks.fetcher.State.data[0].text
  // test.ducks.fetcher.funny

  // class TestFetcher extends Fetcher {
  //   Param: Param
  //   Data: Item[]
  //   async getDataAsync(param: this['Param']) {
  //     return []
  //   }
  //   funny() {}
  // }
}
