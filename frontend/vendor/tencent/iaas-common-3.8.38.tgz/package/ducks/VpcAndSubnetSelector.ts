// 网络选择器，选择VPC和子网
import { t } from '@tencent/tea-app/lib/i18n';
import {
  ComposableDuck as Base,
  reduceFromPayload,
  createToPayload,
  asResult
} from 'saga-duck';
import { select, put, call, take, fork, join } from 'redux-saga/effects';
import { Task } from 'redux-saga';
import { takeLatest, runAndTakeLatest, delay } from 'redux-saga-catch';
import FetcherDuck from './Fetcher';
import { PageParam } from './Page';
import * as vpc from '../models/vpc';
import pagingFetch from '../helpers/pagingFetch';
import { once } from '../helpers/cacheable';

const DescribeAccountAttributes = once((rid: number) =>
  vpc.DescribeAccountAttributes(rid, {})
);

export interface Options {
  regionId: number;
  /** VPC子网查询v3接口不支持数字id了，所以要由外部来转 */
  zoneV3Id?: string;
  /** 业务是否支持默认vpc，如支持，则only-vpc用户不传vpcId与subnetId也会自动新建。默认为false */
  supportDefaultVpc?: boolean;
  /** 是否支持子网，如果不支持，不加载子网数据，默认为false */
  supportSubnet?: boolean;
  /** 是否支持低版本私有网络（即numId<65535)，默认为false */
  supportOldVpc?: boolean;
}

export interface Vpc {
  /** 格式如 vpc-xxxxxxxx */
  id: string;
  name: string;
  isDefault: boolean;
  cidr: string;
}
export interface Subnet {
  /** 格式如 subnet-xxxxxxxx */
  id: string;
  name: string;
  isDefault: boolean;
  cidr: string;
  ipv6Cidr: string;
  totalIPNum: number;
  availableIPNum: number;
}

interface VpcParam {
  regionId: number;
}
class VpcFetcher extends FetcherDuck {
  Param: VpcParam;
  Data: Vpc[];
  protected async getDataAsync(params: VpcParam) {
    const list = await pagingFetch(
      async (offset, limit) => {
        const result = await vpc.DescribeVpcs(params.regionId, {
          Offset: String(offset),
          Limit: String(limit)
        });
        return {
          totalCount: result.TotalCount,
          list: result.VpcSet
        };
      },
      {
        maxLimit: 200
      }
    );

    if (!list) {
      throw t('没有可用的私有网络');
    }
    return list.map(o => ({
      id: o.VpcId,
      name: o.VpcName,
      cidr: o.CidrBlock,
      isDefault: o.IsDefault
    }));
  }
}

interface SubnetParam {
  regionId: number;
  vpcId: string;
  zoneV3Id: string;
}
class SubnetFetcher extends FetcherDuck {
  Param: SubnetParam;
  Data: Subnet[];
  protected async getDataAsync(params: SubnetParam) {
    const filters: vpc.DescribeSubnetsParams['Filters'] = [
      {
        Name: 'vpc-id',
        Values: [params.vpcId]
      }
    ];
    if (params.zoneV3Id) {
      filters.push({
        Name: 'zone',
        Values: [params.zoneV3Id]
      });
    }
    const list = await pagingFetch(
      async (offset, limit) => {
        const result = await vpc.DescribeSubnets(params.regionId, {
          Offset: String(offset),
          Limit: String(limit),
          Filters: filters
        });
        return {
          totalCount: result.TotalCount,
          list: result.SubnetSet
        };
      },
      {
        maxLimit: 200
      }
    );

    if (!list) {
      throw t('没有可用的子网');
    }
    return list.map<Subnet>(o => ({
      id: o.SubnetId,
      name: o.SubnetName,
      cidr: o.CidrBlock,
      ipv6Cidr: o.Ipv6CidrBlock,
      totalIPNum: o.TotalIpAddressCount,
      availableIPNum: o.AvailableIpAddressCount,
      isDefault: o.IsDefault
    }));
  }
}

export interface ValidateResult {
  vpc?: string;
  subnet?: string;
  addDefaultSubnet?: string;
}

export default class Duck extends Base {
  // 注意：有些地域是仅VPC网络，如果同时不是only-vpc用户，则用户需要自己新建
  /** 业务是否支持默认vpc，即对于默认vpc用户，没有传vpc时会自动创建。默认为false */
  get supportDefaultVpc() {
    return false;
  }
  /** 是否支持低版本私有网络（即numId<=65535的vpc），默认为true */
  get supportOldVpc() {
    return true;
  }
  /** 是否支持子网 */
  get supportSubnet() {
    return true;
  }
  get quickTypes() {
    enum Types {
      LOAD_START,
      RELOAD,
      SELECT_VPC,
      SELECT_SUBNET,
      SET_LOADING,
      SET_SUPPORT_DEFAULT_VPC,
      SET_SUPPORT_OLD_VPC,
      SET_VPC_ONLY,
      SET_SUPPORT_SUBNET,
      SET_CAN_ADD_DEFAULT_SUBNET
    }
    return {
      ...super.quickTypes,
      ...Types
    };
  }
  get reducers() {
    const { types } = this;
    return {
      ...super.reducers,
      options: reduceFromPayload<Options>(types.LOAD_START, null),
      vpcId: reduceFromPayload<string>(types.SELECT_VPC, null),
      subnetId: reduceFromPayload<string>(types.SELECT_SUBNET, null),
      loading: reduceFromPayload(types.SET_LOADING, false),
      /** 业务是否支持默认vpc，即对于默认vpc用户，没有传vpc时会自动创建 */
      supportDefaultVpc: reduceFromPayload(
        types.SET_SUPPORT_DEFAULT_VPC,
        this.supportDefaultVpc
      ),
      /** 是否支持低版本私有网络（即numId<=65535的vpc），默认为true */
      supportOldVpc: reduceFromPayload(
        types.SET_SUPPORT_OLD_VPC,
        this.supportOldVpc
      ),
      /** 是否是vpc-only用户，只有vpc-only用户+业务支持默认vpc时，才自动创建默认vpc */
      isVpcOnly: reduceFromPayload(types.SET_VPC_ONLY, null),
      /** 有的业务是vpc级，不需要选子网 */
      supportSubnet: reduceFromPayload(
        types.SET_SUPPORT_SUBNET,
        this.supportSubnet
      ),
      /** 如果是默认vpc模式，当前是否能创建默认子网 */
      canAddDefaultSubnet: reduceFromPayload(
        types.SET_CAN_ADD_DEFAULT_SUBNET,
        true
      )
    };
  }
  get rawSelectors() {
    type State = this['State'];
    return {
      ...super.rawSelectors,

      vpc: (state: State) =>
        (state.vpc.data || []).find(o => o.id === state.vpcId),

      subnet: (state: State) =>
        (state.subnet.data || []).find(o => o.id === state.subnetId),
      invalids: (state: State) => this.validate(state),
      isValid: (state: State) => Object.keys(this.validate(state)).length <= 0
    };
  }
  get creators() {
    const { types } = this;
    return {
      ...super.creators,
      reload: () => ({ type: types.RELOAD }),
      selectVpc: (vpcId: string) => ({
        type: types.SELECT_VPC,
        payload: vpcId
      }),
      selectSubnet: (subnetId: string) => ({
        type: types.SELECT_SUBNET,
        payload: subnetId
      }),
      setSupportDefaultVpc: createToPayload<boolean>(
        types.SET_SUPPORT_DEFAULT_VPC
      ),
      setSupportOldVpc: createToPayload<boolean>(types.SET_SUPPORT_OLD_VPC),
      setVpcOnly: createToPayload<boolean>(types.SET_VPC_ONLY),
      setSupportSubnet: createToPayload<boolean>(types.SET_SUPPORT_SUBNET)
    };
  }
  get quickDucks() {
    return {
      ...super.quickDucks,
      vpc: VpcFetcher,
      subnet: SubnetFetcher
    };
  }
  *saga() {
    yield* super.saga();
  }
  public *fetch(options: Options) {
    const duck = this;
    const { selector, types, creators } = duck;
    if (options !== selector(yield select()).options) {
      yield put({
        type: types.LOAD_START,
        payload: options
      });
    }
    // only-vpc属性判断
    const task: Task = yield fork([duck, duck.isDefaultVpc], options.regionId);
    // 有可能有缓存，会同步完成，做个判断减少不必要的action吧
    yield call(delay, 0);
    if (task.isRunning()) {
      yield put(creators.setVpcOnly(null));
    }
    // 不阻塞更新only-vpc属性
    yield fork(function* () {
      const isDefaultVpc = yield join(task);
      yield put(creators.setVpcOnly(isDefaultVpc));
    });

    // 初始加载及刷新
    yield* duck.sagaFetchVpcAndWatch();
  }
  /**
   * 主加载流程
   */
  *sagaFetchVpcAndWatch() {
    const duck = this;
    const {
      types,
      selector,
      creators,
      ducks: { vpc, subnet }
    } = duck;
    yield runAndTakeLatest(types.RELOAD, function* () {
      yield put({
        type: types.SET_LOADING,
        payload: true
      });
      // 先清空数据
      yield put(vpc.creators.reset());
      yield put(subnet.creators.reset());

      yield call([duck, duck.sagaFetchVpc]);
      // 初始或切换VPC时加载子网列表
      if (selector(yield select()).supportSubnet) {
        yield* duck.sagaFetchSubnetAndWatch();
      } else {
        // 只有没有子网时才认为vpc加载完毕为完成，有子网时，在子网加载流程中处理
        // 或可考虑优化一下，直接使用缓冲整合vpc、subnet等的loading状态
        yield put({
          type: types.SET_LOADING,
          payload: false
        });
        // 如果临时启用，即时加载子网
        yield fork(function* () {
          do {
            yield take(types.SET_SUPPORT_SUBNET);
          } while (!selector(yield select()).supportSubnet);
          yield* duck.sagaFetchSubnetAndWatch();
        });
      }
    });
  }
  *sagaWaitVpcOnly() {
    const { selector, types } = this;
    let isVpcOnly;
    do {
      isVpcOnly = selector(yield select()).isVpcOnly;
      if (isVpcOnly !== null) {
        return isVpcOnly;
      }
    } while (yield take(types.SET_VPC_ONLY));
  }
  /**
   * VPC加载流程
   */
  *sagaFetchVpc() {
    const duck = this;
    const {
      types,
      creators,
      selector,
      selectors,
      ducks: { vpc }
    } = duck;

    const { options, vpcId, supportDefaultVpc, supportSubnet } = asResult(
      selector,
      yield select(selector)
    );
    // 加载VPC
    const vpcs = yield* vpc.fetch({ regionId: options.regionId });
    const vpcFound = vpcs.some(vpc => vpc.id === vpcId);
    if (!vpcFound) {
      let vpcId = '';
      // 如果业务支持默认VPC且为默认VPC用户，选中已创建的默认VPC；如果没有，则选第一条
      // 其它情况都选第一条
      const isVpcOnly = yield* duck.sagaWaitVpcOnly();
      if (supportDefaultVpc && isVpcOnly) {
        vpcs.some(vpc => {
          if (vpc.isDefault) {
            vpcId = vpc.id;
            return true;
          }
        });
      }
      if (!vpcId) {
        const vpc = this.getOneVpc(vpcs);
        vpcId = vpc ? vpc.id : '';
      }
      yield put(creators.selectVpc(vpcId));
    }
  }
  *sagaFetchSubnetAndWatch() {
    const duck = this;
    const { types, creators } = duck;
    yield runAndTakeLatest(types.SELECT_VPC, function* () {
      yield put({
        type: types.SET_LOADING,
        payload: true
      });
      yield call([duck, duck.sagaFetchSubnet]);
      yield put({
        type: types.SET_LOADING,
        payload: false
      });
    });
  }
  /**
   * 子网加载流程
   */
  *sagaFetchSubnet() {
    const duck = this;
    const {
      types,
      selector,
      selectors,
      creators,
      ducks: { subnet }
    } = duck;
    const {
      options,
      vpcId,
      subnetId,
      supportSubnet,
      supportDefaultVpc
    } = asResult(selector, yield select(selector));
    const vpc = selectors.vpc(yield select());
    // 是否选中已经创建了的默认VPC
    const isDefaultVpcSelected = vpc && vpc.isDefault;

    // 如果支持默认vpc（需要业务支持，并且是only-vpc用户），并且选的是默认vpc，检查是否能创建默认子网
    const isVpcOnly = yield* duck.sagaWaitVpcOnly();
    const defaultVpcEnabled = supportDefaultVpc && isVpcOnly;
    if (defaultVpcEnabled && isDefaultVpcSelected) {
      yield fork(function* () {
        // 不重要的流程，出错了不要影响子网加载
        try {
          yield put({
            type: types.SET_CAN_ADD_DEFAULT_SUBNET,
            payload: yield duck.checkDefaultSubnet(
              options.regionId,
              vpcId,
              options.zoneV3Id
            )
          });
        } catch (e) {}
      });
    }
    // 加载子网列表
    const subnets: Subnet[] = vpcId
      ? yield subnet.fetch({
          regionId: options.regionId,
          zoneV3Id: options.zoneV3Id,
          vpcId
        })
      : [];
    // 加载完后保证选中一项
    const subnetFound = subnets.some(subnet => subnet.id === subnetId);
    if (!subnetFound) {
      let subnetId = '';
      // 如果是默认VPC用户，优先选择已创建的默认VPC/子网
      if (defaultVpcEnabled && isDefaultVpcSelected) {
        subnets.some(subnet => {
          if (subnet.isDefault) {
            subnetId = subnet.id;
            return true;
          }
        });
      }
      if (!subnetId) {
        // 否则执行默认选中
        const subnet = this.getOneSubnet(subnets);
        subnetId = subnet ? subnet.id : '';
      }
      yield put(creators.selectSubnet(subnetId));
    }
  }
  /** 判断当前用户在当前地域支持的网络类型，有的地域只支持VPC，这时任何用户都为默认VPC用户 */
  async isDefaultVpc(regionId: number) {
    const { AccountAttributeSet } = await DescribeAccountAttributes(regionId);
    const platforms = AccountAttributeSet.find(
      o => o.AttributeName === 'supported-platforms'
    );
    return platforms.AttributeValues.join(',') === 'VPC';
  }
  async checkDefaultSubnet(regionId, vpcId, zoneV3Id) {
    try {
      // 用 DescribeSubnets 替代，这里zoneId无解
      const result = await vpc.DescribeSubnets(regionId, {
        Filters: [
          {
            Name: 'vpc-id',
            Values: [vpcId]
          },
          {
            Name: 'zone',
            Values: [zoneV3Id]
          },
          {
            Name: 'is-default',
            Values: ['true']
          }
        ]
      });
      return result.TotalCount > 0;
    } catch (e) {
      // 出错了前台就不校验了
      return true;
    }
  }
  /** 当没有选中vpc时，默认选中哪个VPC，如果返回空则表示不默认选中 */
  getOneVpc(vpcs: Vpc[]): Vpc {
    return vpcs[0];
  }
  /** 当没有选中子网时，默认选中哪个子网，如果返回空则表示不默认选中 */
  getOneSubnet(subnets: Subnet[]): Subnet {
    return subnets[0];
  }
  /**
   * 供与Route组合时使用
   * @param history
   */
  getRouteParams(history = true): PageParam<string>[] {
    const {
      types,
      selector,
      selectors,
      creators,
      ducks: { vpc, subnet }
    } = this;
    return [
      {
        key: 'vpcId',
        defaults: '',
        history,
        type: types.SELECT_VPC,
        selector: g => selector(g).vpcId
      },
      {
        key: 'subnetId',
        defaults: '',
        history,
        type: types.SELECT_SUBNET,
        selector: g => selector(g).subnetId
      }
    ];
  }
  /** 供校验用，传入当前Duck state */
  validate(state, opts?: {needIpCount?: number}): ValidateResult {
    const {
      vpcId,
      vpc: { data: vpcList },
      subnetId,
      subnet: { data: subnetList },
      supportDefaultVpc,
      supportOldVpc,
      isVpcOnly,
      supportSubnet,
      canAddDefaultSubnet
    } = asResult(this.selector, state);
    const invalids: ValidateResult = {};
    // 需要选择vpcId
    // 如果为默认VPC用户，则vpcId可以为空，代表自动创建
    if (!vpcId && !(supportDefaultVpc && isVpcOnly)) {
      invalids.vpc = t('请选择私有网络');
    }
    // 当需要选子网时，subnetId不能为空
    // 如果为默认VPC用户，可创建默认子网
    const vpc = vpcList && vpcList.find(o => o.id === vpcId);
    // 切v3了，应该没有这种古老的vpc了吧
    // if (!supportOldVpc && vpc.numId <= 65535) {
    //   invalids.vpc = '不支持低版本私有网络'
    // }
    if (supportSubnet) {
      if(!state.subnetId){
        if(!(
          supportDefaultVpc &&
          isVpcOnly &&
          (!vpcId || (vpc && vpc.isDefault)) &&
          canAddDefaultSubnet
        )){
          invalids.subnet = t('请选择子网');
        }
      }else{
        if(opts?.needIpCount > 0){
          const subnet = subnetList && subnetList.find(o => o.id === subnetId)
          if(subnet?.availableIPNum < opts?.needIpCount){
            invalids.subnet = t('当前所选子网可用IP不足')
          }
        }
      }
    }
    if (supportDefaultVpc && isVpcOnly && !subnetId && !canAddDefaultSubnet) {
      invalids.addDefaultSubnet = t(
        '该私有网络内无 /20 网段可用，无法创建默认子网。'
      );
    }
    return invalids;
  }
}
