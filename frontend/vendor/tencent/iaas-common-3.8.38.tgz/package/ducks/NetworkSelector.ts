// 网络选择器，选择VPC及子网 TODO 这里似乎有点不好复用？
import { DuckMap as Base, reduceFromPayload } from 'saga-duck'
import { select, put, call, take, fork } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga-catch'
import FetcherDuck from '../ducks/Fetcher'
import { t, Trans } from '@tencent/tea-app/lib/i18n'
import * as vpc from '../models/vpc'
import pagingFetch from '../helpers/pagingFetch'

interface Vpc {
  id: string
  // v3接口没有数字id了
  // numId: number
  name: string
  cidr: string
}
interface Subnet {
  id: string
  // numId: number
  name: string
  cidr: string
  totalIPNum: number
  availableIPNum: number
}

enum Types {
  FETCH,
  RELOAD,
  SELECT_VPC,
  SELECT_SUBNET,
  SET_LOADING
}

export default class Duck extends Base {
  get quickTypes() {
    return {
      ...super.quickTypes,
      ...Types
    }
  }
  get reducers() {
    const { types } = this
    return {
      ...super.reducers,
      regionId: (state = null, action): number => {
        switch (action.type) {
          case types.FETCH:
            return action.payload.regionId
          default:
            return state
        }
      },
      zoneId: (state = null, action): number => {
        switch (action.type) {
          case types.FETCH:
            return action.payload.zoneId
          default:
            return state
        }
      },
      vpcId: reduceFromPayload<string>(types.SELECT_VPC, null),
      subnetId: reduceFromPayload<string>(types.SELECT_SUBNET, null),
      loading: reduceFromPayload<boolean>(types.SET_LOADING, false)
    }
  }
  get creators() {
    const { types } = this
    return {
      ...super.creators,
      fetch: (regionId: number, zoneId?: number) => ({
        type: types.FETCH,
        payload: {
          regionId,
          zoneId
        }
      }),
      reload: () => ({ type: types.RELOAD }),
      selectVpc: (vpcId: string) => ({
        type: types.SELECT_VPC,
        payload: vpcId
      }),
      selectSubnet: (subnetId: string) => ({
        type: types.SELECT_SUBNET,
        payload: subnetId
      }),
      setLoading: (loading: boolean) => ({
        type: types.SET_LOADING,
        payload: loading
      })
    }
  }
  get rawSelectors() {
    type State = this['State']
    return {
      ...super.rawSelectors,
      regionId: (state: State) => state.regionId,
      zoneId: (state: State) => state.zoneId,
      vpcId: (state: State) => state.vpcId,
      subnetId: (state: State) => state.subnetId,
      isValid: (state: State) => !!(state.vpcId && state.subnetId)
    }
  }
  get quickDucks() {
    return {
      ...super.quickDucks,
      vpc: VpcFetcher,
      subnet: SubnetFetcher
    }
  }
  *saga() {
    yield* super.saga()
    yield fork([this, this.sagaNetworkSelectorMain])
  }
  *sagaNetworkSelectorMain(duck = this) {
    const {
      types,
      creators,
      selectors,
      ducks: { vpc, subnet }
    } = duck
    // 初始加载及刷新
    yield takeLatest(types.FETCH, function*() {
      const regionId = yield select(selectors.regionId)
      const zoneId = yield select(selectors.zoneId)
      do {
        yield put(creators.setLoading(true))
        // 先清空数据
        yield put(vpc.creators.reset())
        yield put(subnet.creators.reset())
        // 加载VPC
        const vpcs: Vpc[] = yield vpc.fetch({ regionId })
        let vpcId = yield select(selectors.vpcId)
        const vpcFound = vpcs.some(vpc => vpc.id === vpcId)
        if (!vpcFound) {
          vpcId = (vpcs[0] && vpcs[0].id) || null
          yield put(creators.selectVpc(vpcId))
        }

        yield fork(function*() {
          do {
            yield put(creators.setLoading(true))
            const vpcId = yield select(selectors.vpcId)
            // 如果没有可用项，子网不用加载了
            if (!vpcId) {
              continue
            }
            // 加载子网
            const subnets: Subnet[] = yield subnet.fetch({
              regionId,
              zoneId,
              vpcId
            })
            // 加载完后保证选中一项
            let subnetId = yield select(selectors.subnetId)
            const subnetFound = subnets.some(subnet => subnet.id === subnetId)
            if (!subnetFound) {
              subnetId = (subnets[0] && subnets[0].id) || null
              yield put(creators.selectSubnet(subnetId))
            }
            yield put(creators.setLoading(false))
          } while (yield take(types.SELECT_VPC))
        })
      } while (yield take(types.RELOAD))
    })
  }
}

interface VpcParam {
  regionId: number
}
class VpcFetcher extends FetcherDuck {
  Param: VpcParam
  Data: Vpc[]
  protected async getDataAsync(params: VpcParam) {
    const list = await pagingFetch(
      async (offset, limit) => {
        const result = await vpc.DescribeVpcs(params.regionId, {
          Offset: String(offset),
          Limit: String(limit)
        })
        return {
          totalCount: result.TotalCount,
          list: result.VpcSet
        }
      },
      {
        maxLimit: 200
      }
    )

    if (!list) {
      throw t('没有可用的私有网络')
    }
    return list.map(o => ({
      id: o.VpcId,
      name: o.VpcName,
      cidr: o.CidrBlock
    }))
  }
}

interface SubnetParam {
  regionId: number
  vpcId: string
  zoneId: number
}
class SubnetFetcher extends FetcherDuck {
  Param: SubnetParam
  Data: Subnet[]
  protected async getDataAsync(params: SubnetParam) {
    const filters: vpc.DescribeSubnetsParams['Filters'] = [
      {
        Name: 'vpc-id',
        Values: [params.vpcId]
      }
    ]
    if (params.zoneId) {
      filters.push({
        Name: 'zone',
        Values: [getV3ZoneId(params.zoneId)]
      })
    }
    const list = await pagingFetch(
      async (offset, limit) => {
        const result = await vpc.DescribeSubnets(params.regionId, {
          Offset: String(offset),
          Limit: String(limit),
          Filters: filters
        })
        return {
          totalCount: result.TotalCount,
          list: result.SubnetSet
        }
      },
      {
        maxLimit: 200
      }
    )

    if (!list) {
      throw t('没有可用的子网')
    }
    return list.map<Subnet>(o => ({
      id: o.SubnetId,
      name: o.SubnetName,
      cidr: o.CidrBlock,
      totalIPNum: o.TotalIpAddressCount,
      availableIPNum: o.AvailableIpAddressCount
    }))
  }
}

/** 100001 => ap-guangzhou-1 */
function getV3ZoneId(id: string | number): string {
  const zoneV3NameMap = seajs.require('constants')?.ZONEIDMAP || {}
  return zoneV3NameMap[id] || String(id)
}
