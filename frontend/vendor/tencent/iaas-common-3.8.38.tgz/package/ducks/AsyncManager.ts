import FetcherDuck from './Fetcher';
import { resolvePromise } from 'saga-duck/build/helper';

type SAGA<T = boolean> = () => Generator<any, T, any> | Promise<T>;
/** 
 * 用于管理一段saga/async执行的Loading态
 */
export default class AsyncManager<T = boolean> extends FetcherDuck {
  Param: {
    saga: SAGA<T>;
  };
  Data: T;
  get deferLoading() {
    return 10;
  }
  *getData({ saga }: this['Param']) {
    let result = true as unknown as T;
    if (saga) {
      const it = saga();
      if ('next' in it) {
        result = yield* it;
      } else {
        result = yield* resolvePromise(it);
      }
    }
    return result ?? (true as unknown as T);
  }
}
