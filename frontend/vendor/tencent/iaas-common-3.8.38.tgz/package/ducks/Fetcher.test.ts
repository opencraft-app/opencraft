import { delay } from 'redux-saga-catch'
import { fork, join, cancel, select, takeEvery, spawn } from 'redux-saga/effects'
import Fetcher from './Fetcher'
import runDuck from './__test__/runDuck'

const getDataCost = 100
// 有时用例执行比较慢，多做点时间容错
const executeTolerance = 5
class BaseTest extends Fetcher {
  Param: any
  Data: any
  async getDataAsync() {
    await delay(getDataCost)
    return null
  }
}

describe('Fetcher出错逻辑', () => {
  it('getData同步出错时，转为error状态', cb => {
    const error = Math.random()
    class Test extends BaseTest {
      async getDataAsync() {
        throw error
      }
    }
    runDuck(new Test(), function* (runtime) {
      const duck = runtime.duck as Test

      try{
        yield* duck.fetch(null)
      }catch(e){}
      expect(duck.selector(yield select()).loading).toBe(false)
      expect(duck.selector(yield select()).error).toStrictEqual(error)

      cb()
    })
  })

  it('getData异步出错时，转为error状态', cb => {
    const error = Math.random()
    class Test extends BaseTest {
      async getDataAsync() {
        await delay(getDataCost)
        throw error
      }
    }
    runDuck(new Test(), function* (runtime) {
      const duck = runtime.duck as Test

      try{
        yield* duck.fetch(null)
      }catch(e){}
      expect(duck.selector(yield select()).loading).toBe(false)
      expect(duck.selector(yield select()).error).toStrictEqual(error)

      cb()
    })
  })
/*
  it('debug出错前join', cb => {
    runDuck(new BaseTest(), function* () {
      let catched = false
      let task
      try {
        task = yield spawn(function* () {
          yield delay(1000)
          console.log('出错前 oops------------------')
          throw 'oops'
        })
        yield delay(500)
        console.log('出错前 join------------------')
        yield join(task)
      } catch (e) {
        console.log('出错前 catched------------------')
        catched = true
      } finally {
        console.log('出错前 finally------------------', task.error())
        // expect(catched).toBe(true)
        cb()
      }
    })
  })

  it('debug出错后join', cb => {
    runDuck(new BaseTest(), function* () {
      let catched = false
      let task
      try {
        task = yield spawn(function* () {
          yield delay(500)
          console.log('出错后 oops------------------')
          throw 'oops'
        })
        yield delay(1000)
        console.log('出错后 join------------------')
        yield join(task)
      } catch (e) {
        console.log('出错后 catched------------------')
        catched = true
      } finally {
        console.log('出错后 finally------------------', task.error())
        // expect(catched).toBe(true)
        cb()
      }
    })
  })
  it('debug同步join', cb => {
    runDuck(new BaseTest(), function* () {
      let catched = false
      let task
      try {
        task = yield spawn(function* () {
          console.log('同步 oops------------------')
          throw 'oops'
        })
        console.log('同步 join------------------')
        yield join(task)
      } catch (e) {
        console.log('同步 catched------------------')
        catched = true
      } finally {
        console.log('同步 finally------------------', task.error())
        // expect(catched).toBe(true)
        cb()
      }
    })
  })*/
})

describe('Fetcher deferLoading逻辑', () => {
  it('未开启时，fetch即转为loading', cb => {
    runDuck(new BaseTest(), function* (runtime) {
      const duck = runtime.duck as BaseTest

      const task = yield fork({ fn: duck.fetch, context: duck }, null)
      yield delay(0)
      expect(duck.selector(yield select()).loading).toBe(true)

      // 加载完后转为false
      yield join(task)
      expect(duck.selector(yield select()).loading).toBe(false)

      cb()
    })
  })
  it('开启时，fetch后等待deferLoading后才转为loading', cb => {
    const deferLoading = 20
    class Test extends BaseTest {
      get deferLoading() {
        return deferLoading
      }
    }
    runDuck(new Test(), function* (runtime) {
      const duck = runtime.duck as Test

      const task = yield fork({ fn: duck.fetch, context: duck }, null)
      yield delay(0)
      expect(duck.selector(yield select()).loading).toBe(false)
      yield delay(duck.buffer + deferLoading + executeTolerance)
      expect(duck.selector(yield select()).loading).toBe(true)

      // 加载完后转为false
      yield join(task)
      expect(duck.selector(yield select()).loading).toBe(false)

      cb()
    })
  })
  it('开启时，如果deferLoading大于加载时间，则永远不会有loading状态', cb => {
    class Test extends BaseTest {
      get deferLoading() {
        return getDataCost + executeTolerance
      }
    }
    runDuck(new Test(), function* (runtime) {
      const duck = runtime.duck as Test

      yield takeEvery(
        [duck.types.FETCH_START, duck.types.SET_LOADING, duck.types.FETCH_DONE],
        function* (action) {
          expect(duck.selector(yield select()).loading).toBe(false)
        }
      )

      yield* duck.fetch(null)

      cb()
    })
  })
})
