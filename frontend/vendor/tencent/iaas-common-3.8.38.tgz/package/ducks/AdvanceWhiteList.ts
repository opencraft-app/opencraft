/**
 * 高级白名单功能，包含地域灰度功能，只支持单个白名单查询（多个查询底层会进行合并缓存）
 *
 * state可能有以下值
 * null 查询未完成，未知白名单状态
 * {user:true, regions: [1,4]} 在白名单内，可以访问
 * {user:false, regions: [1,4,7]} 不在白名单，需要展示内测申请页
 * 
 * 支持简单的调试，例如临时开启某个地域灰度：
```javascript
devmode.enter() // 仅在开发模式下生效
sessionStorage.DEBUG_WHITELISTS = JSON.stringify({'CKAFKA_REGIONS': ['REGION-36']})
```
 */
import useRegionMaps from '../helpers/useRegionMaps'
import { put, call, select, CallEffect } from 'redux-saga/effects'
import { BaseDuck, reduceFromPayload } from 'saga-duck'
import { GetGreyInfoResult, cacheGetGreyInfo, GetWhiteListOpt } from '../model'
export enum RegionFormat {
  RegionNumber = 'REGION-number',
  RegionIntlNumber = 'REGION-INTL-number',
  Number = 'number',
  RegionId = 'regionId'
}

type State = GetGreyInfoResult
enum Types {
  DONE
}
export default abstract class WhiteListDuck extends BaseDuck {
  get quickTypes() {
    return Types
  }
  get reducer() {
    return reduceFromPayload<State>(this.types.DONE, null)
  }
  *saga() {
    yield* super.saga()
    yield this.ready()
  }
  /**
   * 等待白名单加载完成再继续
   * @return {SagaEffect<whiteListMap>}
   */
  ready(): CallEffect {
    return call(this.waitReady, this)
  }
  *waitReady(duck: this) {
    const { types, selector, whiteKey, regionFormat } = duck
    let info = selector(yield select())
    if (!info) {
      if (!duck.supported) {
        const regions = []
        const regionSet = new Set<number>()
        info = {
          whiteKey: duck.whiteKey,
          user: false,
          regions,
          regionSet
        } as this['State']
      } else if (duck.fullfill) {
        const regions = []
        const regionSet = new Set<number>()

        const { idToName } = useRegionMaps()
        Object.keys(idToName).forEach(x => {
          const regionId = parseInt(x, 10)
          regions.push(regionId)
          regionSet.add(regionId)
        })
        info = {
          whiteKey: duck.whiteKey,
          user: true,
          regions,
          regionSet
        } as this['State']
      } else {
        info = yield cacheGetGreyInfo(whiteKey, regionFormat)
      }
      yield* duck.processInfo(info)
      yield put({ type: types.DONE, payload: info })
    }
    return info
  }
  /** 供某些情况下修改白名单信息（例如测试/预发环境上新区验证） */
  *processInfo(info: GetGreyInfoResult) { }
  /**
   * 要加载的白名单列表
   * @private
   */
  abstract get whiteKey(): string
  /**
   * 指定地域白名单的查询值（regionId的格式化方式)，返回值使用RegionFormat枚举值
   */
  get regionFormat(): GetWhiteListOpt['regionFormat'] {
    return RegionFormat.RegionNumber as GetWhiteListOpt['regionFormat']
  }
  /**
   * 配置为false则全面禁用此白名单（任何用户、地域都不在名单内）
   * 此配置优先于fullfill
   */
  get supported(): boolean {
    return true
  }
  /**
   * 如果白名单全量了，可以简单配置为true来停用
   */
  get fullfill(): boolean {
    return false
  }
}

// 测试/示例代码
if (process.env.NEVER_RUN) {
  class Test extends WhiteListDuck {
    get whiteKey() {
      return ''
    }
  }
  const foo = new Test()
  foo.selector(null).regionSet
}
