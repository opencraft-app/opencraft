import { once } from "../../../helpers/cacheable";
import { buffers, eventChannel } from "redux-saga";
import { HistoryAdapter } from "../types";


const getNmcRouter = once(function () {
  return seajs.require('router')
})

export function getFragment() {
  const debug = getNmcRouter().debug || ''
  const debugReg = new RegExp('^' + debug.replace('/', '\\/'))
  return getNmcRouter().getFragment().replace(debugReg, '')
}


export default class NmcAdapter extends HistoryAdapter {
  constructor(protected path: string) {
    super()
  }
  /**
   * 监听URL变化
   * @param param
   */
  watch() {
    return eventChannel<string>(emitter => {
      emitter(getFragment())
      getNmcRouter().use(this.path, () => {
        const fragment = getFragment()
        emitter(fragment)
      })
      return () => {
        getNmcRouter().unuse(this.path)
      }
    }, buffers.sliding(1))
  }
  /**
   * 实施URL变化
   */
  perform(url: string, replace: boolean) {
    // 平台的router.navigate会同步触发，导致React立即重绘，可能会触发React告警（在render的过程中setState）
    setTimeout(() => {
      getNmcRouter().navigate(url, undefined, replace)
    }, 0)
  }
}