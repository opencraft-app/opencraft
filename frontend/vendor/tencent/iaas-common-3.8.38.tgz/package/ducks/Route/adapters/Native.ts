import { buffers, eventChannel } from "redux-saga";
import { HistoryAdapter } from "../types";

/**
 * 路由功能
 * 
 * 原生history
 * 
 * 其实这里有一个问题，如果是由其它地方进行的history.pushState/replaceState进行的url更新，这里监听不到
 * 
 * 为了解决这个问题，这里约定额外尝试使用document上的自定义事件 NativeAdapter.CustomEvent
 */
 export default class NativeAdapter extends HistoryAdapter {
  static get CustomEvent(){
    return '_locationchanged'
  }
   /**
    * 监听URL变化
    * @param param
    */
   watch() {
     return eventChannel<string>((emitter) => {
       const handler = () => {
         emitter(window.location.search);
       };
       if (window.history && history.pushState && window.addEventListener) {
         window.addEventListener('popstate', handler);
       }
       if(window.document && document.addEventListener){
        document.addEventListener(NativeAdapter.CustomEvent, handler)
       }
       emitter(window.location.search);
 
       return () => {
         window?.removeEventListener('popstate', handler);
         document?.removeEventListener(NativeAdapter.CustomEvent, handler)
       };
     }, buffers.sliding(1));
   }
   /**
    * 实施URL变化
    */
   perform(url: string, replace: boolean) {
     if (window.history && history.pushState) {
       // 如果完全一样，可能是popState，这时应该什么操作都不做
       if (url === document.location.pathname + document.location.search) {
         return;
       }
       if (replace) {
         history.replaceState(null, document.title, url);
       } else {
         history.pushState(null, document.title, url);
       }
     }
   }
 }
 