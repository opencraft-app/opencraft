/**
 * 路由功能实现，提供 url <-> paramsObject 的双向同步功能
 */
import { BaseDuck, INIT, END, DuckOptions } from 'saga-duck'
import { take, put, fork, select, call } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga-catch'
import { Channel } from 'redux-saga'
import { HistoryAdapter, Param } from './types'
import QSParser from './parsers/Querystring'
import { cacheable } from '../../helpers/cacheable'
import NmcAdapter from './adapters/Nmc'
import NativeAdapter from './adapters/Native'
export { Param }

enum Types {
  UPDATE,
  SET,
  CHANGE,
  READY
}
interface Options extends DuckOptions {
  /** url参数定义 */
  params?: any[]
  /** 基本路由 */
  baseUrl?: string
}
export default class RouteDuck extends BaseDuck {
  private parser: QSParser
  protected initialState: any
  constructor(protected options: Options) {
    super(...arguments)
    // 提供延后初始化的能力，防止别人没有初始化完时，params计算会死循环（死锁）的问题
    const params = this.options.params
    if (params && params.length) {
      this.setParams(params)
    }
  }
  @cacheable
  get adaptor(): HistoryAdapter {
    return new NmcAdapter(this.options.baseUrl)
  }
  get quickTypes() {
    return {
      ...super.quickTypes,
      ...Types
    }
  }
  get reducer() {
    const { types, parser } = this
    return (state = {}, action): any => {
      switch (action.type) {
        case types.UPDATE:
          return {
            ...state,
            ...parser.formula(action.payload)
          }
        case types.SET:
          return parser.formula(action.payload)
        default:
          return state
      }
    }
  }
  get params(): Param[] {
    return this.options.params || []
  }
  get creators() {
    const { types, parser } = this
    return {
      ...super.creators,
      /** 用于业务主动更新route，属于增量更新 */
      update: routes => ({
        type: types.UPDATE,
        payload: routes
      }),
      /** 用于nmc跳转响应，属于全量更新 */
      set: routes => ({
        type: types.SET,
        payload: parser.formula(routes)
      })
    }
  }
  *saga() {
    yield* super.saga()
    yield fork([this, this.sagaFromRouteWatch])
    yield fork([this, this.sagaToRouteWatch])
  }
  // 监听路由 nmcRouter => RouteDuck
  *sagaFromRouteWatch(duck = this) {
    const { options, creators, adaptor } = duck
    // 如果没有定义baseUrl，不启用
    if (!options.baseUrl) {
      return
    }
    // yield take(INIT);
    const chan: Channel<string> = yield adaptor.watch()
    yield fork(function* () {
      try {
        while (1) {
          // TODO 要判断是不是router自己设置的 --- 好像一样无解，只能判断相同时不触发联动来规避
          const url = yield take(chan)
          if (duck.parser) {
            const routes = duck.parser.parse(url)
            yield put(creators.set(routes))
          }
        }
      } finally {
        chan.close()
      }
    })
    //
    yield take(END)
    chan.close()
  }
  // 当路由变化时，通过action通知外界，同时尝试更新router
  // RouteDuck => CHANGED action & nmcRouter
  *sagaToRouteWatch(duck = this) {
    const { types, selector, options, parser, adaptor } = duck
    // 如果没有定义baseUrl，不启用
    if (!options.baseUrl) {
      return
    }
    // 第一次强制更新
    let lastRoutes = {} //yield select(selector)
    let initialReplace = true
    yield takeLatest([INIT, types.SET, types.UPDATE], function* (action) {
      // yield delay(100)
      if (!duck.parser) {
        return
      }
      const curRoutes = yield select(selector)
      const changes = {}
      // 原有属性有变更的（删、改）
      Object.keys(lastRoutes).forEach(key => {
        const value = curRoutes[key]
        if (
          value !== lastRoutes[key] &&
          // NaN、数组或对象的对比会有问题，进行更深的判断
          JSON.stringify(value) !== JSON.stringify(lastRoutes[key])
        ) {
          changes[key] = value
        }
      })
      // 新增的属性
      Object.keys(curRoutes)
        .filter(key => !(key in lastRoutes))
        .forEach(key => {
          changes[key] = curRoutes[key]
        })
      // 如果有变动，则更新之
      if (Object.keys(changes).length > 0) {
        // 如果是业务逻辑自己局部更新的，不触发change？
        if (action.type !== types.UPDATE) {
          yield put({
            type: types.CHANGE,
            payload: curRoutes,
            changes
          })
        }

        // 同时更新url
        yield call({
          context: adaptor,
          fn: adaptor.perform
        }, options.baseUrl + parser.stringify(curRoutes), initialReplace || duck.parser.shouldReplace(lastRoutes, curRoutes))
      }

      lastRoutes = curRoutes
      initialReplace = false
    })
  }
  setParams(params: Param[]): void {
    this.parser = new QSParser(params)
    const initialState = {}
    this.parser.params.forEach(({ key, defaults }) => {
      initialState[key] = defaults()
    })
    this.initialState = initialState
  }
}

export class NativeRoute extends RouteDuck {
  get adaptor(): HistoryAdapter {
    return new NativeAdapter()
  }
}