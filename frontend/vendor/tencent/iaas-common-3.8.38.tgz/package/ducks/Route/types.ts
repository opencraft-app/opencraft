import { END } from "redux-saga"

// redux-saga 0.x & 1.x 兼容
export interface Channel<T = any> {
  /**
   * Used to register a taker. The take is resolved using the following rules
   *
   * - If the channel has buffered messages, then `callback` will be invoked
   *   with the next message from the underlying buffer (using `buffer.take()`)
   * - If the channel is closed and there are no buffered messages, then
   *   `callback` is invoked with `END`
   * - Otherwise`callback` will be queued until a message is put into the
   *   channel
   */
  take(cb: (message: T | END) => void): void
  /**
   * Used to extract all buffered messages from the channel. The flush is
   * resolved using the following rules
   *
   * - If the channel is closed and there are no buffered messages, then
   *   `callback` is invoked with `END`
   * - Otherwise `callback` is invoked with all buffered messages.
   */
  flush(cb: (items: T[] | END) => void): void
  /**
   * Closes the channel which means no more puts will be allowed. All pending
   * takers will be invoked with `END`.
   */
  close(): void
}

export type GETTER<T> = () => T
export type OPT<T> = T | GETTER<T>
export interface Param<T = any> {
  /** 对应路由数据对象中的属性 */
  key: string
  /** 对应URL中的参数名，不传则与key相同 */
  route?: string
  /** 在URL中的排序，越小越靠前 */
  order?: number
  /** 是否需要生成新的历史访问记录（即pushState与replaceState的区别），默认不生成 */
  history?: boolean
  /** 默认值，当URL中不存在此参数时即为默认值 */
  defaults?: OPT<T>
  /** 当与默认值相等时是否展示，默认为false */
  alwaysVisible?: boolean
  /** 解析函数，url串到最终属性 */
  parse?: (value: string) => T
  /** 序列化函数，属性到url串 */
  stringify?: (value: T) => string
}

export abstract class HistoryAdapter {
  abstract watch(): Channel<string>
  abstract perform(url: string, replace?: boolean, state?: any)
}