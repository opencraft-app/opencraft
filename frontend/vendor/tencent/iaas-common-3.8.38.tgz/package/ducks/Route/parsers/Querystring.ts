import * as deepEqual from 'fast-deep-equal'
import { Param } from "../types"

export default class QSParser {
  params: Param[]
  constructor(params: Param[]) {
    // 统一化params
    this.params = params
      .map(param => {
        return {
          order: param.order || 0,
          key: param.key,
          route: param.route || param.key,
          history: param.history === true,
          defaults:
            typeof param.defaults === 'function'
              ? param.defaults
              : () => param.defaults,
          alwaysVisible: param.alwaysVisible,
          parse: param.parse || (v => v),
          stringify: param.stringify || (v => '' + v)
        }
      })
      .sort((a, b) => a.order - b.order)
  }
  /**
   * 对值进行标准化，主要做以下行为：
   *   1. 未定义的值移除
   *   2. 如果值是原始的（即直接从url中获取的），则进行解析 -- deprecated 这步应该是无必要的
   * @param values
   */
  formula(values) {
    const o = {}
    this.params.forEach(({ key, parse }) => {
      let value
      if (key in values) {
        value = values[key]
        // if (typeof value === 'string') {
        //   try {
        //     value = parse(values[key])
        //   } catch (e) {}
        // }
        o[key] = value
      }
    })
    return o
  }
  /**
   * 将url解析为routes
   * @param {*} url
   */
  parse(url) {
    const qs = url.split('?')[1] || ''
    const values = {}
    qs.split('&').forEach(kv => {
      const [k, v] = kv.split('=')
      values[decodeURIComponent(k)] = decodeURIComponent(v)
    })
    const routes = {}

    this.params.forEach(({ key, route, parse, defaults }) => {
      let value
      if (route in values) {
        value = parse(values[route])
      } else {
        value = defaults()
        // 保持历史兼容
        if (typeof value === 'string') {
          try {
            value = parse(value)
          } catch { }
        }
      }
      routes[key] = value
    })

    return routes
  }
  /**
   * 将routes对象转换为url
   * @param {*} routes
   */
  stringify(routes) {
    const qs = this.params
      .map(({ key, route, stringify, defaults, alwaysVisible }) => {
        const value = routes[key]
        if (
          value === undefined ||
          (deepEqual(value, defaults()) && !alwaysVisible)
        ) {
          return
        }
        return (
          encodeURIComponent(route) + '=' + encodeURIComponent(stringify(value))
        )
      })
      .filter(v => v)
      .join('&')

    return qs ? '?' + qs : ''
  }
  /**
   * 判断routes改后，是否只需要replace（即只替换，不生成新的历史记录）
   * @param {*} a
   * @param {*} b
   */
  shouldReplace(a, b) {
    return !this.params.some(({ key, history }) => {
      if (a[key] === b[key]) {
        return
      }
      if (history) {
        return true
      }
    })
  }
}