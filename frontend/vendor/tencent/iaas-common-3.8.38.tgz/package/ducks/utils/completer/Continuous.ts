import { Completer } from './Base'
import { delay } from 'redux-saga-catch'
import { waitBodyVisible } from '../../../helpers/showDialog'
import { combineWaitSagas } from '../../../helpers/wait'

/**
 * 持续轮询刷新
 */
export default abstract class ContinuousCompleter<
  TItem,
  TExtra,
  TFilter = any
> extends Completer<TItem, TExtra, TFilter> {
  /** 记录最近多少次的请求结果，与 `stopErrorRate` 配合使用，默认 10 */
  get monitorRecentCount() {
    return 10
  }
  /** 当最近 `monitorRecentCount` 次请求中，错误率超过多少时自动停止轮询，默认 0.5 */
  get stopErrorRate() {
    return 0.5
  }
  /** 轮询间隔，单位 ms ，默认30000ms */
  get interval() {
    return 30000
  }
  /** 是否启用首次刷新，即初始执行一次 `doUpdate` 后再开始轮询，默认为false */
  get initialUpdate() {
    return false
  }
  /**
   * 如果需要暂停轮询（例如不在当前Tab），则可以实现此方法进行轮询阻塞
   * 
   * 如果当前条件满足，返回true；否则等待条件满足后，返回false
   */
  *wait(): IterableIterator<any> {
    return true
  }
  *onFetched(): IterableIterator<any> {
    // 首次刷新
    if (this.initialUpdate) {
      yield* this.doUpdate()
    }
    // 后续轮询
    // 错误率过高时自动停止
    const mon = monitorErrorRate(this.monitorRecentCount)
    while (true) {
      yield delay(this.interval)
      yield combineWaitSagas([this.wait.bind(this), waitBodyVisible])

      try {
        const result = yield* this.doUpdate()
        if (result === false) {
          return
        }
        mon.success()
      } catch (e) {
        console.error(e)
        mon.error()
      }
      if (mon.getErrorRate() > this.stopErrorRate) {
        break
      }
    }
  }
  /**
   * 单次更新操作，如果throw表示本次更新出错，如果返回false，表示停止持续更新。
   */
  protected abstract doUpdate(): IterableIterator<any>
}

/**
 * 计算最近N次请求的错误率
 * @param recentCount 最近N次
 */
function monitorErrorRate(recentCount: number) {
  let recents: boolean[] = []
  function rec(v: boolean) {
    recents.push(v)
    if (recents.length > recentCount) {
      recents = recents.slice(recents.length - recentCount)
    }
  }
  return {
    success() {
      rec(true)
    },
    error() {
      rec(false)
    },
    getErrorRate() {
      return recents.filter(x => x === false).length / recents.length
    }
  }
}
