import { runSaga } from 'redux-saga'
import { delay } from 'redux-saga-catch'
import { all, call } from 'redux-saga/effects'
import { getBufferUpdate } from './getBufferUpdate'

describe('Completer-buffer', () => {
  it('buffer 为 0，同步执行', cb => {
    const list = [{ a: 'sds' }, { b: 'klsdf' }]
    let updated = false
    function* update<T>(v: T[]) {
      expect(v).toStrictEqual(list)
      expect(updated).toBe(false) // 只能执行一次
      updated = true
    }
    runSaga({}, function*() {
      const bufferUpdate = getBufferUpdate(update, 0)
      yield* bufferUpdate(list)
      expect(updated).toBe(true)
      cb()
    })
  })

  it('buffer期间内，合并更新', cb => {
    const list1 = [{ a: 'sds' }, { a: 'kjdrg' }]
    const list2 = [, { b: 'lkjasdf' }]
    let updateTimes = 0
    function* update<T>(v: T[]) {
      updateTimes++
      expect(v).toStrictEqual([{ a: 'sds' }, { a: 'kjdrg', b: 'lkjasdf' }])
    }
    runSaga({}, function*() {
      const bufferUpdate = getBufferUpdate(update, 100)
      yield all([
        call(function*() {
          yield* bufferUpdate(list1)
        }),
        call(function*() {
          yield delay(10)
          yield* bufferUpdate(list2)
        })
      ])
      expect(updateTimes).toBe(1)
      cb()
    })
  })
})
