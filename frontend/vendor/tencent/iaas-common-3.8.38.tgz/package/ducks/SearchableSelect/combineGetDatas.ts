/**
 * 组合多个数据源的请求
 */
import { ListResult } from '../AbstractSearchableList'
import { SearchParam } from '../SearchableList'
export interface DataSource<TParam, TItem> {
  (param: TParam & SearchParam): Promise<ListResult<TItem>>
}

export default function combineGetDatas<TParam, TItem>(sources: DataSource<TParam, TItem>[]): (param: TParam & SearchParam) => Promise<ListResult<TItem>> {
  return async function getData(param: TParam & SearchParam): Promise<ListResult<TItem>> {
    // 多数据源的列表加载规则，先获取除总数量，再来映射到不同数据源的offset
    const counts = await Promise.all(sources.map(async getData => {
      const { totalCount } = await getData({
        ...param,
        offset: 0
      })
      return totalCount
    }))
    // 计算当前offset落在哪个数据源上
    let curSource: DataSource<TParam, TItem>
    let curOffset = param.offset
    for (const [index, source] of sources.entries()) {
      curSource = source
      const count = counts[index] || Number.MAX_SAFE_INTEGER
      // 超出当前数据源范围，下一个
      if (curOffset >= count) {
        curOffset -= count
        continue
      }
      // 当前数据源范围，直接请求加载
      break
    }
    const { list } = await curSource({
      ...param,
      offset: curOffset,
    })
    const totalCount = counts.reduce((sum, v) => sum + v, 0)
    // 如果列表不满足limit，尝试继续
    if (param.offset + list.length < totalCount) {
      const { list: moreList } = await getData({
        ...param,
        offset: param.offset + list.length,
      })
      return {
        list: list.concat(moreList),
        totalCount
      }
    }
    return {
      list,
      totalCount
    }
  }
}