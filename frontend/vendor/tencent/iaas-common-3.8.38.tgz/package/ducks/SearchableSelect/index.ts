/**
 * 可搜索单选（AsyncSelect进阶版）
 * 1. 可搜索（也可关闭此功能）
 * 2. 可分页加载更多
 *
 * 一些优化：
 * 1. 不再需要用户定义Fetcher，简化使用
 * 2. 不再有同步(syncList)的过程，Fetcher将作为一个工具使用
 */

import Base from '../SearchableList'
export { SearchParam } from '../SearchableList'
import { createToPayload, reduceFromPayload } from 'saga-duck'

export default abstract class SearchableSelect extends Base {
  ID: string
  abstract getId(o: this['Item']): this['ID']
  get quickTypes() {
    enum Types {
      SELECT
    }
    return {
      ...super.quickTypes,
      ...Types
    }
  }
  get reducers() {
    const { types } = this
    return {
      ...super.reducers,
      id: reduceFromPayload(types.SELECT, this.defaultId)
    }
  }
  get rawSelectors() {
    type State = this['State']
    return {
      ...super.rawSelectors,
      selected: (state: State) => this.find(state.list, state.id)
    }
  }
  get creators() {
    const { types } = this
    type TID = this['ID']
    return {
      ...super.creators,
      select: createToPayload<TID | null>(types.SELECT)
    }
  }
  protected find(list: this['Item'][] | null, id: this['ID'] | null): this['Item'] {
    return (list || []).find(item => this.getId(item) === id) || null
  }
  /** 默认值 */
  get defaultId(): this['ID'] | null {
    return null
  }
}
