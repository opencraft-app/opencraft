尝试一种更灵活的SearchableSelect使用方案，基于hook

useSelector().load(param).resetOnChange('')