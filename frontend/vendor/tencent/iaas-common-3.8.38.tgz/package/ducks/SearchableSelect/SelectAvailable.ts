import { put, select, take } from 'redux-saga/effects';
import { createToPayload, reduceFromPayload, resolvePromise } from 'saga-duck/build/helper';
import SearchableSelect, { SearchParam } from '.';

export enum Reason {
  NonExist,
  NonAvailable,
}

/**
 * 继承自 SearchableSelect 
 * 新增分页必然选中和 disabled 的能力
 */
export default abstract class SelectAvailable extends SearchableSelect {
  /**
   * 重新选中时用于判断当前 item 是否可选
   * @example 集群选择时需要过滤隔离中状态的实例
   */
  isAvailable(item: this['Item']) {
    if (!item) {
      return false;
    }
    return !item?.disabled;
  }

  /**
   * 根据 ID 获取 Item，若未找到，请抛出异常
   * @param id
   * @param params
   */
  abstract getItemById(id: string, params: this['GetDataParam']): Promise<this['Item']>;

  /**
   * 未找到选中 Item 时触发回调
   * @param id 未找到的 ID
   * @param newItem 新选中的 Item
   */
  abstract onMissSelected(id: string, newItem: this['Item'], reason?: Reason): void;

  get quickTypes() {
    enum Types {
      SET_ASSURE_SELECTED,
    }
    return {
      ...super.quickTypes,
      ...Types,
    };
  }

  get reducers() {
    const { types } = this;
    return {
      ...super.reducers,
      assureSelected: reduceFromPayload(types.SET_ASSURE_SELECTED, false),
    };
  }

  get creators() {
    const { types } = this;
    return {
      ...super.creators,
      assureSelected: createToPayload<boolean>(types.SET_ASSURE_SELECTED),
    };
  }
  /**
   * 确保选中
   */
  *assureSelection(): Generator<any, this['Item'], any> {
    const duck = this;
    const { types, selector, selectors, creators } = duck;
    // 如何加载失败了不要卡住
    yield take([types.SET_TOTAL_COUNT, this.ducks.fetcher.types.FETCH_FAIL]);

    function* getFirstAvailable() {
      const { list } = selector(yield select());
      return list?.find((item) => duck.isAvailable(item));
    }

    function* reset() {
      const available = yield getFirstAvailable();
      yield put(creators.select(available ? duck.getId(available) : ''));
      yield put(creators.assureSelected(true));
    }

    const selected = selectors.selected(yield select());
    if (selected) {
      // id 存在于当前列表中，但 item 可能 disabled
      if (!duck.isAvailable(selected)) {
        this.onMissSelected(selected.id, yield getFirstAvailable(), Reason.NonAvailable);
        return yield* reset();
      }
      yield put(this.creators.assureSelected(true));
      return;
    }

    const { id, param, nomore } = selector(yield select());

    if (!id) {
      // id 不存在，执行默认选中
      return yield* reset();
    }

    if (nomore) {
      // id 存在，列表已加载完成，说明当前 id 不存在于列表中
      this.onMissSelected(id, yield getFirstAvailable());
      // 仍然无法选中，执行默认选中
      yield* reset();
    }

    // 选中 id 不存在于当前列表中，但列表还未加载完成
    try {
      const item = yield* resolvePromise(duck.getItemById(id, param));
      if (duck.isAvailable(item)) {
        const { list } = selector(yield select());
        const newList = list.slice();
        newList.unshift(item);
        yield put({
          type: types.SET_LIST,
          payload: newList,
        });
        yield put(this.creators.assureSelected(true));
        return;
      }
      // 额外补全 item 被 disable，执行默认选中
      this.onMissSelected(id, yield getFirstAvailable(), Reason.NonAvailable);
      yield* reset();
    } catch {
      this.onMissSelected(id, yield getFirstAvailable());
      // 仍然无法选中，执行默认选中
      yield* reset();
    }
  }
  /**
   * @override
   */
  protected *search(baseParam: this['Param']) {
    type Item = this['Item'];
    type Data = this['Data'];

    const duck = this;

    const {
      types,
      selector,
      ducks: { fetcher },
      pageSize,
    } = this;

    const { pendingKeyword: pendingLocalParam } = selector(yield select());
    let list: Item[] = [];
    let totalCount: null | undefined | number = null;
    let continueToken = null;
    let remainCount: null | undefined | number = null;
    do {
      try {
        // 加载下一页内容
        const searchParam: SearchParam = {
          limit: pageSize,
        };
        if (this.transactionPaging) {
          searchParam.continue = continueToken;
        } else {
          searchParam.offset = list.length;
        }
        const fetcherParam = duck.getParam(baseParam, pendingLocalParam, searchParam);
        const data: Data = yield* fetcher.fetch(fetcherParam);

        // 合并列表
        list = list.concat(data.list);

        // 合并 redux store 中的列表，筛选由于确保选中而提前插入的元素
        const appendedList = selector(yield select()).list || [];
        const existedIds = appendedList.map(duck.getId);
        const newList = appendedList
          .slice()
          .concat(data.list.filter((item) => (existedIds.length ? !existedIds.includes(duck.getId(item)) : true)));

        if (this.transactionPaging) {
          continueToken = data.continue;
          // 事务型分页，remainCount不一定有
          remainCount = data.remainCount;
          if (typeof remainCount === 'number') {
            totalCount = list.length + remainCount;
          }
        } else {
          // 更新总数
          totalCount = data.totalCount;
        }
        // 更新结果
        yield put({
          type: types.SEARCH_DONE,
          payload: pendingLocalParam,
        });
        yield put({
          type: types.SET_LIST,
          payload: newList,
        });
        if (this.transactionPaging) {
          // 有continueToken表示列表没拉完，此时totalCount有可能不可信
          if (!continueToken) {
            yield put({
              type: types.NOMORE,
            });
          }
        } else if (list.length === totalCount) {
          // 如果已经加载完了，退出循环
          yield put({
            type: types.NOMORE,
          });
        }
        if (totalCount !== selector(yield select()).totalCount) {
          yield put({
            type: types.SET_TOTAL_COUNT,
            payload: totalCount,
          });
        }
        const { nomore } = duck.selector(yield select());
        if (nomore) {
          break;
        }
      } catch (e) {
        // 出错了Fetcher那会展示出来，不处理，不中止MORE重试
      }
      // 等待下一次加载更多的指令
    } while (yield take(types.MORE));
  }
}
