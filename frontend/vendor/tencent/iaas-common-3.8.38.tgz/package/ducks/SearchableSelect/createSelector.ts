import { SearchParam } from '../SearchableList'
import { createToPayload, DuckCmpProps, reduceFromPayload, useDuck } from 'saga-duck'
import { useEffect, useMemo, useRef } from 'react'
import useControlled from '../../hooks/useControlled'
import { cacheableWith, noRejected, ttl } from '../../helpers/cacheable'
import { ContinueLoadMoreExtraOptions, ListResult, useContinueLoadMore } from '../AbstractSearchableList'
import { FieldAPI } from '../Form'
import { SelectOptionWithGroup } from '@tencent/tea-component'
import { SearchableTeaSelectProps } from '../../duckComponents/SearchableTeaSelect'
import SearchableSelect from '.'
export { SearchParam } from '../SearchableList'
export interface Middleware<TDuck = any> {
  (props: DuckCmpProps<TDuck>): any
}

export interface Selector<TDuck extends SearchableSelect> extends DuckCmpProps<TDuck> { }
abstract class MyDuck<TParam, TItem> extends SearchableSelect {
  declare Param: TParam
  declare Item: TItem
}
interface CreateSelectorOptions<TParam, TItem> {
  /** 分页请求数据接口 */
  getData: (param: TParam & SearchParam) => Promise<ListResult<TItem>>,
  /** 记录如何获取id（即Select的value对应的字段) */
  getId: (o: TItem) => string,
  /** 分页请求一页最大数量，默认为20 */
  pageSize?: number
  /** 是否为事务型分页，默认为false */
  transactionPaging?: boolean
  /** 请求缓存，单位毫秒，默认5000毫秒 */
  ttl?: number
  /** 判断参数是否足够，如不足则不触发请求，并清空列表。默认为 v => !!v */
  isParamValid?: (param: TParam) => boolean
  /** 判断参数是否有变化需要重新请求。默认为JSON.stringify */
  hashParam?: (param: TParam) => any
}
interface CreateSelector {
  <TParam, TItem>(
    opts: CreateSelectorOptions<TParam, TItem>,
  ): (param: TParam | null) => Selector<MyDuck<TParam, TItem>>
  <TParam, TItem, TResult = any>(
    opts: CreateSelectorOptions<TParam, TItem>,
    currying?: (selector: Selector<MyDuck<TParam, TItem>>) => TResult
  ): (param: TParam | null) => TResult

}
/**
 * 创建一个选择器hook，用于SearchableSelect
 * ```typescript
 * const useXxxSelector = createSelector({
 *     getData: async param=>({list: [{id:'test', name: 'test test'}], totalCount: 0}),
 *     getId: o => o.id
 *   },
 *   selector => {
 *     return {
 *       props: selector,
 *       bindField: currying(selector, hooks.bindField)
 *     }
 *   }
 * )
 *
 * function Component({field}: {field: FieldAPI<string>}){
 *   const selectorProps = useXxxSelector(param)
 *   return <>
 *     <SearchableTeaSelect {...selectorProps} toOption={o => ({text: o.name, value: o.id})}/>
 *   </>
 * }
 * ```
 * @returns useXxxSelector
 */

const createSearchableSelector: CreateSelector = function createSeachableSelector<TParam, TItem, TResult = Selector<MyDuck<TParam, TItem>>>(
  opts: CreateSelectorOptions<TParam, TItem>,
  currying?: (selector: Selector<MyDuck<TParam, TItem>>) => TResult
) {
  const {
    getData: query, 
    getId,
    isParamValid = p => !!p,
    hashParam = p => JSON.stringify(p) 
  } = opts
  class MyDuck extends SearchableSelect {
    declare Param: TParam
    declare Item: TItem
    getId(o) {
      return getId(o)
    }
    get pageSize() {
      return opts?.pageSize || 20
    }
    get transactionPaging() {
      return opts?.transactionPaging || false
    }
    @cacheableWith(ttl(opts?.ttl || 5 * 1000, noRejected()))
    async getData(filter) {
      return query(filter)
    }
  }

  function useRawSelector(param: TParam | null): Selector<MyDuck> {
    const { duck, dispatch, store } = useDuck(MyDuck)

    useEffect(() => {
      // 取消已有请求，并重置列表
      dispatch(duck.creators.cancelLoad())
      if (!isParamValid(param)) {
        return
      }
      // 条件变化时重新加载列表
      dispatch(duck.creators.load(param))
    }, [hashParam(param)])

    return {
      duck, dispatch, store
    }
  }

  return function useCustomSelector(param: TParam) {
    const selector = useRawSelector(param)
    if (currying) {
      return currying(selector)
    }
    return selector
  }
}

export default createSearchableSelector

/**
 * 生成SearchableTeaSelect使用的Props
 * @param props 
 * @param opts 
 * @returns 
 */
function getSearchableTeaSelectProps<TDuck extends SearchableSelect>(props: Selector<TDuck>, opts?: Partial<SearchableTeaSelectProps<TDuck['Item']>>): SearchableTeaSelectProps<TDuck['Item']> {
  const { duck, store, dispatch } = props
  const { toOption, ...rest } = opts || {}
  const { id } = duck.selector(store)
  return {
    duck, store, dispatch,
    // 列表没有所选项时，也要展示下选中状态
    placeholder: id || undefined,
    toOption: toOption || ((o: TDuck['Item']) => ({
      text: duck.getId(o),
      value: duck.getId(o)
    })),
    ...rest
  }
}

/** 生成常用的actions */
function getActions<TDuck extends SearchableSelect>(props: DuckCmpProps<TDuck>) {
  const { duck, store, dispatch } = props
  return useMemo(
    () => ({
      reload: () => dispatch(duck.creators.reload()),
      reset: () => dispatch(duck.creators.reset()),
      load: (p: TDuck['Param']) => dispatch(duck.creators.load(p)),
      select: (id: string) => dispatch(duck.creators.select(id)),
      loadMore: () => dispatch(duck.creators.more()),
    }),
    [],
  )
}

/** 获取常用状态 */
function getStatus<TDuck extends SearchableSelect>(props: DuckCmpProps<TDuck>) {
  const { duck, store } = props
  const { loadingMore, fetcher: { loading, error } } = duck.selector(store)
  return useMemo(
    () => ({
      loading,
      error,
      loadingMore
    }),
    [store],
  )
}

/** 实现受控模式 */
function controlled<TDuck extends SearchableSelect>(props: Selector<TDuck>, value: string, onChange: (v: string) => any) {
  const { duck, store, dispatch } = props
  useControlled(
    value,
    onChange,
    duck.selector(store).id,
    v => dispatch(duck.creators.select(v)),
  )
}

/** 将SearchableSelect与Form.FieldAPI绑定起来 */
function bindField<TDuck extends SearchableSelect>(props: Selector<TDuck>, field: FieldAPI<string | null>) {
  const { duck, store, dispatch } = props
  useControlled(
    field.getValue(),
    v => field.setValue(v),
    duck.selector(store).id,
    v => dispatch(duck.creators.select(v)),
  )
}

/**
 * 在UI展示层有过滤的情况下，启用持续加载更多功能
 * @returns 
 */
function continueLoadMore<TDuck extends SearchableSelect>(props: Selector<TDuck>, opts: ContinueLoadMoreExtraOptions<TDuck['Item']>) {
  const { duck, store, dispatch } = props
  useContinueLoadMore({
    duck,
    store,
    dispatch, ...opts
  })
}

/**
 * 监听下拉选项的切换
 * @param props 
 * @param cb 
 * @param ignoreFirst 是否无视第一次设置值（一般为初始化
 */
function onValueChange<TDuck extends SearchableSelect>(props: Selector<TDuck>, cb: (o: TDuck['Item']) => any, ignoreFirst = true) {
  const { duck, store, dispatch } = props
  const lastValue = useRef<string | null>(null)
  const curValue = duck.selector(store).id
  useEffect(() => {
    // 第一次跳过
    if (lastValue.current !== null && curValue !== lastValue.current) {
      cb(duck.selectors.selected(store))
    }
    lastValue.current = curValue
  }, [curValue])
}

/** 参数变化时重置选择值 */
function resetOnChange<TDuck extends SearchableSelect>(props: Selector<TDuck>, {
  defaultValue = ''
}) {
  const { duck, store, dispatch } = props
  const { param } = duck.selector(store)
  const lastParam = useRef(null)
  useEffect(() => {
    if (!param) {
      return
    }
    // 如果条件在非初始化时变化，重置选择的值
    if (lastParam.current !== null) {
      dispatch(duck.creators.select(defaultValue))
    }
    lastParam.current = param
  }, [JSON.stringify(param)])
}

export const hooks = {
  getSearchableTeaSelectProps,
  getActions,
  getStatus,
  controlled,
  bindField,
  resetOnChange,
  onValueChange,
  continueLoadMore
}

export function currying<TDuck extends SearchableSelect, TArgs extends any[]>(selector: Selector<TDuck>, hook: (selector: Selector<TDuck>, ...args: TArgs) => any) {
  return function curryHook<TThis>(this: TThis, ...args: TArgs) {
    hook(selector, ...args)
    return this
  }
}