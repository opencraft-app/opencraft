# Duck开发规范约定/最佳实践（草稿）
## 原因
用于规范 Duck 组件代码，方便开发与维护

## ActionType
- 统一为大写 + 下划线分隔
    >例如： `SET_LIST`、`FIRE_SEARCH`
- 按使用类型分为3类，尽量不要混用
    - 供`reducer`使用的内部更新操作，使用`SET_`前缀
        >例如： `SET_KEYWORD`、`SET_TOTAL_COUNT`
    - 仅供外部触发的操作，使用`FIRE_`前缀，并使用`creators`包装，**不能直接由外部使用**
        >例如： `FIRE_SEARCH`、`FIRE_LOAD_MORE`
    - 仅供外部监听的操作，使用`EVENT_`前缀
        >例如： `EVENT_NO_MORE`

## reducers
- 约定使用`action.payload`进行传值，大部分可以直接使用`reduceFromPayload`快速生成

## selectors
- selectors仅用于`计算`，简单的取值直接用`selector`

## creators
- creators主要用于`外部`调用（且外部只能使用creators，不能直接用types.XXX创建action），大部分可以直接使用`createToPayload`快速生成
- [待定] 内部使用无需creators，直接拼装action，减少冗余

## saga
- 业务逻辑比较多的，尽量拆分成子saga方法，再在saga方法中使用`yield *`调用
- 子saga方法命名约定
    - 仅供内部使用的saga方法，声明为 `protected *xxxx()` 或 `*sagaXxxx()`
    - 仅供内部使用的saga方法，并且仅建立监听逻辑（不阻塞流程执行），声明为 `protected *watchXxxx()` 或 `*sagaWatchXxxx()`
    - 供外部（父duck）使用的saga方法（例如Fetcher#fetch），声明为 `public *xxxx()`

## Duck内逻辑联动
优先使用 `runAndTakeLatest`/`runAndWatchLatest` 嵌套结构。例如
```typescript
yield runAndWatchLatest(types.SELECT_REGION, getRegionId, function*(regionId){
    // 加载可用区列表，并自动选中第一项
    yield* loadZone(regionId)
    yield runAndWatchLatest(types.SELECT_ZONE, getZoneId, function*(zoneId){
        // 这种写法，在切换地域时，不会出现加载 广州 + 上海一区 的VPC这种串数据的情况
        yield* loadVpc(regionId, zoneId)
    })
})
```
有以下优点
- 只有依赖项加载完后，才会加载下一项，逻辑层次清晰，完全掌控执行流程
- 父依赖项变更时，所有子项都会自动中止，并重新执行，不会串数据

如果有需要`独立运行`（相对于父任务）的任务，才考虑使用`action`中转

## Duck间逻辑联动
优先使用saga直接调用，例如：
```typescript
yield* fetcher.fetch(xxx)
```
有以下优点
- 可取消 - 父逻辑中止时，子逻辑一并中止
- 支持错误捕获 - 可以 `try...catch`
- 可传递回调进行逻辑组装
- 减少胶水 `action type`、`action creators`