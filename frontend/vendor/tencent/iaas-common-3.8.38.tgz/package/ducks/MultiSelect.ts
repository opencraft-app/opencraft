// 多选，ButtonBar等
import {
  DuckMap as Base,
  asResult,
  reduceFromPayload,
  createToPayload
} from 'saga-duck'
import { select, put, call, take, fork, cancel } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga-catch'
import { findByCondition } from '../helpers'

enum Types {
  SET_SELECTED,
  SELECT,
  DESELECT,
  SET_LIST
}

export default abstract class Duck extends Base {
  /** ID类型定义 */
  abstract ID
  /** 条目类型定义 */
  abstract Item
  get quickTypes() {
    return {
      ...super.quickTypes,
      ...Types
    }
  }
  get reducers() {
    const { types } = this
    type ID = this['ID']
    type Item = this['Item']
    return {
      ...super.reducers,
      /** 这个list也可以不用，主要是通过selectors.list来获取 */
      list: reduceFromPayload<Item[]>(types.SET_LIST, []),
      selectedId: (state = [], action): ID[] => {
        switch (action.type) {
          case types.SELECT:
            return state.concat(action.payload)
          case types.DESELECT: {
            const deselectSet = new Set(action.payload)
            return state.filter(id => !deselectSet.has(id))
          }
          case types.SET_SELECTED:
            return action.payload
          default:
            return state
        }
      }
    }
  }
  get creators() {
    const { types } = this
    type ID = this['ID']
    type Item = this['Item']
    return {
      ...super.creators,
      setList: createToPayload<Item[]>(types.SET_LIST),
      select: createToPayload<ID | ID[]>(types.SELECT),
      deselect: createToPayload<ID | ID[]>(types.DESELECT),
      setSelected: createToPayload<ID[]>(types.SET_SELECTED)
    }
  }
  get rawSelectors() {
    type State = this['State']
    return {
      ...super.rawSelectors,
      list: (state: State) => state.list,
      availableList: (state: State) => {
        return this.rawSelectors
          .list(state)
          .filter(o => !this.isDisabled(o, state))
      },
      selected: (state: State) => {
        return this.findMulti(this.rawSelectors.list(state), state.selectedId)
      }
    }
  }
  get selectionChangeTypes() {
    return [this.types.SELECT, this.types.DESELECT, this.types.SET_SELECTED]
  }
  /** 选项是否禁用 */
  isDisabled(item: this['Item'], state: this['State']): string {
    return null
  }
  /** 获取ID */
  getId(item: this['Item']): this['ID'] {
    return item as any
  }
  /** 查找 */
  find(list: this['Item'][], id: this['ID']): this['Item'] {
    return findByCondition(list, item => this.getId(item) === id)
  }
  /** 批量查找 */
  findMulti(list: this['Item'][], ids: this['ID'][]): this['Item'][] {
    const idSet = new Set(ids)
    return list.filter(item => idSet.has(this.getId(item)))
  }
}
