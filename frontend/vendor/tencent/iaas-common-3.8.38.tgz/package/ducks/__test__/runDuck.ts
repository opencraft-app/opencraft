import { DuckRuntime, Duck } from 'saga-duck'

export default async function runDuck<TDuck extends Duck>(
  duck: TDuck,
  saga: (ctx: DuckRuntime<TDuck>) => any
) {
  const runtime = new DuckRuntime(duck)
  runtime.addSaga([
    function* () {
      yield* saga(runtime)
      // 不要在saga中中止saga，放在另一个任务里进行
      setTimeout(() => runtime.destroy(), 0)
    }
  ])
}
