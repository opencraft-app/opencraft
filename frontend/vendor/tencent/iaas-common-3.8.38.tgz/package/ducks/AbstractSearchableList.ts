/**
 * 可搜索列表，有以下功能
 *
 * 1. 搜索（自行输入条件）
 * 2. 加载更多
 */

 import {
  ComposableDuck as Base,
  createToPayload,
  DuckCmpProps,
  reduceFromPayload
} from 'saga-duck'
import { takeLatest, runAndTakeLatest, delay } from 'redux-saga-catch'
import { select, take, put } from 'redux-saga/effects'
import Fetcher from './Fetcher'
import { useEffect, useRef } from 'react'
// import { cancelable } from '../helpers/saga'

export interface SearchParam {
  offset?: number
  continue?: any
  limit?: number
}
export interface ListResult<T> {
  list: T[]
  totalCount?: number
  continue?: any
  remainCount?: number
}
export default abstract class AbstractSearchableSelect extends Base {
  /** 基本搜索参数，由外部传入 */
  declare Param: any
  /** 本地搜索参数 */
  declare LocalParam: any
  /** 列表项 */
  declare Item: any
  /** 类型声明 */
  declare Data: ListResult<this['Item']>
  /**
   * 如何构造Fetcher的查询条件
   * @param baseParam 基本搜索参数
   * @param localParam 本地搜索参数
   * @param pagingParam 分页参数
   */
  abstract getParam(
    baseParam: this['Param'],
    localParam: this['LocalParam'],
    pagingParam: SearchParam
  )
  declare GetDataParam: ReturnType<this['getParam']> 
  declare Fetcher: FetcherType<this['Data'], this['GetDataParam']> 
  /**
   * 哪些操作会触发搜索条件变更（本组件内的条件变更）
   */
  get searchTypes() {
    return [this.types.SEARCH]
  }
  /**
   * 默认的搜索条件
   */
  abstract get defaultLocalParam(): this['LocalParam']
  /** 分页接口一次查询最大值（根据后台接口要求设置） */
  get pageSize() {
    return 20
  }
  /** 是否为continue token形式的事务型分页接口 */
  get transactionPaging() {
    return false
  }
  /** 即用户输入后是否自动触发搜索 */
  get autoSearch() {
    return true
  }
  /** 自动搜索延时buffer，默认300毫秒 */
  get autoSearchBuffer() {
    return 300
  }
  /** 请求延时buffer，单位毫秒 */
  get fetchBuffer() {
    return 300
  }
  abstract getData(
    param: this['GetDataParam']
  ): Promise<ListResult<this['Item']>>
  get quickTypes() {
    enum Types {
      SET_LIST,
      /** 外部传入基本参数，开启加载 */
      LOAD,
      /** 中止外部触发发加载，并清空数据 */
      CANCEL_LOAD,
      /** 内部动作，设置基本参数 */
      LOAD_START,
      /** 输入搜索条件 */
      SET_PENDING_SEARCH_PARAMS,
      // 历史兼容
      INPUT_KEYWORD,
      /** 触发搜索 */
      SEARCH,
      RESET,
      RELOAD,
      /** 搜索完成，更新关键字 */
      SEARCH_DONE,
      SET_TOTAL_COUNT,
      MORE,
      NOMORE
    }
    return {
      ...super.quickTypes,
      ...Types
    }
  }
  get reducers() {
    const { types } = this
    return {
      ...super.reducers,
      /** 当前列表对应的基本搜索条件 */
      param: reduceFromPayload<this['Param']>(types.LOAD_START, null),
      /** 搜索框中的用户输入条件 */
      pendingKeyword: (
        state = this.defaultLocalParam,
        action
      ): this['LocalParam'] => {
        switch (action.type) {
          case types.SET_PENDING_SEARCH_PARAMS:
          case types.INPUT_KEYWORD:
          case types.SEARCH:
            return action.payload
          case types.LOAD_START:
          case types.RESET:
          case types.CANCEL_LOAD:
            return this.defaultLocalParam
          default:
            return state
        }
      },
      /** 结果列表对应的搜索条件 */
      keyword: (state = this.defaultLocalParam, action): this['LocalParam'] => {
        switch (action.type) {
          case types.SEARCH_DONE:
            return action.payload
          case types.LOAD_START:
          case types.RESET:
          case types.CANCEL_LOAD:
            return this.defaultLocalParam
          default:
            return state
        }
      },
      /** 当前查询到的列表 */
      list: (state = null, action): this['Item'][] | null => {
        switch (action.type) {
          case types.SET_LIST:
            return action.payload
          case types.LOAD_START:
          // 输入关键字时，老是清空，有点体验不好
          // 但这样有助于区分是条件变更的搜索“刷新”还是“加载更多”
          case types.SEARCH:
          case types.RESET:
          case types.CANCEL_LOAD:
            return null
          default:
            return state
        }
      },
      /** 列表总条数（包括未加载完的，需要后端返回） */
      totalCount: (state = null, action): number | null => {
        switch (action.type) {
          case types.SET_TOTAL_COUNT:
            return action.payload
          case types.LOAD_START:
          case types.RESET:
          case types.CANCEL_LOAD:
          case types.SEARCH:
            return null
          default:
            return state
        }
      },
      /** 列表是否已经加载完，即不会有“加载更多” */
      nomore: (state = false, action): boolean => {
        switch (action.type) {
          case types.NOMORE:
            return true
          case types.LOAD_START:
          case types.RESET:
          case types.CANCEL_LOAD:
          case types.SEARCH:
          case types.RELOAD:
            return false
          default:
            return state
        }
      },
      /** 是否处于加载更多的模式，这时UI上loading需要展示在列表尾部 */
      loadingMore: (state = false, action): boolean => {
        switch (action.type) {
          case types.MORE:
            return true
          case types.SET_LIST:
          case types.LOAD_START:
          case types.RESET:
          case types.CANCEL_LOAD:
          case types.SEARCH:
          case types.RELOAD:
            return false
          default:
            return state
        }
      }
    }
  }
  get creators() {
    const { types } = this
    type Param = this['Param']
    return {
      ...super.creators,
      load: createToPayload<Param>(types.LOAD),
      cancelLoad: createToPayload<void>(types.CANCEL_LOAD),
      // 历史兼容
      inputKeyword: createToPayload<this['LocalParam']>(types.INPUT_KEYWORD),
      setPendingSearchParams: createToPayload<this['LocalParam']>(
        types.SET_PENDING_SEARCH_PARAMS
      ),
      search: createToPayload<this['LocalParam']>(types.SEARCH),
      reload() {
        return { type: types.RELOAD }
      },
      reset() {
        return { type: types.RESET }
      },
      more() {
        return { type: types.MORE }
      }
    }
  }
  get quickDucks() {
    const duck = this
    type Param = this['GetDataParam']
    type Data = this['Data']
    class MyFetcher extends Fetcher {
      Param: Param
      Data: Data
      get buffer() {
        return duck.fetchBuffer
      }
      async getDataAsync(param: MyFetcher['Param']) {
        return duck.getData(param)
      }
    }
    return {
      ...super.quickDucks,
      fetcher: MyFetcher as this['Fetcher']
    }
  }
  *saga() {
    yield* super.saga()
    if (this.autoSearch) {
      yield* this.sagaAutoSearch()
    }
    // 监听load
    yield* this.sagaWatchLoad()
  }
  *sagaAutoSearch() {
    const { types, autoSearchBuffer } = this
    // 是否自动启用搜索
    yield takeLatest(
      [types.SET_PENDING_SEARCH_PARAMS, types.INPUT_KEYWORD, types.SEARCH],
      function* ({ type, payload }) {
        // 如果有触发SEARCH，中止自动触发
        if (type === types.SEARCH) {
          return
        }
        yield delay(autoSearchBuffer)
        yield put({
          type: types.SEARCH,
          payload
        })
      }
    )
  }
  *sagaWatchLoad() {
    const duck = this
    const { types } = this
    yield takeLatest([types.LOAD, types.CANCEL_LOAD], function* (action) {
      if (action.type === types.CANCEL_LOAD) {
        return
      }
      yield* duck.load(action.payload)
    })
  }
  /**
   * 供外界嵌入，以指定参数加载，并监听相关搜索、加载更多等操作。
   *
   * **注意：调用时需自行保证只有一个任务执行（即如果更改参数，需要取消前次的调用与运行）**
   *
   * **注意：请勿与`creators.load()`一起使用，否则会导致存在多套监听逻辑**
   */
  *load(param: this['Param']) {
    const duck = this
    const { types } = this
    yield runAndTakeLatest(types.RELOAD, function* () {
      yield* duck.sagaLoadAndWatchSearch(param)
    })
  }

  *sagaLoadAndWatchSearch(param: this['Param']) {
    const duck = this
    const { types, selector } = this

    // 更新参数
    yield put({
      type: types.LOAD_START,
      payload: param
    })
    const baseParam = selector(yield select()).param
    // 默认以初始条件搜索，同时新搜索会重置当前数据
    yield runAndTakeLatest(this.searchTypes, function* () {
      yield* duck.search(baseParam)
    })
  }
  /**
   * 搜索逻辑
   * @param baseParam
   */
  // @cancelable<AbstractSearchableSelect>(function* () {
  //   yield put(this.creators.reset())
  // })
  protected *search(baseParam: this['Param']) {
    type Item = this['Item']
    type Data = this['Data']

    const duck = this

    const {
      types,
      selector,
      ducks: { fetcher },
      pageSize
    } = this

    const { pendingKeyword: pendingLocalParam } = selector(yield select())
    let list: Item[] = []
    let totalCount: null | undefined | number = null
    let continueToken = null
    let remainCount: null | undefined | number = null
    do {
      try {
        // 加载下一页内容
        const searchParam: SearchParam = {
          limit: pageSize
        }
        if (this.transactionPaging) {
          searchParam.continue = continueToken
        } else {
          searchParam.offset = list.length
        }
        const fetcherParam = duck.getParam(
          baseParam,
          pendingLocalParam,
          searchParam
        )
        const data: Data = yield* fetcher.fetch(fetcherParam)

        // 合并列表
        list = list.concat(data.list)
        if (this.transactionPaging) {
          continueToken = data.continue
          // 事务型分页，remainCount不一定有
          remainCount = data.remainCount
          if (typeof remainCount === 'number') {
            totalCount = list.length + remainCount
          }
        } else {
          // 更新总数
          totalCount = data.totalCount
        }
        // 更新结果
        yield put({
          type: types.SEARCH_DONE,
          payload: pendingLocalParam
        })
        yield put({
          type: types.SET_LIST,
          payload: list
        })
        if (totalCount !== selector(yield select()).totalCount) {
          yield put({
            type: types.SET_TOTAL_COUNT,
            payload: totalCount
          })
        }
        if (this.transactionPaging) {
          // 有continueToken表示列表没拉完，此时totalCount有可能不可信
          if (!continueToken) {
            yield put({
              type: types.NOMORE
            })
            break
          }
        } else if (list.length === totalCount) {
          // 如果已经加载完了，退出循环
          yield put({
            type: types.NOMORE
          })
          break
        }
      } catch (e) {
        // 出错了Fetcher那会展示出来，不处理，不中止MORE重试
      }
      // 等待下一次加载更多的指令
    } while (yield take(types.MORE))
  }
}

interface MyFetcher<TData, TParam> extends Fetcher {
  Param: TParam
  Data: TData
}
type FetcherType<TData, TParam> = {
  new(...any: any[]): MyFetcher<TData, TParam>
}



/**
 * 当SearchableList在UI层有过滤展示时，保证会持续加载直到满足可见项数目要求
 */
export interface ContinueLoadMoreExtraOptions<TItem> {
  isVisible: (o: TItem) => boolean
  /** 保证一次加载中可见项的数目，默认为duck.pageSize */
  assureVisibleCountPerPage?: number
}
export interface ContinueLoadMoreOptions<TItem, TDuck extends MySearchableList<TItem>>
  extends ContinueLoadMoreExtraOptions<TItem>,
  DuckCmpProps<TDuck> { }
abstract class MySearchableList<TItem> extends AbstractSearchableSelect {
  declare Item: TItem
}
/**
 * 保证SearchableList加载的内容一定有可见的项目
 *
 * 用于UI层过滤了选项的情况
 * @param opts
 */
export function useContinueLoadMore<TItem, TDuck extends MySearchableList<TItem>>(
  opts: ContinueLoadMoreOptions<TItem, TDuck>,
) {
  const { duck, store, dispatch, isVisible, assureVisibleCountPerPage = duck.pageSize } = opts
  const { param, pendingKeyword, list, nomore } = duck.selector(store)
  const lastList = useRef<TItem[]>([])
  // 列表查询参数变化，需要重置页码
  useEffect(() => {
    lastList.current = []
  }, [param, pendingKeyword])
  // 列表变化时，保证本次加载必然有有效字段
  useEffect(() => {
    if (nomore || !list?.length) {
      return
    }
    let timer
    const appendedList = list.slice(lastList.current?.length || 0)
    // 如果新加载的内容可见条目不满足数量，继续触发加载
    if (appendedList.length && appendedList.filter(isVisible).length < assureVisibleCountPerPage) {
      // 速度有点快了。。。这时saga可能还没有开始take，似乎只能等一下了
      timer = setTimeout(()=>{
        dispatch(duck.creators.more())
      }, 10)
    } else {
      lastList.current = list
    }
    return () => timer && clearTimeout(timer)
  }, [list, nomore])
}
