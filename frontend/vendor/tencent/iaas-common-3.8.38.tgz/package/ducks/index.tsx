import * as React from 'react'
import { Provider } from 'react-redux'
import { createLogger } from 'redux-logger'
import { DuckRuntime, DuckCmpProps } from 'saga-duck'

type OMIT_DUCK_CMP<TProps> = Omit<TProps, 'duck' | 'store' | 'dispatch'>
interface DuckClass<TDuck> {
  new (...any: any[]): TDuck
}
export function connectWithDuck<
  TProps extends DuckCmpProps<TDuck>,
  TState,
  TDuck
  >(
  Component: React.ComponentClass<TProps, TState>,
  Duck: DuckClass<TDuck>,
  extraMiddlewares?: any[]
): React.StatelessComponent<OMIT_DUCK_CMP<TProps>>
export function connectWithDuck<TProps, TDuck>(
  Component: React.StatelessComponent<TProps>,
  Duck: DuckClass<TDuck>,
  extraMiddlewares?: any[]
): React.StatelessComponent<OMIT_DUCK_CMP<TProps>>

export function connectWithDuck(Component, Duck, extraMiddlewares = []) {
  return function ConnectedWithDuck(props) {
    try {
      const { duckRuntime, ConnectedComponent } = React.useMemo(() => {
        const middlewares =
          process.env.NODE_ENV === 'development'
            ? [createLogger({ collapsed: true })]
            : []
        let duckRuntime

        // 支持 extraMiddlewares[0] 传入 {middlewares: [], enhancers: []} 格式
        if (
          extraMiddlewares?.length === 1 &&
          (extraMiddlewares[0]?.middlewares || extraMiddlewares[0]?.enhancers)
        ) {
          duckRuntime = new DuckRuntime(new Duck(), {
            ...extraMiddlewares[0],
            middlewares: [
              ...middlewares,
              ...(extraMiddlewares[0]?.middlewares || [])
            ]
          })
        } else {
          duckRuntime = new DuckRuntime(
            new Duck(),
            ...middlewares,
            ...extraMiddlewares
          )
        }

        const ConnectedComponent = duckRuntime.connectRoot()(Component)
        return {
          duckRuntime,
          ConnectedComponent
        }
      }, [])

      return (
        <Provider store={duckRuntime.store}>
          <ConnectedComponent {...props} />
        </Provider>
      )
    } catch (e) {
      // 这里错误有可能会被吃掉，先打印出来
      console.log(e)
      throw e
    }
  }
}

export { default as GridDuck } from './Grid'
export { default as RegionDuck } from './Region'
export { default as RouteDuck } from './Route'
export { default as PageDuck } from './Page'
export { default as GridPageDuck } from './GridPage'
export { default as DialogDuck } from './Dialog'
export { default as DialogPureDuck } from './DialogPure'
export { default as ConfirmDuck } from './Confirm'
export { default as DetailPageDuck } from './DetailPage'
export { default as WhiteListDuck } from './WhiteList'
export { default as TreeDuck } from './Tree'
export { default as FetcherDuck } from './Fetcher'
