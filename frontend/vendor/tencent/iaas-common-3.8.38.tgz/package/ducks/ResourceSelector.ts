/**
 * qcloud-component ResourceSelector对应的Duck
 * 有以下功能：
 * 可以按关键字搜索资源
 * 可多选
 */
import { reduceFromPayload, createToPayload, asResult } from 'saga-duck'
import { select, put, call, take, fork } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga-catch'
import Base from './MultiSelect'
import Fetcher from './Fetcher'

export interface FetcherParam {
  offset: number
  limit: number
  keyword: string
}
export interface FetcherData<TItem> {
  list: TItem[]
  totalCount: number
}
enum Types {
  INPUT_KEYWORD,
  SEARCH
}
interface MyFetcher<TItem> extends Fetcher {
  Data: {
    list: TItem[]
  }
}
type FetcherType< TItem> = {
  new (...any: any[]): MyFetcher< TItem>
}
export default abstract class Duck extends Base {
  abstract get Fetcher(): FetcherType<this['Item']>
  get quickTypes(){
    return {
      ...super.quickTypes,
      ...Types
    }
  }
  get reducers(){
    const {types}=this
    return {
      ...super.reducers,
      keyword: reduceFromPayload<string>(types.INPUT_KEYWORD, '')
    }
  }
  get creators(){
    const {types}=this
    return {
      ...super.creators,
      setKeyword(s: string, searchNow = false) {
        return {
          type: types.INPUT_KEYWORD,
          payload: s,
          searchNow
        }
      },
      search() {
        return {
          type: types.SEARCH
        }
      }
    } 
  }
  get rawSelectors(){
    type State = this['State']
    return {
      ...super.rawSelectors,
      // 重写selectors.list，从Fetcher中获取
      list: (state: State) => (state.fetcher.data ? state.fetcher.data.list : [])
    }
  }
  get quickDucks(){
    return {
      ...super.quickDucks,
      fetcher: this.Fetcher as this['Fetcher']
    }
  }
  *saga(){
    yield* super.saga()
    yield fork([this, this.sagaResurceSelectorMain])
  }
  *sagaResurceSelectorMain(duck = this) {
    const {
      types,
      selector,
      selectors,
      ducks: { fetcher }
    } = duck
    // 搜索时，调用Fetcher
    yield takeLatest(types.SEARCH, function*() {
      const state = asResult(selector, yield select(selector))
      const param = duck.getParam(state)

      yield fetcher.fetch(param)
    })
  }
  /**
   * 返回TParam，供Fetcher使用
   */
  getParam(state: this['State']): this['ducks']['fetcher']['Param'] {
    return {
      offset: 0,
      limit: 100,
      keyword: state.keyword
    }
  }
}
