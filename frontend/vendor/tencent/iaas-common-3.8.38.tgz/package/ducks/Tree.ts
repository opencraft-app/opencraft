/**
 * 树Duck
 * 1. 指定根节点 duck.creators.setRoot(...)
 * 2. 指定加载方法 duck.options.getChildren(duck, parent) 返回节点列表
 * 3. 默认支持复选、展开功能
 */
import { Duck } from 'saga-duck'
import { select, take, put, call, fork } from 'redux-saga/effects'
import { takeEvery } from 'redux-saga-catch'

export type ID = string | number
export interface Node {
  parent?: ID
  id: ID
  children?: ID[]
}
export interface AsyncNode extends Node {
  loaded?: boolean
  loading?: boolean
  error?: any
}
export interface NodeUIProps {
  /** 节点的展示 */
  label?: string
  /** 是否处于已禁用的状态 */
  disabled?: boolean
  /** 是否不能选中 */
  checkable?: boolean
  /** 是否处于已选中状态 */
  checked?: boolean
  /** 是否处于已展开状态 */
  expanded?: boolean
  /** 是否为叶子节点，即不能展开 */
  leaf?: boolean
  /** 是否高亮 */
  active?: boolean
}

let idSeed = 1
const ID_PROPERTY = 'id'
export function getId<TNode extends Node>(node: TNode): ID {
  if (typeof node === 'string' || typeof node === 'number') {
    return node
  }
  return (
    node[ID_PROPERTY] || (node[ID_PROPERTY] = node.id || `AUTO_ID_${idSeed++}`)
  )
}

/**
 * 将树形的树结构转换为平面的结构，并将children转换为id列表
 * @param {object|object[]} nodes 节点数组
 * @param {object} map 节点 id->node映射map
 * @param {String} parent 父节点ID
 * @return {Array<Number|String>} idArray
 */
function normalizeNode<TNode extends Node>(
  nodes: any,
  map: NODE_MAP<TNode>,
  parentId?: ID
): ID[] {
  return [].concat(nodes).map(node => {
    const flatNode: TNode = node
    const id = getId(flatNode)
    if (parentId) {
      flatNode.parent = parentId
    }
    map[id] = flatNode
    if (flatNode.children) {
      flatNode.children = normalizeNode(node.children, map, id)
    }
    return id
  })
}

/**
 * 添加或替换节点
 * @param {*} map
 * @param {*} nodes
 */
function addNodes<TNode extends Node>(
  map: NODE_MAP<TNode>,
  nodes: TNode | TNode[],
  parentId: ID,
  afterId: ID
): NODE_MAP<TNode> {
  const newMap = {}
  const parent = parentId && map[parentId]
  const ids = normalizeNode(nodes, newMap, parentId)
  if (parent) {
    const children = (parent.children || []).slice(0)
    const index = afterId ? children.indexOf(afterId) + 1 : children.length
    children.splice(index, 0, ...ids)
    map[parentId] = Object.assign({}, parent, {
      children
    })
  }
  return {
    ...map,
    ...newMap
  }
}
/**
 * 移除节点
 * @param {*} map
 * @param {*} nodes
 */
function removeNodes(map, nodes) {
  const toRemoveMap = {}
  normalizeNode(nodes, toRemoveMap)
  const newMap = { ...map }
  Object.keys(toRemoveMap).forEach(key => {
    delete newMap[key]
  })
  return newMap
}
/**
 * 更新节点值
 * @param {*} map
 * @param {*} nodes
 */
function updateNodes(map, nodes) {
  const toUpdateMap = {}
  normalizeNode(nodes, toUpdateMap)
  const newMap = { ...map }
  Object.keys(toUpdateMap).forEach(key => {
    newMap[key] = {
      ...newMap[key],
      ...toUpdateMap[key]
    }
  })
  return newMap
}

export interface NODE_MAP<TNode> {
  [id: string]: TNode
}
export interface BOOLEAN_MAP {
  [id: string]: boolean
}

enum Types {
  'SET_ROOT',
  'ADD_NODE',
  'REMOVE_NODE',
  'UPDATE_NODE',

  'EXPAND',
  'COLLAPSE',
  'SET_EXPANDED_MAP',

  'CHECK',
  'UNCHECK',
  'SET_CHECKED_MAP',

  'RELOAD'
}
export default abstract class TreeDuck extends Duck {
  abstract Node: Node
  static getId(node) {
    return getId(node)
  }
  get quickTypes() {
    return {
      ...super.quickTypes,
      ...Types
    }
  }
  get reducers() {
    const { types } = this
    type TNode = this['Node']
    return {
      ...super.reducers,
      /** 树根节点ID */
      root: (state = '', action): ID => {
        switch (action.type) {
          case types.SET_ROOT:
            return getId(action.payload)
          default:
            return state
        }
      },
      /** 所有节点MAP */
      map: (state = {}, action): NODE_MAP<TNode> => {
        const node = action.payload
        switch (action.type) {
          case types.SET_ROOT:
            // 如果为设置Root，则返回全新map
            state = {}
          /**jshint fallthrough */
          case types.ADD_NODE:
            return addNodes(
              state,
              node,
              action.parent && getId(action.parent),
              action.after && getId(action.after)
            )
          case types.UPDATE_NODE:
            return updateNodes(state, {
              ...node,
              id: action.id || node.id
            })
          case types.REMOVE_NODE:
            return removeNodes(state, node)
          default:
            return state
        }
      },
      expanded: (state = {}, action): BOOLEAN_MAP => {
        switch (action.type) {
          case types.SET_ROOT:
            return {}
          case types.EXPAND:
            return Object.assign({}, state, {
              [getId(action.payload)]: true
            })
          case types.COLLAPSE:
            return Object.assign({}, state, {
              [getId(action.payload)]: false
            })
          case types.SET_EXPANDED_MAP:
            return action.payload
          default:
            return state
        }
      },
      checked: (state = {}, action): BOOLEAN_MAP => {
        switch (action.type) {
          case types.SET_ROOT:
            return {}
          case types.CHECK:
            return Object.assign({}, state, {
              [getId(action.payload)]: true
            })
          case types.UNCHECK:
            return Object.assign({}, state, {
              [getId(action.payload)]: false
            })
          case types.SET_CHECKED_MAP:
            return action.payload
          default:
            return state
        }
      }
    }
  }
  get creators() {
    const { types } = this
    type TNode = this['Node']
    return {
      ...super.creators,
      /** 设置根节点 */
      setRoot: (node: ID | TNode) => ({
        type: types.SET_ROOT,
        payload: node
      }),
      add: (parent: ID | TNode, node, after: ID | TNode) => ({
        type: types.ADD_NODE,
        parent,
        after,
        payload: node
      }),
      remove: (node: ID | TNode) => ({
        type: types.REMOVE_NODE,
        payload: node
      }),
      /** 更新节点 */
      update: (id: ID, properties) => ({
        type: types.UPDATE_NODE,
        id,
        payload: properties
      }),
      /** 展开节点 */
      expand: (node: ID | TNode) => ({ type: types.EXPAND, payload: node }),
      /** 收缩节点 */
      collapse: (node: ID | TNode) => ({ type: types.COLLAPSE, payload: node }),
      /** 选中节点 */
      check: (node: ID | TNode) => ({ type: types.CHECK, payload: node }),
      /** 节点选中状态 */
      uncheck: (node: ID | TNode) => ({ type: types.UNCHECK, payload: node }),
      /** 重新加载节点 */
      reload: (node: ID | TNode) => ({ type: types.RELOAD, payload: node }),
      setExpandedMap: (map: BOOLEAN_MAP) => ({
        type: types.SET_EXPANDED_MAP,
        payload: map
      }),
      setCheckedMap: (map: BOOLEAN_MAP) => ({
        type: types.SET_CHECKED_MAP,
        payload: map
      })
    }
  }
  get rawSelectors() {
    type State = this['State']
    return {
      ...super.rawSelectors,
      /** 根节点ID */
      rootId: (state: State) => state.root,
      /** 节点map id->node */
      map: (state: State) => state.map,
      /** 根节点 */
      root: (state: State) => state.map[state.root],
      /** 节点是否选中 id->checked */
      checkedMap: (state: State) => state.checked,
      /** 节点是否展开 id->expanded */
      expandedMap: (state: State) => state.expanded
    }
  }
  *saga() {
    yield* super.saga()
    yield fork([this, this.sagaTreeMain])
  }
  *sagaTreeMain(duck = this) {
    const { types, selectors } = duck
    // 展开时自动加载
    yield takeEvery([types.EXPAND, types.RELOAD], function* autoExpand(action) {
      const id = getId(action.payload)
      const map = yield select(selectors.map)
      const node = map[id]
      if (!node) {
        return
      }
      // 如果已加载，无视
      if (action.type !== types.RELOAD && node.loaded) {
        return
      }
      yield call(duck.loadNodeChildren, duck, id)
    })
  }
  /** 加载函数 */
  *getChildren(duck, parent) {}
  /**
   * 加载子节点
   * @param {*} duck
   * @param {*} id
   */
  *loadNodeChildren(duck, id) {
    const { types, selectors, creators, getChildren } = duck
    const map = yield select(selectors.map)
    const node = map[id]
    if (!node) {
      return
    }
    // 如果已加载或正在加载，等待
    if (node.loading) {
      let action
      while ((action = yield take(types.UPDATE_NODE))) {
        if (action.id === id && action.payload && action.payload.loaded) {
          break
        }
      }
    } else {
      // 其它情况，加载之
      yield put(creators.update(id, { loading: true }))
      // 加载数据
      try {
        const children = yield call(getChildren, duck, node)
        yield put(
          creators.update(id, {
            children,
            error: null,
            loading: false,
            loaded: true
          })
        )
      } catch (e) {
        console.error(e)
        yield put(creators.update(id, { error: e, loading: false }))
      }
    }
  }
  /**
   * 映射节点，可扩展，增加常用属性
   * @param {*} node
   * @param {*} store
   */
  proxy(node: this['Node'], store): this['Node'] & NodeUIProps {
    const { selectors } = this
    const expandedMap = selectors.expandedMap(store)
    const checkedMap = selectors.checkedMap(store)
    const expanded = !!expandedMap[node.id]
    const checked = !!checkedMap[node.id]
    return Object.assign({}, node, {
      expanded,
      checked
    })
  }
  /**
   * 能触发选中状态改变的动作列表
   */
  get checkActions() {
    const { types } = this
    return [types.CHECK, types.UNCHECK, types.SET_CHECKED_MAP]
  }
}
