import Form, { ArrayFieldAPI, FieldAPI, MapFieldAPI, getFirstInvalid, getFirstInvalidWithPath } from './Form'
import { put, take, select, fork, join, cancel } from 'redux-saga/effects'
import { delay } from 'redux-saga-catch'
import runDuck from './__test__/runDuck'

interface Context<TForm extends Form = Form> {
  duck: TForm
  getAPI(): FieldAPI<TForm['Values'], TForm>
  getField<T = any>(
    path: number | string | (number | string)[]
  ): FieldAPI<T, TForm>
}
async function run<TForm extends Form>(
  duck: TForm,
  saga: (ctx: Context<TForm>) => any
) {
  runDuck(duck, function* (runtime) {
    yield* saga({
      duck,
      getAPI() {
        return duck.getAPI(runtime.store.getState(), runtime.store.dispatch)
      },
      getField(path) {
        let field = this.getAPI()
        for (const key of [].concat(path)) {
          field = field.getField(key)
        }
        return field
      }
    })
  })
}

describe('setValue', () => {
  it('预定义格式', cb => {
    const form = new Form()
    run(form, function* () {
      yield put(form.creators.setValue(['a', 'a'], 1))
      yield put(form.creators.setValue(['a', 'b', 'c'], '2'))
      expect(form.selectors.values(yield select())).toStrictEqual({
        a: {
          a: 1,
          b: {
            c: '2'
          }
        }
      })
      cb()
    })
  })
  it('根层为array', cb => {
    const form = new Form()
    run(form, function* () {
      yield put(form.creators.setValue(0, 1))
      expect(form.selectors.values(yield select())).toStrictEqual([1])
      cb()
    })
  })
  it('子层为array', cb => {
    const form = new Form()
    run(form, function* () {
      yield put(form.creators.setValue(['a', 0], 1))
      yield put(form.creators.setValue(['b', 'a', 0], 1))
      yield put(form.creators.setValue(['b', 'b', 0, 'a', 0], 1))
      expect(form.selectors.values(yield select())).toStrictEqual({
        a: [1],
        b: {
          a: [1],
          b: [
            {
              a: [1]
            }
          ]
        }
      })
      cb()
    })
  })
})

describe('combineValidators', () => {
  const meta = Symbol('unique meta')
  const numberInvalid = 'not number'
  function validNumber(v, values, m) {
    expect(m).toBe(meta)
    if (typeof v !== 'number') {
      return numberInvalid
    }
  }
  const stringInvalid = 'not string'
  function validString(v, values, m) {
    expect(m).toBe(meta)
    if (typeof v !== 'string') {
      return stringInvalid
    }
  }
  it('传统对象递归', () => {
    interface Values {
      a: { a: number; b: string; c: string }
      b: string
    }
    const values: Values = { a: { a: '', b: 0, c: '' }, b: '' } as any
    const validator = Form.combineValidators<Values>({
      a: {
        a: validNumber,
        b: validString,
        c(v, vs, m) {
          let foo = vs.c // typescript 检测
          expect(v).toBe(values.a.c)
          expect(vs).toBe(values.a)
          expect(m).toBe(meta)
        }
      },
      b(v, vs, m) {
        let foo = vs.b // typescript 检测
        expect(v).toBe(values.b)
        expect(vs).toBe(values)
        expect(m).toBe(meta)
      }
    })
    expect(validator(values, meta)).toStrictEqual({
      a: {
        a: numberInvalid,
        b: stringInvalid,
        c: undefined
      },
      b: undefined
    })
  })
  it('louis版本的递归', () => {
    const validator = Form.combineValidators<{ a: { a: number; b: string } }>({
      a() {
        return {
          a: validNumber,
          b: validString
        }
      }
    })
    expect(validator({ a: { a: '', b: 0 } } as any, meta)).toStrictEqual({
      a: {
        a: numberInvalid,
        b: stringInvalid
      }
    })
  })
  it('根层为array类型', () => {
    type Values = {
      a: string
      c: {
        a: string
        b: number
      }
    }[]
    const validator = Form.combineValidators<Values>([
      {
        a: validString,
        c: {
          a: validString,
          b: validNumber
        }
      }
    ])
    expect(
      validator(
        [
          {
            a: 1,
            c: {
              a: 1,
              b: ''
            }
          },
          {
            a: ''
          },
          {
            a: 1,
            c: {
              a: 1
            }
          }
        ] as any,
        meta
      )
    ).toStrictEqual([
      {
        a: stringInvalid,
        c: {
          a: stringInvalid,
          b: numberInvalid
        }
      },
      {
        a: undefined, // 没校验出问题
        c: {
          a: stringInvalid,
          b: numberInvalid
        }
      },
      {
        a: stringInvalid,
        c: {
          a: stringInvalid,
          b: numberInvalid
        }
      }
    ])
  })
  it('array类型', () => {
    interface Values {
      a: {
        a: number[]
        b: string[]
        c: { a: number }[]
        d: number[]
      }
    }
    const validator = Form.combineValidators<Values>({
      a: {
        a: [validNumber],
        b: [validString],
        c: [
          {
            a: validNumber
          }
        ],
        d: (list, values, meta) => {
          return list.map(v => validNumber(v, list, meta))
        }
      }
    })
    expect(
      validator(
        {
          a: {
            a: [''],
            b: [0],
            c: [{ a: '' }, { a: '' }],
            d: ['']
          }
        } as any,
        meta
      )
    ).toStrictEqual({
      a: {
        a: [numberInvalid],
        b: [stringInvalid],
        c: [
          {
            a: numberInvalid
          },
          {
            a: numberInvalid
          }
        ],
        d: [numberInvalid]
      }
    })
  })

  // Map类型设计上或可考虑另开发一个makeMapValidator方法
  it('Map类型', () => {
    // makeMapValidator返回的校验方法，参数为： (value, values, meta)
    // combineValidators返回的校验方法，参数为： (value, meta)
    // 注意区分
    const validator = Form.makeMapValidator(validString)
    expect(
      validator(
        {
          a: 1,
          b: 2,
          c: ''
        },
        null,
        meta
      )
    ).toStrictEqual({
      a: stringInvalid,
      b: stringInvalid,
      c: undefined
    })
  })

  it('Map类型嵌套', () => {
    const validator = Form.combineValidators({
      map: Form.makeMapValidator(validString)
    })
    expect(
      validator(
        {
          map: {
            a: 1,
            b: 1,
            c: '',
            anykey: 1
          }
        },
        meta
      )
    ).toStrictEqual({
      map: {
        a: stringInvalid,
        b: stringInvalid,
        c: undefined,
        anykey: stringInvalid
      }
    })
  })
})

describe('validate', () => {
  it('输入输出正确', cb => {
    const values = {}
    const meta = {}
    const invalids = {
      a: Symbol(),
      array: [Symbol()]
    }
    class MyForm extends Form {
      get rawSelectors() {
        return {
          ...super.rawSelectors,
          values() {
            return values
          },
          validateMeta() {
            return meta
          }
        }
      }
      validate(v, m) {
        expect(v).toBe(values)
        expect(m).toBe(meta)
        return invalids
      }
    }
    const form = new MyForm()
    run(form, function* () {
      expect(form.selectors.invalids(yield select())).toStrictEqual(invalids)
      cb()
    })
  })

  it('array容错', cb => {
    class MyForm extends Form {
      validate() {
        return {
          array: 'aaa'
        }
      }
    }
    const form = new MyForm()

    run(form, function* (ctx) {
      const field = ctx.getField('array').asArray().get(0)
      expect(field.getError()).toBe(null)
      cb()
    })
  })
})

describe('API', () => {
  const testField = function (ctx: Context, fieldKey, value) {
    const getField = () => ctx.getField(fieldKey)
    getField().setValue(value)
    expect(getField().getValue()).toStrictEqual(value)

    getField().setTouched(true)
    expect(getField().getTouched()).toStrictEqual(true)

    getField().setTouched(false)
    expect(getField().getTouched()).toStrictEqual(false)

    const error = Math.random().toString(16)
    getField().setError(error)
    expect(getField().getError()).toStrictEqual(error)
  }
  it('getField不会变更数据，只是获取引用', cb => {
    const form = new Form()
    run(form, function* (ctx) {
      const initialValues = form.selectors.values(yield select())
      ctx.getField(['number_array', 0])
      // getField不会导致结构创建，只是建立API对象
      expect(form.selectors.values(yield select())).toBe(initialValues)
      cb()
    })
  })
  it('根层项修改', cb => {
    const form = new Form()
    run(form, function* (ctx) {
      testField(ctx, 'number', Math.random())
      testField(ctx, 'string', Math.random().toString(16))
      testField(ctx, 'number_array', [1, 2, 3, 4])
      testField(ctx, 'string_array', ['asd', 'dd', 'gsdf'])
      testField(ctx, 'object_array', [{ a: 3 }, { b: 5 }])

      cb()
    })
  })

  it('多层项修改', cb => {
    const form = new Form()
    run(form, function* (ctx) {
      testField(ctx, ['object', 'number'], Math.random())
      testField(ctx, ['object', 'string'], Math.random().toString(16))
      testField(ctx, ['object_array', 0], { a: Math.random() })
      testField(ctx, ['object_array', 1, 'number'], Math.random())
      testField(ctx, ['object_array', 2, 0, 'number'], Math.random())

      cb()
    })
  })

  it('array结构初始化', cb => {
    const form = new Form()
    run(form, function* (ctx) {
      const value = Math.random()
      ctx.getField(['number_array', 0]).setValue(value)
      // 设置值后，值建立成功
      expect(form.selectors.values(yield select())).toStrictEqual({
        number_array: [value]
      })

      // array嵌套对象
      ctx.getField(['number_array', 1, 'a']).setValue(value)
      expect(form.selectors.values(yield select())).toStrictEqual({
        number_array: [value, { a: value }]
      })
      cb()
    })
  })
  it('多层array增删', cb => {
    const form = new Form()
    run(form, function* (ctx) {
      const value = Math.random()
      ctx.getField([1, 1, 'a', 1, 1]).setValue(value)
      // 设置值后，值建立成功
      expect(form.selectors.values(yield select())).toStrictEqual([
        ,
        [
          ,
          {
            a: [, [, value]]
          }
        ]
      ])
      cb()
    })
  })
  it('根层array元素增删', cb => {
    const form = new Form()
    run(form, function* (ctx) {
      const value = Math.random()
      ctx.getField([1]).setValue(value)
      expect(form.selectors.values(yield select())).toStrictEqual([, value])
      expect(ctx.getAPI().asArray().length).toBe(2)
      // 删除空元素后，后面的前移
      ctx.getAPI().asArray().remove(0)
      expect(form.selectors.values(yield select())).toStrictEqual([value])
      expect(ctx.getAPI().asArray().length).toBe(1)
      cb()
    })
  })

  it('array增删，能兼容父级设置touched: true的场景', cb => {
    const form = new Form()
    run(form, function* (ctx) {
      ctx.getField('array').setTouched(true)
      ctx.getField('array').asArray().insert(1, 'hello')

      cb()
    })
  })

  it('父级设置touched，子级应该也被视作touched', cb => {
    const form = new Form()
    run(form, function* (ctx) {
      ctx.getField('array').setValue(['hello', 'world'])
      ctx.getField('array').setTouched(true)
      expect(ctx.getField('array').asArray().get(0).getTouched()).toBe(true)

      cb()
    })
  })

  it('getFields类型约束', cb => {
    class MyForm extends Form {
      declare Values: {
        a: string
        b: string
      }
    }
    const form = new MyForm()
    run(form, function* (ctx) {
      const api = ctx.duck.getAPI(null, () => { })
      // 预期没有错误
      api.getFields(['a']).a
      // @ts-expect-error 当没有获取到对应字段时，预期类型报错
      api.getFields(['a']).b
      // @ts-expect-error 字段列表为空时，获取对应字段预期类型报错
      api.getFields([]).a
      // 字段列表为空时，仅调用不报错（兼容旧有代码）
      api.getFields([])

      cb()
    })
  })

  describe('array增删后，touched/error等状态自动同步', () => {
    function test(getArray: () => ArrayFieldAPI<any, Form>) {
      const getElement = index => getArray().getField(index)
      const error = Math.random().toString(16)
      getElement(0).setTouched(true)
      getElement(0).setError(error)
      // 前后方插入，变成 [null, null, a, null, null]
      getArray().insert(0, null, null)
      getArray().insert(3, null, null)
      expect(getElement(2).getTouched()).toBe(true)
      expect(getElement(2).getError()).toBe(error)
      // 同时前后的错误及touched应为空
      expect(getElement(0).getError()).toBe(undefined)
      expect(getElement(0).getTouched()).toBe(undefined)
      expect(getElement(3).getError()).toBe(undefined)
      expect(getElement(3).getTouched()).toBe(undefined)
      // 前后方移除，变成[null, a, null]
      getArray().remove(3)
      getArray().remove(0)
      expect(getElement(1).getTouched()).toBe(true)
      expect(getElement(1).getError()).toBe(error)
      // 同时前后的错误及touched应为空
      expect(getElement(0).getError()).toBe(undefined)
      expect(getElement(0).getTouched()).toBe(undefined)
      expect(getElement(2).getError()).toBe(undefined)
      expect(getElement(2).getTouched()).toBe(undefined)
    }
    it('根层', cb => {
      const form = new Form()
      run(form, function* (ctx) {
        test(() => ctx.getAPI().asArray())
        cb()
      })
    })
    it('其它层', cb => {
      const form = new Form()
      run(form, function* (ctx) {
        test(() => ctx.getAPI().getField('test').asArray())
        cb()
      })
    })
  })

  describe('Array遍历', () => {
    function test(getArray: () => ArrayFieldAPI<any, Form>) {
      const valueCount = 10
      const values = new Array(valueCount)
        .fill(0, 0, valueCount)
        .map(x => Math.random())
      getArray().insert(0, ...values)
      // 长度判断
      expect(getArray().length).toBe(valueCount)
      // for...of 遍历
      let iteratorCount = 0
      for (const field of getArray()) {
        expect(field.getValue()).toBe(values[iteratorCount])
        iteratorCount++
      }
      expect(iteratorCount).toBe(valueCount)
      // for...of array.entries() 遍历
      let entryCount = 0
      for (const [index, field] of getArray().entries()) {
        expect(field.getValue()).toBe(values[index])
        entryCount++
      }
      expect(entryCount).toBe(valueCount)

      // 删除某项
      const deleteIndex = Math.floor(Math.random() * valueCount)
      getArray().remove(deleteIndex)
      expect(getArray().length).toBe(valueCount - 1)
      entryCount = 0
      for (const [index, field] of getArray().entries()) {
        expect(field.getValue()).toBe(
          values[index >= deleteIndex ? index + 1 : index]
        )
        entryCount++
      }
      expect(entryCount).toBe(valueCount - 1)
    }
    it('根层', cb => {
      run(new Form(), function* (ctx) {
        // 测试根层
        test(() => ctx.getAPI().asArray())
        cb()
      })
    })
    it('其它层', cb => {
      run(new Form(), function* (ctx) {
        // 测试根层
        test(() => ctx.getAPI().getField('test').asArray())
        cb()
      })
    })
  })

  describe('Record/Map遍历', () => {
    function test(getMap: () => MapFieldAPI<any, Form>) {
      const valueCount = 10
      const values = new Array(valueCount)
        .fill(0, 0, valueCount)
        .reduce((map, v, index) => {
          map[`key${index}`] = Math.random()
          return map
        }, {})
      getMap().setValue(values)
      // 长度判断
      expect(getMap().size).toBe(valueCount)
      // for...of 遍历
      let iteratorCount = 0
      for (const [key, field] of getMap()) {
        expect(field.getValue()).toBe(values[key])
        iteratorCount++
      }
      expect(iteratorCount).toBe(valueCount)
      // for...of map.entries() 遍历
      let entryCount = 0
      for (const [key, field] of getMap().entries()) {
        expect(field.getValue()).toBe(values[key])
        entryCount++
      }
      expect(entryCount).toBe(valueCount)

      // 删除某项
      const deleteKey = Object.keys(values)[0]
      getMap().delete(deleteKey)
      expect(getMap().size).toBe(valueCount - 1)
      iteratorCount = 0
      for (const [key, field] of getMap()) {
        expect(key).not.toBe(deleteKey)
        iteratorCount++
      }
      expect(iteratorCount).toBe(valueCount - 1)
    }
    it('根层', cb => {
      run(new Form(), function* (ctx) {
        // 测试根层
        test(() => ctx.getAPI().asMap())
        cb()
      })
    })
    it('其它层', cb => {
      run(new Form(), function* (ctx) {
        // 测试根层
        test(() => ctx.getAPI().getField('test').asMap())
        cb()
      })
    })
  })

  describe('值类型转换', () => {
    function test(getField: () => FieldAPI<any, Form>) {
      const inA = Symbol()
      const savedA = Symbol()
      const outA = Symbol()
      const from = inV => {
        expect(inV).toBe(inA)
        return savedA
      }
      const to = savedV => {
        expect(savedV).toBe(savedA)
        return outA
      }
      getField().map(to, from).setValue(inA)
      expect(getField().getValue()).toBe(savedA)
      expect(getField().map(to, from).getValue()).toBe(outA)
    }
    it('根层', cb => {
      run(new Form(), function* (ctx) {
        test(() => ctx.getAPI())
        cb()
      })
    })
    it('子层', cb => {
      run(new Form(), function* (ctx) {
        test(() => ctx.getAPI().getField('test'))
        cb()
      })
    })
    it('多层', cb => {
      run(new Form(), function* (ctx) {
        test(() => ctx.getAPI().getField('test').getField('foo'))
        cb()
      })
    })
    it('array', cb => {
      run(new Form(), function* (ctx) {
        test(() => ctx.getAPI().getField('test').asArray().getField(0))
        cb()
      })
    })
    it('array嵌套', cb => {
      class TestForm extends Form {
        Values: {
          test: { foo: number[] }[]
        }
      }
      run(new TestForm(), function* (ctx) {
        test(() =>
          ctx
            .getAPI()
            .getField('test')
            .asArray()
            .getField(0)
            .getField('foo')
            .asArray()
            .getField(0)
        )
        cb()
      })
    })
  })
})

describe('actionMapping', () => {
  function test(path, type, cb) {
    class MyForm extends Form {
      get actionMapping() {
        const mapping: any = {}
        const objPath = path.slice(0)
        let lastKey = objPath.pop()
        let o = mapping
        for (const key of objPath) {
          o = o[key] = o[key] || {}
        }
        o[lastKey] = type
        return mapping
      }
    }
    run(new MyForm(), function* (ctx) {
      function getField() {
        let field = ctx.getAPI()
        for (const key of path) {
          field = field.getField(key)
        }
        return field
      }
      // form -> action
      const value = Math.random()
      function* saga() {
        const action = yield take(type)
        expect(action.payload).toBe(value)
        // action -> form
        const outValue = Math.random()
        yield put({
          type,
          payload: outValue
        })
        // 不是立即生效的... 所以加下延时
        yield delay(10)
        expect(getField().getValue()).toBe(outValue)
        cb()
        // 这里主动cancel，外面用join保证任务执行完
        // 如果不cancel，会导致最终saga被强行中止，因为run没有结束
        yield cancel()
      }
      const task = yield fork(saga)
      yield delay(10)
      getField().setValue(value)

      yield join(task)
    })
  }
  it('预定义', cb => {
    test(['test'], 'TEST', cb)
  })
  it('预定义多层', cb => {
    test(['test', 'foo'], 'TEST_FOO', cb)
  })
  it('array类型', cb => {
    test(['test', 0], 'TEST_ARRAY', cb)
  })
})


describe('getFirstInvalids', () => {
  const error = 'error'
  it('无错误', () => {
    expect(getFirstInvalid(null)).toBe(null)
    expect(getFirstInvalid([])).toStrictEqual(null)
    expect(getFirstInvalid({
      test: {}, arr: [null, {
        foo: null
      }]
    })).toBe(null)
  })

  it('根层错误', () => {
    expect(getFirstInvalid(error)).toBe(error)
  })

  it('数组内错误', ()=>{
    expect(getFirstInvalid([error])).toBe(error)
    expect(getFirstInvalid([null, null, error])).toBe(error)
  })

  it('对象内错误', ()=>{
    expect(getFirstInvalid({
      foo: null,
      bar: error
    })).toBe(error)
  })

  it('多层结构错误', ()=>{
    expect(getFirstInvalid([
      null, {
        foo: {
          bar: [error]
        }
      }
    ])).toBe(error)
  })

  it('指定范围错误', ()=>{
    const invalids = {
      foo: error,
      bar: null
    }
    expect(getFirstInvalid(invalids, ['foo'])).toBe(error)
    expect(getFirstInvalid(invalids, ['bar'])).toBe(null)
  })
})


describe('getFirstInvalidWithPath', () => {
  const error = 'error'
  it('无错误', () => {
    expect(getFirstInvalidWithPath(null)).toBe(null)
    expect(getFirstInvalidWithPath({
      test: {}, arr: [null, {
        foo: null
      }]
    })).toStrictEqual(null)
    expect(getFirstInvalidWithPath([])).toBe(null)
  })

  it('根层错误', () => {
    expect(getFirstInvalidWithPath(error)).toStrictEqual({
      invalid: error,
      path: []
    })
  })

  it('数组内错误', ()=>{
    expect(getFirstInvalidWithPath([error])).toStrictEqual({invalid: error, path: [0]})
    expect(getFirstInvalidWithPath([null, null, error])).toStrictEqual({invalid: error, path: [2]})
  })

  it('对象内错误', ()=>{
    expect(getFirstInvalidWithPath({
      foo: null,
      bar: error
    })).toStrictEqual({invalid: error, path: ['bar']})
  })

  it('多层结构错误', ()=>{
    expect(getFirstInvalidWithPath([
      null, {
        foo: {
          bar: [error]
        }
      }
    ])).toStrictEqual({invalid: error, path: [1, 'foo', 'bar', 0]})
  })

  it('指定范围错误', ()=>{
    const invalids = {
      foo: error,
      bar: null
    }
    expect(getFirstInvalidWithPath(invalids, ['foo'])).toStrictEqual({invalid: error, path: ['foo']})
    expect(getFirstInvalidWithPath(invalids, ['bar'])).toBe(null)
  })
})