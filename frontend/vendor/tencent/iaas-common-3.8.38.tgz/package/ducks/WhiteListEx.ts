/**
 * 白名单查询，支持分组输入额外参数
 */
import { BaseDuck } from 'saga-duck'
import { put } from 'redux-saga/effects'
import { getWhiteList } from '../model'

const map = {}

export default abstract class WhiteListEx extends BaseDuck {
  // 需要查询的 key
  // EXAMPLE：
  // get whiteListKeysList() {
  //   return [
  //     {
  //       whitelistKeys: ['ipv6_vpc', 'vpc_broadcast', 'VPC-gateway-flow-control']
  //       opts: {}
  //     },
  //     {
  //       whitelistKeys: ['ipv6_vpc'],
  //       opts: {
  //         withRegion: true,
  //         regionFormat: 'REGION-number' as any
  //       }
  //     }
  //   ]
  // }
  abstract get whiteListKeysList(): {
    whitelistKeys: string[]
    opts: {
      withRegion?: boolean
      regionFormat?: 'REGION-number' | 'number' | 'regionId'
      [otherOpt: string]: any
    }
  }[]

  get quickTypes() {
    return {
      ...super.quickTypes,
      DONE: 'DONE'
    }
  }
  get reducer() {
    const { types } = this
    return (state = {}, action) => {
      if (action.type == types.DONE) {
        return {
          ...state,
          ...action.payload
        }
      }
      return state
    }
  }
  *saga() {
    const { types } = this
    yield* super.saga()
    // 按顺序加载白名单，如果有相同的 key，后加载的会覆盖前面的
    for (let i = 0; i < this.whiteListKeysList.length; i++) {
      const result = yield getWhiteList(
        this.whiteListKeysList[i].whitelistKeys,
        this.whiteListKeysList[i].opts
      )
      yield put({ type: types.DONE, payload: result })
    }
  }
}
