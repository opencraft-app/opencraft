// 单选，可用于下拉框、ButtonBar等
import {
  DuckMap as Base,
  asResult,
  reduceFromPayload,
  createToPayload
} from 'saga-duck'
import { select, put, call, take, fork, cancel } from 'redux-saga/effects'
import { takeLatest, runAndTakeLatest } from 'redux-saga-catch'

export default abstract class Duck extends Base {
  /** ID类型定义 */
  abstract ID
  /** 条目类型定义 */
  abstract Item
  /** 是否启用自动选中，默认为true */
  get assureSelection() {
    return true
  }
  get quickTypes() {
    enum Types {
      SELECT,
      SET_LIST
    }
    return {
      ...super.quickTypes,
      ...Types
    }
  }
  get reducers() {
    const { types } = this
    return {
      ...super.reducers,
      list: reduceFromPayload(types.SET_LIST, this.defaultList),
      id: reduceFromPayload(types.SELECT, this.defaultId)
    }
  }
  get rawSelectors() {
    type State = this['State']
    return {
      ...super.rawSelectors,
      selected: (state: State) => this.find(state.list, state.id)
    }
  }
  get creators() {
    const { types } = this
    type TID = this['ID']
    type TItem = this['Item']
    return {
      ...super.creators,
      setList: createToPayload<TItem[]>(types.SET_LIST),
      select: createToPayload<TID>(types.SELECT)
    }
  }
  *saga() {
    yield* super.saga()
    if (this.assureSelection) {
      yield* this.sagaAssureSelectionWatch()
    }
  }
  *sagaAssureSelectionWatch(duck = this) {
    // 保证选中
    yield takeLatest(
      this.selectionTypes,
      () => duck.sagaAssureSelection()
    )
  }
  /**
   * 哪些ActionType会影响到选中值
   */
  protected get selectionTypes() {
    const { types } = this
    return [types.SELECT, types.SET_LIST]
  }
  /**
   * 确保选中，如果没有可选项，置为null
   */
  *sagaAssureSelection() {
    const duck = this
    const { types, selector, creators } = duck
    const { list, id } = asResult(selector, yield select(selector))
    if (!list) {
      return
    }
    const availableList = list.filter(duck.isAvailable)
    const found = duck.find(availableList, id)
    if (found === undefined) {
      const newId = availableList.length > 0 ? duck.getId(duck.getOne(availableList)) : null
      if (newId !== id) {
        yield put(creators.select(newId))
      }
    }
  }
  /** 设计为由外部控制何时开始约束选中（防止列表未加载时值被置空），建议搭配assureSelection: false使用 */
  *runAssureSelectionAndWatch() {
    yield runAndTakeLatest(this.selectionTypes, [this, this.sagaAssureSelection])
  }
  /** 选项是否可用 */
  isAvailable(item: this['Item']): boolean {
    return true
  }
  /** 获取ID */
  getId(item: this['Item']): this['ID'] {
    return item as any
  }
  /** 自动修正选中 */
  protected find(list: this['Item'][], id: this['ID']): this['Item'] {
    return (list || []).find(item => this.getId(item) === id)
  }
  /** 默认如果没有找到，则选第一项，可重写 */
  protected getOne(list: this['Item'][]): this['Item'] {
    return list && list[0]
  }
  /** 默认列表 */
  get defaultList(): this['Item'][] {
    return []
  }
  /** 默认值 */
  get defaultId(): this['ID'] {
    return null
  }
}
