import { DuckMap, reduceFromPayload, createToPayload } from 'saga-duck';
import { put, take, select, all, call, fork } from 'redux-saga/effects';
import { takeEvery, runAndTakeLatest } from 'redux-saga-catch';
import { PageParam } from '../Page';
import buildConfig from '../../buildConfig';
import { once, cacheable } from '../../helpers/cacheable';
import { t } from '@tencent/tea-app/lib/i18n';
import persistence from '@tencent/iaas-common/inject/appUtil'
import queryRegionViaConsole from './queryRegionViaConsole';
import queryRegionViaQcbase from './queryRegionViaQcbase';
import queryRegionSystemInfo from './queryRegionSystemInfo';
import { resolvePromise } from '../../helpers/saga';
import { OnceDescribeRegionsAndZones } from '../../models/regionMap';

enum Types {
  SELECT,
  SET_FULL_LIST,
  SET_WHITELIST,
  /** 当指定地域不可用，自动切换为其它可用地域时触发 */
  UNSUPPORTED,
  /** 当初始加载完成后，无任何地域可用时触发 */
  NO_VALID_REGION,
  SET_INITIAL_LOAD,
  INITIALIZED
}

// // 过滤白名单
// function* filterWithWhiteList({selector, types}){
//     const {fullList, whiteList = []} = yield select(selector)
//     yield put({
//         type: types.SET_LIST,
//         payload: fullList.filter(region=>{
//             return whiteList.indexOf(region.value) >= 0
//         })
//     })
// }

/**
 * 保证选中，如果不在内则抛UNSUPPORTED
 * @returns regionValided
 */
function* assureSelect({ selector, selectors, types }: RegionDuck) {
  const list = selectors.list(yield select());
  const { id } = yield select(selector);
  // 列表为空，当前地域肯定有问题
  if (!list?.length) {
    return false
  }
  // 列表中找得到，有效
  if (list?.some(region => region.value == id)) {
    return true
  }
  // 列表中找不到时，自动选第一项
  const autoSelectRegion = list[0]
  if (!autoSelectRegion) {
    return false
  }
  if (id > 0) {
    yield put({
      type: types.UNSUPPORTED,
      payload: id
    });
  }
  yield put({
    type: types.SELECT,
    payload: autoSelectRegion.regionId
  });
  return true

}

/**
 * 地域选择逻辑
 *
 * 代码参考模板：http://code.qcm.oa.com/?tpl=gridpage&addons=region&patchOnly=1
 */
export default class RegionDuck extends DuckMap {
  /**
   * 组合白名单，例如：
   *  - [1,2,3] + [3,4,5] = [3]
   *  - [1,2,3] + [] = [1,2,3]
   *  - [1,2,3] + [4,5] = [null]
   *
   * 注意，这里白名单为空时表示不启用，即全放通。所以如果要表达一个地域都没有，请使用 [null]
   *
   * 可以使用reduce，例如： whiteLists.reduce(RegionDuck.combineWhiteLists)
   */
  static combineWhiteLists(whiteList1: number[], whiteList2: number[]) {
    if (!whiteList1?.length) {
      return whiteList2
    }
    if (!whiteList2?.length) {
      return whiteList1
    }
    // 两个列表不为空

    // 两个列表不为空
    const map = new Set(whiteList2)
    const finalWhiteList = whiteList1.filter(v => map.has(v))
    if (!finalWhiteList.length) {
      return [null]
    }
    return finalWhiteList
  }
  // 获取业务key，如果存在走新逻辑，如果不存在走旧逻辑 默认为空
  get product(): string {
    return null
  }
  Item: Region;
  get quickTypes() {
    return {
      ...super.quickTypes,
      ...Types
    };
  }
  get reducers() {
    const { types } = this;
    return {
      ...super.reducers,
      /** 当前选中的地域id */
      id: reduceFromPayload<number>(types.SELECT, +persistence.getRegionId()),
      /** 当前帐号能访问到的地域列表 */
      fullList: reduceFromPayload<this['Item'][]>(types.SET_FULL_LIST, []),
      /** 业务自己的地域白名单 */
      whiteList: reduceFromPayload<number[]>(types.SET_WHITELIST, []),
      /** 是否完成了初始加载，即白名单、地域列表都加载完毕 */
      initialLoaded: reduceFromPayload<boolean>(types.SET_INITIAL_LOAD, false),
      /** 是否已经ready，即白名单、地域列表都加载完毕，地域约束成功（如果不支持，自动切换到其它地域） */
      initialized: (state = false, action) => {
        switch (action.type) {
          case types.INITIALIZED:
            return true;
          default:
            return state;
        }
      }
    };
  }
  get creators() {
    const { types } = this;
    return {
      ...super.creators,
      select: (regionId: number | string) => ({
        type: types.SELECT,
        payload: parseInt(regionId as string, 10) || persistence.getRegionId()
      }),
      setWhiteList: createToPayload<number[]>(types.SET_WHITELIST)
    };
  }
  get rawSelectors() {
    type State = this['State'];
    return {
      ...super.rawSelectors,
      id: ({ id }: State) => id,
      list: ({ fullList, whiteList }: State) => {
        return fullList.filter(region => {
          return !whiteList.length || whiteList.indexOf(region.value) >= 0;
        });
      },
      selected: ({ fullList, id }: State) => {
        return fullList.find(item => item.value === id);
      }
    };
  }
  /**
   * 当没有可用地域时，仍达成 initialized 状态。
   *
   * 为兼容旧逻辑设计，默认为 true。
   * 关闭后，如果没有可用地域，不会触发initialized状态
   */
  get keepInitializedWhenNoValid() {
    return true
  }
  *saga() {
    if (!buildConfig.showRegion) {
      return;
    }
    yield* super.saga();
    yield fork([this, this.sagaSyncCookieWatch]);
    yield all([
      call([this, this.sagaLoadWhiteList]),
      call([this, this.sagaInitLoad])
    ]);
    yield put({ type: this.types.SET_INITIAL_LOAD, payload: true })
    // 如果确保选中后，当前地域仍不在可选列表中，表示未能初始化完成
    yield* this.sagaAssureSelection();
  }
  /**
   * 等待地域初始化完毕
   */
  public *initialized() {
    if (!buildConfig.showRegion) {
      return;
    }
    const { types, selector } = this;
    const { initialized } = selector(yield select());
    if (!initialized) {
      yield take(types.INITIALIZED);
    }
  }
  // 同步localStorage
  *sagaSyncCookieWatch(duck = this) {
    const { options, types } = duck;
    if (duck.syncCookie) {
      yield takeEvery(types.SELECT, function* ({ payload: regionId }) {
        if (+regionId) {
          persistence.setRegionId(regionId);
        }
      });
    }
  }
  // 预定白名单
  *sagaLoadWhiteList(duck = this) {
    const { creators, getWhiteList } = duck;
    const whiteList: number[] = yield call(getWhiteList, duck);
    if (whiteList && whiteList.length) {
      yield put(creators.setWhiteList(whiteList));
    }
  }
  // 确保选中
  *sagaAssureSelection(duck = this) {
    let firstLoad = true
    // 如果确保选中后，当前地域仍不在可选列表中，表示未能初始化完成
    yield runAndTakeLatest(duck.selectionTypes, function* () {
      // 地域列表和白名单都加载完成后才算初始化完成
      const regionValided = yield* assureSelect(duck);
      const { initialized } = duck.selector(yield select())
      if ((regionValided || duck.keepInitializedWhenNoValid) && !initialized) {
        yield put({ type: duck.types.INITIALIZED });
      }
      if (firstLoad && !regionValided) {
        yield put({ type: duck.types.NO_VALID_REGION })
      }
      firstLoad = false
    })
  }
  /** 哪些ActionType会影响地域列表选中，它们将会触发选择约束 */
  get selectionTypes() {
    const { types } = this;
    return [types.SET_FULL_LIST, types.SET_WHITELIST, types.SELECT];
  }
  // 初始加载
  *sagaInitLoad(duck = this) {
    const { types } = duck;
    let list = yield* resolvePromise(duck.fetchRegion(this))

    /**
     * 如果有白名单叠加，需要添加白名单调试
     * 支持简单的调试，例如临时开启某个地域灰度：
      ```javascript
      devmode?.enter() // 仅在开发模式下生效
      sessionStorage.DEBUG_REGIONS = JSON.stringify({'regionIds': ['78']})
      ```
    */
    if (
      window.sessionStorage &&
      (!window['devmode'] || window['devmode'].getStatus() === 'on')
    ) {
      const debugPatchStr = sessionStorage.getItem('DEBUG_REGIONS')
      try {
        const debugPatchRegions = JSON.parse(debugPatchStr)

        if (debugPatchRegions) {
          const regionAllList = yield* resolvePromise(OnceDescribeRegionsAndZones())
          const debugPatchsList = regionAllList.filter(o=>debugPatchRegions?.regionIds?.includes(o.RegionId))?.map(o=>( {
            area: o.Location,
            name: o.RegionName,
            regionId: Number(o.RegionId),
            value: Number(o.RegionId),
            /**
             * api v3 region: ap-guangzhou
             */
            region: o.Region,
            oversea: false,
          }))

        list = list?.concat((debugPatchsList||[]) as any)
         
        }
      } catch (e) { }
    }
   
    yield put({
      type: types.SET_FULL_LIST,
      payload: list
    });
  }
  /** 
   * 是否同步到localStorage/cookie中，保证切换页面也能保持地域。默认为true，可重写
   * 
   * 公有云不需要再额外写入存储，这里平台组件会进行处理，duck中写入会与tea冲突导致“地域灰度发布”有兼容性问题，建议业务公有云场景设置为 false
   * 
   * 私有化场景由于平台未处理存储，因而仍需要保留，默认为true
   */
  get syncCookie(): boolean {
    return true;
  }
  /**
   * 加载地域列表（完整的）
   * @param duck
   */
  @cacheable
  async fetchRegion(duck?: this): Promise<this['Item'][]> {
    if (this.product) {
      return await queryRegionSystemInfo(this.product)
        
    }
    return buildConfig.usePlatformRegions
      ? await queryRegionViaConsole()
      : await queryRegionViaQcbase();
  }
  /**
   * 获取业务地域白名单
   * @param duck
   */
  *getWhiteList(duck: this): any {
    return [];
  }
  /**
   * 与RouteDuck配合时使用
   */
  getRouteParam(o: Partial<PageParam> = {}): PageParam<number> {
    const regionDuck = this;
    return {
      key: 'regionId',
      route: 'rid',
      history: true,
      order: -2,
      // 注意，如果开启了RouteParam，则此处defaults会更优先
      defaults: () => persistence.getRegionId() || '',
      alwaysVisible: true,
      parse: v => parseInt(v, 10) || 1,
      type: regionDuck.types.SELECT,
      selector: regionDuck.selectors.id,
      creator: regionDuck.creators.select,
      ...o
    };
  }
}

export interface Region {
  area?: string;
  name: string;
  regionId: number;
  value: number;
  /**
   * api v3 region: ap-guangzhou
   */
  region?: string;
  oversea?: boolean;
}

interface OrderedRegionList {
  data: Array<{ id: number; value: string }>;
}
