// 获取用户能访问的地域列表
import { t, Trans } from '@tencent/tea-app/lib/i18n';
import { Region } from './';

// qcbase服务，由cvm团队维护
export default async function queryRegionViaQcbase() {
  const iaas = seajs.require('models/iaas');
  const util = seajs.require('util');
  let constants = seajs.require('constants');

  //私有云兼容
  constants = constants || {
    REGIONNAMES: {
      1: t('广州')
    },
    REGIONIDMAP: {
      1: 'ap-guangzhou'
    }
  };
  const regionList = constants.REGIONNAMES;
  interface Result {
    regionList: {
      area: string; // 华南地区
      isOverSea: boolean; // false
      region: string; // ap-guangzhou
      regionId: number; // 1
      regionName: string; // 广州
      regionShortName: string; // gz
    }[];
  }
  const result = await iaas.request<Result>(
    '/cgi/area?action=queryConsoleRegion&uin=' + util.getUin(),
    {}
  );
  return result.regionList.map<Region>(region => {
    let regionId = parseInt(region.regionId as any, 10);
    return {
      area: region.area,
      name: region.regionName || regionList[regionId],
      value: regionId,
      regionId,
      region: region.region,
      oversea: region.isOverSea
    };
  });
}
