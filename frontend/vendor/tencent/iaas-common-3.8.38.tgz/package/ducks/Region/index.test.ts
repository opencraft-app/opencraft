import { DuckRuntime } from 'saga-duck'
import { delay } from 'redux-saga-catch'
import { select, take, call, fork, put } from 'redux-saga/effects'
import Duck, { Region } from '.'


function genRegion(rid: number): Region {
  return {
    regionId: rid,
    name: `Region-${rid}`,
    value: rid
  }
}
function genRegions(list: number[]) {
  return list.map(genRegion)
}

describe('ducks/Region', () => {
  it('unsupported', cb => {
    class Test extends Duck {
      async fetchRegion() {
        await delay(100)
        const list: Region[] = [
          {
            region: 'test',
            regionId: 2,
            name: 'test',
            value: 2
          }
        ]
        return list
      }
      async getWhiteList() {
        await delay(100)
        return [2]
      }
    }
    const duck = new Test()
    const runtime = new DuckRuntime(duck)
    runtime.addSaga([
      function* () {
        let state = duck.selector(yield select())
        expect(state.id).toBe(1)
        yield take(duck.types.UNSUPPORTED)
        // UNSUPPORTED后才会重新SELECT
        yield delay(10)
        state = duck.selector(yield select())
        expect(state.id).toBe(2)
        cb()
        setTimeout(() => {
          runtime.destroy()
        })
      }
    ])
  })
  it('initialized', cb => {
    let regionFetched = false
    let whiteListFetched = false
    class Test extends Duck {
      async fetchRegion() {
        regionFetched = true
        await delay(100)
        return genRegions([])
      }
      async getWhiteList() {
        whiteListFetched = true
        await delay(200)
        return []
      }
    }
    const duck = new Test()
    const runtime = new DuckRuntime(duck)
    runtime.addSaga([
      function* () {
        let state = duck.selector(yield select())
        expect(state.initialized).toBe(false)
        yield* duck.initialized()
        expect(regionFetched).toBe(true)
        expect(whiteListFetched).toBe(true)
        state = duck.selector(yield select())
        expect(state.initialized).toBe(true)
        cb()
        setTimeout(() => {
          runtime.destroy()
        })
      }
    ])
  })

  it('当没有可用地域时，初始化不成功', cb => {
    class Test extends Duck {
      get keepInitializedWhenNoValid() {
        return false
      }
      async fetchRegion(): Promise<Region[]> {
        await delay(10)
        return genRegions([1, 2])
      }
      async getWhiteList() {
        await delay(10)
        return [3]
      }
    }
    const duck = new Test()
    const runtime = new DuckRuntime(duck)
    runtime.addSaga([
      function* () {
        // 没有可用地域，未初始化完成
        let noValidRegionFired = false
        yield fork(function* () {
          yield take(duck.types.NO_VALID_REGION)
          noValidRegionFired = true
        })
        yield delay(100)
        let state = duck.selector(yield select())
        expect(state.initialized).toBe(false)
        expect(noValidRegionFired).toBe(true)

        // 动态变更后，应自动选中并初始化完成
        yield put(duck.creators.setWhiteList([1]))
        let inited = false
        yield fork(function* () {
          yield* duck.initialized()
          inited = true
        })
        yield delay(10)
        expect(inited).toBe(true)

        cb()
        setTimeout(() => {
          runtime.destroy()
        })
      }
    ])
  })
  it('当存在getOpertionKey时', cb => {
    class Test extends Duck {
      get product() {
        return 'ckafka'
      }
      async fetchRegion(): Promise<Region[]> {
        if (this.product) {
          expect(this.product).toBe('ckafka')
          await delay(100)
          const list: Region[] = [
            {
              region: 'test',
              regionId: 2,
              name: 'test',
              value: 2
            }
          ]
          return list
        }
      }
      async getWhiteList() {
        await delay(10)
        return [2]
      }
    }
    const duck = new Test()
    const runtime = new DuckRuntime(duck)
    runtime.addSaga([
      function* () {

        let state = duck.selector(yield select())
        expect(state.id).toBe(1)
        yield take(duck.types.UNSUPPORTED)
        yield delay(10)
        state = duck.selector(yield select())
        expect(state.id).toBe(2)
        cb()
        setTimeout(() => {
          runtime.destroy()
        })
      }
    ])
  })
  it('白名单整合', () => {
    const expects = [
      [[1, 2, 3], [3, 4, 5], [3]],
      [[1, 2, 3], [], [1, 2, 3]],
      [[], [1, 2, 3], [1, 2, 3]],
      [[1, 2, 3], [4, 5], [null]],
      [[], [], []],
      [[null], [], [null]],
      [[null], [1], [null]]
    ]
    for (const [list1, list2, result] of expects) {
      expect(Duck.combineWhiteLists(list1, list2)).toStrictEqual(result)
    }
    // 可直接reduce整合
    expect([
      [1, 2, 3],
      [2, 3, 4],
      [3, 4, 5]
    ].reduce(Duck.combineWhiteLists)).toStrictEqual([3])
  })
})
