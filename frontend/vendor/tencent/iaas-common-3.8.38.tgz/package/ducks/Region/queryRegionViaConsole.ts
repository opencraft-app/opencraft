import { t, Trans } from '@tencent/tea-app/lib/i18n';
import { Region } from './';

// 平台服务，以前是cvm维护，现公有云已不再维护，但TCE还在使用
export default async function queryRegionViaConsole() {
  const manager = seajs.require('models/manager');
  const appUtil: any = seajs.require('appUtil');
  let constants = seajs.require('constants');

  //私有云兼容
  constants = constants || {
    REGIONNAMES: {
      1: t('广州')
    },
    REGIONIDMAP: {
      1: 'ap-guangzhou'
    }
  };
  const regionList = constants.REGIONNAMES;
  const regionIdV3Map = constants.REGIONIDMAP;
  interface Result {
    regionList: {
      area: string; // 华南地区
      region: string; // ap-guangzhou
      regionId: number; // 1
      regionName: string; // 广州
    }[];
  }
  interface Result {
    // 1: 华南地区（广州）
    [regionId: number]: string;
  }
  const regionMap = await new Promise<Result>((resolve, reject) => {
    manager.queryRegion(resolve, reject);
  });
  const list: Region[] = [],
    sortData = appUtil.getRegionOrderHackObj(regionMap);

  for (let prop in sortData) {
    let regionId = parseInt(prop.replace('_', ''), 10);
    list.push({
      name: regionList[regionId] || regionMap[regionId],
      value: regionId,
      regionId,
      region: regionIdV3Map[regionId]
    });
  }
  return list;
}
