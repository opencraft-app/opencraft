// 获取用户能访问的地域列表
import { t, Trans } from '@tencent/tea-app/lib/i18n';
import { DescribeRegionZone } from '../../models/location';
import buildConfig from '../../buildConfig';
import { Region } from './';
import apiRequest from '../../models/apiRequest';

export default async function queryRegionSystemInfo(product: string) {
  const data = {
    action: 'DescribeRegions',
    serviceType: 'region',
    regionId: 1,
    data: Object.assign(
      {
        Product: product,
        Version: "2022-06-27"
      },
    )
  }
  if (buildConfig.usePlatformRegions) {
    const result = await DescribeRegionZone(undefined, { ProductId: product.toUpperCase() })
    return result.RegionSet.filter((r) => r.RegionState === 'AVAILABLE').map((r) => ({
      regionId: +r.RegionID,
      value: +r.RegionID,
      name: r.RegionName,
      region: r.Region,
    }))
  }
  const { Response: result } = await apiRequest<{ Response: Result }>(data, {
    classicResponse: false
  })
  return result.RegionSet.map<Region>(region => {
    let regionId = parseInt(region.RegionIdMC as any, 10);
    return {
      area: region.LocationMC,
      name: region.RegionNameMC,
      value: regionId,
      regionId,
      region: region.Region,
      oversea: !!region.RegionTypeMC
    };
  });
}
interface Result {
  RegionSet: {
    LocationMC: string
    Region: string
    RegionIdMC: string
    RegionName: string
    RegionNameMC: string
    RegionState: string
    RegionTypeMC: number
  }[]

}
