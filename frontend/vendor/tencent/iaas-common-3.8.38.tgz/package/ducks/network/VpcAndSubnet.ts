import { runAndWatchLatest, watchLatest } from '../../helpers/saga'
import { takeLatest } from 'redux-saga-catch'
import { put, select } from 'redux-saga/effects'
import { ComposableDuck, createToPayload, reduceFromPayload } from 'saga-duck'
import SubnetSelect from './SubnetSearchableSelect'
import VpcSelect from './VpcSearchableSelect'

export interface NetworkSelectorOptions {
  regionId: number
  /** 指定可用区，用于限制子网，需要v3格式（子网请求接口限制） */
  zoneV3Id?: string
  /** 是否支持子网，如果不支持，则子网逻辑不启用 */
  supportSubnet?: boolean
  /** 如果没有选，是否自动选中第一项可用。默认为true TODO 与自定义可用状态有关联 */
  autoSelect?: boolean
  /** TODO 自定义选项可用状态 */
  // TODO IP数量限制 needSubnetIpCount
  // TODO 未来可以考虑把基础网络/私有网络的选项整合进来，即：
  /** 是否支持基础网络，默认为false */
  // supportBaseNetwork?: boolean
}
export interface SelectorStatus {
  loading: boolean
  vpc: {
    loading: boolean,
    error: any
    empty: boolean
  },
  subnet: {
    loading: boolean,
    error: any
    empty: boolean
  }
}
export default class NetworkSelectorDuck extends ComposableDuck {
  get quickTypes() {
    enum Types {
      LOAD,
      SET_OPTIONS
    }
    return {
      ...super.quickTypes,
      ...Types
    }
  }
  get reducers() {
    const { types } = this
    return {
      ...super.reducers,
      options: reduceFromPayload<NetworkSelectorOptions>(types.SET_OPTIONS, null)
    }
  }
  get rawSelectors() {
    type State = this['State']
    return {
      ...super.rawSelectors,
      status: (state: State): SelectorStatus => {
        const { vpc, subnet } = state
        return {
          loading: vpc.fetcher.loading || subnet.fetcher.loading,
          vpc: {
            loading: vpc.fetcher.loading,
            error: vpc.fetcher.error,
            empty: !vpc.fetcher.loading && !vpc.fetcher.error && vpc.totalCount === 0,
          },
          subnet: {
            loading: subnet.fetcher.loading,
            error: subnet.fetcher.error,
            empty: !subnet.fetcher.loading && !subnet.fetcher.error && subnet.totalCount === 0

          }
        }
      }
    }
  }
  get creators() {
    const { types } = this
    return {
      ...super.creators,
      /** 逻辑启动入口，开启参数监听及加载 */
      load: () => ({ type: types.LOAD }),
      /** 动态更新参数 */
      setOptions: createToPayload<NetworkSelectorOptions>(types.SET_OPTIONS),
    }
  }
  get quickDucks() {
    return {
      ...super.quickDucks,
      vpc: VpcSelect,
      subnet: SubnetSelect,
    }
  }
  * saga() {
    yield* super.saga()

    const duck = this
    const { types, selector } = this
    yield takeLatest(types.LOAD, function* () {
      yield* duck.load()
    })
  }
  // // TODO 更好的扩展方式？感觉rxjs更合适
  // protected *getVpcOptionsChannel() {
  //   const {
  //     types,
  //     selector,
  //     creators,
  //     ducks: { vpc, subnet },
  //   } = this
  //   const chan: Channel<VpcOptions> = yield channel()
  //   yield runAndWatchLatest(
  //     types.SET_OPTIONS,
  //     g => {
  //       const { options } = selector(g)
  //       if (!options) {
  //         return null
  //       }
  //       return {
  //         regionId: options.regionId
  //       }
  //     },
  //     function* (vpcOptions) {
  //       yield put(chan, vpcOptions)
  //     }
  //   )
  // }
  * load(options?: NetworkSelectorOptions) {
    const duck = this
    const {
      types,
      selector,
      creators,
      ducks: { vpc },
    } = this
    if (options) {
      yield put(creators.setOptions(options))
    }
    // VPC加载
    yield runAndWatchLatest(
      types.SET_OPTIONS,
      g => {
        const { options } = selector(g)
        if (!options) {
          return null
        }
        return {
          regionId: options.regionId
        }
      },
      function* (vpcOptions) {
        // 必要参数不齐，不加载
        if (!vpcOptions) {
          return
        }
        yield* vpc.load(vpcOptions)
      }
    )
    // 子网加载
    yield runAndWatchLatest(
      types.SET_OPTIONS,
      g => {
        const { options } = selector(g)
        return options?.supportSubnet !== false
      },
      function* (subnetEnabled) {
        // 子网未启用，不执行
        if (!subnetEnabled) {
          return
        }
        yield* duck.loadSubnet()
      }
    )

  }

  * loadSubnet() {
    const {
      types,
      selector,
      creators,
      ducks: { vpc, subnet },
    } = this
    // 子网加载

    yield runAndWatchLatest(
      [types.SET_OPTIONS, vpc.types.SELECT],
      g => {
        const { options, vpc: { id: vpcId } } = selector(g)
        if (!options || !vpcId) {
          return null
        }
        return {
          regionId: options.regionId,
          zoneV3Id: options.zoneV3Id,
          vpcId
        }
      },
      function* (subnetOptions) {
        // 必要参数不齐，不加载
        if (!subnetOptions) {
          return
        }
        yield* subnet.load(subnetOptions)
      },
    )
    // 切换VPC及可用区时，自动重置子网
    yield watchLatest([types.SET_OPTIONS, vpc.types.SELECT], g => {
      const { vpc: { id: vpcId }, options } = selector(g)
      return {
        vpcId,
        zoneV3Id: options?.zoneV3Id
      }
    }, function* () {
      yield put(subnet.creators.select(''))
    })
  }
}