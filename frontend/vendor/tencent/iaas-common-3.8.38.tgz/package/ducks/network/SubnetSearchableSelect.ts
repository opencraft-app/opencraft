import Base from '../SearchableSelect'
import * as vpc from '../../models/vpc';

export interface Param {
  regionId: number
  zoneV3Id?: string
  vpcId: string
}
export default class SubnetSearchableSelect extends Base {
  declare Param: Param
  declare Item: vpc.Subnet
  getId(o: this['Item']) {
    return o.SubnetId
  }
  get pageSize() {
    return 100
  }
  async getData(filter: this['GetDataParam']) {
    const { regionId, zoneV3Id, vpcId, offset, limit, keyword } = filter

    const params: vpc.DescribeSubnetsParams = {
      Offset: String(offset),
      Limit: String(limit),
      Filters: [
        {
          Name: 'vpc-id',
          Values: [vpcId]
        }
      ]
    }

    if (zoneV3Id) {
      params.Filters.push({
        Name: 'zone',
        Values: [zoneV3Id]
      })
    }

    if (keyword) {
      if (/^subnet-\w{8}$/.test(keyword)) {
        params.Filters.push({
          Name: 'subnet-id',
          Values: [keyword]
        })
      } else {
        params.Filters.push({
          Name: 'subnet-name',
          Values: [keyword]
        })
      }
    }

    const { SubnetSet, TotalCount } = await vpc.DescribeSubnets(regionId, params);
    return {
      totalCount: TotalCount,
      list: SubnetSet
    }
  }
}