import Base from '../SearchableSelect'
import * as vpc from '../../models/vpc';

export interface Param {
  regionId: number
}
export default class VpcSearchableSelect extends Base {
  declare Param: Param
  declare Item: vpc.Vpc
  getId(o: this['Item']) {
    return o.VpcId
  }
  get pageSize() {
    return 100
  }
  async getData(filter: this['GetDataParam']) {
    const { regionId, offset, limit, keyword } = filter

    const params: vpc.DescribeVpcsParams = {
      Offset: String(offset),
      Limit: String(limit),

    }

    if (keyword) {
      params.Filters = []
      if (/^vpc-\w{8}$/.test(keyword)) {
        params.Filters.push({
          Name: 'vpc-id',
          Values: [keyword]
        })
      } else {
        params.Filters.push({
          Name: 'vpc-name',
          Values: [keyword]
        })
      }
    }

    const { VpcSet, TotalCount } = await vpc.DescribeVpcs(regionId, params);
    return {
      totalCount: TotalCount,
      list: VpcSet
    }
  }
}