import Base from './DialogPure'
import { select, put, call } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga-catch'
import { isCamRefused } from '../components/Cam'
/**
 * 与DialogPure不同的是，自带保存，不再推荐使用，还是DialogPure比较清晰
 * @deprecated
 */
export default abstract class Dialog extends Base {
  /** 点击提交后执行的操作 */
  abstract save(values: this['SubmitData'], data: this['Data']): Promise<any>
  *sagaSubmitWatch() {
    const duck = this
    const { types, options, selectors, creators } = this
    // 提交
    yield takeLatest([types.SUBMIT], function*(action) {
      const data = yield select(selectors.data)
      try {
        yield call([duck, duck.save], action.payload, data)
        yield put({ type: types.SUBMIT_DONE })
        // 默认完成后都关闭
        yield put(creators.hide())
      } catch (e) {
        // 提示错误
        //tips.error(e.message || e.errorMsg)
        yield put({ type: types.SUBMIT_FAIL, payload: e })
        isCamRefused(e) ? yield put({ type: types.HIDE }) : null
      }
    })
  }
}

// 测试/示例代码
if (process.env.NEVER_RUN) {
  class Foo extends Dialog {
    Data: {
      domain: string
    }
    async save(submitData: this['SubmitData'], data: this['Data']){
      console.log(data.domain)
    }
  }
  const foo = new Foo()
  foo.selector(null).submitting
}
