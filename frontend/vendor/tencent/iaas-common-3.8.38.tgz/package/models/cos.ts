
/*
[{
    "Name": "backup-1251326374",
    "Location": "ap-shanghai",
    "CreationDate": "2018-01-18T15:11:22Z"
}]
*/
import apiRequest from './apiRequest';

export interface CosBucket {
  Name: string
  Location: string
  CreationDate: string
}
export interface CosBucketPath extends CosBucket {
  Path?: string
}

/** cos bucket对应的域名 */
export function getCosHost(bucket: CosBucket) {
  return `${bucket.Name}.cos.${bucket.Location}.myqcloud.com`
}

export function parseCosHost(host: string): CosBucketPath {
  const [, Name, Location, Path] = String(host).match(
    /^(.*).cos.([a-z0-9\-]+).myqcloud.com(\/.*)?$/
  )
  return {
    Name,
    Location,
    CreationDate: null,
    Path
  }
}

// /** cos控制台跳转链接里的region映射 */
// export const COS_REGION_ID_MAP = {
//   'ap-shanghai': 1, // 上海 华东
//   'ap-guangzhou': 2, // 广州 华南
//   'ap-beijing-1': 3, // 北京一区 华北
//   'ap-singapore': 4, // 新加坡
//   'ap-chengdu': 5, //, // 成都 西南
//   'ap-hongkong': 6, // 香港
//   'na-toronto': 7, // 多伦多
//   'eu-frankfurt': 8, // 法兰克福
//   'ap-beijing': 9
// }

/** cos控制台跳转链接 */
export function getCosConsoleLink(
  bucket: CosBucket,
  path: string = '',
  from: string = ''
) {
  const [, bucketName, appId] = bucket.Name.match(/^(.*)\-(\d+)$/)
  // const regionId = COS_REGION_ID_MAP[bucket.Location]
  // 路径以`/`起始与结尾
  if (path) {
    if (!/^\//.test(path)) {
      path = '/' + path
    }
    if (!/\/$/.test(path)) {
      path = path + '/'
    }
    path = encodeURIComponent(path)
  }
  // 2018-08-13 update cos已提供兼容链接，统一使用cos5地址
  // // 目前cos未提供通用接口，所以先尝试使用cos4链接，如果地域没有配置映射则使用cos5
  // if (regionId) {
  //   // cos4
  //   return `/cos4/bucket/setting?type=filelist&appid=${appId}&bucketName=${bucketName}&path=${path}&region=${regionId}`
  // }
  return `/cos5/bucket/setting?type=filelist&bucketName=${
    bucket.Name
  }&path=${path}&region=${bucket.Location}&_from=${from}`
}

interface BucketResult {
  Buckets: Array<CosBucket>
  TotalCount: number
}

export async function ListBuckets(regionId: number) {
  const data = {
    action: 'ListBuckets',
    serviceType: 'cos',
    regionId,
    data: Object.assign(
      {
        Version: '2021-02-24'
      },
    )
  }
  const result = await apiRequest<{ Response: BucketResult }>(data, {
    classicResponse: false
  })
  return result.Response
}


/** 
 * @deprecated ⚠️废弃
 */
export async function headBucket(
  param: headBucketParams,
  opts?: APIRequestOpts
) {
  const data = await seajs.require('models/iaas').request<headBucketResult>(
    '/cgi/cos',
    {
      action: 'headBucket',
      data: param
    },
    opts
  )
  return data
}
export interface headBucketParams {
  Bucket: string
  Region: string
}
export interface headBucketResult {}


/** 
 * @deprecated ⚠️废弃
 */
export async function putBucketACL(
  param: putBucketACLParams,
  opts?: APIRequestOpts
) {
  const data = await seajs.require('models/iaas').request<putBucketACLResult>(
    '/cgi/cos',
    {
      action: 'putBucketACL',
      data: param
    },
    opts
  )
  return data
}
export interface putBucketACLParams {
  /** qcs::cam::uin/${uin}:uin/${uin} */
  GrantFullControl: string
  Bucket: string
  Region: string
}
export interface putBucketACLResult {}


/** 
 * @deprecated ⚠️废弃，可以使用ListBuckets替代
 */
export async function getService(opts?: APIRequestOpts) {
  const data = await seajs.require('models/iaas').request<getServiceResult>(
    '/cgi/cos',
    {
      action: 'getService',
      data: {}
    },
    opts
  )
  return data
}
export interface getServiceResult {
  Buckets: CosBucket[]
}

// --------- TODO 模板
/** 
 * @deprecated ⚠️废弃
 */
export async function DescribeExample(
  regionId: number,
  param: DescribeExampleParams,
  opts?: APIRequestOpts
) {
  const data = await seajs.require('models/iaas').request<DescribeExampleResult>(
    '/cgi/cos',
    {
      action: 'DescribeExample',
      regionId,
      data: param
    },
    opts
  )
  return data
}
export interface DescribeExampleParams {}
export interface DescribeExampleResult {}
