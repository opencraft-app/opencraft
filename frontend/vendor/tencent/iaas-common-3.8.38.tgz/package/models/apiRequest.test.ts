describe('models/apiRequest', () => {
  it('能正常解析', cb => {
    expect(require('./apiRequest')).toStrictEqual(
      require('@tencent/iaas-common/inject/apiRequest')
    )
    cb()
  })
})
