import { Children, useEffect, useState } from 'react'
import { once } from '../helpers/cacheable'
import apiRequest from './apiRequest'
import React from 'react'
import { LoadingTip } from '@tencent/tea-component'

// 查询地域全集
export async function DescribeRegionsAndZones() {
  const data = {
    action: 'DescribeRegionsAndZones',
    serviceType: 'region',
    regionId: 1,
    data: Object.assign({
      Version: '2022-06-27'
    })
  }

  const { Response: result } = await apiRequest<{ Response: Result }>(data, {
    classicResponse: false
  })
  return result.ResourceRegionSet
}

export const OnceDescribeRegionsAndZones = once(DescribeRegionsAndZones)

interface Result {
  ResourceRegionSet: ResourceRegionSet[]
}

interface ResourceRegionSet {
  ProductWhiteList: string
  RegionNameJp: string
  Weight: number
  InnerDomainName: string
  OnlineState: string
  RegionState: string
  RegionTypeMC: number
  Region: string
  RegionId: string
  RegionNameEn: string
  LocationJp: string
  RegionType: string
  RegionShortName: string
  LocationKo: string
  LocationEn: string
  OuterDomainName: string
  Location: string
  RegionNameKo: string
  RegionName: string
  ResourceZoneSet: ResourceZoneSet[]
}

interface ResourceZoneSet {
  ProductWhiteList: string
  ZoneNameEn: string
  Weight: number
  Zone: string
  OnlineState: string
  SaleType: string
  WhiteList: string
  ZoneId: string
  ZoneState: string
  MachineRoomType: string
  ZoneNameJp: string
  LifeState: string
  ZoneNameKo: string
  ZoneName: string
}

interface RegionConstants {
  /** REGIONMAP['1'] = 'gz' */
  REGIONMAP: Record<string, string>
  /** REGIONIDMAP['1'] = 'ap-guangzhou' */
  REGIONIDMAP: Record<string, string>
  /** ZONEIDMAP['100002'] = 'ap-guangzhou-2' */
  ZONEIDMAP: Record<string, string>
  /** ZONENAMEMAP['100002'] = '广州二区' */
  ZONENAMEMAP: Record<string, string>
  /** REGIONNAMES['1'] = '广州' */
  REGIONNAMES: Record<string, string>
  /** ZONETOREGIONMAP['100002'] = 1 */
  ZONETOREGIONMAP: Record<string, number>
  /** ZONETOREGIONMAPV3['100002'] = 'ap-guangzhou' */
  ZONETOREGIONMAPV3: Record<string, string>

  /** ZONEIDV3TONAMEMAP['ap-guangzhou-2'] = '广州二区' */
  ZONEIDV3TONAMEMAP: Record<string, string>

  /** REGIONAREAMAP['ap-guangzhou'] = {name:'广州',area:'华南地区'} */
  REGIONAREAMAP: Record<string, { name: string; area: string }>

  /** ZONEV3TOZONEIDMAP['ap-guangzhou-2'] = '100002' */
  ZONEV3TOZONEIDMAP: Record<string, string>
  REGIONORDER: Array<number>
  REGIONV3TOREGIONID: Record<string, string>
  REGIONV3TOREGIONNAME: Record<string, string>
}

interface RegionMaps {
  /** 1 => 'gz' */
  idToShortId: Record<number, string>
  /** 1 => '广州' */
  idToName: Record<number, string>
  /** 1 => 'ap-guangzhou' */
  idToV3Id: Record<number, string>
  /** 'ap-guangzhou' => 1 */
  v3IdToId: Record<string, number>
  /** 'ap-guangzhou' => {name:'广州',area:'华南地区'}  */
  v3IdToInfo: Record<string, { name: string; area: string }>
}

interface ZoneMaps {
  /** 100002 => '广州二区' */
  idToName: Record<number, string>
  /** 100002 => 'ap-guangzhou-2' */
  idToV3Id: Record<number, string>
  /** 100002 => 1 */
  idToRegionId: Record<number, number>
  /** 100002 => 'ap-guangzhou' */
  idToRegionV3Id: Record<number, string>
  /** ap-guangzhou-2 => '广州二区' */
  v3IdToName: Record<string, string>
  /** 'ap-guangzhou-2' = '100002' */
  v3IdToId: Record<string, string>
}

const RegionCache = {
  inited: false,
  regionConstants: {
    REGIONMAP: {},
    REGIONNAMES: {},
    REGIONIDMAP: {},
    REGIONAREAMAP: {},
    REGIONORDER: [],
    REGIONV3TOREGIONID: {},
    REGIONV3TOREGIONNAME: {},
    ZONEIDMAP: {},
    ZONEIDV3TONAMEMAP: {},
    ZONENAMEMAP: {},
    ZONETOREGIONMAP: {},
    ZONETOREGIONMAPV3: {},
    ZONEV3TOZONEIDMAP: {}
  } as RegionConstants,
  regionMap: {
    idToShortId: {},
    idToName: {},
    idToV3Id: {},
    v3IdToId: {},
    v3IdToInfo: {},
  } as RegionMaps,
  zoneMap: {
    idToName: {},
    idToV3Id: {},
    idToRegionId: {},
    idToRegionV3Id: {},
    v3IdToName: {},
    v3IdToId: {},
  } as ZoneMaps
}

async function initRegionCache() {
  const result = await OnceDescribeRegionsAndZones()
  const regionConstants: RegionConstants = {
    REGIONMAP: {},
    REGIONNAMES: {},
    REGIONIDMAP: {},
    REGIONAREAMAP: {},
    REGIONORDER: [],
    REGIONV3TOREGIONID: {},
    REGIONV3TOREGIONNAME: {},
    ZONEIDMAP: {},
    ZONEIDV3TONAMEMAP: {},
    ZONENAMEMAP: {},
    ZONETOREGIONMAP: {},
    ZONETOREGIONMAPV3: {},
    ZONEV3TOZONEIDMAP: {}
  }
  for (const key of result) {
    regionConstants.REGIONMAP[+key.RegionId] = key.RegionShortName
    regionConstants.REGIONNAMES[+key.RegionId] = key.RegionName
    regionConstants.REGIONIDMAP[+key.RegionId] = key.Region
    regionConstants.REGIONV3TOREGIONID[key.Region] = key.RegionId
    regionConstants.REGIONV3TOREGIONNAME[key.Region] = key.RegionName
    regionConstants.REGIONAREAMAP[key.Region] = {
      area: key.Location,
      name: key.RegionName
    }
    regionConstants.REGIONORDER.push(Number(key.RegionId))
    for (const zone of key?.ResourceZoneSet) {
      regionConstants.ZONEIDMAP[zone.ZoneId] = zone.Zone
      regionConstants.ZONEIDV3TONAMEMAP[zone.Zone] = zone.ZoneName
      regionConstants.ZONENAMEMAP[zone.ZoneId] = zone.ZoneName
      regionConstants.ZONETOREGIONMAP[zone.ZoneId] = +key.RegionId
      regionConstants.ZONETOREGIONMAPV3[zone.ZoneId] = key.Region
      regionConstants.ZONEV3TOZONEIDMAP[zone.Zone] = zone.ZoneId
    }
  }
  RegionCache.inited = true
  RegionCache.regionConstants = regionConstants

  RegionCache.regionMap={
     idToShortId: regionConstants?.REGIONMAP || {},
    idToName: regionConstants?.REGIONNAMES || {},
    idToV3Id: regionConstants?.REGIONIDMAP || {},
    get v3IdToId(){
      const v3IdToId = {}
      for(const [id, v3Id] of Object.entries(regionConstants?.REGIONIDMAP || {})){
        v3IdToId[v3Id] = +id
      }
      return v3IdToId
    },
    v3IdToInfo: regionConstants?.REGIONAREAMAP || {}
  }
  RegionCache.zoneMap = {
    idToName: regionConstants?.ZONENAMEMAP || {},
    idToV3Id: regionConstants?.ZONEIDMAP || {},
    idToRegionId: regionConstants?.ZONETOREGIONMAP || {},
    idToRegionV3Id: regionConstants?.ZONETOREGIONMAPV3 || {},
    v3IdToName: regionConstants?.ZONEIDV3TONAMEMAP || {},
    v3IdToId: regionConstants?.ZONEV3TOZONEIDMAP || {}
  }
}


// 异步获取REGIONMAP数据
export default async function getRegionConstants() {
  try {
    if (RegionCache.inited) {
      return RegionCache.regionConstants
    }
    await initRegionCache()
    return RegionCache.regionConstants
  } catch (error) {
    // 接口出错
    let constants = seajs?.require('constants') as RegionConstants
    if (!constants) {
      // 如果取不到，预期是专有云
      constants = getTceMockConstants()
    }
    return constants
  }
}

export function getTceMockConstants(): RegionConstants {
  try {
    const tceSdk = require('@tencent/tce-sdk')
    const regionList = tceSdk.region.getRegionListSync()
    const regionMap: RegionConstants = {
      REGIONMAP: {},
      REGIONNAMES: {},
      REGIONIDMAP: {},
      REGIONAREAMAP: {},
      REGIONORDER: [],
      REGIONV3TOREGIONID: {},
      REGIONV3TOREGIONNAME: {},
      ZONEIDMAP: {},
      ZONEIDV3TONAMEMAP: {},
      ZONENAMEMAP: {},
      ZONETOREGIONMAP: {},
      ZONETOREGIONMAPV3: {},
      ZONEV3TOZONEIDMAP: {}
    }
    for (const key of regionList) {
      regionMap.REGIONMAP[key.RegionId] = key.RegionShortName
      regionMap.REGIONNAMES[key.RegionId] = key.RegionName
      regionMap.REGIONIDMAP[key.RegionId] = key.Region
      regionMap.REGIONV3TOREGIONID[key.Region] = key.RegionId
      regionMap.REGIONV3TOREGIONNAME[key.Region] = key.RegionName
      regionMap.REGIONAREAMAP[key.Region] = {
        area: key.Location,
        name: key.Region
      }
      regionMap.REGIONORDER.push(Number(key.RegionId))
      for (const zone of key?.ResourceZoneSet) {
        regionMap.ZONEIDMAP[zone.ZoneId] = zone.Zone
        regionMap.ZONEIDV3TONAMEMAP[zone.Zone] = zone.ZoneName
        regionMap.ZONENAMEMAP[zone.ZoneId] = zone.ZoneName
        regionMap.ZONETOREGIONMAP[zone.ZoneId] = key.RegionId
        regionMap.ZONETOREGIONMAPV3[zone.ZoneId] = key.Region
        regionMap.ZONEV3TOZONEIDMAP[zone.Zone] = zone.ZoneId
      }
    }
    return regionMap
  } catch {}
}

export async function getRegionMaps() {
  if(RegionCache.inited){
    return RegionCache.regionMap
  }
  await initRegionCache()
 
  return RegionCache.regionMap
}
export async function getZoneMaps() {
  if(RegionCache.inited){
    return RegionCache.zoneMap
  }
  await initRegionCache()
  return RegionCache.zoneMap
}

/**
 * React hook 可以获取地域信息
 */
export function useRegionMaps() {
  const [, reload] = useState(Symbol())
  useEffect(() => {
    if (RegionCache.inited) {
      return
    }
    initRegionCache().then(() => {
      reload(Symbol())
    })
  }, [])
  return RegionCache.regionMap
}

/**
 * React hook 可以获取地域信息
 */
export function useZoneMaps() {
  const [, reload] = useState(Symbol())
  useEffect(() => {
    if (RegionCache.inited) {
      return
    }
    initRegionCache().then(() => {
      reload(Symbol())
    })
  }, [])
  return RegionCache.zoneMap
}

/**
 * 组件获取地域信息，地域请求中会展示 loading 状态
 * @param props 
 * @returns 
 */
export function RegionMap(props:{  
  loadingText?: string
  children: (regionMap: RegionMaps) => React.ReactNode
}){
  const {children,loadingText} = props
  const regionMap = useRegionMaps()
  if(!RegionCache.inited){
    return <LoadingTip loadingText={loadingText}/>
  }
  return <>{children(regionMap)}</>
}