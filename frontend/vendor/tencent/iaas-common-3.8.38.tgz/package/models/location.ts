// TCE地域统一
// 本文件由 http://git.code.oa.com/cluezhang/capi-ts 生成，请勿手工编辑

async function capiRequest<T = any, TParam = any>(
  regionId: number,
  action: string,
  param?: TParam,
  opts: APIRequestOpts = {}
) {
  const data = {
    action: action,
    serviceType: 'location',
    regionId: regionId,
    data: Object.assign(
      {
        Version: '2019-11-28',
        Language: seajs.require('lib/appUtil')?.getLanguage()
      },
      param
    )
  }
  const result = await seajs.require('models/iaas').apiRequest<{ Response: T }>(data, {
    ...opts,
    classicResponse: false
  })
  return result.Response
}

/** 查询地域/可用区信息. 集成: 1. 国际化; 2. 租户白名单; 3. 产品部署信息 */
export function DescribeRegionZone(
  regionId: number,
  params: DescribeRegionZoneParams,
  opts?: APIRequestOpts
) {
  return capiRequest<DescribeRegionZoneResult>(
    regionId,
    'DescribeRegionZone',
    params,
    opts
  )
}
/** **DescribeRegionZone入参**

查询地域/可用区信息. 集成: 1. 国际化; 2. 租户白名单; 3. 产品部署信息  */
export interface DescribeRegionZoneParams {
  /** TCE 产品Code */
  ProductId?: string
}
/** **DescribeRegionZone出参**

查询地域/可用区信息. 集成: 1. 国际化; 2. 租户白名单; 3. 产品部署信息 */
export interface DescribeRegionZoneResult {
  /** 地域数量 */
  RegionCount?: number

  /** 地域信息 */
  RegionSet?: RegionEx[]
}
/** DescribeRegionZone 返回的 Region 描述信息 */
export interface RegionEx {
  /** 地域名称(固定为英文字符串, API使用) */
  Region: string

  /** 地域编号 */
  RegionID: string

  /** 地域名称 */
  RegionName: string

  /** 地域状态(AVAILABLE/UNAVAILABLE) */
  RegionState: string

  /** 地域状态描述 */
  RegionStateRemark: string

  /** 可用区数量 */
  ZoneCount: number

  /** 可用区列表 */
  ZoneSet: ZoneEx[]
}
/** DescribeRegionZone 接口返回的 Zone 描述信息 */
export interface ZoneEx {
  /** 所属Region编号 */
  RegionID: string

  /** 可用区名称(固定为英文字符串, API使用) */
  Zone: string

  /** 可用区编号 */
  ZoneID: string

  /** 可用区名称(国际化支持, 前端展示使用) */
  ZoneName: string

  /** 可用区状态(AVAILABLE/UNAVAILABLE) */
  ZoneState: string

  /** 可用区状态(原因描述) */
  ZoneStateRemark: string
}
