import apiRequest from "./apiRequest"

async function capiRequest<T = any, TParam = any>(
  regionId: number,
  action: string,
  param?: TParam,
  opts: APIRequestOpts = {}
) {
  const data = {
    action: action,
    serviceType: 'cam',
    regionId: regionId,
    data: Object.assign(
      {
        Version: '2019-01-16'
      },
      param
    )
  }
  const result = await apiRequest<{ Response: T }>(data, {
    ...opts,
    classicResponse: false
  })
  return result.Response
}

/**
 * 本接口（GetRole）用于获取指定角色的详细信息。
 * @param regionId
 * @param param
 * @param opts
 */
export async function GetRole(
  regionId: number,
  param: GetRoleParams,
  opts?: APIRequestOpts
) {
  const data = await capiRequest<GetRoleResult>(
    regionId,
    'GetRole',
    param,
    opts
  )
  return data
}
export interface GetRoleParams {
  /**  角色 ID，用于指定角色，入参 RoleId 与 RoleName 二选一  */
  RoleId?: string
  /**  角色名，用于指定角色，入参 RoleId 与 RoleName 二选一  */
  RoleName?: string
}
export interface GetRoleResult {
  /**  角色详情  */
  RoleInfo: RoleInfo
  /**  唯一请求 ID，每次请求都会返回。定位问题时需要提供该次请求的 RequestId。  */
  RequestId: string
}
export interface RoleInfo {
  /**  角色ID  */
  RoleId: string
  /**  角色名称  */
  RoleName: string
  /**  角色的策略文档  */
  PolicyDocument: string
  /**  角色描述  */
  Description: string
  /**  角色的创建时间  */
  AddTime: string
  /**  角色的最近一次时间  */
  UpdateTime: string
  /**  角色是否允许登录  */
  ConsoleLogin: number
  /**  角色类型，取user或system
  注意：此字段可能返回 null，表示取不到有效值。  */
  RoleType: string
}

/**
 * 本接口（ListAttachedRolePolicies）用于获取角色绑定的策略列表。
 * @param regionId
 * @param param
 * @param opts
 */
export async function ListAttachedRolePolicies(
  regionId: number,
  param: ListAttachedRolePoliciesParams,
  opts?: APIRequestOpts
) {
  const data = await capiRequest<ListAttachedRolePoliciesResult>(
    regionId,
    'ListAttachedRolePolicies',
    param,
    opts
  )
  return data
}
export interface ListAttachedRolePoliciesParams {
  /**  页码，从 1 开始  */
  Page: number
  /**  每页行数，不能大于200  */
  Rp: number
  /**  角色 ID。用于指定角色，入参 RoleId 与 RoleName 二选一  */
  RoleId?: string
  /**  角色名。用于指定角色，入参 RoleId 与 RoleName 二选一  */
  RoleName?: string
  /**  按策略类型过滤，User表示仅查询自定义策略，QCS表示仅查询预设策略  */
  PolicyType?: string
}
export interface ListAttachedRolePoliciesResult {
  /**  角色关联的策略列表  */
  List: AttachedPolicyOfRole[]
  /**  角色关联的策略总数  */
  TotalNum: number
  /**  唯一请求 ID，每次请求都会返回。定位问题时需要提供该次请求的 RequestId。  */
  RequestId: string
}
export interface AttachedPolicyOfRole {
  /**  策略ID  */
  PolicyId: number
  /**  策略名称  */
  PolicyName: string
  /**  绑定时间  */
  AddTime: string
  /**  策略类型，User表示自定义策略，QCS表示预设策略
  注意：此字段可能返回 null，表示取不到有效值。  */
  PolicyType: string
  /**  策略创建方式，1表示按产品功能或项目权限创建，其他表示按策略语法创建  */
  CreateMode: number
  /**  是否已下线
  注意：此字段可能返回 null，表示取不到有效值。  */
  Deactived: number
}

/**
 * 本接口（CreateRole）用于创建角色。
 * @param regionId
 * @param param
 * @param opts
 */
export async function CreateRole(
  regionId: number,
  param: CreateRoleParams,
  opts?: APIRequestOpts
) {
  const data = await capiRequest<CreateRoleResult>(
    regionId,
    'CreateRole',
    param,
    opts
  )
  return data
}
export interface CreateRoleParams {
  /**  角色名称 */
  RoleName: string
  /**  策略文档，示例：{"version":"2.0","statement":[{"action":"name/sts:AssumeRole","effect":"allow","principal":{"service":["cloudaudit.cloud.tencent.com","cls.cloud.tencent.com"]}}]}，principal用于指定角色的授权对象。获取该参数可参阅 获取角色详情（https://cloud.tencent.com/document/product/598/36221） 输出参数RoleInfo  */
  PolicyDocument: string
  /**  角色描述 */
  Description?: string
  /**  是否允许登录 1 为允许 0 为不允许  */
  ConsoleLogin?: number
  /**  申请角色临时密钥的最长有效期限制(范围：0~43200)  */
  SessionDuration?: number
}
export interface CreateRoleResult {
  /**  角色ID 注意：此字段可能返回 null，表示取不到有效值。  */
  RoleId: number
  /**  唯一请求 ID，每次请求都会返回。定位问题时需要提供该次请求的 RequestId。  */
  RequestId: string
}

/**
 * 本接口（AttachRolePolicy）用于绑定权限策略到角色。
 * @param regionId
 * @param param
 * @param opts
 */
export async function AttachRolePolicy(
  regionId: number,
  param: AttachRolePolicyParams,
  opts?: APIRequestOpts
) {
  const data = await capiRequest<AttachRolePolicyResult>(
    regionId,
    'AttachRolePolicy',
    param,
    opts
  )
  return data
}
export interface AttachRolePolicyParams {
  /**  策略ID，入参PolicyId与PolicyName二选一  */
  PolicyId?: string
  /**  策略名，入参PolicyId与PolicyName二选一  */
  PolicyName?: string
  /**  角色ID，用于指定角色，入参 AttachRoleId 与 AttachRoleName 二选一 */
  AttachRoleId?: string
  /**  角色名称，用于指定角色，入参 AttachRoleId 与 AttachRoleName 二选一   */
  AttachRoleName?: string
}

export interface AttachRolePolicyResult {
  /**  唯一请求 ID，每次请求都会返回。定位问题时需要提供该次请求的 RequestId。  */
  RequestId: string
}

/**
 * 本接口（CreatePolicy）用于创建策略。
 * @param regionId
 * @param param
 * @param opts
 */
export async function CreatePolicy(
  regionId: number,
  param: CreatePolicyParams,
  opts?: APIRequestOpts
) {
  const data = await capiRequest<CreatePolicyResult>(
    regionId,
    'CreatePolicy',
    param,
    opts
  )
  return data
}
export interface CreatePolicyParams {
  /**  策略名   */
  PolicyName: string
  /**  策略文档，示例：{"version":"2.0","statement":[{"action":"name/sts:AssumeRole","effect":"allow","principal":{"service":["cloudaudit.cloud.tencent.com","cls.cloud.tencent.com"]}}]}，principal用于指定角色的授权对象。获取该参数可参阅 获取角色详情（https://cloud.tencent.com/document/product/598/36221） 输出参数RoleInfo  */
  PolicyDocument: string
  /**  角色名称，用于指定角色，入参 AttachRoleId 与 AttachRoleName 二选一   */
  Description?: string
}

export interface CreatePolicyResult {
  /**  唯一请求 ID，每次请求都会返回。定位问题时需要提供该次请求的 RequestId。  */
  RequestId: string
  /**  新增策略ID   */
  PolicyId: string
}
