import apiRequest from '@tencent/iaas-common/inject/apiRequest'

export default apiRequest
