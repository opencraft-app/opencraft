import apiRequest from './apiRequest'

async function capiRequest<T = any, TParam = any>(
  regionId: number,
  action: string,
  param?: TParam,
  opts: APIRequestOpts = {}
) {
  const data = {
    action: action,
    serviceType: 'vpc',
    regionId: regionId,
    data: Object.assign(
      {
        Version: '2017-03-12'
      },
      param
    )
  }
  const result = await apiRequest<{ Response: T }>(data, {
    ...opts,
    classicResponse: false
  })
  return result.Response
}

/**
 *  DescribeVpcs 查询VPC列表
 *  本接口（DescribeVpcs）用于查询私有网络列表。
 */
export function DescribeVpcs(
  regionId: number,
  params: DescribeVpcsParams,
  opts?: APIRequestOpts
) {
  return capiRequest<DescribeVpcsResult>(regionId, 'DescribeVpcs', params)
}

export interface DescribeVpcsParams {
  /**
   * VPC实例ID。形如：vpc-f49l6u0z。每次请求的实例的上限为100。参数不支持同时指定VpcIds和Filters。
   */
  VpcIds?: Array<string>

  /**
      * 过滤条件，不支持同时指定VpcIds和Filters参数。
支持的过滤条件如下：
<li>vpc-name：VPC实例名称。</li>
<li>is-default ：是否默认VPC。</li>
<li>vpc-id ：VPC实例ID，例如：vpc-f49l6u0z。</li>
<li>cidr-block：VPC的CIDR。</li>
<li>tag-key ：按照标签键进行过滤，非必填参数。</li>
<li>tag:tag-key：按照标签键值对进行过滤，非必填参数。 其中 tag-key 请使用具体的标签键进行替换，可参考示例2。</li>
  **说明：**若同一个过滤条件（Filter）存在多个Values，则同一Filter下Values间的关系为逻辑或（OR）关系；若存在多个过滤条件（Filter），Filter之间的关系为逻辑与（AND）关系。
      */
  Filters?: Array<Filter>

  /**
   * 偏移量，默认为0。
   */
  Offset?: string

  /**
   * 返回数量，默认为20，最大值为100。
   */
  Limit?: string
}
export interface DescribeVpcsResult {
  TotalCount: number
  VpcSet: Vpc[]
}
/**
 *  DescribeSubnets 查询子网列表
 *  本接口（DescribeSubnets）用于查询子网列表。
 */
export function DescribeSubnets(
  regionId: number,
  params: DescribeSubnetsParams,
  opts?: APIRequestOpts
) {
  return capiRequest<DescribeSubnetsResult>(regionId, 'DescribeSubnets', params)
}

export interface DescribeSubnetsParams {
  /**
  * 子网实例ID查询。形如：subnet-pxir56ns。每次请求的实例的上限为100。参数不支持同时指定SubnetIds和Filters。
  */
  SubnetIds?: Array<string>

  /**
      * 过滤条件，参数不支持同时指定SubnetIds和Filters。
<li>subnet-id - String - （过滤条件）Subnet实例名称。</li>
<li>vpc-id - String - （过滤条件）VPC实例ID，形如：vpc-f49l6u0z。</li>
<li>cidr-block - String - （过滤条件）子网网段，形如: 192.168.1.0 。</li>
<li>is-default - Boolean - （过滤条件）是否是默认子网。</li>
<li>is-remote-vpc-snat - Boolean - （过滤条件）是否为VPC SNAT地址池子网。</li>
<li>subnet-name - String - （过滤条件）子网名称。</li>
<li>zone - String - （过滤条件）可用区。</li>
<li>tag-key - String -是否必填：否- （过滤条件）按照标签键进行过滤。</li>
<li>tag:tag-key - String - 是否必填：否 - （过滤条件）按照标签键值对进行过滤。 tag-key使用具体的标签键进行替换。使用请参考示例2。</li>
<li>cdc-id - String - 是否必填：否 - （过滤条件）按照cdc信息进行过滤。过滤出来制定cdc下的子网。</li>
<li>is-cdc-subnet - String - 是否必填：否 - （过滤条件）按照是否是cdc子网进行过滤。取值：“0”-非cdc子网，“1”--cdc子网</li>
      */
  Filters?: Array<Filter>

  /**
   * 偏移量，默认为0。
   */
  Offset?: string

  /**
   * 返回数量，默认为20，最大值为100。
   */
  Limit?: string
}
export interface DescribeSubnetsResult {
  TotalCount: number
  SubnetSet: Subnet[]
}

export interface Vpc {
  /** `VPC`名称。 */
  VpcName?: string
  /** `VPC`实例`ID`，例如：vpc-azd4dt1c。 */
  VpcId?: string
  /** `VPC`的`IPv4` `CIDR`。 */
  CidrBlock?: string
  /** 是否默认`VPC`。 */
  IsDefault: boolean
  /** 是否开启组播。 */
  EnableMulticast?: boolean
  /** 创建时间。 */
  CreatedTime: string
  /** `DNS`列表。 */
  DnsServerSet?: string[]
  /** `DHCP`域名选项值。 */
  DomainName?: string
  /** `DHCP`选项集`ID`。 */
  DhcpOptionsId?: string
  /** 是否开启`DHCP`。 */
  EnableDhcp?: boolean
  /** `VPC`的`IPv6` `CIDR`。 */
  Ipv6CidrBlock?: string
  /** 标签键值对 */
  TagSet?: Tag[]
  /** 辅助CIDR */
  AssistantCidrSet: AssistantCidr[]
}

export interface AssistantCidr {
  /** `VPC`实例`ID`。形如：`vpc-6v2ht8q5` */
  VpcId?: string
  /** 辅助CIDR。形如：`172.16.0.0/16` */
  CidrBlock?: string
  /** 辅助CIDR类型（0：普通辅助CIDR，1：容器辅助CIDR），默认都是0。 */
  AssistantType?: number
  /** 辅助CIDR拆分的子网。 */
  SubnetSet: Subnet[]
}

export interface Subnet {
  /** `VPC`实例`ID`。 */
  VpcId?: string
  /** 子网实例`ID`，例如：subnet-bthucmmy。 */
  SubnetId?: string
  /** 子网名称。 */
  SubnetName?: string
  /** 子网的 `IPv4` `CIDR`。 */
  CidrBlock?: string
  /** 是否默认子网。 */
  IsDefault?: boolean
  /** 是否开启广播。 */
  EnableBroadcast?: boolean
  /** 可用区。 */
  Zone?: string
  /** 路由表实例ID，例如：rtb-l2h8d7c2。 */
  RouteTableId?: string
  /** 创建时间。 */
  CreatedTime: string
  /** 可用`IP`数。 */
  AvailableIpAddressCount?: number
  /** 子网的 `IPv6` `CIDR`。 */
  Ipv6CidrBlock?: string
  /** 关联`ACL`ID */
  NetworkAclId?: string
  /** 是否为 `SNAT` 地址池子网。 */
  IsRemoteVpcSnat?: boolean
  /** 子网`IP`总数。 */
  TotalIpAddressCount?: number
  /** 标签键值对。 */
  TagSet?: Tag[]
}
export interface Tag {
  /** 标签键 */
  Key: string
  /** 标签值 */
  Value: string
}

export interface Filter {
  /** 属性名称, 若存在多个Filter时，Filter间的关系为逻辑与（AND）关系。 */
  Name?: string
  /** 属性值, 若同一个Filter存在多个Values，同一Filter下Values间的关系为逻辑或（OR）关系。 */
  Values?: string[]
}

export async function DescribeAccountAttributes(
  regionId: number,
  param: DescribeAccountAttributesParams,
  opts?: APIRequestOpts
) {
  const data = await capiRequest<DescribeAccountAttributesResult>(
    regionId,
    'DescribeAccountAttributes',
    param,
    opts
  )
  return data
}
export interface DescribeAccountAttributesParams { }
export interface DescribeAccountAttributesResult {
  /**  用户账号属性对象  */
  AccountAttributeSet: AccountAttribute[]
  /**  唯一请求 ID，每次请求都会返回。定位问题时需要提供该次请求的 RequestId。  */
  RequestId: string
}
export interface AccountAttribute {
  /**  属性名，目前有 "supported-platforms"  */
  AttributeName: string
  /**  属性值，supported-platforms的值可能为 "VPC" / "CLASSIC" */
  AttributeValues: string[]
}
