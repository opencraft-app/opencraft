const iaas = seajs.require('models/iaas')

export type GetRequestRes<
  T extends (...args: any[]) => Promise<any>
> = T extends (...args: any[]) => Promise<infer P> ? P : any

/**
 * 批量拉取列表接口，主要用于全量拉取资源，所有数据拉取完才会一起返回
 * @param opt
 */
export function fullAmountFetch<TParams extends any[], TResponse>(opt: {
  fetchFn: (...p: TParams) => Promise<TResponse>
  // 单次拉取数量
  fetchLimit?: number
  // 注入切片参数
  injectSliceParam: (param: any, limit: number, offset: number) => TParams
  // 统一接口返回
  formatResponse: (response: TResponse) => { TotalCount: number; List: any[] }
  // 是否串行拉取数据
  fetchSerial?: boolean
}) {
  const {
    fetchFn,
    fetchLimit = 20,
    injectSliceParam,
    formatResponse,
    fetchSerial = true
  } = opt
  return async function (
    ...param: TParams
  ): Promise<{ TotalCount: number; List: any[] }> {
    let { TotalCount, List } = formatResponse(
      await fetchFn(...injectSliceParam(param, fetchLimit, 0))
    )

    let fetched = List && List.length

    if (fetchSerial) {
      // 串行拉取
      while (fetched < TotalCount) {
        const { List: newList } = formatResponse(
          await fetchFn(...injectSliceParam(param, fetchLimit, fetched))
        )
        List = List.concat(newList)
        fetched = List.length
      }
    } else {
      // 并行拉取
      const timeToFetch = Math.ceil((TotalCount - fetched) / fetchLimit)
      const ListArray = (
        await Promise.all(
          Array(timeToFetch)
            .fill(0)
            .map((_, index) => {
              return fetchFn(
                ...injectSliceParam(param, fetchLimit, (index + 1) * fetchLimit)
              )
            })
        )
      )
        .map(response => formatResponse(response))
        .map(x => x.List)
      List = List.concat(...ListArray)
    }
    return {
      TotalCount,
      List
    }
  }
}

/**
 * 基于 iaas.apiRequest 的 V3 请求
 */
export function iaasApiV3FullAmountFetch<
  TParams extends any[],
  TRes extends { Response: { TotalCount: number } }
>(opt: {
  fetchFn: (...p: TParams) => Promise<TRes>
  // 返回中列表字段名，如 VpcSet
  listKey: string
  totalCountKey?: string
  // 单次拉取数量
  fetchLimit?: number
  // 是否串行拉取数据
  fetchSerial?: boolean
}) {
  return fullAmountFetch<TParams, TRes>({
    fetchFn: opt.fetchFn,
    fetchLimit: opt.fetchLimit,
    fetchSerial: opt.fetchSerial,
    injectSliceParam: (param, limit, offset) => {
      return param.map((x, index) => {
        return index === 1
          ? { ...param[index], Limit: limit, Offset: offset }
          : x
      })
    },
    formatResponse: response => {
      const TotalCount = response.Response[opt.totalCountKey || 'TotalCount']
      const List = response.Response[opt.listKey]
      return {
        TotalCount,
        List
      }
    }
  })
}

/**
 * 批量拉取列表接口，生成器版本
 */
export function fullAmountFetchGen<TResponse>(opt: {
  fetchFn: (...arg) => Promise<TResponse>
  // 单次拉取数量
  fetchLimit?: number
  // 注入切片参数
  injectSliceParam: (param: any, limit: number, offset: number) => any
  // 统一接口返回
  formatResponse: (
    response: TResponse
  ) => {
    TotalCount: number
    List: any[]
  }
}) {
  const { fetchFn, fetchLimit = 20, injectSliceParam, formatResponse } = opt

  return function* gen(...param) {
    const { TotalCount, List } = yield fetchFn(
      ...injectSliceParam(param, fetchLimit, 0)
    ).then(res => {
      return formatResponse(res)
    })
    let fetched = List.length

    while (fetched < TotalCount) {
      const { List } = yield fetchFn(
        ...injectSliceParam(param, fetchLimit, fetched)
      )
      fetched = List.length
    }
  }
}

/**
 * v3 拉全量。结合qcbase原来的asyncParallel
 * 适用于ts 3+ 推断
 */
export function fetchAllHelper<
  TRequest extends (...args: any[]) => ReturnType<TRequest>
>(
  api: TRequest,
  options?: {
    targetSet /** v3 Response中的数据对应字段名，默认取非TotalCount的另一个 。很危险，建议传对应字段名*/?: string
    limit /**每次请求后台接口limit值，默认是100 */?: number
  }
) {
  const {
    targetSet = Object.keys(Response).filter(key => key !== 'TotalCount')[0],
    limit = 100
  } = options || {}

  type params = Parameters<TRequest>
  type dataParam = Omit<params[1], 'Limit' | 'Offset'>

  const request = async (
    regionId: params[0],
    data: dataParam = {} as dataParam,
    opts: params[2] = {}
  ) => {
    const params = {
      ...data,
      Limit: limit,
      Offset: 0
    }

    const { Response }: any = await api(
      regionId,
      {
        ...params
      },
      opts
    )

    const resultSet = Response[targetSet]

    const totalCount = Response.TotalCount

    if (totalCount !== resultSet.length) {
      let chunks = []
      for (
        let offset = resultSet.length;
        offset < totalCount;
        offset += limit
      ) {
        chunks.push(() =>
          api(
            regionId,
            {
              ...params,
              Offset: offset,
              Limit: limit
            },
            opts
          )
        )
      }
      if (chunks.length) {
        const ListArray = await asyncParallel(chunks, 5)
        ListArray.forEach(({ Response }) => {
          resultSet.push(...Response[targetSet])
        })
      }
    }

    return {
      Response: {
        TotalCount: totalCount,
        [targetSet]: resultSet
      }
    } as GetRequestRes<TRequest>
  }
  return request
}

/**
 * v3 批量查询。结合qcbase原来的asyncParallel
 *
 * 批量查询的结果取决于 queryData 集合的数量；
 * 若 queryData.length 长度为 100 limit 为 10
 * 则相当于分别用 0~10, 10~20, 20~30, 30~40 等的 queryData 各查询一次，查询完了返回对应结果
 * 与接口本身的 totalCount 无关
 *
 * 适用于ts 3+ 推断
 */
export function batchQueryHelper<
  TRequest extends (
    regionId: number,
    data: unknown,
    opts: unknown & { queryKey?: string }
  ) => ReturnType<TRequest>
>(
  api: TRequest,
  options?: {
    targetSet /** v3 Response中的数据对应字段名，默认取非TotalCount的另一个 。很危险，建议传对应字段名*/?: string
    limit /**每次请求后台接口limit值，默认是100 */?: number
  }
) {
  const {
    targetSet = Object.keys(Response).filter(key => key !== 'TotalCount')[0],
    limit = 100
  } = options || {}

  type params = Parameters<TRequest>
  type dataParam = Omit<params[1], 'Limit' | 'Offset'>
  type optsParam = params[2]

  const request = async (
    regionId: params[0],
    data: dataParam = {} as dataParam,
    opts: optsParam = {}
  ) => {
    // queryKey：批量查询 queryData 的数据集合（必须是数组类型）的 key 值
    const { queryKey } = opts
    const queryData = data[queryKey]
    // 不是持批量查询，则抛异常
    if (!(queryKey && Array.isArray(queryData))) {
      throw new Error(`data[${queryKey}]: isn't an Array, ${data[queryKey]}`)
    }
    let offset = 0
    let params = {
      ...data,
      [queryKey]: queryData.slice(0, limit),
      Limit: limit,
      Offset: offset
    }
    const { Response }: any = await api(regionId, params, opts)
    const resultSet = Response[targetSet]
    const totalCount = queryData.length // 批量查询 totalCount 取决于 queryData 集合的数量

    if (limit < queryData.length) {
      let chunks = []
      for (offset = limit; offset < queryData.length; offset += limit) {
        params = {
          ...params,
          [queryKey]: queryData.slice(offset, offset + limit),
          Offset: 0,
          Limit: limit
        }

        chunks.push(() => api(regionId, params, opts))
      }
      if (chunks.length) {
        const ListArray = await asyncParallel(chunks, 5)
        ListArray.forEach(({ Response }) => {
          resultSet.push(...Response[targetSet])
        })
      }
    }

    return {
      Response: {
        TotalCount: totalCount,
        [targetSet]: resultSet
      }
    } as GetRequestRes<TRequest>
  }
  return request
}

/**
 * gql 拉全量。结合qcbase原来的asyncParallel
 */
export async function fetchAllGql<T>(
  params: {
    regionId: string
    variables: object
    operationName: string
    query: string
  },
  path: string[],
  options?: {
    limit /**每次请求后台接口limit值，默认是100 */?: number
  }
) {
  const { limit = 100 } = options || {}

  params = {
    ...params,
    variables: {
      ...params.variables,
      limit,
      offset: 0
    }
  }

  const { data }: any = await iaas.gqlRequest(params)
  const { nodes: resultSet, totalCount } = getGqlData(path, data)

  if (totalCount !== resultSet.length) {
    let chunks = []
    for (let offset = resultSet.length; offset < totalCount; offset += limit) {
      chunks.push(() =>
        iaas.gqlRequest({
          ...params,
          variables: {
            ...params.variables,
            offset,
            limit: Math.min(totalCount - offset, limit)
          }
        })
      )
    }
    if (chunks.length) {
      const ListArray = await asyncParallel(chunks, 5)
      ListArray.forEach(({ data }) => {
        const { nodes } = getGqlData(path, data)
        resultSet.push(...nodes)
      })
    }
  }

  return {
    totalCount: totalCount,
    list: resultSet as T[]
  }
}

/**
 * 获取graphql层级里指定的属性
 * 例如
 * @param {*} pathArray 如 ['resource', 'loadbalance', 'list']
 * @param {*} data 如 { resource: { loadbalance: { list: {...} } } }
 * @return {*} 返回对应层级的数据，如果没有此层级，返回null
 */
export function getGqlData(pathArray: string[], data) {
  var o = data,
    i,
    key
  for (i = 0; i < pathArray.length; i++) {
    key = pathArray[i]
    if (o && key in o) {
      o = o[key]
    } else {
      return null
    }
  }
  return o
}

async function asyncParallel(thunks: Function[], concurrency = 5) {
  async function parallelPool(size: number, task: () => Promise<any>) {
    let done = false
    let active = 0
    let errors = []
    return new Promise((resolve, reject) => {
      function poolIterator() {
        while (active < size && !done) {
          active++
          task()
            .then(more => {
              if (--active <= 0 && (done || !more)) {
                if (errors.length > 0) {
                  // at least one task failed
                  return reject(JSON.stringify(errors))
                } else {
                  // all tasks completed successfully
                  return resolve()
                }
              } else if (more) {
                poolIterator()
              } else {
                done = true
              }
            })
            .catch(err => {
              errors.push(err)
              done = true
              if (--active <= 0) {
                return reject(JSON.stringify(errors))
              } else {
                // wait until all active tasks are drained before rejecting the
                // final result (no new tasks will be started now that we're in
                // this error state)
              }
            })
        }
      }
      poolIterator()
    })
  }
  if (concurrency > 0) {
    concurrency = Math.min(concurrency, thunks.length)
  } else {
    concurrency = thunks.length
  }
  let index = 0
  let results = []
  await parallelPool(concurrency, async () => {
    if (index < thunks.length) {
      const currentIndex = index++
      const thunk = thunks[currentIndex]
      results[currentIndex] = await thunk.call(this)
    }
    return index < thunks.length
  })
  return results
}
