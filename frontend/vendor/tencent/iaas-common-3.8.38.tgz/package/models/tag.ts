import { fetchAllHelper } from './util'
import apiRequest from './apiRequest'

async function capiRequest<T = any, TParam = any>(
  regionId: number,
  action: string,
  param?: TParam,
  opts: APIRequestOpts = {}
) {
  const data = {
    action: action,
    serviceType: 'tag',
    regionId: regionId,
    data: Object.assign(
      {
        Version: '2018-08-13'
      },
      param
    )
  }
  const result = await apiRequest<{ Response: T }>(data, {
    ...opts,
    classicResponse: false
  })
  return result.Response
}

/** 用于查询已建立的标签列表中的标签键。 */

export async function DescribeTagKeys(
  regionId: number,
  param: DescribeTagKeysParams,
  opts?: APIRequestOpts
) {
  const data = await capiRequest<DescribeTagKeysResult>(
    regionId,
    'DescribeTagKeys',
    param,
    opts
  )
  return data
}

export const DescribeTagKeysInstances = fetchAllHelper(
  (regionId: number, param: DescribeTagKeysParams, opts?: APIRequestOpts) => {
    return DescribeTagKeys(regionId, param, opts).then(
      (data: DescribeTagKeysResult) => {
        return { Response: data }
      }
    )
  },
  {
    targetSet: 'Tags',
    limit: 1000
  }
)

export interface DescribeTagKeysParams {
  /**  创建者用户 Uin，不传或为空只将 Uin 作为条件查询  */
  CreateUin?: number
  /**  数据偏移量，默认为 0, 必须为Limit参数的整数倍  */
  Offset: number
  /**  每页大小，默认为 15  */
  Limit: number
}
export interface DescribeTagKeysResult {
  /**  结果总数  */
  TotalCount: number
  /**  数据位移偏量  */
  Offset: number
  /**  每页大小  */
  Limit: number
  /**  标签列表  */
  Tags: string[]
  /**  唯一请求 ID，每次请求都会返回。定位问题时需要提供该次请求的 RequestId。  */
  RequestId: string
}

/** 用于查询已建立的标签列表。 */
export async function DescribeTags(
  regionId: number,
  param: DescribeTagsParams,
  opts?: APIRequestOpts
) {
  const data = await capiRequest<DescribeTagsResult>(
    regionId,
    'DescribeTags',
    param,
    opts
  )
  return data
}
export interface DescribeTagsParams {
  /**  标签键,与标签值同时存在或同时不存在，不存在时表示查询该用户所有标签  */
  TagKey?: string
  /**  标签值,与标签键同时存在或同时不存在，不存在时表示查询该用户所有标签  */
  TagValue?: string
  /**  数据偏移量，默认为 0, 必须为Limit参数的整数倍  */
  Offset?: number
  /**  每页大小，默认为 15  */
  Limit?: number
  /**  创建者用户 Uin，不传或为空只将 Uin 作为条件查询  */
  CreateUin?: number
}
export interface DescribeTagsResult {
  /**  结果总数  */
  TotalCount: number
  /**  数据位移偏量  */
  Offset: number
  /**  每页大小  */
  Limit: number
  /**  标签列表  */
  Tags: TagWithDelete[]
  /**  唯一请求 ID，每次请求都会返回。定位问题时需要提供该次请求的 RequestId。  */
  RequestId: string
}
export interface TagWithDelete {
  /**  标签键  */
  TagKey: string
  /**  标签值  */
  TagValue: string
  /**  是否可以删除  */
  CanDelete: number
}
