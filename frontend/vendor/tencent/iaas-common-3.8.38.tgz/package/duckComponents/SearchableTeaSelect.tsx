import * as React from 'react'
import * as classnames from 'classnames'
import {
  Select,
  SimulateSelectProps,
  SelectOptionWithGroup,
  StatusTip,
  Text,
  LoadingTip
} from '@tencent/tea-component'
import { DuckCmpProps } from 'saga-duck'
import Duck from '../ducks/SearchableSelect'
import { getStatusTipProps } from './SearchableSelect'
import { useTranslation } from '@tencent/tea-component/lib/i18n'

interface MyDuck<TItem> extends Duck {
  ID: string
  Item: TItem
}
export interface SearchableTeaSelectProps<TItem>
  extends DuckCmpProps<MyDuck<TItem>>,
  Omit<
  SimulateSelectProps,
  | 'options'
  | 'type'
  | 'searchable'
  | 'value'
  | 'onChange'
  | 'searchValue'
  | 'onSearchValueChange'
  | 'onSearch'
  | 'onScrollBottom'
  | 'tips'
  | 'bottomTips'
  > {
  toOption: (item: TItem) => SelectOptionWithGroup
  filterOption?: (item: TItem) => boolean
}
export default function SearchableTeaSelect<TItem>(
  props: SearchableTeaSelectProps<TItem>
) {
  const searchableProps = useSearchableTeaSelect(props)
  return (
    <Select
      size="m"
      appearance="button"
      type="simulate"
      searchable
      {...searchableProps}
    />
  )
}

/** 为了配合Table Filterable使用，将props逻辑抽离出来 */
export function useSearchableTeaSelect<TItem>(props: SearchableTeaSelectProps<TItem>) {
  const { duck, store, dispatch, toOption, filterOption, placeholder, onOpen, onClose,...rest } = props
  const enableFilter = filterOption && typeof filterOption === 'function'
  const { selector, creators } = duck
  const {
    id,
    pendingKeyword,
    list,
    loadingMore,
    nomore,
    keyword,
    totalCount,
    fetcher: { loading, error }
  } = selector(store)

  let uiList = list
  if(enableFilter){
    uiList = list?.filter(filterOption) || null
  }

  const handlers = React.useMemo(() => {
    return {
      select: (id: string) => dispatch(creators.select(id)),
      inputKeyword: (keyword: string) =>
        dispatch(creators.inputKeyword(keyword)),
      clearKeyword: () => dispatch(creators.search('')),
      search: keyword => dispatch(creators.search(keyword)),
      more: () => dispatch(creators.more()),
      reload: () => dispatch(creators.reload())
    }
  }, [duck, dispatch])

  // 如果是加载更多的模式，loading应该展示在列表下方
  const isLoadMoreMode = loadingMore
  const statusTipProps = getStatusTipProps({
    list: uiList,
    totalCount,
    hideCount: enableFilter || typeof totalCount !== 'number',
    keyword,
    loading,
    error,
    onClear: handlers.clearKeyword,
    onRetry: handlers.reload
  })

  const [isOpen, setIsOpen] = React.useState(false);
  const fetched = duck.ducks.fetcher.selectors.fetched(store);
  const t = useTranslation();

  const button = React.useCallback(
    (options) => {
      let buttonText: React.ReactNode = <Text theme="weak">{placeholder || t.pleaseSelect}</Text>;
      if (fetched && totalCount === 0) {
        buttonText = <Text theme="weak">{t.emptyText}</Text>;
      }
      if (options) {
        buttonText = typeof options.text === 'undefined' ? options.value : options.text;
      }
      if (!isOpen && loading) {
        buttonText = <LoadingTip />;
      }
      return buttonText;
    },
    [isOpen, loading, totalCount],
  );

  return {
    value: id,
    options: uiList?.map(toOption) || [],
    button,
    onChange: handlers.select,
    searchValue: pendingKeyword,
    onSearchValueChange: handlers.inputKeyword,
    // Tea Simulate Selec有个问题，onSearch会在每次输入时触发，导致频繁触发请求
    // 所以我们需要在duck层做一下缓冲
    onSearch: handlers.search,
    onScrollBottom: nomore ? undefined : handlers.more,
    filter: () => true,
    autoClearSearchValue: false,
    tips:
      !isLoadMoreMode && statusTipProps ? (
        <StatusTip {...statusTipProps}></StatusTip>
      ) : undefined
    ,
    bottomTips:
      isLoadMoreMode && statusTipProps ? (
        <StatusTip {...statusTipProps}></StatusTip>
      ) : undefined,
      onOpen:() => {
        setIsOpen(true);
        onOpen?.()
      },
      onClose:() => {
        setIsOpen(false);
        onClose?.()
      },
    ...rest

  }
}

SearchableTeaSelect['defaultLabelAlign'] = 'middle'
