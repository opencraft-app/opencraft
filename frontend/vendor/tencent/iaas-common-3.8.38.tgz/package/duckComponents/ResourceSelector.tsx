// import * as React from 'react'
// import {
//   ResourceSelectorGeneric as ResouceSelector,
//   ResourceSelectorProps,
//   ResourceSelectorInfoRow
// } from '@tencent/qcloud-component'
// import { Identifiable } from '@tencent/qcloud-lib'
// import * as classnames from 'classnames'
// import { memorize, purify, DuckCmpProps } from 'saga-duck'
// import Duck, { FetcherParam } from '../ducks/ResourceSelector'
// interface MyDuck<TItem> extends Duck{
//   Item: TItem
// }
// const getHandlers = memorize(
//   ({ creators, getId }: Duck, dispatch) => ({
//     inputKeyword: (v: string) => dispatch(creators.setKeyword(v)),
//     search(keyword: string) {
//       dispatch(creators.setKeyword(keyword))
//       dispatch(creators.search())
//     },
//     clear() {
//       dispatch(creators.setKeyword(''))
//       dispatch(creators.search())
//     },
//     setSelected(list) {
//       dispatch(creators.setSelected(list.map(getId)))
//     }
//   })
// )

// interface Props<TItem extends Identifiable>
//   extends Partial<ResourceSelectorProps<TItem>> {
//   title?: string | JSX.Element | JSX.Element[]
//   itemNameRender: (item: TItem) => string | JSX.Element
//   itemDescriptionRender: (item: TItem) => string | JSX.Element
// }

// export default purify(function<
//   TItem extends Identifiable,
// >(props: DuckCmpProps<MyDuck< TItem>> & Props<TItem>) {
//   const {
//     duck: {
//       creators,
//       selector,
//       selectors,
//       ducks: { fetcher },
//       getId,
//       isDisabled
//     },
//     store,
//     dispatch,
//     title = '请选择',
//     itemNameRender = i => getId(i) + '',
//     itemDescriptionRender = i => getId(i) + '',
//     ...rest
//   } = props
//   const handlers = getHandlers(props)

//   const state = selector(store)
//   const fetcherState = fetcher.selector(store)
//   const list = selectors.list(store)
//   const selected = selectors.selected(store)
//   const keyword = state.keyword
//   const searchedKeyword = fetcherState.filter.keyword
//   const error = fetcherState.error
//   const loading = fetcherState.loading

//   return (
//     <ResouceSelector
//       search={{
//         keyword,
//         onInput: handlers.inputKeyword,
//         onSearch: handlers.search,
//         onClear: handlers.clear
//       }}
//       list={list || []}
//       selection={selected}
//       onSelectionChanged={handlers.setSelected}
//       selectorTitle={title as any}
//       itemNameRender={itemNameRender}
//       itemDescriptionRender={itemDescriptionRender}
//       itemDisabled={(o: TItem) => isDisabled(o, state)}
//       {...rest}
//     >
//       {loading && (
//         <ResourceSelectorInfoRow>正在加载...</ResourceSelectorInfoRow>
//       )}
//       {(!list || !list.length) && (
//         <ResourceSelectorInfoRow>没有数据</ResourceSelectorInfoRow>
//       )}
//       {searchedKeyword && (
//         <ResourceSelectorInfoRow>
//           搜索关键字 “{searchedKeyword}”{' '}
//           <a href="javascript:;" onClick={handlers.clear}>
//             清除
//           </a>
//         </ResourceSelectorInfoRow>
//       )}
//       {error && (
//         <ResourceSelectorInfoRow>
//           <div>
//             <i className="n-error-icon" />
//             {error.message}{' '}
//           </div>
//         </ResourceSelectorInfoRow>
//       )}
//     </ResouceSelector>
//   )
// })
