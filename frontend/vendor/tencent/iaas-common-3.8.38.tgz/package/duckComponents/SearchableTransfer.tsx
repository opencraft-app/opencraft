/**
 * 穿梭框/资源选择器
 *
 * 对应的逻辑Duck为 `ducks/SearchableMultiSelect`
 */
import * as React from 'react'
import { DuckCmpProps, purify, memorize } from 'saga-duck'
import { SearchBox, TableColumn } from '@tencent/tea-component'
import Duck from '../ducks/SearchableMultiSelect'
import { t, Trans } from '@tencent/tea-app/lib/i18n'
import {
  StatusTip,
  Transfer,
  TransferProps,
  Table,
  StatusTipProps
} from '@tencent/tea-component'
import {
  selectable,
  removeable,
  scrollable,
  columnsResizable,
  rowtooltip,
} from '@tencent/tea-component/lib/table/addons'

interface MyDuck<T> extends Duck {
  Item: T
}
interface Props<T = any>
  extends DuckCmpProps<MyDuck<T>>,
    Omit<TransferProps, 'leftCell' | 'rightCell'> {
  /** 左侧选择提示文案，例如：请选择Topic */
  title?: React.ReactNode
  /**
   * ID/Name列头，如果不指定，则不显示表头
   *
   * 另如果指定Left、Right组件，则此配置无效
   */
  idHeader?: React.ReactNode
  /** 判断选项是否被禁用
   *
   * 另如果指定Left、Right组件，则此配置无效
   */
  itemDisabled?(item: T): boolean
  /**
   * 选项如何被渲染，如果不指定，则直接展示id（duck.getId）
   *
   * 另如果指定Left、Right组件，则此配置无效
   */
  itemRenderer?(item: T): React.ReactNode
  /**
   * 选项展示什么tip
   * 另如果指定Left、Right组件，则此配置无效
   */
  itemTip?(item: T): React.ReactNode
  /**
   * 额外列展示
   * 另如果指定Left、Right组件，则此配置无效
   */
  extraColumns?: TableColumn<T>[]
  searchPlaceholder?: string
  Left?: React.ComponentType<LeftProps<T>>
  Right?: React.ComponentType<RightProps<T>>
  /**
   * 是否需要调整列宽
   * @default false
   */
  needResizeColumn?: boolean
}

interface LeftProps<T> extends DuckCmpProps<Duck> {
  idHeader?: React.ReactNode
  statusTip?: React.ReactNode
  extraColumns?:  TableColumn<T>[]
}
interface RightProps<T> extends DuckCmpProps<Duck> {
  idHeader?: React.ReactNode
  extraColumns?:  TableColumn<T>[]
}

const getHandlers = memorize(({ creators }: Duck, dispatch) => ({
  inputKeyword: keyword => dispatch(creators.inputKeyword(keyword)),
  search: keyword => dispatch(creators.search(keyword)),
  clearKeyword: () => dispatch(creators.search('')),
  select: selected => dispatch(creators.select(selected)),
  remove: selected => dispatch(creators.remove(selected)),
  more: () => dispatch(creators.more()),
  reload: () => dispatch(creators.reload())
}))

function SearchableTransfer<T>(props: Props<T>) {
  const handlers = getHandlers(props)
  const {
    duck,
    store,
    dispatch,
    title: header = t('请选择'),
    idHeader,
    itemDisabled = o => false,
    itemRenderer = o => duck.getId(o),
    itemTip = o => undefined,
    searchPlaceholder = t('输入关键字搜索'),
    Left = DefaultLeft,
    Right = DefaultRight,
    extraColumns = [],
    needResizeColumn,
    ...rest
  } = props
  const { selector, selectors } = duck
  const {
    pendingKeyword,
    keyword,
    list,
    totalCount,
    selection,
    fetcher: { loading, error }
  } = selector(store)

  let statusTip: React.ReactNode = null
  if (loading) {
    statusTip = <CompactStatusTip status="loading" />
  } else if (error) {
    statusTip = <CompactStatusTip status="error" onRetry={handlers.reload} />
  } else if (keyword) {
    statusTip = (
      <CompactStatusTip
        status="found"
        foundText={
          list && list.length > 0
            ? typeof totalCount !== 'number' ? t('找到以下结果') : t('找到{{count}}条结果', { count: totalCount })
            : t('搜索"{{keyword}}"暂无数据', { keyword })
        }
        onClear={handlers.clearKeyword}
      />
    )
  } else if (list && list.length <= 0) {
    statusTip = <CompactStatusTip status="empty" />
  }

  return (
    <Transfer
      {...rest}
      leftCell={
        <Transfer.Cell
          title={header}
          scrollable={false}
          header={
            <SearchBox
              value={pendingKeyword}
              onChange={handlers.inputKeyword}
              onSearch={handlers.search}
              onClear={handlers.clearKeyword}
              placeholder={searchPlaceholder}
            />
          }
        >
          <Left
            duck={duck}
            store={store}
            dispatch={dispatch}
            statusTip={statusTip}
            itemDisabled={itemDisabled}
            itemRenderer={itemRenderer}
            itemTip={itemTip}
            idHeader={idHeader}
            extraColumns={extraColumns}
            needResizeColumn={needResizeColumn}
          />
        </Transfer.Cell>
      }
      rightCell={
        <Transfer.Cell
          title={t('已选择 ({{count}})', {
            count: (selection && selection.length) || 0
          })}
        >
          <Right
            duck={duck}
            store={store}
            dispatch={dispatch}
            itemRenderer={itemRenderer}
            idHeader={idHeader}
            extraColumns={extraColumns}
            needResizeColumn={needResizeColumn}
          />
        </Transfer.Cell>
      }
    />
  )
}

export default SearchableTransfer

const defaultIdHeader = t('ID')

interface DefaultLeftProps<T> extends LeftProps<T>{
  itemDisabled(item: T): boolean
  itemRenderer: (t: T) => React.ReactNode
  itemTip?(item: T): React.ReactNode
  needResizeColumn: boolean
}
function DefaultLeft<T>(props: DefaultLeftProps<T>) {
  const {
    duck,
    store,
    dispatch,
    statusTip,
    itemDisabled,
    itemRenderer,
    itemTip,
    idHeader,
    extraColumns = [],
    needResizeColumn,
} = props
  const { selector, selectors, creators } = duck
  const { list, selection, loadingMore, nomore } = selector(store)
  const getId = duck.getId.bind(duck)
  const [columns, setColumns] = React.useState([
     {
       header: idHeader || defaultIdHeader,
       key: 'id',
       render: t => itemRenderer(t)
     },
     ...extraColumns
  ])
  return (
    <Table
      records={list || []}
      recordKey={getId}
      columns={columns}
      hideHeader={!idHeader}
      topTip={loadingMore ? null : statusTip}
      bottomTip={loadingMore ? statusTip : null}
      rowDisabled={itemDisabled}
      addons={[
        ...(needResizeColumn
          ? [
              columnsResizable({
                onResizeEnd: columns => {
                  setColumns(columns)
                },
                minWidth: 100,
                maxWidth: 1000,
              }),
            ]
        : []),
        scrollable({
          maxHeight: 310,
          onScrollBottom: () => {
            if (nomore) {
              return
            }
            dispatch(creators.more())
          }
        }),
        selectable({
          value: selection.map(getId),
          onChange: ids => {
            // 选择的内容
            const idSet = new Set(ids)
            // TODO 这里如果执行了搜索，会把已有的给清空...要考虑下怎么避免
            // 想到一个方案是，只处理当前在列表内的数据，不在列表内的不修改
            // 当前列表的所有内容
            const listMap = new Map<string, T>()
            list?.forEach(record => {
              listMap.set(getId(record), record)
            })
            // 当前已选的所有内容
            const selectedMap = new Map<string, T>()
            selection.forEach(record => {
              selectedMap.set(getId(record), record)
            })
            const newSelection = new Map<string, T>()
            // 不在列表中，或当前选中的，保留
            for (const [id, record] of selectedMap) {
              if (!listMap.has(id) || idSet.has(id)) {
                newSelection.set(id, record)
              }
            }
            // 在列表中，新增的，添加
            for (const id of idSet) {
              if (!newSelection.has(id)) {
                const item = listMap.get(id)
                if (item && !itemDisabled(item)) {
                  newSelection.set(id, item)
                }
              }
            }
            dispatch(creators.select([...newSelection.values()]))
          },
          rowSelect: true
        }),
        rowtooltip({
          tooltip: (item) => itemTip?.(item) || null,
        }),
      ]}
    />
  )
}
interface DefaultRightProps<T> extends RightProps<T> {
  itemRenderer: (t: T) => React.ReactNode
  needResizeColumn: boolean
}
function DefaultRight<T>(props: DefaultRightProps<T>) {
  const { duck, store, dispatch, itemRenderer, idHeader, extraColumns = [], needResizeColumn } = props
  const { selector, selectors, creators } = duck
  const { selection } = selector(store)
  const getId = duck.getId.bind(duck)
  const [columns, setColumns] = React.useState([
     {
       header: idHeader || defaultIdHeader,
       key: 'id',
       render: t => itemRenderer(t)
     },
     ...extraColumns
  ])
 return (
   <Table
      records={selection}
      recordKey={getId}
      columns={columns}
      hideHeader={!idHeader}
      addons={[
       ...(needResizeColumn
        ? [
            columnsResizable({
              onResizeEnd: columns => {
                setColumns(columns)
              },
              minWidth: 100,
              maxWidth: 1000,
            }),
          ]
        : []),
        removeable({
          onRemove: id =>
            dispatch(
              creators.remove([selection.find(record => getId(record) === id)])
            )
        })
      ]}
    />
  )
}

// 原始的StatusTip margin过大，展示在这里很难看
function CompactStatusTip(props: StatusTipProps) {
  const { style, ...rest } = props
  return (
    <StatusTip
      style={{
        margin: 0,
        ...style
      }}
      {...rest}
    />
  )
}
