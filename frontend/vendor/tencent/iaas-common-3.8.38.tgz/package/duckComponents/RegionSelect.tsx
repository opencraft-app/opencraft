// 同Region.tsx，但展示为tea2新样式
import * as React from 'react'
import { memorize, DuckCmpProps } from 'saga-duck'
import Duck, { Region } from '../ducks/Region'
import { RegionSelectProps, RegionOptionProps } from '@tencent/tea-component'
import { purify } from 'saga-duck/purify'
import buildConfig from '../buildConfig'
import OldRegion from './Region'
import { RegionSupport } from '@tencent/tea-app'

const getSelectHandler = memorize((duck, dispatch) => {
  return value => {
    dispatch(duck.creators.select(parseInt(value, 10)))
  }
})

export interface Props
  extends Omit<RegionSelectProps, 'value' | 'onChange'>,
    DuckCmpProps<Duck> {
  /**
   * 当需要处理地域展示、分组等信息时，可在此处理
   *
   * 例如添加地域实例数量：
   *
   * javascript```
   *  <RegionSelect injectRegionSetting={s => { s.content += `(${count})`; return s }} />
   * ```
   */
  injectRegionSetting?: (defaultSetting: RegionSetting) => RegionSetting
}

export default purify(function DuckRegionBar(props: Props) {
  if (!buildConfig.showRegion) {
    return <noscript />
  }
  if (buildConfig.noRegionGroup) {
    return <OldRegion {...props} />
  }
  const {
    duck: { selectors },
    store,
    dispatch,
    injectRegionSetting = defaultGetSetting,
    ...rest
  } = props
  const list = selectors.list(store)

  if (!list.length) return <noscript />
  const selected = selectors.selected(store)
  const areaArrayList = getAreaArrayList(list)
  const maxRowNum = getMaxRows()
  const regionSettings: RegionSetting[] = list.map(region =>
    injectRegionSetting(
      getRegionDefaultSetting(region, maxRowNum, areaArrayList)
    )
  )
  // 先计算分组
  let groups = new Map<string, Map<string, RegionSetting[]>>()
  regionSettings.forEach(r => {
    const largeGroupName = r.largeGroup || r.group
    let largeGroup = groups.get(largeGroupName)
    if (!largeGroup) {
      largeGroup = new Map<string, RegionSetting[]>()
      groups.set(largeGroupName, largeGroup)
    }
    let group = largeGroup.get(r.group)
    if (!group) {
      group = []
      largeGroup.set(r.group, group)
    }
    group.push(r)
  })

  // 如果一个业务只有国内地域，或考虑将group进行一次提升，避免只显示在一列内，不太好看
  if (groups.size === 1) {
    for (const [lname, lg] of groups) {
      groups.delete(lname)
      for (const [name, regions] of lg) {
        const riseGroup = new Map<string, RegionSetting[]>()
        riseGroup.set(name, regions)
        groups.set(name, riseGroup)
      }
      break
    }
  }

  return (
    <RegionSupport>
      {({ RegionSelect, RegionPanel, RegionOption }) => (
        <RegionSelect
          value={selected ? String(selected.value) : null}
          onChange={getSelectHandler(arguments[0])}
          {...rest}
        >
          <RegionPanel>
            {Array.from(groups.entries()).map(([largeGroupName, largeGroup]) => (
              <RegionPanel.Column key={largeGroupName}>
                {Array.from(largeGroup.entries()).map(([groupName, regions]) => (
                  <RegionPanel.Group name={groupName} key={groupName}>
                    {regions.map(region => {
                      const {
                        value,
                        content,
                        group,
                        largeGroup,
                        ...rest
                      } = region
                      return (
                      <RegionOption
                        {...rest}
                        key={value}
                        value={value}
                      >
                        <section style={{display:'inline-block'}}>{content}</section>
                      </RegionOption>
                    )})}
                  </RegionPanel.Group>
                ))}
              </RegionPanel.Column>
            ))}
          </RegionPanel>
        </RegionSelect>
      )}
    </RegionSupport>
  )
})

function getRegionDefaultSetting(
  r: IRegion,
  maxRowNum: number,
  areaArrayList: number[][]
): RegionSetting {
  const area = r.area
  const colIndex = getRegionColIndex(r.value, maxRowNum, areaArrayList)
  return {
    disabled: r.disabled,
    value: String(r.value),
    content: r.name,
    largeGroup: colIndex ? colIndex : '',
    group: area ? area : '',
    dot: r.newFlag
  }
}

/**
 * 获取按area分组的二维regionId数组 形如：[[1, 11, 12], [4, 7], ...]
 * 这里未考虑area的排序，因为没有排序数据来源，暂时先默认按 region list 的顺序
 * @param regionList region列表
 */
function getAreaArrayList(regionList: Region[]): number[][] {
  let areaArrayList: number[][] = []
  // 已经存在的area
  let curExistAreas = []
  regionList.forEach(region => {
    const regionId = region.value
    const area = region.area
    // 当前region所在area是否存在
    if (!curExistAreas.includes(area)) {
      curExistAreas.push(area)
      areaArrayList.push([])
    }
    areaArrayList[curExistAreas.indexOf(area)].push(regionId)
  })
  return areaArrayList
}

/**
 * 获取region所在的列序号 计算方法：region实际的index除以每列允许排的最大个数，然后取整
 * @param regionId
 * @param maxRowNum 每列最大行数
 * @param areaArrayList 按area分组的二维regionId数组
 */
function getRegionColIndex(
  regionId: number,
  maxRowNum: number,
  areaArrayList: number[][]
): string {
  let regionRealIndex = 0
  areaArrayList.some((regionList, index) => {
    regionRealIndex =
      index * AREA_OFFSET +
      1 + // 这个region的总偏移值
      [].concat.apply([], areaArrayList).indexOf(regionId) // region本身在region list里的index
    return regionList.includes(regionId)
  })
  return String(Math.floor(regionRealIndex / maxRowNum))
}

function defaultGetSetting(defaultSetting?: RegionSetting): RegionSetting {
  return defaultSetting
}

/** 地域展示属性 */
export interface RegionSetting extends RegionOptionProps {
  /** 地域ID，默认为数字ID，也可自行订制为gz、ap-guangzhou等格式 */
  value: string
  /** 内容自定义，如没有则直接显示地域名 */
  content?: React.ReactChild
  /** 所属地区 */
  group?: string
  /** 所属大类，它不会展示，但同largeGroup的不同group会展示在同一列内 */
  largeGroup?: string
  /** 图标 */
  flag?: string
  /** 是否展示小红点 */
  dot?: boolean
}

interface IRegion extends Region {
  newFlag?: boolean
  disabled?: boolean
}

// 偏移值的来源：每个地区显示的块，地区title会占一行，块后会空一行，因此每个地区块除了所显示的region行数外还占用前述的额外两行
// 所以某region的总偏移值 = 2（每个地区的额外行数） * n（在这个region之前的地区个数） + 1（它所在地区的title占一行）
/** 一个地区的偏移值 */
const AREA_OFFSET = 2

/** 获取每列最大行数 */
function getMaxRows() {
  let windowHeight = window.innerHeight
  let maxRowNum
  switch (true) {
    case windowHeight <= 400:
      maxRowNum = 5
      break
    case windowHeight <= 500:
      maxRowNum = 7
      break
    case windowHeight <= 600:
      maxRowNum = 9
      break
    case windowHeight <= 700:
      maxRowNum = 11
      break
    case windowHeight <= 800:
      maxRowNum = 13
      break
    default:
      maxRowNum = 13
      break
  }
  return maxRowNum
}
