// TODO
import * as React from 'react'
import * as classnames from 'classnames'
import { memorize, purify, DuckCmpProps } from 'saga-duck'
import Duck from '../ducks/Grid'

const getHandlers = memorize(({ creators }: Duck, dispatch) => ({
  fetch: () => dispatch(creators.fetch({}))
}))

interface Props {}

export default purify(function(props: DuckCmpProps<Duck> & Props) {
  const { duck, store, dispatch } = props
  const handlers = getHandlers(props)
  return <div />
})
