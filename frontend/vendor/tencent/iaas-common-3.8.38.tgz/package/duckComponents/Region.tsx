import * as React from 'react'
import { memorize, DuckCmpProps } from 'saga-duck'
import Duck from '../ducks/Region'
import { Segment } from '@tencent/tea-component'
import { purify } from 'saga-duck/purify'
import buildConfig from '../buildConfig'

const getSelectHandler = memorize((duck, dispatch) => {
  return value => {
    dispatch(duck.creators.select(parseInt(value, 10)))
  }
})

export default purify(function DuckRegionBar({
  duck: { selectors },
  store,
  dispatch
}: DuckCmpProps<Duck>) {
  if (!buildConfig.showRegion) {
    return <noscript />
  }
  const list = selectors.list(store)

  if (!list.length) return <noscript />

  const options = list.map(item => {
    return {
      text: item.name,
      value: item.value.toString()
    }
  })
  const selected = selectors.selected(store)

  return (
    <Segment
      options={options}
      value={((selected && selected.value) || '').toString()}
      onChange={getSelectHandler(arguments[0])}
    />
  )
})
