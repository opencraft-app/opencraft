import * as React from 'react'
import { DuckCmpProps } from 'saga-duck'
import Duck from '../ducks/Page'

/**
 * 用于页面前置判断拦截，例如：未开通白名单
 *
 * 与 `ducks/Page` 中的 `preEffects`, `preError`, `selectors.interceptor` 机制关联
 *
 * 示例：
 * ```typescriptreact
 * export default makePageInterceptor(function Page(props: DuckCmpProps<PageDuck>){
 *    return <div>TODO</div>
 * })
 * ```
 * @param Component
 */
export default function makePageInterceptor<TProps extends DuckCmpProps<Duck>>(
  Component: React.FunctionComponent<TProps>
) {
  return function(props: TProps) {
    const { duck, store } = props

    const interceptor = duck.selectors.interceptor(store)
    // 前置判断
    if (interceptor) {
      return interceptor
    }
    return <Component {...props} />
  }
}
