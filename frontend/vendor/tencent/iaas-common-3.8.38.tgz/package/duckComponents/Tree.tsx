// import * as React from 'react'
// import { TreeNode, TreeView } from '@tencent/qcloud-component'
// import { purify, memorize, DuckCmpProps } from 'saga-duck'
// import Duck, {
//   ID,
//   Node,
//   AsyncNode,
//   NodeUIProps,
//   NODE_MAP,
//   BOOLEAN_MAP
// } from '../ducks/Tree'
// const jQuery = seajs.require('$')
// export const getNodeId = e =>
//   jQuery(e.target)
//     .closest('[role="treeitem"]')
//     .attr('id')

// const getHandlers = memorize(function({ creators }: Duck, dispatch) {
//   return {
//     onCheck: (node, checked) =>
//       dispatch(checked ? creators.check(node) : creators.uncheck(node)),
//     onExpand: (node, expanded) =>
//       dispatch(expanded ? creators.expand(node) : creators.collapse(node)),
//     reload: e => dispatch(creators.reload(getNodeId(e)))
//   }
// })
// interface MyDuck<TNode extends Node> extends Duck{
//   Node: TNode
// }
// type HANDLER = (...any: any[]) => any
// interface RENDER_OPTIONS<TNode extends Node> {
//   map: NODE_MAP<TNode>
//   rootVisible?: boolean
//   handlers: {
//     reload: HANDLER
//     onCheck: HANDLER
//     onExpand: HANDLER
//   }
//   duck: MyDuck<TNode>
//   store: any
// }

// function renderNode<TNode extends AsyncNode>(
//   id: ID,
//   options: RENDER_OPTIONS<TNode>,
//   root = false
// ): JSX.Element | JSX.Element[] {
//   const { map, handlers, rootVisible, duck, store } = options
//   const node = map[id]
//   if (!id || !node) {
//     return null
//   }
//   const item = duck.proxy(node, store)
//   if (!item) {
//     return null
//   }
//   let children: JSX.Element | JSX.Element[]
//   const error = item.error
//   if (!item.loading && error) {
//     children = (
//       <div>
//         加载失败，<a href="javascript:;" onClick={handlers.reload}>
//           重试
//         </a>
//       </div>
//     )
//   } else {
//     children =
//       item.children &&
//       item.children.reduce((list, id) => {
//         const node = renderNode(id, options)
//         if (node) {
//           list = list.concat(node)
//         }
//         return list
//       }, [])
//     if (root && !rootVisible) {
//       return children
//     }
//   }

//   return (
//     <TreeNode
//       key={'' + item.id}
//       id={'' + item.id}
//       label={item.label}
//       root={root}
//       leaf={item.leaf}
//       disabled={item.disabled}
//       active={item.active}
//       checkable={!!item.checkable}
//       checked={item.checked}
//       expanded={item.expanded}
//       loading={item.loading}
//       onCheck={handlers.onCheck}
//       onExpand={handlers.onExpand}
//     >
//       {children}
//     </TreeNode>
//   )
// }

// export default purify(function Tree<TNode extends AsyncNode>(
//   props: DuckCmpProps<MyDuck<TNode>> & { rootVisible?: boolean }
// ) {
//   const { duck, store, rootVisible = false } = props
//   const { selectors } = duck
//   const rootId = selectors.rootId(store)
//   const map = selectors.map(store)
//   const handlers = getHandlers(props)

//   return (
//     <TreeView>
//       {renderNode(rootId, { map, handlers, rootVisible, duck, store }, true)}
//     </TreeView>
//   )
// })
