import * as React from 'react'
import { memorize, purify, DuckCmpProps } from 'saga-duck'
import AsyncSelectDropdown, { Props } from './AsyncSelectDropdown'
import Duck, { Project } from '../ducks/Project'
import { DropdownListItem } from './SelectDropdown'

const getSelectHandler = memorize((duck, dispatch) => {
  return selected => {
    dispatch(duck.creators.select(selected.value))
  }
})

export default purify(function DuckRegionBar(
  props: DuckCmpProps<Duck> & Partial<Props<Project>>
) {
  const { duck, store } = props
  if (!duck.selectors.visible(store)) {
    return <noscript />
  }
  return <AsyncSelectDropdown toOption={toOption} {...props} />
})

function toOption(o: Project): DropdownListItem {
  return {
    label: o.name,
    id: o.projectId
  }
}
