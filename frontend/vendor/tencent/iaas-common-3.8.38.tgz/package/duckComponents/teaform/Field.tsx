/**
 * 对应tea2的Form.Item，处理将FieldAPI的校验信息同步到status、message等属性上
 */

import * as React from 'react'
import { FormItemProps, FormItem, BubbleContent, Text } from '@tencent/tea-component'
import { FieldAPI } from '../../ducks/Form'

export interface FormFieldProps extends Omit<FormItemProps, 'status'> {
  field: FieldAPI<any> | FieldAPI<any>[]
  /**提示类型可以为文本或者气泡，默认文本提示 */
  tipsType?: 'text' | 'bubble'
  /** 
   * 当表单项校验出错时，是否同时展示error与原有message（换行）。默认为false 
   * 
   * 注意当此项开启时，会额外加上如下结构
   * ```typescript
   * <>
   *   <Text parent="p">{error}</Text>
   *   <Text parent="p" theme="label">{message}</Text>
   * </>
   * ```
   */
  keepMessageOnError?: boolean
}
export default function FormField(props: FormFieldProps) {
  const {
    field,
    message: fixedMessage,
    children,
    label = <noscript />,
    tipsType = 'text',
    keepMessageOnError = false,
    ...rest
  } = props
  let status: FormItemProps['status'] = null
  let message: FormItemProps['message'] = fixedMessage

  const { error, isError } = getErrorOfFields([].concat(field))

  if (keepMessageOnError) {
    const messageText = <Text parent="p" theme="label">{fixedMessage}</Text>
    if (isError) {
      message = <>
        <Text parent="p">{error}</Text>
        {messageText}
      </>
    } else {
      message = messageText
    }
  } else {
    message = isError ? error : message
  }
  status = isError ? 'error' : null
  return (
    <FormItem
      status={status}
      message={
        tipsType === 'text'
          ? message
          : message && (
            <div style={{ position: 'absolute', zIndex: 2 }}>
              <BubbleContent placement="bottom" error>
                {message}
              </BubbleContent>
            </div>
          )
      }
      label={label}
      {...rest}
    >
      {children}
    </FormItem>
  )
}

export function getErrorOfFields(fields: FieldAPI<any>[]) {
  let error: React.ReactChild
  let isError: boolean
  for (const field of fields) {
    error = field.getError()
    // 某些情况下，这个错误是子级的，这时应该当作没有错误，否则渲染时React会报错
    if (error && typeof error === 'object' && !React.isValidElement(error)) {
      error = null
    }
    isError = field.getTouched() && !!error
    if (isError) {
      break
    }
  }
  return {
    error, isError
  }
}

interface ControlledProps<T> {
  value: T
  onChange: (T) => any
}
/**
 * 快速将表单项与 value/onChange 的受控组件绑定起来
 * @param field 
 * @param autoTouch 是否在onChange时自动`setTouched`，默认为true
 * @returns 
 */
export function controlledField<T>(field: FieldAPI<T>, autoTouch = true): ControlledProps<T> {
  return {
    value: field.getValue(),
    onChange: (v: T) => {
      field.setValue(v)
      field.clearError()
      if (autoTouch) {
        field.setTouched()
      }
    }
  }
}
