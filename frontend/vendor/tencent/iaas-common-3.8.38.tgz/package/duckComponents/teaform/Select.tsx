// 对应ducks/Form 原生下拉框
import * as React from 'react'
import { FieldAPI } from '../../ducks/Form'
import {
  Select as TeaSelect,
  SelectProps,
  SimulateSelectProps,
  SelectOptionWithGroup
} from '@tencent/tea-component'
import { t, Trans } from '@tencent/tea-app/lib/i18n'

export interface Item extends SelectOptionWithGroup {}
interface Props extends SimulateSelectProps{
  /** @deprecated 已废弃，不再生效 */
  type?: 'native' | 'simulate'
  value?: never
  field: FieldAPI<string>
  /** @deprecated 历史兼容，请使用options替代 */
  list?: Item[]
  beforeChange?: Function
  onChange?: (value: string) => void
}
function Select(props: Props) {
  const {
    field,
    list,
    type = 'simulate',
    placeholder = t('请选择'),
    beforeChange,
    ...rest
  } = props

  return (
    <TeaSelect
      type='simulate'
      size="m"
      appearance='button'
      boxSizeSync
      matchButtonWidth
      options={list}
      value={field.getValue()}
      onChange={value => {
        // simulate下拉框的value直接就是option.value了，所以不再需要进行数字转换
        if (typeof beforeChange === 'function') {
          if (beforeChange(value) === false) {
            return
          }
        }
        if (props && props.onChange) {
          props.onChange(value)
        }
        field.setValue(value)
        field.clearError()
        field.setTouched()
      }}
      placeholder={placeholder}
      {...rest}
    />
  )
}

Select['defaultLabelAlign'] = 'middle'
export default Select
