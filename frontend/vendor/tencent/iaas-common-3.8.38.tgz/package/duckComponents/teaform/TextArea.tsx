import * as React from 'react'
import { FieldAPI } from '../../ducks/Form'
import { TextArea as TeaTextArea, TextAreaProps } from '@tencent/tea-component'

interface Props extends Omit<TextAreaProps, 'value'> {
  field: FieldAPI<string>
}
function TextArea<T>(props: Props) {
  const { field, onBlur, onChange, ...rest } = props

  return (
    <TeaTextArea
      value={field.getValue() || ''}
      onChange={value => {
        field.setValue(value)
        field.clearError()
        if(onChange) {
          return onChange(value, this)
        }
      }
      }
      onBlur={e => {
        field.setTouched()
        if (onBlur) {
          return onBlur(e)
        }
      }}
      {...rest}
    />
  )
}

TextArea['defaultLabelAlign'] = TeaTextArea.defaultLabelAlign
export default TextArea
