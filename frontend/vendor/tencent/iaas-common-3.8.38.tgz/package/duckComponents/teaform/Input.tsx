import * as React from 'react'
import { FieldAPI } from '../../ducks/Form'
import { Input as TeaInput, InputProps } from '@tencent/tea-component'
import TextArea from './TextArea'

interface Props extends Omit<InputProps, 'value'> {
  field: FieldAPI<string>
}
function Input<T>(props: Props) {
  const { field, onBlur, onChange, ...rest } = props

  return (
    <TeaInput
      value={field.getValue() || ''}
      onChange={value => {
        field.setValue(value)
        field.clearError()
        if(onChange) {
          return onChange(value, this)
        }
      }
      }
      onBlur={e => {
        field.setTouched()
        if (onBlur) {
          return onBlur(e)
        }
      }}
      {...rest}
    />
  )
}
Input.TextArea = TextArea

Input['defaultLabelAlign'] = 'middle'
export default Input
