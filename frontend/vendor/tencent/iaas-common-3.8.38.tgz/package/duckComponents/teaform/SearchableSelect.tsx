import * as React from 'react'
import { FieldAPI } from '../../ducks/Form'
import { SearchableTeaSelectProps } from "../../duckComponents/SearchableTeaSelect"
import Select from '../SearchableTeaSelect'
import useControlled from '../../hooks/useControlled'

interface Props<TItem> extends SearchableTeaSelectProps<TItem>{
  field: FieldAPI<string>
}
export default function SearchableTeaSelect<TItem>(
  props: Props<TItem>
) {
  const { field, ...rest } = props
  const { duck, store, dispatch } = props
  useControlled(
    field.getValue(),
    v => {
      field.setValue(v)
      field.clearError()
      field.setTouched()
    },
    duck.selector(store).id,
    v => dispatch(duck.creators.select(v)),
  )
  return (
    <Select
      {...rest}
    />
  )
}

SearchableTeaSelect['defaultLabelAlign'] = "middle"