// 对应ducks/Form 原生下拉框，内容动态加载
import * as React from 'react'
import BaseAsyncSelect, {
  Props as AsyncSelectProps,
  Item
} from '../AsyncSelect'
import { FieldAPI } from '../../ducks/Form'

export { Item }

interface Props<T> extends Omit<AsyncSelectProps<T>, 'value' | 'onChange'> {
  field: FieldAPI<string | number>
}

function AsyncSelect<T>(props: Props<T>) {
  const { field, ...rest } = props

  const isNumber = typeof field.getValue() === 'number'

  // 有些是值为undefined, select会取第一个，想取请选择
  const isUndefOrNull =
    field.getValue() === undefined || field.getValue() === null

  return (
    <BaseAsyncSelect
      value={isUndefOrNull ? '' : String(field.getValue())}
      onChange={value => {
        field.setValue(isNumber ? +value : value)
        field.clearError()
        field.setTouched()
      }}
      {...rest}
    />
  )
}

AsyncSelect['defaultLabelAlign'] = 'middle'
export default AsyncSelect
