// 对应ducks/Form 原生文本框
import * as React from 'react'
import { FieldAPI } from '../../ducks/Form'
import Field, { FieldBaseProps } from './Field'
import { useConfig } from '@tencent/tea-component/lib/util'

interface Props extends FieldBaseProps<string> {
  className?: string
  style?: React.CSSProperties
  field: FieldAPI<string>
  placeholder?: string
  maxLength?: number
  disabled?: boolean
}
export default function<T>(props: Props) {
  const { classPrefix } = useConfig()
  const {
    className = `${classPrefix}-textarea`,
    style,
    field,
    fieldClassName,
    wrap,
    placeholder,
    tip,
    ...rest
  } = props

  return (
    <Field tip={tip} field={field} className={fieldClassName} wrap={wrap}>
      <textarea
        className={className}
        style={style}
        onChange={e => field.setValue(e.target.value)}
        onBlur={() => {
          field.setTouched()
        }}
        placeholder={placeholder}
        {...rest}
        value={field.getValue() || ''}
      />
    </Field>
  )
}
