// 对应ducks/Form 原生下拉框
import * as React from 'react'
import * as classnames from 'classnames'
import { InputAdorment, Input, InputProps } from '@tencent/tea-component'
import { useConfig } from '@tencent/tea-component/lib/util'
import Field from './Field'
import { FieldAPI } from '../../ducks/Form'
import { FieldBaseProps } from './Field'

interface Props extends FieldBaseProps<string> {
  className?: string
  size?: InputProps['size']
  style?: React.CSSProperties
  field: FieldAPI<string>
  placeholder?: string
  maxLength?: number
  type?: string
  disabled?: boolean
  children?
  before?: React.ReactNode
  after?: React.ReactNode
  onBlur?: Function
}
export default function<T>(props: Props) {
  const { classPrefix } = useConfig()
  const {
    className,
    style,
    field,
    fieldClassName,
    fieldErrorClassName,
    fieldTipClassName,
    wrap,
    tip,
    children,
    placeholder,
    type = 'text',
    disabled = false,
    before = null,
    after = null,
    onBlur = e => {},
    ...rest
  } = props

  let inner = (
    <Input
      disabled={disabled}
      className={classnames(`${classPrefix}-input`, className)}
      style={style}
      onChange={value => field.setValue(value)}
      onBlur={e => {
        field.setTouched()
        onBlur(e)
      }}
      value={field.getValue() || ''}
      placeholder={placeholder}
      type={type}
      {...rest}
    />
  )

  return (
    <Field
      field={field}
      className={fieldClassName}
      wrap={wrap}
      errorClassName={fieldErrorClassName}
      tipClassName={fieldTipClassName}
      tip={tip}
    >
      {before || after ? (
        <InputAdorment before={before} after={after}>
          {inner}
        </InputAdorment>
      ) : (
        inner
      )}
    </Field>
  )
}
