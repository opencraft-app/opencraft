// 对应ducks/Form 原生下拉框
import * as React from 'react'
import { Select, SelectProps } from '@tencent/tea-component'
import { t } from '@tencent/tea-app/lib/i18n'
import Field, { FieldBaseProps } from './Field'

export interface Item {
  value: string
  text: string
  disabled?: boolean
  tooltip?: string
}
interface Props extends FieldBaseProps<string | number> {
  className?: string
  size?: SelectProps['size']
  style?: React.CSSProperties
  list: Item[]
  needBlank?: boolean
  placeholder?: string
  disabled?: boolean
  onChange?: (value: string | number) => void
}
export default function<T>(props: Props) {
  const {
    className,
    style,
    field,
    fieldClassName,
    wrap,
    list,
    tip,
    needBlank,
    placeholder = t('请选择'),
    disabled,
    size
  } = props

  const isNumber = typeof field.getValue() === 'number'

  // 有些是值为undefined, select会取第一个，想取请选择
  const isUndefOrNull =
    field.getValue() === undefined || field.getValue() === null

  return (
    <Field field={field} className={fieldClassName} wrap={wrap} tip={tip}>
      <Select
        className={className}
        type="native"
        options={list}
        value={isUndefOrNull ? '' : String(field.getValue())}
        onChange={value => {
          if (props && props.onChange) {
            props.onChange(isNumber ? +value : value)
          }
          field.setValue(isNumber ? +value : value)
        }}
        placeholder={placeholder}
        disabled={disabled}
        style={style}
        size={size}
      />
    </Field>
  )
}
