// 多个checkbox组合
/**
 * radioLabels格式例子：
 * [{text:'服务器证书', value:'SVR'}, {text:'客户端证书', value:'CA'}...]
 */
import * as React from 'react'
import Field from './Field'
import { Checkbox } from '@tencent/tea-component'
import { FieldBaseProps } from './Field'
import { FieldAPI } from '../../ducks/Form'
export interface Item {
  value: string
  text: string
  disabled?: boolean
}
interface Props extends FieldBaseProps<string[]> {
  className?: string
  style?: React.CSSProperties
  field: FieldAPI<string[]>
  checkboxLabels: Item[]
}
export default function<T>(props: Props) {
  const {
    field,
    fieldClassName,
    wrap,
    checkboxLabels
  } = props

  return (
    <Field field={field} className={fieldClassName} wrap={wrap}>
      <Checkbox.Group
        value={field.getValue()}
        onChange={value => field.setValue(value)}
      >
        {checkboxLabels.map(({ value, text, disabled }) => (
          <Checkbox key={value} name={value} disabled={disabled}>
            {text}
          </Checkbox>
        ))}
      </Checkbox.Group>
    </Field>
  )
}
