// 多个radio组合
/**
 * radioLabels格式例子：
 * [{text:'服务器证书', value:'SVR'}, {text:'客户端证书', value:'CA'}...]
 */
import * as React from 'react'
import { Radio, RadioProps } from '@tencent/tea-component'
import Field, { FieldBaseProps } from './Field'
import { FieldAPI } from '../../ducks/Form'

export interface Item extends Omit<RadioProps, 'value'> {
  text: React.ReactNode
  // value 不是控制 Radio 状态的布尔值，而是作为 Radio 的标识
  value: string
}
interface Props extends FieldBaseProps<string> {
  className?: string
  style?: React.CSSProperties
  field: FieldAPI<string>
  radioLabels: Item[]
}
export default function<T>(props: Props) {
  const { field, fieldClassName, wrap, radioLabels } = props
  return (
    <Field field={field} className={fieldClassName} wrap={wrap}>
      <Radio.Group
        value={field.getValue()}
        onChange={value => field.setValue(value)}
      >
        {radioLabels.map(({ value, text, ...rest }) => (
          <Radio key={value} display="block" name={value} {...rest}>
            {text}
          </Radio>
        ))}
      </Radio.Group>
    </Field>
  )
}
