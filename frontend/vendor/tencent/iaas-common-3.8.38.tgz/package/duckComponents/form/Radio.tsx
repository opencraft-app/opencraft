// 对应ducks/Form 原生下拉框
import * as React from 'react'
import { Radio } from '@tencent/tea-component'
import { FieldAPI } from '../../ducks/Form'
import { FieldBaseProps } from './Field'

interface Props extends FieldBaseProps<string> {
  value: string
  className?: string
  style?: React.CSSProperties
  onClick?(value: string): void
  field: FieldAPI<string>
  children?: React.ReactChild
}

export default function<T>(props: Props) {
  const { className, style, field, value, wrap, onClick, ...rest } = props
  return (
    <Radio
      {...rest}
      name={value}
      style={style}
      className={className}
      value={field.getValue() == value}
      onClick={e => {
        field.setValue(value)
        onClick && onClick(value)
      }}
      onBlur={() => {
        field.setTouched()
      }}
    />
  )
}
