// 对应ducks/Form 原生文本框
import * as React from 'react'
import { t } from '@tencent/tea-app/lib/i18n'
import Field from './Field'
import { FieldBaseProps } from './Field'
import { FieldAPI } from '../../ducks/Form'

interface Props extends FieldBaseProps<File> {
  className?: string
  style?: React.CSSProperties
  field: FieldAPI<File>
  placeholder?: string
}

export default function<T>(props: Props) {
  const {
    field,
    fieldClassName,
    wrap,
    tip
  } = props
  const uploadFile = e => {
    let file: File = e.target.files[0]
    field.setValue(file)
  }
  return (
    <Field tip={tip} field={field} className={fieldClassName} wrap={wrap}>
      <input
        type="text"
        className="tc-15-input-text m"
        readOnly
        value={field.getValue() && field.getValue().name}
        title={field.getValue() && field.getValue().name}
        placeholder={t('还未选择文件')}
      />
      <div className="tc-upload-btn" title={t('选择文件')}>
        <div className="file-input-wrap">
          <input
            type="file"
            onChange={e => uploadFile(e)}
            onBlur={() => {
              field.setTouched()
            }}
          />
          <span>{field.getValue() ? t('重新上传') : t('上传')}</span>
        </div>
      </div>
    </Field>
  )
}
