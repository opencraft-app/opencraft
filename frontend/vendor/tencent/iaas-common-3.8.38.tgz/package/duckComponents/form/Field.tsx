// 对应ducks/Form
import * as React from 'react'
import * as classnames from 'classnames'
import { FieldAPI } from '../../ducks/Form'
import { useConfig } from '@tencent/tea-component/lib/util'

type JSXContent = JSX.Element | JSX.Element[] | string
export interface Props<T> extends FieldBaseProps<T> {
  className?: string
  errorClassName?: string
  tipClassName?: string
  children?: JSXContent | ((field: FieldAPI<T>) => JSXContent)
}
export interface FieldBaseProps<T> {
  field: FieldAPI<T>
  fieldClassName?: string
  fieldErrorClassName?: string
  fieldTipClassName?: string
  /** 是否使用标准Field包装，默认为true */
  wrap?: boolean
  /** 默认说明文案 */
  tip?: string | JSX.Element
  /** 是否展示icon */
  isIcon?: boolean
}
export default function<T>(props: Props<T>) {
  const { classPrefix } = useConfig()

  const {
    field,
    className = `${classPrefix}-form__controls`,
    errorClassName = 'is-error',
    tipClassName = `${classPrefix}-form__help-text`,
    tip,
    children,
    wrap = true,
    isIcon = true
  } = props

  let content = children

  if (!wrap) {
    if (!content) {
      return <noscript />
    }
    if (typeof content === 'function') {
      content = content(field)
    }
    if (typeof content === 'string') {
      return <span>{content}</span>
    }
    if (Array.isArray(content)) {
      return <div>{content}</div>
    }
    return content
  }

  const error = field.getError()
  const isError = field.getTouched() && !!error
  return (
    <div
      className={classnames(className, {
        [errorClassName]: isError
      })}
    >
      {children}
      {isError && isIcon && (
        <b
          key="icon"
          className={`${classPrefix}-icon ${classPrefix}-icon-valid`}
        />
      )}
      {(isError || tip) && (
        <p className={tipClassName}>{(isError && error) || tip}</p>
      )}
    </div>
  )
}
