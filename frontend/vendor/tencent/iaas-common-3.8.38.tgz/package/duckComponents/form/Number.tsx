// 对应ducks/Form 原生文本框
import * as React from 'react'
import * as classnames from 'classnames'
import Field, { FieldBaseProps } from './Field'
import { FieldAPI } from '../../ducks/Form'

interface Props extends FieldBaseProps<number> {
  className?: string
  style?: React.CSSProperties
  field: FieldAPI<number>
  placeholder?: string
  tip?: string
  disabled?: boolean
  children?
}
export default function<T>(props: Props) {
  const {
    className,
    style,
    field,
    fieldClassName,
    wrap,
    children,
    placeholder,
    tip,
    disabled = false
  } = props

  return (
    <Field field={field} className={fieldClassName} wrap={wrap} tip={tip}>
      <input
        disabled={disabled}
        type="number"
        className={classnames('tc-15-input-text', className)}
        style={style}
        onChange={e => field.setValue(+e.target.value)}
        onBlur={() => {
          field.setTouched()
        }}
        value={'' + field.getValue()}
        placeholder={placeholder}
      />
      {children && children}
    </Field>
  )
}
