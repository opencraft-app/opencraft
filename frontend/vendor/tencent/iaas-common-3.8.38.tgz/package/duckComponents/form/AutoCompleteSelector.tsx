// 对应ducks/Form 原生下拉框
import * as React from 'react'
import Field from './Field'
import AutoComplete from '../../components/PureAutocomplete'
import { FieldBaseProps } from './Field'

export interface Item {
  value: string
  text: string
}

interface Props extends FieldBaseProps<string> {
  className?: string
  style?: React.CSSProperties
  list: Item[]
  defaultIndex?: number
  placeholder?: string
  needBlank?: boolean
}

export default function<T>(props: Props) {
  const {
    field,
    fieldClassName,
    wrap,
    list,
    tip,
    defaultIndex
  } = props

  return (
    <Field field={field} className={fieldClassName} wrap={wrap} tip={tip}>
      <AutoComplete
        dataSource={list}
        onItemSelect={item => field.setValue(item?.value.toString())}
        value={field.getValue()}
        defaultIndex={defaultIndex}
      />
    </Field>
  )
}
