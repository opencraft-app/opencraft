import { FieldAPI } from "../../ducks/Form";

export const getFormItemProps = (field: FieldAPI<any>) => ({
    message: (field.getTouched() && field.getError()) || '',
    status: field.getTouched() && field.getError() ? ('error' as any) : null
  })