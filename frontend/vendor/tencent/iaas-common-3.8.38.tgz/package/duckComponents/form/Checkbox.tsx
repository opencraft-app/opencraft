import * as React from 'react'
import Field from './Field'
import { FieldAPI } from '../../ducks/Form'
import { FieldBaseProps } from './Field'
import { Checkbox } from '@tencent/tea-component'
interface Props extends FieldBaseProps<string | boolean> {
  label?: string | React.ReactNode
  className?: string
  style?: React.CSSProperties
  onClick?(value: string): void
  field: FieldAPI<string | boolean>
  disabled?: boolean
  trueValue?: string | boolean
  falseValue?: string | boolean
  onChange?: (value: string | boolean) => void
}
export default function<T>(props: Props) {
  const {
    className,
    style,
    field,
    wrap,
    onClick,
    label,
    fieldClassName,
    disabled,
    trueValue = true,
    falseValue = false,
    tip,
    ...rest
  } = props
  return (
    <Field field={field} className={fieldClassName} wrap={wrap} tip={tip}>
      <Checkbox
        disabled={disabled}
        value={field.getValue() === trueValue}
        onClick={() => {
          let value = field.getValue() === trueValue ? falseValue : trueValue
          field.setValue(value)
          props.onChange && props.onChange(value)
        }}
        {...rest}
      >
        {label}
      </Checkbox>
    </Field>
  )
}
