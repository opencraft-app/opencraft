// 对应ducks/Form 原生下拉框，内容动态加载
import * as React from 'react'
import * as classnames from 'classnames'
import Field from './Field'
import { FieldAPI } from '../../ducks/Form'
import AsyncSelect, { Props as AsyncSelectProps, Item } from '../AsyncSelect'
import { FieldBaseProps } from './Field'

interface Props<T>
  extends FieldBaseProps<string | number>,
    Omit<AsyncSelectProps<T>, 'value' | 'onChange'> {}
function defaultToItem(o): Item {
  return o
}
export default function<T>(props: Props<T>) {
  const { field, fieldClassName, wrap, ...rest } = props

  return (
    <Field field={field} className={fieldClassName} wrap={wrap}>
      <AsyncSelect
        value={String(field.getValue())}
        onChange={v => {
          field.setValue(v)
          field.setTouched()
        }}
        {...rest}
      />
    </Field>
  )
}
