import * as React from 'react'
import { DuckCmpProps, purify, memorize } from 'saga-duck'
import { SearchBox, SearchBoxProps, Text } from '@tencent/tea-component'
import Duck from '../ducks/SearchableSelect'
import { t, Trans } from '@tencent/tea-app/lib/i18n'
import {
  Dropdown,
  List,
  StatusTip,
  StatusTipProps,
  DropdownProps,
  ListItemProps,
  ListProps
} from '@tencent/tea-component'
import getErrorMessage from '../util/getErrorMessage'

interface MyDuck<T> extends Duck {
  Item: T
}
interface Props<T = any>
  extends DuckCmpProps<MyDuck<T>>,
  Omit<DropdownProps, 'button' | 'children' | 'clickClose'> {
  /** 判断选项是否被禁用 */
  itemDisabled?(item: T): boolean
  /** 选项如何被渲染，如果不指定，则直接展示id（duck.getId） */
  itemRenderer?(item: T): React.ReactChild
  /** 选项展示什么tip */
  itemTip?(item: T): React.ReactChild
  placeholder?: React.ReactChild
  searchPlaceholder?: string
}

const getHandlers = memorize(({ creators }: Duck, dispatch) => ({
  inputKeyword: keyword => dispatch(creators.inputKeyword(keyword)),
  search: keyword => dispatch(creators.search(keyword)),
  clearKeyword: () => dispatch(creators.search('')),
  select: selected => dispatch(creators.select(selected)),
  more: () => dispatch(creators.more()),
  reload: () => dispatch(creators.reload())
}))

const SearchalbeSelect = purify(function Cmp<T>(props: Props<T>) {
  const handlers = getHandlers(props)
  const {
    duck,
    store,
    dispatch,
    itemDisabled = o => false,
    itemRenderer = o => duck.getId(o),
    itemTip = o => undefined,
    placeholder = t('请选择...'),
    searchPlaceholder = t('输入关键字搜索'),
    size = 'm',
    ...rest
  } = props
  const { selector, selectors } = duck
  const { id: selectedId } = selector(store)

  const selected = selectors.selected(store)
  const selectedItem = selected ? itemRenderer(selected) : null

  return (
    <Dropdown
      appearence="button"
      button={selectedItem || selectedId || placeholder}
      clickClose={false}
      size={size}
      {...rest}
    >
      {close => (
        <div>
          <SearchableSearchBox
            duck={duck}
            store={store}
            dispatch={dispatch}
            placeholder={searchPlaceholder}
          />
          <SearchableList
            duck={duck}
            store={store}
            dispatch={dispatch}
            type="option"
            getListItemContent={itemRenderer}
            getListItemProps={o => {
              const id = duck.getId(o)
              return {
                current: id === selectedId,
                disabled: itemDisabled(o),
                tooltip: itemTip(o),
                onClick: () => {
                  handlers.select(id)
                  close()
                }
              }
            }}
          />
        </div>
      )}
    </Dropdown>
  )
})

SearchalbeSelect['defaultLabelAlign'] = 'middle'
export default SearchalbeSelect

// 子组件，可以自由组装成其它形式
export interface SearchableSearchBoxProps
  extends DuckCmpProps<MyDuck<any>>,
  Omit<SearchBoxProps, 'value' | 'onChange' | 'onSearch' | 'onClear'> { }
/**
 * 搜索框
 */
export function SearchableSearchBox(props: SearchableSearchBoxProps) {
  const handlers = getHandlers(props)
  const {
    duck,
    store,
    dispatch,
    placeholder = t('输入关键字搜索'),
    ...rest
  } = props
  const { selector } = duck
  const { pendingKeyword } = selector(store)

  return (
    <SearchBox
      value={pendingKeyword}
      onChange={handlers.inputKeyword}
      onSearch={handlers.search}
      onClear={handlers.clearKeyword}
      placeholder={placeholder}
      {...rest}
    />
  )
}
export interface SearchableListProps<T>
  extends DuckCmpProps<MyDuck<T>>,
  Omit<ListProps, 'onScrollBottom'> {
  getListItemProps?(item: T): Partial<ListItemProps>
  getListItemContent(item: T): React.ReactChild
  addons?: Addon[]
}

interface Addon {
  onInjectTip?: Middleware<
    (opts: SearchableListStatusTipProps) => React.ReactNode
  >
}
/**
 * 列表
 */
export function SearchableList<T>(props: SearchableListProps<T>) {
  const handlers = getHandlers(props)
  const {
    duck,
    store,
    dispatch,
    getListItemProps = o => { },
    getListItemContent,
    addons = [],
    ...rest
  } = props
  const { selector } = duck
  const { id: selectedId, list, loadingMore, nomore } = selector(store)

  // 如果是加载更多的模式，loading应该展示在列表下方
  const isLoadMoreMode = loadingMore
  const getStatusTip = useMiddleware(
    addons,
    'onInjectTip'
  )((opts: SearchableListStatusTipProps) => {
    return <SearchableListStatusTip {...opts} />
  })
  const statusTip = getStatusTip({
    duck,
    store,
    dispatch,
    wrap: tip => <List.StatusTip>{tip}</List.StatusTip>
  })

  return (
    <List onScrollBottom={nomore ? undefined : handlers.more} {...rest}>
      {!isLoadMoreMode && statusTip}
      {(list || []).map(o => {
        const id = duck.getId(o)
        const props = getListItemProps(o)
        return (
          <List.Item
            key={id}
            current={id === selectedId}
            onClick={() => {
              handlers.select(id)
            }}
            {...props}
          >
            {getListItemContent(o)}
          </List.Item>
        )
      })}
      {isLoadMoreMode && statusTip}
    </List>
  )
}

/**
 * 状态Tip
 */
export interface SearchableListStatusTipProps
  extends DuckCmpProps<MyDuck<any>>,
  Omit<StatusTipProps, 'status' | 'onRetry' | 'onClear'> {
  wrap?: (content: React.ReactChild) => React.ReactElement
}
export function SearchableListStatusTip(props: SearchableListStatusTipProps) {
  const handlers = getHandlers(props)
  const { duck, store, dispatch, wrap, ...rest } = props
  const { selector, selectors } = duck
  const {
    keyword,
    list,
    totalCount,
    fetcher: { loading, error }
  } = selector(store)

  const tipProps = getStatusTipProps({
    keyword,
    list,
    totalCount,
    loading,
    error,
    onRetry: handlers.reload,
    onClear: handlers.clearKeyword
  })

  if (!tipProps) {
    return null
  }

  const tip = <StatusTip {...tipProps} {...rest} />
  if (wrap) {
    return wrap(tip)
  }
  return tip
}

interface StatusTipOptions {
  keyword: string
  list: any[] | null
  totalCount: number | null
  /** 当前端有条目过滤时，不展示总条数 */
  hideCount?: boolean
  loading: boolean
  error: any
  onRetry: () => any
  onClear: () => any
}
export function getStatusTipProps(options: StatusTipOptions): StatusTipProps | null {
  const {
    loading,
    keyword,
    list,
    totalCount,
    hideCount,
    error,
    onRetry,
    onClear
  } = options
  let tipProps: StatusTipProps | null = null

  if (loading) {
    tipProps = {
      status: 'loading'
    }
  } else if (error) {
    tipProps = {
      status: 'error',
      errorText: React.isValidElement(error) ?
        <Text theme="danger">{error}</Text> :
        getErrorMessage(error),
      onRetry
    }
  } else if (keyword && list) {
    tipProps = {
      status: 'found',
      foundText:
        list.length > 0
          ? (hideCount || typeof totalCount !== 'number') ? t('找到以下结果') : t('找到{{count}}条结果', { count: totalCount })
          : t('搜索"{{keyword}}"暂无数据', { keyword }),
      onClear
    }
  } else if (list && list.length <= 0) {
    tipProps = {
      status: 'empty'
    }
  }
  return tipProps
}
interface Middleware<T> {
  (next: T): T
}

function useMiddleware<K extends keyof Addon>(addons: Addon[], name: K) {
  // infer value type
  type Value<T> = T extends Middleware<infer V> ? V : never
  type ValueType = Value<Addon[typeof name]>

  if (!addons || !addons.length) {
    return (initialValue: ValueType) => initialValue
  }

  return (initialValue: ValueType) =>
    addons
      .map(x => x[name])
      .filter(Boolean)
      .reduce<ValueType>(
        (previous, middleware: Middleware<any>) => middleware(previous),
        initialValue
      )
}
