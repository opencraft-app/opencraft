/**
 * GridPage中的Pagination
 */
import * as React from 'react'
import { Pagination, PaginationProps } from '@tencent/tea-component'
import { memorize, purify, DuckCmpProps } from 'saga-duck'

import Duck from '../ducks/GridPage'

const getHandler = memorize((duck, dispatch) => {
  return ({ pageIndex, pageSize }) => {
    dispatch(duck.creators.paginate(pageIndex, pageSize))
  }
})

interface Props
  extends Omit<
    PaginationProps,
    'pageSize' | 'onPagingChange' | 'pageIndex' | 'recordCount'
  > {
  minPageSize?: number
  maxPageSize?: number
  pageSizeInterval?: number
}

export default purify(function DuckGridPagePagination(
  props: DuckCmpProps<Duck> & Props
) {
  const {
    store,
    dispatch,
    duck,
    minPageSize,
    maxPageSize,
    pageSizeInterval,
    ...rest
  } = props
  const {
    selectors,
    ducks: { grid }
  } = duck

  const onPageChange = getHandler(props)

  return (
    <Pagination
      pageSize={selectors.count(store)}
      onPagingChange={onPageChange}
      pageIndex={selectors.page(store)}
      recordCount={grid.selectors.totalCount(store)}
      pageSizeOptions={getCountList(
        minPageSize || duck.minPageSize,
        maxPageSize || duck.maxPageSize,
        pageSizeInterval || duck.pageSizeInterval
      )}
      {...rest}
    />
  )
})

const betterPages = [5, 10, 20, 50, 100, 200, 500, 1000]
function getCountList(minPageSize = 5, maxPageSize = 50, pageSizeInterval = 5) {
  return betterPages.filter(v => v >= minPageSize && v <= maxPageSize)
  // const listArr = []
  // for (
  //   let pageSize = minPageSize;
  //   pageSize <= maxPageSize;
  //   pageSize += pageSizeInterval
  // ) {
  //   listArr.push(pageSize)
  // }
  // return listArr
}
