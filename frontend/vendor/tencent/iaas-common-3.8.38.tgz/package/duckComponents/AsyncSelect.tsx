import * as React from 'react'
import * as classnames from 'classnames'
import { DuckCmpProps } from 'saga-duck'
import Select, { Props as SelectProps, Item } from '../components/Select'
import { t, Trans } from '@tencent/tea-app/lib/i18n'
import Fetcher from '../ducks/Fetcher'
import getErrorMessage from '../util/getErrorMessage'

interface MyFetcher<TItem> extends Fetcher {
  Data: TItem[]
}
export { Item }
export interface Props<T>
  extends Omit<DuckCmpProps<MyFetcher<T>>, 'dispatch'>,
    Omit<SelectProps, 'list'> {
  toItem?: (o: T) => Item
  emptyText?: string
}
function defaultToItem<T>(o: T): Item {
  return o as any
}
export default function<T>(props: Props<T>) {
  const {
    duck,
    store,
    toItem = defaultToItem,
    emptyText = t('无可用选项'),
    ...rest
  } = props
  const state = duck.selector(store)

  let list: Item[]
  if (state.loading) {
    list = [
      {
        value: null,
        text: t('加载中...'),
        disabled: true
      }
    ]
  } else if (state.error) {
    let error = state.error
    let code = error.code
    const message = getErrorMessage(error)
    list = [
      {
        value: null,
        text: t('加载失败 [#{{code}}]{{message}}', {
          code: code || -1,
          message
        }),
        disabled: true
      }
    ]
  } else {
    list = (state.data && state.data.length && state.data.map(toItem)) || [
      {
        value: null,
        text: emptyText,
        disabled: true
      }
    ]
  }

  return <Select list={list} {...rest} />
}
