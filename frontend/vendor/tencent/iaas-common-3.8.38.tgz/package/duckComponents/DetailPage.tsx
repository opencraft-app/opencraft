import * as React from 'react'
import * as classnames from 'classnames'
import CamTips, { isCamRefused } from '../components/Cam'
import { purify, DuckCmpProps } from 'saga-duck'
import Duck from '../ducks/DetailPage'
import { Layout, Justify, Text, Icon } from '@tencent/tea-component'
import { t } from '@tencent/tea-app/lib/i18n'
import getErrorMessage from '../util/getErrorMessage'

const { Content, Body } = Layout



const TextTip = purify(function TextTip({ children }) {
  return <div style={{ textAlign: 'center', padding: '100px' }}>{children}</div>
})

function historyBack() {
  history.go(-1)
}
type FunctionChildren<T> = (data: T) => React.ReactNode
interface Props<TDuck = any> extends DuckCmpProps<TDuck> {
  className?: string
  /** 是否展示返回按钮，默认为true */
  showBackButton?: boolean
  /** 点击返回时的回调 */
  onBack?: () => any
  /** 是否优先尝试返回历史记录（如果有的话），仅当onBack未设置时才有效 */
  backHistory?: boolean
  /** 返回路由，仅当onBack未设置时才有效 */
  backRoute?: string
  /** 返回文案，现有样式实际上并不会展示 @deprecated */
  backTitle?: string
  /** 标题 */
  title?: React.ReactNode
  /** 子标题 */
  subTitle?: React.ReactNode
  /** 额外标题 */
  titleRight?: React.ReactNode
  children?: React.ReactNode | FunctionChildren<DuckCmpProps<TDuck>>
  popComponent?: React.ReactNode
  /** 是否为全屏 */
  full?: boolean
  /** 自定义错误处理函数，如果提供则覆盖默认错误处理 */
  errorHandler?: (error: any) => React.ReactNode
}
// TODO 纯render组件是否会不利于性能优化？
// 因为这里是传递完整的store进来，数据一定会变动
// 或可考虑做一层包装，即取出要用的数据后，继续下一级
export default purify(function DetailPage<TDuck extends Duck = Duck>({
  duck,
  store,
  dispatch,
  className,
  showBackButton = true,
  /** 是否优先尝试返回历史记录（如果有的话） */
  backHistory,
  backRoute,
  backTitle,
  title,
  subTitle,
  onBack,
  titleRight,
  children,
  full,
  popComponent = <noscript />,
  errorHandler
}: Props<TDuck>) {
  const { selectors } = duck
  const id = selectors.id(store)
  const data = selectors.data(store)
  const loading = selectors.loading(store)
  const error = selectors.error(store) as any
  // 如果历史记录大于2（chrome打开时，新标签页也是1次，当前是第2次）
  if (!onBack && backHistory && history.length > 2) {
    backRoute = ''
    onBack = historyBack
  }

  if (!onBack && backRoute) {
    onBack = () => {
      seajs.require('router').navigate(backRoute)
    }
  }

  let overrideChildren: React.ReactNode
  if (loading) {
    // loading最优先
    overrideChildren = <TextTip>{t('加载中...')}</TextTip>
  } else if (error) {
   if (errorHandler) {
      overrideChildren = errorHandler(error)
    } else {
      const message = getErrorMessage(error)
      // 其次错误
      if(isCamRefused(error)){
        overrideChildren = <CamTips message={message} />
      }else{
        overrideChildren = <TextTip>
        {message}
        </TextTip>
      }
    }
  } else if (!data) {
    // 其次没有找到
    overrideChildren = <TextTip>{t('未找到指定资源')}</TextTip>
  } else {
    overrideChildren =
      typeof children === 'function'
        ? children({ duck, store, dispatch })
        : children
  }
  return (
    <Layout>
      <Body>
        <Content>
          <Content.Header
            showBackButton={showBackButton}
            title={title || id}
            subtitle={
              typeof subTitle === 'string' ? <Text theme="weak">（{subTitle}）</Text> : subTitle
            }
            onBackButtonClick={onBack}
            operation={titleRight}
          ></Content.Header>
          <Content.Body full={full}>{overrideChildren}</Content.Body>
        </Content>
      </Body>
    </Layout>
  )
})
