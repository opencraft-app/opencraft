import * as React from 'react'
import * as classnames from 'classnames'
import Duck from '../ducks/Select'
import { DuckCmpProps, purify, memorize } from 'saga-duck'
import { Dropdown as DropdownList, Menu } from '@tencent/tea-component'
import { t } from '@tencent/tea-app/lib/i18n'
export interface DropdownListItem {
  /**
   * 列表项的标识，在同一个列表中不允许重复
   */
  id: string | number

  /**
   * 列表显示的标签，可以为字符串或者是特定 React Element
   */
  label?: string | JSX.Element

  /**
   * 列表是否被禁用，默认为 false
   */
  disabled?: boolean

  /**
   * 子dropdown（支持分类下拉菜单,暂时只支持到二级下拉菜单）
   */
  // sub?: DropdownListItem[]
}

interface MyDuck<TItem, TId> extends Duck {
  ID: TId
  Item: TItem
}
const getHandlers = memorize((duck: Duck, dispatch) => ({
  onSelect: (selected: DropdownListItem) =>
    dispatch(duck.creators.select(selected.id))
}))
export interface Props<TItem> {
  /** 注意，id一定要映射为value */
  toOption: (item: TItem) => DropdownListItem
  className?: string
  /** 人为禁用 */
  disabled?: boolean
  /** 标红 */
  invalid?: boolean
  /** 列表为空时的提示 */
  emptyText?: string
  /** 未选时的提示 */
  noSelectText?: string
  /** 展示文本，优先于noSelectText及已选项 */
  placeholder?: string
}
export default purify(function<TItem, TId>(
  props: DuckCmpProps<MyDuck<TItem, TId>> & Props<TItem>
) {
  const {
    duck,
    store,
    dispatch,
    toOption,
    className,
    invalid,
    disabled,
    emptyText = t('无可用选项'),
    noSelectText = t('请选择'),
    placeholder
  } = props
  const { list, id } = duck.selector(store)
  const selected = duck.selectors.selected(store)

  const buttonList = list.map(toOption)
  // 是否可用
  buttonList.forEach(
    (o, index) => (o.disabled = !duck.isAvailable(list[index]))
  )

  const buttonSelected = buttonList[list.indexOf(selected)]

  const empty = buttonList.length <= 0

  const handlers = getHandlers(props)
  return (
    <DropdownList
      appearence="link"
      // selected={buttonSelected}
      className={classnames(className, { 'err-style': invalid })}
      // simulateSelect={false}
      button={
        placeholder ||
        (buttonSelected
          ? buttonSelected.label
          : empty
          ? emptyText
          : noSelectText)
      }
      // disabled={disabled || empty}
      // onSelect={handlers.onSelect}
    >
      <Menu>
        {buttonList.map(item => {
          return <Menu.Item title={item.label} />
        })}
      </Menu>
    </DropdownList>
  )
})
