// TODO 这里ts类型校验搞不定，先作为模板使用吧
import * as React from 'react'
import * as classnames from 'classnames'
import { memorize, purify, DuckCmpProps } from 'saga-duck'
import Dialog from '../duckComponents/Dialog'
import FormDialog from '../ducks/FormDialog'
import Form from '../ducks/Form'
import { t } from '@tencent/tea-app/lib/i18n'
interface Props<TFormDialog extends FormDialog>
  extends DuckCmpProps<TFormDialog> {
  title?: string
  Form: React.ComponentClass<
    DuckCmpProps<TFormDialog['ducks']['form']> & FormProps<TFormDialog['Data']>
  >
}
interface FormProps<TInstance> {
  instance: TInstance
}
export default purify(function<T extends FormDialog>(props: Props<T>) {
  const { duck, store, dispatch, title = t('编辑'), Form } = props
  const { data } = duck.selector(store)
  return (
    <Dialog duck={duck} store={store} dispatch={dispatch} title={title}>
      <Form
        duck={duck.ducks.form}
        store={store}
        dispatch={dispatch}
        instance={data}
      />
    </Dialog>
  )
})
