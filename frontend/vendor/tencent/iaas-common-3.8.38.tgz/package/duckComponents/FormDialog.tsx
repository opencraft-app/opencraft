/**
 * 表单弹框，传入QcForm类即可，与ducks/DialogPure组合使用
 * 或可改名为 QcFormDialog？
 */
import * as React from 'react'
import Dialog from './Dialog'
import { purify, DuckCmpProps } from 'saga-duck'
import Duck from '../ducks/DialogPure'

/**
 * 注意。。。QcloudComponent中的Dialog实现比较暴力，如果这里用refs，React会报异常（refs相关销毁出错）
 * 所以换成回调的方式获取实例
 *
 */

interface Props {
  title?: string
  Form: any
  size?: number | 's' | 'm' | 'l' | 'xl' | 'auto'
  showFooter?: boolean
}

export default purify(
  class FormDialog extends React.Component<DuckCmpProps<Duck> & Props, any> {
    _refCallback
    _form
    onSubmit
    constructor(props) {
      super(props)
      this._refCallback = form => {
        this._form = form
      }
      this.onSubmit = this._onSubmit.bind(this)
    }
    _onSubmit() {
      const form = this._form
      // 校验
      if (!form.isValid()) {
        return
      }
      const {
        duck: { creators },
        dispatch
      } = this.props
      // 提交
      dispatch(creators.submit(form.getValue()))
    }
    render() {
      const {
        duck,
        store,
        dispatch,
        title: fixedTitle,
        size,
        showFooter = true,
        Form
      } = this.props
      const { selectors } = duck
      const data = selectors.data(store)
      const { title = fixedTitle, value } = data
      return (
        <Dialog
          {...{ duck, store, dispatch, size, title, showFooter }}
          onSubmit={this.onSubmit}
        >
          <Form
            refCallback={this._refCallback}
            value={value}
            options={data}
            onSubmit={this.onSubmit}
          />
        </Dialog>
      )
    }
  }
)
