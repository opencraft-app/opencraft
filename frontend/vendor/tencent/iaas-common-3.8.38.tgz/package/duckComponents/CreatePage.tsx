import * as React from 'react'
import { purify, DuckCmpProps } from 'saga-duck'
import Duck from '../ducks/Page'
import { Layout, Icon, Justify, Card, Text } from '@tencent/tea-component'

const { Content, Body } = Layout

function historyBack() {
  history.go(-1)
}

interface Props {
  className?: string
  /** 点击返回时的回调 */
  onBack?: () => any
  /** 是否优先尝试返回历史记录（如果有的话），仅当onBack未设置时才有效 */
  backHistory?: boolean
  /** 返回路由，仅当onBack未设置时才有效 */
  backRoute?: string
  /** 返回文案，现有样式实际上并不会展示 @deprecated */
  backTitle?: string
  /** 标题 */
  title?: string
  /** 子标题 */
  subTitle?: string | JSX.Element | JSX.Element[]
  /** 额外标题 */
  titleRight?: string | JSX.Element | JSX.Element[]
  children?: string | JSX.Element | JSX.Element[]
  /**
   * 是否需要展示底部
   */
  contentFooter?: string | JSX.Element | JSX.Element[]
  /**
   * 内容区域是否包裹一层Card
   */
  contentBodyCard?: boolean
  /**
   *   内容区撑满
   */
  full?: boolean
  /**
   * 是否显示后退按钮
   */
  showBackButton?: boolean
}

export default purify(function CreatePage({
  duck: { selectors },
  store,
  dispatch,
  /** 是否优先尝试返回历史记录（如果有的话） */
  backHistory,
  backRoute,
  backTitle,
  onBack,
  title,
  children,
  titleRight,
  subTitle,
  contentFooter,
  contentBodyCard = true,
  full = false,
  showBackButton = true
}: DuckCmpProps<Duck> & Props) {
  // 如果历史记录大于2（chrome打开时，新标签页也是1次，当前是第2次）
  if (!onBack && backHistory && history.length > 2) {
    backRoute = ''
    onBack = historyBack
  }

  if (!onBack && backRoute) {
    onBack = () => {
      seajs.require('router').navigate(backRoute)
    }
  }

  return (
    <Layout>
      <Body>
        <Content>
          <Content.Header
            title={title}
            subtitle={
              subTitle ? (
                typeof subTitle === 'string' ? (
                  <Text theme="weak">（{subTitle}）</Text>
                ) : (
                  subTitle
                )
              ) : null
            }
            showBackButton={showBackButton}
            onBackButtonClick={onBack}
            operation={titleRight}
          ></Content.Header>
          <Content.Body full={full}>
            {contentBodyCard ? (
              <Card>
                <Card.Body>{children}</Card.Body>
              </Card>
            ) : (
              children
            )}
          </Content.Body>
        </Content>
        {contentFooter}
      </Body>
    </Layout>
  )
})
