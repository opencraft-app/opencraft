import * as React from 'react'
import { Table, StatusTip, TableProps, SearchBoxProps, SearchBox } from '@tencent/tea-component'
import { DuckCmpProps } from 'saga-duck'
import Duck from 'ducks/SearchableSelect'
import { getStatusTipProps } from 'duckComponents/SearchableSelect'
import { RadioableOptions, ScrollableAddonOptions } from '@tencent/tea-component/es/table/addons'
import { t } from '@tencent/tea-app/lib/i18n'

interface MyDuck<TItem> extends Duck {
  ID: string
  Item: TItem
}
export interface SearchableSelectProps<TItem> extends DuckCmpProps<MyDuck<TItem>> {
  /** searchbox 自定义props */
  searchbox?: Omit<SearchBoxProps, 'value' | 'onChange' | 'onSearch'>
  /** table 自定义props */
  table?: Omit<TableProps, 'records' | 'recordKey' | 'topTip' | 'bottomTip'>
  /** table 的scrollable插件自定义参数，注意它的 maxHeight/minHeight基本是必填的，否则无法生成滚动条 */
  scrollable: Omit<ScrollableAddonOptions, 'onScrollBottom'>
  /** table 的radioable插件自定义参数 */
  radioable?: Omit<RadioableOptions, 'value' | 'onChange'>
}

/**
 * 用于与 ducks/SearchableSelect 配合的表格单选组件
 * 
 * 使用示例：
 * ```jsx
const createMySelector = createSearchableSelector(
  {
    async getData(filter: Param & SearchParam) {
      return {
        list: [],
        totalCount: 0,
      }
    },
    getId(o: Item) {
      return o.AccessKeyId
    },
  },
  selector => selector,
)

function MyForm(props) {
  const selector = createMySelector(props.param)
  const { selected, jsx } = useSearchableTableSelect({
    ...selector,
    table: {
      columns: [
        {
          header: '密钥名',
          key: 'SecretName',
        },
        {
          header: 'SecretId',
          key: 'AccessKeyId',
        },
      ],
    },
    scrollable: {
      minHeight: 400,
      maxHeight: 400,
    },
  })

  return (
     <Form>
      <Form.Item label="密钥" showStatusIcon={false}>{jsx}</Form.Item>
    </Form>
  )
}
 * ```
 */
export function useSearchableTableSelect<TItem>(props: SearchableSelectProps<TItem>) {
  const {
    duck,
    store,
    dispatch,
    searchbox = {},
    table: { addons = [], ...rest },
    scrollable,
    radioable = {},
  } = props
  const { selector, selectors, creators } = duck
  const {
    id,
    pendingKeyword,
    list,
    loadingMore,
    nomore,
    keyword,
    totalCount,
    fetcher: { loading, error },
  } = selector(store)

  let uiList = list

  const handlers = React.useMemo(
    () => ({
      select: (id: string) => dispatch(creators.select(id)),
      inputKeyword: (keyword: string) => dispatch(creators.inputKeyword(keyword)),
      clearKeyword: () => dispatch(creators.search('')),
      search: keyword => dispatch(creators.search(keyword)),
      more: () => dispatch(creators.more()),
      reload: () => dispatch(creators.reload()),
    }),
    [duck, dispatch],
  )

  // 如果是加载更多的模式，loading应该展示在列表下方
  const isLoadMoreMode = loadingMore
  const statusTipProps = getStatusTipProps({
    list: uiList,
    totalCount,
    hideCount: typeof totalCount !== 'number',
    keyword,
    loading,
    error,
    onClear: handlers.clearKeyword,
    onRetry: handlers.reload,
  })

  const searchboxProps: SearchBoxProps = {
    placeholder: t('输入关键字搜索'),
    ...searchbox,
    value: pendingKeyword,
    onChange: handlers.inputKeyword,
    onSearch: handlers.search,
  }
  const tableProps: TableProps = {
    addons: [
      Table.addons.radioable({
        rowSelect: true,
        ...radioable,
        value: id,
        onChange: handlers.select,
      }),
      Table.addons.scrollable({
        ...scrollable,
        onScrollBottom: nomore ? undefined : handlers.more,
      }),
      ...addons,
    ],
    records: uiList || [],
    recordKey: duck.getId,
    topTip: !isLoadMoreMode && statusTipProps ? <StatusTip {...statusTipProps}></StatusTip> : undefined,
    bottomTip: isLoadMoreMode && statusTipProps ? <StatusTip {...statusTipProps}></StatusTip> : undefined,
    ...rest,
  }

  return {
    id,
    selected: selectors.selected(store),
    searchbox: searchboxProps,
    table: tableProps,
    jsx: <TableSelectWrap searchbox={searchboxProps} table={tableProps} />,
  }
}

const borderedStyle: React.CSSProperties = {
  border: '1px solid #cfd5de',
  borderTopWidth: 0,
}
interface TableSelectWrapProps {
  searchbox: SearchBoxProps
  table: TableProps
}
function TableSelectWrap(props: TableSelectWrapProps) {
  return (
    <>
      <SearchBox {...props.searchbox} />
      <div style={borderedStyle}>
        <Table {...props.table} />
      </div>
    </>
  )
}
TableSelectWrap.defaultLabelAlign = 'middle'

export default function SearchableTableSelect<TItem>(props: SearchableSelectProps<TItem>) {
  const { jsx } = useSearchableTableSelect(props)
  return jsx
}
SearchableTableSelect.defaultLabelAlign = 'middle'
