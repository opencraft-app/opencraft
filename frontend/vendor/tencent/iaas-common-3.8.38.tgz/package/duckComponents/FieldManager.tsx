import * as React from 'react'
import { Component } from 'react'
import { Modal, ModalProps, Button, Alert, Checkbox, Text, Row, Col, List } from '@tencent/tea-component'
import { t } from '@tencent/tea-app/lib/i18n'
import { DuckCmpProps } from 'saga-duck'
import DialogDuck from '../ducks/DialogPure'
import * as classnames from 'classnames'
import { showDialog } from '../helpers/showDialog'
import tips from '@tencent/iaas-common/inject/tips'
import { safeSetLocalStorageItem } from '../util/localStorageUtil'

export interface ColumnField extends Identifiable {
  [propName: string]: any
  headTitle: React.ReactChild
  /** 表示必选，不能取消 */
  required?: boolean
  /** 表示默认选中 */
  defaults?: boolean
  hide?: boolean
}
interface Props extends ModalProps {
  title?: string
  fields: ColumnField[]
  tipText?: string
  cacheKey: string
  /** 最多选多少个字段 */
  maxLimit?: number
  /** 超出最大限制强制不可选 */
  mandatoryMaxLimit?: boolean
  /** 默认选了多少个 */
  defaultsNum?: number
  /** 弹出窗内，每列展示多少个选项 */
  eachColNum?: number
  listClassName?: string
  onChange: any
}

interface State {
  selection: string[]
  [propName: string]: any
}

const defaultValue = {
  fields: [],
  tipText: '',
  eachColNum: 6,
  cacheKey: '',
  maxLimit: 0,
  defaultsNum: 0
}

/**
 * 保证 selection 保持与 records 有相同的偏序关系，查找插入位置
 */
function findInsertPosition<T extends Identifiable>(
  records: T[],
  selection: string[],
  item: T
): number {
  let ri: number = 0
  let si: number = 0
  while (records[ri] && selection[si]) {
    if (records[ri].id == item.id) break
    if (records[ri].id === selection[si]) {
      si++
    }
    ri++
  }
  return si
}

/**
 * 插入到选区中，保持与 records 相同的偏序顺序
 */
function selectionInsert(
  records: Identifiable[],
  selection: string[],
  item: Identifiable
): string[] {
  selection = selection ? selection.slice() : []

  let index = -1
  for (let i = 0; i < selection.length; i++) {
    if (selection[i] === item.id) {
      index = i
      break
    }
  }

  if (index === -1) {
    const insertIndex = findInsertPosition(records, selection, item)
    selection.splice(insertIndex, 0, item.id + '')
  }

  return selection
}

function selectionRemove<T extends Identifiable>(
  records: T[],
  selection: string[],
  item: T
): string[] {
  selection = selection.slice()
  const index = selection.indexOf(item.id + '')

  if (index > -1) {
    selection.splice(index, 1)
  }

  return (selection || []).filter(x => x !== item.id)
}
interface ButtonProps extends Props {}

/**
 * 自定义Grid列配置
 *
 * 代码参考模板： http://code.qcm.oa.com/?tpl=gridpage&addons=field-manager&patchOnly=1
 */
export default class FieldManagerButton extends React.Component<
  ButtonProps,
  any
> {
  protected model: CustomFields
  constructor(props) {
    super(props)
    this.model = new CustomFields(this.props.fields, this.props.cacheKey)
  }
  componentWillMount() {
    // 初始触发一次
    this.props.onChange(this.model.getDisplayFields())
  }

  componentWillReceiveProps(nexProps) {
    if (
      this.props.cacheKey !== nexProps.cacheKey ||
      this.props.fields !== nexProps.fields
    ) {
      this.model = new CustomFields(nexProps.fields, nexProps.cacheKey)
    }
    const lastFieldsKey = this.props.fields.map(item=>item.id)
    const newFieldsKey = nexProps.fields.map(item=>item.id)
    if(lastFieldsKey.length !== newFieldsKey.length){
      this.props.onChange(this.model.getDisplayFields())
    }else{
      let res =newFieldsKey.every(item=>{
        return lastFieldsKey.includes(item)
      })
      if(!res){
        this.props.onChange(this.model.getDisplayFields())
      }
    }
    // 如果cacheKey变化，通常是不同的列表了，这里相当于初始化触发一次
    if (this.props.cacheKey !== nexProps.cacheKey) {
      this.props.onChange(this.model.getDisplayFields())
    }
  }

  render() {
    const { model } = this
    const { style, fields, cacheKey, ...rest } = this.props
    return (
      <React.Fragment>
        <Button
          style={style}
          icon="setting"
          onClick={() => {
            showDialog(
              function(props: MyDialogProps) {
                return <FieldManager {...{ model, ...rest, ...props }} />
              },
              Duck,
              function*(duck: Duck) {
                yield* duck.show(null, () => {})
              }
            )
          }}
        />
      </React.Fragment>
    )
  }
}

class Duck extends DialogDuck {
  Data: any
}

/**
 * 自定义列逻辑对象
 */
class CustomFields {
  public selection: string[]
  constructor(public fields: ColumnField[], public cacheKey: string) {
    this.init()
  }
  init() {
    this.selection = this.getInitSelection()
  }
  setSelection(selection: string[] = []) {
    this.selection = selection
    let { cacheKey = '' } = this
    cacheKey && safeSetLocalStorageItem(cacheKey, selection.join(','))
  }
  private getInitSelection() {
    let { fields = [], cacheKey = '' } = this
    let selection = localStorage[cacheKey] && localStorage[cacheKey].split(',')

    if (selection) {
      let fieldsMap = {}
      fields.forEach(field => {
        // hide属性为true的则不再默认勾选
        if(!field.hide){
          fieldsMap[field.id] = true
        }
      })
      selection = selection.filter(key => !!fieldsMap[key])
      selection = fields.reduce((selection, field) => {
        return field.required
          ? selectionInsert(fields, selection, field)
          : selection
      }, selection)
    }

    if (!selection) {
      selection = fields.reduce((selection, field) => {
        if(field.required || !field.hide && field.defaults){
            selection.push(field.id)
        }
        return selection
      }, [])
    }
    return selection
  }
  getDisplayFields(selection = this.selection): ColumnField[] {
    let { fields = defaultValue.fields } = this
    return fields.reduce((columns, field) => {
      if (selection.indexOf(field.id) != -1) {
        columns.push(field)
      }
      return columns
    }, [])
  }
}

/**
 * 自定义列弹框
 */
interface MyDialogProps
  extends Omit<Props, 'fields' | 'cacheKey'>,
    DuckCmpProps<DialogDuck> {
  model: CustomFields
}
class FieldManager extends Component<MyDialogProps, State> {
  state: State = {
    selection: this.props.model.selection
  }
  private _countFields() {
    const { fields = [] } = this.props.model
    const { selection } = this.state
    const selected = new Set(selection)
    let count = 0
    let requiredCount = 0
    let defaultsCount = 0
    let selectedCount = 0
    fields.forEach(field => {
      count++
      if (field.required) {
        requiredCount++
      }
      if (field.defaults) {
        defaultsCount++
      }
      if (selected.has(String(field.id))) {
        selectedCount++
      }
    })
    return {
      count: count,
      requiredCount,
      defaultsCount,
      selectedCount
    }
  }
  private _updateSelection(selection) {
    this.setState({
      selection
    })
  }
  getSelection() {
    let { selection = [] } = this.state || {}
    return selection
  }
  setSelection(selection: string[] = []) {
    this.props.model.setSelection(selection)
    tips && tips.success(t('设置成功'))
  }
  renderCol() {
    const count = this._countFields()
    const { maxLimit = count.count, mandatoryMaxLimit, listClassName='list-mod'  } = this.props
    let { eachColNum = defaultValue.eachColNum } = this.props
    const { fields = defaultValue.fields as ColumnField[]} = this.props.model
    let { selection = [] } = this.state || {}
    let uls = []
    fields.forEach((field, index) => {
      let required = !!field.required
      let defaultShow = !field.hide
      let indexUl = Math.floor(index / eachColNum)
      if (!uls[indexUl]) {
        uls[indexUl] = []
      }
      const isChecked =
        required || selection.indexOf(field && String(field.id)) > -1
      uls[indexUl].push(
        <List.Item key={field.id}>
          <Checkbox
            id={`customize_field_${field.id}`}
            disabled={
              required ||
              (!isChecked &&
                mandatoryMaxLimit &&
                count.selectedCount >= maxLimit)
            }
            value={isChecked}
            onChange={checked => {
              let action = checked ? selectionInsert : selectionRemove
              this._updateSelection(action(fields, selection, field))
            }}
          >
            {field.headTitle}
          </Checkbox>
          </List.Item>
      )
    })
    return <Row>
      {
      uls.map((ul, index) => {
      return (
        <Col span={12} key={index}>
          <List>{ul}</List>
        </Col>
      )
      
    })}
    </Row>
  }
  renderContent() {
    const count = this._countFields()
    const {
      tipText = t('请选择您想显示的列表详细信息。'),
      maxLimit = count.count,
      defaultsNum = count.defaultsCount
    } = this.props
    return (
      <>
        <Alert type='info'>
          {tipText}
          {maxLimit > 0 && (
            <Text id="limitTip">
              {t(
                '根据您的分辨率，最多可勾选{{ maxLimit }}个字段，已勾选{{ count }}个。',
                {
                  maxLimit,
                  count: count.selectedCount
                }
              )}
            </Text>
          )}
        </Alert>
        {this.renderCol()}
      </>
    )
  }
  render() {
    let _this = this
    const {
      duck: { creators, selectors },
      dispatch,
      store,
      size = 540,
      title = t('自定义列表字段'),
      onChange = fields => {},
      model,
      ...rest
    } = this.props
    if (!selectors.visible(store)) {
      return <noscript />
    }
    return (
      <Modal
        caption={title}
        size={size}
        visible={true}
        disableEscape
        onClose={() => {
          dispatch(creators.hide())
        }}
      >
        <Modal.Body>{this.renderContent()}</Modal.Body>
        <Modal.Footer>
          <Button
            type='primary'
            onClick={() => {
              let selection = _this.getSelection()
              let fields = model.getDisplayFields(selection)
              model.setSelection(selection)
              dispatch(creators.hide())
              onChange(fields)
            }}
          >
            {t('确定')}
          </Button>
        </Modal.Footer>
      </Modal>
    )
  }
}
