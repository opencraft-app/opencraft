import * as React from 'react'
import * as classnames from 'classnames'
import Duck from '../ducks/AsyncSelect'
import Select, { Props as BaseProps, DropdownListItem } from './SelectDropdown'
import { DuckCmpProps, purify, memorize } from 'saga-duck'
import { t } from '@tencent/tea-app/lib/i18n'
export interface Props<T> extends BaseProps<T> {}
export { DropdownListItem }
interface MyDuck<TItem, TId> extends Duck {
  ID: TId
  Item: TItem
}
export default function<TItem, TId>(
  props: DuckCmpProps<MyDuck<TItem, TId>> & Props<TItem>
) {
  const { duck, store, dispatch, disabled, placeholder, ...rest } = props
  const {
    list,
    id,
    fetcher: { loading, error }
  } = duck.selector(store)
  return (
    <Select
      duck={duck}
      store={store}
      dispatch={dispatch}
      disabled={loading || disabled}
      placeholder={loading ? t('加载中...') : placeholder}
      {...rest}
    />
  )
}
