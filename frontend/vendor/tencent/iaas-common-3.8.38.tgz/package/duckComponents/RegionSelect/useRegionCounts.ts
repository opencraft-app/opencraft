/**
 * hook版的地域资源加载器
 */
import * as React from 'react'
import { noRejected, once, ttl } from '../../helpers/cacheable'
import Semaphore from 'semaphore-async-await'
import { RegionSetting } from '../RegionSelect'
import { Duck, reduceFromPayload, useDuck } from 'saga-duck'
import { runAndWatchLatest } from '../../helpers/saga'
import { takeLatest, runAndTakeLatest, delay } from 'redux-saga-catch'
import { call, race, take, fork, put } from 'redux-saga/effects'
import { createToPayload, resolvePromise } from 'saga-duck/build/helper'


interface BaseOptions {
  /** 获取指定地域的资源数量，注意设置为 tipErr: false */
  getCount(regionId: number): Promise<number>
  /** 延迟多久后开始加载当前地域资源数量，单位毫秒，默认为 1000  */
  currentRegionDelay?: number
  /** 延迟多久后开始加载其它地域资源数量，单位毫秒，默认为 10000 */
  othersRegionDelay?: number
  /** 请求并发限制，默认为20 */
  concurrency?: number
}
interface Options extends BaseOptions {
  /** 地域列表 */
  regionIds: number[]
  /** 当前地域id，可选 当前地域优先加载，以及token变化时重新请求当前地域数量 */
  regionId?: number
}

export default function useRegionCounts(opts: Options) {
  const { regionIds = [],
    getCount,
    regionId: currentRegionId,
    currentRegionDelay = 1000,
    othersRegionDelay = 10000,
    concurrency = 20 } = opts
  const { duck, store, dispatch } = useDuck(MyDuck)
  const { selector, types, creators } = duck
  const { counts } = selector(store)

  // 基本参数设置
  React.useEffect(() => {
    dispatch(creators.load({
      getCount,
      currentRegionDelay,
      othersRegionDelay,
      concurrency
    }))
  }, [])

  // 地域列表同步
  React.useEffect(() => {
    dispatch(creators.setRegionIds(regionIds))
  }, [regionIds.join()])

  // 当前地域同步
  React.useEffect(() => {
    dispatch(creators.setRegionId(currentRegionId))
  }, [currentRegionId])

  return {
    /** 各地域资源数量 */
    counts,
    /** 用于手工触发指定地域的重新加载，不传则为当前地域 */
    refresh: (regionId = currentRegionId) => {
      dispatch(creators.refresh(regionId))
    },
    injectProps: {
      /** 用于 ducksComponent/RegionSelect onOpen回调，立即触发所有地域数量加载（不再等待延时） */
      onOpen: () => {
        dispatch(creators.open())
      },
      /** 用于 ducksComponent/RegionSelect 的地域资源数量注入 */
      injectRegionSetting: (o: RegionSetting) => {
        const count = counts[+o.value]
        // 已经加载出数量了
        if (typeof count === 'number') {
          return {
            ...o,
            num: count,
          }
        }
        return o
      }
    }
  }
}

interface Counts {
  [key: number]: number | undefined
}

class MyDuck extends Duck {
  declare Options: BaseOptions
  get quickTypes() {
    enum Types {
      LOAD,
      SET_REGION_ID,
      SET_REGION_IDS,
      SET_COUNT,
      // OPEN，立即开始加载所有地域
      OPEN,
      // 刷新指定地域
      REFRESH
    }
    return {
      ...super.quickTypes,
      ...Types
    }
  }
  get reducers() {
    const { types } = this
    return {
      ...super.reducers,
      options: reduceFromPayload<this['Options']>(types.LOAD, null),
      regionId: reduceFromPayload<number>(types.SET_REGION_ID, null),
      regionIds: reduceFromPayload<number[]>(types.SET_REGION_IDS, []),
      counts: (state: Counts = {}, action): Counts => {
        switch (action.type) {
          case types.SET_COUNT:
            return {
              ...state,
              [action.regionId]: action.payload
            }
          default:
            return state
        }
      }
    }
  }
  get creators() {
    const { types } = this
    return {
      ...super.creators,
      load: createToPayload<this['Options']>(types.LOAD),
      setRegionIds: createToPayload<number[]>(types.SET_REGION_IDS),
      setRegionId: createToPayload<number>(types.SET_REGION_ID),
      setCount(regionId: number, count: number) {
        return {
          type: types.SET_COUNT,
          regionId,
          payload: count
        }
      },
      open() {
        return { type: types.OPEN }
      },
      refresh: createToPayload<number>(types.REFRESH),
    }
  }
  *saga() {
    yield* super.saga()

    yield runAndWatchLatest(this.types.LOAD, g => this.selector(g).options, v => this.load(v))
  }
  *load(opts: this['Options']) {
    yield runAndWatchLatest(this.types.SET_REGION_IDS, g => this.selector(g).regionIds, v => this.loadRegions(v, opts))
  }
  /** 加载各地域数量 */
  *loadRegions(regionIds: number[], opts: this['Options']) {
    if (!regionIds?.length) {
      return
    }

    const { types, selector, creators } = this

    // 缓存、并发限制
    const semaphore = new Semaphore(opts.concurrency)
    const getCount = once(async (regionId: number) => {
      await semaphore.acquire()
      try {
        return await opts.getCount(regionId)
      } finally {
        semaphore.release()
      }
    }, noRejected(ttl(5000)))

    // 各地域的加载逻辑
    const triggered = new Set<number>()
    const loadRegion = function* (regionId: number) {
      // 加载过的不重复加载
      if (triggered.has(regionId)) {
        return
      }
      triggered.add(regionId)
      const count = yield* resolvePromise(getCount(regionId))
      yield put(creators.setCount(regionId, count))
    }

    // ----当前地域提前加载-----
    yield runAndWatchLatest(types.SET_REGION_ID, g => selector(g).regionId, function* (regionId) {
      // 延时或展开
      yield delay(opts.currentRegionDelay)
      yield* loadRegion(regionId)
    })

    // ---- 指定地域刷新
    yield takeLatest(types.REFRESH, function* (action) {
      const regionId: number = action.payload
      if (action) {
        triggered.delete(regionId)
      }
      yield* loadRegion(regionId)
    })

    // ----其它地域加载--------
    // 延时或展开
    yield race({
      delay: delay(opts.othersRegionDelay),
      open: take(types.OPEN)
    })

    // 加载所有地域
    for (const regionId of regionIds) {
      yield fork(loadRegion, regionId)
    }
  }

}