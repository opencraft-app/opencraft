# @tencent/iaas-common 公共组件/工具目录

> 本文档为 `@tencent/iaas-common` 项目的完整公共组件和工具目录索引。

---

## 目录结构概览

| 目录 | 说明 | 文件数量 |
|------|------|----------|
| `components/` | 基础前台通用业务组件 | 44+ |
| `duckComponents/` | 与 duck 关联的组件 | 53+ |
| `ducks/` | 状态管理相关的 Duck 类 | 58+ |
| `helpers/` | 辅助工具函数 | 28 |
| `hooks/` | React Hooks | 8 |
| `models/` | 数据模型/API接口定义 | 9 |
| `util/` | 通用工具函数 | 5 |
| `inject/` | 依赖注入相关 | 6 |
| `model.ts` | 常用接口定义 | 1 |

---

# 一、Components - 基础业务组件

## 1.1 表单组件

| 组件 | 路径 | 用途 |
|------|------|------|
| `CIDRInput` | `components/CIDRInput.tsx` | CIDR网段输入组件，支持IP和掩码的受控输入 |
| `PureAutocomplete` | `components/PureAutocomplete.tsx` | 纯自动补全选择器，支持键盘选择和输入过滤 |
| `Select` | `components/Select.tsx` | 简化的Select组件，封装Tea的Select |
| `SearchableDropdown` | `components/SearchableDropdown.tsx` | 可搜索的下拉列表组件，支持多种主题风格 |
| `DateTimePicker` | `components/DateTimePicker.tsx` | 日期时间选择器，结合Segment快捷选项和RangePicker |
| `KVTagSearchBox` | `components/KVTagSearchBox.tsx` | 键值对标签搜索框，简化value与attributes的使用 |
| `TagAddList` | `components/TagAddList.tsx` | 标签添加列表组件，用于创建资源时添加标签 |

### form 子目录

| 组件 | 路径 | 用途 |
|------|------|------|
| `FormField` | `components/form/formField.tsx` | 表单字段上下文组件 |
| `FormInput` | `components/form/formInput.tsx` | 表单输入容器组件 |
| `AutoCompleteSelector` | `components/form/formInputs/autoCompleteSelector.tsx` | 表单自动补全选择器 |
| `SelectInput` | `components/form/formInputs/select.tsx` | 表单Select组件 |
| `TextInput` | `components/form/formInputs/text.tsx` | 表单文本输入组件 |
| `InputNum` | `components/form/formInputs/inputNum.tsx` | 表单数字输入组件 |

---

## 1.2 数据展示组件

| 组件 | 路径 | 用途 |
|------|------|------|
| `Operations` | `components/Operations.tsx` | 列表操作列组件，自动将超出的操作放到"更多"菜单中 |
| `SortGrid` | `components/SortGrid.tsx` | 支持拖拽排序的Table组件 |
| `SmartTip` | `components/SmartTip.tsx` | 智能提示组件，根据Fetcher状态自动展示提示 |
| `TextHighlighter` | `components/TextHighlighter.tsx` | 文本高亮组件，支持关键词高亮显示 |
| `TransferFieldManager` | `components/TransferFieldManager.tsx` | 穿梭框自定义字段选择器 |

---

## 1.3 导出组件

| 组件 | 路径 | 用途 |
|------|------|------|
| `ExportTable` | `components/ExportTable.tsx` | 表格数据导出组件，支持单个和批量导出为CSV |
| `ExportTableWithDataFetcher` | `components/ExportTableWithDataFetcher.tsx` | 带数据分页获取功能的表格导出组件 |

---

## 1.4 监控组件

| 组件 | 路径 | 用途 |
|------|------|------|
| `Monitor` | `components/Monitor.tsx` | 监控SDK React组件包装（旧版本） |
| `MonitorV2` | `components/MonitorV2.tsx` | 监控SDK 2.0 React组件包装（**推荐使用**） |

---

## 1.5 反馈/权限组件

| 组件 | 路径 | 用途 |
|------|------|------|
| `CAMBreak` | `components/Cam.tsx` | 主要权限中断展示组件 |
| `CamTips` | `components/Cam.tsx` | 权限提示信息组件（已废弃） |
| `CamHelpTips` | `components/Cam.tsx` | 权限帮助提示组件 |

---

## 1.6 工具组件

| 组件 | 路径 | 用途 |
|------|------|------|
| `ClipboardButton` | `components/ClipboardButton.tsx` | 复制到剪贴板按钮组件 |
| `BackHref` | `components/BackHref.tsx` | 返回链接组件 |
| `ActionPanel` | `components/ActionPanel.tsx` | Table操作面板组件 |
| `AreaDropdownMenu` | `components/AreaDropdownMenu.tsx` | 分类下拉选择器 |

---

## 1.7 业务组件

| 组件 | 路径 | 用途 |
|------|------|------|
| `RegionSelectorTea2` | `components/region/RegionSelectorTea2.tsx` | 地域选择器组件（Tea2版本） |

---

# 二、DuckComponents - Duck关联组件

> 这些组件需要配合 `duck`、`store`、`dispatch` 参数使用

## 2.1 通用组件

| 组件 | 路径 | Duck关联 | 用途 |
|------|------|----------|------|
| `Dialog` | `duckComponents/Dialog.tsx` | `DialogPure` | 通用弹框组件 |
| `Confirm` | `duckComponents/Confirm.tsx` | `Confirm` | 确认框组件 |
| `FormDialog` | `duckComponents/FormDialog.tsx` | `DialogPure` | 表单弹框组件 |

---

## 2.2 页面组件

| 组件 | 路径 | Duck关联 | 用途 |
|------|------|----------|------|
| `CreatePage` | `duckComponents/CreatePage.tsx` | `Page` | 创建页面布局组件 |
| `DetailPage` | `duckComponents/DetailPage.tsx` | `DetailPage` | 详情页面布局组件 |
| `makePageInterceptor` | `duckComponents/makePageInterceptor.tsx` | `Page` | 页面拦截器HOC |

---

## 2.3 表格组件

| 组件 | 路径 | Duck关联 | 用途 |
|------|------|----------|------|
| `Grid` | `duckComponents/Grid.tsx` | `Grid` | 表格组件，支持多选/单选 |
| `GridPageGrid` | `duckComponents/GridPageGrid.tsx` | `GridPage` | 分页列表页表格 |
| `GridPagePagination` | `duckComponents/GridPagePagination.tsx` | `GridPage` | 分页组件 |

---

## 2.4 选择器组件

| 组件 | 路径 | Duck关联 | 用途 |
|------|------|----------|------|
| `AsyncSelect` | `duckComponents/AsyncSelect.tsx` | `Fetcher` | 异步加载下拉选择框 |
| `AsyncSelectDropdown` | `duckComponents/AsyncSelectDropdown.tsx` | `AsyncSelect` | 异步下拉菜单组件 |
| `SearchableSelect` | `duckComponents/SearchableSelect.tsx` | `SearchableSelect` | 可搜索下拉选择 |
| `SearchableTableSelect` | `duckComponents/SearchableTableSelect.tsx` | `SearchableSelect` | 可搜索表格单选 |
| `SearchableTeaSelect` | `duckComponents/SearchableTeaSelect.tsx` | `SearchableSelect` | Tea风格可搜索选择 |
| `SearchableTransfer` | `duckComponents/SearchableTransfer.tsx` | `SearchableMultiSelect` | 穿梭框资源选择器 |
| `SelectDropdown` | `duckComponents/SelectDropdown.tsx` | `Select` | 下拉菜单选择组件 |

---

## 2.5 业务组件

| 组件 | 路径 | Duck关联 | 用途 |
|------|------|----------|------|
| `Region` | `duckComponents/Region.tsx` | `Region` | 地域选择器（Segment样式） |
| `RegionSelect` | `duckComponents/RegionSelect.tsx` | `Region` | 地域选择器（Tea2新样式） |
| `Project` | `duckComponents/Project.tsx` | `Project` | 项目选择器 |
| `FieldManager` | `duckComponents/FieldManager.tsx` | `DialogPure` | 自定义表格列配置管理 |

---

## 2.6 表单组件 (form/)

| 组件 | 路径 | 用途 |
|------|------|------|
| `Field` | `duckComponents/form/Field.tsx` | 基础表单字段包装组件 |
| `Input` | `duckComponents/form/Input.tsx` | 文本输入框组件 |
| `Number` | `duckComponents/form/Number.tsx` | 数字输入框组件 |
| `Select` | `duckComponents/form/Select.tsx` | 下拉选择框组件 |
| `Checkbox` | `duckComponents/form/Checkbox.tsx` | 复选框组件 |
| `Radio` | `duckComponents/form/Radio.tsx` | 单选按钮组件 |
| `TextArea` | `duckComponents/form/TextArea.tsx` | 多行文本输入框 |
| `File` | `duckComponents/form/File.tsx` | 文件上传组件 |

---

## 2.7 Tea风格表单组件 (teaform/)

| 组件 | 路径 | 用途 |
|------|------|------|
| `Field` | `duckComponents/teaform/Field.tsx` | Tea Form.Item封装 |
| `Control` | `duckComponents/teaform/Control.tsx` | Tea Form.Control封装 |
| `Input` | `duckComponents/teaform/Input.tsx` | Tea Input封装 |
| `InputNumber` | `duckComponents/teaform/InputNumber.tsx` | Tea InputNumber封装 |
| `Select` | `duckComponents/teaform/Select.tsx` | Tea Select封装 |
| `TextArea` | `duckComponents/teaform/TextArea.tsx` | Tea TextArea封装 |
| `Checkbox` | `duckComponents/teaform/Checkbox.tsx` | Tea Checkbox封装 |
| `RadioGroup` | `duckComponents/teaform/RadioGroup.tsx` | Tea RadioGroup封装 |
| `Switch` | `duckComponents/teaform/Switch.tsx` | Tea Switch封装 |

---

# 三、Ducks - 状态管理类

## 3.1 核心基础Duck

| Duck | 路径 | 用途 |
|------|------|------|
| `Fetcher` | `ducks/Fetcher.ts` | 单项数据加载，处理loading/success/error状态 |
| `Select` | `ducks/Select.ts` | 通用单选逻辑 |
| `MultiSelect` | `ducks/MultiSelect.ts` | 多选逻辑 |
| `AsyncSelect` | `ducks/AsyncSelect.ts` | 动态单选，关联Fetcher异步加载 |

---

## 3.2 可搜索列表类

| Duck | 路径 | 用途 |
|------|------|------|
| `AbstractSearchableList` | `ducks/AbstractSearchableList.ts` | 可搜索列表抽象基类 |
| `SearchableList` | `ducks/SearchableList.ts` | 简化的可搜索列表 |
| `SearchableMultiSelect` | `ducks/SearchableMultiSelect.ts` | 可搜索多选 |

---

## 3.3 页面级Duck

| Duck | 路径 | 用途 |
|------|------|------|
| `Page` | `ducks/Page.ts` | 页面公共逻辑抽象，处理URL路由同步 |
| `GridPage` | `ducks/GridPage.ts` | 列表页通用逻辑 |
| `DetailPage` | `ducks/DetailPage.ts` | 详情页公共逻辑 |
| `Grid` | `ducks/Grid.ts` | Grid表格数据管理 |

---

## 3.4 对话框/表单Duck

| Duck | 路径 | 用途 |
|------|------|------|
| `DialogPure` | `ducks/DialogPure.ts` | 纯对话框逻辑 |
| `Dialog` | `ducks/Dialog.ts` | 带保存逻辑的对话框（已废弃） |
| `Confirm` | `ducks/Confirm.tsx` | 确认框Duck |
| `Form` | `ducks/Form.ts` | 通用表单实现 |
| `FormDialog` | `ducks/FormDialog.ts` | 组合Form和DialogPure的表单弹窗 |
| `FormPage` | `ducks/FormPage.ts` | 页面级表单 |

---

## 3.5 特殊业务Duck

| Duck | 路径 | 用途 |
|------|------|------|
| `DynamicDuck` | `ducks/DynamicDuck.ts` | 动态创建和管理多个子Duck实例 |
| `Tree` | `ducks/Tree.ts` | 树形数据管理 |
| `TagSearch` | `ducks/TagSearch.ts` | 标签搜索框逻辑 |
| `Tags` | `ducks/Tags.ts` | 标签数据加载，支持缓存 |

---

## 3.6 白名单相关

| Duck | 路径 | 用途 |
|------|------|------|
| `WhiteList` | `ducks/WhiteList.ts` | 简单白名单查询 |
| `AdvanceWhiteList` | `ducks/AdvanceWhiteList.ts` | 高级白名单，支持地域灰度 |
| `WhiteListEx` | `ducks/WhiteListEx.ts` | 白名单查询扩展 |

---

## 3.7 网络相关Duck

| Duck | 路径 | 用途 |
|------|------|------|
| `NetworkSelector` | `ducks/NetworkSelector.ts` | VPC和子网选择器（旧版） |
| `VpcAndSubnetSelector` | `ducks/VpcAndSubnetSelector.ts` | VPC和子网选择器（增强版） |
| `ResourceSelector` | `ducks/ResourceSelector.ts` | 通用资源选择器 |
| `Project` | `ducks/Project.ts` | 项目选择器 |

---

## 3.8 子目录模块

| 模块 | 路径 | 用途 |
|------|------|------|
| `Region` | `ducks/Region/` | 地域选择逻辑 |
| `Route` | `ducks/Route/` | URL路由与状态双向同步 |
| `SearchableSelect` | `ducks/SearchableSelect/` | 可搜索单选模块 |
| `network` | `ducks/network/` | 网络选择模块（VPC/Subnet） |
| `completer` | `ducks/utils/completer/` | 数据补全工具 |

---

# 四、Helpers - 辅助工具函数

## 4.1 缓存与限流

| 工具 | 路径 | 用途 |
|------|------|------|
| `RateLimit` | `helpers/RateLimit.ts` | 基于信号量的限流工具 |
| `cacheable` | `helpers/cacheable.ts` | 提供多种缓存策略的装饰器 |

---

## 4.2 数据获取

| 工具 | 路径 | 用途 |
|------|------|------|
| `getAllList` | `helpers/getAllList.ts` | 全量拉取分页列表数据 |
| `pagingFetch` | `helpers/pagingFetch.ts` | 通用分页接口全量拉取 |

---

## 4.3 CAM权限

| 工具 | 路径 | 用途 |
|------|------|------|
| `assureCamRolePolicy` | `helpers/assureCamRolePolicy.ts` | CAM角色和策略的授权管理 |

---

## 4.4 计费SDK

| 工具 | 路径 | 用途 |
|------|------|------|
| `getBillingSdk` | `helpers/getBillingSdk.ts` | 获取计费SDK |
| `getBillingInjectedSdk` | `helpers/getBillingInjectedSdk.ts` | 获取计费SDK（注入版） |

---

## 4.5 链接生成

| 工具 | 路径 | 用途 |
|------|------|------|
| `links` | `helpers/links.ts` | 生成各平台域名链接 |

---

## 4.6 导出工具

| 工具 | 路径 | 用途 |
|------|------|------|
| `xlsx` | `helpers/xlsx.js` | XLSX文件导出工具 |

---

## 4.7 其他工具

| 工具 | 路径 | 用途 |
|------|------|------|
| `showDialog` | `helpers/showDialog.tsx` | 独立运行环境的弹窗展示 |
| `visibility` | `helpers/visibility.ts` | 检测页面标签页可见状态 |
| `wait` | `helpers/wait.ts` | 条件等待工具函数 |
| `insertCSS` | `helpers/insertCSS.ts` | 动态注入CSS样式 |
| `log` | `helpers/log.ts` | 开发模式下打印日志 |
| `networkReporter` | `helpers/networkReporter.ts` | 主动数据上报工具 |
| `reporter` | `helpers/reporter.js` | TCSS统计上报和页面测速 |
| `range` | `helpers/range.js` | 自然数区间计算库 |
| `onOuterClick` | `helpers/onOuterClick.ts` | 组件外部点击触发装饰器 |
| `useFieldManager` | `helpers/useFieldManager.ts` | 表格列字段管理Hook |
| `useRegionMaps` | `helpers/useRegionMaps.ts` | 获取平台地域/可用区映射 |
| `checkGroupConstraint` | `helpers/checkGroupConstraint.ts` | 团体云/定制云地域约束 |
| `saga` | `helpers/saga.ts` | Redux-Saga辅助工具 |

---

# 五、Hooks - React Hooks

| Hook | 路径 | 用途 |
|------|------|------|
| `useStateWithAsyncDependents` | `hooks/index.ts` | 带有异步effect的state |
| `useActions` | `hooks/useActions.ts` | 将包含异步判断的操作列表同步化 |
| `useControlled` | `hooks/useControlled.ts` | 将有内部状态的组件封装为受控组件 |
| `useFetch` | `hooks/useFetch.ts` | 通用数据获取Hook |
| `useForm` | `hooks/useForm.ts` | 表单状态管理Hook |
| `useNetworkSelector` | `hooks/useNetworkSelector.ts` | VPC/子网选择器Hook |
| `useOnValueChange` | `hooks/useOnValueChange.ts` | 监听值变化时触发回调 |
| `useRecord` | `hooks/useRecord.ts` | 保持对象引用不变 |

---

# 六、Models - 数据模型/API接口

| 模型 | 路径 | 用途 |
|------|------|------|
| `apiRequest` | `models/apiRequest.ts` | 统一API请求入口 |
| `cam` | `models/cam.ts` | CAM服务相关接口 |
| `cos` | `models/cos.ts` | COS对象存储相关接口 |
| `location` | `models/location.ts` | TCE地域/可用区信息查询 |
| `regionMap` | `models/regionMap.tsx` | 地域/可用区映射数据获取 |
| `tag` | `models/tag.ts` | 标签服务相关接口 |
| `util` | `models/util.ts` | 数据请求相关工具函数 |
| `vpc` | `models/vpc.ts` | VPC网络相关接口 |

---

# 七、Util - 通用工具函数

| 工具 | 路径 | 用途 |
|------|------|------|
| `format` | `util/format.ts` | 数字格式化（千分位） |
| `getErrorMessage` | `util/getErrorMessage.ts` | 从错误对象中提取错误信息 |
| `ip` | `util/ip.ts` | IP地址处理工具 |
| `localStorageUtil` | `util/localStorageUtil.ts` | 安全的localStorage操作 |

---

# 八、Inject - 依赖注入

> 此目录用于平台能力抽离，支持在不同平台进行替换

| 模块 | 路径 | 用途 |
|------|------|------|
| `apiRequest` | `inject/apiRequest.ts` | 统一API请求 |
| `appUtil` | `inject/appUtil.ts` | 地域ID的获取和设置 |
| `getOwnerUin` | `inject/getOwnerUin.ts` | 获取当前主账号UIN |
| `iaas` | `inject/iaas.ts` | 导出seajs的iaas模块 |
| `tips` | `inject/tips.ts` | 消息提示工具 |

---

# 九、model.ts - 常用接口定义

| 接口 | 用途 |
|------|------|
| `DescribeVpcEx` | 获取VPC列表（**已废弃**，使用 `models/vpc` 的 `DescribeVpcs`） |
| `getWhiteList` | 获取白名单高级接口 |
| `parseGreyInfo` | 解析白名单灰度信息 |
| `cacheGetGreyInfo` | 获取业务及地域白名单，自动合并请求并缓存 |
| `getProjects` | 获取项目列表 |
| `GetTagKeys` | 获取标签Key（**已废弃**，使用 `models/tag` 的 `DescribeTagKeys`） |
| `GetTags` | 根据标签Key获取标签（**已废弃**，使用 `models/tag` 的 `DescribeTags`） |

---

# 十、快速索引

## 按使用场景

| 场景 | 推荐组件/工具 |
|------|--------------|
| 表格行操作 | `Operations` |
| 表格导出 | `ExportTable` / `ExportTableWithDataFetcher` |
| 多条件搜索 | `KVTagSearchBox` |
| 监控图表 | `MonitorV2`（推荐） |
| CIDR输入 | `CIDRInput` |
| 地域选择 | `RegionSelect` / `RegionSelectorTea2` |
| 时间范围选择 | `DateTimePicker` |
| 自定义列 | `TransferFieldManager` / `FieldManager` |
| 拖拽排序表格 | `SortGrid` |
| 文本高亮 | `TextHighlighter` |
| 标签添加 | `TagAddList` |
| 权限提示 | `CAMBreak` |
| 复制按钮 | `ClipboardButton` |
| 列表页 | `GridPage` + `GridPageGrid` + `GridPagePagination` |
| 详情页 | `DetailPage` |
| 创建页 | `CreatePage` + `FormPage` |
| 表单弹窗 | `FormDialog` |
| 确认操作 | `Confirm` |
| 异步选择 | `AsyncSelect` / `AsyncSelectDropdown` |
| 可搜索选择 | `SearchableSelect` / `SearchableTeaSelect` |
| 多选穿梭框 | `SearchableTransfer` |
| VPC/子网选择 | `VpcAndSubnetSelector` / `useNetworkSelector` |
| 数据请求 | `Fetcher` / `useFetch` |
| 白名单查询 | `getWhiteList` / `WhiteList` / `AdvanceWhiteList` |
| API请求限流 | `RateLimit` |
| 数据缓存 | `cacheable` / `once` |
| 全量数据拉取 | `getAllList` / `pagingFetch` |
| CAM授权 | `assureCamRolePolicy` |
| Excel导出 | `xlsx` |

