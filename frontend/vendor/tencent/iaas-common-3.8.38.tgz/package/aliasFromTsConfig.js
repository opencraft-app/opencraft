// @i18n-noscan
/**
 * 此方法将自动从 tsconfig.json 中提取alias信息，用于webpack的 resolve.alias 属性
 * 
```javascript
resolve: {
  alias: {
    // 从 tsconfig 中读取 path-mapping 配置，webpack 通过 alias 支持
    ...aliasFromTsConfig(cwd)
  }
}
```
 */
module.exports = function aliasFromTsConfig(cwd) {
  const { resolve } = require('path')
  let jsConfig
  try {
    jsConfig = require(resolve(cwd, 'tsconfig.json'))
  } catch (err) {
    console.warn('=============', err.message)
    return {}
  }

  // @see https://www.typescriptlang.org/docs/handbook/module-resolution.html
  const { baseUrl = null, paths = null } = jsConfig.compilerOptions || {}
  if (!baseUrl || !paths) {
    return {}
  }

  let alias = {}

  for (let [name, mapping] of Object.entries(paths)) {
    if (!mapping || !Array.isArray(mapping) || mapping.length != 1) {
      console.warn(
        `[Tea] 无法从配置文件解析到路径映射: compilerOptions.path["${name}"]`
      )
      console.warn(
        `      一个合法的路径应映射为包含单个路径的数组, 如: ["../node_modules/@tencent/tea-app"]`
      )
    } else {
      let [aliasPath] = mapping
      // WebPack 不支持通配，但是默认就是通配了，直接把通配符去掉
      name = name.replace(/\/\*$/, '')
      aliasPath = aliasPath.replace(/\/\*$/, '')
      alias[name] = resolve(cwd, baseUrl, aliasPath)
    }
  }

  return alias
}
