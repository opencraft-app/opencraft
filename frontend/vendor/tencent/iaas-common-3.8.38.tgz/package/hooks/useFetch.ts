import { FetcherDuck } from '../ducks';
import { useMemo } from 'react';
import { useDuck } from 'saga-duck';

export interface FetcherOptions {
  /**
   * 请求缓冲，在此缓冲时间内不会调用 getData/getDataAsync 方法，避免重复请求
   */
  buffer?: number;
  /**
   * 是否开启延迟loading展示
   *
   * 当数据加载在deferLoading毫秒内完成时（通常是有缓存），不切换loading态，避免界面跳动
   *
   * 默认为0，即不开启 
   */
  deferLoading?: number;
}

export default function useFetcher<TParam extends Array<any>, TData>(
  fn: (...param: TParam) => Promise<TData>,
  opts?: FetcherOptions
) {
  const TempFetcher = useMemo(
    () =>
      class TempFetcher extends FetcherDuck {
        Param: TParam;
        Data: TData;
        get buffer() {
          return opts?.buffer || super.buffer;
        }
        get deferLoading() {
          return opts?.deferLoading || super.deferLoading;
        }
        protected async getDataAsync(params: TParam) {
          return fn(...params);
        }
      },
    [],
  );

  const { duck, store, dispatch } = useDuck(TempFetcher);
  const methods = useMemo(() => {
    return {
      fetch: (...params: TParam) => {
        dispatch(duck.creators.fetch(params));
      },
      /**
       * 取消fetch请求，并清空数据与重置状态
       */
      cancel: () => {
        dispatch(duck.creators.cancelFetch())
      },
      reload: () => {
        dispatch(duck.creators.reload())
      },
      reset: () => {
        dispatch(duck.creators.reset())
      }
    }
  }, [duck, dispatch])
  return {
    data: duck.selectors.data(store) as TData,
    error: duck.selectors.error(store),
    loading: duck.selectors.loading(store),
    ...methods
  };
}
