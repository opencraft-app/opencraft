/**
 * 网络选择器，管理VPC/子网的选择与联动
 *
 * hook版的，降低耦合，替换ducks/NetworkSelector及ducks/VpcAndSubnetSelector
 */

import { useDuck } from "saga-duck";
import Duck, { NetworkSelectorOptions, SelectorStatus as NetworkSelectorStatus } from "../ducks/network/VpcAndSubnet";
import { useEffect } from "react";
import { SearchableTeaSelectProps } from "../duckComponents/SearchableTeaSelect";
import { Subnet, Vpc } from "../models/vpc";
import { SelectOptionWithGroup } from "@tencent/tea-component";


interface NetworkSelectorResult {
  status: NetworkSelectorStatus
  /** 供自由组装SearchableSelect */
  props: {
    vpc: SearchableTeaSelectProps<Vpc>
    subnet: SearchableTeaSelectProps<Subnet>
  },
}
export default function useNetworkSelector(options: NetworkSelectorOptions): NetworkSelectorResult {
  const { duck, store, dispatch } = useDuck(Duck)
  const { ducks: { vpc, subnet } } = duck
  // 渲染时即启用
  useEffect(() => {
    dispatch(duck.creators.load())
  }, [])
  // 动态更新参数
  useEffect(() => {
    dispatch(duck.creators.setOptions(options))
  }, [JSON.stringify(options)])
  return {
    status: duck.selectors.status(store),
    props: {
      vpc: {
        duck: vpc,
        store,
        dispatch,
        toOption: vpcToOption
      },
      subnet: {
        duck: subnet,
        store,
        dispatch,
        toOption: subnetToOption
      }
    },
  }
}

function vpcToOption(o: Vpc): SelectOptionWithGroup {
  return {
    value: o.VpcId,
    text: `${o.VpcId} | ${o.VpcName} | ${o.CidrBlock}`,
    tooltip: `${o.VpcId} | ${o.VpcName} | ${o.CidrBlock}`,
  }
}

function subnetToOption(o: Subnet): SelectOptionWithGroup {
  return {
    value: o.SubnetId,
    text: `${o.SubnetId} | ${o.SubnetName} | ${o.CidrBlock}`,
    tooltip: `${o.SubnetId} | ${o.SubnetName} | ${o.CidrBlock}`,
  }
}