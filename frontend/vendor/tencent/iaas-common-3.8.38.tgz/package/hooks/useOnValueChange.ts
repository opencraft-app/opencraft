import { useEffect, useRef } from 'react'

/**
 * 工具hook，当监听的值产生变化时触发，注意第一次不会触发
 * @param value
 * @param cb
 */
export default function useOnValueChange<T>(value: T, cb: (v: T, old: T) => any) {
  const lastValue = useRef<T>(value)
  useEffect(() => {
    if (lastValue.current !== value) {
      cb(value, lastValue.current)
    }
    lastValue.current = value
  }, [value])
}
