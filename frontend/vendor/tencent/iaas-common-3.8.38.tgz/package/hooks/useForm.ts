import FormBase from '../ducks/Form';
import { useEffect, useMemo } from 'react';
import { useDuck } from 'saga-duck';
import { createLogger } from 'redux-logger';

type Valid<TValue, TValues, TMeta> = (v: TValue, values: TValues, meta: TMeta) => any // INVALID | VALIDATORS<TValue, TMeta>
type ValidFunction<TValue, TValues, TMeta> = Valid<TValue, TValues, TMeta> | TValue extends Array<infer TItem>
  ? Valid<TValue, TValues, TMeta> | [ValidFunction<TItem,TValues, TMeta>]
  : TValue extends object
  ? { [key in keyof TValue]?: ValidFunction<TValue[key],TValue, TMeta> } | Valid<TValue,TValues, TMeta>
  : Valid<TValue, TValues, TMeta>;
export interface Field<T, TValues, TMeta> {
  default?: T;
  valid?: ValidFunction<T, TValues, TMeta>;
}

export type FieldOf<T extends Record<string, any>> = {
  [P in keyof T]: T[P]['default'];
};

export type Params<TValues extends Record<string, any>, TMeta> = {
  [P in keyof TValues]: Field<TValues[P], TValues, TMeta>;
};

export default function useForm<T extends Record<string, any>, TMeta>(fields: Params<T, TMeta>, meta?: TMeta) {
  type Values = FieldOf<typeof fields>;
  const TempForm = useMemo(() => {
    class TempForm extends FormBase {
      Values: Values;
      Meta: TMeta;
      validate(values: Values, meta) {
        return validator(values, meta);
      }
    }

    const validators = {};
    Object.keys(fields).forEach((key) => {
      validators[key] = fields[key].valid;
    });
    const validator = TempForm.combineValidators<Values>(validators);
    return TempForm;
  }, []);
  const { duck, store, dispatch } = useDuck(TempForm, [createLogger({ collapsed: true })]);

  /**
   * 设置 Meta
   */
  useEffect(() => {
    if (!meta) return;
    dispatch(duck.creators.setMeta(meta));
  }, [JSON.stringify(meta)]);

  /**
   * 设置初始值
   */
  const defaultValues = Object.values(fields).map((item) => item.default);
  useEffect(() => {
    const initValues = {} as Values;
    Object.keys(fields).forEach((key: keyof Values) => {
      initValues[key] = fields[key].default;
    });
    dispatch(duck.creators.setValues(initValues));
  }, [JSON.stringify(defaultValues)]);

  return {
    fields: duck.getAPI(store, dispatch).getFields(Object.keys(fields) as any),
    values: duck.selectors.values(store),
    meta: duck.selectors.validateMeta(store),
    firstInvalid: duck.selectors.firstInvalid(store),
    check() {
      const firstInvalid = duck.selectors.firstInvalid(store);
      dispatch(duck.creators.setAllTouched());
      if (firstInvalid) {
        return false;
      }
      return true;
    },
  };
}
