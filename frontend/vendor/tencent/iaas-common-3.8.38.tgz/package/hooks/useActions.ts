/**
 * 尝试将Operations中的逻辑抽取公共化，也能用于批量操作、分组菜单等场景。
 * 
 * 为了更容易维护，换成 saga-duck 的方案，处理异步逻辑更简单
 * 
 * 主要做这几件事
 *  - 判断 supported ，如果为Promise，则默认为false，直到完成时再替换结果
 *  - 当 supported 不为false时，判断 invalid ，如果为Promise，默认置空，直到完成时再替换结果
 *  - 包装 fn ，当 invalid 有内容或内容未决(Promise)时执行无效果
 *  - 返回的 actions 会过滤不支持(supported: false)的选项
 *  - 支持 menu 递归结构
 * 
 */

import * as React from 'react'
import { createToPayload, Duck, useDuck } from 'saga-duck'
import { takeLatest } from 'redux-saga-catch'
import { all, put } from 'redux-saga/effects'

export interface Action {
  /** 操作是否支持，如果不支持(为false)则不展示此按钮，可以为Promise。不传表示支持 */
  supported?: boolean | Promise<boolean>
  /** 操作是否可用，可以为Promise */
  invalid?: React.ReactNode | Promise<React.ReactNode>
  /** 操作入口 */
  fn?: () => void
}

/** 将Action转为支持递归子菜单的类型 */
export type Menuize<T extends Action> = T & {
  /** 递归子菜单，如果子菜单所有项都为 supported:false ，则此项也会被过滤 */
  menu?: Menuize<T>[]
}

/** 将Action转为 */
export type Synchronize<T extends Menuize<Action>> = Omit<T, 'supported' | 'invalid' | 'menu'> & {
  supported?: boolean
  invalid?: React.ReactNode
  menu?: Synchronize<T>[]
}

/**
 * 将包含异步判断 (supported/invalid) 的操作列表（支持menu递归）同步化的 react hook
 * 
 * 例如：
 * ```jsx
 * function Cmp() {
 *   const actions = useActions([
 *     {
 *       supported: Promise.resolve(false),
 *       label: '删除',
 *       fn: () => { }
 *     },
 *     {
 *       supported: Promise.resolve(true),
 *       invalid: Promise.resolve('当前状态不支持此操作'),
 *       label: '编辑',
 *       fn: () => { alert(1) }
 *     },
 *   ])
 *   // actions 最终为以下内容
 *   // [
 *   //   {
 *   //     supported: true,
 *   //     invalid: '当前状态不支持此操作',
 *   //     label: '编辑',
 *   //     fn: () => {}
 *   //   }
 *   // ]
 * }
 * ```
 */
export default function useActions<T extends Action>(actions: Menuize<T>[], deps: any[] = [actions]): Synchronize<Menuize<T>>[] {
  const { duck, store, dispatch } = useDuck(ActionsDuck as ActionsDuckType<T>)
  React.useEffect(() => {
    dispatch(duck.creators.load(actions))
    return () => {
      dispatch(duck.creators.cancel())
    }
  }, [duck, dispatch, ...deps])

  return duck.selectors.visibleActions(store)
}

type ActionsDuckType<T extends Action> = {
  new (...any: any[]): ActionsDuck<T>
}
class ActionsDuck<T extends Action> extends Duck {
  get quickTypes() {
    enum Types {
      LOAD,
      CANCEL_LOAD,
      SET_SYNC_ACTIONS,
      UPDATE_SYNC_ACTION,
    }
    return {
      ...super.quickTypes,
      ...Types
    }
  }
  get reducers() {
    const { types } = this
    return {
      ...super.reducers,
      actions: (state: Synchronize<Menuize<T>>[] = [], action): Synchronize<Menuize<T>>[] => {
        switch (action.type) {
          // 初始列表设置
          case types.SET_SYNC_ACTIONS:
            return action.payload
          // 子项异步更新，支持递归
          case types.UPDATE_SYNC_ACTION:
            {
              const { type, indexes, payload } = action as { type: string, indexes: number[], payload: Partial<Synchronize<Menuize<T>>> }
              const newList = state.slice(0)
              const [index, ...restIndexes] = indexes
              const old = newList[index]
              newList[index] = {
                ...old,
                ...(restIndexes.length > 0 ? {
                  menu: this.reducers.actions(old.menu, { type, indexes: restIndexes, payload })
                } : payload)
              }
              return newList
            }
          case types.CANCEL_LOAD:
            return [];
          default:
            return state
        }
      }
    }
  }
  get rawSelectors() {
    type State = this['State']
    return {
      ...super.rawSelectors,
      visibleActions: (state: State) => {
        return filterAction(state.actions)
      }
    }
  }
  get creators() {
    const { types } = this
    return {
      ...super.creators,
      load: createToPayload<Menuize<T>[]>(types.LOAD),
      cancel: createToPayload<void>(types.CANCEL_LOAD),
    }
  }
  *saga() {
    yield* super.saga()

    const duck = this
    const { types } = duck
    yield takeLatest([types.LOAD, types.CANCEL_LOAD], function* (action) {
      if (action.type === types.CANCEL_LOAD) {
        return
      }
      const actions: T[] = action.payload
      // 初始值设置，如果是异步的，默认都当作不可用
      yield put({
        type: types.SET_SYNC_ACTIONS,
        payload: actions.map(toSyncAction)
      })
      yield* duck.watchActions(actions, [])
    })
  }
  *watchActions(list: Menuize<T>[], indexes: number[]) {
    const duck = this
    const { types } = duck
    yield all(list.map(function* (o, index) {
      let supported: boolean = null
      if (checkIfPromise(o.supported)) {
        try {
          supported = yield o.supported
          yield put({
            type: types.UPDATE_SYNC_ACTION,
            indexes: indexes.concat(index),
            payload: { supported }
          })
        } catch {
          // 出错就当作不支持
        }
      }
      // 如果不支持，直接跳过后面所有
      if (supported === false) {
        return
      }

      // 再处理 invalid
      let invalid: React.ReactNode = null
      if (checkIfPromise(o.invalid)) {
        try {
          invalid = yield o.invalid
          const fn = invalid ? noop : o.fn
          yield put({
            type: types.UPDATE_SYNC_ACTION,
            indexes: indexes.concat(index),
            payload: { invalid, fn }
          })
        } catch { }
      }
      // 如果不可用，跳过
      if (invalid) {
        return
      }
      // 最后处理menu递归
      if (o.menu) {
        yield* duck.watchActions(o.menu, indexes.concat(index))
      }
    }))
  }
}

function toSyncAction<T extends Action>(o: Menuize<T>): Synchronize<Menuize<T>> {
  const supported = checkIfPromise(o.supported) ? false : o.supported
  const invalid = checkIfPromise(o.invalid) ? null : o.invalid
  const fn = checkIfPromise(o.invalid) || o.invalid ? noop : o.fn
  return ({
    ...o,
    supported: supported,
    invalid: invalid,
    fn,
    menu: o.menu?.map(toSyncAction)
  })
}

/**
 * 过滤 supported 标记为 false 的选项。当一个子菜单全部都不支持时，父菜单也会被过滤。
 */
function filterAction<T extends Action>(list: Synchronize<Menuize<T>>[]): Synchronize<Menuize<T>>[] {
  return list.map(o => {
    if (o.supported === false) {
      return null
    }
    if (o.menu) {
      const menu = filterAction(o.menu)
      if (menu.length <= 0) {
        return null
      }
      return {
        ...o,
        menu
      }
    }
    return o
  }).filter(o => !!o)
}


function checkIfPromise<T>(promise: Promise<T> | T): promise is Promise<T> {
  return promise instanceof Object ? ('then' in promise) && ('catch' in promise) : false
}

function noop() { }