import React from 'react';

export default function useRecord<T>(record: T) {
  const state = React.useMemo(() => ({} as T), []);
  for (const key of Object.keys(record)) {
    state[key] = record[key];
  }
  return state as T;
}
