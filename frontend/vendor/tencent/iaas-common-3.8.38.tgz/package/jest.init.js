import 'babel-polyfill'

global.seajs = {
  require(m) {
    switch (m) {
      case 'appUtil':
        return {
          getRegionId() {
            return 1
          },
          setRegionId() {}
        }
      default:
        return {}
    }
  }
}
