import { t } from '@tencent/tea-app/lib/i18n'
import { language } from '@tencent/tce-sdk';
import { isTCE } from './util/tce';
const i18n = seajs.require('widget/i18n')

let isI18n = false
i18n.then(_isI18n => {
  if (_isI18n) {
    isI18n = true
  }
})

/** 当前用户帐号支付货币单位 */
export const currency = {
  get symbol() {
    if (isTCE) {
      return language.getCurrentCurrencyInfo?.()?.symbol || '¥';
    }
    return isI18n ? '$' : '¥'
  },
  get code() {
    if (isTCE) {
      return language.getCurrentCurrencyInfo?.()?.code || 'CNY';
    }
    return isI18n ? 'USD' : 'CNY'
  },
  get words() {
    if (isTCE) {
      return language.getCurrentCurrencyInfo?.().words || t('元');
    }
    return isI18n ? t('美元') : t('元')
  }
}

declare global {
  interface Window {
    LOGIN_INFO: {
      area?: number
    }
  }
}

/*
 * 根据当前用户类型返回正确链接。
 * 当用户是国际站时，如传入有国际站链接，则使用国际站链接，否则使用国内站链接
 */
export function docLink(zhUrl, intUrl) {
  return window.LOGIN_INFO && window.LOGIN_INFO.area == 2 && intUrl ? intUrl : zhUrl
}