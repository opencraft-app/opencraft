/** 当前环境是否是TCE环境。公私一体化项目的TCE环境才会命中 */
export const isTCE = window.ISTCE === true;

declare global {
  interface Window {
    ISTCE: boolean;
  }
}