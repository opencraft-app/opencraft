import cidrRegex from 'cidr-regex'
import ipRegex from 'ip-regex'

// 将IP字符串如 10.0.0.1 转为数字
// 如 255.255.255.255 转为 4294967295，也就是二进制的 32 个 1
export function ipv4ToNumber(str: string): number {
  if (!ipRegex.v4({ exact: true }).test(str)) {
    return null
  }
  return str
    .split('.')
    .map((v, i) => {
      // IP 最大能到 32 位，需要 >>> 0 转为无符号整型
      return (Number(v) << ((3 - i) * 8)) >>> 0
    })
    .reduce((pre, cur) => {
      return pre + cur
    }, 0)
}
// 将IP字符串转为数字数组
// 如 '255.255.255.255' 转为 [255, 255, 255, 255]
export function ipv4ToNumbers(str: string): number[] {
  if (!ipRegex.v4({ exact: true }).test(str)) {
    return null
  }
  return str.split('.').map((v, i) => {
    return Number(v)
  })
}
// 根据 CIDR 中的掩码对 IP 进行裁剪
// 255.255.255.255/16 => 255.255.0.0/16
// 255.255.255.255/0 => 0.0.0.0/0
export function formatV4Cidr(str: string) {
  if (!cidrRegex.v4({ exact: true }).test(str)) {
    return null
  }
  let [ip, mask] = str.split('/')
  const maskNumber = Number(mask)
  let ipNumbers = ipv4ToNumbers(ip)
  ipNumbers = ipNumbers.map((x, i) => {
    const m = 8 - Math.max(Math.min(8, maskNumber - i * 8), 0)
    return (x >> m) << m
  })
  return `${ipNumbers[0]}.${ipNumbers[1]}.${ipNumbers[2]}.${ipNumbers[3]}/${mask}`
}
