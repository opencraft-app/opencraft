/**
 * 设置LocalStorage缓存
 * @param key
 * @param value
 */
export function safeSetLocalStorageItem(key: string, value: string) {
  try {
    localStorage.setItem(key, value);
  } catch {
  }
}
