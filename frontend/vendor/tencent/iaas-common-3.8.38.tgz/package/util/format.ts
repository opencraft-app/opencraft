/**
 * 数字千分位转换
 * 12300.00 => 12,300.00
 */
export function thousandsFormat(number: number) {
  const val = Number(number)
  if (isNaN(val)) {
    return null
  }

  let [integerPart, decimalPart] = String(val).split('.')
  integerPart = integerPart.replace(/(\d)(?=(?:\d{3})+$)/g, '$1,')
  return decimalPart ? `${integerPart}.${decimalPart}` : integerPart
}
