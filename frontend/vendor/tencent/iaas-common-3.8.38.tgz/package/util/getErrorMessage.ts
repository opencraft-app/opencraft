/** 获取一个错误的文本信息 */
export default function getErrorMessage(e) {
  const message =  e?.Message || e?.shortMessage || e?.message || e?.msg || e?.errorMsg || String(e)
  // 递归一下，避免有些返回的message还是对象
  if(typeof message !== 'string'){
    return getErrorMessage(message)
  }
  return message
}
