# 简介
`iaas_common`为腾讯云基础、网络、中间件中心基于`saga-duck`及`tea`的控制台开发公共代码库。

使用tnpm包的形式引入，解决以前`git submodule`引入造成版本不稳定的问题

# 使用
## 版本
- `1.x.x` 基于`saga-duck2.x`与`tea-component`，**约束`typescript`版本为`2.6.1`**
- `2.x.x` 基于`saga-duck3.x`与`tea-component`
- `3.x.x` 基于`saga-duck3.x`与`tea2`

## 安装
`tnpm i -S @tencent/iaas-common`

（安装特定版本： `tnpm i -S @tencent/iaas-common@x`）

## 初始化配置
执行指令 `iaas-init`

如果使用`tea-cli`开发，无需其它处理；否则还应在对应的webpack配置中添加`alias`（可参考 `aliasFromTsConfig.js` 文件内容）

如果还使用`tea-cli`的国际化功能，请将本代码库目录添加到扫描目标，例如
`tea scan -i {src,node_modules/@tencent/iaas-common}/**/*.{js,jsx,ts,tsx}`

如果使用`tea-cli`2.2+，编辑`tea.config.js`添加`scan`指令参数
```js
// 翻译扫描目录
exports.command = {
  scan: {
    input: [
      '{app,src,node_modules/@tencent/iaas-common}/**/*.{js,jsx,ts,tsx}',
      "!**/__tests__/**",
      '!**/*.test.{js,jsx,ts,tsx}'
    ]
  }
}
```

最后，在项目的入口ts文件里引入公共声明，例如

`/// <reference path="../node_modules/@tencent/iaas-common/ambient.d.ts" />`

## 配置化(buildConfig)
对于不同的环境，可以进行功能配置化，以兼容私有云

用法： 打包时将配置以JSON序列化后，传递给 `TEA_IAAS_COMMON_BUILD_CONFIG` 环境变量。

目前支持以下配置（最新内容请查看 [buildConfig.ts](./buildConfig.ts)）
```ts
{
  /** 是否展示地域 */
  showRegion?: boolean
  /** TCE使用平台公共的地域查询（qcbase的queryConsoleRegion接口在TCE不存在） */
  usePlatformRegions?: boolean
  /** 是否禁用地域分组，即不使用RegionSelect组件 */
  noRegionGroup?: boolean
  /** 如果不展示地域，则默认的regionId */
  fixedRegionId?: number
  /** 是否将所有白名单全量（不请求白名单接口） */
  noWhiteList?: boolean
  /** 是否使用tea的请求 */
  useTeaApiRequest?: boolean
}
```
# 贡献&发布
可以在对应分支push或提pr，需发布时，使用`npm version patch` 或手动更新 `package.json` 中的 `version` 字段，push后CI会自动进行发布。

# 分支约定
- `master` 发布为 `1.x.x`
- `saga-duck3` 发布为 `2.x.x`
- `tea2` 发布为 `3.x.x`
- `hotfix/*` 发布为`x.x.x-x`
- `dev/*` 可发布任意版本，但会加上 `beta` 标签，安装时需指定版本或标签

**符合以上规则的分支，`CI`在`push`中检测到`package.json`变更后，将会自动进行`tnpm`包发布**
