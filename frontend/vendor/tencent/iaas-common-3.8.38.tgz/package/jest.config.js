const esModules = ['saga-duck', 'redux-saga-catch', '@tencent/tea-app'].join('|')
module.exports = {
  setupFilesAfterEnv: ['./jest.init.js'],
  preset: 'ts-jest',
  testEnvironment: 'node',
  transform: {
    '^.+\\.jsx?$': 'babel-jest',
    '^.+\\.tsx?$': 'ts-jest'
  },
  transformIgnorePatterns: [`/node_modules/(?!${esModules})`],
  testRegex: '(/__tests__/.*|(\\.|/)(test|spec))\\.(jsx?|tsx?)$',
  moduleNameMapper: {
    '^@tencent/iaas-common/inject/(.*)': '<rootDir>/inject/$1',
    '^common/(.*)': '<rootDir>/$1',
    '^duckComponents/(.*)': '<rootDir>/duckComponents/$1',
    '^ducks/(.*)': '<rootDir>/ducks/$1',
    '^components/(.*)': '<rootDir>/components/$1',
    '^helpers/(.*)': '<rootDir>/helpers/$1',
    '^models/(.*)': '<rootDir>/models/$1'
  },
  moduleFileExtensions: ['ts', 'tsx', 'js', 'jsx', 'json', 'node'],
  globals: {
    window: {}
  }
}
