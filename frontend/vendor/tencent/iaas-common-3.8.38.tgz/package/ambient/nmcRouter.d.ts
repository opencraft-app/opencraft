/**
 * 声明 NmcRouter
 * 忽略了部分内部调用的方法
 */
interface NmcRouter {
  /**
   * 支持 debug 模式（url 加上 debug 后不改变页面切换逻辑，可有针对性做一些事情）
   */
  debug?: string;
  /**
   * 扩展路由
   * @method extend
   * @param {Object} obj 路由 map
   */
  extends(obj: Object): void;
  /**
   * 动态使用路由规则
   * @method use
   * @param {String} rule 路由匹配字符串
   * @param {Function} action 路由操作
   **/
  use(rule: string, action: Function): void;
  /**
   * 取消动态路由规则的使用
   * @method unuse
   * @param {String} rule 路由的匹配字符串
   **/
  unuse(rule: string): void;
  /**
   * 获取hash值
   * @method getHash
   * @param {Object} win 窗口对象
   * @return {String} hash值
   */
  getHash(win: Window): string;
  /**
   * 获取url片段
   * @method getFragment
   * @return {String} url片段
   */
  getFragment(): string;
  /**
   * 导航
   * @method navigate
   * @param {String}  url 地址
   * @param {Boolean} silent 不改变地址栏
   * @param {Boolean} replacement 替换浏览器的当前会话历史(h5模式时支持)
   */
  navigate(url: string, silent?: boolean, replacement?: boolean): void;
  /**
   * 重定向
   * @method redirect
   * @param {String}  url 地址
   * @param {Boolean} silent 不改变地址栏
   * @param {Boolean} replacement 替换浏览器的当前会话历史(h5模式时支持)
   */
  redirect(url: string, silent?: boolean, replacement?: boolean): void;
  /**
   * 加载页面
   * @method loadUrl
   * @param {String} url 地址
   */
  loadUrl(url: string): void;

  [key: string]: any;
}
