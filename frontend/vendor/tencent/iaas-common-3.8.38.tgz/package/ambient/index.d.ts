/// <reference path="./iaas.d.ts" />
/// <reference path="./nmcRouter.d.ts" />
/// <reference path="./appUtil.d.ts" />
/// <reference path="./tips.d.ts" />
/// <reference path="./redux.d.ts" />
/// <reference path="./redux-saga.d.ts" />
// TS2.8工具方法引入
// 低版本ts不支持排除某属性，使用自定义方案
// 参考：https://stackoverflow.com/questions/48215950/exclude-property-from-type
type Diff<T extends string, U extends string> = ({ [P in T]: P } &
  { [P in U]: never } & { [x: string]: never })[T]

declare namespace nmc {
  interface Require {
    (id: 'models/iaas'): Iaas
    (id: 'router'): NmcRouter
    (id: 'appUtil'): AppUtil
    (id: 'tips'): Tips
    (id: string): any
  }
}
declare const seajs: {
  require: nmc.Require
  use: (path: string | string[], callback?: Function) => {}
}

interface Identifiable {
  id: number | string
}

interface BaseReactProps extends React.Props<any> {
  className?: string
  style?: React.CSSProperties
}

declare namespace JSX {
  export interface IntrinsicElements {
    radiogroup: any
    input: React.DetailedHTMLProps<
      React.InputHTMLAttributes<HTMLInputElement>,
      HTMLInputElement
    > & { webkitdirectory?; directory?}
  }
}

interface GroupUserRegion {
  id: number
  region: string
  zoneList: GroupUserZone[]
}
interface GroupUserZone {
  zoneId: number
  zoneName: string
}
interface Window {
  QCLOUD_BUY_CONFIG?: {
    isGroupCloudUser: boolean
    ftCloudRegions: QCBuyGroupUserRegion[]
    autoDrivingCloudRegions: QCBuyGroupUserRegion[]
    isAutoDrivingCloudUser: boolean
  }
  ftCloudRegions?: GroupUserRegion[]
  isFtCloudUser?: boolean
  isAutoDrivingCloudUser?: boolean
  autoDrivingCloudRegions?: GroupUserRegion[]
}
interface QCBuyGroupUserRegion {
  id: string
  apCode: string
  zones: { id: string, name_cn: string, zone_id: string }[]
}