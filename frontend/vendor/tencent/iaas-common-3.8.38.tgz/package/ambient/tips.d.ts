interface Tips {
  /**
   * 成功提示
   * @method success
   * @param  {String} str 提示内容
   * @param  {Int}    duration 持续时间
   * @author evanyuan
   */
  success(str?: string, duration?: number): void;
  /**
   * 失败或错误提示
   * @method error
   * @param  {String} str 提示内容
   * @param  {Int}    duration 持续时间
   * @author evanyuan
   */
  error(str?: string, duration?: number): void;
  /**
   * 操作中提示
   * @method error
   * @param  {String} str 提示内容
   * @param  {Int}    duration 持续时间
   * @author enofan
   */
  loading(str?: string, duration?: number): void;
  /**
   * 小黄条提示
   * @method flash
   * @param  {String} str 提示内容
   * @param  {String} type 类型
   * @param  {Int}    duration 持续时间
   * @author evanyuan
   */
  flash(str?: string, type?: 'loading' | 'success' | 'error', duration?: number): void;
  /**
   * 显示小黄条
   * @method showFlash
   * @param  {String} str 提示内容
   * @param  {String} icoClass 图标class (top-alert-icon-waring top-alert-icon-done top-alert-icon-doing)
   * @param {String} type 提醒类型(loading, success, warning), 默认为loading
   * @author evanyuan
   */
  showFlash(str: string, iconClass: string, type?: 'loading' | 'success' | 'error'): void;
  hideFlash(fromTiming: boolean): void;
  showLoading(opts?: LoadingOptions): void;
  stopLoading(): void;
  /**
   * 禁用启用加载提示
   * @param bool 
   */
  setLoading(bool: boolean): void;
  hideFlashNow(): void;
  [key: string]: any;
}

interface LoadingOptions {
  text?: string;
  className?: string;
}