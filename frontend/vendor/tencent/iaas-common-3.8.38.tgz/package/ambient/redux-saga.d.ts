import '@redux-saga/types'
declare module '@redux-saga/types'{
  interface Action<T extends string = string> {
    type: T
    payload?: any
    [key: string]: any
  }
}