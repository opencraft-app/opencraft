interface AppUtil {
  /**
   * 获取登录用户的 user_id 用户名
   * @returns {*|String}
   */
  getUserId(): string | undefined;
  /**
   * 获取登录用户的 uin
   * @returns {*|Number}
   */
  getUserUin(): number;
  /**
   * 获取登录用户的开发商uin
   * @returns {*|String}
   */
  getOwnerUin(): string | undefined;
  /**
   * 获取登录用户的 user_cam_id
   * @returns {*|String}
   */
  getCamId(): string | undefined;
  /**
   * 获取地域列表
   * @param productCode 产品 ID
   * @returns {*}
   */
  getRegionList(productCode: string): Promise<any[]>;
  /**
   * 获取当前登录用户信息
   */
  getCurrentUserInfo(): Promise<any>;
  /**
   * 查询可用区
   * @param {String} regionName 地域名称
   */
  getZone(regionName: string): any;
  /**
   * 返回本地存储的 region 简称，如 gz
   */
  getRegion(): string;
  /**
   * 设置当前地域
   * @param {String} region 地域名称
   */
  setRegion(region: string): void;
  /**
   * 返回本地存储的 regionId
   * @return {String}
   */
  getRegionId(): string;
  /**
   * 设置地域 ID
   * @param {String} regionId 地域 Id
   */
  setRegionId(rid: string): void;
  /**
   * 支持国际化 3.6.0支持
   * @param {} region_id 
   */
  getRegionName(regionId?: string): string;
  /**
   * 将 utf-16 的值转成 utf-8
   */
  utf16to8(str: string): string;
  /**
   * 简易版parallel并行任务函数
   * @method parallel
   * @param {Array} tasks 函数数组
   * @param {Function} callback 回调
   */
  parallel(tasks: Function[], callback: Function): void;
  /**
   * 修改url参数
   * @param url  需要修改的url
   * @param arg  需要修改的参数名
   * @param argValue  修改后的值
   */
  changeURLArg(url: string, arg: string, argValue: string): string;
  /**
   * 解析 GGW 返回的日期时间格式: 2015-01-15 21:15:20
   * @param {String} timeStr 日期字符串 (yyyy-MM-dd hh-mm-ss.mmm)
   * */
  cgwTimeParse(timeStr: string): Date;
  /**
   * UTC日期时间格式: 2015-01-15T21:15:20Z 转换为 localTime: 2015-01-16 05:15:20
   * @param {String} UTCDateString 日期字符串 (yyyy-MM-ddThh:mm:ss.mmmZ)
   * */
  convertUTCTimeToLocalTime(UTCDateString: string): string;
  /**
   * @method formatDate
   * @param {Object} date Date 对象
   * @param {String} fmt 格式化目标格式
   * @description 定义 Date 发 format 方法用于格式化日期
   */
  formatDate(date: Date, fmt: string): string;
  /**
   * 把 date 对象转成显示的日期  例如 2016-01-02 05:12:07
   * @param time
   * @returns {string}
   */
  getFormatTime(time: Date): string;
  /**
   * 获取一个区间时间
   * @param hourSpan
   * @returns {{beginTime: (*|string), nowTime: (*|string)}}
   */
  getTimeSpan(hourSpan: number): Record<'beginTime' | 'nowTime', string>;
  /**
   * 把 date 日期对象转化为显示的文本日期  例如 2016-10-22
   * @param date
   * @returns {string}
   */
  dateToStr(date: Date): string;
  /**
   * 把文本的日期转化为Date对象  例如  '2016-10-22'
   * @param str
   * @returns {Date}
   */
  strToDate(str: 'REALTIME' | string): Date;
  /**
   * 获取一天的开始
   * @param date
   * @returns {Date|*}
   */
  toDayStart(date: Date): Date;
  /**
   * 获取一天的结束 '2016-10-22 23:59:59'
   * @param date
   * @returns {Date|*}
   */
  toDayEnd(date: Date): Date;
  /**
   * 判断一个对象是否是数组，参数不是对象或者不是数组，返回 false
   * @param {Object} arg 需要测试是否为数组的对象
   * @return {Boolean} 传入参数是数组返回 true，否则返回 false
   */
  isArray(arg): boolean;
  /**
   * 校验是否是合格的 IP 地址
   * @param ip 
   */
  checkIfIp(ip: string): boolean;
  /**
   * 将json格式格式化
   * @param json 
   * @param options 
   */
  formatJson(
    json: string,
    options?: Record<'newlineAfterColonIfBeforeBraceOrBracket' | 'spaceAfterColon', boolean>,
  ): string;
  /**
   * 防抖
   * @param fn 
   * @param wait 
   */
  debounce(fn: Function, wait: number): Function;
  /**
   * 普通对象深拷贝(不支持递归对象)
   * @param obj
   * @returns {Object}
   */
  clone(obj): any;
  /**
   * html模板生成器, =号转义, -号原始输出
   * @method tmpl
   * @param  {String} str html模板字符串 | script模版元素Id
   * @param  {Object} data 用于生成模板的数据对象
   * @param  {Object} [mixinTmpl] 混合模版对象
   * @return {String} 返回 html 字符串
   * @author evanyuan
   * @example
   *		var careerTmpl = '<div><%=career%></div>';
   * 		util.tmpl('<h1><%=user%></h1> <%#careerTmpl%>', {user:'evanyuan', career: '前端工程师'}, {careerTmpl: careerTmpl});
   */
  tmpl(str: string, data: Record<string, any>, mixinTmpl: Record<string, any>): string;
  /**
   * 提取 url 中的参数到对象中返回
   * @param url 
   */
  parseQueryString(url: string): Record<string, string>;
  /**
   * 获取语言
   * 优先 url，Node 接口，cookie，弹性交付
   */
  getLanguage(): string;
  /**
   * 设置语言
   */
  setLanguage(): void;
  /**
   * 获取默认语言，这里 sdk 中就是单词拼写错的。。。
   */
  getDefaultLanguge(): string;
  requestLang(data: any, success: Function, fail: Function, serviceType: string, cmd: string): void;
  getCurrentLang(platform: string, success: Function, fail: Function): void;
  setCurrentLang(lang: string, platform: string, success: Function, fail: Function): void;
  addLanguage(url: string): void;
  getLanguageMap(): Record<string, string>;
  getUin(): string;
  getImgCacheUrl(): string;
  [key: string]: any;
}