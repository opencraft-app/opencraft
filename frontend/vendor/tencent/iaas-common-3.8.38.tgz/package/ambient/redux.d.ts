// redux-saga-catch升级ts版，使得takeLatest等方法带了类型校验
// 为保证兼容，加上payload属性声明，避免旧代码报类型错误
import 'redux'
declare module 'redux'{
  interface Action{
    payload?: any
    [key: string]: any
  }
}