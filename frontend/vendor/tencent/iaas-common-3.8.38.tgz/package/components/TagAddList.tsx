/**
 * tea2增加标签组件，一般用于创建资源时 创建标签
 * 目前样式可能有点龊，有缘人可以来优化下
 * author jiahuitan
 * example:
<Form.Item label={t('标签')}>
  <Form.Text>
    <TagAddList onChange={tagList => tags.setValue(tagList)} />
  </Form.Text>
</Form.Item>
 *
 */

import * as React from 'react'
import { t } from '@tencent/tea-app/lib/i18n'
import {
  AutoComplete,
  Icon,
  Row,
  Col,
  Text,
  Input,
  Table,
  TableColumn,
  TableProps,
  IconProps
} from '@tencent/tea-component'
import { fetchAllHelper } from '../models/util'

const { useEffect, useState } = React

interface TagAddListProps {
  /**标签标签变化时的回调，一开始也会触发 */
  onChange: (tagList: { key: string; value: string }[]) => void
  /**默认标签列表 */
  defaultTagList?: { key: string; value: string }[]
  tableProps?: Partial<TableProps>
  iconProps?: Partial<IconProps>
}

interface TagRecord {
  key: string
  value: string
  options?: { text: string; value: string }[]
}

const iaas = seajs.require('models/iaas')
const appUtil = seajs.require('appUtil')

const TagAddList = ({
  onChange,
  defaultTagList = [],
  tableProps,
  iconProps
}: TagAddListProps) => {
  // 当前用户的keys列表
  const [tagKeys, setTagKeys] = useState<{ text: string; value: string }[]>([])

  // 待添加的标签
  const [tagList, setTagList] = useState<TagRecord[]>(defaultTagList)

  useEffect(() => {
    onChange(tagList)
  }, [tagList])

  useEffect(() => {
    // 拉标签key
    GetTagKeys().then(keys => {
      setTagKeys(keys.map(key => ({ value: key, text: key })))
    })
  }, [])
  const columns = [
    {
      key: 'key',
      header: t('标签键'),
      render: (tag, id, index) => (
        <AutoComplete
          options={(tagKeys || []).filter(({ text }) => text.includes(tag.key))}
          onChange={value => {
            // 只有直接选择才会去查询对应的值
            GetTagValues([value]).then(values =>
              setTagList(
                tagList.map((tag, tagIndex) =>
                  tagIndex === index
                    ? {
                        ...tagList[index],
                        key: value,
                        options: values.map(v => ({
                          value: v.tagValue,
                          text: v.tagValue
                        }))
                      }
                    : tag
                )
              )
            )
          }}
        >
          {ref => (
            <Input
              ref={ref}
              placeholder={t('请选择')}
              style={{ width: '100px' }}
              value={tag.key}
              onChange={value =>
                setTagList(
                  tagList.map((tag, tagIndex) =>
                    tagIndex === index
                      ? {
                          ...tagList[index],
                          key: value
                        }
                      : tag
                  )
                )
              }
            />
          )}
        </AutoComplete>
      )
    },
    {
      key: 'value',
      header: t('标签值'),
      render: (tag, id, index) => (
        <AutoComplete
          options={(tag.options || []).filter(({ text }) =>
            text.includes(tag.value)
          )}
          onChange={v =>
            setTagList(
              tagList.map((tag, tagIndex) =>
                tagIndex === index
                  ? {
                      ...tagList[index],
                      value: v
                    }
                  : tag
              )
            )
          }
        >
          {ref => (
            <Input
              ref={ref}
              placeholder={t('请选择')}
              style={{ width: '100px' }}
              value={tag.value}
              onChange={value =>
                setTagList(
                  tagList.map((tag, tagIndex) =>
                    tagIndex === index
                      ? {
                          ...tagList[index],
                          value: value
                        }
                      : tag
                  )
                )
              }
            />
          )}
        </AutoComplete>
      )
    },
    {
      key: 'action',
      header: t('操作'),
      render: (x, id, index) => (
        <Icon
          type="close"
          onClick={() => {
            setTagList(tagList.filter((item, i) => i !== index))
          }}
          {...iconProps}
        />
      )
    }
  ] as TableColumn<TagRecord>[]

  return (
    <>
      <Table columns={columns} records={tagList} {...tableProps} />

      <a
        onClick={() => {
          setTagList([...tagList, { key: '', value: '' }])
        }}
      >
        {t('添加')}
      </a>
    </>
  )
}

const DescribeAllTagValues = fetchAllHelper(
  (regionId: number, data = {}) => {
    return iaas.apiRequest<
      {
        Response: {
          Tags: { TagKey: string; TagValue: string }[]
        }
      },
      { Version: string; TagKeys: string[] }
    >({
      action: 'DescribeTagValues',
      serviceType: 'tag',
      data: {
        Version: '2018-08-13',
        regionId,
        ...data
      }
    })
  },
  { limit: 1000, targetSet: 'Tags' }
)
async function GetTagValues(
  tagKeys: string[]
): Promise<{ tagKey: string; tagValue: string }[]> {
  return DescribeAllTagValues(undefined, { TagKeys: tagKeys }).then(
    ({ Response: { Tags } }) => {
      return Tags.map(x => ({
        tagKey: x.TagKey,
        tagValue: x.TagValue
      }))
    }
  )
}

//------
const DescribeAllTagKeys = fetchAllHelper(
  (regionId: number, data = {}) => {
    return iaas.apiRequest<{ Response: { Tags: string[] } }>({
      action: 'DescribeTagKeys',
      serviceType: 'tag',
      regionId: regionId,
      data: {
        Version: '2018-08-13',
        ...data
      }
    })
  },
  { targetSet: 'Tags', limit: 1000 }
)
async function GetTagKeys(): Promise<string[]> {
  return DescribeAllTagKeys(undefined).then(({ Response: { Tags } }) => {
    return Tags
  })
}

export default TagAddList
