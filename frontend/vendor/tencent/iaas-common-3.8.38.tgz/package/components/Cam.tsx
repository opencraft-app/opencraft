import * as React from 'react'
import { t } from '@tencent/tea-app/lib/i18n'
import { app } from '@tencent/tea-app'
import { StatusTip } from '@tencent/tea-component'
import links from '../helpers/links'

function Loading(props: any) {
  return <StatusTip status="loading"></StatusTip>
}
export default function CAMBreak(props) {
  const [CAMBreak, setCAMBreak] = React.useState<React.FunctionComponent>(() => Loading)
  React.useEffect(() => {
    (async () => {
      try {
        const { CAMBreak } = await app?.sdk?.use('cam-sdk')
        setCAMBreak(() => CAMBreak)
      } catch (e) {
        setCAMBreak(() => CamTips)
      }
    })()
  }, [])
  return <CAMBreak {...props} />
}

const interfaceReg = /\(\w+:\w+\)/g
const camReg = /\(([\w|\/|-]*:){5}.*?\)/g

/**
 * @deprecated 请使用 CAMBreak 替代
 * @param props
 */
export function CamTips(props) {
  let { message = '', style = {} } = props
  message = message
    .replace(/^\(.+?\)/, '')
    .trim()
    .replace(interfaceReg, '<span class="text-success">$&</span>')
    .replace(camReg, '<span class="text-warning">$&</span>')
    .replace(/^(.+)$/gm, '<p class="rich-text">$1</p>')

  return (
    <div className="authority-wrap" style={{ textAlign: 'left', ...style }}>
      <p className="authority-inf text-weak">
        {t('该操作需要授权，请联系您的开发商为您添加权限。')}
        <a
          target="_blank"
          href={links.main("/document/product/598/10602")}
        >
          {t('查看授权操作指南')} <i className="external-link-icon" />
        </a>
      </p>
      {message && (
        <div>
          <p className="authority-tit text-weak">{t('失败信息描述：')}</p>

          <div className="rich-textarea">
            <div
              dangerouslySetInnerHTML={{ __html: message }}
              className="rich-content"
            />
          </div>
        </div>
      )}
    </div>
  )
}

export function CamHelpTips(props) {
  const { error = {} } = props
  let content = error.message || props.child || props.children
  if (props.type !== 'icon') {
    return (
      <span>
        <span
          aria-qc-popover-style={typeof props.style != 'undefined' ? props.style : 'width:500px;positon:fixed'}
          aria-qc-popover={'<cam-tips>' + content + '</cam-tips>'}
          aria-qc-popover-position={props.position || null}
          aria-qc-popover-attach-el={props.attachEl || null}
        >
          {props.content || '*****'}
        </span>
      </span>
    )
  } else {
    return (
      <span>
        <i
          b-if="icon"
          className="icon-info-red"
          aria-qc-popover-style={props.style || null}
          aria-qc-popover={'<cam-tips>' + content + '</cam-tips>'}
          aria-qc-popover-position={props.position || null}
          aria-qc-popover-attach-el={props.attachEl || null}
        />
      </span>
    )
  }
}

export function isCamRefused(e) {
  return (
    e?.code == 4102 ||
    e?.code == 42 ||
    e?.code == 'UnauthorizedOperation' ||
    e?.code == 'AuthFailure.UnauthorizedOperation'
  )
}
