import * as React from 'react'
import { Dropdown, List } from '@tencent/tea-component'
import { app } from '@tencent/tea-app'
import { t } from '@tencent/tea-app/lib/i18n'

export default class ProjectDropdown extends React.Component {
  componentDidMount() {
    if (!this.props.list) {
      this.getProjectList().then(list => {
        this.setState({ list })
      })
    }
  }
  getProjectList() {
    const { needAll = true, showAll, cam } = this.props
    let isShowAll = false
    return app.user.getPermitedProjectInfo().then(({ isShowAll, projects }) => {
      let list = projects.map(item => ({
        label: item.projectName,
        projectId: item.projectId,
        id: item.projectId
      }))
      isShowAll = needAll ? cam || isShowAll : false
      // 数据加载成功
      this.props.onLoaded && this.props.onLoaded(projects.slice())

      if (showAll) {
        isShowAll = true
      }

      if (isShowAll) {
        list.unshift({
          label: t('所有项目'),
          projectId: -1,
          id: -1
        })
      }
      return list
    })
  }
  render() {
    let { selected, onClick } = this.props

    if (this.state && this.state.list) {
      selected = this.state.list.filter(p => {
        return p.id == selected.id
      })[0]
    }

    return (
      <Dropdown
        button={(selected && selected.label) || t('请选择')}
        {...this.props}
      >
        <List type={'option'}>
          {(this.props.list || this.state ? this.state.list : []).map(item => (
            <List.Item
              selected={item.id == selected.id}
              onClick={e => onClick(item)}
            >
              {item.label}
            </List.Item>
          ))}
        </List>
      </Dropdown>
    )
  }
}
