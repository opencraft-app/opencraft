// /**
//  * 渲染到 document 下的单例气泡
//  * 主要用于规避气泡被外部元素 overflow 裁剪的问题
//  * author yuemingliu
//  */
// import { Component } from 'react'
// import * as ReactDom from 'react-dom'

// interface State {
//   visiable: boolean
//   popupElement: JSX.Element
//   target: HTMLElement
//   popupProps?
//   position: {
//     top?: number
//     left?: number
//     bottom?: number
//     right?: number
//   }
// }

// class PopupBoxManager extends Component<{}, State> {
//   constructor(props, context) {
//     super(props, context)
//     this.state = {
//       visiable: false,
//       popupElement: null,
//       target: null,
//       position: {
//         top: 0,
//         left: 0
//       }
//     }
//   }
//   replace(popupElement, popupProps) {
//     this.setState(
//       preState => {
//         // 在确定浮层尺寸之前先进行隐藏
//         return Object.assign(preState, {
//           popupElement,
//           target: popupProps.target,
//           popupProps: popupProps,
//           visiable: Boolean(popupElement),
//           position: { top: -999, left: -999 }
//         })
//       },
//       () => {
//         this.updatePosition()
//       }
//     )
//   }
//   release(popupElement) {
//     if (popupElement != this.state.popupElement) {
//       return
//     }
//     this.setState(preState =>
//       Object.assign(preState, {
//         popupElement: null,
//         visable: false,
//         position: {
//           top: 0,
//           left: 0
//         }
//       })
//     )
//   }
//   updatePosition() {
//     let managerWrapper = this.refs.managerWrapper
//     let $popupElement = $(managerWrapper)
//       .children()
//       .eq(0)
//     if (!$popupElement) {
//       return
//     }
//     // 计算气泡尺寸
//     let size = {
//       width: $popupElement.width(),
//       height: $popupElement.height()
//     }
//     // 计算气泡位置
//     let position = getPosition(
//       size,
//       this.state.target,
//       this.state.popupProps.focusPosition,
//       this.state.popupProps.alignPosition
//     )
//     this.setState(preState => Object.assign(preState, { position }))
//   }
//   render() {
//     return (
//       <div
//         style={Object.assign(
//           {
//             position: 'absolute'
//           },
//           this.state.position,
//           this.state.visiable ? {} : { visibility: 'hidden' }
//         )}
//         ref="managerWrapper"
//       >
//         {this.state.visiable && this.state.popupElement}
//       </div>
//     )
//   }
// }

// let popupContainer: HTMLDivElement = null
// let isSetup: boolean = false
// let manager: PopupBoxManager = null

// /**
//  * 在 document 下创建浮层的容器
//  */
// function renderPopupContainer() {
//   popupContainer = document.getElementById(
//     'react-popup-container'
//   ) as HTMLDivElement
//   if (popupContainer) {
//     return popupContainer
//   }
//   popupContainer = document.createElement('div')
//   popupContainer.id = 'react-popup-container'
//   document.body.appendChild(popupContainer)
//   return popupContainer
// }
// function renderManaer() {
//   if (popupContainer) {
//     manager = ReactDom.render(
//       <PopupBoxManager />,
//       popupContainer
//     ) as PopupBoxManager
//   }
// }

// function setup() {
//   if (!isSetup) {
//     renderPopupContainer()
//     renderManaer()
//     isSetup = true
//   }
// }

// export default {
//   replace: function(popupElement: JSX.Element, props) {
//     setup()
//     manager.replace(popupElement, props)
//   },
//   release: function(popupElement: JSX.Element) {
//     manager.release(popupElement)
//   }
// }

// function getPosition(popupElementSize, target, focusPosition, alignPosition) {
//   const $target = $(target)
//   const targetPosition = $target.offset()
//   const targetSize = {
//     width: $target.width(),
//     height: $target.height()
//   }

//   const positionTop =
//     focusPosition == 'top'
//       ? targetPosition.top + targetSize.height + 10
//       : focusPosition == 'bottom'
//         ? targetPosition.top - popupElementSize.height - 10
//         : 0
//   const positionLeft = getHorizontalPosition(
//     popupElementSize,
//     targetPosition,
//     targetSize,
//     alignPosition
//   )
//   return {
//     top: positionTop,
//     left: positionLeft
//   }
// }
// // 计算气泡的水平位置
// function getHorizontalPosition(
//   popupElementSize,
//   targetPosition,
//   targetSize,
//   alignPosition
// ) {
//   const targetCenter = targetPosition.left + targetSize.width / 2
//   const alignPositionNumber =
//     alignPosition == 'end' ? 90 : alignPosition == 'start' ? 10 : alignPosition
//   return targetCenter - popupElementSize.width * alignPositionNumber / 100
// }
