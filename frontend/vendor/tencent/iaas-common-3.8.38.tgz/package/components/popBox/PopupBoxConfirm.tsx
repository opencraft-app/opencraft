// import { Component } from 'react'

// import { PopupBoxBody, PopupBoxFooter, Button } from '@tencent/qcloud-component'
// import PopupBox from 'common/components/popBox/PopupBox'

// interface Props {
//   target: HTMLElement
//   confirmText?: string
//   cancelText?: string
//   onConfirm
//   onCancel
//   children?
//   focusPosition?
//   alignPosition?
//   style?
// }
// interface State {}

// export default class PopupBoxConfirm extends Component<Props, State> {
//   render() {
//     return (
//       <PopupBox
//         target={this.props.target}
//         onBlur={() => {
//           this.props.onCancel && this.props.onCancel()
//         }}
//         focusPosition={this.props.focusPosition || 'bottom'}
//         alignPosition={this.props.alignPosition || 'end'}
//         style={this.props.style || { minWidth: '260px' }}
//       >
//         <PopupBoxBody>{this.props.children}</PopupBoxBody>
//         <PopupBoxFooter>
//           <Button
//             onClick={e => {
//               this.props.onConfirm && this.props.onConfirm()
//             }}
//           >
//             {this.props.confirmText || '确认'}
//           </Button>
//           <Button
//             onClick={e => {
//               this.props.onCancel && this.props.onCancel()
//             }}
//             className={'weak'}
//           >
//             {this.props.cancelText || '取消'}
//           </Button>
//         </PopupBoxFooter>
//       </PopupBox>
//     )
//   }
// }
