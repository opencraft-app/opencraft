// /**
//  * 渲染到 document 下的单例气泡
//  * 主要用于规避气泡被外部元素 overflow 裁剪的问题
//  * author yuemingliu
//  */
// import { Component, createElement, Children } from 'react'
// import { PopupBox, PopupBoxProps } from '@tencent/qcloud-component'
// import popupManager from './Manager'

// interface Props extends PopupBoxProps {
//   target: HTMLElement // 气泡附着对象，用于确定气泡位置
//   scrollHide?: boolean
// }

// export default class PopupBoxFixed extends Component<Props, {}> {
//   render() {
//     return <noscript />
//   }
//   private _popupElement
//   private _renderToManager() {
//     this._popupElement = createElement(
//       PopupBox,
//       this.props,
//       Children.toArray(this.props.children)
//     )
//     popupManager.replace(this._popupElement, this.props)
//   }
//   componentDidUpdate() {
//     this._renderToManager()
//   }
//   componentDidMount() {
//     this._renderToManager()
//   }
//   componentWillUnmount() {
//     popupManager.release(this._popupElement)
//   }
// }
