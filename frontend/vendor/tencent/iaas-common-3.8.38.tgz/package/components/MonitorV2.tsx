/**
 * Monitor SDK 2.0 React组件包装，Tea2兼容模式
 * 
 * sdk项目： https://git.woa.com/CloudMonitorFrontend/tea-sdk-monitor
 * 
 * 从旧版升级过来要做的改造点：
 * 
 * 1. 需添加configId，查询方法参考以上链接
 * 2. metrics/dimensions字段废弃无用了
 */
import { app } from '@tencent/tea-app'
import * as React from 'react'
import { purify } from 'saga-duck'


interface Props<T> {
  options: MonitorOptions<T>
  loadingTip?: JSX.Element
  needRebuild?: (oldOptions: MonitorOptions<T>, newOptions: MonitorOptions<T>) => boolean | Promise<boolean>
}

export interface MonitorOptions<T> {
  regionId?: number
  data?: MonitorData<T>
  getData?: () => Promise<MonitorData<T>>
  namespace: string
  configId: string
  policyViewName?: string
  periods?: PERIOD[]
  metrics?: Metric<T>[] // deprecated
  dimensions?: (keyof T)[]
  isHideAddPolicy?: boolean
  metricExtend?: {
    // 该分组与接入配置的category不同，是用于把多个指标显示在一个图表中
    groups?:{
      // 用于显示图表的标题
      groupName: string,
      // 唯一确定一个分组。这里是任意规则，只要保持唯一就好
      groupId: string,
      //该分组包含的指标，配置指标的名称
      metrics:string[]
    }[],
    // 这里配置mini-dashboard不需要展示的指标
    hiddenMetrics?:string[]
     // 指定显示哪些指标，配置showMetrics后，hiddenMetrics参数不再生效。
    showMetrics?:string[]
    // 图表可视化配置项，可以定制图表的展示样式。采用数组是为了支持不同指标定制不同的样式
    chartOptions?: [{
      // 需要定制图例的指标名称。浏览器控制台/network/接口中DescribeDashboardMetrics查询对应的MetricName，也可以在接入系统中查询对应api指标名称。
      metrics?: string[],
      // 图例的配置项。total为true，代表显示求和
      legend?: {
        total?: boolean,
      }
    }],
    // 支持扩展视图，配置视图的策略id。指标展示的顺序，先展示外部configId所配置的主视图的指标，再一次展示扩展视图内的指标
    multipleViews?: { configId: string }[]
  }
  /** 用于指定滚动条所在的DOM节点，图表懒加载的时候使用。 */
  scrollDiv?: Element
}
interface MonitorData<T> {
  title?: string
  instances: T | T[]
}
export type PERIOD = 60 | 300 | 3600 | 86400
export interface Metric<T> {
  metricName: string
  metricCName?: string
  unit: string
  dimensions?: (keyof T)[]
}

// // 此方案在tea2下会报错，估计是因为React版本不同（SDK使用的是0.14）导致不兼容
// interface State<T> {
//   MonitorDetail: React.ComponentClass<MonitorOptions<T>>
// }

// @purify
// export default class Monitor<T> extends React.Component<Props<T>, State<T>> {
//   container: HTMLElement
//   state = {
//     MonitorDetail: null
//   }

//   componentDidMount() {
//     importer.ready().then(sdk => {
//       this.setState({
//         MonitorDetail: sdk.MonitorDetail
//       })
//       //   const { options } = this.props
//       //   sdk.MonitorDetailBuilder.build(options, this.container)
//     })
//   }

//   render() {
//     const { options } = this.props
//     const { MonitorDetail } = this.state
//     if (MonitorDetail) {
//       return <MonitorDetail {...options} />
//     }
//     return null
//     // return <div ref={container => (this.container = container)} />
//   }
// }


// 换用sdk build方法的方案，弊端是每次build都会unmount再mount，有一定开销
interface State {
  MonitorDetailBuilder: {
    build(options: MonitorOptions<any>, HTMLElement)
  }
}
@purify
export default class Monitor<T> extends React.Component<Props<T>, State> {
  container: HTMLElement
  curOptions = null
  state = {
    MonitorDetailBuilder: null
  }
  unmounted: boolean

  componentDidMount() {

    // monitor-v2-sdk，UI 和参数和之前都有一些变化
    // https://git.code.oa.com/CloudMonitorApp/tea-sdk-monitor
    let importer
    try{
      // TCS环境下，app.sdk.use就会报错
      importer = app.sdk.use('monitor-v2-sdk')
    }catch{
      importer = seajs.require('lib/monitor-sdk-importer').ready()
    }
    importer.then(sdk => {
      if (this.unmounted) {
        return
      }
      this.setState({
        MonitorDetailBuilder: sdk.MonitorDetailBuilder
      })
      this.updateMonitor()
    })
  }
  componentWillUnmount() {
    this.unmounted = true
  }

  async updateMonitor() {
    const { options, needRebuild } = this.props
    const { MonitorDetailBuilder } = this.state
    const rebuild = await needRebuild?.(this.curOptions,options)
    if (rebuild === false) return
    if (MonitorDetailBuilder && this.container) {
      // 这里sdk没有提供disposer功能，可能无法正常清理版本不同的React组件，造成内存泄漏
      MonitorDetailBuilder.build(options, this.container)
    }
  }

  render() {
    this.updateMonitor()
    return <div ref={container => (this.container = container)} >{this.props.loadingTip}</div>
  }
}
