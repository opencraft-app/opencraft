/**
 * tea2 版本 支持拖拽排序的 Table 组件
 * 相比tea1。不包含按钮，只是在Table的基础上多了拖动排序的功能
 */
import * as React from 'react'
import { Table, TableColumn, TableProps, Icon } from '@tencent/tea-component'

interface RecordItem {
  id: string
  [propName: string]: any
}

interface Props extends TableProps {
  // 组件是否处于拖动排序状态
  draggable: Boolean
  // 点击拖动时的回调
  onDragBegin?: () => void
  // 拖动结束的回调
  onDragEnd?: (record: any[]) => void
}

interface State {
  // 前一次外部传入的表格数据
  preRecords: RecordItem[]
  // 排序过程中间状态
  tempData: RecordItem[]
  // 是否正在拖拽过程中
  isDraging: Boolean
  // 拖拽开始时点击位置与元素上沿的偏差
  clickOffset?: number
  // 与屏幕左边距离
  leftOffset: number
  // 克隆列表行
  cloneTr
}

export default class SortGrid extends React.Component<Props, State> {
  state = (() => {
    return {
      preRecords: this.props.records,
      tempData: this.props.records,
      isDraging: false,
      clickOffset: null,
      leftOffset: null,
      cloneTr: null
    }
  })()

  static getDerivedStateFromProps(nextProps: Props, prevState: State) {
    const updateState: Partial<State> = {}
    if (prevState.preRecords !== nextProps.records) {
      updateState.preRecords = nextProps.records
      updateState.tempData = nextProps.records
    }
    return updateState
  }
  dragMaskContainer: HTMLElement = null

  tablePanelWrapper: HTMLElement = null

  dragStart(e, rowData: RecordItem) {
    // 防止事件重复触发
    if (this.state.isDraging) {
      return
    }
    e.preventDefault()

    // 获取被拖动的行
    let index: number = this.getRowIndex(rowData)
    if (index == -1) {
      return
    }
    let dragingData: RecordItem = this.state.tempData[index]
    dragingData.__isDraging = true
    let tempData: RecordItem[] = [].concat(this.state.tempData)
    tempData.splice(index, 1, dragingData)

    this.setState({ isDraging: true, tempData: tempData })

    // 克隆一个用于拖拽的元素
    let $targetTr = $(e.target).closest('tr')
    let $targetTable = $(e.target).closest('table')
    let $cloneTable = $targetTable.clone().removeAttr('data-reactid')
    let $cloneTr = $targetTr.clone().removeAttr('data-reactid')
    $cloneTr.find('*').removeAttr('data-reactid')
    $cloneTable.width($targetTable.width())
    // 为了保持列表样式，其实克隆了整个 table
    $cloneTable.find('tr').remove()
    $cloneTable.find('*').removeAttr('data-reactid')
    $cloneTable
      .find('tbody')
      // 列表行样式中只有底边框，所以额外插入一行，用于显示上边框
      .append(
        '<tr><td class="text-center" colspan="' +
          $cloneTr.children().length +
          '" style="padding:0;height:auto;line-height:0;"><span></span></td></tr>'
      )
      .append($cloneTr)

    // 计算点击位置与元素上沿的偏差
    let clickOffset = e.clientY - $targetTr.offset().top

    let clientY = e.clientY
    this.setState(
      {
        cloneTr: $cloneTable[0],
        leftOffset: $targetTr.offset().left,
        clickOffset
      },
      () => {
        $(this.dragMaskContainer).html(this.state.cloneTr)
        this.updateMask(clientY)
        $(document)
          .on('mouseup.sortGrid', e => {
            if (this.state.isDraging) {
              this.dragEnd(e)
            }
            $(document).off('.sortGrid')
            this.setState({ isDraging: false })
          })
          .on('mousemove.sortGrid', e => {
            if (this.state.isDraging) {
              this.dragMove(e)
            }
          })
      }
    )
  }
  dragEnd(e: JQuery.TriggeredEvent) {
    e.preventDefault()
    let tempData = this.state.tempData
    tempData = tempData.map(rowData => {
      if (rowData.__isDraging) {
        rowData.__isDraging = false
      }
      return rowData
    })
    if (typeof this.props.onDragEnd === 'function') {
      this.props.onDragEnd(this.state.tempData)
    }
    this.setState({ isDraging: false, tempData })
  }
  dragMove(e: JQuery.TriggeredEvent): void {
    e.preventDefault()
    this.updateMask(e.clientY)
    this.checkTrExChange(e.clientY)
  }
  // 更新拖动浮层
  updateMask(clientY: number): void {
    $(this.refs.dragMask).css({
      top: clientY - this.state.clickOffset,
      left: this.state.leftOffset
    })
  }
  // 检查是否需要交换位置
  checkTrExChange(clientY: number) {
    let dragingRowOffset = this.getDragingRowEdge()
    if (dragingRowOffset === null) {
      return null
    }
    let dragingIndex = this.getDragingRowIndex()
    if (clientY < dragingRowOffset.top) {
      if (dragingIndex - 1 < 0) {
        return
      }
      this.exchangeRowData(dragingIndex, dragingIndex - 1)
    }
    if (clientY > dragingRowOffset.bottom) {
      if (dragingIndex + 1 >= this.state.tempData.length) {
        return
      }
      this.exchangeRowData(dragingIndex, dragingIndex + 1)
    }
  }
  // 交换两行数据的位置
  exchangeRowData(index1: number, index2: number): void {
    let tempData = [...this.state.tempData]
    let row1 = tempData[index1]
    let row2 = tempData[index2]
    tempData[index1] = row2
    tempData[index2] = row1
    this.setState({ tempData })
  }

  // 获取被拖动元素在列表中占位行的边界
  getDragingRowEdge(): { top: number; bottom: number } {
    let $dragingRow = $(this.tablePanelWrapper).find('.SortGrid-draging-row')
    if (!$dragingRow.length) {
      return null
    }
    let top = $dragingRow.offset().top
    let bottom = top + $dragingRow.outerHeight()
    return { top, bottom }
  }
  // 查询数据在列表中的位置
  getRowIndex(rowData: RecordItem): number {
    let result = -1
    this.state.tempData.map((item, index) => {
      if (item.id == rowData.id) {
        result = index
      }
    })
    return result
  }
  // 查询正在拖拽的数据在列表内的索引
  getDragingRowIndex(): number {
    let result = -1
    this.state.tempData.map((item, index) => {
      if (item.__isDraging) {
        result = index
      }
    })
    return result
  }
  render(): JSX.Element {
    const tempColumns = (this.props.draggable
      ? [
          {
            key: '__drag',
            header: '',
            width: 50,
            render: x => (
              <div
                data-drag-handler
                onMouseDown={e => {
                  if (typeof this.props.onDragBegin === 'function') {
                    this.props.onDragBegin()
                  }
                  this.dragStart(e, x)
                }}
              >
                <Icon type="drop" />
              </div>
            )
          }
        ]
      : ([] as TableColumn<any>[])
    ).concat(this.props.columns)
    return this.props.draggable ? (
      <div
        className="SortGrid-wrapper"
        style={{
          position: 'relative'
        }}
        ref={node => (this.tablePanelWrapper = node)}
      >
        <style>
          {`.SortGrid-draging-row {
            visibility: hidden
          }`}
        </style>
        <Table
          {...this.props}
          columns={tempColumns}
          records={this.state.tempData}
          rowClassName={x => (x.__isDraging ? 'SortGrid-draging-row' : '')}
        />
        {this.state.isDraging ? (
          <div
            ref="dragMask"
            style={{
              position: 'fixed',
              zIndex: 9999,
              top: 0,
              left: 0
            }}
          >
            <div
              ref={node => (this.dragMaskContainer = node)}
              className="tc-15-table-box"
            />
          </div>
        ) : null}
      </div>
    ) : (
      <Table
        {...this.props}
        columns={tempColumns}
        records={this.state.tempData}
      />
    )
  }
}

// 测试/示例代码
if (process.env.NEVER_RUN) {
  const { scrollable, removeable } = Table.addons
  const Example = () => {
    const [records, setRecords] = React.useState<{ id: string }[]>([])
    return (
      <SortGrid
        addons={[
          scrollable({
            maxHeight: 400,
            minHeight: 400
          }),
          removeable({
            onRemove: key => {
              setRecords(records.filter(record => record.id !== key))
            }
          })
        ]}
        bordered={true}
        recordKey="id"
        columns={[]}
        records={records}
        onDragEnd={v => setRecords(v)}
        draggable={true}
      />
    )
  }
}
