// import {
//   ResourceSelectorGeneric as BaseSelector,
//   ResourceSelectorProps as BaseProps,
//   ResourceSelectorHead as BaseResourceSelectorHead,
//   ResourceSelectorInfoRow as BaseResourceSelectorInfoRow
// } from '@tencent/qcloud-component'

// import * as React from 'react'
// import * as ReactDOM from 'react-dom'
// import * as classnames from 'classnames'

// import { SearchBox, SearchBoxProps } from '@tencent/qcloud-component'
// import {
//   TablePanelGeneric,
//   TablePanelColumnGeneric,
//   TablePanelRecord,
//   TablePanelSortHeadCell
// } from '@tencent/qcloud-component'
// const TablePanel = TablePanelGeneric

// import {
//   BaseReactProps,
//   Identifiable,
//   createContainer,
//   uuid,
//   findById,
//   findChildren
// } from '@tencent/qcloud-lib'

// /**
//  * 保证 selection 保持与 records 有相同的偏序关系，查找插入位置
//  */
// function findInsertPosition<T extends Identifiable>(
//   records: T[],
//   selection: T[],
//   item: T
// ): number {
//   let ri: number = 0
//   let si: number = 0
//   while (records[ri] && selection[si]) {
//     if (records[ri].id == item.id) break
//     if (records[ri].id === selection[si].id) {
//       si++
//     }
//     ri++
//   }
//   return si
// }

// /**
//  * 插入到选区中，保持与 records 相同的偏序顺序
//  */
// function selectionInsert<T extends Identifiable>(
//   records: T[],
//   selection: T[],
//   item: T
// ): T[] {
//   selection = selection ? selection.slice() : []

//   let index = -1
//   for (let i = 0; i < selection.length; i++) {
//     if (selection[i].id === item.id) {
//       index = i
//       break
//     }
//   }

//   if (index === -1) {
//     const insertIndex = findInsertPosition(records, selection, item)
//     selection.splice(insertIndex, 0, item)
//   }

//   return selection
// }

// function selectionRemove<T extends Identifiable>(
//   records: T[],
//   selection: T[],
//   item: T
// ): T[] {
//   selection = selection.slice()
//   const index = selection.indexOf(item)

//   if (index > -1) {
//     selection.splice(index, 1)
//   }

//   return (selection || []).filter(x => x.id !== item.id)
// }

// export interface ResourceSelectorProps<TResource extends Identifiable>
//   extends BaseProps<TResource> {
//   selectionTitle: string | JSX.Element
//   /**
//    * 表格配置
//    */
//   columns?: any[]
//   topTip?: string | JSX.Element
//   recordDisabled?: (record) => boolean
// }

// interface StateProps {
//   [propName: string]: any
// }

// export class ResourceSelectorGeneric<
//   T extends Identifiable
// > extends React.Component<ResourceSelectorProps<T>, StateProps> {
//   private _secret = uuid()
//   private _shiftIndex
//   private _shiftKey = false
//   private _lastEnd
//   componentDidMount() {
//     let _root = this
//     if (this.refs.content) {
//       let table = ReactDOM.findDOMNode(this.refs.content)
//       $(table).on('mousedown', '.tc-15-table-fixed-body tr', function(e) {
//         _root._shiftKey = e.shiftKey
//         if (e.shiftKey && _root._shiftIndex !== undefined) {
//           _root.setState({
//             _userSelectNone: true
//           })
//         } else {
//           _root.setState({
//             _userSelectNone: false
//           })
//         }
//       })
//     }
//   }
//   constructor(props) {
//     super(props)
//   }
//   public render() {
//     const {
//       selectorTitle = '请选择',
//       selectionTitle = '已选择({selection.length})',
//       children,
//       search,
//       list,
//       selection,
//       columns,
//       topTip,
//       onSelectionChanged,
//       recordDisabled = item => !!item.disabled
//     } = this.props

//     let _root = this
//     const heads = findChildren(this.props.children, ResourceSelectorHead)
//     const infoRows = findChildren(this.props.children, ResourceSelectorInfoRow)
//     return (
//       <div className={classnames('tc-15-mod-selector', this.props.className)}>
//         {heads.map(head => (
//           <div key={head.key} className="tc-15-mod-selector-area">
//             {head}
//           </div>
//         ))}

//         <div className="tc-15-mod-selector-tb">
//           {/* left */}
//           <div className="tc-15-option-cell options-left">
//             <div className="tc-15-option-hd">
//               <h4>{selectorTitle}</h4>
//             </div>
//             <div className="tc-15-option-bd">
//               <SearchBox {...search} />
//               <div
//                 className="tc-15-option-box"
//                 ref={'optionBox'}
//                 style={{
//                   'user-select':
//                     this.state && this.state._userSelectNone ? 'none' : ''
//                 }}
//               >
//                 {columns && (
//                   <TablePanel
//                     ref="content"
//                     className="tc-15-option-list"
//                     onRowClick={(record: any, index) => {
//                       if (recordDisabled && recordDisabled(record)) {
//                         return
//                       }

//                       const selected = !findById(selection, record.id)
//                       let start, end
//                       let selects
//                       let unselects = []

//                       let {
//                         _shiftIndex = undefined,
//                         _lastEnd = undefined
//                       } = this

//                       if (
//                         this._shiftKey &&
//                         typeof _shiftIndex !== 'undefined'
//                       ) {
//                         if (_shiftIndex > index) {
//                           start = index
//                           end = _shiftIndex
//                           if (typeof _lastEnd !== 'undefined') {
//                             if (_lastEnd > _shiftIndex) {
//                               unselects = list.slice(
//                                 _shiftIndex + 1,
//                                 _lastEnd + 1
//                               )
//                             } else {
//                               unselects = list.slice(_lastEnd, start)
//                             }
//                           }
//                           this._lastEnd = start
//                         } else {
//                           //向后
//                           start = _shiftIndex
//                           end = index
//                           if (typeof _lastEnd !== 'undefined') {
//                             if (_lastEnd < _shiftIndex) {
//                               unselects = list.slice(_lastEnd, _shiftIndex)
//                             } else {
//                               unselects = list.slice(end + 1, _lastEnd + 1)
//                             }
//                           }
//                           this._lastEnd = end
//                         }
//                         selects = list.slice(start, end + 1)
//                         let _selection = selects.reduce(function(
//                           selection,
//                           item,
//                           i
//                         ) {
//                           if (!(recordDisabled && recordDisabled(item))) {
//                             return selectionInsert(list, selection, item)
//                           } else {
//                             return selection
//                           }
//                         },
//                         selection)

//                         var _unselects = []
//                         _selection = unselects.reduce(function(
//                           selection,
//                           item,
//                           i
//                         ) {
//                           if (!(recordDisabled && recordDisabled(item))) {
//                             // 去除不该选中的元素
//                             return selectionRemove(list, selection, item)
//                           } else {
//                             return selection
//                           }
//                         },
//                         _selection)

//                         onSelectionChanged(_selection)

//                         // _root.setState({
//                         //   _userSelectNone: false
//                         // })
//                       } else {
//                         let action = selected
//                           ? selectionInsert
//                           : selectionRemove

//                         if (selected) {
//                           this._shiftIndex = index
//                         } else {
//                           this._shiftIndex = undefined
//                         }
//                         this._lastEnd = undefined
//                         return onSelectionChanged(
//                           action(list, selection, record)
//                         )
//                       }
//                     }}
//                     columns={[
//                       {
//                         id: 'checker',
//                         checker: true,
//                         width: '35px',
//                         bodyCell: x => {
//                           let index = list
//                             .map(item => item.id)
//                             .indexOf(x && x.id)
//                           return (
//                             <div
//                               className="tc-15-first-checkbox"
//                               data-title={`${x.tips || ''}`}
//                             >
//                               <input
//                                 type="checkbox"
//                                 className="tc-15-checkbox"
//                                 checked={
//                                   selection
//                                     .map(item => item.id)
//                                     .indexOf(x && x.id) > -1
//                                 }
//                                 disabled={recordDisabled && recordDisabled(x)}
//                               />
//                             </div>
//                           )
//                         }
//                       }
//                     ].concat(columns)}
//                     records={list}
//                     recordDisabled={recordDisabled}
//                     minHeight={1}
//                     style={{ margin: 0 }}
//                     bodyStyle={{ borderBottom: 0 }}
//                     topTip={
//                       topTip != undefined ? (
//                         topTip
//                       ) : infoRows.length ? (
//                         <div>
//                           {infoRows.map(row => <div key={row.key}>{row}</div>)}
//                         </div>
//                       ) : null
//                     }
//                     selection={selection}
//                     onSelectionChange={onSelectionChanged}
//                   />
//                 )}
//                 {!columns &&
//                   infoRows.map(row => (
//                     <div key={row.key} className="info-row">
//                       {row}
//                     </div>
//                   ))}
//                 {!columns && (
//                   <ul className="tc-15-option-list">
//                     {list.map((x, index) => this._renderItem(x, index))}
//                   </ul>
//                 )}
//               </div>
//             </div>
//           </div>

//           {/* seperator */}
//           <div className="tc-15-option-cell separator-cell">
//             <i className="icon-sep" />
//           </div>

//           {/* right */}
//           <div className="tc-15-option-cell options-right">
//             <div className="tc-15-option-hd">
//               <h4>{selectionTitle}</h4>
//             </div>
//             <div className="tc-15-option-bd">
//               <div className="tc-15-option-box">
//                 {!columns &&
//                   !selection.length && (
//                     <ResourceSelectorInfoRow>暂未选择</ResourceSelectorInfoRow>
//                   )}
//                 {!columns && (
//                   <ul className="tc-15-option-list">
//                     {selection.map(x => this._renderSelectedItem(x))}
//                   </ul>
//                 )}
//                 {columns && (
//                   <TablePanel
//                     ref="selection"
//                     className="tc-15-option-list"
//                     columns={columns.concat([
//                       {
//                         id: 'del',
//                         headTitle: ' ',
//                         width: '35px',
//                         bodyCell: x => {
//                           return (
//                             <a
//                               href="javascript: void(0)"
//                               className="opt-act"
//                               role="button"
//                               title="取消"
//                               onClick={() => {
//                                 this._shiftIndex = undefined
//                                 this._shiftKey = false
//                                 this._lastEnd = undefined
//                                 this._checkItem(x, false)
//                               }}
//                             >
//                               <i className="icon-del">取消</i>
//                             </a>
//                           )
//                         }
//                       }
//                     ])}
//                     // minHeight={1}
//                     records={selection}
//                     style={{ margin: 0 }}
//                     bodyStyle={{ borderBottom: 0 }}
//                     topTip={selection && selection.length ? null : '暂未选择'}
//                   />
//                 )}
//               </div>
//             </div>
//           </div>
//         </div>

//         {columns && (
//           <div className="tc-15-mod-selector-tips">
//             支持按住 Shift 键进行多选
//           </div>
//         )}
//       </div>
//     )
//   }

//   private _renderItem(item: T, index: Number) {
//     const selected = !!findById(this.props.selection, item.id)
//     let disabledReason: any =
//       this.props.itemDisabled && this.props.itemDisabled(item)

//     if (disabledReason === true) {
//       disabledReason = '该项不可用'
//     }

//     return (
//       <li
//         key={item.id}
//         className={classnames({ selected })}
//         title={disabledReason || null}
//       >
//         <input
//           type="checkbox"
//           checked={selected}
//           className="tc-15-checkbox"
//           id={this._secret + item.id}
//           onChange={e => {
//             if (!disabledReason) {
//               this._checkItem(item, e.target.checked)
//             }
//           }}
//           disabled={!!disabledReason}
//         />
//         <label className="opt-txt" htmlFor={this._secret + item.id}>
//           {this._renderText(item)}
//         </label>
//       </li>
//     )
//   }

//   private _renderSelectedItem(item: T) {
//     return (
//       <li key={item.id}>
//         <span className="opt-txt">{this._renderText(item)}</span>
//         <a
//           href="javascript: void(0)"
//           className="opt-act"
//           role="button"
//           title="取消"
//           onClick={() => this._checkItem(item, false)}
//         >
//           <i className="icon-del">取消</i>
//         </a>
//       </li>
//     )
//   }

//   private _renderText(item: T) {
//     const { itemNameRender, itemDescriptionRender } = this.props
//     const name = itemNameRender(item)
//     const desc = itemDescriptionRender && itemDescriptionRender(item)
//     return (
//       <span className="opt-txt-inner">
//         <span className="item-name">{name}</span>
//         {desc && <span className="item-descr">{desc}</span>}
//       </span>
//     )
//   }

//   private _checkItem(item: T, checked: boolean) {
//     const operation = checked ? selectionInsert : selectionRemove
//     const nextSelection = operation(this.props.list, this.props.selection, item)

//     this.props.onSelectionChanged(nextSelection)
//   }
// }

// export function ResourceSelectorHead(props: BaseReactProps) {
//   return BaseResourceSelectorHead(props)
// }

// export function ResourceSelectorInfoRow(props: BaseReactProps) {
//   return BaseResourceSelectorInfoRow(props)
//   // return <div>{props.children}</div>
// }
