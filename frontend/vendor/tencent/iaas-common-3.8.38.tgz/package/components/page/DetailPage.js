/**
 * 控制台通用列表页
 */
import * as React from 'react'
const router = seajs.require('router')

import { Layout } from "@tea/component/layout";
const { Body, Content } = Layout;

export default class DetailPage extends React.Component {
  //回退的时候首先尝试浏览器回退, 否则使用备用的 url 跳转
  back() {
    const { backUrl } = this.props
    if (history.length > 1) {
      history.back()
    } else {
      router.navigate(backUrl)
    }
  }
  render() {
    const { title, showBackButton, children, backUrl, ...rest } = this.props

    return (
      <Layout>
        <Body>
          <Content>
            <Content.Header
              showBackButton
              onBackButtonClick={this.back.bind(this)}
              title={title}
              {...rest}
            />
            <Content.Body>
              {children}
            </Content.Body>
          </Content>
         </Body>
       </Layout>
    );
  }
}
