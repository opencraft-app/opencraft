/**
 * 控制台通用列表页
 */
import * as React from 'react'

import RegionBar from '../region/RegionBar'
import ProjectDropdown from '../project/ProjectDropdown'

import {
  Table,
  Pagination,
  SearchBox,
  ContentView,
  Justify,
  Card
} from '@tencent/tea-component'

export default class GridPage extends React.Component {
  render() {
    const {
      actions,
      currentRegion,
      currentProject,
      showAllProject,
      full
    } = this.props
    return (
      <ContentView>
        <ContentView.Header>
          {this.props.header ? (
            this.props.header
          ) : (
            <Justify
              left={
                <React.Fragment>
                  <h2>{this.props.title}</h2>
                  {this.props.project && (
                    <ProjectDropdown
                      selected={currentProject}
                      onSelect={actions.changeProject}
                      onLoaded={actions.projectListLoaded}
                      showAll={showAllProject}
                    />
                  )}

                  {this.props.region && (
                    <RegionBar
                      selected={currentRegion}
                      onSelect={actions.changeRegion}
                      onReady={() => {
                        actions.changeRegion(currentRegion)
                      }}
                    />
                  )}
                </React.Fragment>
              }
              right={
                this.props.help && (
                  <div className="manage-area-title-right">
                    <a href={this.props.help.link} target="_blank">
                      <b className="links-icon" />
                      {this.props.help.text}
                    </a>
                  </div>
                )
              }
            />
          )}
        </ContentView.Header>
        {this.props.tipsContent}
        <ContentView.Body full={full}>
          {this.props.content || this.props.children}
        </ContentView.Body>
      </ContentView>
    )
  }
}
