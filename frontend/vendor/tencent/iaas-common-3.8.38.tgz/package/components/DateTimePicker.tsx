import * as React from 'react'
import * as moment from 'moment'
import { Moment, DurationInputArg2 } from 'moment'
import { DatePicker, Segment } from '@tencent/tea-component'
import { t } from '@tencent/tea-app/lib/i18n'
import { RangePickerProps } from '@tencent/tea-component/lib/datepicker/RangePicker'

const { RangePicker } = DatePicker

interface TabItem {
  text?: string
  range: [Moment, Moment]
}

interface Props
  extends Pick<
    RangePickerProps,
    'showTime' | 'defaultValue' | 'value' | 'range'
  > {
  tabs?: Array<TabItem>
  onChange: (value: [Moment, Moment]) => void
  defaultTabIndex?: number
  /**
   * 默认单位为天，在时间对比的时候会用到
   * @default day
   */
  unit?: DurationInputArg2
  /**是否需要实时获取时间 */
  needRealTime?: boolean

  // Segement 和 RangePicker 是否有间隙, 为了创建模拟包含时间选择的 Segment
  // 默认是有间隙
  segAndRangeGap?: boolean
}

export default class DateTimePicker extends React.Component<Props, any> {
  state = {
    segmentOptions: [],
    rangeMap: {},
    segmentValue: ''
  }

  static defaultProps = {
    unit: 'day',
    needRealTime: false
  }

  constructor(props) {
    super(props)
  }

  componentWillMount() {
    this.parseTabs()
  }

  parseTabs = (tabIndex?: string) => {
    let tabs = this.props.tabs
    if (!tabs) {
      tabs = [
        {
          text: t('实时'),
          range: [moment().subtract(1, 'h'), moment()]
        },
        {
          text: t('近24小时'),
          range: [moment().subtract(1, 'd'), moment()]
        },
        {
          text: t('近7天'),
          range: [moment().subtract(7, 'd'), moment()]
        }
      ]
    }

    let labelTextArr = tabs.map(item => item.text)
    let rangeArr = tabs.map(item => item.range)

    let segmentOptions = labelTextArr.map((text, index) => ({
      text,
      value: index.toString()
    }))

    let rangeMap = rangeArr.reduce((obj, cur, index) => {
      obj[index] = cur
      return obj
    }, {})

    this.setState(
      {
        segmentOptions,
        rangeMap
      },
      () => {
        if (typeof tabIndex !== 'undefined') {
          this.setState({
            segmentValue: tabIndex.toString()
          })

          this.setRangeValue(tabIndex)
        } else if (typeof this.props.defaultTabIndex !== 'undefined') {
          this.setState({
            segmentValue: this.props.defaultTabIndex.toString()
          })

          this.setRangeValue(this.props.defaultTabIndex)
        }
      }
    )
  }

  setSegmentValue = value => {
    this.setState({
      segmentValue: value
    })
  }

  getSegmentValue = dates => {
    const [start, end] = dates
    const { unit } = this.props
    return Object.entries(this.state.rangeMap).reduce((prev, cur) => {
      const [key, range] = cur
      if (start.isSame(range[0], unit) && end.isSame(range[1], unit)) {
        return key
      }
      return prev
    }, null)
  }

  setRangeValue = val => {
    this.props.onChange(this.state.rangeMap[val])
  }

  render() {
    const {
      segAndRangeGap: needGap = true
    } = this.props
  
    return (
      <React.Fragment>
        <Segment
          value={this.state.segmentValue}
          options={this.state.segmentOptions}
          onChange={value => {
            this.props.needRealTime && this.parseTabs(value)
            this.setSegmentValue(value)
            this.setRangeValue(value)
          }}
          style={{
            marginRight: needGap ? 10 : -1
          }}
        />
        <RangePicker
          range={this.props.range}
          value={this.props.value}
          defaultValue={this.props.defaultValue}
          showTime={this.props.showTime}
          onChange={value => {
            this.props.onChange(value)
            this.setSegmentValue(this.getSegmentValue(value))
          }}
        />
      </React.Fragment>
    )
  }
}
