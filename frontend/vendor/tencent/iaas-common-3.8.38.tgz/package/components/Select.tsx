import * as React from 'react'
import * as classnames from 'classnames'
import { Select as TeaSelect, SimulateSelectProps } from '@tencent/tea-component'

type Value = string | number
export interface Item {
  value: string | number
  text: string
  disabled?: boolean
  title?: string
}

export interface Props<T extends Value = Value>
  extends Omit<SimulateSelectProps, 'options' | 'value' | 'onChange'> {
  /** @deprecated 不再能指定type，强制为simulate */
  type?: string
  list: Item[]
  value: T
  onChange: (v: T) => any
}
export default function <T extends Value>(props: Props<T>) {
  const { type, list, value, onChange, ...rest } = props

  return (
    <TeaSelect
      type='simulate'
      appearance='button'
      boxSizeSync
      matchButtonWidth
      options={list.map(o => {
        const value = String(o.value)
        return {
          value,
          text: o.text,
          disabled: o.disabled,
          tooltip: o.title
        }
      })}
      value={String(value)}
      onChange={v => {
        // 进行类型转换
        let changedValue: Value = v
        if (typeof value === 'number') {
          changedValue = +changedValue
        }
        onChange(changedValue as T)
      }}
      {...rest}
    />
  )
}
