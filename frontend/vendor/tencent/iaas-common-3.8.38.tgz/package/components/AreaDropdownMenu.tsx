/**
 * 分类下拉选择器
 * author yuemingliu
 */

import * as React from 'react'
import { t } from '@tencent/tea-app/lib/i18n'

interface State {
  // 当前选中的 id
  selected: string[]
}

interface listItem {
  label: string
  id: string
  disable: boolean
  selected: boolean
}

interface Props {
  // 是否允许多选
  multipleSelect: Boolean
  // 可选元素列表
  list: {
    [groupName: string]: listItem[]
  }
  onChange(selected: string[])
}

export default class AreaDropdownMenu extends React.Component<Props, State> {
  onSelectItem(e) {
    if (this.state.selected.length && this.props.multipleSelect) {
      // 多选
    } else {
      // 单选
    }
  }
  renderGroup(itemGroup: listItem[], groupName: string) {
    return [
      <p className="text-weak">{groupName}</p>,
      <ul className="area-list">
        {itemGroup.map(item => (
          <li
            onClick={this.onSelectItem}
            className={item.selected ? 'cur' : ''}
          >
            <a>{item.label}</a>
          </li>
        ))}
      </ul>
    ]
  }
  render() {
    return (
      <div className="tc-15-dropdown tc-15-dropdown-btn-style tc-15-menu-active">
        <a className="tc-15-dropdown-link" href="javascript:void(0);">
          <em>{t('请选择')}</em>
          <i className="caret" />
        </a>
        <div className="tc-15-dropdown-menu area-dropdown-menu">
          {Object.keys(this.props.list).map(key =>
            this.renderGroup(this.props.list[key], key)
          )}
        </div>
      </div>
    )
  }
}
