import * as React from 'react';
import * as csvUtil from './csv';
import { t } from '@tencent/tea-app/lib/i18n';
import { Button } from '@tencent/tea-component';

const tips: any = seajs.require('tips');

/**
 * 导出单个表格数据
 */
export interface ExportTableProps<T> {
  columns: Array<{
    name: string;
    key: string;
    renderer?: (val: string, item: T) => string;
  }>; // 导出文件的表头
  fileName: string; // 导出文件名
  getExportData: () => Promise<T[]>; // 导出文件的数据源
}

/**
 * 导出多个表格数据
 */
export interface BatchExportTableProps<T> {
  batchColumns: Array<
    Array<{
      name: string;
      key: string;
      renderer?: (val: string, item: T) => string;
    }>
  >; // 导出文件的表头
  fileNames: (string | any)[];
  getExportDatas: (() => Promise<T[]>)[];
}

export default class ExportTable<T> extends React.Component<
  ExportTableProps<T> | BatchExportTableProps<T>
> {
  constructor(props) {
    super(props);
  }
  async exportTableData({ columns, fileName, exportData }) {
    let exceed;
    // 是否尝试导出失败
    let tried = false;
    // 目前导出的文件数
    let fileNum = 0;
    // 已成功导出数
    let exported = 0;
    // 上次导出失败的位置
    let lastTry;
    do {
      // 本次尝试范围，默认导出乘下的所有，失败时减少导出量重试
      const thisTry = lastTry
        ? Math.floor((lastTry - exported) / 1.5) + exported
        : exportData.length;
      const content = csvUtil.format(
        exportData.slice(exported, thisTry),
        columns
      );
      exceed = csvUtil.save(fileName, content, false);
      if (exceed) {
        lastTry = thisTry;
      } else {
        fileNum++;
        exported = thisTry;
        lastTry = null;
      }
      tried = true;
    } while (exceed || exported < exportData.length);

    if (fileNum > 1) {
      tips.flash(t('因文件过大，自动拆分为多个文件下载'));
    } else {
      tips.success(t('导出成功'));
    }
  }

  render() {
    const { columns, fileName, getExportData } = this.props as ExportTableProps<
      T
    >;
    const { batchColumns, fileNames, getExportDatas } = this
      .props as BatchExportTableProps<T>;

    // 优先支持单个文件的导出
    if (getExportData) {
      return (
        <Button
          icon="download"
          title={t('下载')}
          onClick={async () => {
            const exportData = await getExportData();

            this.exportTableData({ columns, fileName, exportData });
          }}
        />
      );
    }

    if (getExportDatas) {
      return (
        <Button
          icon="download"
          title={t('下载')}
          onClick={() =>
            getExportDatas.forEach(async (getExportDataItem, index) => {
              const exportData = await getExportDataItem();

              this.exportTableData({
                columns: batchColumns[index],
                fileName: fileNames[index],
                exportData
              });
            })
          }
        />
      );
    }
  }
}
