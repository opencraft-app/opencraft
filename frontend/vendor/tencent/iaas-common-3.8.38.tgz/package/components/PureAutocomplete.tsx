import * as React from 'react'
import * as ReactDom from 'react-dom'
import * as classnames from 'classnames'
// import OnOuterClick from 'common/helpers/onOuterClick'
import { Popover, DropdownBox } from '@tencent/tea-component'
import { Text, Icon, List } from '@tencent/tea-component'
import { purify } from 'saga-duck'
import { t, Trans } from '@tencent/tea-app/lib/i18n'
import { withConfig, WithConfigProps } from '@tencent/tea-component/lib/util'
// 怎么说呢 现有的autocomplete不支持按键选择，原有的的autocomplete使用了旧的forminput以及classname

/**
 * 自动填充数据源的格式如下
 *
 * @interface DataSourceItem
 */
interface DataSourceItem {
  text: string
  value: string | number
}

interface AutoCompleteSelectorProps extends BaseReactProps {
  /**
   * 自动填充数据源
   *
   * @type {Array<DataSourceItem>}
   * @memberof AutoCompleteSelectorProps
   */
  dataSource: Array<DataSourceItem>

  /**
   * 某个补全项被选中的回调
   *
   * @param {DataSourceItem} item
   * @memberof AutoCompleteSelectorProps
   */
  onItemSelect?: (item: DataSourceItem) => void

  /**
   * 输入框输入值的回调
   *
   * @param {string} item
   * @memberof AutoCompleteSelectorProps
   */
  onChange?: (item: string) => {}

  /**
   * 失去焦点的回调
   *
   * @memberof AutoCompleteSelectorProps
   */
  onBlur?: () => {}

  /**
   * 禁用
   *
   * @type {boolean}
   * @memberof AutoCompleteSelectorProps
   */
  disabled?: boolean

  /**
   * 是否需要button
   *
   * @type {boolean}
   * @memberof AutoCompleteSelectorProps
   */
  hasButton?: boolean

  /**
   * 文本框的提示文字
   *
   * @type {string}
   * @memberof AutoCompleteSelectorProps
   */
  placeholder?: string

  addon?: JSX.Element

  /**
   * 展示错误
   *
   * @type {boolean}
   * @memberof AutoCompleteSelectorProps
   */
  showErrors?: boolean

  /**
   * 错误是否放在前面
   *
   * @type {boolean}
   * @memberof AutoCompleteSelectorProps
   */
  errorBefore?: boolean

  /**
   * 提示文字
   *
   * @type {string}
   * @memberof AutoCompleteSelectorProps
   */
  defaultPrompt?: string

  /**
   * 外壳的类名
   *
   * @type {string}
   * @memberof AutoCompleteSelectorProps
   */
  wrapClass?: string

  /**
   * 外壳的样式
   *
   * @type {React.CSSProperties}
   * @memberof AutoCompleteSelectorProps
   */
  style?: React.CSSProperties

  /**
   * 用户设定的默认index
   *
   * @type {number}
   * @memberof AutoCompleteSelectorProps
   */
  defaultIndex?: number

  /**
   * 受控组件, 外部传入的value值
   *
   * @type {number}
   * @memberof AutoCompleteSelectorProps
   */
  value?: string | number

  /**
   * 当用户设定默认index后进行的回调操作
   *
   * @param {DataSourceItem} item
   * @memberof AutoCompleteSelectorProps
   */
  setInitialValue?: (item: DataSourceItem) => {}
}

interface AutoCompleteSelectorState {
  /**
   * 列表是否展示
   *
   * @type {boolean}
   * @memberof AutoCompleteSelectorState
   */
  isOpened?: boolean

  /**
   * 是否在输入中，这个决定是用表单的值，还是state的值
   *
   * @type {boolean}
   * @memberof AutoCompleteSelectorState
   */
  isInputing?: boolean

  /**
   * 这个还是需要的，不过只在输入的时候才会展示
   *
   * @type {string}
   * @memberof AutoCompleteSelectorState
   */
  value?: string

  /**
   * 当前展示的列表的数据源
   *
   * @type {Array<DataSourceItem>}
   * @memberof AutoCompleteSelectorState
   */
  filterList?: Array<DataSourceItem>

  /**
   * 当前focus的列表项的下标
   *
   * @type {number}
   * @memberof AutoCompleteSelectorState
   */
  focusIndex?: number
}

@withConfig
export default class AutoCompleteSelector extends React.Component<
  AutoCompleteSelectorProps & WithConfigProps,
  AutoCompleteSelectorState
> {
  state: AutoCompleteSelectorState = {
    isOpened: false,
    isInputing: false,
    value: '',
    filterList: [],
    focusIndex: -1
  }

  input: HTMLElement
  overlayRef: any
  childrenRef: any

  constructor(props) {
    super(props)

    this.close = this.close.bind(this)

    this.overlayRef = React.createRef() as any
    this.childrenRef = React.createRef() as any
  }

  open = () => {
    this.setState({
      isOpened: true,
      isInputing: true,
      filterList: this.props.dataSource,
      focusIndex: -1,
      value: this.getSelectedLabel() // 打开时初始默认值为当前选中的值
    })
  }

  close() {
    this.setState({
      isOpened: false,
      isInputing: false
    })
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.dataSource !== this.props.dataSource) {
      this.setState({
        filterList: nextProps.dataSource
      })
    }
  }

  /**
   * 自动补全的选项被选中的监听
   *
   * @param {*} item
   * @param {*} e
   * @memberof FormInputAutoComplete
   */
  onItemSelect = item => {
    if (this.props.disabled) return
    // 关闭弹层
    this.close()
    // 将选中的值传出去
    this.props.onItemSelect && this.props.onItemSelect(item)
  }

  /**
   * 用户设定默认index后的监听
   *
   * @param {*} item
   * @param {*} e
   * @memberof FormInputAutoComplete
   */
  setInitialValue(item) {
    //将默认的值传出去
    this.props.setInitialValue && this.props.setInitialValue(item)
  }

  /**
   * 下拉收缩按钮的监听
   *
   * @memberof FormInputAutoComplete
   */
  onButtonClick() {
    if (this.props.disabled) return
    this.setState({
      isOpened: !this.state.isOpened,
      isInputing: false,
      filterList: this.props.dataSource,
      focusIndex: -1
    })
  }

  /**
   *  输入框的输入值的回调
   *
   * @param {*} e
   * @memberof FormInputAutoComplete
   */
  onInput = e => {
    const { dataSource, disabled } = this.props

    if (disabled) return

    const filterList = dataSource.filter(item => {
      const { text: label } = item
      const matched = label.indexOf(e.target.value) !== -1
      return matched
    })

    this.setState({
      isInputing: true,
      value: e.target.value,
      filterList,
      focusIndex: -1
    })
  }

  /**
   *  失去焦点的时候，选择原来的值
   *
   * @param {*} selectValue
   * @param {*} e
   * @memberof FormInputAutoComplete
   */
  onBlur(selectValue, e) {}

  /**
   *
   *
   * @param {*} e
   * @memberof AutoCompleteSelector
   */
  onKeyDown = e => {
    const keyCode = e.keyCode

    const KEYCODE = {
      ENTER: 13,
      UP: 38,
      DOWN: 40
    }

    let { focusIndex, filterList } = this.state

    if (keyCode === KEYCODE.UP) {
      focusIndex = focusIndex - 1 < 0 ? filterList.length - 1 : focusIndex - 1
    }
    if (keyCode === KEYCODE.DOWN) {
      focusIndex = focusIndex + 1 >= filterList.length ? 0 : focusIndex + 1
    }

    if (keyCode === KEYCODE.UP || keyCode === KEYCODE.DOWN) {
      this.setState(
        {
          focusIndex
        },
        () => {
          let menuItem: Element = document.querySelector(
            `.menu-item-${focusIndex}`
          )
          // 滚动到可视区域
          menuItem && menuItem.scrollIntoView()
        }
      )
    }

    if (keyCode === KEYCODE.ENTER) {
      this.onItemSelect(filterList[focusIndex])
      this.input.blur()
    }
  }

  highlight(text: React.ReactNode, keyword: string): React.ReactNode {
    if (typeof text !== 'string') {
      return text
    }
    return text.split(keyword).map((text, index) => {
      const key = `${text}-${index}`
      if (index >= 1) {
        return (
          <React.Fragment key={key}>
            <Text theme={index === 1 ? 'primary' : 'text'}>{keyword}</Text>
            {text}
          </React.Fragment>
        )
      }
      return <Text key={key}>{text}</Text>
    })
  }

  getSelectedLabel = () => {
    if (this.props.value) {
      let item = this.props.dataSource.find(
        item => item.value === this.props.value
      )

      if (!item) {
        return `${this.props.value}${t('不存在于列表中, 请重新选择')}`
      }

      return item.text
    } else if (typeof this.props.defaultIndex !== 'undefined') {
      let item = this.props.dataSource[this.props.defaultIndex]

      return (item && item.text) || t('无')
    } else {
      return t('无')
    }
  }

  componentDidMount() {
    // 自己写事件监听器吧, 嘤嘤嘤
    document.addEventListener('mousedown', this.mousedownListener)
  }

  mousedownListener = evt => {
    const domRefs = [this.overlayRef, this.childrenRef]

    for (let domRef of domRefs) {
      if (domRef.current && domRef.current.contains(evt.target as Node)) {
        return
      }
    }

    // 调用close
    this.close()
  }

  componentWillUnmount() {
    // 移除事件监听器
    document.removeEventListener('mousedown', this.mousedownListener)
  }

  render() {
    const {
      dataSource: options,
      placeholder,
      addon,
      value: propsValue,
      style
    } = this.props
    const { filterList, focusIndex, value, isOpened, isInputing } = this.state

    const selectedLabel = this.getSelectedLabel()
    const {
      config: { classPrefix }
    } = this.props

    return (
      <Popover
        placement="bottom-start"
        visible={isOpened}
        placementOffset={5}
        overlay={
          <DropdownBox>
            <div ref={this.overlayRef}>
              <List type="option">
                {Array.isArray(filterList) && filterList.length > 0 ? (
                  filterList.map((item, index) => {
                    let { value: optValue, text } = item
                    return (
                      <li
                        style={style}
                        key={optValue}
                        className={classnames(`menu-item-${index}`, {
                          'is-current':
                            optValue === propsValue || focusIndex === index
                        })}
                        onClick={event => {
                          event.stopPropagation()
                          this.onItemSelect(item)
                        }}
                      >
                        {this.highlight(text || optValue.toString(), value)}
                      </li>
                    )
                  })
                ) : (
                  <List.Item>{t('无相关搜索内容')}</List.Item>
                )}
              </List>
            </div>
          </DropdownBox>
        }
      >
        <div className={`${classPrefix}-input-group`} ref={this.childrenRef}>
          <input
            ref={input => (this.input = input)}
            className={`${classPrefix}-input`}
            onKeyDown={this.onKeyDown}
            placeholder={placeholder}
            onChange={this.onInput}
            onClick={this.open}
            value={isInputing ? value : selectedLabel}
            title={isInputing ? value : selectedLabel}
          />
          {addon && (
            <div className={`${classPrefix}-input-group__addon`}>
              <Icon type="arrowdown" />
            </div>
          )}
        </div>
      </Popover>
    )
  }
}
