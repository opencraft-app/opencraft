import React from 'react'
import { Bubble } from '@tencent/tea-component'
import { Icon } from '@tencent/tea-component'

export default function HelpBubble(props) {
  const { title = '', text = '', position = 'top', content, ...rest } = props
  return (
    <div {...rest}>
      {title + ' '}
      <Bubble
        placement={position}
        content={
          content ? (
            content
          ) : (
            <p
              style={{ fontWeight: 'normal' }}
              dangerouslySetInnerHTML={{ __html: text }}
            />
          )
        }
      >
        <Icon type="help" />
      </Bubble>
    </div>
  )
}
