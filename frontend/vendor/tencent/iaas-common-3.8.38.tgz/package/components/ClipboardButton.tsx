/**
 * 如果存在clipboard未正常引入的问题，可以在页面入口添加依赖
 * requires: ['clipboard']
 */
import * as React from 'react'
import { t, Trans } from '@tencent/tea-app/lib/i18n'

const tips = seajs.require('tips')
;(seajs as any).use('clipboard')

interface Props {
  options?: any
  type?: string
  className?: string
  style?: React.CSSProperties
  component?: string
  onClick?: React.MouseEventHandler
  children?: string | number | JSX.Element | JSX.Element[]
}
export default class ClipboardButton extends React.Component<Props, any> {
  clipboard: any
  static defaultProps = {
    onClick: function(e) {
      e.stopPropagation()
      return false
    },
    onSuccess: function() {
      tips.success(t('复制成功'))
    },
    onError: function(e) {
      tips.error(
        t('当前浏览器不支持一键复制，请选中文本后用 Ctrl + C 快捷键进行复制')
      )
      console.warn(e)
    }
  }

  /* Returns a object with all props that fulfill a certain naming pattern
   *
   * @param {RegExp} regexp - Regular expression representing which pattern
   *                          you'll be searching for.
   * @param {Boolean} remove - Determines if the regular expression should be
   *                           removed when transmitting the key from the props
   *                           to the new object.
   *
   * e.g:
   *
   * // Considering:
   * // this.props = {option-foo: 1, onBar: 2, data-foobar: 3 data-baz: 4};
   *
   * // *RegExps not using // so that this comment doesn't break up
   * this.propsWith(option-*, true); // returns {foo: 1}
   * this.propsWith(on*, true); // returns {Bar: 2}
   * this.propsWith(data-*); // returns {data-foobar: 1, data-baz: 4}
   */
  propsWith(regexp, remove = false) {
    const object = {}

    Object.keys(this.props).forEach(function(key) {
      if (key.search(regexp) !== -1) {
        const objectKey = remove ? key.replace(regexp, '') : key
        object[objectKey] = this.props[key]
      }
    }, this)

    return object
  }

  componentWillUnmount() {
    this.clipboard && this.clipboard.destroy()
  }

  componentDidMount() {
    // Support old API by trying to assign this.props.options first;
    const options = this.props.options || this.propsWith(/^option-/, true)
    const element = this.refs.element
    const Clipboard = seajs.require('clipboard')
    this.clipboard = new Clipboard(element, options)

    const callbacks = this.propsWith(/^on/, true)
    Object.keys(callbacks).forEach(function(callback) {
      this.clipboard.on(callback.toLowerCase(), this.props['on' + callback])
    }, this)
  }

  render() {
    const attributes = {
      type: this.getType(),
      className: this.props.className || 'copy-icon',
      style: this.props.style || { cursor: 'pointer' },
      ref: 'element',
      title: t('点击复制'),
      onClick: this.props.onClick,
      ...this.propsWith(/^data-/),
      ...this.propsWith(/^button-/, true)
    }

    return React.createElement(
      this.getComponent(),
      attributes,
      this.props.children
    )
  }

  getType() {
    if (this.getComponent() === 'button' || this.getComponent() === 'input') {
      return this.props.type || 'button'
    } else {
      return undefined
    }
  }

  getComponent() {
    return this.props.component || 'button'
  }
}
