import * as React from 'react'
const router = seajs.require('router')
import { t } from '@tencent/tea-app/lib/i18n'
export interface BackHrefProps extends BaseReactProps {
  /**跳转链接 */
  backUrl?: string

  /**链接跳转方式 */
  target?: string

  /**是否显示 */
  isShow?: boolean

  /**是否可用 */
  disabled?: boolean
}

export default class BackHref extends React.Component<BackHrefProps, void> {
  _OnBack = () => {
    const { backUrl } = this.props
    if (history.length > 1) {
      history.back()
    } else if (backUrl) {
      router.navigate(backUrl)
    }
  }
  render() {
    let {
      backUrl,
      target,
      className,
      style,
      isShow = true,
      disabled = false
    } = this.props

    return isShow ? (
      <a
        href="javascript:;"
        className={`back-link ${className}`}
        onClick={!disabled ? this._OnBack : null}
        style={style}
        target={target}
      >
        <i className="btn-back-icon" />
        {t('返回')}
      </a>
    ) : (
      <noscript />
    )
  }
}
