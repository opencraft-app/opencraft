/**
 * Monitor SDK React组件包装，Tea2兼容模式
 */
import * as React from 'react'
import { purify } from 'saga-duck'

const importer = seajs.require('lib/monitor-sdk-importer')

interface Props<T> {
  options: MonitorOptions<T>
}

export interface MonitorOptions<T> {
  regionId?: number
  data?: MonitorData<T>
  getData?: () => Promise<MonitorData<T>>
  namespace: string
  periods?: PERIOD[]
  metrics: Metric<T>[]
  dimensions?: (keyof T)[]
  isHideAddPolicy?: boolean
}
interface MonitorData<T> {
  instance: T
}
export type PERIOD = 60 | 300 | 3600 | 86400
export interface Metric<T> {
  metricName: string
  metricCName?: string
  unit: string
  dimensions?: (keyof T)[]
}

// // 此方案在tea2下会报错，估计是因为React版本不同（SDK使用的是0.14）导致不兼容
// interface State<T> {
//   MonitorDetail: React.ComponentClass<MonitorOptions<T>>
// }

// @purify
// export default class Monitor<T> extends React.Component<Props<T>, State<T>> {
//   container: HTMLElement
//   state = {
//     MonitorDetail: null
//   }

//   componentDidMount() {
//     importer.ready().then(sdk => {
//       this.setState({
//         MonitorDetail: sdk.MonitorDetail
//       })
//       //   const { options } = this.props
//       //   sdk.MonitorDetailBuilder.build(options, this.container)
//     })
//   }

//   render() {
//     const { options } = this.props
//     const { MonitorDetail } = this.state
//     if (MonitorDetail) {
//       return <MonitorDetail {...options} />
//     }
//     return null
//     // return <div ref={container => (this.container = container)} />
//   }
// }

// 换用sdk build方法的方案，弊端是每次build都会unmount再mount，有一定开销
interface State {
  MonitorDetailBuilder: {
    build(options: MonitorOptions<any>, HTMLElement)
  }
}
@purify
export default class Monitor<T> extends React.Component<Props<T>, State> {
  container: HTMLElement
  state = {
    MonitorDetailBuilder: null
  }
  unmounted: boolean

  componentDidMount() {
    importer.ready().then(sdk => {
      if (this.unmounted) {
        return
      }
      this.setState({
        MonitorDetailBuilder: sdk.MonitorDetailBuilder
      })
      this.updateMonitor()
    })
  }
  componentWillUnmount() {
    this.unmounted = true
  }

  updateMonitor() {
    const { options } = this.props
    const { MonitorDetailBuilder } = this.state
    if (MonitorDetailBuilder && this.container) {
      // 这里sdk没有提供disposer功能，可能无法正常清理版本不同的React组件，造成内存泄漏
      MonitorDetailBuilder.build(options, this.container)
    }
  }

  render() {
    this.updateMonitor()
    return <div ref={container => (this.container = container)} />
  }
}
