import * as React from 'react'
import * as classnames from 'classnames'
import OnOuterClick from '../helpers/onOuterClick'
import { t, Trans } from '@tencent/tea-app/lib/i18n'

export interface DropdownListItem {
  /**
   * 列表项的标识，在同一个列表中不允许重复
   */
  id: string | number

  /**
   * 列表显示的标签，可以为字符串或者是特定 React Element
   */
  label?: string | JSX.Element

  /**
   * 列表是否被禁用，默认为 false
   */
  disabled?: boolean
}

export interface DropdownListProps extends BaseReactProps {
  /**
   * 是否模拟为 select 组件，默认为 false
   * */
  simulateSelect?: boolean

  /**
   * 外观主题：
   *   - `select` （默认）表示渲染为类似 select 组件的下拉框
   *   - `dropdown` 表示渲染为弹出菜单
   *   - `dropdown-hd` 表示渲染为标题使用的弹出菜单
   */
  theme?: 'select' | 'dropdown' | 'dropdown-hd' | 'dropdown-new'

  /**
   * 是否使用小尺寸，默认为 false
   */
  smallSize?: boolean

  /**
   * 按钮最大宽度，可以给数字（单位：px）或者 CSS 字符串值，默认为空，不限制最大宽度
   */
  buttonMaxWidth?: number | string
  buttonMinWidth?: number | string

  /**
   * 菜单最大宽度，可以给数字（单位：px）或者 CSS 字符串值，默认为空，不限制最大宽度
   */
  menuMaxWidth?: number | string

  /**
   * 菜单最大高度，可以给数字（单位：px）或者 CSS 字符串值，默认为空，不限制最大高度
   */
  menuMaxHeight?: number | string

  /**
   * 弹出方向：
   *   - `down` (默认) 从下方弹出
   *   - `up` 从上方弹出
   */
  popDirection?: 'down' | 'up'

  /** 下拉按钮的样式设置 */
  buttonClassName?: string

  /** 下拉浮层的样式设置 */
  menuWrapClassName?: string

  /** 下拉菜单的样式设置 */
  meunClassName?: string

  /**
   * 下拉组件的标签，simulateSelect 为 false 的时候生效
   * */
  placeholder?: string | JSX.Element

  /**
   * 下拉显示的项目列表
   * */
  items?: DropdownListItem[]

  /**
   * 当前选中的项目
   */
  selected?: DropdownListItem

  /**
   * 下拉项被选中的时候
   */
  onSelect?: (item: DropdownListItem) => void

  /**
   * 是否禁用下拉组件
   */
  disabled?: boolean

  /** 是否可搜索（本地搜索），默认false */
  searchable?: boolean
  searchPlaceholder?: string
  emptyTips?: string | JSX.Element | JSX.Element[]
  wrapperStyle?: React.CSSProperties
}

interface StyleClassConfig {
  className: string
  activeClassName?: string
  buttonClassName: string
  buttonActiveClassName?: string
  menuWrapClassName?: string
  menuClassName: string
  menuItemSelectedClassName: string
  triggerMenuDisplay?: boolean
  upClassName?: string
}

type StyleClassConfigMap = {
  [theme: string]: StyleClassConfig
}

const styleClassConfigMap: StyleClassConfigMap = {
  select: {
    className: 'tc-15-simulate-select-wrap',
    activeClassName: 'show',
    buttonClassName: 'tc-15-simulate-select',
    buttonActiveClassName: 'show',
    menuClassName: 'tc-15-simulate-option',
    menuItemSelectedClassName: 'selected',
    upClassName: '',
    triggerMenuDisplay: true
  },
  dropdown: {
    className: 'tc-15-dropdown',
    buttonClassName: 'tc-15-dropdown-link',
    activeClassName: 'tc-15-menu-active',
    buttonActiveClassName: 'active',
    menuClassName: 'tc-15-dropdown-menu',
    menuItemSelectedClassName: 'selected',
    upClassName: 'tc-15-dropup'
  },
  'dropdown-hd': {
    className: 'tc-15-dropdown tc-15-dropdown-in-hd',
    buttonClassName: 'tc-15-dropdown-link',
    activeClassName: 'tc-15-menu-active',
    buttonActiveClassName: 'active',
    menuClassName: 'tc-15-dropdown-menu',
    menuItemSelectedClassName: 'selected',
    upClassName: 'tc-15-dropup'
  },
  'dropdown-new': {
    className: 'tc-15-dropdown',
    buttonClassName: 'tc-15-dropdown-link',
    activeClassName: 'tc-15-menu-active',
    buttonActiveClassName: 'active',
    menuWrapClassName: 'dropdown-list-wrap',
    menuClassName: 'tc-15-dropdown-menu',
    menuItemSelectedClassName: 'selected',
    upClassName: 'tc-15-dropup'
  }
}

export interface DropdownListState {
  /**
   * 当前是否为打开状态
   */
  isOpened?: boolean
  /** 当前搜索关键字 */
  keyword?: string
}

export default class DropdownList extends React.Component<
  DropdownListProps,
  DropdownListState
> {
  private _documentClickHandler: (e: MouseEvent) => void

  state = {
    isOpened: false,
    keyword: ''
  }

  private _handleButtonClick(e: React.MouseEvent) {
    if (!this.props.disabled) {
      this.setState({
        isOpened: !this.state.isOpened
      })
      e.stopPropagation()
    }
  }

  private _handleItemClick(item: DropdownListItem, e: React.MouseEvent) {
    if (!item.disabled) {
      this.select(item)
    }
    this.close()
    e.stopPropagation()
  }

  public select(item: DropdownListItem) {
    var selectedIndex = this.props.items.indexOf(item)
    if (this.props.onSelect) {
      this.props.onSelect(selectedIndex > -1 ? item : null)
    }
  }

  public open() {
    if (!this.props.disabled) {
      this.setState({ isOpened: true })
    }
  }

  @OnOuterClick
  public close() {
    this.setState({ isOpened: false })
  }

  /** 根据关键字过滤列表，外界可覆盖 */
  public filterItem(item: DropdownListItem, keyword: string) {
    return keyword ? String(item.label).indexOf(keyword) >= 0 : true
  }

  public render() {
    const {
      selected,
      buttonMaxWidth,
      buttonMinWidth,
      menuMaxWidth,
      menuMaxHeight,
      disabled,
      searchable,
      searchPlaceholder = t('请输入关键字'),
      emptyTips = t('无搜索结果'),
      wrapperStyle
    } = this.props
    const { isOpened, keyword } = this.state
    const {
      items = [],
      simulateSelect = false,
      placeholder = t('请选择'),
      theme,
      popDirection,
      smallSize
    } = this.props

    let filteredItems = items
    if (keyword) {
      filteredItems = filteredItems.filter(o => this.filterItem(o, keyword))
    }

    const classConfig =
      styleClassConfigMap[theme] || styleClassConfigMap['select']

    const className = classnames(classConfig.className, this.props.className, {
      [classConfig.activeClassName]: isOpened,
      [classConfig.upClassName]: popDirection === 'up',
      m: smallSize,
      disabled
    })
    const buttonClassName = classnames(
      classConfig.buttonClassName,
      this.props.buttonClassName,
      { [classConfig.buttonActiveClassName]: isOpened, m: smallSize }
    )
    const menuWrapClassName = classnames(
      classConfig.menuWrapClassName,
      this.props.menuWrapClassName
    )
    const menuClassName = classnames(
      classConfig.menuClassName,
      this.props.meunClassName
    )

    const buttonContent =
      (simulateSelect && selected && selected.label) || placeholder

    const itemsBody = filteredItems.map(item => (
      <li
        role="presentation"
        className={classnames({
          disabled: item.disabled,
          [classConfig.menuItemSelectedClassName]: item === selected
        })}
        key={item.id}
        onClick={e => this._handleItemClick(item, e)}
        title={typeof item.label == 'string' ? item.label : null}
      >
        <a
          role="menuitem"
          style={{ cursor: item.disabled ? 'not-allowed' : 'pointer' }}
          className={classnames({
            [classConfig.menuItemSelectedClassName]: item === selected
          })}
        >
          {item.label}
        </a>
      </li>
    ))

    //let wrapperStyle: React.CSSProperties = {}

    let buttonStyle: React.CSSProperties = {
      display: 'inline-block',
      cursor: disabled ? 'not-allowed' : 'pointer',
      color: disabled ? '#999' : null,
      backgroundColor: 'white'
    }
    if (buttonMinWidth) {
      buttonStyle = Object.assign(buttonStyle, {
        minWidth: buttonMinWidth
      })
    }
    if (buttonMaxWidth) {
      buttonStyle = Object.assign(buttonStyle, {
        maxWidth: buttonMaxWidth,
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap'
      })
    }

    let menuStyle: React.CSSProperties = {
      maxWidth: menuMaxWidth,
      maxHeight: menuMaxHeight,
      overflow: 'auto'
    }
    if (classConfig.triggerMenuDisplay) {
      menuStyle.display = isOpened ? 'block' : 'none'
    }

    return (
      <div className={className} style={wrapperStyle}>
        <a
          style={buttonStyle}
          className={buttonClassName}
          onClick={this._handleButtonClick.bind(this)}
          title={typeof buttonContent == 'string' ? buttonContent : null}
        >
          {buttonContent}
          <i className="caret" />
        </a>
        <div className={menuWrapClassName}>
          {searchable && (
            <div className="search-box search-box-simple m">
              <div className="search-input-wrap">
                <input
                  className="tc-15-input-text search-input"
                  placeholder={searchPlaceholder}
                  onChange={e => this.setState({ keyword: e.target.value })}
                  defaultValue={this.state.keyword}
                />
              </div>
              <input
                className="search-btn"
                type="button"
                defaultValue={t('搜索')}
              />
            </div>
          )}
          <ul key="menu" className={menuClassName} style={menuStyle}>
            {(!filteredItems || !filteredItems.length) && (
              <li role="presentation" className="disabled">
                <a role="menuitem">{emptyTips}</a>
              </li>
            )}
            {Array.isArray(filteredItems) &&
              filteredItems.length > 0 &&
              itemsBody}
          </ul>
        </div>
      </div>
    )
  }
}

DropdownList['defaultLabelAlign'] = 'middle'
