/**
 * 简单版用于进行 CIDR 输入的受控组件
 * 输入范围会被限制在 CIDRLimit 这个 CIDR 内部
 * author yuemingliu
 */
import React, { useState, useEffect, Fragment } from 'react'
import { Bubble, Input, useConfig } from '@tencent/tea-component'
import { t } from '@tencent/tea-app/lib/i18n'

const appUtil = seajs.require('appUtil') as any

// IP 输入组件
export default function CIDRInput(props: {
  initValue?: string // 初始值，VPC要求子网CIDR依据VPC CIDR初始化，传入VPC IP的初始值即可
  CIDRLimit: string // CIDR 可输入的范围
  value: string // 当前值
  startValidate?: boolean
  isError?: boolean
  onchange(cidr: string) // 输入值改变
  maxMask?: number // 掩码最大值
  minMask?: number // 掩码最小值
}) {
  const {
    initValue,
    CIDRLimit,
    value,
    startValidate,
    isError,
    onchange,
    maxMask = 28,
    minMask
  } = props

  if (!CIDRLimit) {
    return null
  }
  const CIDRLimitIP = CIDRLimit.split('/')[0]
  const CIDRLimitMask = Number(CIDRLimit.split('/')[1])
  // 没有合法的 CIDR 输入
  if (!appUtil.isValidCIDR(CIDRLimitIP, CIDRLimitMask)) {
    return null
  }

  // 掩码最小值
  const minOption = minMask ? Math.max(minMask, CIDRLimitMask) : CIDRLimitMask

  // 确定掩码范围
  const optionMask = [...Array(maxMask - minOption + 1)].map(
    (_, index) => index + minOption
  )

  // 当前值如果设置有问题，使用 CIDRLimit 的值代替
  let currentIP = null
  let currentMask = null
  if (!value) {
    currentIP = CIDRLimitIP
    currentMask =
      (initValue && subnetCidrHandler(Number(initValue.split('/')[1]))) ||
      minOption
    updateCIDR({
      IP: currentIP,
      mask: currentMask
    })
  } else {
    currentIP = value.split('/')[0]
    currentMask = Number(value.split('/')[1])
    if (
      value &&
      (!currentIP ||
        !currentMask ||
        isNaN(currentMask) ||
        currentMask > maxMask ||
        currentMask < minOption)
    ) {
      currentIP = CIDRLimitIP
      currentMask = minOption
    }
  }

  function updateCIDR(data: { IP?: string; mask? }) {
    const { IP, mask } = data
    onchange(`${IP || currentIP}/${mask || currentMask}`)
  }

  // VPC CIDR的掩码为12-23时，子网CIDR掩码默认为24
  // VPC CIDR的掩码>=24时，子网CIDR掩码默认为“VPC掩码+1”. （如vpc为24，则子网为25.）
  function subnetCidrHandler(val: number): number {
    if (val) {
      if (val >= 12 && val <= 23) return 24
      else if (val >= 24) return val + 1
      else return val
    }
    return val
  }

  const { classPrefix } = useConfig()
  return (
    <em
      className={
        'vpc-ip-input' + (isError ? ` ${classPrefix}-text-danger` : '')
      }
    >
      {currentIP.split('.').map((val, index) => {
        return (
          <Fragment key={index}>
            <IPSegment
              editable={
                (index + 1) * 8 > CIDRLimitMask &&
                index * 8 < currentMask &&
                currentMask > CIDRLimitMask
              }
              val={val || '0'}
              IPSegmentLimit={CIDRLimitIP.split('.')[index]}
              mask={currentMask - index * 8 > 8 ? 8 : currentMask - index * 8}
              IPSegmentLimitMask={
                CIDRLimitMask - index * 8 > 0 ? CIDRLimitMask - index * 8 : 0
              }
              onchange={val => {
                const newIP = currentIP.split('.')
                newIP.splice(index, 1, val)
                updateCIDR({ IP: newIP.join('.') })
              }}
              startValidate={startValidate}
            />
            <span>{index == 3 ? ' / ' : ' . '}</span>
          </Fragment>
        )
      })}
      <select
        className={`${classPrefix}-select`}
        style={{ width: '55px' }}
        value={currentMask || minOption}
        onChange={e => {
          const val = e.target.value
          updateCIDR({ mask: val })
        }}
      >
        {optionMask.map(val => {
          return <option key={val} value={val}>{val}</option>
        })}
      </select>
    </em>
  )
}

// IP 输入中的一段
function IPSegment(props: {
  editable: boolean
  val: string // 当前值
  mask: number // 一个 IP 段上的掩码
  IPSegmentLimit: string // CIDR 范围限制
  IPSegmentLimitMask: number // CIDR 范围限制的掩码
  startValidate?: boolean // 是否校验标红
  onchange?
}) {
  const {
    editable,
    val,
    mask,
    onchange,
    IPSegmentLimit,
    IPSegmentLimitMask
  } = props

  const [isLegal, setIsLegal] = useState(true)

  if (editable) {
    // 计算 IP 段可选范围
    const { range, rangeDesc, step } = getRage(
      mask,
      IPSegmentLimit,
      IPSegmentLimitMask
    )
    return (
      <em className={props.startValidate && !isLegal ? 'is-error' : ''}>
        <Bubble content={rangeDesc}>
          <Input
            value={val}
            style={{
              width: '45px',
              textAlign: 'center'
            }}
            onChange={val => {
              if (typeof onchange != 'function') {
                return
              }

              // 允许输入框放空
              if (val === '') {
                onchange(val)
                setIsLegal(false)
                return
              }
              // 必须是大于 0 的数字
              const num = Number(val)
              if (isNaN(num) || num < 0) {
                return
              }
              // 如果超出 range 的最大值，强行设置到最大值
              if (num > range[range.length - 1]) {
                onchange(String(range[range.length - 1]))
                setIsLegal(true)
                return
              }
              onchange(String(num))
              setIsLegal(range.includes(num))
            }}
          />
        </Bubble>
      </em>
    )
  } else {
    return <em>{val}</em>
  }
}
IPSegment.prototype.isLegal = function () {}

// 计算 IP 段可选范围
function getRage(
  /**
   * eg: ipSegment 128, ipSegmentMask 2, mask 4
   *
   *  1 0 0 0 0 0 0 0 ipSegment
   * |---|            ipSegmentMask
   * |-------|        mask
   *     |---|        window
   *
   * 这种情况下可选范围就是变动中间 2 位
   * range 中会有 4 个元素，step 为 2^(8-mask)
   */

  mask: number, // 当前掩码
  ipSegment: string, // 限制网段 IP
  ipSegmentMask: number // 限制网段掩码
): { range: number[]; step: number; rangeDesc: string } {
  const windowLength = mask - ipSegmentMask

  const step = 1 << (8 - mask)
  const range = [...Array(1 << windowLength)].map((_, index) => {
    return Number(ipSegment) + (index << (8 - mask))
  })

  let rangeDesc = t('范围：')
  if (step == 1) {
    // 步长为 1 的时候直接展示 a-b
    rangeDesc += `${range[0]}-${range[range.length - 1]}`
  } else if (range.length > 4) {
    // 步长不为 1 且可选值大于 4 个，展示 a1,a2,...,aN
    rangeDesc += `${range[0]},${range[1]},...,${range[range.length - 1]}`
  } else {
    // 可选值少于 4 个，全部显示
    rangeDesc += range.join(',')
  }

  return {
    range,
    step,
    rangeDesc
  }
}
