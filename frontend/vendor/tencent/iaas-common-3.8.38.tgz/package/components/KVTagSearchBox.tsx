import * as React from 'react'
import { TagSearchBox } from '@tencent/tea-component'
import { AttributeValue } from '@tencent/tea-component/lib/tagsearchbox/AttributeSelect'
import { TagValue as BaseTagValue } from '@tencent/tea-component/lib/tagsearchbox/Tag'
import { TagSearchBoxProps } from '@tencent/tea-component/lib/tagsearchbox/TagSearchBox'
import * as deepEqual from 'fast-deep-equal'
import { purify } from 'saga-duck'

interface KVTagSearchBoxOptions<T> {
  /** 支持的标签搜索类型 */
  attributes: KVAttribute<T>[]
  /** 是否自动填充默认值，默认为true */
  fillDefaults?: boolean
  /**
   * 是否开启 aaa|bbb 形式的文本转为数组的支持，默认不开启
   * 如果不开启，文本将原样传递，例如： "aaa|bbb"；
   * 如果开启，则所有input类型的标签value会变为数组，例如： ["aaa", "bbb"]
   */
  multipleText?: boolean
  /**
   * 默认key，如果用户没有选任何标签直接输入文本，则会使用此属性，注意只能是input类型
   *
   * 默认为keyword
   *
   * 注：如果需要始终展示为无类型的文本，请将defaultKey对应的attribute.name设置为空，
   * 否则会自动添加对应attribute的类型标签（例如： test => 关键字:test ）
   */
  defaultKey?: string | ((text: string) => keyof T)
}
export interface Props<T>
  extends KVTagSearchBoxOptions<T>,
    Omit<
      TagSearchBoxProps,
      'value' | 'onChange' | 'attributes' | 'defaultValue'
    > {
  value: T
  /** 当值变化时调用 */
  onChange: (value: T) => any
}

/**
 * 封装tea的TagSearchBox组件，主要有以下处理：
 * - 将value与attributes分离开，value不再是包含attributes的结构，而是数据对象
 * - input默认关闭多选项输入，防止不支持多关键字搜索的功能受到影响
 */
export default purify(function KVTagSearchBox<T>(props: Props<T>) {
  const {
    attributes,
    value,
    onChange,
    fillDefaults,
    multipleText,
    defaultKey,
    ...rest
  } = props
  // 处理values为async异步加载的情况
  const computedAttributes = useAttributes(attributes)
  const adapter: Adapter<T> = React.useMemo(() => new Adapter(), [])

  const options = React.useMemo(() => {
    return {
      attributes: computedAttributes,
      fillDefaults: fillDefaults !== false,
      multipleText: multipleText === true,
      defaultKey: defaultKey || 'keyword'
    }
  }, [computedAttributes, props])

  const computedValue = React.useMemo(() => {
    return adapter.encode(value, options)
  }, [adapter, options, value])

  const wrappedOnChange = React.useMemo(() => {
    return value => onChange(adapter.decode(value, options))
  }, [onChange, adapter, options])

  return (
    <TagSearchBox
      attributes={computedAttributes}
      value={computedValue}
      onChange={wrappedOnChange}
      {...rest}
    />
  )
})

function useAttributes<T>(attributes: KVAttribute<T>[]) {
  const [computedAttributes, setAttributes] = React.useState<KVAttribute<T>[]>(
    []
  )
  // 处理Attributes异步逻辑
  React.useEffect(() => {
    let running = true
    // 如果有属性为异步，先设置一个空列表，加载完后再更新回来
    const intialAttributes = (attributes || [])
      // 没有name的类型不展示
      .filter(o => o.name)
      .map((attr, index) => {
        if (typeof attr.values === 'function') {
          const loadingAttr = Object.assign({}, attr, {
            values: []
          })

          const loadingTask = attr.values()
          Promise.resolve(loadingTask).then(v => {
            // 防止串任务
            if (!running) {
              return
            }
            setAttributes(prev => {
              const cur = prev.slice(0)
              cur[index] = Object.assign({}, attr, {
                values: v
              })
              return cur
            })
          })

          return loadingAttr
        }
        return attr
      })
    setAttributes(intialAttributes)

    return () => {
      running = false
    }
  }, [attributes])

  return computedAttributes
}

/**
 * TagSearchBox的值是与UI强相关的，使用时不太方便，这里进行转换，映射成{key: value}形式的值
 */
class Adapter<T> {
  private orderMap = new Map<string, number>()
  /** 将Values的值转换为TagSearchBox组件识别的数组式value */
  encode(v: T, options: KVTagSearchBoxOptions<T>) {
    return options.attributes
      .map(attr => {
        if (!(attr.key in v)) {
          return null
        }
        let value: any = v[attr.key]
        if (
          value === null ||
          value === undefined ||
          value === attr.defaults ||
          deepEqual(value, attr.defaults)
        ) {
          return null
        }
        if (attr?.encode) {
          return {
            attr: attr,
            values: attr.encode(value)
          }
        }
        // 前面已经把异步任务放在KV组件层进行了处理，所以这里直接计算即可
        let list = attr.values as any[]
        var values
        const type =
          Object.prototype.toString.call(attr.type) == '[object Array]'
            ? attr.type[0]
            : attr.type
        switch (type) {
          case 'input':
            if (!(options.multipleText || attr.multipleText)) {
              value = value.split(TEXT_SPLITER)
            }
            values = value.map(o => ({ name: o }))

            break
          case 'single':
            values = list
              ? list.filter(function (o) {
                  return o.key === value
                })
              : []
            break
          case 'multiple':
            values = list
              ? list.filter(function (o) {
                  return value.indexOf(o.key) >= 0
                })
              : []
            break
        }
        if (!values) {
          values = [
            {
              key: value,
              name: value
            }
          ]
        }
        return {
          attr: attr,
          values: values
        }
      })
      .filter(function (o) {
        return o
      })
      .sort((a, b) => {
        return (
          this.orderMap.get(a.attr.key) - this.orderMap.get(b.attr.key) || 0
        )
      })
  }
  /** 将TagSearchBox的值转为Values对象 */
  decode(v: TagValue[], options: KVTagSearchBoxOptions<T>): T {
    this.orderMap.clear()
    const map = {} as T
    if (v) {
      v.forEach((o, index) => {
        let attr = o.attr
        if (!attr) {
          if (typeof options.defaultKey === 'function') {
            const key = options.defaultKey(o.values?.[0]?.name)
            // 有些input是开启了数组选项的，这里要处理一下
            attr = options.attributes.find(a => a.key === key)
          } else {
            attr = {
              type: 'input',
              key: options.defaultKey,
              name: '',
              defaults: ''
            }
          }
        }
        if (attr?.decode) {
          map[attr.key] = attr.decode(o)
        } else {
          var values = o.values
          var value
          const type =
            Object.prototype.toString.call(attr.type) == '[object Array]'
              ? attr.type[0]
              : attr.type
          switch (type) {
            case 'input':
              value = values.map(o => o.name)
              if (!(options.multipleText || attr.multipleText)) {
                value = value.join(TEXT_SPLITER)
              }
              break
            case 'single':
              value = values[0].key
              break
            case 'multiple':
              value = values.map(function (o) {
                return o.key
              })
              break
          }
          this.orderMap.set(attr.key, index)
          map[attr.key] = value
        }
      })
    }
    if (options.fillDefaults !== false) {
      options.attributes.forEach(attr => {
        if (!(attr.key in map)) {
          map[attr.key] = attr.defaults
        }
      })
    }
    return map
  }
}

export interface KVAttribute<T, K extends Extract<keyof T, string> = any>
  extends AttributeValue {
  key: K
  /** 默认值，重置、删除时的值 */
  defaults: T[K]
  /** 是否在列表的搜索条件中展示，默认为true */
  searchNotify?: boolean
  /** 自定义列表的搜索条件展示的标签，如不指定则为attribute.name */
  searchLabel?: string
  /**
   * 是否开启 aaa|bbb 形式的文本转为数组的支持，默认不开启
   * 如果不开启，文本将原样传递，例如： "aaa|bbb"；
   * 如果开启，则input类型的标签value会变为数组，例如： ["aaa", "bbb"]
   */
  multipleText?: boolean
  /** 当在Grid搜索条件中展示时，该如何格式化 */
  format?(v: T[K]): string
  encode?(v: T[K]): string
  decode?(v: TagValue): T[K]
}

interface TagValue extends BaseTagValue {
  attr?: KVAttribute<any>
}

// ------------- 以下方法为Grid搜索条件展示与清空相关逻辑 --------------
/** 将标签搜索框的值序列化为字符串，展示在Grid中 */
export function stringify<T>(values: T, attributes: KVAttribute<T>[]): string {
  return attributes
    .filter(a => {
      return (
        a.searchNotify !== false &&
        a.key in values &&
        a.defaults !== values[a.key] &&
        !deepEqual(a.defaults, values[a.key])
      )
    })
    .map(a => {
      const value = values[a.key]
      const label = 'searchLabel' in a ? a.searchLabel : a.name
      const text = a.format ? a.format(value) : value
      return label ? `${label}:${text}` : text
    })
    .join('、')
}

/** 清空标签搜索框的值（只清空展示在Grid中的部分） */
export function reset<T>(values: T, attributes: KVAttribute<T>[]): T {
  const result = Object.assign({}, values)
  attributes
    .filter(a => a.searchNotify !== false)
    .forEach(a => {
      result[a.key] = a.defaults
    })
  return result
}

// TagSearchBox对于多段文本使用的分隔符
const TEXT_SPLITER = '|'
