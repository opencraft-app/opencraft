import * as React from 'react'
import classnames from 'classnames'

import FormField from '../formField'
import FormPrompt from '../formPrompt'
import { buildHandler } from './util'

function isNumeric(n) {
  return !isNaN(parseFloat(n)) && isFinite(n)
}

export default function InputNum({
  field,
  defaultPrompt = '',
  showErrors = true,
  errorBefore,
  isForm,
  className,
  addon,
  onChange,
  onBlur,
  noTouch = false,
  children
}) {
  return (
    <FormField field={field}>
      {({ setValue, getValue, setTouched, getTouched, getError }) => {
        const showAnyErrors =
          showErrors && (isForm ? getTouched() === true : true)
        const classes = classnames(
          'tc-15-input-num',
          {
            'is-error':
              !errorBefore && showAnyErrors && getTouched() && getError()
          },
          className
        )
        const value = getValue('')
        const minusClass = classnames('minus', {
          disabled: value == 1
        })
        const minus = () => {
          if (value == 0 || !isNumeric(value)) {
            return
          }
          setValue(Number(value) - 1, noTouch)
        }
        const plus = () => {
          if (!isNumeric(value)) {
            return
          }
          setValue(Number(value) + 1, noTouch)
        }
        return (
          <span className={classes}>
            <span
              className={minusClass}
              tabIndex={0}
              role="button"
              onClick={minus}
            >
              -
            </span>
            <input
              type="text"
              className="num"
              value={value}
              onChange={buildHandler(onChange, e =>
                setValue(e.target.value, noTouch)
              )}
              onBlur={buildHandler(onBlur, () => setTouched())}
            />
            <span className="plus" tabIndex={0} role="button" onClick={plus}>
              +
            </span>
            {addon}
            <FormPrompt field={field} defaultPrompt={defaultPrompt} />
          </span>
        )
      }}
    </FormField>
  )
}
