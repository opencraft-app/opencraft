import * as React from 'react'
import { buildHandler } from './util'
import classnames from 'classnames'
import FormField from '../formField'
import { t, Trans } from '@tencent/tea-app/lib/i18n';

export default function FormInputSelectGroup({
  options1,
  field1,
  onChange1,
  onBlur1,
  options2,
  field2,
  onChange2,
  onBlur2,
  needBlank = true,
  children,
  defaultPrompt,
  noTouch,
  ...rest
}) {
  const renderSelect = (field, options, onChange, onBlur) => {
    options = options || []
    return (
      <FormField field={field}>
        {({ setValue, getValue, setTouched }) => {
          let resolvedOptions
          if (needBlank) {
            resolvedOptions = options.find(d => d.value === '')
              ? options
              : [
                  {
                    label: t('请选择...'),
                    value: '',
                    disabled: true
                  },
                  ...options
                ]
          } else {
            resolvedOptions = options
          }
          const selectedIndex = resolvedOptions.findIndex(
            d => d.value === getValue()
          )
          const nullIndex = resolvedOptions.findIndex(d => d.value === '')
          return (
            <select
              {...rest}
              onChange={buildHandler(onChange, e => {
                const val = resolvedOptions[e.target.value].value
                setValue(val, noTouch)
              })}
              onBlur={buildHandler(onBlur, () => setTouched())}
              value={selectedIndex > -1 ? selectedIndex : nullIndex}
              className="tc-15-select m"
              style={{ marginRight: '5px', display: 'inline-block' }}
            >
              {resolvedOptions.map((option, i) => {
                return (
                  <option key={i} value={i} disabled={option.disabled}>
                    {option.label}
                  </option>
                )
              })}
            </select>
          )
        }}
      </FormField>
    )
  }
  return (
    <FormField>
      {({ ...api }) => {
        const error = api.getError(field1) || api.getError(field2)
        const classes = classnames('form-unit', {
          'is-error': error
        })
        const prompt = error || defaultPrompt
        return (
          <div className={classes}>
            {renderSelect(field1, options1, onChange1, onBlur1)}
            {renderSelect(field2, options2, onChange2, onBlur2)}{children()}
            <p className="form-input-help">{prompt}</p>
          </div>
        )
      }}
    </FormField>
  )
}
