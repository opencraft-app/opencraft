import * as React from 'react'
import { buildHandler } from './util'
import FormInput from '../formInput'
import { t, Trans } from '@tencent/tea-app/lib/i18n';

export default function FormInputSelect({
  options,
  field,
  needBlank = true,
  showErrors,
  errorBefore,
  onChange,
  onBlur,
  isForm,
  noTouch,
  wrapClass,
  defaultPrompt,
  children,
  ...rest
}: any) {
  return (
    <FormInput
      {...{
        field,
        showErrors,
        errorBefore,
        isForm,
        defaultPrompt,
        className: wrapClass,
        otherChild: children
      }}
    >
      {({ setValue, getValue, setTouched }) => {
        let resolvedOptions
        if (needBlank) {
          resolvedOptions = options.find(d => d.value === '')
            ? options
            : [
                {
                  label: t('请选择...'),
                  value: '',
                  disabled: true
                },
                ...options
              ]
        } else {
          resolvedOptions = options
        }
        const selectedIndex = resolvedOptions.findIndex(
          d => d.value === getValue()
        )
        const nullIndex = resolvedOptions.findIndex(d => d.value === '')
        return (
          <select
            {...rest}
            onChange={buildHandler(onChange, e => {
              const val = resolvedOptions[e.target.value].value
              setValue(val, noTouch)
            })}
            onBlur={buildHandler(onBlur, () => setTouched())}
            value={selectedIndex > -1 ? selectedIndex : nullIndex}
          >
            {resolvedOptions.map((option, i) => {
              return (
                <option key={i} value={i} disabled={option.disabled}>
                  {option.label}
                </option>
              )
            })}
          </select>
        )
      }}
    </FormInput>
  )
}
