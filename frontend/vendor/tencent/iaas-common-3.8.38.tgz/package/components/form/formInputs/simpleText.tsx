import * as React from 'react'
//
import { buildHandler } from './util'
import FormField from '../formField'

export default function FormInputText({
  field,
  onChange,
  onBlur,
  noTouch = false,
  ...rest
}) {
  return (
    <FormField field={field}>
      {({ setValue, getValue, setTouched }) => {
        return (
          <input
            {...rest}
            value={getValue('')}
            onChange={buildHandler(onChange, e =>
              setValue(e.target.value, noTouch)
            )}
            onBlur={buildHandler(onBlur, () => setTouched())}
          />
        )
      }}
    </FormField>
  )
}
