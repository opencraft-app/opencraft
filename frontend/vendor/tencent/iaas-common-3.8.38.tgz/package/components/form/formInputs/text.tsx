import * as React from 'react'
//
import { buildHandler } from './util'
import FormInput from '../formInput'

export default function FormInputText({
  field,
  addon,
  defaultPrompt,
  showErrors,
  errorBefore,
  onChange,
  onBlur,
  isForm,
  noTouch,
  wrapClass,
  ...rest
}: any) {
  return (
    <FormInput
      {...{
        field,
        addon,
        defaultPrompt,
        showErrors,
        errorBefore,
        isForm,
        className: wrapClass
      }}
    >
      {({ setValue, getValue, setTouched }) => {
        return (
          <input
            {...rest}
            value={getValue('')}
            onChange={buildHandler(onChange, e =>
              setValue(e.target.value, noTouch)
            )}
            onBlur={buildHandler(onBlur, () => setTouched())}
          />
        )
      }}
    </FormInput>
  )
}
