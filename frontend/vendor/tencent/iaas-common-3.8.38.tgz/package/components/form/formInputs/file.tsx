import * as React from 'react'
import classnames from 'classnames'
import { buildHandler } from './util'
import FormField from '../formField'
import FormPrompt from '../formPrompt'
import { t, Trans } from '@tencent/tea-app/lib/i18n';


export default function FormFile({
  field,
  defaultPrompt = '',
  className,
  onChange,
  onBlur,
  showErrors = true,
  errorBefore,
  isForm,
  children
}) {
  return (
    <FormField field={field}>
      {({ ...api }) => {
        const uploadFile = e => {
          let file = e.target.files[0]
          api.setValue(file)
        }

        const showAnyErrors =
          showErrors && (isForm ? api.getTouched() === true : true)
        const classes = classnames(
          'form-unit',
          {
            'is-error':
              !errorBefore &&
              showAnyErrors &&
              api.getTouched() &&
              api.getError()
          },
          className
        )

        return (
          <div className={classes}>
            <input
              type="text"
              className="tc-15-input-text m"
              readOnly
              value={api.getValue('') && api.getValue('').name}
              title={api.getValue('') && api.getValue('').name}
              placeholder={t("还未选择文件")}
            />
            <a
              href="javascript:void(0);"
              className="tc-upload-btn"
              title={t('选择文件')}
            >
              <div className="file-input-wrap">
                <input
                  type="file"
                  onChange={buildHandler(onChange, e => uploadFile(e))}
                  onBlur={buildHandler(onBlur, () => api.setTouched())}
                />
                <span>{api.getValue('') ? t('重新上传') : t('上传')}</span>
              </div>
            </a>
            <FormPrompt field={field} defaultPrompt={defaultPrompt} />
          </div>
        )
      }}
    </FormField>
  )
}
