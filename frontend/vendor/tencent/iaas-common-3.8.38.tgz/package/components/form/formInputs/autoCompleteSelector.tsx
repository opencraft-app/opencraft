import * as React from 'react'
import * as ReactDom from 'react-dom'
import * as classnames from 'classnames'
import { FormInput } from '../../../components/form'
import OnOuterClick from '../../../helpers/onOuterClick'
import { t, Trans } from '@tencent/tea-app/lib/i18n';


/**
 * 自动填充数据源的格式如下
 *
 * @interface DataSourceItem
 */
interface DataSourceItem {
  label: string
  value: string | number
}

interface AutoCompleteSelectorProps extends BaseReactProps {
  /**
   * 选择的值存储在form的字段名
   *
   * @type {string}
   * @memberof AutoCompleteSelectorProps
   */
  field: string
  /**
   * 自动填充数据源
   *
   * @type {Array<DataSourceItem>}
   * @memberof AutoCompleteSelectorProps
   */
  dataSource: Array<DataSourceItem>

  /**
   * 某个补全项被选中的回调
   *
   * @param {DataSourceItem} item
   * @memberof AutoCompleteSelectorProps
   */
  onItemSelect?: (item: DataSourceItem) => {}

  /**
   * 输入框输入值的回调
   *
   * @param {string} item
   * @memberof AutoCompleteSelectorProps
   */
  onChange?: (item: string) => {}

  /**
   * 失去焦点的回调
   *
   * @memberof AutoCompleteSelectorProps
   */
  onBlur?: () => {}

  /**
   * 禁用
   *
   * @type {boolean}
   * @memberof AutoCompleteSelectorProps
   */
  disabled?: boolean

  /**
   * 是否需要button
   *
   * @type {boolean}
   * @memberof AutoCompleteSelectorProps
   */
  hasButton?: boolean

  /**
   * 文本框的提示文字
   *
   * @type {string}
   * @memberof AutoCompleteSelectorProps
   */
  placeholder?: string

  addon?: JSX.Element

  /**
   * 展示错误
   *
   * @type {boolean}
   * @memberof AutoCompleteSelectorProps
   */
  showErrors?: boolean

  /**
   * 错误是否放在前面
   *
   * @type {boolean}
   * @memberof AutoCompleteSelectorProps
   */
  errorBefore?: boolean

  /**
   * 提示文字
   *
   * @type {string}
   * @memberof AutoCompleteSelectorProps
   */
  defaultPrompt?: string

  /**
   * 外壳的类名
   *
   * @type {string}
   * @memberof AutoCompleteSelectorProps
   */
  wrapClass?: string

  /**
   * 外壳的样式
   *
   * @type {React.CSSProperties}
   * @memberof AutoCompleteSelectorProps
   */
  style?: React.CSSProperties

  /**
   * 用户设定的默认index
   *
   * @type {number}
   * @memberof AutoCompleteSelectorProps
   */
  defaultIndex?: number

  /**
   * 当用户设定默认index后进行的回调操作
   *
   * @param {DataSourceItem} item
   * @memberof AutoCompleteSelectorProps
   */
  setInitialValue?: (item: DataSourceItem) => {}
}

interface AutoCompleteSelectorState {
  /**
   * 列表是否展示
   *
   * @type {boolean}
   * @memberof AutoCompleteSelectorState
   */
  isOpened?: boolean

  /**
   * 是否在输入中，这个决定是用表单的值，还是state的值
   *
   * @type {boolean}
   * @memberof AutoCompleteSelectorState
   */
  isInputing?: boolean

  /**
   * 这个还是需要的，不过只在输入的时候才会展示
   *
   * @type {string}
   * @memberof AutoCompleteSelectorState
   */
  value?: string

  /**
   * 当前展示的列表的数据源
   *
   * @type {Array<DataSourceItem>}
   * @memberof AutoCompleteSelectorState
   */
  filterList?: Array<DataSourceItem>

  /**
   * 当前focus的列表项的下标
   *
   * @type {number}
   * @memberof AutoCompleteSelectorState
   */
  focusIndex?: number
}

export default class AutoCompleteSelector extends React.Component<
  AutoCompleteSelectorProps,
  AutoCompleteSelectorState
> {
  state: AutoCompleteSelectorState = {
    isOpened: false,
    isInputing: false,
    value: '',
    filterList: [],
    focusIndex: -1
  }

  input: HTMLElement

  constructor(props) {
    super(props)

    this.open = this.open.bind(this)
    this.close = this.close.bind(this)
    this.onItemSelect = this.onItemSelect.bind(this)
    this.onButtonClick = this.onButtonClick.bind(this)
    this.onInput = this.onInput.bind(this)
    this.onBlur = this.onBlur.bind(this)
    this.renderList = this.renderList.bind(this)
    this.highLight = this.highLight.bind(this)
    this.getSelected = this.getSelected.bind(this)
    this.onKeyDown = this.onKeyDown.bind(this)
  }

  open() {
    this.setState({
      isOpened: true,
      isInputing: false,
      filterList: this.props.dataSource,
      focusIndex: -1
    })
  }

  @OnOuterClick
  close() {
    this.setState({
      isOpened: false,
      isInputing: false
    })
  }

  /**
   * 自动补全的选项被选中的监听
   *
   * @param {*} item
   * @param {*} e
   * @memberof FormInputAutoComplete
   */
  onItemSelect(item, e, { setValue }) {
    if (this.props.disabled) return
    setValue(item.value)
    this.close()
    // 将选中的值传出去
    this.props.onItemSelect && this.props.onItemSelect(item)
  }

  /**
   * 用户设定默认index后的监听
   *
   * @param {*} item
   * @param {*} e
   * @memberof FormInputAutoComplete
   */
  setInitialValue(item) {
    //将默认的值传出去
    this.props.setInitialValue && this.props.setInitialValue(item)
  }

  /**
   * 下拉收缩按钮的监听
   *
   * @memberof FormInputAutoComplete
   */
  onButtonClick() {
    if (this.props.disabled) return
    this.setState({
      isOpened: !this.state.isOpened,
      isInputing: false,
      filterList: this.props.dataSource,
      focusIndex: -1
    })
  }

  /**
   *  输入框的输入值的回调
   *
   * @param {*} e
   * @memberof FormInputAutoComplete
   */
  onInput(e) {
    const { dataSource, disabled } = this.props

    if (disabled) return

    const filterList = dataSource.filter(item => {
      const { label } = item
      const matched = label.indexOf(e.target.value) !== -1
      return matched
    })

    this.setState({
      isInputing: true,
      value: e.target.value,
      filterList,
      focusIndex: -1
    })

    // 话说需要？感觉不需要啊，毕竟这个组件不需要不正确的值
    this.props.onChange && this.props.onChange(e.target.value)
  }

  /**
   *  失去焦点的时候，选择原来的值
   *
   * @param {*} selectValue
   * @param {*} e
   * @memberof FormInputAutoComplete
   */
  onBlur(selectValue, e) {}

  /**
   *
   *
   * @param {*} e
   * @memberof AutoCompleteSelector
   */
  onKeyDown({ setValue }, e) {
    const keyCode = e.keyCode

    const KEYCODE = {
      ENTER: 13,
      UP: 38,
      DOWN: 40
    }

    const { focusIndex, filterList } = this.state
    if (keyCode === KEYCODE.UP) {
      this.setState({
        focusIndex: focusIndex - 1 < 0 ? filterList.length - 1 : focusIndex - 1
      })
    }
    if (keyCode === KEYCODE.DOWN) {
      this.setState({
        focusIndex: focusIndex + 1 >= filterList.length ? 0 : focusIndex + 1
      })
    }

    if (keyCode === KEYCODE.ENTER) {
      this.onItemSelect(filterList[focusIndex], e, { setValue })
      this.input.blur()
    }
  }

  /**
   * 高亮label匹配到的部分
   *
   * @param {string} str
   * @memberof AutoCompleteSelector
   */
  highLight(str: string, value) {
    // let index
    // let res = []
    // if (value === '') return [str]
    // while (1) {
    //   index = str.indexOf(value)
    //   if (index === -1) break
    //   let lStr = str.substr(0, index)
    //   str = str.substr(index + value.length)
    //   res.push(lStr)
    //   res.push(<em>{value}</em>)
    // }

    // res.push(str)
    // return res
    const [first, ...rest]: any = str.split(value)
    if (rest.length === 0 || value === '') return [str]

    let res = [first]
    return res.concat(
      rest.map(str => (
        <span>
          <em>{value}</em>
          {str}
        </span>
      ))
    )
  }

  getSelected(getValue) {
    return (this.props.dataSource.find(item => item.value === getValue()) ||
      {}) as DataSourceItem
  }
  /**
   * 渲染匹配输入框的值的列表
   *
   * @param {*} {
   *     getValue,
   *     setValue,
   *     setTouched
   *   }
   * @returns
   * @memberof FormInputAutoComplete
   */
  renderList({ getValue, setValue, setTouched }) {
    const { value, isInputing, filterList, focusIndex } = this.state
    const { defaultIndex } = this.props

    const resList = filterList.map((item, index) => {
      const selected = this.getSelected(getValue)
      const { label } = item

      return (
        <li
          style={{
            backgroundColor:
              label === selected.label || focusIndex === index ? '#f2f2f2' : ''
          }}
          key={label}
          onClick={e => {
            this.onItemSelect(item, e, { setValue })
          }}
          role="presentation"
        >
          <a
            title={label}
            className="text-truncate"
            role="menuitem"
            href="javascript:;"
          >
            {isInputing ? this.highLight(label, value) : label}
          </a>
        </li>
      )
    })
    if (resList.length === 0) {
      resList.push(
        <li role="presentation">
          <a className="autocomplete-empty" role="menuitem" href="javascript:;">
            {isInputing ? t('无相关搜索内容') : t('无')}
          </a>
        </li>
      )
    }

    return resList
  }

  render() {
    const {
      field,
      addon,
      showErrors,
      errorBefore,
      defaultPrompt,
      wrapClass,
      style,
      disabled = false,
      hasButton = true,
      placeholder,
      dataSource,
      defaultIndex
    } = this.props

    const { value, isInputing, isOpened, filterList } = this.state

    return (
      <FormInput
        className={wrapClass}
        addon={addon}
        field={field}
        defaultPrompt={defaultPrompt}
        showErrors={showErrors}
        errorBefore={errorBefore}
      >
        {({ setValue, getValue, setTouched }) => {
          // 找到选择的值对应的label
          let label = this.getSelected(getValue).label
          //显示用户设定的index对应的值
          if (!label) {
            if (dataSource[defaultIndex] && defaultIndex != undefined) {
              label = dataSource[defaultIndex].label
              setValue(dataSource[defaultIndex].value)
              this.setInitialValue(dataSource[defaultIndex])
            }
          }
          return (
            <div
              onKeyDown={e => this.onKeyDown({ setValue }, e)}
              style={style}
              className={classnames('tc-15-autocomplete', { open: isOpened })}
            >
              <div className="tc-15-autocomplete-inner">
                <div className="tc-15-autocomplete-input-wrap">
                  <input
                    ref={input => (this.input = input)}
                    title={isInputing ? value : label}
                    placeholder={placeholder}
                    disabled={disabled}
                    className="tc-15-input-text xl"
                    value={isInputing ? value : label}
                    onFocus={this.open}
                    onInput={this.onInput}
                  />
                </div>
                <button
                  style={{ display: hasButton ? 'block' : 'none' }}
                  className="tc-15-dropdown-icon"
                  onClick={this.onButtonClick}
                >
                  <i className="dropdown-icon" />
                </button>
              </div>
              <ul
                style={{ display: isOpened ? 'block' : 'none' }}
                className="tc-15-autocomplete-menu"
                role="menu"
              >
                {this.renderList({ setValue, getValue, setTouched })}
              </ul>
            </div>
          )
        }}
      </FormInput>
    )
  }
}
