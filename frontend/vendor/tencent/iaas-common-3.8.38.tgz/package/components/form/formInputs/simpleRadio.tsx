import * as React from 'react'
//
import { buildHandler } from './util'
import FormField from '../formField'

export default function FormInputRadio({
  field,
  value,
  onChange,
  onBlur,
  noTouch = false,
  ...rest
}) {
  return (
    <FormField field={field}>
      {({ setValue, getValue, setTouched }) => {
        return (
          <input
            {...rest}
            type="radio"
            name={field}
            checked={getValue(false) === value}
            onChange={buildHandler(onChange, e => setValue(value, noTouch))}
            onBlur={buildHandler(onBlur, () => setTouched())}
          />
        )
      }}
    </FormField>
  )
}
