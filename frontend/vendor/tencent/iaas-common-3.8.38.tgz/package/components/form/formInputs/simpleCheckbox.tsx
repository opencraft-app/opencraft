import * as React from 'react'
//
import { buildHandler } from './util'
import FormField from '../formField'

export default function FormInputCheckbox({
  field,
  value,
  onChange,
  onBlur,
  noTouch = false,
  ...rest
}) {
  return (
    <FormField field={field}>
      {({ setValue, getValue, setTouched }) => {
        return (
          <input
            {...rest}
            type="checkbox"
            checked={getValue(false) == 1}
            onChange={buildHandler(onChange, e =>
              setValue(e.target.checked ? 1 : 0, noTouch)
            )}
            onBlur={buildHandler(onBlur, () => setTouched())}
          />
        )
      }}
    </FormField>
  )
}
