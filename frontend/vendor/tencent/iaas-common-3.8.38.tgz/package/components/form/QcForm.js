import React, { Component } from 'react'
import Form from './form'
import _ from './utils'
export default class QcForm extends Component {
  /** 供子类扩展 */
  renderForm(/*{ values, getError }*/) {
    return <div />
  }
  /** 供子类扩展 */
  validate(/*values*/) {
    return {}
  }
  /** 入数据处理，供子类扩展 */
  preProcess(values) {
    return values
  }
  /** 出数据处理，供子类扩展 */
  postProcess(values) {
    return values
  }
  preSubmit(values) {
    return values
  }
  isValid() {
    return this.refs.form.isValid()
  }
  getValue() {
    return this.postProcess(this.refs.form.getAllValues())
  }
  componentWillMount() {
    const { refCallback } = this.props
    if (refCallback) {
      refCallback(this)
    }
  }
  render() {
    const { value = {}, onSubmit } = this.props
    return (
      <Form
        ref="form"
        defaultValues={this.preProcess(value)}
        validate={this.validate}
        onSubmit={onSubmit}
        preSubmit={this.preSubmit}
      >
        {api => this.renderForm(api)}
      </Form>
    )
  }

  static combineValidators(validators) {
    const fields = Object.keys(validators)
    return (values, ...rest) => {
      return fields.reduce((results, field) => {
        _.set(
          results,
          field,
          validators[field](_.get(values, field), values, ...rest)
        )
        return results
      }, {})
    }
  }
}
