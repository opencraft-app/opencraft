import React from 'react'
import classnames from 'classnames'

import FormField from './formField'
import FormPrompt from './formPrompt'

const FormPromptJS: any = FormPrompt

export default function FormInput({
  field,
  defaultPrompt = '',
  showErrors = true,
  errorBefore,
  isForm = false,
  className = '',
  addon = null,
  otherChild,
  children
}: any) {
  return (
    <FormField field={field}>
      {({ ...api }) => {
        const showAnyErrors =
          showErrors && (isForm ? api.getTouched() === true : true)
        const classes = classnames(
          'form-unit',
          {
            'is-error':
              !errorBefore &&
              showAnyErrors &&
              api.getTouched() &&
              api.getError()
          },
          className
        )

        if (addon) {
          return (
            <div className={classes}>
              <div className="tc-input-group-wrap s">
                <div className="tc-input-group">
                  {children({
                    ...api
                  })}
                  <span className="tc-input-group-addon">{addon}</span>
                </div>
              </div>
              <FormPromptJS field={field} defaultPrompt={defaultPrompt} />
            </div>
          )
        } else {
          return (
            <div className={classes}>
              {children({
                ...api
              })}
              {otherChild}
              <FormPromptJS field={field} defaultPrompt={defaultPrompt} />
            </div>
          )
        }
      }}
    </FormField>
  )
}
