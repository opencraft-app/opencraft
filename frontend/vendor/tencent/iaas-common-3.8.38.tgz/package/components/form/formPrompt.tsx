import React from 'react'
import classnames from 'classnames'
//
import FormField from './formField'

export default function FormPrompt({
  field,
  defaultPrompt,
  className,
  style
}: {
  field
  defaultPrompt?: string
  className?
  style?
}) {
  return (
    <FormField field={field}>
      {({ getTouched, getError }) => {
        const error = getTouched() && getError()
        const prompt = error || defaultPrompt
        const classes = classnames('form-input-help', className)
        return (
          <p className={classes} style={style}>
            {prompt}
          </p>
        )
      }}
    </FormField>
  )
}
