/**
 * 从 https://github.com/tannerlinsley/react-form 定制化改造（原库无法扩展不同的错误样式）
 * TODO 后面考虑独立出来，例如发布到 @tencent/qc-react-form
 */

import Form, { FormDefaultProps } from './form'
import FormField from './formField'
import FormError from './formError'
import FormInput from './formInput'
// Inputs
import Select from './formInputs/select'
import SelectGroup from './formInputs/selectGroup'
import Checkbox from './formInputs/checkbox'
import Textarea from './formInputs/textarea'
import NestedForm from './formInputs/nestedForm'
import Text from './formInputs/text'
import File from './formInputs/file'
import RadioGroup from './formInputs/radioGroup'
import Radio from './formInputs/radio'
import InputNum from './formInputs/inputNum'
import SimpleText from './formInputs/simpleText'
import SimpleSelect from './formInputs/simpleSelect'
import SimpleCheckbox from './formInputs/simpleCheckbox'
import SimpleRadio from './formInputs/simpleRadio'
import AutoCompleteSelector from './formInputs/autoCompleteSelector'
import { buildHandler } from './formInputs/util'

import QcForm from './QcForm'

export {
  Form,
  FormDefaultProps,
  FormField,
  FormError,
  FormInput,
  // Inputs
  Select,
  SelectGroup,
  Checkbox,
  Textarea,
  NestedForm,
  Text,
  File,
  RadioGroup,
  Radio,
  InputNum,
  SimpleText,
  SimpleSelect,
  SimpleRadio,
  SimpleCheckbox,
  AutoCompleteSelector,
  QcForm,
  buildHandler
}
