import * as React from 'react'
import * as classnames from 'classnames'
import { Dropdown as DropdownList } from '@tencent/tea-component'
import { t } from '@tencent/tea-app/lib/i18n'
const styleClassConfigMap = {
  dropdown: {
    className: 'tc-15-dropdown',
    buttonClassName: 'tc-15-dropdown-link',
    activeClassName: 'tc-15-menu-active',
    buttonActiveClassName: 'active',
    menuClassName: 'tc-15-dropdown-menu',
    menuItemSelectedClassName: 'selected',
    upClassName: 'tc-15-dropup'
  }
}

export default class DropdownMenu extends DropdownList {
  render() {
    const {
      selected,
      buttonMaxWidth,
      menuMaxWidth,
      menuMaxHeight,
      disabled
    } = this.props
    const { isOpened } = this.state
    const {
      items = [],
      simulateSelect = false,
      placeholder = t('请选择'),
      popDirection,
      smallSize
    } = this.props

    const theme = 'dropdown'

    const classConfig = styleClassConfigMap[theme]

    const className = classnames(classConfig.className, this.props.className, {
      [classConfig.activeClassName]: isOpened,
      [classConfig.upClassName]: popDirection === 'up',
      m: smallSize,
      disabled
    })
    const buttonClassName = classnames(
      classConfig.buttonClassName,
      this.props.buttonClassName,
      { [classConfig.buttonActiveClassName]: isOpened, m: smallSize }
    )
    const menuClassName = classnames(
      classConfig.menuClassName,
      this.props.meunClassName
    )

    const buttonContent =
      (simulateSelect && selected && selected.label) || placeholder

    const itemsBody = items.map(item => (
      <li
        role="presentation"
        className={classnames({
          disabled: item.disabled,
          [classConfig.menuItemSelectedClassName]: item === selected
        })}
        key={item.id}
        onClick={e => this._handleItemClick(item, e)}
        title={typeof item.label == 'string' ? item.label : null}
      >
        {item.label}
      </li>
    ))

    let wrapperStyle = {}

    let buttonStyle = {
      display: 'inline-block',
      cursor: disabled ? 'not-allowed' : 'pointer',
      color: disabled ? '#999' : null
    }
    if (buttonMaxWidth) {
      buttonStyle = Object.assign(buttonStyle, {
        maxWidth: buttonMaxWidth,
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap'
      })
    }

    let menuStyle = {
      maxWidth: menuMaxWidth,
      maxHeight: menuMaxHeight,
      overflow: 'auto'
    }
    if (classConfig.triggerMenuDisplay) {
      menuStyle.display = isOpened ? 'block' : 'none'
    }

    return (
      <div className={className} style={wrapperStyle}>
        <a
          style={buttonStyle}
          className={buttonClassName}
          onClick={this._handleButtonClick.bind(this)}
          title={typeof buttonContent == 'string' ? buttonContent : null}
        >
          {buttonContent}
          <i className="caret" />
        </a>
        {Array.isArray(items) && items.length > 0 && (
          <ul key="menu" className={menuClassName} style={menuStyle}>
            {itemsBody}
          </ul>
        )}
      </div>
    )
  }
}
