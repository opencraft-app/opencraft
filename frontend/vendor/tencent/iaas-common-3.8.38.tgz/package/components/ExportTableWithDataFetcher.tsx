import * as React from 'react';
import BaseExportTable, {
  ExportTableProps,
  BatchExportTableProps
} from './ExportTable';

/**
 * 导出单个表格数据
 */
interface ExportTableWithDataFetcherProps<T>
  extends Pick<ExportTableProps<T>, 'columns' | 'fileName'> {
  fetchTableData: (
    offset: number,
    pageSize: number
  ) => Promise<{ list: T[]; totalCount: number }>; // 导出文件的数据源
  offset?: number; // 下载数据的起始位置
  len?: number; // 下载多少条数据
  pageSize?: number; // 请求每一页数据的数量
}

/**
 * 导出多个表格数据
 */
interface BatchExportTableWithDataFetcherProps<T>
  extends Pick<BatchExportTableProps<T>, 'batchColumns' | 'fileNames'> {
  fetchers: ((
    offset: number,
    pageSize: number
  ) => Promise<{ list: T[]; totalCount: number }>)[];
  offset?: number; // 下载数据的起始位置
  len?: number; // 下载多少条数据
  pageSize?: number; // 请求每一页数据的数量
}

/**
 * @description 导出表格数据组件，优先支持单个文件的导出
 * @author aidanwen@tencent.com
 * @date 2020/12/11 10:06:06
 * @export
 * @class ExportTableWithDataFetcher
 * @extends {(React.Component<ExportTableWithDataFetcherProps<T> & BatchExportTableWithDataFetcherProps<T>>)}
 * @template T
 */
export default class ExportTableWithDataFetcher<T> extends React.Component<
  ExportTableWithDataFetcherProps<T> | BatchExportTableWithDataFetcherProps<T>
> {
  constructor(props) {
    super(props);
    this.state = {
      exportData: []
    };
  }

  async getExportData(fetchTableData, offset, len, pageSize) {
    // 导出所有
    let fullList = [];
    let finished = false;
    // // 下载的数据长度小于pageSize时
    if (len && len < pageSize) {
      pageSize = len;
    }
    // 有的接口有限制最大页数，这时需要多次查询
    do {
      const { list, totalCount } = await fetchTableData(offset, pageSize);
      fullList = fullList.concat(list);
      // 如果没有限制现在多少条数据，默认下载所有的数据
      if (!len) {
        len = totalCount;
      }
      // 下载数据长度超出总列表长度，默认从offset下载完所有的数据
      if (len > totalCount) {
        len = totalCount - offset;
      }
      if (fullList.length >= len) {
        finished = true;
      }
      offset = offset + pageSize;
    } while (!finished);
    return fullList;
  }
  render() {
    const { offset = 0, len = 0, pageSize = 10 } = this.props;
    const { columns, fileName, fetchTableData } = this
      .props as ExportTableWithDataFetcherProps<T>;
    const { batchColumns, fileNames, fetchers } = this
      .props as BatchExportTableWithDataFetcherProps<T>;

    // 优先支持单个文件的导出
    if (fetchTableData) {
      return (
        <BaseExportTable
          getExportData={() =>
            this.getExportData(fetchTableData, offset, len, pageSize)
          }
          columns={columns}
          fileName={fileName}
        />
      );
    }

    if (fetchers) {
      return (
        <BaseExportTable
          getExportDatas={fetchers.map(fetcher => () =>
            this.getExportData(fetcher, offset, len, pageSize)
          )}
          batchColumns={batchColumns}
          fileNames={fileNames}
        />
      );
    }
  }
}
