const iaas = seajs.require('models/iaas')
const util = seajs.require('util')

let _regionCache = null
export function queryRegion(opts = {}) {
  return _regionCache
    ? Promise.resolve(_regionCache)
    : iaas
        .request(
          '/cgi/area?action=queryConsoleRegion&uin=' + util.getUin(),
          {},
          opts
        )
        .then(data => {
          _regionCache = data
          return _regionCache
        })
}

export function queryRegionMap(opts = {}) {
  return queryRegion(opts).then(result => {
    return result.regionList.reduce((map, regionData) => {
      map[regionData.regionId] = `${regionData.area}（${
        regionData.regionName
      }）`
      return map
    }, {})
  })
}
