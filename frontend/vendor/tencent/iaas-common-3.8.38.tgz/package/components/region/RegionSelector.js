/**
 * 地域选择下拉列表
 * props
 *    list: 可选，地域列表，不受到 whiteList 影响，不提供则使用 manager.queryRegion 获取地域列表
 *      [{regionId: Int, name: String}]
 *    whiteList: 可选，没有提供 list 的时候，用于过滤 manager.queryRegion 的地域
 *    regionChange： 可选，选择事件的回调函数
 *      接受第一个参数为当前选择地域，结构为 {id: int, label: '地域名称'}
 *    onReady: 可选，地域列表准备完毕回调
 */
import * as React from 'react'

import { DropdownList } from '@tencent/qcloud-component'

const manager = seajs.require('models/manager')
const appUtil = seajs.require('appUtil')
const regionList = seajs.require('constants').REGIONNAMES

export default class RegionSelector extends React.Component {
  componentDidMount() {
    let me = this
    async function initState() {
      let list = me.props.list
        ? await me.props.list
        : await me.getRegionList().catch(err => {
            return null
          })
      me.setState(
        {
          list: list || [],
          selected:
            list.find(item => {
              return item.id == me.props.defaultRegion
            }) ||
            (list && list[0]) ||
            null
        },
        () => {
          me.props.onReady
            ? me.props.onReady(me.state)
            : me.props.regionChange && me.props.regionChange(me.state.selected)
        }
      )
    }
    initState()
  }
  getRegionList() {
    const whiteList = this.props.whiteList
    return Promise.all([
      new Promise((resolve, reject) => {
        manager.queryRegion(regionMap => resolve(regionMap), reject)
      }),
      whiteList
        ? new Promise((resolve, reject) => {
            if (typeof whiteList == 'function') {
              that.getRegionList().then(resolve, reject)
            } else {
              resolve(whiteList)
            }
          })
        : Promise.resolve([])
    ]).then(result => {
      const regionMap = result[0]
      const whiteList = result[1]

      var list = [],
        sortData = appUtil.getRegionOrderHackObj(regionMap)

      for (var prop in sortData) {
        prop = prop.replace('_', '')
        if (whiteList.length && whiteList.indexOf(prop) < 0) {
          continue
        } else {
          list.push({
            id: prop,
            label: regionMap[prop] || regionList[prop]
          })
        }
      }

      return list
    })
  }
  getCurrentRegion() {
    return (this.state && this.state.selected) || null
  }
  render() {
    let regionSelector = this
    let itemList = (this.state && this.state.list) || []
    function regionChange(selectedRegion) {
      this.props
      regionSelector.props.regionChange &&
        regionSelector.props.regionChange(selectedRegion)
      regionSelector.setState({
        selected: selectedRegion
      })
    }
    return (
      <DropdownList
        items={itemList}
        theme="dropdown-hd"
        className="mr20"
        menuMaxHeight="500px"
        simulateSelect
        selected={(this.state && this.state.selected) || itemList[1]}
        onSelect={regionChange}
      />
    )
  }
}
