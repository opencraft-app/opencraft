//TODO a better stateless way

import * as React from 'react'
import { Segment } from '@tencent/tea-component'
import { queryRegion } from './model'

const appUtil = seajs.require('appUtil')
const REGIONNAMES = seajs.require('constants').REGIONNAMES

class RegionBar extends React.Component {
  componentDidMount() {
    if (!this.props.list) {
      this.getRegionList().then(regionList => {
        this.setState({ list: regionList })
        this.props.onReady && this.props.onReady()
      })
    }
  }
  getRegionList() {
    const whiteList = this.props.whiteList
    let _this = this
    return Promise.all([
      queryRegion(),
      whiteList
        ? new Promise((resolve, reject) => {
            if (typeof whiteList == 'function') {
              _this.getRegionList().then(resolve, reject)
            } else {
              resolve(whiteList)
            }
          })
        : Promise.resolve([])
    ])
      .then(([{ regionList }, whiteList]) => {
        var list = []

        for (let region of regionList) {
          if (whiteList.length && whiteList.indexOf(region.regionId + '') < 0) {
            continue
          } else {
            list.push({
              text: REGIONNAMES[region.regionId] || region.regionName,
              value: region.regionId + '',
              regionId: region.regionId + ''
            })
          }
        }

        return list
      })
      .catch(e => {
        console.log(e)
      })
  }
  render() {
    let { onSelect, selected, whiteList, ...restProps } = this.props
    let options = this.state ? this.state.list : []
    return (
      <Segment
        value={selected && selected.value}
        onChange={value => {
          let find = options.find(item => item.value == value)
          onSelect(find || null)
        }}
        options={options}
        {...restProps}
      />
    )
  }
}

export default RegionBar
