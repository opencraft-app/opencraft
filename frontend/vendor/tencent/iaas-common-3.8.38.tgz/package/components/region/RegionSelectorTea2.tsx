import React, { useState } from 'react'
import { Select, SelectProps } from '@tencent/tea-component'
import { once } from '../../helpers/cacheable'
import { useAsync } from 'react-use'

const iaas = seajs.require('models/iaas')
const util = seajs.require('util')
const constants = seajs.require('constants')

export interface Region {
  area?: string
  name: string
  regionId: number
  value: number
  // api v3 region: ap-guangzhou
  region?: string
}
async function queryConsoleRegion() {
  interface Result {
    regionList: {
      area: string // 华南地区
      region: string // ap-guangzhou
      regionId: number // 1
      regionName: string // 广州
    }[]
  }
  const result = await iaas.request<Result>(
    '/cgi/area?action=queryConsoleRegion&uin=' + util.getUin(),
    {}
  )
  return result.regionList.map<Region>(region => {
    let regionId = parseInt(region.regionId as any, 10)
    return {
      area: region.area,
      name: region.regionName || constants.REGIONNAMES[regionId],
      value: regionId,
      regionId,
      region: region.region
    }
  })
}
const cacheQueryRegion = once(queryConsoleRegion)

export default function RegionSelectorTea2(
  props: SelectProps & {
    list?: Region[]
    // 地域的数字 ID 或字符串 ID，在没有传入 list 的时候用于过滤请求的的地域
    whiteList?: (string | number)[]
    regionChange: (selectedRegion: Region) => void
    // 地域的数字 ID 或字符串 ID，
    defaultRegion?: string | number
    // 地域的数字 ID 或字符串 ID，
    val: string | number
  }
) {
  const { list, whiteList, regionChange, defaultRegion, val } = props

  const [regionList, setRegionList] = useState(list || null)
  useAsync(
    async function() {
      let tempList = list || []
      if (!list) {
        // 拉取地域信息
        tempList = await cacheQueryRegion()
        // 白名单过滤
        if (whiteList && whiteList.length) {
          tempList = tempList.filter(x => {
            return (
              !whiteList.includes(x.region) && !whiteList.includes(x.regionId)
            )
          })
        }
        setRegionList(tempList)
      }
      if (defaultRegion) {
        const selected = tempList.find(x => {
          return x.regionId === defaultRegion || x.region === defaultRegion
        })
        regionChange && regionChange(
          selected
        )
      }
      return 
    },
    [list, whiteList]
  )

  const selectValue = (regionList || []).find(
    x => x.region === val || x.regionId === val
  )?.region

  return (
    <Select
      type="native"
      size="m"
      {...props}
      options={(regionList || []).map(x => ({
        value: x.region,
        text: `${x.area}(${x.name})`
      }))}
      value={selectValue}
      onChange={val => {
        const region = (regionList || []).find(x => x.region === val)
        regionChange(region)
      }}
    ></Select>
  )
}
