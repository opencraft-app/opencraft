import { Table } from '@tencent/tea-component'

// tea2现已自带action panel，换它自己的实现
export default Table.ActionPanel
