/**
 *
 * 穿梭框 自定义字段选择器。用法和FieldManger一样
用法
TransferFieldManager(cacheKey) {
  const { duck, store, dispatch } = this.props
  let { creators, selectors, ducks } = duck

  let fullColumns = selectors.fullColumns(store)

  return (
    fullColumns &&
    fullColumns.length > 0 && (
      <TransferFieldManager
        fields={selectors.fields(store) as any}
        cacheKey={cacheKey}
        onChange={fields => dispatch(creators.setCustomFields(fields))}
      />
    )
  )
}
注意：列的header值默认是是使用string.includes进行匹配，若是 ReactNode 类型的话，筛选查找会使用 id 的值。这种情况下将id指定为和header的值一样才能匹配成功

 */
import * as React from 'react'
import {
  Transfer,
  Table,
  SearchBox,
  Modal,
  ModalProps,
  Button
} from '@tencent/tea-component'
import { t } from '@tencent/tea-app/lib/i18n'
import { Fragment } from 'react'
import tips from '@tencent/iaas-common/inject/tips'
import { safeSetLocalStorageItem } from '../util/localStorageUtil'

const { removeable, selectable, scrollable } = Table.addons

export interface ColumnField extends Identifiable {
  id: string
  [propName: string]: any
  headTitle: string
  /** 表示必选，不能取消 */
  required?: boolean
  /** 表示默认选中 */
  defaults?: boolean
  hide?: boolean
}

interface FieldMap {
  [id: string]: ColumnField
}

interface Props extends ModalProps {
  fields: ColumnField[]

  cacheKey: string
  /**判断是否为标签的正则，默认 /^__tagKey__/ */
  tagReg?: RegExp
  /** 最多选多少个字段 */
  maxLimit?: number
  onChange: any
}

interface DialogProps extends Props {
  /**设置弹框是否可见 */
  setVisible: (visible: boolean) => void
}

const { useState, useEffect, useRef } = React

const defaultValue = {
  fields: [],
  cacheKey: '',
  maxLimit: 12,
  tagReg: /^__tagKey__/
}

const columns = [
  {
    key: 'headTitle',
    header: t('字段')
  }
]

export const TransferFieldManagerDialog = ({
  fields,
  cacheKey,
  onChange,
  maxLimit = defaultValue.maxLimit,
  visible,
  setVisible,
  tagReg = defaultValue.tagReg
}: DialogProps) => {
  // 搜索框
  const [inputValue, setInputValue] = useState('')

  // 已选
  const [targetFieldKeys, setTargetFieldKeys] = useState<string[]>([])

  /**fields model */
  let model = useRef<CustomFields>(null)
  let ids = fields.map(e => e.id).join('')

  useEffect(() => {
    model.current = new CustomFields({ fields, cacheKey, tagReg: tagReg })
  }, [fields])
  useEffect(() => {
    onChange(model.current.getDisplayFields())
  }, [ids])
  useEffect(() => {
    if (visible) {
      const selectFields = model.current.getDisplayFields()
      // 设置当前选中
      setTargetFieldKeys(selectFields.map(item => item.id))
    }
  }, [visible])

  return (
    <Modal
      caption={t('自定义列表字段')}
      visible={visible}
      onClose={() => setVisible(false)}
      size="l"
    >
      <Modal.Body>
        <Transfer
          leftCell={
            <Transfer.Cell
              scrollable={false}
              title={t('请选择')}
              header={
                <SearchBox
                  value={inputValue}
                  onChange={value => setInputValue(value)}
                />
              }
            >
              <Table
                records={fields.filter(i =>
                  typeof i.headTitle.includes === 'function'
                    ? i.headTitle.includes(inputValue)
                    : i.id.includes(inputValue)
                )}
                recordKey="id"
                columns={columns}
                rowDisabled={x =>
                  x.required ||
                  (targetFieldKeys.length >= maxLimit &&
                    !targetFieldKeys.includes(x.id))
                }
                addons={[
                  selectable({
                    value: targetFieldKeys,
                    onChange: keys => {
                      // 选择 or 删除
                      setTargetFieldKeys(keys)
                    },
                    rowSelect: true,
                    all: false
                  }),
                  scrollable({
                    maxHeight: 310
                  })
                ]}
              />
            </Transfer.Cell>
          }
          rightCell={
            <Transfer.Cell title={`${t('已选择')}(${targetFieldKeys.length})`}>
              <Table
                records={fields.filter(i => targetFieldKeys.includes(i.id))}
                recordKey="id"
                columns={columns}
                addons={[
                  removeable({
                    onRemove: key => {
                      const removeItem = fields.find(field => field.id === key)
                      if (removeItem && removeItem.required) {
                        // 必选值不能删
                        return
                      }
                      setTargetFieldKeys(targetFieldKeys.filter(i => i !== key))
                    }
                  })
                ]}
              />
            </Transfer.Cell>
          }
        />
      </Modal.Body>
      <Modal.Footer>
        <Button
          type="primary"
          onClick={() => {
            const fields = model.current.getDisplayFields(targetFieldKeys)
            model.current.setSelection(targetFieldKeys)
            // 把操作放到最后
            const findOperateIndex = fields.findIndex(
              field => field.headTitle === t('操作')
            )
            if (findOperateIndex >= 0) {
              fields.push(fields.splice(findOperateIndex, 1)[0])
            }

            onChange(fields)
            tips.success(t('设置成功'))
            setVisible(false)
          }}
        >
          {t('确定')}
        </Button>
        <Button onClick={() => setVisible(false)}>{t('取消')}</Button>
      </Modal.Footer>
    </Modal>
  )
}

export const TransferFieldManager = (props: Props) => {
  /**对话框可见状态 */
  const [visible, setVisible] = useState(false)
  return (
    <Fragment>
      <Button
        icon="setting"
        onClick={() => {
          setVisible(true)
        }}
      />
      <TransferFieldManagerDialog
        visible={visible}
        setVisible={setVisible}
        {...props}
      />
    </Fragment>
  )
}

export default TransferFieldManager

class CustomFields {
  public selection: string[]
  public fields: ColumnField[]
  public cacheKey: string
  public tagReg: RegExp
  constructor({
    fields = defaultValue.fields,
    cacheKey = defaultValue.cacheKey,
    tagReg = defaultValue.tagReg
  }: {
    fields?: ColumnField[]
    cacheKey?: string
    tagReg?: RegExp
  }) {
    this.fields = fields
    this.cacheKey = cacheKey
    this.tagReg = tagReg
    this.init()
  }
  init() {
    this.selection = this.getInitSelection()
  }
  setSelection(selection: string[] = []) {
    this.selection = selection
    let { cacheKey = '' } = this
    cacheKey && safeSetLocalStorageItem(cacheKey, selection.join(','))
  }
  private getInitSelection() {
    let { fields = [], cacheKey = '' } = this

    let selection: string[] =
      localStorage[cacheKey] && localStorage[cacheKey].split(',')

    if (selection) {
      let fieldsMap = {}
      fields.forEach(field => {
        fieldsMap[field.id] = true
      })
      selection = selection.filter(key => !!fieldsMap[key])
      selection = fields.reduce((selection, field) => {
        return selection
      }, selection)
    }

    if (!selection) {
      selection = fields
        .filter(field => !this.tagReg.test(field.id))
        .reduce((selection, field) => {
          if (!field.hide) {
            selection.push(field.id)
          }
          return selection
        }, [])
    }
    return selection
  }
  getDisplayFields(selection = this.selection): ColumnField[] {
    let { fields = defaultValue.fields } = this
    return fields.reduce((columns, field) => {
      if (selection.indexOf(field.id) != -1) {
        columns.push(field)
      }
      return columns
    }, [])
  }
}
