import pathToRegexp from 'path-to-regexp'
import * as pt from 'path'
import * as React from 'react'

const router = seajs.require('router')

export default function PageRoute(props = {}) {
  const { routes = [], basePath = '/' } = props
  let component = <div />
  let url = router.fragment.split('?')
  let search = url[1]
  let currentPath = url[0]
  currentPath = pt.relative(basePath, currentPath)

  routes.some(route => {
    let reg = pathToRegexp(route.path)

    if (reg.exec(currentPath)) {
      component = <route.component />
      return true
    }
  })

  return component
}
