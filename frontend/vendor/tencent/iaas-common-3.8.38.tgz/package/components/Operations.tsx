import * as React from 'react'
import { Button, Dropdown, List } from '@tencent/tea-component'
import { t } from '@tencent/tea-app/lib/i18n'
import useActions, { Action, Menuize, Synchronize } from '../hooks/useActions'

interface MyAction extends Action {
  /** 操作展示文本 */
  label: string
  /** 操作提示，如果 invalid 有值，优先展示 invalid 信息 */
  tooltip?: React.ReactNode
}
export type ActionProps = Menuize<MyAction>
export type SyncActionProps = Synchronize<Menuize<MyAction>>

export interface OperationsProps {
  actions: ActionProps[]
  /** 最大显示的按钮数，多出的放到“更多”菜单中 */
  maxButton?: number
}
/**
 * 用于列表操作列，操作指令比较多时自动将超出的操作放到“更多”菜单中
 * 
 * @example
 ```javascript
  <Operations actions={[
    {
      label: "删除",
      // 可以是promise异步检查
      invalid: checkCanDelete(item),
      tooltip: "删除实例",
      fn: ()=>{}
    }
  ]} />
  ```
 * @param props
 * @returns
 */
export default function Operations(props: OperationsProps) {
  const { actions, maxButton = 3 } = props


  const supportedActions = useActions(actions)
  let outerActions = supportedActions
  let menuActions: typeof supportedActions
  if (supportedActions.length > maxButton) {
    outerActions = supportedActions.slice(0, maxButton - 1)
    menuActions = supportedActions.slice(maxButton - 1)
  }
  return (
    <>
      {outerActions.map((o) => (
        <LinkAction key={o.label} action={o}></LinkAction>
      ))}
      {menuActions && menuActions.length > 0 && (
        <LinkAction action={{ label: t('更多'), menu: menuActions }} />
      )}
    </>
  )
}

interface LinkActionProps {
  action: SyncActionProps
}
function LinkAction(props: LinkActionProps) {
  const { fn, invalid, tooltip, label, menu } = (props.action)
  if (menu?.length > 0) {
    return <Dropdown appearence="link" button={label} clickClose>
      <div>
        <List type="option">
          {menu.map((item) => (
            <ListItemAction key={item.label} action={item}></ListItemAction>
          ))}
        </List>
      </div>
    </Dropdown>
  }
  return (
    <Button
      type="link"
      disabled={!!invalid}
      onClick={fn}
      tooltip={invalid || tooltip}
    >
      {label}
    </Button>
  )
}
interface ListItemActionProps {
  action: SyncActionProps
}
function ListItemAction(props: ListItemActionProps) {
  const { fn, invalid, tooltip, label, menu } = props.action

  if (menu) {
    return <ListSubMenuItem action={props.action} />
  }
  return (
    <List.Item
      onClick={fn}
      disabled={!!invalid}
      tooltip={invalid || tooltip}
    >
      {label}
    </List.Item>
  )
}

interface ListSubMenuItemProps {
  action: SyncActionProps
}
function ListSubMenuItem(props: ListSubMenuItemProps) {
  const { label, menu } = props.action
  return <List.SubMenu label={label} placement="left">
    <List type="option">
      {menu.map((item) => (
        <ListItemAction key={item.label} action={item}></ListItemAction>
      ))}
    </List>
  </List.SubMenu>
}