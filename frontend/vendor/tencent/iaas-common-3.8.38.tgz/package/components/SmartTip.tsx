import * as React from 'react'

import { FetcherState, FetchState, QueryState } from '../ducks/Fetcher'

import { LoadingTip, StatusTip } from '@tencent/tea-component'
import { t, Trans } from '@tencent/tea-app/lib/i18n'

export interface SmartTipProps {
  fetcher: FetcherState<any>
  query?: QueryState<any>
  onClearSearch?: () => any
  onRetry?: () => any
  emptyTips?: string | JSX.Element
  enableLoading?: boolean
}

export namespace TablePanelSmartTip {
  export function render({
    fetcher,
    enableLoading,
    query,
    onClearSearch,
    onRetry,
    emptyTips
  }: SmartTipProps): JSX.Element {
    const search = query && query.search
    let topTip: JSX.Element = null
    if ((enableLoading !== false || search) && fetcher.loading) {
      topTip = <LoadingTip />
    } else if (fetcher.fetchState === FetchState.Failed) {
      topTip = <StatusTip.ErrorTip onRetry={onRetry} />
    } else if (fetcher.data.recordCount === 0) {
      if (search) {
        return (
          <StatusTip.FoundTip
            foundText={t('搜索 “{{keyword}}” 无结果', {
              keyword: `${search.substr(0, 20)}${
                search.length > 20 ? '...' : ''
              }`
            })}
            onClear={onClearSearch}
          />
        )
      } else {
        emptyTips = emptyTips || t('没有记录')
        return <StatusTip.EmptyTip emptyText={emptyTips} />
      }
    } else {
      if (search) {
        return (
          <StatusTip.FoundTip
            foundText={t('搜索 “{{keyword}}” 找到 {{count}} 条结果', {
              count: fetcher.data.recordCount,
              keyword: `${search.substr(0, 20)}${
                search.length > 20 ? '...' : ''
              }`
            })}
            onClear={onClearSearch}
          />
        )
      }
    }
    return topTip
  }
}
