# 腾讯云 workbench-server api 代理的客户端工具 

## 开发环境
### 配置tnpm
```
alias tnpm="npm --registry https://mirrors.tencent.com/npm/"
```
注意：alias命令默认仅针对当前终端有效，一旦开启新的终端窗口之前的alias别名便会实效。要实现永久保存，还需要把这个命令写入到根目录下的.bashrc文件中，然后 source ~/.bashrc 使其生效。

### 安装项目依赖
```
tnpm install
```

## 开发

使用 npm run dev 命令启动本地开发服务器：

```
npm run dev
```

## 构建

```
npm run build
```

## 发布 npm 包

```
npm run deploy
```

## 使用

安装 npm 包
```
tnpm i -S @tencent/iaas-workbench-api-client
```

```
import { apiRequest } from "@tencent/iaas-workbench-api-client"

// 以查询广州地域的 lighthouse 的实例列表为例
apiRequest(
  {
    serviceType: 'lighthouse',
    action: 'DescribeInstances',
    // number 型的地域 如：1（代表广州）
    // 如果 regionId 存在而 region 不存在则 regionId 会报转换成 region
    regionId: 1,
    // string 类型的地域id 如：ap-guangzhou(代表广州)
    // 如果传了 region 则会忽略 regionId
    region: 'ap-guangzhou'
    // 其他参数
    data: {
      "Limit": 100,
      "Offset": 0
    }
  },
  {
    onLoginVerifyFail: (error) => {
      // 登录校验失效时触发
    },
    onCamError: (error) => {
      // cam 报错时触发
    },
    onRequestInit: (jqAjax) => {
      // 可以使用以下语句取消请求
      // jqAjax.abort()
    },
    ...opts
  }
).catch((error) => {
  // 其他错误处理
}).then((res) => {
  // 数据处理
})
```