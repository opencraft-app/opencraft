export interface I18NTranslationOptions {
    /** 用于确定单复数的数量值 */
    count?: number;
    /** 用于确定上下文的说明文本，只能使用字符串常量，否则无法扫描 */
    context?: string;
    [key: string]: any;
}
export interface I18NTranslation {
    [key: string]: string;
}
export interface I18NInitOptions {
    lng: string;
}
/**
 * 国际化包括的信息以及所需的工具
 */
export declare const i18n: {
    /**
     * 当前用户的国际化语言，已知语言：
     *  - `zh` 中文
     *  - `en` 英文
     */
    lng: string;
    /**
     * 当前用户的国际化语言，已知语言：
     *  - `zh` 中文
     *  - `en` 英文
     */
    lang: string;
    /**
     * 当前用户所在站点
     *  - `1` 表示国内站；
     *  - `2` 表示国际站；
     *
     * @type {1 | 2}
     */
    site: number;
    /**
     * 注册国家
     */
    country: {
        name: string;
        code: string;
    };
    /**
     * 初始化当前语言的国际化配置
     */
    init: ({ lng }: I18NInitOptions) => void;
    /**
     * 标记翻译句子
     * 详细的标记说明，请参考 http://tapd.oa.com/tcp_access/markdown_wikis/0#1020399462009480783
     */
    t: (sentence: string, options?: I18NTranslationOptions) => string;
};
