/**
 * 统一处理接入层请求云 API 的参数结构
 *
 * @param {any} params 原始参数
 * @param {any} opts 配置项
 * @returns {any} 处理之后的数据
 */
export declare function formatApiParams(params: any, opts: any): Promise<any>;
