/**
 * number 型的 regionId 转换成字符串型的 region
 * 如：1 -> ap-guangzhou
 * @param regionId 数字型的 regionId
 * @returns 对应的 region 字符串
 */
export declare function getRegionByRegionId(regionId: number): Promise<any>;
/**
 * 字符串型的 region 转换成 number 型的 regionId
 * 如：ap-guangzhou -> 1
 * @param region
 * @returns 对应的 regionId
 */
export declare function getRegionIdByRegion(region: string): Promise<any>;
export declare function getRegionIdMap(): any;
