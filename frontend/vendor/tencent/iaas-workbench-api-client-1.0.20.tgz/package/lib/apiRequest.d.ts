import { ApiRequestOptions, ApiRequestParams } from './interface';
/**
 * 云 api 代理
 */
export declare const apiRequest: (params: ApiRequestParams, opts: ApiRequestOptions) => Promise<any>;
