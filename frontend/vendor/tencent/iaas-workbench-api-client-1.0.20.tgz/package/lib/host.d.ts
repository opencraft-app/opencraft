/**
 * 自动适配 tencent.com/tencent.cn/tencent.com.cn 根域名
 */
export declare function generateApiHost(): any;
