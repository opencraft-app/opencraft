/**
 * 通知 api inspector 接口的调用事件
 */
export declare class ApiMessage {
    /**
     * 生成唯一标识此 message 的id
     * 此逻辑移植自 qcloud-console
     * @see：https://git.woa.com/qcloud-developer/qcloud-console/blob/master/web/app/zh/lib/uid-creator.js
     * @returns
     */
    static createMessageId(): string;
    messageId: string;
    constructor();
    /**
     * 通知 api inspector 接口的调用事件
     * @param payload
     */
    postMessage(payload: any): void;
}
