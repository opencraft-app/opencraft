/**
 * 云 api 代理
 * @param {Object} data { serviceType: "vpc", action: "DescribeVpc", regionId: 1, data: {offset:0, limit:10} }
 * @param {Object} [opts] 配置项
 * @return {Promise<Object>}
 */
export declare function apiRequest(data: any, opts: any): Promise<any>;
