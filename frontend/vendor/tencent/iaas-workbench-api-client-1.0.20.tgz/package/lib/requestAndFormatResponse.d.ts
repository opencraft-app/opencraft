import { ApiRequestOptions, ApiRequestParams } from './interface';
export declare function requestAndFormatResponse(params: ApiRequestParams, opts: ApiRequestOptions): Promise<any>;
