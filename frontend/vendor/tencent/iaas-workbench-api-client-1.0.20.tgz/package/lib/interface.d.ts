export interface RequestOptions {
    lid?: string;
    life?: string;
    pid?: string;
    i18n?: string;
    intl?: string;
    isFormData?: boolean;
    isDeepExtendOptions?: boolean;
    onRequestInit?(jqAjax: any): any;
    [propName: string]: any;
}
export interface ApiRequestOptions extends RequestOptions {
    /**
     * 是否将客户端 IP 附加在云 API 的 `clientIP` 参数中
     * @deprecated
     */
    withClientIP?: boolean;
    /**
     * 是否将客户端 UA 附加在云 API 的 `clientUA` 参数中
     */
    withClientUA?: boolean;
    classicResponse?: boolean;
    isChangeResponseToLowerCamelCase?: boolean;
    onCamError?(error: any): any;
    errorHandler?(error: any, options: any, trace?: any): any;
    error?(error: any): any;
    onLoginVerifyFail?(error: any): any;
}
export interface ApiRequestParams {
    action: string;
    serviceType: string;
    regionId?: number;
    region?: string;
    data?: any;
    cgiName?: string;
}
