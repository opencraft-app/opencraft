export declare const API_HOST: any;
export declare const REGION_ID_MAP_LOCALSTORAGE_KEY = "_iaas_region_id_map_";
export declare const REGION_ID_MAP_BACKUP: {
    1: string;
    4: string;
    5: string;
    6: string;
    7: string;
    8: string;
    9: string;
    11: string;
    12: string;
    15: string;
    16: string;
    17: string;
    18: string;
    19: string;
    21: string;
    22: string;
    23: string;
    24: string;
    25: string;
    31: string;
    32: string;
    33: string;
    34: string;
    35: string;
    36: string;
    37: string;
    39: string;
    45: string;
    46: string;
    53: string;
    54: string;
    55: string;
    56: string;
    57: string;
    58: string;
    71: string;
    72: string;
    73: string;
    74: string;
    76: string;
};
/**
 * IE11 浏览器使用 iframe 模式进行跨域请求
 * 搜狗浏览器IE11兼容模式下，对CORS方式的跨域ajax处理有bug，会报算术结果超过 32 位的错误，通过内嵌iframe实现跨域请求的方式无此问题
 * 所以对IE11浏览器采用内嵌 iframe 方式进行跨域
 */
export declare const IS_USE_IFRAME_MODE: boolean;
