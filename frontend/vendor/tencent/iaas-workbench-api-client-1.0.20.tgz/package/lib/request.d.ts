import { RequestOptions } from './interface';
/**
 * 请求 iaas.qcloud.com
 * @param {String} url 请求 endpoint
 * @param {Object} param 请求参数
 * @param {Object} [opts] 配置项
 * @param {Boolean} opts.classicResponse=true 是否使用经典的 json 回包(code=0, 表示成功, 其他表示失败)
 */
export declare function request(apiUrl: any, param: any, opttions?: RequestOptions): Promise<any>;
