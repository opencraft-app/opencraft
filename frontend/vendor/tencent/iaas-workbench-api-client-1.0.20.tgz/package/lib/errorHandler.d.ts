import { ApiRequestOptions } from './interface';
export declare function errorHandler(error: any, opts?: ApiRequestOptions, trace?: any): Promise<void>;
