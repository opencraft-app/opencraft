export declare function isCamRefused(e: any): boolean;
