import { ApiRequestParams } from './interface';
/**
 * 云API请求
 * 入参 data内字段 请全部大写
 * 出参 全部大写，不再转换
 * @param {*} param0
 * @param {*} opts
 */
export interface IRequestParam {
    action: string;
    data?: any;
    regionId?: number;
    region?: string;
}
export interface ICapiRequestParam extends IRequestParam {
    serviceType: string;
    tcbRequest?: boolean;
}
/**
 * iaas请求 设置
 */
export interface IRequestOpts {
    /** 是否显示全局加载条 默认true */
    global?: boolean;
    /** 是否显示失败提示 默认true */
    tipErr?: boolean;
    /** 是否使用经典的 json 回包(code=0, 表示成功, 其他表示失败) 默认true */
    classicResponse?: boolean;
    camTips?: boolean;
    camTipsType?: string;
}
/**
 * 云API请求
 * @param serviceType 业务缩写
 * @param action 云API方法
 * @param data 接口入参
 * @param regionId 请求地域 地域数字ID
 */
export declare function iframeModeCapiRequest({ cgiName, serviceType, action, data, region, regionId }: ApiRequestParams, opts?: IRequestOpts): Promise<any>;
