export declare function getCookie(name: any): string;
/**
 * 从cookie中获取 uin
 * @returns
 */
export declare function getUin(): any;
/**
 * 生成简易 guid
 * @returns
 */
export declare function createGuid(): string;
/**
 *
 * @returns
 */
export declare function getACSRFToken(): number | "";
export declare function queryToObj(url: any): any;
export declare function isObject(obj: any): boolean;
/**
 * 将对象 key 转换成大驼峰或小驼峰
 * @param source 原始对象
 * @param type 转换类型  upper(大驼峰) | lower(小驼峰)
 * @param notChangeAllUppercaseFeild 是否转换全为大写字符的 key
 * @returns
 */
export declare function changeLetterCaseFirstLetter(source: any, type: any, notChangeAllUppercaseFeild: any): any;
