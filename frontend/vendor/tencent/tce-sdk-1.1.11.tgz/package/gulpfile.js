/* eslint-disable */
var gulp = require('gulp');
var del = require('delete');
var rollup = require('rollup');
var fs = require('fs');
var babel = require('rollup-plugin-babel');
var resolve = require('rollup-plugin-node-resolve');
var commonjs = require('rollup-plugin-commonjs');
var { DEFAULT_EXTENSIONS } = require('@babel/core');
var rollupTypescript = require('rollup-plugin-typescript2');
var browserSync = require('browser-sync').create(),
  reload = browserSync.reload;
var { uglify } = require('rollup-plugin-uglify');
var json = require('@rollup/plugin-json');
const esbuild = require('esbuild');

var builtins = require('rollup-plugin-node-builtins');
var globals = require('rollup-plugin-node-globals');
var replace = require('@rollup/plugin-replace');
var package = require('./package.json');
var { visualizer } = require('rollup-plugin-visualizer');
var alias = require('@rollup/plugin-alias');

// 纯净版的情况下，只打包一个index.js及去掉babel，从TCE3.10.0及TCS234开始
var isPure = process.env.NODE_ENV === 'pure';
// 是否是 CI 环境，如果为 true 则不打包dts
var isCi = process.env.NODE_ENV === 'ci';


const rollupBuildTs = async (entry, outDir, moduleName) => {
  return rollup
    .rollup({
      onwarn: function (warning) {
        // Skip certain warnings

        // should intercept ... but doesn't in some rollup versions
        if (warning.code === 'THIS_IS_UNDEFINED') {
          return;
        }

        // console.warn everything else
        console.warn(warning.message);
      },
      input: entry,
      // plugins 需要注意引用顺序
      plugins: [
        replace({
          preventAssignment: true,
          VERSION: package.version,
          delimiters: ['{{', '}}'],
        }),
        builtins(),
        // 使得 rollup 支持 commonjs 规范，识别 commonjs 规范的依赖
        alias({
          entries: [
            { find: 'axios', replacement: 'node_modules/axios/dist/axios.min.js' }  // 正确指定 UMD 版本
          ]
        }),
        commonjs(),
        globals(),
        resolve({ preferBuiltins: false, mainFields: ['browser'] }),
        rollupTypescript({ useTsconfigDeclarationDir: true, tsconfig: isCi ? 'tsconfig.ci.json' : 'tsconfig.json' }),
        babel({
          runtimeHelpers: true,
          // 只转换源代码，不运行外部依赖
          exclude: 'node_modules/**',
          // babel 默认不支持 ts 需要手动添加
          extensions: [...DEFAULT_EXTENSIONS, '.ts'],
        }),
        json(),
        ...[uglify()],
        // visualizer()
      ],
      external: ['jsencrypt', '@tencent/tce-cam-sdk'],
    })
    .then((bundle) => {
      return bundle.write({
        file: outDir,
        format: 'umd',
        freeze: false,
        name: moduleName,
        globals: {
          jsencrypt: 'JSEncrypt',
          '@tencent/tce-cam-sdk': 'CAMSDK',
          '@tencent/tce-auth-sdk': 'AUTHSDK',
        },
      });
    })
    .then(() => {
      reload({ stream: true });
    });
};

const rollupBuildCommon = () => {
  return Promise.all([
    rollupBuildTs('./src/common/country.ts', 'lib/assets/country/country.js', 'country'),
    rollupBuildTs('./src/common/location_en_us.ts', 'lib/assets/location/location_en_us.js', 'provinceMap_en_us'),
    rollupBuildTs('./src/common/location_zh_cn.ts', 'lib/assets/location/location_zh_cn.js', 'provinceMap_zh_cn'),
  ]);
};

const rollupBuild = () => {
  const dir = fs.readdirSync('./src');
  return Promise.all(
    dir.map((file) => {
      if (file === 'index.ts') {
        return rollupBuildTs('./src/index.ts', './lib/index.js', 'tcesdk');
      } else {
        if (file === 'common') return rollupBuildCommon();
        if (!isPure) {
          return rollupBuildTs(`./src/${file}/index.ts`, `./lib/${file}/index.js`, 'tcesdk');
        }
      }
    }),
  );
};

const rollupBuildPure = () => {
  const dir = fs.readdirSync('./src');
  return rollupBuildTs('./src/index.ts', './lib/index.pure.js', 'tcesdk');
};

const delFiles = (done) => {
  del(['lib']);
  done();
};

const copyAssets = (done) => {
  gulp.src('assets/**/*').pipe(gulp.dest('lib/assets'));
  gulp.src('node_modules/@tencent/tce-moment/dist/moment.min.js').pipe(gulp.dest('lib/assets/moment'));
  done();
};

const browserServer = (done) => {
  browserSync.init({
    server: {
      baseDir: './',
      index: './lib/index.js',
    },
  }),
    gulp.watch('./src/**/*.ts', gulp.series(rollupBuild));
  done();
};

const ESBuildSeries = (done) => {
  esbuild.build({
    entryPoints: ['./src/index.ts'],
    outdir: 'dest',
    bundle: true,
    // sourcemap: true,
    // minify: true,
    format: 'iife',
    globalName: 'tcesdk',
  });
  done();
};
const browserESBuildServer = (done) => {
  browserSync.init({
    server: {
      baseDir: './',
      index: './dest/index.js',
    },
  }),
    gulp.watch('./src/**/*.ts', gulp.series(ESBuildSeries));
  done();
};

gulp.task('default', gulp.series(rollupBuild, browserServer));
gulp.task('build', gulp.series(delFiles, rollupBuild, copyAssets));
gulp.task('build:pure', gulp.series(rollupBuildPure));
gulp.task('esbuild', gulp.series(ESBuildSeries, browserESBuildServer));
