export default function jsencrypt(publicKey: string, plaintext: string): string;
