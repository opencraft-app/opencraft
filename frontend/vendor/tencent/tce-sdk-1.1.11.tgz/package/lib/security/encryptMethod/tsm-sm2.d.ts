export default function tsm_sm2(publicKey: string, plaintext: string): any;
