export default function kms_sm2(publicKey: string, plaintext: string): any;
