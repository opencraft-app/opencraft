interface EncryptFunctionByMethod {
    [x: string]: {
        libraryName: string;
        assetUrl: () => string;
        encryptFunction: (publicKey: string, plaintext: string) => string;
    };
}
export declare const ciphertextPrefix = "TCESECURITY";
/**
 * 组装密文信息
 * @param ciphertext 密文
 * @param method 加密方式
 * @param version 版本号
 */
export declare function generateEncryptText(ciphertext: string, method: string, version: string): string;
export declare const encryptFunctionByMethod: EncryptFunctionByMethod;
export declare const utils: {
    /**
     * 获取 skey
     */
    getSessionKey(): string | null;
    /**
     * 获取加密库js地址
     * @param encryptType 加密方式
     * @returns url
     */
    getEncryptLibJsUrl(encryptType: string): string;
};
export {};
