/**
 * 加密明文
 * @param plaintext 明文
 * @param defaultText 默认值【环境没有配置加密方式的情况下默认返回的内容】
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE >= 3.10.0
 * @version TCS ❌
 */
export declare function encrypt(plaintext: string, defaultText?: string): Promise<string | false>;
/**
 * 获取防CSRF串
 * @method getCSRFToken
 * @return {String} 验证串
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.1.0
 */
export declare function getCSRFToken(): string;
/**
 * 打开水印
 * @param content 水印内容
 * @returns
 */
export declare function openWaterMask(content: string): Promise<void>;
