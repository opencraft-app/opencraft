/** 将一个对象或数组里的对象的 key 的首字母转为转为小写的泛型 */
export declare type TransformFirstLetterToLowerCase<T> = T extends Array<infer V> ? V extends object ? TransformFirstLetterToLowerCase<V>[] : V[] : T extends object ? {
    [K in keyof T as Uncapitalize<K & string>]: TransformFirstLetterToLowerCase<T[K]>;
} : T;
/** 将一个对象或数组里的对象的 key 的首字母转为转为大写的泛型 */
export declare type TransformFirstLetterToUpperCase<T> = T extends Array<infer V> ? V extends object ? TransformFirstLetterToUpperCase<V>[] : V[] : T extends object ? {
    [K in keyof T as Capitalize<K & string>]: TransformFirstLetterToUpperCase<T[K]>;
} : T;
/**
 * 将对象 或数组里的对象的 key 的首字母转为小写，且不侵入原对象
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.10.0
 * @version TCE登录页 ❌
 * @version TCS ❌
 * @export
 * @template T 泛型
 * @param {T} objOrArr 对象或数组对象
 * @param {boolean} [notChangeAllUppercaseField=false] field都是大写的是否选择不转换，比如「CPU」
 * @returns {TransformFirstLetterToLowerCase<T>}
 */
export declare function transformFirstLetterToLowerCase<T = any>(objOrArr: T, notChangeAllUppercaseField?: boolean): TransformFirstLetterToLowerCase<T>;
/**
 * 将对象 或数组里的对象的 key 的首字母转为大写，且不侵入原对象
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.10.0
 * @version TCE登录页 ❌
 * @version TCS ❌
 * @export
 * @template T
 * @param {T} objOrArr
 * @returns {TransformFirstLetterToUpperCase<T>}
 */
export declare function transformFirstLetterToUpperCase<T = any>(objOrArr: T): TransformFirstLetterToUpperCase<T>;
/**
 * 截取message中的IP
 * @export
 * @param {string} message
 * @returns
 */
export declare function getMessageIP(message: string): string;
export declare function yunapi3ResponseHandle(response: any): any;
export declare function printYapiErrorLog(url: any, req: any, res: any, interfaceName: any): void;
export declare function getYapiUrl(): string;
export declare function getQueryString(query: any): string;
export declare function yapiIsCancel(value: any): boolean;
export declare const CommonErrorCode: {
    /**
     * CAM没有授权
     */
    UnauthorizedOperation: string;
};
export declare const jiguangCouldReloadPage: () => boolean;
/**
 * 根据代码格式化消息。
 * @param code 字符串形式的代码。
 * @param message 要格式化的消息。
 * @returns 格式化后的消息。
 */
export declare const code2Message: (code: string, message: string) => string;
