import { AxiosRequestConfig } from 'axios';
import { Region } from '../region';
export interface Error<T = object> {
    code: string;
    message: string;
    requestId: string;
    data?: T;
    [x: string]: any;
}
export interface IResHandlerParam<T extends object> {
    res: IAPIResponse<T>;
    serviceType: string;
    action: string;
}
export interface IAPIResponse<T extends object> {
    /**
     * 接口返回的业务数据
     */
    res: T;
    /**
     * 接口失败返回的错误对象，err不为null表示接口失败了
     */
    err?: Error;
    /**
     * 接口的原始出参，未经处理的数据
     */
    rawResponse?: any;
}
export interface IAPIRequest<T extends object = object> {
    /**
     * 接口分类【产品】
     */
    serviceType: string;
    /**
     * 接口名
     */
    action: string;
    /**
     * 当前地域，可以不填，默认为当前地域
     */
    region?: string;
    /**
     * 当前语言，可以不填，默认为当前语言
     */
    language?: string;
    /**
     * 接口需要的业务入参，不需要入参的时候不用
     */
    data?: T;
    /**
     * V3接口需要的版本
     */
    version: string;
    /**
     * url后的query
     */
    query?: {
        [key: string]: string;
    };
}
export declare function getAllRegionListAsync(): Promise<Region[]>;
export declare function getCurrentRegionAsync(): Promise<Region>;
/**
 * 请求云api接口 【只支持V3接口】
 * @template T 入参泛型
 * @template U 出参泛型
 * @param {IAPIRequest<T>} body 入参包体
 * @param {string} body.serviceType 接口分类【产品】
 * @param {string} body.action 接口名
 * @param {string} body.version 接口版本号
 * @param {string} body.region ?当前地域，可以不填，默认为当前地域
 * @param {string} body.language ?当前语言，可以不填，默认为当前语言
 * @param {T} body.data<T> ?接口需要的业务入参，不需要入参的时候不用
 * @param {Partial<AxiosRequestConfig>} options yapi可选配置
 * @returns {Promise<IAPIResponse<U>>} {Promise<{ res: U, err: { code, message } }>}
 */
/**
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.8.0
 * @version TCE、TCS登录页 ❌
 * @version TCS控制台 >= 2.1.0
 */
export declare function yApiRequest<T extends object = object, U extends object = object>(body: IAPIRequest<T>, options?: Partial<AxiosRequestConfig>): Promise<IAPIResponse<U>>;
