export declare const cancelToken: import("axios").CancelTokenStatic;
export declare const yApiAxios: import("axios").AxiosInstance;
