/**
 * 路由跳转
 * @param path 跳转路径
 */
export declare function navigate(path: string): void;
