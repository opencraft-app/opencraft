/**
 * 获取当前环境所有的域名信息
 */
export interface TceDomain {
    /**
     * 登录域名
     */
    login?: string;
    /**
     * 主域
     */
    base?: string;
    /**
     * 租户端域名
     */
    tenantConsole?: string;
    /**
     * 官网域名
     */
    officialWebsite?: string;
    /**
     * 购买页域名
     */
    buy?: string;
    /**
     * imgcache域名
     */
    imgcache?: string;
    /**
     * cos域名
     */
    cos?: string;
    /**
     * csp域名
     */
    csp?: string;
    /**
     * qcbase域名
     */
    qcbase?: string;
    /**
     * 控制台域名
     */
    console?: string;
    /**
     * 文档域名
     */
    doc?: string;
    /**
     * 云api地址
     */
    yapiUrl?: string;
}
/**
 * 获取域名列表
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.1.0
 */
export declare function getDomainList(): TceDomain;
/**
 * 替换域名
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 ❌
 * @version TCS ❌
 */
export declare function replaceDomainInStr(str: string): string;
