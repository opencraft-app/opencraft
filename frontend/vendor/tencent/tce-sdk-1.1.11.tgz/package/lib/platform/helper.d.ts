import { ICurrentAccess } from 'src/common/types';
import { DescribeRegionZoneResProduct } from 'src/region';
/**
 * 通用前端组件
 */
export declare const PLATFORM_COMMON_COMPONENT: {
    /**
     * tce-js-sdk
     */
    TCESDK: string;
    /**
     * 前端通用js
     */
    CORE: string;
    /**
     * 平台js
     */
    PLATFORM: string;
};
/**
 * 组件对应version地址
 */
export declare const componentVersionPathMap: () => {
    [x: string]: string;
};
/**
 * 组件信息
 */
export interface IComponentInfo {
    /**
     * 组件名称
     */
    productName: string;
    /**
     * git分支名
     */
    branch: string;
    /**
     * git-commitId
     */
    commitId: string;
    /**
     * 构建时间
     */
    buildTime: string;
    /**
     * 部署时间
     */
    deployTime: string;
    /**
     * 页面接入信息[通用组件没有接入信息]
     */
    pageAccessInfo?: ICurrentAccess;
}
/**
 * 异步获取version信息
 * @export
 * @param {string} versionPath
 * @returns
 */
export declare function fetchVersionJson(versionPath: string): Promise<{
    branch: any;
    commitId: any;
    buildTime: any;
    deployTime: any;
    productName: any;
} | undefined>;
/**
 * 获取overview的version——path
 */
export declare function getOverviewVersionPath(): string;
/**
 * 获取通用组件的version——path
 */
export declare function getCommonVersionPath(path: string): string;
export declare function getDeliverProductListCache(region?: string): DescribeRegionZoneResProduct;
export declare function setDeliverProductListCache(deliverProductList: DescribeRegionZoneResProduct, region?: string): void;
export declare function clearDeliverProductListCache(): void;
