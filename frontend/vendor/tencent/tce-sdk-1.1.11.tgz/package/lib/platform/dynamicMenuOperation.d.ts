/**
 * 根据platformCode, 得到对应的platform, modules, menus信息
 * @param platformCode
 */
import { IAPIResponse } from '../api';
export interface IMenu {
    id: string;
    module: string;
    name: string;
    icon?: string;
    iconActive?: string;
    href: string;
    headline: boolean;
    order: number;
    menus?: IMenu[];
    /**
     * 打开形式
     * page 新页面打开
     * category 路由形式
     */
    openType?: 'page' | 'category';
    defaultDeliver?: boolean;
    isCustomized?: boolean;
    modified?: boolean;
    platform: string;
    platformCode: 'tab_ocloud_manager' | 'tab_ocloud_pass' | 'tab_ocloud_application' | 'tab_ocloud_user';
}
interface AddMenuProps {
    menuName: string;
    headline?: boolean;
    href: string;
    platformCode: string;
    moduleId: string;
}
interface RemoveMenuProps {
    href: string;
    platformCode: string;
    moduleId: string;
}
/**
 * DrawSwitches接口入参定义
 */
export interface DrawSwitchesReq {
    /**
     * input
     */
    Params: DrawSwitchesParams[];
}
/**
 * DrawSwitchesParams
 */
export interface DrawSwitchesParams {
    /**
     * key命名
     */
    Key: string;
    /**
     * value
     */
    Value: string;
    /**
     * ns
     */
    Namespace: string;
    /**
     * 描述
     */
    Description?: string;
}
/**
 * 菜单名
 * @param menuName
 * 是否在顶部展示
 * @param headline
 * 菜单路径
 * @param href
 * 菜单所属平台code
 * @param platformCode
 * 所属产品Id
 * @param moduleId
 */
export declare const addMenu: ({ menuName, headline, href, platformCode, moduleId }: AddMenuProps) => Promise<IAPIResponse<any>> | "missing parameter" | "can not find menus by moduleId";
/**
 * 删除的链接
 * @param href
 * 菜单所属平台code
 * @param platformCode
 * 所属产品Id
 * @param moduleId
 */
export declare const removeMenu: ({ href, platformCode, moduleId }: RemoveMenuProps) => Promise<IAPIResponse<any>> | "missing parameter";
export {};
