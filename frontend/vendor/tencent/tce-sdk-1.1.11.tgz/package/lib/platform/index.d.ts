import { getCurrentPlatform } from '../common';
import { toLoginPageForExpired, showPreLoginModal } from '../common/modal';
import { getComponentCommitId } from 'src/common/customize';
import { IComponentInfo, PLATFORM_COMMON_COMPONENT } from './helper';
/**
 * 客制化logo信息
 */
interface CustomizeLogo {
    favicon: string;
    mainLogo: string;
}
export * from './dynamicMenuOperation';
/**
 * 平台类型
 */
export { PLATFORM_TYPE } from '../common';
/**
 * 获取当前平台类型
 */
export { getCurrentPlatform, getComponentCommitId };
/**
 * 获取客制化版本
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS ❌
 */
export declare function getCustomizeVersion(): any;
/**
 * 退出登录
 * @version TCE控制台、购买页 >= 3.10.0
 * @version TCE登录页 ❌
 * @version TCS ❌
 */
export declare function logout(): void;
/**
 * 获取平台logo信息【浏览器favicon及控制台主logo】
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.3.4.0.0
 */
export declare function getCustomizeLogo(): CustomizeLogo;
/**
 * 获取平台Title信息
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.3.4.0.0
 */
export declare function getCustomizeTitle(): string;
/**
 * 获取前端组件信息
 * @export
 * @param {string} [urlPath] 默认为当前页面
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.8.0
 * @version TCE登录页 ❌
 * @version TCS ❌
 */
export declare function getFrontendComponentInfo(urlPath?: string): Promise<IComponentInfo | undefined>;
/**
 * 获取全局变量
 * 默认先从TCE_GLOBAL_CONSTANT中获取，获取不到再从TCS下面获取，最后再从window下获取
 */
export declare function getGlobalVariable(key: string): any;
interface IProductInfo {
    productCode: string;
}
export interface DeliverProductInfo {
    productCode: string;
    subProduct: IProductInfo[];
}
/**
 * 获取交付产品列表
 * @param region region名称【比如：chongqing】
 */
export declare function getDeliverProductList(region?: string): Promise<DeliverProductInfo[]>;
export interface ICheckProductDeliverParam {
    /**
     * region名称【比如：chongqing】
     */
    region?: string;
    /**
     * 产品code
     */
    productCode: string;
    /**
     * 子产品code
     */
    subProductCode?: string;
}
/**
 * 检查产品是否已经交付
 * @param param ICheckProductDeliverParam
 */
export declare function checkProductDeliver(param: ICheckProductDeliverParam): Promise<boolean>;
export { PLATFORM_COMMON_COMPONENT, IComponentInfo, toLoginPageForExpired, showPreLoginModal };
/**
 * 判断是否开启换肤功能
 */
export declare function isUseCustomizeTheme(): boolean;
/**
 * 获取静态资源路径
 */
export declare function getCustomizeThemePath(): string;
