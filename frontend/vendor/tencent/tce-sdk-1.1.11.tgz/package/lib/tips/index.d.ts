/**
 * 显示loading
 * @param text loading文本
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.10.0
 * @version TCE、TCS登录页、购买页 ❌
 * @version TCS控制台 >= 2.3.0
 */
export declare function showLoading(text?: string): void;
/**
 * 隐藏loading
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.10.0
 * @version TCE、TCS登录页、购买页 ❌
 * @version TCS控制台 >= 2.3.0
 */
export declare function hideLoading(): void;
/**
 * 成功提示
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.10.0
 * @version TCE、TCS登录页、购买页 ❌
 * @version TCS控制台 >= 2.3.0
 * @param text 提示内容
 * @param duration 持续时间，默认为4秒
 */
export declare function success(text: string, duration?: number): void;
/**
 * 失败提示
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.10.0
 * @version TCE、TCS登录页、购买页 ❌
 * @version TCS控制台 >= 2.3.0
 * @param text 提示内容
 * @param duration 持续时间，默认为4秒
 */
export declare function error(text: string, duration?: number): void;
