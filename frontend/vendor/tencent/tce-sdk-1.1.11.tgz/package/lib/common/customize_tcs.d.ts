import { ICurrentAccess, ICustomizeAccess, ICustomizeAccessTab } from './types';
/**
 * 获取产品接入tabs【控制台顶部导航】
 */
export declare function getCustomizeAccessTabs(): ICustomizeAccessTab[];
/**
 * 根据路由key获取接入信息
 * @param routerKey 路由key
 */
export declare function getCustomizeAccessInfoByRouterKey(routerKey: string): ICustomizeAccess | undefined;
/**
 * 根据当前页面接入信息
 * @export
 * @param {string} [urlPath] urlPath 默认为当前页面的urlPath
 * @returns {(ICurrentAccess | undefined)}
 */
export declare function getCurrentPageAccessInfo(urlPath: string): ICurrentAccess | undefined;
