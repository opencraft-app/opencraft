export declare function resetSourceCache(): void;
export declare function getSource(url: string): Promise<void>;
/**
 * 字符串转16进制
 * @param str 字符串
 */
export declare function str2hex(str: string): string;
/**
 * 包装location
 */
export declare const loc: {
    setLocationHref(newHref: string): void;
    getLocationHref(): string;
    getLocationPath(): string;
    locationReload(): void;
};
declare function getTceSdkAssetsBasePath(): string;
/**
 * 获取tcesdk加载外部的静态资源
 */
export declare const assets: {
    getTceSdkAssetsBasePath: typeof getTceSdkAssetsBasePath;
    getXlsxUrl(): string;
    getCryptoJSUrl(): string;
    getJsencryptUrl(): string;
    getSMUrl(): string;
    getWaterMarkUrl(): string;
};
/**
 * 获取客制化产品及菜单的icon
 * @param icon 源icon
 * @param type 'type' | 'product' | 'menu'
 * @param uuid 菜单或产品的唯一ID
 * @returns
 */
export declare function getCustomizeIcon(icon: string, type: 'type' | 'product' | 'menu', uuid: string): string;
/**
 *  获取客制化产品及菜单的icon【激活状态】
 * @param icon 源icon
 * @param type 'type' | 'product' | 'menu'
 * @param iconActive 源激活态icon
 * @returns
 */
export declare function getCustomizeActiveIcon(icon: string, iconActive: string): string;
/**
 * 获取完整url地址
 * @param url 原始url
 * @param imgcache imgcache域名
 * @param base 主域
 * @returns
 */
export declare function getFullAssetUrl(url: string | string[], imgcache: string, base: string): string | string[];
export {};
