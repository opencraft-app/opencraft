export declare const MODAL: {
    show: (config: any) => void;
    hide: () => void;
    showPreLoginModal: (message: any, description: any, callback: any) => void;
};
/**
 * 针对iframe这种登录态过期重新回到登录页面
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE购买页 >= 3.10.0
 * @version TCE、TCS登录页 ❌
 * @version TCS控制台 >= 2.1.0
 */
export declare function toLoginPageForExpired(): void;
/**
 * 显示进入登录页面的Modal
 * @param message 标题
 * @param description 的描述信息
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.8.0
 * @version TCE、TCS登录页 ❌
 * @version TCS控制台 >= 2.1.0
 */
export declare function showPreLoginModal(message: string, description: string): void;
