import { CamProps, AuthProps, MonitorProps, CbsProps, StandAloneProps, UMANAGEProps, ANNOUNCEProps, ApprovalProps, GroupAccountProps, PLATFORMSDKProps } from '@tencent/types-tce-sdk-component';
/**
 * tcesdk动态加载静态资源的路径
 */
export declare const TCESDK_ASSETS_BASE_PATH = "common/tcesdk/assets";
/**
 * tcesdk动态加载静态资源的路径[TCS场景下，静态资源的模块是tcs-common开头的]
 */
export declare const TCESDK_ASSETS_BASE_PATH_FOR_TCS = "tcs-common/tcesdk/assets";
/**
 * 语言类型
 */
export declare const LANGUAGE_TYPE: {
    /**
     * 中文
     */
    ZH_CN: string;
    /**
     * 英文
     */
    EN_US: string;
};
/**
 * 平台类型
 */
export declare const PLATFORM_TYPE: {
    /**
     * tce租户端控制台
     */
    TCE_TCLOUD: string;
    /**
     * tce运营端控制台
     */
    TCE_OCLOUD: string;
    /**
     * tcs运营端控制台
     */
    TCS_OCLOUD: string;
    /**
     * tcs租户端控制台
     */
    TCS_TCLOUD: string;
    /**
     * jiguang平台
     */
    JIGUANG: string;
    /**
     * tce租户端购买页
     */
    TCE_TCLOUD_BUY: string;
    /**
     * tce租户端登录页
     */
    TCE_TCLOUD_LOGIN: string;
    /**
     * tce运营端登录页
     */
    TCE_OCLOUD_LOGIN: string;
    /**
     * tcs运营端登录页
     */
    TCS_OCLOUD_LOGIN: string;
};
export interface ComponentType {
    'cam-sdk': CamProps;
    'auth-sdk': AuthProps;
    'tag-sdk': any;
    'sg-sdk': any;
    'tsm-sdk': any;
    'monitor-v2-sdk': any;
    'monitor-v3-sdk': any;
    'cls-sdk': any;
    'standalone-sdk': StandAloneProps;
    'monitor-sdk': any;
    'cwhistle-sdk': MonitorProps;
    'approval-sdk': ApprovalProps;
    'cbs-sdk': CbsProps;
    'platform-sdk': PLATFORMSDKProps;
    'announce-sdk': ANNOUNCEProps;
    'umanage-sdk': UMANAGEProps;
    'project-sdk': GroupAccountProps;
    'csip-sdk': any;
    'inspector-sdk': any;
    'menus-sdk': any;
    'region-sdk': any;
    'organization-sdk': any;
    'tce-monitor-sdk': any;
    'edge-vnc': any;
    'billing-sdk': any;
}
export declare type ComponentMap = {
    [name in keyof ComponentType]?: {
        /**
         * 组件打包出来的的library名
         */
        libraryName?: string;
        /**
         * 组件静态资源的js地址
         */
        content: string;
        /**
         * 组件静态资源的css地址
         */
        css?: string[];
        /**
         * 业务sdk中用于判断sdk类型以加载依赖
         */
        component?: string;
        /**
         * 对应的前端组件名称【可用于获取组件对应的commitId】
         */
        componentName: string;
    };
};
export declare const getSdkRouterMap: () => ComponentMap;
export declare const JIGUANG_LOGIN_EXPIRED_RELOAD_TIME_STORAGE = "JIGUANG_LOGIN_EXPIRED_RELOAD_TIME";
