import { ICustomizeAccessTab } from './types';
export declare function getCustomizeAccessTabs(navData: any[]): ICustomizeAccessTab[];
