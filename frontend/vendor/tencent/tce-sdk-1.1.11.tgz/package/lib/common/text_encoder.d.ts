declare function TextEncoder(): void;
export { TextEncoder };
