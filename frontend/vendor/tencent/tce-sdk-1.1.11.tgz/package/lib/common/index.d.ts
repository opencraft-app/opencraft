/**
 * 通用的私有方法，不对方暴露
 */
import { BaseUserInfo } from '../user';
import { Language } from '../language';
import { Region } from '../region';
import { FoyoConfig, TransportSecret } from '../config';
import { LANGUAGE_TYPE, PLATFORM_TYPE, TCESDK_ASSETS_BASE_PATH, ComponentMap, getSdkRouterMap, ComponentType } from './constants';
import { getSource, resetSourceCache, str2hex, loc, assets as tcesdkAssets } from './util';
export interface Title {
    [x: string]: string;
}
export interface TCE_GLOBAL_CONSTANT {
    /**
     * 平台类型
     */
    platformType?: string;
    /**
     * 登录域名
     */
    loginHost?: string;
    /**
     * 主域
     */
    baseHost?: string;
    /**
     * 官网域名
     */
    officialWebsiteHost?: string;
    /**
     * 购买页域名
     */
    buyHost?: string;
    /**
     * imgcache域名
     */
    imgcacheHost?: string;
    /**
     * cos域名
     */
    cosDomain?: string;
    /**
     * csp域名
     */
    cspDomain?: string;
    /**
     * 租户端控制台域名
     */
    tenantConsoleDomain?: string;
    /**
     * qcbase域名
     */
    qcbaseHost?: string;
    /**
     * 控制塔域名
     */
    consoleHost?: string;
    /**
     * 云api地址
     */
    yapiUrl?: string;
    /**
     * 传输加密信息
     */
    transportSecret?: TransportSecret;
    /**
     * 配置中心配置
     */
    foyoConfig?: FoyoConfig[];
    /**
     * title信息
     */
    title?: Title | string;
    /**
     * 支持的语言列表
     */
    languageList?: Language[];
    /**
     * 规划中支持的语言列表
     */
    planLanguageList?: Language[];
    /**
     * 弹性变量配置列表
     */
    elasticConfig?: any;
    /**
     * 客制化全局配置
     */
    customizeGlobalConfig?: any;
    /**
     * csrfCode
     */
    csrfCode?: string;
    /**
     * 内部主域 多域名的支持
     */
    innerMainDomain?: string | string[];
    /**
     * themeCode
     */
    themeCode?: string;
    /**
     * themeAssetsPath
     */
    themeAssetsPath?: string;
    staticAssets?: {
        tcesdk?: {
            path?: string;
        };
    };
    /**
     * 登录建模数据 用于组合交付下定制登录页面
     */
    loginCustomizeInfo?: any;
}
export interface TCE_GLOBAL_CONSTANT_ASYNC {
    regionList?: Region[];
    sdk?: object;
}
/**
 * 获取平台异步获取的常量
 */
export declare function getGlobalConstantsAsync(): TCE_GLOBAL_CONSTANT_ASYNC;
/**
 * 获取平台所有的全局常量
 */
export declare function getGlobalConstants(): TCE_GLOBAL_CONSTANT;
/**
 * 判断是否为TCE运营端控制台
 */
export declare function isTceOcloud(): boolean;
/**
 * 判断是否为TCE运营端登陆页
 */
export declare function isTceOcloudLogin(): boolean;
/**
 * 判断是否为TCE租户端控制台
 */
export declare function isTceTcloud(): boolean;
/**
 * 判断是否为TCS运营端控制台
 */
export declare function isTcsOcloud(): boolean;
/**
 * 判断是否为TCS租户端控制台
 */
export declare function isTcsTcloud(): boolean;
/**
 * 判断是否为TCS运营端登录
 */
export declare function isTcsOcloudLogin(): boolean;
/**
 * 判断是否为jiguang
 */
export declare function isJiGuang(): boolean;
/**
 * 判断是否为TCE购买页
 */
export declare function isTceTcloudBuy(): boolean;
/**
 * 获取当前平台类型
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.1.0
 */
export declare function getCurrentPlatform(): string | undefined;
/**
 * 获取当前环境的语言列表【会自动根据不同的端来获取不同的数据】
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS ❌
 */
export declare function getLangList(): Language[];
/**
 * 获取客户规划中的语言列表【也就是交付给客户可以支持的语言列表】
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.10.11
 * @version TCE登录页、购买页 >= 3.10.11
 * @version TCS ❌
 */
export declare function getPlanLangList(): Language[];
/**
 * 获取环境当前语言
 * 取值顺序：url,window.I18N_CONFIG.tceLanguage,cookie
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.10.0
 * @version TCE登录页、购买页 ❌
 * @version TCS ❌
 */
export declare function getCurrentLang(): string;
/**
 * 获取平台当前语言下的货币
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.10.0
 * @version TCE登录页 ❌
 * @version TCS ❌
 */
export declare function getCurrentCurrency(): string;
interface CurrencyInfo {
    /**
     * 符号，如“￥”
     */
    symbol: string;
    /**
     * 中文词，如“人民币”
     */
    words: string;
    /**
     * 货币代号，如“CNY”
     */
    code: string;
}
/**
 * 获取平台当前语言下的货币信息
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.10.0
 * @version TCE登录页 ❌
 * @version TCS ❌
 */
export declare function getCurrentCurrencyInfo(): CurrencyInfo;
/**
 * 同步方式获取地域列表，不区分产品
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE、TCS登录页、购买页 ❌
 * @version TCS控制台 >= 2.1.0
 */
export declare function getRegionListSync(): Region[];
/**
 * 获取当前region信息
 * 获取优先级  url or localStorage
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE、TCS登录页、TCE购买页 ❌
 * @version TCS >= 2.1.0
 */
export declare function getCurrentRegion(): Region | undefined;
/**
 * 获取当前登录用户信息
 * @version TCE控制台 >= 3.8.0
 * @version TCE购买页 >= 3.10.0
 * @version TCE、TCS登录页 ❌
 * @version TCS控制台 >= 2.1.0
 */
export declare function getCurrentUserInfo(): BaseUserInfo | undefined;
export { TCESDK_ASSETS_BASE_PATH, PLATFORM_TYPE, LANGUAGE_TYPE, getSource, resetSourceCache, str2hex, loc, ComponentMap, ComponentType, getSdkRouterMap, tcesdkAssets, };
