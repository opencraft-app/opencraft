declare const COUNTRY: {
    _countryCode: {
        EnName: string;
        Name: string;
        IOS2: string;
        IOS3: string;
        Code: string;
    }[];
};
export default COUNTRY;
export declare type CountryAttribute = typeof COUNTRY;
