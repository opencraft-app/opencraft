import { ICustomizeAccessTab, ICurrentAccess, ICustomizeProduct, ICustomizeAccess, ICustomizeAccessMenu, ICustomizeModule, IFlatMenu } from './types';
/**
 * 获取客制化产品的配置【TCE平台适用】
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.10.11
 * @version TCE登录页、购买页 >= 3.10.11
 * @version TCS ❌
 * @param product 产品代码
 * @param platform 平台【'tcloud', 'ocloud', 'common'】
 * @param code 配置代码
 * @return string[]
 */
export declare function getCustomizeProductConfig(product: string, platform: string, code: string): string[];
interface FilterConfig {
    /**
     * 产品code
     */
    product: string;
    /**
     * 平台【'tcloud', 'ocloud', 'common'】
     */
    platform: string;
    /**
     * 配置code
     */
    code: string;
}
/**
 * 将入参中的product、platform、code等信息一并返回，方便处理
 */
interface ConfigItem extends FilterConfig {
    value: string[];
}
/**
 * 获取客制化产品的配置【TCE平台适用】
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS ❌
 * @return ConfigItem[]
 */
export declare function getCustomizeProductConfigMultiple(filters: FilterConfig[]): ConfigItem[];
/**
 * 获取客制化产品接入tab
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.10.0
 * @version TCE登录页 ❌
 * @version TCS >= 2.3.0
 * @export
 * @returns {ICustomizeAccessTab[]}
 */
export declare function getCustomizeAccessTabs(): ICustomizeAccessTab[];
/**
 * 根据路由key获取接入信息
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.10.0
 * @version TCE登录页 ❌
 * @version TCS >= 2.3.0
 * @export
 * @param {string} routerKey 路由key
 * @returns {ICustomizeAccess[]}
 */
export declare function getCustomizeAccessInfoByRouterKey(routerKey: string): ICustomizeAccess | undefined;
/**
 * 根据当前页面接入信息
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.10.0
 * @version TCE登录页 ❌
 * @version TCS >= 2.3.0
 * @export
 * @param {string} [urlPath] urlPath 默认为当前页面的urlPath
 * @returns {(ICurrentAccess | undefined)}
 */
export declare function getCurrentPageAccessInfo(urlPath?: string): ICurrentAccess | undefined;
/**
 * 根据uuid获取产品信息
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.10.0
 * @version TCE登录页 ❌
 * @version TCS ❌
 * @param uuid 产品uuid
 * @returns ICustomizeModule | undefined
 */
export declare function getProductInfoByUUID(uuid: string): ICustomizeModule | undefined;
/**
 * 根据uuid获取菜单信息
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.10.0
 * @version TCE登录页、购买页  ❌
 * @version TCS ❌
 * @param uuid 菜单的uuid
 * @returns ICustomizeAccessMenu | undefined
 */
export declare function getMenuInfoByUUID(uuid: string): ICustomizeAccessMenu | undefined;
/**
 * 获取环境部署的产品列表
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.10.0
 * @version TCE登录页、购买页  ❌
 * @version TCS ❌
 * @returns ICustomizeProduc[]
 */
export declare function getCustomizeProductList(): ICustomizeProduct[];
/**
 * 根据产品code获取产品信息
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.10.0
 * @version TCE登录页、购买页  ❌
 * @version TCS ❌
 * @param productCode 产品code
 * @returns ICustomizeProduc | undefined
 */
export declare function getCustomizeProductByCode(productCode: string): ICustomizeProduct | undefined;
/**
 * 获取客制化产品及菜单icon的完整地址
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.10.0
 * @version TCE登录页、购买页  ❌
 * @version TCS >= 2.3.0
 * @param icon 客制化返回的icon信息
 * @returns url
 */
export declare function getCustomizeIconUrl(icon: string): string;
/**
 * 获取前端组件CommitId
 * @param routerKey 路由key，如果没有路由key的情况，传入组件名称
 */
export declare function getComponentCommitId(routerKey: string): string;
/**
 * 获取所有的菜单信息
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.10.11
 * @version TCE登录页、购买页  ❌
 * @version TCS ❌
 */
export declare function getAllMenus(): IFlatMenu[];
/**
 * 获取客制化产品中的登录建模相关的配置【TCS平台适用】
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 ❌
 * @version TCE登录页、购买页 ❌
 * @version TCS控制台 >= 2.3.5.0
 * @version TCS登录页 >= 2.3.5.0
 * @param code 配置代码 相关配置项可以从window.TCE_GLOBAL_CONSTANT.loginCustomizeInfo中获取
 * @return string | string[] | null
 */
export declare function getCustomizeProductLoginModalConfig(code: string): string | string[] | null;
export {};
