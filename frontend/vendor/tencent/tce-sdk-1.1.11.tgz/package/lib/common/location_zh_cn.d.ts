declare const provinces: ({
    name: string;
    sub: ({
        name: string;
        sub: never[];
        type?: undefined;
    } | {
        name: string;
        sub: {
            name: string;
        }[];
        type: number;
    } | {
        name: string;
        sub?: undefined;
        type?: undefined;
    })[];
    type: number;
} | {
    name: string;
    sub?: undefined;
    type?: undefined;
})[];
export default provinces;
export declare type ProvinceMap = typeof provinces;
