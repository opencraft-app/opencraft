/**
 * 定义TCE sdk专属异常类
 */
export default class TceSDKException extends Error {
    constructor(error: string);
    getMessage(): string;
    toString(): string;
    toLocaleString(): string;
}
