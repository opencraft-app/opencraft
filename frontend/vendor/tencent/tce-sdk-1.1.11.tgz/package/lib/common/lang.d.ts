export declare const LANG: {
    t(path: string): any;
};
