/// <reference types="react" />
export declare function getCAM(): Promise<{
    showBreakModal: (options: import("@tencent/types-tce-sdk-component").ShowBreakModalOptions) => void;
    addCamBreak: (options: import("@tencent/types-tce-sdk-component").AddBreakOptions) => void;
    showBreakTips: (props: import("@tencent/types-tce-sdk-component").CamBreakProps) => void;
    addCamBreakIcon: (options: import("@tencent/types-tce-sdk-component").AddBreakOptions) => void;
    showRoleGrantDialog: (options: import("@tencent/types-tce-sdk-component").ShowRoleGrantDialogProps) => Promise<unknown>;
    haveRole: (req: any) => Promise<import("@tencent/types-tce-sdk-component").CamGetRoleRes>;
    havePolicies: (req: import("@tencent/types-tce-sdk-component").HavePoliciesParam) => Promise<import("@tencent/types-tce-sdk-component").CamListAttachedRolePoliciesRes>;
    CAMBreak: (props: import("@tencent/types-tce-sdk-component").CamBreakProps & import("@tencent/types-tce-sdk-component").CamBreakType) => JSX.Element | null;
}>;
