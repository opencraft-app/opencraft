import { str2hex } from 'src/common/util';
import type * as XLSX from 'xlsx';
export declare interface StorageObject {
    local: Storage;
    session: Storage;
}
export interface LogInfo {
    /**
     * 标题
     */
    key: string;
    /**
     * 内容
     */
    value: any;
}
/**
 * 将字符传参数转变为对象，默认不传，不传将从document.location.search 获取
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.1.0
 * @param str 入参
 */
export declare function getQueryParameters(str?: string): {
    [x: string]: string;
};
/**
 * 将数据组装成csv文件下载
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.1.0
 * @param rows csv每行的数据，字符串二维数组
 * @param header csv文件的头，字符串数组
 * @param filename csv下载后的文件名，例如test.csv
 */
export declare function downloadCsv(rows: string[][], header: string[], filename: string): void;
/**
 * 获取xlsx库
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE >= 3.11.0
 * @version TCS >= 2.3.0
 */
export declare function getXlsx(): Promise<typeof XLSX>;
/**
 * 将数据组装成xlsx文件下载
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE >= 3.11.0
 * @version TCS >= 2.3.0
 * @param rows xlsx每行的数据，字符串二维数组
 * @param header xlsx文件的头，字符串数组
 * @param filename xlsx下载后的文件名，例如test.xlsx
 */
export declare function downloadXlsx(rows: string[][], header: string[], filename: string): Promise<void>;
/**
 * 解析xlsx文件
 * @param file xlsx文件
 * @returns Promise<{ headers: string[]; rows: any[][] }>
 */
export declare function parseXlsxFile(file: File): Promise<{
    headers: string[];
    rows: any[][];
}>;
/**
 * 返回storage函数
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.1.0
 * @param namespace 命名空间，默认为tce
 */
export declare function storage(namespace?: string): StorageObject;
/**
 * 关键信息打印
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.1.0
 * @param title 标题
 * @param details 详细信息
 */
export declare function log(title: string, details?: LogInfo[]): void;
/**
 * @deprecated 请使用log方法
 */
export declare const printKeywordLog: typeof log;
/**
 * 手机号脱敏
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.1.0
 * @param phoneNumber 手机号码
 */
export declare function maskPhoneNumber(phoneNumber: string): string;
/**
 * 邮箱脱敏
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.1.0
 * @param mail 邮箱
 */
export declare function maskMail(mail: string): string;
/**
 * 生成一个uuid
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.1.0
 */
export declare function uuid(): string;
/**
 * 获取dom元素的宽高
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.10.0
 * @version TCE登录页 ❌
 * @version TCS ❌
 * @export
 * @param {string} [selector='#appArea'] 默认为控制台页面右侧内容区的宽高
 * @returns {{ clientHeight: number; clientWidth: number }}
 */
export declare function getElementRect(selector?: string): {
    clientHeight: number;
    clientWidth: number;
};
export { str2hex };
