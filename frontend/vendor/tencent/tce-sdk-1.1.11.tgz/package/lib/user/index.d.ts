import * as common from '../common';
import { UserInfo, BaseUserInfo, IWhiteListResult, IWhiteListValueType } from './types';
/**
 * 获取当期登录用户信息
 */
export declare const getCurrentUserInfo: typeof common.getCurrentUserInfo;
/**
 * 异步获取当前用户信息
 * @version TCE控制台、购买页 >= 3.10.0
 * @version TCE登录页 ❌
 * @version TCS ❌
 * @return Promise<UserInfo | undefined>
 */
export declare function getCurrentUserInfoAsync(): Promise<UserInfo | undefined>;
/**
 * 获取当前用户已关联的策略列表
 * @export
 * @version TCE运营端控制台 >= 3.10.0
 * @version TCE租户端控制台、购买页 ❌
 * @version TCE登录页 ❌
 * @version TCS ❌
 * @returns {string[]} 返回策略列表名称
 */
export declare function getCurrentUserRelatedPolicies(): Promise<string[]>;
/**
 * 判断当前用户是否为超级管理员【也就是是否关联的（AdministratorAccess）策略】
 * @export
 * @version TCE运营端控制台 >= 3.10.0
 * @version TCE租户端控制台、购买页 ❌
 * @version TCE登录页 ❌
 * @version TCS ❌
 * @returns {boolean}
 */
export declare function checkCurrentUserIsAdmin(): Promise<boolean>;
/**
 * 获取当前用户关联的白名单列表
 * @version TCE租户端控制台、购买页 >= 3.11.0
 * @version TCE运营端控制台 ❌
 * @version TCE登录页 ❌
 * @version TCS ❌
 * @param whitelistKeys 白名单key
 * @param valueType 白名单值类型，默认为ownerUin【'appid' | 'uin' | 'owneruin'】
 * @returns IWhiteListResult
 */
export declare function hasWhiteListForMultiKey(whitelistKeys: string[], valueType?: IWhiteListValueType): Promise<IWhiteListResult>;
/**
 * 获取当前用户是否关联白名单
 * @version TCE租户端控制台、购买页 >= 3.11.0
 * @version TCE运营端控制台 ❌
 * @version TCE登录页 ❌
 * @version TCS ❌
 * @param whitelistKey 白名单key
 * @param valueType 白名单值类型，默认为ownerUin【'appid' | 'uin' | 'owneruin'】
 * @returns boolean
 */
export declare function hasWhiteList(whitelistKey: string, valueType?: IWhiteListValueType): Promise<boolean>;
export { BaseUserInfo, UserInfo };
