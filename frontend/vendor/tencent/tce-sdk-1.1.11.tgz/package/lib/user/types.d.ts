interface PassedBankInfo {
    Accountid: string;
    Accountname: string;
    Accountbank: string;
    Provincename: string;
    Provinceid: string;
    Cityname: string;
    Cityid: string;
    Bankname: string;
    Bankid: string;
}
interface NeedCheckBankInfo {
    Accountid: string;
    Accountname: string;
    Accountbank: string;
    Provincename: string;
    Provinceid: string;
    Cityname: string;
    Cityid: string;
    Bankname: string;
    Bankid: string;
}
interface Curinfo {
    Name: string;
    Type: number;
    Area: number;
    Idcardtype: number;
    Idcard: string;
    Organizationcode: string;
    AuthenticateType: string;
}
export interface BaseUserInfo {
    /**
     * 是否为主账号
     */
    isOwner: boolean;
    /**
     * 用户uin
     */
    userUin: string;
    /**
     * 主账号uin
     */
    ownerUin: string;
    /**
     * 用户名称
     */
    userName: string;
    /**
     * appId
     */
    appId: string;
}
export interface UserInfo extends BaseUserInfo {
    /**
     * 主账号UIN
     */
    ownerUin: string;
    /**
     * 主账号用户名
     */
    ownerUserName: string;
    /**
     * 用户uin
     */
    userUin: string;
    /**
     * 用户名称
     */
    userName: string;
    /**
     * 用户昵称
     */
    nickName: string;
    /**
     * 电话国家码
     */
    countryCode: string;
    /**
     * 电话
     */
    tel: string;
    /**
     * 邮箱
     */
    mail: string;
}
export interface IGetUserInfoByLoginUinRes {
    Uin: string;
    Owneruin: number;
    Account: string;
    Usertype: string;
    Type: number;
    Area: number;
    Curarea: number;
    Mailverify: number;
    Idcard: string;
    Idcardtype: number;
    Curidcardtype: number;
    Idcardurl: string;
    Idcarduuid: string;
    Idcardcacheurl: string;
    Idcardcacheuuid: string;
    Idcardurlnew: string;
    Idcardcacheuuidnew: string;
    Entrycardcacheurlnew: string;
    Entrycardurlnew: string;
    Contact: string;
    Tel: string;
    CountryCode: string;
    Needinfo: number;
    Mail: string;
    Curmail: string;
    Mailpass: number;
    Curmailpass: number;
    Registerstatus: string;
    Curdevcheckstate: number;
    Devcheckpass: number;
    Bankaccount: string;
    Banknumber: string;
    Perfection: number;
    Collname: string;
    Colltel: string;
    Collmail: string;
    WanIpTime: string;
    WanRestrict: number;
    Accredit: string;
    Curaccredit: string;
    Addr: string;
    Addrprefix: string;
    Devcheckmsg: string;
    Curdevcheckmsg: string;
    Organizationcode: string;
    Curorganizationcode: string;
    AuthenticateType: string;
    CurauthenticateType: string;
    IsModify: string;
    Curname: string;
    Curidcard: string;
    Curtype: number;
    SrcPlatform: string;
    BizInfo: string;
    Devchecktime: string;
    Mailchecktime: string;
    Firstdevchecktime: string;
    Acceptopenprotocol: number;
    Acceptyunprotocol: number;
    Openuser: number;
    Acceptopen: string;
    PassedBankInfo: PassedBankInfo;
    NeedCheckBankInfo: NeedCheckBankInfo;
    BankStatus: string;
    BankMsg: string;
    DeployName: string;
    SubExist: number;
    Nickname: string;
    Name: string;
    MsgLang: string;
    Curinfo: Curinfo;
    Authmethod: number;
    RequestId: string;
}
export interface ListSelfAttachedUserAllPoliciesReq {
    /**
     * 0:返回直接关联和随组关联策略，1:只返回直接关联策略，2:只返回随组关联策略
     */
    AttachType: number;
    /**
     * 策略类型
     */
    StrategyType?: number;
    /**
     * 每页数量，默认值是 20，必须大于 0 且小于或等于 200
     */
    Rp?: number;
    /**
     * 页码，默认值是 1，从 1开始，不能大于 200
     */
    Page?: number;
}
/**
 * ListSelfAttachedUserAllPolicies接口出参定义
 */
export interface ListSelfAttachedUserAllPoliciesRes {
    /**
     * 策略列表数据
     */
    PolicyList: AttachedUserPolicy[];
    /**
     * 策略总数
     */
    TotalNum: number;
}
/**
 *  用户关联的策略详情
 */
export interface AttachedUserPolicy {
    /**
     * 策略ID
     */
    PolicyId: number;
    /**
     * 策略名
     */
    PolicyName: string;
    /**
     * 策略描述
     */
    Description: string;
    /**
     * 创建时间
     */
    AddTime: string;
    /**
     * 策略类型(1表示自定义策略，2表示预设策略)
     */
    StrategyType: number;
    /**
     * 创建模式(1表示按产品或项目权限创建的策略，其他表示策略语法创建的策略)
     */
    CreateMode: number;
    /**
     * 随组关联信息
     */
    Groups?: AttachedUserPolicyGroupInfo[];
}
/**
 * 用户关联策略(随组管理)信息
 */
export interface AttachedUserPolicyGroupInfo {
    /**
     * 分组ID
     */
    GroupId: number;
    /**
     * 分组名称
     */
    GroupName: string;
}
export declare type IWhiteListValueType = 'appid' | 'uin' | 'owneruin';
export interface IWhiteListResult {
    [x: string]: {
        result: boolean;
        oriData: string[];
    };
}
export interface IWhiteListResp {
    code: number;
    data: {
        [x: string]: string[];
    };
    msg: string;
}
export {};
