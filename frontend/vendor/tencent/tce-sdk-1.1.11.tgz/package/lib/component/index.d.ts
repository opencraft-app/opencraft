import { ComponentType } from '../common';
export declare function getComponent<T>(name: T extends keyof ComponentType ? T : keyof ComponentType): Promise<T extends keyof ComponentType ? ComponentType[T] : T>;
