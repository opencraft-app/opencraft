import { IFileUploadParam, IFileUploadResp, IGetFileUploadUrlParam } from './type';
/**
 * 文件上传
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.11.0
 * @version TCE、TCS登录页 ❌
 * @version TCS控制台 >= 2.3.0
 * @param uploadParam 上传参数
 * @returns Promise<IFileUploadResp>
 */
export declare function upload(uploadParam: IFileUploadParam): Promise<IFileUploadResp>;
/**
 * 获取上传服务的链接
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.11.0
 * @version TCE、TCS登录页 ❌
 * @version TCS控制台 >= 2.3.0
 * @param param 入参
 */
export declare function getUploadUrl(param: IGetFileUploadUrlParam): string;
