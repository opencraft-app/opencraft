import { IAPIResponse } from '../api';
export interface IGetFileUploadUrlParam {
    /**
     * 接入的应用ID
     */
    appId: string;
    /**
     * 上传的模块名称
     */
    module: string;
    /**
     * 文件名
     */
    fileName?: string;
}
export interface IFileUploadParam extends IGetFileUploadUrlParam {
    /**
     * 上传的文件
     */
    file: FormData;
}
interface IFileUploadRespData {
    url: string;
}
export declare type IFileUploadResp = IAPIResponse<IFileUploadRespData>;
export {};
