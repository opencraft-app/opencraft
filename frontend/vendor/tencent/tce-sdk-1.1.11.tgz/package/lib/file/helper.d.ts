/**
 * 生成带签名的字符串
 * @param data 待签名的data
 */
export declare function generateSignStr<T extends object>(data: T): string;
/**
 * 获取当前平台类型
 */
export declare function getCurrentPlatformForFile(): "" | "ocloud" | "tcloud";
/**
 * 获取不同平台file服务的地址
 * @returns url
 */
export declare function getFileServerUrl(): string;
/**
 * 获取crypto-js 加载地址
 * @returns url
 */
export declare function getCryptoJsUrl(): string;
