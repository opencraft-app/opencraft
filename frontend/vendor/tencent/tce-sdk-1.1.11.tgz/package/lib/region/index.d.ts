import * as common from '../common';
import { ProvinceMap } from 'src/common/location_zh_cn';
export interface Region {
    /**
     * regionId，数字格式的
     */
    regionId: number;
    /**
     * region
     */
    region: string;
    /**
     * regionName: 根据不同语言返回的地域名称
     */
    regionName: string;
    zoneList: Zone[];
    /**
     * 地域角色(MR:主地域, SR:从地域, OR:其它地域)
     */
    regionRole?: string;
}
export interface Zone {
    zoneId: number;
    zone: string;
    zoneName: string;
}
export interface IDC {
    /**
     * 地域ID
     */
    regionId: number;
    /**
     * 可用区ID
     */
    zoneId: number;
    /**
     * IDC id
     */
    idcId: number;
    /**
     * IDC【字符串】
     */
    idc: string;
    /**
     * IDC名称【根据不同语言返回的地域名称】
     */
    idcName: string;
}
/**
 * DescribeRegionZone接口入参定义
 */
export interface DescribeRegionZoneReq {
    /**
     * TCE 产品Code
     */
    ProductId: string;
}
export interface DescribeRegionZoneResProduct {
    [key: string]: {
        [key: string]: {
            [key: string]: string[];
        } | null;
    };
}
/**
 * DescribeRegionZone接口出参定义
 */
export interface DescribeRegionZoneRes {
    /**
     * 地域数量
     */
    RegionCount: number;
    /**
     * 地域信息
     */
    RegionSet: RegionEx[];
    /**
     * 产品列表
     */
    Products: DescribeRegionZoneResProduct;
}
/**
 * DescribeRegionZone 返回的 Region 描述信息
 */
export interface RegionEx {
    /**
     * 地域名称(固定为英文字符串, API使用)
     */
    Region: string;
    /**
     * 地域编号(国际化支持, 前端展示使用)
     */
    RegionID: string;
    /**
     * 地域名称
     */
    RegionName: string;
    /**
     * 地域状态(AVAILABLE/UNAVAILABLE)
     */
    RegionState: string;
    /**
     * 地域状态描述
     */
    RegionStateRemark: string;
    /**
     * 可用区数量
     */
    ZoneCount: number;
    /**
     * 可用区列表
     */
    ZoneSet: ZoneEx[];
    /**
     * 地域角色(MR:主地域, SR:从地域, OR:其它地域)
     */
    RegionRole: string;
}
/**
 * DescribeRegionZone 接口返回的 Zone 描述信息
 */
export interface ZoneEx {
    /**
     * 所属Region编号
     */
    RegionID: string;
    /**
     * 可用区名称(固定为英文字符串, API使用)
     */
    Zone: string;
    /**
     * 可用区编号
     */
    ZoneID: string;
    /**
     * 可用区名称(国际化支持, 前端展示使用)
     */
    ZoneName: string;
    /**
     * 可用区状态(AVAILABLE/UNAVAILABLE)
     */
    ZoneState: string;
    /**
     * 可用区状态(原因描述)
     */
    ZoneStateRemark: string;
    /**
     * 可用区角色（MAZ:主可用区, SAZ:从可用区, OAZ:其它可用区）
     */
    ZoneRole: string;
}
/**
 * getCountryCode返回的国家名和code
 */
export interface ICountry {
    Name: string;
    Code: string;
}
/**
 * 异步获取地域列表
 * @param productCode 产品code【非必填，不传的时候直接返回所有的地域】
 * @param subProductCode 产品code【非必填】
 */
export declare function getRegionListAsync(productCode?: string, subProductCode?: string): Promise<Region[]>;
/**
 * 异步获取当前region信息
 * 适用TCE租户端购买页
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE租户端控制台、购买页 >= 3.10.0
 * @version TCE运营端控制台 >= 3.8.0
 * @version TCE、TCS登录页 ❌
 * @version TCS控制台 >= 2.1.0
 * @param regionId 地域ID 非必填，不传的时候会从当前url中获取,都没有的情况下取列表第一个
 */
export declare function getCurrentRegionAsync(regionId?: string): Promise<Region>;
/**
 * 同步方式获取地域列表，不区分产品
 */
export declare const getRegionListSync: typeof common.getRegionListSync;
/**
 * 获取当前region信息
 * 获取优先级  url or localStorage
 * 适用TCE租户端控制台、TCE运营端控制台、TCS控制台
 */
export declare const getCurrentRegion: typeof common.getCurrentRegion;
/**
 * 根据语言获取国家名称和代码
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.1.0
 * @param language 语言
 */
export declare function getCountryCodeAsync(language?: string): Promise<ICountry[]>;
/**
 * 根据语言获取省市区列表
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.1.0
 * @param language 语言
 */
export declare function getLocationAsync(language?: string): Promise<ProvinceMap>;
/**
 * 设置当前地域
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、TCE购买页 >= 3.8.0
 * @version TCE、TCS登录页 ❌
 * @version TCS ❌
 * @param {String} region 地域名称,运营端为英文如'chongqing',租户端为ID
 */
export declare function setRegion(region: string): void;
/**
 * 获取IDC列表
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE运营端控制台 >= 3.11.0
 * @version TCE、TCS登录页、TCE租户端、购买页 ❌
 * @version TCS控制台 >= 2.3.0
 * @param zoneId 可用区ID
 */
export declare function getIDCList(zoneId: number): IDC[];
