import { ReactElement } from 'react';
/**
 * 显示sidebar
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.11.0
 * @version TCE登录页、购买页 ❌
 * @version TCS ❌
 */
export declare function show(): void;
/**
 * 隐藏sidebar
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.11.0
 * @version TCE登录页、购买页 ❌
 * @version TCS ❌
 */
export declare function hide(): void;
/**
 * 展开
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.11.0
 * @version TCE登录页、购买页 ❌
 * @version TCS ❌
 */
export declare function expand(): void;
/**
 * 折叠sidebar
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.11.0
 * @version TCE登录页、购买页 ❌
 * @version TCS ❌
 */
export declare function collapse(): void;
/**
 * 展开所有菜单
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.11.0
 * @version TCE登录页、购买页 ❌
 * @version TCS ❌
 */
export declare function expandAllMenu(): void;
/**
 * 展开所有菜单
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.11.0
 * @version TCE登录页、购买页 ❌
 * @version TCS ❌
 */
export declare function hideMenuItem(href: string): void;
/**
 * 展开所有菜单
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.11.0
 * @version TCE登录页、购买页 ❌
 * @version TCS ❌
 */
export declare function customHeaderMenuItem(node: ReactElement): void;
