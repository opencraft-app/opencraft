import { IAPIResponse } from '../api';
import { getCustomizeProductConfig, getCustomizeProductConfigMultiple, getCustomizeAccessTabs, getCustomizeAccessInfoByRouterKey, getCurrentPageAccessInfo, getProductInfoByUUID, getMenuInfoByUUID, getCustomizeProductByCode, getCustomizeProductList, getCustomizeIconUrl, getAllMenus, getCustomizeProductLoginModalConfig } from '../common/customize';
import * as config from '../common/config';
export { getCustomizeProductConfig, getCustomizeProductConfigMultiple, getCustomizeAccessInfoByRouterKey, getCurrentPageAccessInfo, getCustomizeAccessTabs, getCustomizeProductList, getProductInfoByUUID, getCustomizeProductByCode, getMenuInfoByUUID, getCustomizeIconUrl, getAllMenus, getCustomizeProductLoginModalConfig, };
export interface FoyoConfig {
    Description: string;
    Key: string;
    Namespace: string;
    Value: string;
}
/**
 * 传输加密信息
 */
export interface TransportSecret {
    /**
     * 加密方式
     */
    method: string;
    /**
     * 公钥
     */
    public_key: string;
}
export interface DescribeConfigReq {
    Params: {
        /**
         * 配置分类
         */
        Namespace: string;
        /**
         * 关键字
         */
        Key: string;
    };
    /**
     * 语言
     */
    Language: string;
}
export interface DescribeConfigUpDateReq {
    Params: [
        {
            /**
             * 配置分类
             */
            Namespace: string;
            /**
             * 关键字
             */
            Key: string;
            /**
             * 关键字
             */
            Value: boolean | string | number | object | any[];
        }
    ];
    /**
     * 语言
     */
    Language: string;
}
declare type FoyoConfigValue = boolean | string | object | number | undefined;
interface GetConfigRes {
    /**
     * 值
     */
    Value: FoyoConfigValue | FoyoConfigValue[];
}
export interface DescribeConfigRes {
    Data: DescribeConfigItem;
}
export interface DescribeConfigListRes {
    Data: {
        PageNum: number;
        PageSize: number;
        Count: number;
        Data: DescribeConfigItem[];
    };
}
interface DescribeConfigItem {
    /**
     * ID
     */
    EntryID: number;
    /**
     * 关键字
     */
    Key: string;
    /**
     * 配置分类
     */
    Namespace: string;
    /**
     * 描述
     */
    Description: string;
    /**
     * 当前版本号
     */
    Version: number;
    /**
     * 配置时间
     */
    ModifyTime: number;
    /**
     * 来源，暂定sdk和cli
     */
    Source: string;
    /**
     * 扩展字段json
     */
    Ext: string | DescribeExt;
    /**
     * 值
     */
    Value: boolean | string | object | number | any[];
}
interface DescribeExt {
    /**
     * 当前版本号
     */
    Version: string;
    /**
     * 值类型 num bool str array obj
     */
    ValueType: 'bool' | 'str' | 'obj' | 'num' | 'array';
}
export declare const FOYO_CONFIG: {
    tcenter_base: {
        name: string;
        /**
         * 租户端是否展示右上角费用菜单
         */
        tcloud_show_fee_menu: string;
        /**
         * 租户端是否打开注册功能
         */
        tcloud_allow_reg: string;
        /**
         * 租户端主子账号登录是否启用图形验证码
         */
        tcloud_login_show_captcha: string;
        /**
         * 运营端主子账号登录是否启用图形验证码
         */
        ocloud_login_show_captcha: string;
        /**
         * 租户端所有页面统计系统的api地址
         */
        tcloud_statistics_api: string;
        /**
         * 租户端会话超时时间【分钟】
         */
        tcloud_session_timeout: string;
        /**
         * 租户端购买页所属项目是否必填配置
         */
        tcloud_view_project_required: string;
        /**
         * 异地登录保护开关：开启后，租户端的账号发生异地登录时，平台会对用户做身份校验
         */
        tcloud_remote_login_protection: string;
        /**
         * 金融专区白名单
         */
        fzo_whiltelist: string;
        /**
         * 价格展示配置
         */
        price_display_content: string;
    };
    tcenter_login_description: {
        name: string;
        /**
         * 租户端登录页面左侧信息
         */
        tcloud_login_show_description: string;
    };
    tcenter_privacy_agreement: {
        name: string;
        /**
         * 租户端隐私协议
         */
        tcloud_privacy: string;
    };
    tcenter_system_maintenance: {
        name: string;
        /**
         * 租户端系统维护页面
         */
        tcloud_system_maintenance_info: string;
    };
    tcenter_password_control: {
        name: string;
        /**
         * 是否打开租户端密码控件
         */
        enable: string;
        /**
         * 密码控件window下license
         */
        license_window: string;
        /**
         * 密码控件mac下license
         */
        license_mac: string;
        /**
         * 密码控件urlPar
         */
        urlPar: string;
    };
    tcenter_security: {
        name: string;
        /**
         * 是否打开数字证书
         */
        digital_certificate: string;
    };
};
export declare const ELASTIC_CONFIG_KEY: {
    common: {
        tce_log_server: string;
    };
    tcloud: {
        billing_backend_type: string;
        cos_allow_use_sm4: string;
        vpc_multicast: string;
    };
    ocloud: {
        cvm_configurable: string;
        no_vpc_options: string;
    };
};
/**
 * 获取弹性变量配置
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、登录页 >= 3.10.0
 * @version TCE购买页 ❌
 * @version TCS ❌
 * @param key 配置key
 * @return string
 */
export declare function getElasticConfig<T>(key: string): T;
/**
 * 获取客制化全局变量配置
 * @param key 配置key
 * @return string
 */
export declare function getCustomizeGlobalConfig(key: string): string;
/**
 * 异步获取配置中心配置
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE >= 3.10.0
 * @version TCS ❌
 * @param Namespace 配置分类
 * @param Key 关键字
 * @return  boolean | string | object | number | undefined
 */
export declare function getConfigAsync(Namespace: string, Key: string): Promise<IAPIResponse<GetConfigRes>>;
/**
 * 异步获取指定ns下的配置中心配置
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE >= 3.10.12
 * @version TCS ❌
 * @param Namespace 配置分类
 * @return  DescribeConfigItem[]
 */
export declare function getConfigAsyncByNs(Namespace: string): Promise<IAPIResponse<DescribeConfigItem[]>>;
interface GetConfigListAsyncFilter {
    /**
     * 配置分类
     */
    namespace: string;
    /**
     * 配置key
     */
    key: string;
}
interface ConfigItem extends GetConfigListAsyncFilter {
    value: FoyoConfigValue | FoyoConfigValue[];
}
/**
 * 异步获取配置中心配置
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE >= 3.10.0
 * @version TCS ❌
 * @return  FoyoConfigValue | FoyoConfigValue[]
 */
export declare function getConfigAsyncMultiple(filters: GetConfigListAsyncFilter[]): Promise<ConfigItem[]>;
/**
 * 设置配置中心配置值
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE >= 3.10.0
 * @version TCS ❌
 * @param Namespace 配置分类
 * @param Key 关键字
 * @param Value 值
 */
export declare function setConfig<T extends object | number | string | boolean | any[]>(Namespace: string, Key: string, Value: T): Promise<IAPIResponse<{}>>;
export declare const getConfigSync: typeof config.getConfigSync;
