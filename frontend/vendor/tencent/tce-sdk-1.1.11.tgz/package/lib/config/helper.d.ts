import { IAPIResponse } from 'src/api';
import { DescribeConfigRes, DescribeConfigListRes } from '.';
export declare const currentLang: string;
/**
 * 异步获取配置中心配置
 * @param Namespace 配置分类
 * @param Key 关键字
 */
export declare function getConfig(Namespace: string, Key: string): Promise<IAPIResponse<DescribeConfigRes>>;
/**
 * 异步获取配置中心配置
 * @param Namespace 配置分类
 * @param Key 关键字
 */
export declare function getConfigList(Namespace: string): Promise<IAPIResponse<DescribeConfigListRes>>;
