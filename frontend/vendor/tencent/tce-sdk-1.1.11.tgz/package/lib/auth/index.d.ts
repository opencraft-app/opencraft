export declare function getAUTH(): Promise<{
    showAuthModal: ({ cb, reqData }: import("@tencent/types-tce-sdk-component").IProps) => Promise<unknown>;
    showAuthDigitalCertModal: (props: import("@tencent/types-tce-sdk-component").IShowAuthDigitalCertModalProps) => Promise<unknown>;
}>;
