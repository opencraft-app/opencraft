## [1.1.7](https://git.woa.com/tce-tools/tce-sdk/compare/v1.1.5...v1.1.7) (2025-11-19)


### Bug Fixes

* 修复getUploadUrl的并发时候nonce重复的 bug ([4c7ed07](https://git.woa.com/tce-tools/tce-sdk/commits/4c7ed072f35d634ca3d0bef33f167170d6945b7a))


### Features

* 支持获取指定ns下的所有配置 ([20e7d8b](https://git.woa.com/tce-tools/tce-sdk/commits/20e7d8b702a90ab673be8ff61fa79b5f2fc98d44))
* 更新 package-lock.json ([d955b05](https://git.woa.com/tce-tools/tce-sdk/commits/d955b0559bc44d82a449fac560124e54a41c82de))



## [1.1.5](https://git.woa.com/tce-tools/tce-sdk/compare/v1.0.5...v1.1.5) (2025-10-17)


### Bug Fixes

* 修复ApprovalProps定义问题 ([7edbb91](https://git.woa.com/tce-tools/tce-sdk/commits/7edbb916b2f96ceb30a0338a3821cb11a6ecd23f))
* 修复regionRole大小写问题 ([c4f6fb4](https://git.woa.com/tce-tools/tce-sdk/commits/c4f6fb45e208c7bd2ebf1356a4e063f1adf18a19))
* 修复英文翻译中标题大小写以及完整句子无标点的问题 ([a18bb45](https://git.woa.com/tce-tools/tce-sdk/commits/a18bb459d096a88d04c0310483f8645f79d20dc1))
* 增加approval-sdk入参 ([b609236](https://git.woa.com/tce-tools/tce-sdk/commits/b6092369720906855678e6d0ad81f89634170897))
* 更新axios到最新版本修复安全问题 ([4224670](https://git.woa.com/tce-tools/tce-sdk/commits/42246708e9d3fcead2944e8e127fb4d42e73557e))


### Features

* tcs getCurrentUserInfo方法可以暴露更多数据到前端控制台 ([8ef7502](https://git.woa.com/tce-tools/tce-sdk/commits/8ef75023e682938b50bb61030400064e9528e5ec))
* 完善Approve-sdk单测 ([2538b73](https://git.woa.com/tce-tools/tce-sdk/commits/2538b733df04723cf463ce37bedfff32b350b32c))
* 更新axios版本 ([5005bbb](https://git.woa.com/tce-tools/tce-sdk/commits/5005bbb14a634f956654d7ab66ed62e0517397a7))
* 添加RegionRole字段描述 ([b1f7f1f](https://git.woa.com/tce-tools/tce-sdk/commits/b1f7f1f7a8b1ee61c91fdd1caafe5955bdf5d065))



## [1.0.4](https://git.woa.com/tce-tools/tce-sdk/compare/v1.0.0-beta.0...v1.0.4) (2025-02-26)


### Bug Fixes

* 添加换肤效果 ([2653211](https://git.woa.com/tce-tools/tce-sdk/commits/26532119f1bc723bd195792df641d3e2b0f6268f))
* 添加换肤效果 ([2ab3a31](https://git.woa.com/tce-tools/tce-sdk/commits/2ab3a31b047403862c40a8f0bf2f354a108dde92))
* 修复getCurrentLang在登录页面存在的语言不对的问题 ([caa8af9](https://git.woa.com/tce-tools/tce-sdk/commits/caa8af9b20fa5a17596e2f0066de606a05569163))


### Features

* 更新changelog ([b2c7c72](https://git.woa.com/tce-tools/tce-sdk/commits/b2c7c72b4f60a369497d2ba3cbbc63d446114049))
* 兼容380购买页的i18n ([a1a3153](https://git.woa.com/tce-tools/tce-sdk/commits/a1a3153752a3f45d9258fcecd236b2937eacc36f))
* 新增build:ci指令，在ci环境下只build单js，不build ts ([50f258a](https://git.woa.com/tce-tools/tce-sdk/commits/50f258ac3feb879c82a6bf08180602f4ef8c59da))
* 移除cbs-sdk libraryName ([0150bab](https://git.woa.com/tce-tools/tce-sdk/commits/0150babc267bd1652da13fc3c9b73c260d431c28))
* 增加225的国家代码 ([17445aa](https://git.woa.com/tce-tools/tce-sdk/commits/17445aa39f4bff01b064609575a1150acccb55f9))
* tcs侧增加获取登录建模数据的方法 getCustomizeProductLoginModalConfig ([51d8082](https://git.woa.com/tce-tools/tce-sdk/commits/51d80820bdfdf385ab01c457bd85fc7087c1f1fc))



# [1.0.0](https://git.woa.com/tce-tools/tce-sdk/compare/v1.0.0-beta.0...v1.0.0) (2024-10-23)


### Bug Fixes

* 添加换肤效果 ([2653211](https://git.woa.com/tce-tools/tce-sdk/commits/26532119f1bc723bd195792df641d3e2b0f6268f))
* 添加换肤效果 ([2ab3a31](https://git.woa.com/tce-tools/tce-sdk/commits/2ab3a31b047403862c40a8f0bf2f354a108dde92))
* 修复getCurrentLang在登录页面存在的语言不对的问题 ([caa8af9](https://git.woa.com/tce-tools/tce-sdk/commits/caa8af9b20fa5a17596e2f0066de606a05569163))



## [0.59.1](https://git.woa.com/tce-tools/tce-sdk/compare/v0.59.0...v0.59.1) (2024-09-13)



# [0.59.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.58.0...v0.59.0) (2024-09-06)


### Bug Fixes

* getRegionListAsync方法兼容TCS场景，TCS没有部署Location服务，直接同步获取地域信息 ([5741041](https://git.woa.com/tce-tools/tce-sdk/commits/5741041bd6a56ac1ed0fb0b0ed0e8b299eb76e16))


### Features

* 安全问题 ([315a0d4](https://git.woa.com/tce-tools/tce-sdk/commits/315a0d4ff169ae392044d7db6697c8c98c434126))
* 新增获取货币相关信息的方法 ([a4a3576](https://git.woa.com/tce-tools/tce-sdk/commits/a4a3576aa9a3b4a2ca16973c013608999ab05e91))
* 新增billing-sdk ([720d38a](https://git.woa.com/tce-tools/tce-sdk/commits/720d38a2acffceb602f703cd824103e6fe76b814))
* platform中增加isUseCustomizeTheme和getCustomizeThemePath两个方法 ([1552c7b](https://git.woa.com/tce-tools/tce-sdk/commits/1552c7bb349fccfbd0c7d62087572657e41376e7))



# [0.58.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.57.1...v0.58.0) (2024-07-16)


### Bug Fixes

* 安全问题修复 ([9131ed6](https://git.woa.com/tce-tools/tce-sdk/commits/9131ed65c53a7db774e6ac2f516b22f74d9d7e0c))
* 安全问题修复 ([ae56632](https://git.woa.com/tce-tools/tce-sdk/commits/ae5663223f7df23081d6d57c7b1a4be42cf3e50f))
* 安全问题修复 ([4a98130](https://git.woa.com/tce-tools/tce-sdk/commits/4a98130a3900b182778ea561716a46f154bca2c6))
* 流水线执行build报内存溢出 ([51503f8](https://git.woa.com/tce-tools/tce-sdk/commits/51503f80c00db3cf62c93798f817500ed64760ed))
* 修复循环依赖问题 ([67ddc76](https://git.woa.com/tce-tools/tce-sdk/commits/67ddc766fd8526e8a7453bb5977e13374a2d9950))
* master向230同步时，将TCE_VERSION改为TCS2.3.0 ([6c015b1](https://git.woa.com/tce-tools/tce-sdk/commits/6c015b19f75de69828ebf1353abc53e0f789cb03))
* remove useless export ([9681999](https://git.woa.com/tce-tools/tce-sdk/commits/9681999c9599c2f0e04dd1c481e85980c31d899c))


### Features

* 更改批量获取配置的出参格式 ([90ba907](https://git.woa.com/tce-tools/tce-sdk/commits/90ba9075b302c38fe78d7bd943a6abd2780ca5d0))
* 更新类型 ([027a048](https://git.woa.com/tce-tools/tce-sdk/commits/027a0483b155c9b91558f0761baf10904d57916b))
* 更新批量获取配置文档和单测 ([da7ad95](https://git.woa.com/tce-tools/tce-sdk/commits/da7ad9555caa90c88e9b32cde7ff3a506ed25d44))
* 更新moment ([b31aeab](https://git.woa.com/tce-tools/tce-sdk/commits/b31aeab6a8dbe6d809105222eadcb1d030d2f6b4))
* 更新platform-sdk类型 ([c05678d](https://git.woa.com/tce-tools/tce-sdk/commits/c05678d19036d108b6a774d3d945a9991cee15f8))
* 新增批量获取客制化变量、foyo配置的方法 ([7967bf4](https://git.woa.com/tce-tools/tce-sdk/commits/7967bf48cb58a9d0254122ad99dd2cf4c4924e63))
* 修复安全问题 ([8ef89c6](https://git.woa.com/tce-tools/tce-sdk/commits/8ef89c6c5122518bd4525e61fac163c4aa8afb51))
* 增加axios的可选配置, 比如timeout作为可选参数进行传递 ([6d7b5c3](https://git.woa.com/tce-tools/tce-sdk/commits/6d7b5c3561caa424ceb7cd21f8140d61d5487b90))
* getCustomizeAccessTabs增加非必填出参groupName ([778abb4](https://git.woa.com/tce-tools/tce-sdk/commits/778abb4438115798302050b05e768f472bbbfa09))



## [0.57.2](https://git.woa.com/tce-tools/tce-sdk/compare/v0.57.1...v0.57.2) (2024-05-07)


### Bug Fixes

* 修复循环依赖问题 ([67ddc76](https://git.woa.com/tce-tools/tce-sdk/commits/67ddc766fd8526e8a7453bb5977e13374a2d9950))



## [0.57.1](https://git.woa.com/tce-tools/tce-sdk/compare/v0.57.0...v0.57.1) (2024-05-07)

### Features

- 增加lang.getTcloudLangList 和 lang.getPlanLangList

## [0.56.1](https://git.woa.com/tce-tools/tce-sdk/compare/v0.56.0...v0.56.1) (2023-12-27)

### Bug Fixes

- 修改子账号登录时,getCurrentUserInfo 获取用户信息的 bug

# [0.56.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.55.0...v0.56.0) (2023-12-18)

### Features

- api.yApiRequest 出参错误的 message 如果 code 为一级错误码，则返回为[code]:message

# [0.55.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.54.2...v0.55.0) (2023-12-18)

### Features

- api.yApiRequest 出参增加 rawResponse 用于返回云 API 接口原始响应数据 ([badb4b7](https://git.woa.com/tce-tools/tce-sdk/commits/badb4b79faeac1a28b661747c037f6398dcdb2a1))

## [0.54.2](https://git.woa.com/tce-tools/tce-sdk/compare/v0.54.1...v0.54.2) (2023-12-15)

### Features

- getAllMenus 添加 product 返回

## [0.54.1](https://git.woa.com/tce-tools/tce-sdk/compare/v0.54.0...v0.54.1) (2023-12-14)

### Features

- 增加 config.getAllMenus（获取客制化全量菜单）

# [0.54.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.53.0...v0.54.0) (2023-12-14)

# [0.53.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.52.7...v0.53.0) (2023-12-01)

### Features

- file.upload 入参增加 fileName ([71f082f](https://git.woa.com/tce-tools/tce-sdk/commits/71f082f761d2c8b6bae672b68ba832c05492f3b9))

## [0.52.7](https://git.woa.com/tce-tools/tce-sdk/compare/v0.52.4...v0.52.7) (2023-11-28)

### Features

- yApiRequest 报错的时候在 err 中增加 rest 信息 ([ed7de80](https://git.woa.com/tce-tools/tce-sdk/commits/ed7de8067ae7a1fd5d47e02c98bd0224d8bcd199))

## [0.52.4](https://git.woa.com/tce-tools/tce-sdk/compare/v0.52.3...v0.52.4) (2023-10-26)

### Bug Fixes

- 修复 getDeliverProductList SDK 后端接口数据为空的场景 ([2cb67d3](https://git.woa.com/tce-tools/tce-sdk/commits/2cb67d3589dd9261d5173b0be73713d2f4dce01f))

## [0.52.3](https://git.woa.com/tce-tools/tce-sdk/compare/v0.52.2...v0.52.3) (2023-10-17)

### Bug Fixes

- 兼容客制化 productmenu 中没有 productCode 的情况 ([1d0f133](https://git.woa.com/tce-tools/tce-sdk/commits/1d0f13316bbc93ddff811710230303a4a7d7ad0d))

## [0.52.2](https://git.woa.com/tce-tools/tce-sdk/compare/v0.52.1...v0.52.2) (2023-10-11)

### Bug Fixes

- 修复 getCustomizeProductList 获取客制化产品列表数据缺失的问题 ([a16af96](https://git.woa.com/tce-tools/tce-sdk/commits/a16af960dff5ca786aeae6b11d4c9c2d427b79aa))

## [0.52.1](https://git.woa.com/tce-tools/tce-sdk/compare/v0.52.0...v0.52.1) (2023-09-20)

### Bug Fixes

- 优化国密加密加载静态资源流程,增加缓存 ([7194da1](https://git.woa.com/tce-tools/tce-sdk/commits/7194da1d88f46dacd428abec67e864c8201c2ba3))

# [0.52.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.51.10...v0.52.0) (2023-09-19)

### Bug Fixes

- 翻译审批错误信息 ([f51e82a](https://git.woa.com/tce-tools/tce-sdk/commits/f51e82ae3c8b9f83eb2197525c922b252f85c35a))
- 修改下 readme ([23891a7](https://git.woa.com/tce-tools/tce-sdk/commits/23891a762973c6236fd3088aa06891cf16a4d95f))

### Features

- 增加了 parseXlsxFile 方 ([39ee13c](https://git.woa.com/tce-tools/tce-sdk/commits/39ee13cb517600ceb2abd15385d16577fb5f3cba))
- 增加了 parseXlsxFile 方法 ([e1352d9](https://git.woa.com/tce-tools/tce-sdk/commits/e1352d952457cf6ea535559d3b0b4fbebdda75f9))

## [0.51.10](https://git.woa.com/tce-tools/tce-sdk/compare/v0.51.5...v0.51.10) (2023-09-06)

### Bug Fixes

- 修复 types 定义位置错误 ([71562fd](https://git.woa.com/tce-tools/tce-sdk/commits/71562fdc22c17d82531c99782a49acfdd1263bc0))
- 修改 jsEncryp 进行 rsa2048 加密位数缺失的 bug ([837eb00](https://git.woa.com/tce-tools/tce-sdk/commits/837eb00fe1fd693257ff7456982619a838a9a44b))

### Features

- 更新业务 sdk ([ad014f1](https://git.woa.com/tce-tools/tce-sdk/commits/ad014f104f84a826cc1702835a9ba3098d35a32c))
- 更新 monitor-sdk 类型 ([51cbdc6](https://git.woa.com/tce-tools/tce-sdk/commits/51cbdc6be73c0c9bd35d32d67632684cbbace224))
- 更新 monitor-sdk 类型定义 ([a955c2a](https://git.woa.com/tce-tools/tce-sdk/commits/a955c2a59cc094227d4334c988b35baf41f887e3))

## [0.51.5](https://git.woa.com/tce-tools/tce-sdk/compare/v0.51.4...v0.51.5) (2023-08-22)

### Bug Fixes

- 修复 getCustomizeTitle 特殊场景下报错问题 ([1cec0a7](https://git.woa.com/tce-tools/tce-sdk/commits/1cec0a755e3a67a977cc0b7c32f82655eb65cfb9))

## [0.51.4](https://git.woa.com/tce-tools/tce-sdk/compare/v0.51.3...v0.51.4) (2023-08-16)

### Bug Fixes

- 修复水印文字太长被遮挡的问题 ([4393cc0](https://git.woa.com/tce-tools/tce-sdk/commits/4393cc05ab62fb64465bc137eb313747ff8571d1))

## [0.51.3](https://git.woa.com/tce-tools/tce-sdk/compare/v0.51.2...v0.51.3) (2023-08-10)

### Bug Fixes

- i18next 不存在的情况下也预载 ([c69ed21](https://git.woa.com/tce-tools/tce-sdk/commits/c69ed21130f188959907921028b5e2ed7e11ed3c))

### Features

- 增加购买页获取当前 region 的能力 ([a655749](https://git.woa.com/tce-tools/tce-sdk/commits/a6557498a0fc2b351da54b30e3ceba0f7ca5e0ef))
- platform.logout 支持 tcs 场景 ([ed2f5ba](https://git.woa.com/tce-tools/tce-sdk/commits/ed2f5ba3ef6a02bc487e2a726ee887ec246f98e2))
- setRegion 增加购买页的场景 ([6130190](https://git.woa.com/tce-tools/tce-sdk/commits/613019052aa77fa84927b5f0ef94c69aac451f75))

## [0.51.2](https://git.woa.com/tce-tools/tce-sdk/compare/v0.51.1...v0.51.2) (2023-07-24)

### Bug Fixes

- 修复购买页路由 key 长度问题,获取接入信息的时候优先取更长的 ([f99b975](https://git.woa.com/tce-tools/tce-sdk/commits/f99b975456afcb2d86cc3abe97753577fd56d9dc))

## [0.51.1](https://git.woa.com/tce-tools/tce-sdk/compare/v0.51.0...v0.51.1) (2023-07-20)

### Features

- platform.getDeliverProductList 增加缓存 ([a996c3d](https://git.woa.com/tce-tools/tce-sdk/commits/a996c3d9ec706651930dc70a090459cfa2441530))

# [0.51.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.50.0...v0.51.0) (2023-07-19)

### Features

- 增加 platform.getDeliverProductList 及 platform.checkProductDeliver 方法 ([8a78373](https://git.woa.com/tce-tools/tce-sdk/commits/8a78373b6cd2ee09644bf9997d5df08cbade9412))

# [0.50.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.49.1...v0.50.0) (2023-07-06)

### Features

- 引入水印能力 ([16f7992](https://git.woa.com/tce-tools/tce-sdk/commits/16f79927e3cdf255ada42325a2575b2a5b0edcc2))

## [0.49.1](https://git.woa.com/tce-tools/tce-sdk/compare/v0.49.0...v0.49.1) (2023-06-12)

### Bug Fixes

- utils.str2hex 增加浏览器兼容性的逻辑 ([0197d26](https://git.woa.com/tce-tools/tce-sdk/commits/0197d261cb178f3d2c1513d0511f233277f20655))

# [0.49.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.48.10...v0.49.0) (2023-06-12)

### Features

- 处理中文场景下字符串转换为 16 进制的问题,utils 中增加 str2hex 方法 ([9a06bc4](https://git.woa.com/tce-tools/tce-sdk/commits/9a06bc46eb3032ac933fabb8c42b073d6f5ecf20))

## [0.48.10](https://git.woa.com/tce-tools/tce-sdk/compare/v0.48.8...v0.48.10) (2023-06-07)

### Bug Fixes

- 修复 kms-sm2 加密中换行场景报错的问题 ([c66cdcc](https://git.woa.com/tce-tools/tce-sdk/commits/c66cdcc26aabdd093e4c949292698d695a3791c5))
- 修改 platform-sdk 加载路径 --testfree (merge request !182) ([c88edf2](https://git.woa.com/tce-tools/tce-sdk/commits/c88edf2cb824abc853eb94db38470c8cb43bed27))

### Features

- 新增异步获取 xlsx 库的方法 ([a268170](https://git.woa.com/tce-tools/tce-sdk/commits/a268170a52cf3008034cf53e14a643a16b79ee04))

## [0.48.8](https://git.woa.com/tce-tools/tce-sdk/compare/v0.48.3...v0.48.8) (2023-05-31)

### Bug Fixes

- 订正 getTceSdkAssetsBasePath 获取方式 ([c0e9243](https://git.woa.com/tce-tools/tce-sdk/commits/c0e9243008503c3d8a7b241ac444b42c94e162a1))
- 订正 getTceSdkAssetsBasePath 获取方式 ([73024bb](https://git.woa.com/tce-tools/tce-sdk/commits/73024bb7babf5f2fd103a7d88fc66003cca26342))

### Features

- 将 output 的函数去掉 Freeze ([19a4361](https://git.woa.com/tce-tools/tce-sdk/commits/19a4361560b3b23f04c623af87320c5ab1ff7dff))
- 新增 getTceSdkAssetsBasePath 的获取 path 方式 ([4ed47f3](https://git.woa.com/tce-tools/tce-sdk/commits/4ed47f3ddbd07eb67cbb01afbe9a7f8c5af24338))
- 增加 project-sdk --testfree (merge request !179) ([10f4670](https://git.woa.com/tce-tools/tce-sdk/commits/10f4670309005e026c6d4b358227c20630f23b51))
- getCustomizeTitle 兼容新版取值方式 ([920a367](https://git.woa.com/tce-tools/tce-sdk/commits/920a367d4fe5f6f207ef06c31944ab0404945622))

## [0.48.3](https://git.woa.com/tce-tools/tce-sdk/compare/v0.48.1...v0.48.3) (2023-05-23)

### Bug Fixes

- 修复获取 tcs 二级菜单 name 获取错误问题 ([46d3011](https://git.woa.com/tce-tools/tce-sdk/commits/46d3011904d771d3072df441215f3607023b40a4))
- 修正 replaceDomainInStr 获取方式 ([b7cbb8e](https://git.woa.com/tce-tools/tce-sdk/commits/b7cbb8e1634069b6b2e4903540ec2236b85a2911))

### Features

- printKeywordLog 方法改名为 log ([d4e6990](https://git.woa.com/tce-tools/tce-sdk/commits/d4e6990be5eb6346c3a8cd951c61f558ccf908a2))

## [0.48.1](https://git.woa.com/tce-tools/tce-sdk/compare/v0.48.0...v0.48.1) (2023-05-12)

### Features

- 去掉 getComponentCommitId 中对开关的判断 ([8321619](https://git.woa.com/tce-tools/tce-sdk/commits/8321619008fcc84c96b015f7e679ae492061fdd3))

# [0.48.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.47.2...v0.48.0) (2023-05-10)

### Features

- 增加 platform.getComponentCommitId 方法 ([579948b](https://git.woa.com/tce-tools/tce-sdk/commits/579948b384c52fde177775e8cc14d51bbb47bdb4))

## [0.47.2](https://git.woa.com/tce-tools/tce-sdk/compare/v0.47.1...v0.47.2) (2023-04-27)

### Features

- 修复 getCustomizeAccessInfoByRouterKey 的 bug ([deaa8ce](https://git.woa.com/tce-tools/tce-sdk/commits/deaa8ce6b30b691908dee5d78810b47bec0ed455))

# [0.47.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.46.0...v0.47.0) (2023-04-24)

### Bug Fixes

- 解决 merge Conflict ([6d1bc65](https://git.woa.com/tce-tools/tce-sdk/commits/6d1bc65e1028ae402f0e36af676cadc087bc910f))
- 修复二次认证 bug --bug=109822001 --testfree (merge request !175) ([7ffb148](https://git.woa.com/tce-tools/tce-sdk/commits/7ffb14819847053cea5ca1c558f622a9c547386c))

### Features

- 增加自动展开所有菜单的能力 --bug=106217307 --testfree (merge request !166) ([69a2c6f](https://git.woa.com/tce-tools/tce-sdk/commits/69a2c6f864e8f86ae38a54f89d50e6b0a28d61b5))
- getCustomizeProductList 增加支持客制化 next 场景 ([aac618a](https://git.woa.com/tce-tools/tce-sdk/commits/aac618aef67103fb8573ac8a293adf1f525f9ca2))

# [0.46.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.45.0...v0.46.0) (2023-04-23)

### Bug Fixes

- 修复客制化 next 渲染 js 路径错误 ([4d0aa5c](https://git.woa.com/tce-tools/tce-sdk/commits/4d0aa5c8264a85ae8780fe59544526e8fdd9dadb))

### Features

- getCustomizeAccessTabs 一级导航增加 href 和 target ([33a3831](https://git.woa.com/tce-tools/tce-sdk/commits/33a3831bf960ad3179e6fa98c24e5aa5bfc38c6d))
- region 返回值新增 regionRole 和 zoneRole 字段 ([4a4bad8](https://git.woa.com/tce-tools/tce-sdk/commits/4a4bad858e942989bbc0da1663594cfce4ed99ab))

# [0.45.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.44.0...v0.45.0) (2023-04-13)

### Features

- getCustomizeAccessTabs 中 types 增加 href 字段 ([87393f2](https://git.woa.com/tce-tools/tce-sdk/commits/87393f224c2e41f736d484472eb1a9428d4488a5))

# [0.44.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.43.3...v0.44.0) (2023-04-13)

### Bug Fixes

- 修复打包 pure 版本时失效问题 ([27fd5af](https://git.woa.com/tce-tools/tce-sdk/commits/27fd5af35d3020ef1085f967804a939085320f69))

### Features

- getCustomizeAccessTabs 出参增加 display ([d7c5a8f](https://git.woa.com/tce-tools/tce-sdk/commits/d7c5a8ffbf48d4b45b5bdef2a7f21c91f4697245))

## [0.43.3](https://git.woa.com/tce-tools/tce-sdk/compare/v0.43.2...v0.43.3) (2023-04-13)

### Bug Fixes

- 修复默认产品分类 icon 地址错误 ([f4dc032](https://git.woa.com/tce-tools/tce-sdk/commits/f4dc0324aa07982aba962ccdebcea4a3e6ca4933))

## [0.43.2](https://git.woa.com/tce-tools/tce-sdk/compare/v0.43.1...v0.43.2) (2023-04-12)

### Bug Fixes

- 修复二次认证传参 bug ([c59767d](https://git.woa.com/tce-tools/tce-sdk/commits/c59767de6d0ba169bc6ab8c618fac6bc4d1a414d))

## [0.43.1](https://git.woa.com/tce-tools/tce-sdk/compare/v0.43.0...v0.43.1) (2023-04-12)

### Features

- getCustomizeLogo 增加对 TCS 及客制化 2.0 的支持 ([5f05f72](https://git.woa.com/tce-tools/tce-sdk/commits/5f05f727b2c75bc4ea62e3439791f867f9343d7a))

# [0.43.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.42.8...v0.43.0) (2023-04-06)

### Bug Fixes

- 修复 TCS 的 customNav 为空数组的 bug ([fb34c8e](https://git.woa.com/tce-tools/tce-sdk/commits/fb34c8e152f1b41ac7bb990ab4160de76f4db72b))
- 修复 tcs 环境下 tag 路径问题 ([6c0cc0a](https://git.woa.com/tce-tools/tce-sdk/commits/6c0cc0a1ad81c66902343aea951736a09c5283cc))

### Features

- 补充完单测 ([f1b859b](https://git.woa.com/tce-tools/tce-sdk/commits/f1b859b5a81dcab657a2ae2efabb88229cae838e))
- 获取客制化数据兼容客制化 2.0，增加 platform.getGlobalVariable 方法用于获取 window 的全局变量 --testfree (merge request !173) ([73b9ae3](https://git.woa.com/tce-tools/tce-sdk/commits/73b9ae3784882619da0d8f7058a506c25d745ff7))
- 新增 sidebar 两个方法 ([0b1a6c9](https://git.woa.com/tce-tools/tce-sdk/commits/0b1a6c93c13858e936e63a92bad899d9fa35a4d8))
- 增加超云相关内容的兼容 ([0514d94](https://git.woa.com/tce-tools/tce-sdk/commits/0514d9489253bfda4128151bff342f131c7b35f1))
- sidebar 单测 ([a9c2694](https://git.woa.com/tce-tools/tce-sdk/commits/a9c2694ecfa59013c797044b4cd8db4d6993e69c))
- TCS 场景下的客制化增加 customNav ([feb56a2](https://git.woa.com/tce-tools/tce-sdk/commits/feb56a26d19f4d899326254c7aa56996414c1f0d))
- TCS 场景下的客制化增加 customNav ([aa99157](https://git.woa.com/tce-tools/tce-sdk/commits/aa99157775367b9517dc15d4ff571d85e3531af3))

## [0.42.8](https://git.woa.com/tce-tools/tce-sdk/compare/v0.42.6...v0.42.8) (2023-03-10)

### Bug Fixes

- tcs 场景下 tab 中需要增加 visiable 字段 ([d6d6c87](https://git.woa.com/tce-tools/tce-sdk/commits/d6d6c87ca7f3a8dc27ecdf05bf1da5bce63c56eb))

### Features

- 新增 build:pure 指令，打包时去掉 polyfill --testfree (merge request !171) ([3edecc3](https://git.woa.com/tce-tools/tce-sdk/commits/3edecc3726c6c7b018e36833a0971dfb525973cf))

## [0.42.6](https://git.woa.com/tce-tools/tce-sdk/compare/v0.42.5...v0.42.6) (2023-02-03)

### Bug Fixes

- 修复 eslint 及循环依赖的问题 ([4c98ec1](https://git.woa.com/tce-tools/tce-sdk/commits/4c98ec19a75b9cae8b6345a96f5bec05971589c0))

### Features

- 极光场景 yApi 处理登录失效场景 --testfree (merge request !169) ([d39181a](https://git.woa.com/tce-tools/tce-sdk/commits/d39181aa4d73e99ee06c03cfd4aa11b7dbe915c7))

## [0.42.5](https://git.woa.com/tce-tools/tce-sdk/compare/v0.42.4...v0.42.5) (2023-01-03)

### Bug Fixes

- 修复 getCustomizeAccessInfoByRouterKey 方法在无菜单场景下的 bug ([0bf70f4](https://git.woa.com/tce-tools/tce-sdk/commits/0bf70f474c67415c8dd5100a294e81d84bb7d6f2))

## [0.42.4](https://git.woa.com/tce-tools/tce-sdk/compare/v0.42.3...v0.42.4) (2022-12-16)

### Bug Fixes

- 修复获取 TCS 菜单没有二级菜单的问题 ([c5b6b0f](https://git.woa.com/tce-tools/tce-sdk/commits/c5b6b0fa345ece72cf722a0f37d6b19bcd358d36))

## [0.42.1](https://git.woa.com/tce-tools/tce-sdk/compare/v0.42.0...v0.42.1) (2022-12-06)

### Bug Fixes

- 修改测试用例 ([f825554](https://git.woa.com/tce-tools/tce-sdk/commits/f82555490c901d841db5fb744f04eb355b6a7422))
- 修改测试用例 ([22541a4](https://git.woa.com/tce-tools/tce-sdk/commits/22541a45ab21700ad7ccd5e6157a19dc3ac28176))
- 修改测试用例 ([8c1fad3](https://git.woa.com/tce-tools/tce-sdk/commits/8c1fad3fb5dfb96cc6c1b3e1040ecadfaa032bc2))
- 增加测试用例 ([549369b](https://git.woa.com/tce-tools/tce-sdk/commits/549369bdab5dd232b5c3de565283a1235ebdfdfa))

### Features

- 获取组件版本信息适配 TCS ([8cb58bd](https://git.woa.com/tce-tools/tce-sdk/commits/8cb58bd8b8feb56c85076da81d957d1a4e8715de))
- 增加审批 sdk ([9dfa35e](https://git.woa.com/tce-tools/tce-sdk/commits/9dfa35e252cc5a612830c4ee6bb1b82c0d17faf2))

# [0.42.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.41.0...v0.42.0) (2022-12-01)

### Bug Fixes

- remove useless export ([b098d97](https://git.woa.com/tce-tools/tce-sdk/commits/b098d97ba87292551dee85a1dc90465cabd93c8c))

### Features

- 增加 axios 的可选配置, 比如 timeout 作为可选参数进行传递 ([01b876f](https://git.woa.com/tce-tools/tce-sdk/commits/01b876f3d5aaeb6f6087af1f6da213a6df41298a))
- tcesdk 增加展开所有菜单的功能 ([ab40eb8](https://git.woa.com/tce-tools/tce-sdk/commits/ab40eb89dbaa45dc343d06724b25abb11913fe5b))

## [0.41.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.40.1...v0.41.2) (2022-11-30)

### Features

- 新增获取省市区列表 --testfree (merge request !161) ([e3cefd9](https://git.woa.com/tce-tools/tce-sdk/commits/e3cefd9a3c7ae6c702b0465c687746788ed805f7))
- getCustomizeAccessTabs 出参增加 name 及 visiable ([7956cf5](https://git.woa.com/tce-tools/tce-sdk/commits/7956cf52177ef2872de8fad0623bd4341a34fd64))

## [0.40.1](https://git.woa.com/tce-tools/tce-sdk/compare/v0.40.0...v0.40.1) (2022-11-21)

### Bug Fixes

- 优化加密逻辑,当加密的明文为空或者空字符串的时候直接返回原文 ([c977553](https://git.woa.com/tce-tools/tce-sdk/commits/c977553586c459730d4c83e8050bee7dc8602514))

# [0.40.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.39.0...v0.40.0) (2022-11-17)

### Bug Fixes

- 修复路径 bug ([52481eb](https://git.woa.com/tce-tools/tce-sdk/commits/52481ebb16df7990a9c9ea22ab396b34a229bf72))
- 修复路径 bug ([623ec84](https://git.woa.com/tce-tools/tce-sdk/commits/623ec84fb9b654010f31fd27d070ac80ca86226e))

### Features

- 产品及菜单接入信息支持 TCS ([719dc96](https://git.woa.com/tce-tools/tce-sdk/commits/719dc96d8b77c752e7851b088257f7babf191818))
- 完善客制化相关 SDK 支持 TCS 的逻辑 ([60533b2](https://git.woa.com/tce-tools/tce-sdk/commits/60533b29d03474ac32a0e7e22112569a63220b46))

# [0.39.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.38.1...v0.39.0) (2022-11-16)

### Features

- 在获取客制化产品接入信息的地方加上 productCode 及 productName ([2cfbbb2](https://git.woa.com/tce-tools/tce-sdk/commits/2cfbbb2a6c94d729a2fb251674f1415db6b017e5))

## [0.38.1](https://git.woa.com/tce-tools/tce-sdk/compare/v0.38.0...v0.38.1) (2022-11-16)

### Bug Fixes

- 修复 getComponent 预加载资源问题 --testfree ([0570f53](https://git.woa.com/tce-tools/tce-sdk/commits/0570f5305d2389df85cf2f639beed714b7d59b06))

# [0.38.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.37.6...v0.38.0) (2022-11-15)

### Features

- 新增 getCustomizeProductList、getCustomizeProductByCode、getCustomizeIconUrl --testfree ([04da04a](https://git.woa.com/tce-tools/tce-sdk/commits/04da04aff154684682cb7875063e5408661a1745))

## [0.37.6](https://git.woa.com/tce-tools/tce-sdk/compare/v0.37.1...v0.37.6) (2022-11-14)

### Bug Fixes

- 修复重复依赖的问题 ([065114f](https://git.woa.com/tce-tools/tce-sdk/commits/065114ff08e6491db650d8c7f0e26d05694c6343))
- 修复 sdkRouter 注入路径没带 imgcacheHost 问题 --testfree ([54504c9](https://git.woa.com/tce-tools/tce-sdk/commits/54504c9520235778900e126d40fcdc699789821d))
- 修改测试用例 --testfree (merge request !144) ([5f60079](https://git.woa.com/tce-tools/tce-sdk/commits/5f600790f0c637b3915f601fe50f91d50c8260d5))

### Features

- 添加云备份 cbs-sdk --testfree (merge request !147) ([3c7890e](https://git.woa.com/tce-tools/tce-sdk/commits/3c7890e6e46988b2fb56dbe18c3a2aff4c7016ea))
- 新增获取货币 getCurrentCurrency 方法 --testfree (merge request !136) ([f138e7e](https://git.woa.com/tce-tools/tce-sdk/commits/f138e7ea396473698ad3b4129e5aa833e3d5077e))
- 新增 cwhistle 云哨 SDK --testfree ([e4a85dd](https://git.woa.com/tce-tools/tce-sdk/commits/e4a85dda5678a3ecda55dd3b7a47777e58a2dd55))
- 域名增加替换能力,多域名支持 --testfree (merge request !140) ([aab620e](https://git.woa.com/tce-tools/tce-sdk/commits/aab620e152b68fe6f5d5dc74f057fe12f4e5316a))
- 云 api 请求将错误信息中其他字段暴露出来 --testfree ([d35df24](https://git.woa.com/tce-tools/tce-sdk/commits/d35df24ae0931fd1b125550771454d9e2729c1d2))

# [0.37.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.36.0...v0.37.0) (2022-09-14)

### Bug Fixes

- 修复 gulp 打包计时不准确问题 --testfree ([d9e464f](https://git.woa.com/tce-tools/tce-sdk/commits/d9e464ffed9bce50900217f4d6b018c48d249d3e))
- 修复 yapi 传入 region 为数字时接口报错问题 --testfree ([70c9be5](https://git.woa.com/tce-tools/tce-sdk/commits/70c9be5100acfa05d54de1dfdb528b94532a643b))
- 修改 axios 版本,解决低版本漏洞 --bug=101992247 --testfree ([f61f0cf](https://git.woa.com/tce-tools/tce-sdk/commits/f61f0cf0a6dccf0ff2fe4ef6559d85d9d39379a8))

### Features

- 增加外部 sdk 加载依赖 ([63ec46e](https://git.woa.com/tce-tools/tce-sdk/commits/63ec46e2840eae03e001a52de0d912ad09344909))
- 增加 tips-sdk ([1355af5](https://git.woa.com/tce-tools/tce-sdk/commits/1355af56e85e8f02fd700a0de441e2673d82a7f6))
- tce-sdk 中增加数字证书配置 ([1f1d4d0](https://git.woa.com/tce-tools/tce-sdk/commits/1f1d4d0b0aa7ede38710da0d3e4890efdac36537))

# [0.36.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.34.0...v0.36.0) (2022-08-23)

### Bug Fixes

- 修复客制化 bug --bug=100419603 --testfree ([f40e47b](https://git.woa.com/tce-tools/tce-sdk/commits/f40e47b4992946010d17bb88611956e7b50bc6dc))
- 修改 axios 版本,解决低版本漏洞 ([5c3b7de](https://git.woa.com/tce-tools/tce-sdk/commits/5c3b7dee7d4d6b717b4766665877b8c56d08cb10))

### Features

- 加载 tea2.js 的时候需要增加 tea2.css ([d1fafa0](https://git.woa.com/tce-tools/tce-sdk/commits/d1fafa0278311ae9af045ce8831cdad3e56aa62f))
- 新增 getProductInfoByUUID/getMenuInfoByUUID ([c934747](https://git.woa.com/tce-tools/tce-sdk/commits/c9347470e6cfb156c31170b770ddfcaf20e5efcd))

## [0.35.1](https://git.woa.com/tce-tools/tce-sdk/compare/v0.34.0...v0.35.1) (2022-07-28)

### Bug Fixes

- 修改 axios 版本,解决低版本漏洞 ([5c3b7de](https://git.woa.com/tce-tools/tce-sdk/commits/5c3b7dee7d4d6b717b4766665877b8c56d08cb10))

### Features

- 加载 tea2.js 的时候需要增加 tea2.css ([d1fafa0](https://git.woa.com/tce-tools/tce-sdk/commits/d1fafa0278311ae9af045ce8831cdad3e56aa62f))

# [0.35.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.34.0...v0.35.0) (2022-07-26)

### Features

- 加载 tea2.js 的时候需要增加 tea2.css ([d1fafa0](https://git.woa.com/tce-tools/tce-sdk/commits/d1fafa0278311ae9af045ce8831cdad3e56aa62f))

# [0.34.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.33.0...v0.34.0) (2022-07-25)

### Features

- 增加数字证书二次认证逻辑 ([3c08501](https://git.woa.com/tce-tools/tce-sdk/commits/3c0850129a549a59d824a8bfbed212a25e3aa926))
- standalone --testfree (merge request !106) ([af0583e](https://git.woa.com/tce-tools/tce-sdk/commits/af0583e2372027405c31555fe42afe62a128f2bb))

# [0.33.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.32.0...v0.33.0) (2022-07-07)

### Features

- 增加云 API 默认 resHandler 方法 ([680b996](https://git.woa.com/tce-tools/tce-sdk/commits/680b9962a62129b19a8b3794c73baecc91794de9))

# [0.32.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.31.1...v0.32.0) (2022-07-07)

### Features

- tce-sdk 中增加数字证书配置及外部 SDK 依赖 ([ec17167](https://git.woa.com/tce-tools/tce-sdk/commits/ec171677f54390e941c290199a1a3f24a82e4055))

## [0.31.1](https://git.woa.com/tce-tools/tce-sdk/compare/v0.31.0...v0.31.1) (2022-06-23)

### Bug Fixes

- 修复登录态失效的时候弹窗回到登录页面报错问题 --bug=99988171 ([5e1801b](https://git.woa.com/tce-tools/tce-sdk/commits/5e1801b0a37389875eaed8826b829a040c9f5e63))
- 修复客制化 bug ([4efbcb5](https://git.woa.com/tce-tools/tce-sdk/commits/4efbcb5cc696c905cfeeba340313fba32dc5f7b1))

# [0.31.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.30.1...v0.31.0) (2022-06-22)

### Features

- 311 场景下去掉加载 react 相关的内容,平台全局加载了 ([600aa2f](https://git.woa.com/tce-tools/tce-sdk/commits/600aa2ff3e4fe85fc12de1344bfa46a59f238626))
- 获取客制化产品数据加载 target ([8f66866](https://git.woa.com/tce-tools/tce-sdk/commits/8f668667fc9e87642636f2227c3b867b9d766246))
- 增加 foyo 配置常量 --bug=99988171 ([7fff0c6](https://git.woa.com/tce-tools/tce-sdk/commits/7fff0c6fa937a860824001d81999f56e8b411b5d))

## [0.30.1](https://git.woa.com/tce-tools/tce-sdk/compare/v0.30.0...v0.30.1) (2022-06-10)

### Bug Fixes

- 修复登录态失效的时候弹窗回到登录页面报错问题 ([a085ffc](https://git.woa.com/tce-tools/tce-sdk/commits/a085ffcb817dee9550b88b7301ffaddf466efe3a))

# [0.30.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.29.0...v0.30.0) (2022-06-09)

### Features

- 增加对 router 及 sidebar 的操作的 SDK ([008572e](https://git.woa.com/tce-tools/tce-sdk/commits/008572eb68641d04f6b1498507e92601474e6ea5))

# [0.29.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.28.1...v0.29.0) (2022-06-08)

### Features

- 增加 foyo 配置常量 ([786c977](https://git.woa.com/tce-tools/tce-sdk/commits/786c977d2b542100210eb3354fc75036eada2379))

## [0.28.1](https://git.woa.com/tce-tools/tce-sdk/compare/v0.28.0...v0.28.1) (2022-05-31)

### Bug Fixes

- 修复白名单接口参数名错误的问题及 getQueryParameters 方法添加 decode 以及空值校验 ([9dfc5cd](https://git.woa.com/tce-tools/tce-sdk/commits/9dfc5cd31680ac147b3c8e91e45a182c179d070c))

# [0.28.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.27.0...v0.28.0) (2022-05-31)

### Features

- 1.云 api 地址支持在 TCE_GLOBAL_CONSTANT 直接配置 yapiUrl;2.支持极光云 api 地址 ([524f5d4](https://git.woa.com/tce-tools/tce-sdk/commits/524f5d4364409134443da641f2ac8ed72082e45c))

# [0.27.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.26.1...v0.27.0) (2022-05-23)

### Features

- 新增 standalone-sdk 配置 ([8405ad5](https://git.woa.com/tce-tools/tce-sdk/commits/8405ad567dae13667105c627d8c4d497c6388ae6))

## [0.26.1](https://git.woa.com/tce-tools/tce-sdk/compare/v0.26.0...v0.26.1) (2022-05-23)

### Bug Fixes

- 修复在 tcs 环境下加载静态资源失败的 bug ([3803e38](https://git.woa.com/tce-tools/tce-sdk/commits/3803e383179dbbfdb2e86623e7e12d89708051bb))

# [0.26.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.25.2...v0.26.0) (2022-05-20)

### Features

- utils 中增加 downloadXlsx 方法 ([fe61b71](https://git.woa.com/tce-tools/tce-sdk/commits/fe61b71b5bf38bbdc0c17033c09a8d5b234007c0))

## [0.25.2](https://git.woa.com/tce-tools/tce-sdk/compare/v0.25.1...v0.25.2) (2022-05-18)

### Features

- 增加 foyo 配置常量 fzo_whiltelist ([aaa9baa](https://git.woa.com/tce-tools/tce-sdk/commits/aaa9baaf10fc36827e6322bb2e07aede46154157))

## [0.25.1](https://git.woa.com/tce-tools/tce-sdk/compare/v0.25.0...v0.25.1) (2022-05-17)

### Bug Fixes

- 修复 hasWhiteList 数据为空的 bug ([5e8846b](https://git.woa.com/tce-tools/tce-sdk/commits/5e8846b2ed69ced80b3fc8abec3a68d21fefd03e))

# [0.25.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.24.0...v0.25.0) (2022-05-17)

### Features

- 增加白名单相关方法[hasWhiteList/hasWhiteListForMultiKey] ([f35dac8](https://git.woa.com/tce-tools/tce-sdk/commits/f35dac8a95cea3b8c787f304ebdadabaf8ffc2f8))

# [0.24.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.23.0...v0.24.0) (2022-05-13)

### Features

- 增加获取 IDC 列表的 SDK ([44c035f](https://git.woa.com/tce-tools/tce-sdk/commits/44c035f7c92ecb527569c5a0e4ca6d3492a38439))

# [0.23.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.22.9...v0.23.0) (2022-05-11)

### Features

- 增加获取上传文件的 url ([f530690](https://git.woa.com/tce-tools/tce-sdk/commits/f530690b9db49a91c8c03e37b4be7840d16f1052))

## [0.22.9](https://git.woa.com/tce-tools/tce-sdk/compare/v0.22.8...v0.22.9) (2022-05-10)

### Bug Fixes

- 修复 file 服务入参多了字符串的 bug ([941f8b7](https://git.woa.com/tce-tools/tce-sdk/commits/941f8b705eb9db75f4953329d16198112f2ee049))
- domain list 中 doc 添加 platform type 判断 ([df69d06](https://git.woa.com/tce-tools/tce-sdk/commits/df69d0698c92f9e6c780740b16997ae0bd5c0151))

## [0.22.8](https://git.woa.com/tce-tools/tce-sdk/compare/v0.22.6...v0.22.8) (2022-04-28)

### Features

- 将 preload 的依赖地址改为优先从环境变量获取 ([de53e46](https://git.woa.com/tce-tools/tce-sdk/commits/de53e462f182b58baf38fdb89eb869f264642ee2))

## [0.22.6](https://git.woa.com/tce-tools/tce-sdk/compare/v0.22.5...v0.22.6) (2022-04-24)

### Features

- 修改云 API 请求的超时时间,和后端保持一致为 30 秒;增加 ocloud_login_show_captcha 的 foyo 配置 ([1c2195c](https://git.woa.com/tce-tools/tce-sdk/commits/1c2195cc07ac3e325d407475eba7da42f6b70165))

## [0.22.5](https://git.woa.com/tce-tools/tce-sdk/compare/v0.22.4...v0.22.5) (2022-04-22)

### Features

- 将 tcs 场景下的 platform 入参也直接使用 ocloud ([cfff0fb](https://git.woa.com/tce-tools/tce-sdk/commits/cfff0fb9507d5357100144a414d89fb68892a8f4))

## [0.22.4](https://git.woa.com/tce-tools/tce-sdk/compare/v0.22.3...v0.22.4) (2022-04-20)

### Features

- 浏览器场景下 file.upload 去掉 appkey ([7032912](https://git.woa.com/tce-tools/tce-sdk/commits/70329123a945ff03e9e107b5149249f819d0224b))

## [0.22.3](https://git.woa.com/tce-tools/tce-sdk/compare/v0.22.2...v0.22.3) (2022-04-18)

### Features

- 错误的场景增加 data ([83c268d](https://git.woa.com/tce-tools/tce-sdk/commits/83c268dba88bb00d6284e0038ace40fe77688fbf))

## [0.22.2](https://git.woa.com/tce-tools/tce-sdk/compare/v0.22.1...v0.22.2) (2022-04-17)

### Features

- file.upload 将签名从 header 迁移到 query ([43cc6f0](https://git.woa.com/tce-tools/tce-sdk/commits/43cc6f066db13663bf2ffa3bbb70182484b80fd8))

## [0.22.1](https://git.woa.com/tce-tools/tce-sdk/compare/v0.22.0...v0.22.1) (2022-04-15)

### Features

- 优化 run dev 开发使用体验 ([4afd478](https://git.woa.com/tce-tools/tce-sdk/commits/4afd478df680689ff39603ae3c8944ac514e1fae))
- 在加载业务 SDK 的时候前置增加判断 react 等内容 ([00dcb50](https://git.woa.com/tce-tools/tce-sdk/commits/00dcb503c5327d8920ec9942bd31601726aed358))

# [0.22.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.21.0...v0.22.0) (2022-04-13)

### Features

- 新增文件服务 sdk ([5b4c484](https://git.woa.com/tce-tools/tce-sdk/commits/5b4c48410dc8427529c7e478e70e24b0a6ff6788))

## 0.21.0 (2022-04-13)

### Features

- 将 yapi 请求超时时间增加到 20s ([ff80e989](https://git.woa.com/tce-tools/tce-sdk/commit/ff80e989932a9bda40b1f0f7a6027f610c8bdb33))
- cam 添加 sowRoleGrantDialog 方法文档 ([a738260](https://git.woa.com/tce-tools/tce-sdk/commits/a7382601da462575929797e8ea99e82040d79c10))

## [0.20.2](https://git.woa.com/tce-tools/tce-sdk/compare/v0.20.1...v0.20.2) (2022-03-24)

### Features

- setRegion 按运营端租户端区分 ([5f85533](https://git.woa.com/tce-tools/tce-sdk/commits/5f8553325cb0aa37fbdea8b960df0c4eb20a14b3))

## [0.20.1](https://git.woa.com/tce-tools/tce-sdk/compare/v0.20.0...v0.20.1) (2022-03-23)

### Bug Fixes

- 修复 cam 和 auth 对应 sdk 的 bug ([5ea2640](https://git.woa.com/tce-tools/tce-sdk/commits/5ea26409fb929de9ec83c09c19b7fe6aefe19723))

# [0.20.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.19.1...v0.20.0) (2022-03-21)

### Bug Fixes

- 修复文档例子错误 ([46c887f](https://git.woa.com/tce-tools/tce-sdk/commits/46c887fda57effa72dd129e0f474aecfcbf1c1dc))

### Features

- 新增 setRegion 方法 ([c60d61d](https://git.woa.com/tce-tools/tce-sdk/commits/c60d61dcbc15cb33cc168895d641e4d050157d98))

## [0.19.1](https://git.woa.com/tce-tools/tce-sdk/compare/v0.19.0...v0.19.1) (2022-03-18)

### Bug Fixes

- 将业务 SDK 的 CAM 改成 cam-sdk，AUTH 改成 auth-sdk；完善业务 SDK 文档 ([8db1df3](https://git.woa.com/tce-tools/tce-sdk/commits/8db1df38cc541833b0c9353477b1eb57d7f632fc))

# [0.19.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.18.0...v0.19.0) (2022-03-16)

### Features

- 改造现有获取 sdk 的方法，使其兼容 tea 的 sdk 获取 ([fc511df](https://git.woa.com/tce-tools/tce-sdk/commits/fc511dfa206b6471475bb87d1c4c7c5a932f8bc4))

# [0.18.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.17.2...v0.18.0) (2022-03-16)

### Features

- 增加获取当前用户关联的策略列表及判断当前用户是否为超级管理员的方法 ([dac1f69](https://git.woa.com/tce-tools/tce-sdk/commits/dac1f6943c15d7c545da28d21c4b3489ad167a55))

## [0.17.2](https://git.woa.com/tce-tools/tce-sdk/compare/v0.17.1...v0.17.2) (2022-03-09)

### Bug Fixes

- 修复 getFrontendComponentInfo 购买页场景下 bug ([cef8052](https://git.woa.com/tce-tools/tce-sdk/commits/cef80525be5b332630a124301a39137c65c3b38f))

## [0.17.1](https://git.woa.com/tce-tools/tce-sdk/compare/v0.17.0...v0.17.1) (2022-03-08)

### Bug Fixes

- 导出 TransformFirstLetterToLowerCase,TransformFirstLetterToUpperCase 定义 ([4b416bf](https://git.woa.com/tce-tools/tce-sdk/commits/4b416bfd3ce964a145ccce8d1e196198fefec11d))

# [0.17.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.16.1...v0.17.0) (2022-03-08)

### Features

- 新增 transformFirstLetterToLowerCase,transformFirstLetterToUpperCase,getElementRect 方法 ([0b2972c](https://git.woa.com/tce-tools/tce-sdk/commits/0b2972c52746486c569a52232551deb5042c7bff))

## [0.16.1](https://git.woa.com/tce-tools/tce-sdk/compare/v0.16.0...v0.16.1) (2022-03-06)

### Bug Fixes

- 增加缺失的 platform 中的常量 PLATFORM_COMMON_COMPONENT ([a41de9f](https://git.woa.com/tce-tools/tce-sdk/commits/a41de9f3fcfcd49f17c49492a0962936669360b1))

# [0.16.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.14.0...v0.16.0) (2022-03-06)

### Features

- 增加获取组件信息的 sdk,完善单测,提高到 96% ([02197f0](https://git.woa.com/tce-tools/tce-sdk/commits/02197f01c2fff9155788395403d6b359ed2ebe09))

# [0.15.0](https://git.woa.com/tce-tools/tce-sdk/compare/v0.14.0...v0.15.0) (2022-03-02)

### Features

- 增加获取客制化产品接入信息相关的 sdk ([4add7bb](https://git.woa.com/tce-tools/tce-sdk/commits/4add7bb242e690a7a189dba1ea6c9c40d509d031))

## [0.14.1](https://git.woa.com/tce-tools/tce-sdk/compare/v0.13.2...v0.13.4) (2022-02-24)

### Features

- 云 API 添加取消请求的功能 & 补充新增函数单测 ([6dc62ed](https://git.woa.com/tce-tools/tce-sdk/commits/6dc62ed8cf4a793055dffc7478b5117bb8def342))

## [0.13.3](https://git.woa.com/tce-tools/tce-sdk/compare/v0.13.2...v0.13.3) (2022-02-17)

### Features

- 增加云 API 通用错误码常量及平台类型常量 ([5cf5b31](https://git.woa.com/tce-tools/tce-sdk/commits/5cf5b31dd50eae8432c9cb09dfa9ea91047ac83f))

## 0.13.1 (2022-02-16)

### Bug Fixes

- Platform_Type 导入问题 ([4e91ea6](https://git.woa.com/tce-tools/tce-sdk/commits/4e91ea636c88c9cf078d67bcacca7cfe26670122))
- ts 定义文件修复 ([fec08d7](https://git.woa.com/tce-tools/tce-sdk/commits/fec08d7bec41c410f509c0d6f6c3e30f288a0ac7))
- 修复 rewire 问题 ([d0c4521](https://git.woa.com/tce-tools/tce-sdk/commits/d0c4521cf1f2ea7ba534ff8cd621111a34933b9a))
- 修复 TCS 下获取 csrfCode 的 bug ([77abbd3](https://git.woa.com/tce-tools/tce-sdk/commits/77abbd3189f1be996f0e02c00f2faad95d2fa473))
- 修复异步获取配置返回 undefined 问题 ([c438584](https://git.woa.com/tce-tools/tce-sdk/commits/c4385848ff3000a932b453edaf6073e8c427a156))
- 修复构建出现的 cookie 的 bug ([980ce3d](https://git.woa.com/tce-tools/tce-sdk/commits/980ce3d4d5f1a95d4ef1c0003617ea64a6df78dc))
- 修复构建出现的 cookie 的 bug，修改版本为 0.9.2 ([1e98cca](https://git.woa.com/tce-tools/tce-sdk/commits/1e98ccab0beb196cb44f8e542f4553e86ce3a076))
- 修改 tnpm install 也执行 run build 的问题 ([83495bc](https://git.woa.com/tce-tools/tce-sdk/commits/83495bceb1c27eda7fd1a4fcec0140656f7d2360))
- 修改 tnpm install 也执行 run build 的问题 ([f11615a](https://git.woa.com/tce-tools/tce-sdk/commits/f11615a073d787f0a3e9625c457f58efe4aca888))
- 修改单测 ([07d7054](https://git.woa.com/tce-tools/tce-sdk/commits/07d705446dd119e771963c79db3e747a4930462b))
- 修改同步获取 config 函数解决 uft-8 乱码问题 ([82762d9](https://git.woa.com/tce-tools/tce-sdk/commits/82762d9d30bd81959494e80998a49b8f85edd942))
- 修改国家和 code 对应文档 ([8c83b48](https://git.woa.com/tce-tools/tce-sdk/commits/8c83b48139f52fa6db1efd2e86b125bd127b1488))
- 单测调整 ([e026290](https://git.woa.com/tce-tools/tce-sdk/commits/e026290074c2d6d2c947bf8db20579ec586d34ec))
- 导出 pdf 增加--no-sandbox ([f9183cf](https://git.woa.com/tce-tools/tce-sdk/commits/f9183cfb8b0c200576d6353a0765c0fa6f568f37))
- 常量名称错误修复 ([c1ab65a](https://git.woa.com/tce-tools/tce-sdk/commits/c1ab65aabc6a1a5259e9321b08fa456087f7757a))
- 常量名称错误修复 ([36a5466](https://git.woa.com/tce-tools/tce-sdk/commits/36a54663b1c641139a56c77a59e15718e3139324))
- 开源治理修复 ([2ee68e0](https://git.woa.com/tce-tools/tce-sdk/commits/2ee68e0ecb13ab9295d918a953990fd9354c159c))
- 开源治理样式修复 ([80daff2](https://git.woa.com/tce-tools/tce-sdk/commits/80daff2606f63b1dee99a20eca9d3b3759d353a5))
- 开源治理样式修复 ([86eb91c](https://git.woa.com/tce-tools/tce-sdk/commits/86eb91c92cefb2a6aa71966fd48a96da17bf5e5e))
- 开源治理样式修复 ([21409b9](https://git.woa.com/tce-tools/tce-sdk/commits/21409b917b11ed33a4909ca13f753a4d96b783fc))
- 恢复误删除的 config 附录 ([994d96b](https://git.woa.com/tce-tools/tce-sdk/commits/994d96b2553ba42aa00e9fab06bef9648868a8bd))
- 打包问题 ([cb88c96](https://git.woa.com/tce-tools/tce-sdk/commits/cb88c96a7ba648ee5b22e9c403964ffc623599c4))
- 拼写错误修复 ([d526187](https://git.woa.com/tce-tools/tce-sdk/commits/d526187597d88e649cddc3401cab9d30a42d432b))
- 接入公司最新 eslint 规范 ([e431b2c](https://git.woa.com/tce-tools/tce-sdk/commits/e431b2c5a2a19ddc3fe1ac8f1b037d2f20479e57))
- 接入公司最新 eslint 规范 ([b6590ef](https://git.woa.com/tce-tools/tce-sdk/commits/b6590efe64762344d1e8bea7690e5b1930b21a90))
- 接入公司最新 eslint 规范 ([2a354a3](https://git.woa.com/tce-tools/tce-sdk/commits/2a354a3073a468ba81b1f6135f0deb8aff7ac41b))
- 更改 build 顺序以修复 types 没有打包出来的问题 ([39f48ed](https://git.woa.com/tce-tools/tce-sdk/commits/39f48ed5d30a7e961fef6edd2bcede24b4bb120c))
- 更新 api 测试用例 ([f3caafa](https://git.woa.com/tce-tools/tce-sdk/commits/f3caafa83b8f823ed7d456beaa3f9807622a5fe9))
- 生成 pdf 命令修复 ([6919493](https://git.woa.com/tce-tools/tce-sdk/commits/6919493e644ecc0be2155e10e8f9a133e3a5c4b0))
- 缩进问题修复 ([b06f3d3](https://git.woa.com/tce-tools/tce-sdk/commits/b06f3d38bb26d7a0603f73db98019db767e248c8))
- 解决冲突 ([ce07a01](https://git.woa.com/tce-tools/tce-sdk/commits/ce07a011f11c9ea4971b99fedff699c77f49943c))
- 解决冲突 ([a170f80](https://git.woa.com/tce-tools/tce-sdk/commits/a170f80f6efccb39da7d63bd3784d2e0d10ac71c))
- 调整 tcs 运营端云 API 请求地址 ([50cbff3](https://git.woa.com/tce-tools/tce-sdk/commits/50cbff3a780f3155c0ad573ca5446a519cc64a3a))
- 购买页的 tcejs 默认加上异步获取地域 --bug=93551865 ([22fa34f](https://git.woa.com/tce-tools/tce-sdk/commits/22fa34f8c48b526da8d467d425a607dd42d17185))
- 需改 cam 的支持的版本为 390 ([e0b35eb](https://git.woa.com/tce-tools/tce-sdk/commits/e0b35eb8c785a57e83006e51e62f5b02835b9b1b))

### Features

- 修改单测 ([698228b](https://git.woa.com/tce-tools/tce-sdk/commits/698228b22768e4a550798abffbb0b3a697ab3c33))
- api 函数单测补充 ([5c76b81](https://git.woa.com/tce-tools/tce-sdk/commits/5c76b815b5a6a25ee2a6ec1db69dd72bb5f0a011))
- api 及部分 common 函数单测补充 ([758763b](https://git.woa.com/tce-tools/tce-sdk/commits/758763b3a6fb024f6b68b6a0e9c72b1c3277d7eb))
- csrfCode 优先从 cookie 中获取 --story=871043455 ([b0ae818](https://git.woa.com/tce-tools/tce-sdk/commits/b0ae8180345ceea5f60ba5641168667e09bec653))
- init ([1acbe49](https://git.woa.com/tce-tools/tce-sdk/commits/1acbe49dcb02a552721b237409da01e6575d33fd))
- init project ([e5caf2d](https://git.woa.com/tce-tools/tce-sdk/commits/e5caf2d7a008e8523e528e5dcce02b4daafe00f0))
- linux 上使用 chrome 加上--no-sandbox ([c16b307](https://git.woa.com/tce-tools/tce-sdk/commits/c16b3071530fe2fd77dbe012c3b9ebec3bb11479))
- linux 上使用 chrome 加上--no-sandbox ([344fc53](https://git.woa.com/tce-tools/tce-sdk/commits/344fc539e7bcd62c00244363024c8f04e153d857))
- region 函数单测补充 ([fee0cd8](https://git.woa.com/tce-tools/tce-sdk/commits/fee0cd818e3c4e4bbdd7f0df3e94b5b9d45dcde6))
- sdk 文档版本支持情况粒度更改为单个函数 ([2709845](https://git.woa.com/tce-tools/tce-sdk/commits/2709845abfb3b6d78dc623bba3920fd5d2fbfa52))
- security 文档更新 ([76d5ff1](https://git.woa.com/tce-tools/tce-sdk/commits/76d5ff16b780083b16561e2a2006568008df9559))
- tcesdk 增加腾讯国密 SDK 及更新完善单测用例 --story=865559115 ([968ec85](https://git.woa.com/tce-tools/tce-sdk/commits/968ec85127147d5cd81b8e581e989973a1f3c362))
- utils 单测增加 ([8bab8c6](https://git.woa.com/tce-tools/tce-sdk/commits/8bab8c6b466fd7b07ddc561099bdd582eb340bc9))
- util 类函数单测补充 ([7f91c3b](https://git.woa.com/tce-tools/tce-sdk/commits/7f91c3b8a2dabcb599e1e81566bfe26914a000f6))
- yapi error 增加 requestid 字段&新增反馈链接 ([fa8c5dc](https://git.woa.com/tce-tools/tce-sdk/commits/fa8c5dc8d8c2f1dece073803923e60ed49eccf59))
- yApi 单测补充 ([4b47c34](https://git.woa.com/tce-tools/tce-sdk/commits/4b47c341beb746a746ae069b49978591708ba88e))
- 修复 axios 的 ts 定义 ([cd410ec](https://git.woa.com/tce-tools/tce-sdk/commits/cd410ec0be2f057dbc5e1988ea423eec36494fe1))
- 修复全局地域缓存 bug --story=93551865 ([54cf765](https://git.woa.com/tce-tools/tce-sdk/commits/54cf7651b3aab9f11d5cd4c43eaa4a2e1dc4e85d))
- 修复打包出现的 bug ([9b37b92](https://git.woa.com/tce-tools/tce-sdk/commits/9b37b921671f9c636c64428213ef64320668e4e0))
- 修改 TS 定义生成 --story=869425893 ([d73a1a9](https://git.woa.com/tce-tools/tce-sdk/commits/d73a1a9e656032304f8b4c094ef4316e7ac6517a))
- 修改前端加密方式 ([229f254](https://git.woa.com/tce-tools/tce-sdk/commits/229f2544eb0564cf9a30e45b95ca165bdde1811e))
- 修改单元测试生成文件的路径 ([b43e259](https://git.woa.com/tce-tools/tce-sdk/commits/b43e2596ec7d7e61bd566cb1350a7b11938631c3))
- 修改文档 --story=871043455 ([1fe553e](https://git.woa.com/tce-tools/tce-sdk/commits/1fe553e4052322b83b61159a6fbf73ca9b0b7bc3))
- 修改文档，增加注意事项 --story=871043455 ([a2ff260](https://git.woa.com/tce-tools/tce-sdk/commits/a2ff2603b07e7810f50c772662b6414ebeb48367))
- 修改补充 CAM 文档 ([2d1d16f](https://git.woa.com/tce-tools/tce-sdk/commits/2d1d16fe6b5b495526097401f46d1538dfa55d5c))
- 修改部分文档 ([eeb087f](https://git.woa.com/tce-tools/tce-sdk/commits/eeb087fb99d9267b1667d2885dce9091ef6f1a89))
- 剩余函数单测补充 ([892edcc](https://git.woa.com/tce-tools/tce-sdk/commits/892edcc4bcc0ab5c466d0b3985cefd6c71cca273))
- 加密增加默认参数,兼容没有配置加密方式的客户 ([76dc919](https://git.woa.com/tce-tools/tce-sdk/commits/76dc919cf547c710052b2536c683508abf94418e))
- 去掉 crossorigin,避免出现跨域问题 ([a4839aa](https://git.woa.com/tce-tools/tce-sdk/commits/a4839aab12be9d1271aed3b6fa51734543b16de5))
- 去掉 prettier,使用 vs-code-prettier-eslint 作为默认格式化插件 ([fb75782](https://git.woa.com/tce-tools/tce-sdk/commits/fb75782bbe63bea6cc455db16ac263a55e92e9c4))
- 去掉 Promise.resolve ([98ce4e6](https://git.woa.com/tce-tools/tce-sdk/commits/98ce4e6e201790baf53b60c24e72fa8e4c3b594e))
- 去掉一个 base_encode ([4852222](https://git.woa.com/tce-tools/tce-sdk/commits/485222223d5f3741b5a276299abcdea8bb841ef7))
- 去掉部分无效代码 ([43cac1f](https://git.woa.com/tce-tools/tce-sdk/commits/43cac1fee87c2472184723f3c323aaf45c2abaf6))
- 地域增加通过子产品 ID 类获取 ([37b557b](https://git.woa.com/tce-tools/tce-sdk/commits/37b557b0202c90dfebc61c8a0edd8a005c7599d7))
- 增加@commitlint/cli @commitlint/config-conventional ([5212c14](https://git.woa.com/tce-tools/tce-sdk/commits/5212c14072d2e5b26ada2c3a78515c9c3bffe226))
- 增加 apiResI18nHandler 国际化工具方法 ([864f358](https://git.woa.com/tce-tools/tce-sdk/commits/864f3582461f48341e435c026ed5e2e7d774920f))
- 增加 iframe 场景时候调用 tcesdk ([ed6e57c](https://git.woa.com/tce-tools/tce-sdk/commits/ed6e57cd026d3dbda00e784a73f9eebe5e021821))
- 增加 language 和 util ([d5b8e1e](https://git.woa.com/tce-tools/tce-sdk/commits/d5b8e1e98b9601f5f965e90840cd9d24c45be51d))
- 增加 pdf 文档排序功能&修改 pdf 路径&修改单测超时时间限制 ([05d08d2](https://git.woa.com/tce-tools/tce-sdk/commits/05d08d2b6639623e57ee654e5bed95d1b2242340))
- 增加 plantform 单测，增加 chai-spy 包 ([c42ba47](https://git.woa.com/tce-tools/tce-sdk/commits/c42ba47b759936179878e3c3489f2ca935c99146))
- 增加 platform 文档 ([c593954](https://git.woa.com/tce-tools/tce-sdk/commits/c593954152b237934bf8afa0277fa7303ca1e2cb))
- 增加 prepublish prebuild ([a8166cd](https://git.woa.com/tce-tools/tce-sdk/commits/a8166cd5893379609585bea18397ce7358692099))
- 增加 prepublish prebuild ([c3148b7](https://git.woa.com/tce-tools/tce-sdk/commits/c3148b7e6c23316ea69b53b087e0f3c2de927e9d))
- 增加 rsa2048 明文太长分段加密的能力,获取用户信息 sdk 增加 appId 出参 ([c7ab0f6](https://git.woa.com/tce-tools/tce-sdk/commits/c7ab0f6b3668360874bca4e14d021c8bde59fae1))
- 增加 rsa 公钥加密方法及增加 docs ([c7dc21e](https://git.woa.com/tce-tools/tce-sdk/commits/c7dc21e71215aa6898033695fd75437f55ddd4bf))
- 增加 tcs 获取 reginList 中 zone 的信息 ([57ec6d2](https://git.woa.com/tce-tools/tce-sdk/commits/57ec6d2ddf8bb5df395aeb64f89bfaee796c91be))
- 增加 uglify 代码压缩 ([32ed6ad](https://git.woa.com/tce-tools/tce-sdk/commits/32ed6ada81e65e3cd34c85c4ef4f51b4835a44f1))
- 增加 window 下的全局变量定义，增加加密方法和组件定义 ([11d8679](https://git.woa.com/tce-tools/tce-sdk/commits/11d86794e9d060147c65b15cf0ec3aa16cf840fd))
- 增加加密默认值处理 ([6b09cb4](https://git.woa.com/tce-tools/tce-sdk/commits/6b09cb4455564d837d7d646872eaf68c77e2e40f))
- 增加单元测试和覆盖测试 ([f91fbf6](https://git.woa.com/tce-tools/tce-sdk/commits/f91fbf625d6643cab90484c9729836e95f63f8e6))
- 增加平台退出方法,云 API 请求增加登录态失效及 IP 限制的弹框 ([5ce1159](https://git.woa.com/tce-tools/tce-sdk/commits/5ce1159a42152c335a6eafac98e74809e38d89de))
- 增加异地登录保护 foyo 配置 --story=868178271 ([88c302c](https://git.woa.com/tce-tools/tce-sdk/commits/88c302c5c3771581da8431a4d4b64128cb9a8cc6))
- 增加异步获取用户信息 SDK\电话邮箱脱敏 SDK --bug=92525037 ([d1854f4](https://git.woa.com/tce-tools/tce-sdk/commits/d1854f4ea25abb9063e4c7940f594aa8d3be4da6))
- 增加异步获取配置中心 sdk 函数，补充文档及单测 ([c6f7cb1](https://git.woa.com/tce-tools/tce-sdk/commits/c6f7cb11723844d08036b9818ba5e14f25b1d389))
- 增加弹性变量控制租户端及运营端登录态 skey 是否设置为 httponly --story=871043455 ([96b4e34](https://git.woa.com/tce-tools/tce-sdk/commits/96b4e3499b2e7d13483785d2b2f1fd40bd4758d8))
- 增加打包时单独合成 types 文件功能&优化部分函数结构 ([ad5fe76](https://git.woa.com/tce-tools/tce-sdk/commits/ad5fe760d9374daeb40a125c94f79263e8c75c99))
- 增加模拟获取 url 的 search 参数方法 ([a0de967](https://git.woa.com/tce-tools/tce-sdk/commits/a0de967683f51f7912d02b3f7e0c6b07d48b95db))
- 增加点击下载链接 ([5364bbd](https://git.woa.com/tce-tools/tce-sdk/commits/5364bbd35874d68b66b2264ea3ec5adffbe8ff3c))
- 增加组件调用方法 ([ed81194](https://git.woa.com/tce-tools/tce-sdk/commits/ed81194f25355e64b41cf02b08bbc6e9efc96735))
- 增加获取 title 和获取 logo 的方法 ([f498273](https://git.woa.com/tce-tools/tce-sdk/commits/f498273065c65559485964e08846a2a45a833ccc))
- 增加获取 uuid 的方法、增加 showPreLoginModal 方法 ([2e99507](https://git.woa.com/tce-tools/tce-sdk/commits/2e99507939a8d86ac5f7d37212a962fcdb031fc7))
- 增加获取地域的列表及云 API 请求的方式 ([ce360d3](https://git.woa.com/tce-tools/tce-sdk/commits/ce360d3de11d70a5eb418480a5e601cc1c76b9ec))
- 增加获取客制化产品配置的方法 ([4fb7cba](https://git.woa.com/tce-tools/tce-sdk/commits/4fb7cbaa2742a764972a0ddbfcb6b3514ffd6f45))
- 增加获取弹性变量方法 --story=864222927 ([b532f61](https://git.woa.com/tce-tools/tce-sdk/commits/b532f61a24c42e270833ce87a4157cd31f5b9004))
- 增加获取当前用户及地域信息方法 ([7d3a124](https://git.woa.com/tce-tools/tce-sdk/commits/7d3a124e545d75ffb3c9b51ea31f1fd49bc3033e))
- 处理循环依赖的问题 ([5b6423e](https://git.woa.com/tce-tools/tce-sdk/commits/5b6423e223a0bfd3a7275a00d6639ff5fc59cee1))
- 完善各个方法的版本支持情况 ([25ec69b](https://git.woa.com/tce-tools/tce-sdk/commits/25ec69be82835928b3959ec3f04e0875a654892d))
- 完善文档 ([c92f939](https://git.woa.com/tce-tools/tce-sdk/commits/c92f939432724e85bbfad323ce756f1c4d66e1d6))
- 完善文档 ([63855bc](https://git.woa.com/tce-tools/tce-sdk/commits/63855bc61a127b5a7bd1df0b2edc9bbe07860b9a))
- 完善文档,增加 window 及 iframe 使用 tcesdk 的时候增加 tcesdk 完整声明 ([ac44243](https://git.woa.com/tce-tools/tce-sdk/commits/ac4424398fad7d3aedb75faf0d653d017a438598))
- 将 chrome 浏览器改成 ChromeHeadless ([ebf44d3](https://git.woa.com/tce-tools/tce-sdk/commits/ebf44d34b0d98517c6b955bdb83d3b9e4f0c1d9c))
- 将 chrome 浏览器改成 ChromeHeadless ([e1ae752](https://git.woa.com/tce-tools/tce-sdk/commits/e1ae752906162df15c8fa9b732ca5db015318167))
- 将 tce-sdk 中的运营端的云 API 请求的域名修改为最新的 oapi --story=865732921 ([d6c10f3](https://git.woa.com/tce-tools/tce-sdk/commits/d6c10f3c2a5c5d551cbb14ad4e93a12ef2849ad3))
- 将前端加密方法改成异步的,动态加载 jsencrypt ([e775db1](https://git.woa.com/tce-tools/tce-sdk/commits/e775db1759182e5744ab8a330ef3d5e030402a5d))
- 将文档外链移到 header ([f23ce35](https://git.woa.com/tce-tools/tce-sdk/commits/f23ce357590017ac0f9b9782412bf8a1a0f7944a))
- 文档版本表格样式修改 ([dad2c1b](https://git.woa.com/tce-tools/tce-sdk/commits/dad2c1be9b34af6e9607a5694dd74a8463fda0db))
- 文档生成 script 修改 ([95ceba7](https://git.woa.com/tce-tools/tce-sdk/commits/95ceba72f7fa982541f06dd93440dd5681bdd269))
- 新增接口文档补充 ([dccd54f](https://git.woa.com/tce-tools/tce-sdk/commits/dccd54f6480414e53fbb08773a869c98fa2688c1))
- 暂时加上 pollyfill ([df4647f](https://git.woa.com/tce-tools/tce-sdk/commits/df4647f5fd15eaa452735bb38a5b350993d1a233))
- 测试下 webHook ([6e546b4](https://git.woa.com/tce-tools/tce-sdk/commits/6e546b4f7dff77e86170dd3d6a6f984393525e59))
- 添加 AUTHSDK ([355f151](https://git.woa.com/tce-tools/tce-sdk/commits/355f1515eb0fed4fd3558186956f80bc50b4ff71))
- 添加 build:pdf 命令以生产 pdf 版文档 ([8a9e925](https://git.woa.com/tce-tools/tce-sdk/commits/8a9e9253688b3f5cb523694567366f22848f231f))
- 添加 cam ([f4dd7ec](https://git.woa.com/tce-tools/tce-sdk/commits/f4dd7ec2ce2efbaaec559be15b5868e08613729f))
- 添加 cam ([438a1fc](https://git.woa.com/tce-tools/tce-sdk/commits/438a1fc0bdd68793cd06e643d565a11800fc0bd9))
- 添加同步获取配置的方法、文档及单测 ([7a6e257](https://git.woa.com/tce-tools/tce-sdk/commits/7a6e257ab196bf7b81ea8b27eadff7b2f7f2698e))
- 添加安全方法 ([40ae4d7](https://git.woa.com/tce-tools/tce-sdk/commits/40ae4d7bec48c125cc7c4e26146392715483e5aa))
- 添加异步获取国家 code 函数 ([569a016](https://git.woa.com/tce-tools/tce-sdk/commits/569a016f1cf9425741c538f608326c168136326b))
- 添加检测函数行为库 sinon，补充 plantform location 相关单测 ([dc8dfbd](https://git.woa.com/tce-tools/tce-sdk/commits/dc8dfbdf919cab698aaa5950a931438578a0c634))
- 添加获取国家姓名及 code 功能的文档 ([e1d7d10](https://git.woa.com/tce-tools/tce-sdk/commits/e1d7d10e9c800f2ece6e3859ee3a18c0c7debe4e))
- 添加配置中心获取和设置函数 ([04abe72](https://git.woa.com/tce-tools/tce-sdk/commits/04abe72bb88ed9df298a7ef1ebd7b4548c700308))
- 补充 config 文档，将对外的常量从 constants 中迁出 ([536698f](https://git.woa.com/tce-tools/tce-sdk/commits/536698fa63e75e2d66a5abceecb0cdedb04a689d))
- 补充 sdk 中组件的使用文档 ([1014f5c](https://git.woa.com/tce-tools/tce-sdk/commits/1014f5cb426adbf933d4634cbce89aacc4c7cbf0))
- 补充常量说明 ([78c82d8](https://git.woa.com/tce-tools/tce-sdk/commits/78c82d88bd530ba1e9c149fed466fc7761c9d738))
- 补充文档 ([be99cce](https://git.woa.com/tce-tools/tce-sdk/commits/be99cce8540f0c594b5ac24673045b8af3bfa5bc))
- 补充防 CSRF 串函数单测 ([27eaa82](https://git.woa.com/tce-tools/tce-sdk/commits/27eaa82e81318e1c4a3d826cb2ebf3a8603db58d))
- 迁移多个 util 类函数，补充文档 ([22ebbbf](https://git.woa.com/tce-tools/tce-sdk/commits/22ebbbf68ae1ae30e073e01435b24887e3c556ba))
- 迁移获取防 CSRF 串函数 ([1fa997c](https://git.woa.com/tce-tools/tce-sdk/commits/1fa997cb49e12f414cc4fd4153a9c815a2250bd0))
- 通过弹性变量控制日志收集 --bug=91940927 ([88905c2](https://git.woa.com/tce-tools/tce-sdk/commits/88905c2e45d19ab3562f248ffedf6740a636d457))
