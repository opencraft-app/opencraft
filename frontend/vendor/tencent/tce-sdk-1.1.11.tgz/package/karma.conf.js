// Karma configuration
// Generated on Wed Apr 14 2021 16:22:17 GMT+0800 (GMT+08:00)
const path = require('path');

// 需要测试的模块
const testModule = process.env.test_module ? `${process.env.test_module}.spec` : 'index';
const singleRun = process.env.singleRun === 'false' ? false : true;
const isDebug = process.env.IS_DEBUG === 'true' ? true : false
module.exports = function (config) {
  config.set({
    client: {
      mocha: {
        timeout: 10000
      }
    },
    // base path that will be used to resolve all patterns (eg. files, exclude)
    // basePath: '',

    // frameworks to use
    // available frameworks: https://npmjs.org/browse/keyword/karma-adapter
    // 添加mocha测试框架，chai断言库
    frameworks: ['mocha', 'chai', 'sinon'],

    // list of files / patterns to load in the browser
    files: [
      { pattern: 'assets/**/*.js', 'included': false }, // 引入可以访问，但不包含
      `test/${testModule}.ts`
    ],

    // list of files / patterns to exclude
    // exclude: [],

    // preprocess matching files before serving them to the browser
    // available preprocessors: https://npmjs.org/browse/keyword/karma-preprocessor
    preprocessors: {
      [`test/${testModule}.ts`]: ['webpack'],
      'src/**/*.ts': ['webpack']
    },

    // test results reporter to use
    // possible values: 'dots', 'progress'
    // available reporters: https://npmjs.org/browse/keyword/karma-reporter
    reporters: ['nyan', 'coverage-istanbul'],

    // web server port
    // port: 9876,

    // enable / disable colors in the output (reporters and logs)
    // colors: true,

    // level of logging
    // possible values: config.LOG_DISABLE || config.LOG_ERROR || config.LOG_WARN || config.LOG_INFO || config.LOG_DEBUG
    // logLevel: config.LOG_INFO,

    // enable / disable watching file and executing tests whenever any file changes
    // autoWatch: true,

    // start these browsers
    // available browser launchers: https://npmjs.org/browse/keyword/karma-launcher
    // browsers: ['ChromeHeadless'],
    // linux下，chrome打开需要使用--no-sandbox
    browsers: isDebug ? [] : ['ChromeHeadlessNoSandbox'],
    customLaunchers: {
      ChromeHeadlessNoSandbox: isDebug ? {
        base: 'ChromeHeadless',
        flags: [
          "--no-sandbox",
          "--user-data-dir=/tmp/chrome-test-profile",
          "--disable-web-security",
          "--remote-debugging-port=9876",
        ],
        debug: true,
      } : {
        base: 'ChromeHeadless',
        flags: ["--no-sandbox"],
      }
    },

    // Continuous Integration mode
    // if true, Karma captures browsers, runs the tests and exits
    singleRun: singleRun,

    // Concurrency level
    // how many browser should be started simultaneous
    // concurrency: Infinity,
    mime: {
      'text/x-typescript': ['ts']
    },

    webpackMiddleware: {
      noInfo: true,
      stats: 'errors-only'
    },
    webpack: {
      mode: 'development',
      entry: './src/index.ts',
      output: {
        filename: '[name].js'
      },
      devtool: 'inline-source-map',
      module: {
        rules: [
          {
            test: /\.ts$/,
            use: {
              loader: 'babel-loader'
            },
            exclude: [path.join(__dirname, 'node_modules')]
          },
          {
            test: /\.ts$/,
            include: [path.join(__dirname, 'src')],
            enforce: 'post',
            use: {
              loader: 'istanbul-instrumenter-loader',
              options: { esModules: true }
            }
          }
        ]
      },
      resolve: {
        extensions: ['*', '.ts', '.js', '.json'],
        alias: {
          src: path.resolve(__dirname, 'src')
        }
      }
    },

    coverageIstanbulReporter: {
      reports: ['html', 'lcovonly', 'text-summary'],
      // dir: path.join(__dirname, 'coverage/%browser%/'),
      dir: path.join(__dirname, 'coverage/chrome_headless/'),
      fixWebpackSourcePaths: true,
      'report-config': {
        html: { outdir: 'html' }
      },
      thresholds: {
        global: {
          statements: 100,
          lines: 100,
          branches: 100,
          functions: 100
        }
      }
    },

    nyanReporter: {
      renderOnRunCompleteOnly: true
    }
  });
};
