module.exports = {
  extends: [
    '@tencent/eslint-config-tencent',
    '@tencent/eslint-config-tencent/ts',
    '@tencent/eslint-config-tencent/prettier',
  ],
  globals: {
    // 这里填入你的项目需要的全局变量
    // 这里值为 false 表示这个全局变量不允许被重新赋值，比如：
    //
    // jQuery: false,
    // $: false
  },
  ignorePatterns: ['.eslintrc.js'],
  parserOptions: {
    project: './tsconfig.eslint.json',
  },
  rules: {
    // 这里填入你的项目需要的个性化配置，比如：
    //
    // 一个缩进必须用两个空格替代
    'max-params': ['error', 4],
    'prefer-promise-reject-errors': 'off',
    '@typescript-eslint/no-invalid-this': 'off',
    '@typescript-eslint/member-ordering': 'off',
    '@typescript-eslint/naming-convention': ['off'],
  },
};
