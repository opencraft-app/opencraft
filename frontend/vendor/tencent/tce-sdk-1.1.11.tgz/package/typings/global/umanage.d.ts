import { StyledProps } from '@tencent/tea-component';

declare const UMANAGE: {
  getComponent: () => typeof AppIdBubble;
};

interface IProps extends StyledProps {
  AppId?: number;
  Uin?: number;
}
declare const AppIdBubble: ({ AppId, Uin, ...rest }: IProps) => JSX.Element;
export type UMANAGEProps = typeof UMANAGE;
export { AppIdBubble as default };
