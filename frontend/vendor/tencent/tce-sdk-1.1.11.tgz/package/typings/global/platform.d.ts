/// <reference types="react" />

export interface CommonProps {
  code: string;
  name?: string | undefined;
  icon?: string | string[];
}
export interface NavbarProps {
  logo: logoProps;
  platformLabel?: platformLabelProps;
  left: LeftItem[];
  right: RightItem[];
}
export interface logoProps {
  src: string;
  href: string;
  width?: number | string;
  height?: number | string;
}
export interface platformLabelProps {
  label: string;
  display: boolean;
}
export interface LeftItem extends CommonProps {
  href?: string;
  platform?: string;
  types?: LeftItemTypes[];
}
export interface LeftItemTypes extends CommonProps {
  modules: LeftItemTypesModules[];
}
export interface LeftItemTypesModules {
  uuid: string;
  name: string;
  href: string;
  target?: string;
}
export interface RightItem extends CommonProps {
  children?: any;
  callback?: Function;
  current?: string;
  badgeFunc?: Function;
  visible?: boolean;
}
export interface SidebarProps {
  title: string;
  menus: MenuProps[];
}
export interface MenuProps {
  name: string;
  uuid: string;
  href?: string;
  menus?: MenuProps[];
  icon?: any;
  className?: string | undefined;
}
export interface DialogParamProps {
  animation?: boolean;
  button?: object;
  title: string;
  preventResubmit: boolean;
  closeIcon?: boolean;
  mask?: boolean;
  class?: string;
  isMaskClickHide?: boolean;
  defaultCancelBtn?: boolean;
  defaultCancelCb?: Function;
  beforeButtonHtml?: string;
  buttonHighlight?: any;
  buttonDisable?: any;
  callback?: any;
  onload?: Function;
  owner?: string;
  time?: number;
}
export interface IPageStatusParam extends IPageStatusProps {
  /**
   * 挂载点
   */
  mountNode: string;
}
export interface IPageStatusProps {
  /**
   * status类型
   */
  type: 'loading' | '404' | 'error' | 'unauthorized';
  /**
   * 标题
   */
  title?: string;
  /**
   * 描述信息
   */
  description?: string;
  /**
   * 自定义显示图片
   */
  imgSrc?: string;
}
declare const PLATFORMSDK: {
  Dialog: {
    create(
      html?: string | undefined,
      width?: number | undefined,
      height?: number | undefined,
      option?: DialogParamProps | undefined,
    ): void;
    hide(): void;
  };
  navBar: {
    render(id: string, menuData: NavbarProps, navigate: (href: string) => void): void;
    hide(): void;
  };
  sidebar: {
    render(id: string, data: SidebarProps, navigate: (href: string) => void, props: any): void;
    show(): void;
    hide(): void;
    expand(): void;
    collapse(): void;
    getCurrentMenu(): string;
    setCurrentMenu(href: string): void;
    hideMenuItem(href: string): void;
    customHeaderMenuItem(
      node: import('react').ReactElement<any, string | import('react').JSXElementConstructor<any>>,
    ): void;
  };
  pageStatus: {
    show(param: IPageStatusParam): void;
    hide(): void;
    hideFlash(): void;
  };
};
export declare type PLATFORMSDKProps = typeof PLATFORMSDK;
export default PLATFORMSDK;

export {};
