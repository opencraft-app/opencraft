declare function showApprovalModal(ApprovalDocID: number | string): Promise<unknown>;
declare const APPROVAL: {
  showApprovalModal: typeof showApprovalModal;
};
export type APPROVALProps = typeof APPROVAL;

export { APPROVAL as default };

export {};
