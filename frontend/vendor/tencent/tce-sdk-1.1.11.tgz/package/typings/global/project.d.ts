declare const GroupAccount: {
  renderGroupSelect: (el: string, onChange: (value: string) => void) => void;
  renderProjectSelect: (props: any) => void;
  renderProjectTreeSelect: (props: any) => void;
};
export type GroupAccountProps = typeof GroupAccount;

export { GroupAccount as default };

export {};
