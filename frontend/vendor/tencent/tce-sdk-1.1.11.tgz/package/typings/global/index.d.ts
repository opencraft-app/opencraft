import CryptoJS from 'crypto-js';
import XLSX from 'xlsx';
import { TCE_GLOBAL_CONSTANT, TCE_GLOBAL_CONSTANT_ASYNC, ComponentMap } from '../../src/common';
import { SeaJs } from '@tencent/types-tce-seajs';

type IConfigTabPlatform = 'tenant_side' | 'ops_side';
interface IConfigTab {
  code: string;
  name: string;
  platform: IConfigTabPlatform;
  showOnControl: 'Y' | 'N';
}

declare global {
  interface Window {
    TCE_GLOBAL_CONSTANT: TCE_GLOBAL_CONSTANT;
    TCE_GLOBAL_CONSTANT_ASYNC: TCE_GLOBAL_CONSTANT_ASYNC;
    g_product_config_data: any;
    g_platform_config_platformTabs: IConfigTab[];
    g_config_data: any;
    I18N_CONFIG: any;
    TCS: any;
    customizeVersion: any;
    __sdkRouterByTce: ComponentMap;
    CryptoJS: typeof CryptoJS;
    XLSX: typeof XLSX;
    seajs: SeaJs;
    $: any;
    jiguangPlatformMessage: any;
    isUseGetMaskedUserInfoByLoginUin: any;
  }
}
