declare const ANNOUNCE: {
  render: (id: string) => void;
};
export default ANNOUNCE;
export type ANNOUNCEProps = typeof ANNOUNCE;
