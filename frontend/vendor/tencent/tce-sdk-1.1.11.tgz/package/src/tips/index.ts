interface ITipsProps {
  showLoading: ({ text }) => void;
  stopLoading: () => void;
  success: (text: string, duration?: number) => void;
  error: (text: string, duration?: number) => void;
}

const getSeajsTips = () => window.seajs.require<ITipsProps>('tips');
/* istanbul ignore next */
// @ts-ignore
const getTeaNotification = () => window.TeaComponentV2?.notification;
/* istanbul ignore next */
// @ts-ignore
const getTeaMessage = () => window.TeaComponentV2?.message;

// loading实例【避免并发情况】
const loadingInsArr: any[] = [];

/**
 * 显示loading
 * @param text loading文本
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.10.0
 * @version TCE、TCS登录页、购买页 ❌
 * @version TCS控制台 >= 2.3.0
 */
export function showLoading(text?: string) {
  const teaMessage = getTeaMessage();
  const seajsTips = getSeajsTips();
  /* istanbul ignore next */
  if (seajsTips) {
    /* istanbul ignore next */
    seajsTips.showLoading({ text });
    return;
  }
  /* istanbul ignore next */
  if (teaMessage) {
    const loadingIns = teaMessage.loading({
      content: text || 'loading',
      duration: 0,
    });
    loadingInsArr.push(loadingIns);
    return;
  }
}
/**
 * 隐藏loading
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.10.0
 * @version TCE、TCS登录页、购买页 ❌
 * @version TCS控制台 >= 2.3.0
 */
export function hideLoading() {
  const seajsTips = getSeajsTips();
  /* istanbul ignore next */
  if (seajsTips) {
    /* istanbul ignore next */
    seajsTips.stopLoading();
    return;
  }
  /* istanbul ignore next */
  while (loadingInsArr.length > 0) {
    const loadingIns = loadingInsArr.pop();
    loadingIns?.hide();
  }
}
/**
 * 成功提示
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.10.0
 * @version TCE、TCS登录页、购买页 ❌
 * @version TCS控制台 >= 2.3.0
 * @param text 提示内容
 * @param duration 持续时间，默认为4秒
 */
export function success(text: string, duration = 4000) {
  const teaNotification = getTeaNotification();
  const seajsTips = getSeajsTips();
  /* istanbul ignore next */
  if (seajsTips) {
    seajsTips.success(text, duration);
    return;
  }
  /* istanbul ignore next */
  if (teaNotification) {
    teaNotification.success({ description: text, duration });
  }
}
/**
 * 失败提示
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.10.0
 * @version TCE、TCS登录页、购买页 ❌
 * @version TCS控制台 >= 2.3.0
 * @param text 提示内容
 * @param duration 持续时间，默认为4秒
 */
export function error(text: string, duration = 4000) {
  const teaNotification = getTeaNotification();
  const seajsTips = getSeajsTips();
  /* istanbul ignore next */
  if (seajsTips) {
    seajsTips.error(text, duration);
    return;
  }
  /* istanbul ignore next */
  if (teaNotification) {
    teaNotification.error({ description: text, duration });
  }
}
