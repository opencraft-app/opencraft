import { getConfigSync } from '../common/config';
import * as common from '../common';

export interface Language {
  /**
   * 是否为默认语言
   */
  default: boolean;
  /**
   * 语言名称
   */
  name: string;
  /**
   * 语言名称
   */
  currency?: string;
  /**
   * 购买页老版本的id就是新版本的name
   */
  id?: string;
}

export const {
  getCurrentLang,
  getLangList,
  getPlanLangList,
  LANGUAGE_TYPE,
  getCurrentCurrency,
  getCurrentCurrencyInfo,
} = common;

/**
 * 获取租户端语言列表【用于运营端获取租户端语言列表】
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.10.11
 * @version TCE登录页、购买页 >= 3.10.11
 * @version TCS ❌
 */
export function getTcloudLangList(): Language[] {
  const { defaultLang, langList } =
    (getConfigSync('tcenter_base', 'tcloud_language_list') as {
      defaultLang: string;
      langList: string[];
    }) || {};
  if (!langList || langList.length === 0) {
    return getPlanLangList();
  }
  return langList.map((lang) => ({
    default: lang === defaultLang,
    name: lang,
  }));
}
