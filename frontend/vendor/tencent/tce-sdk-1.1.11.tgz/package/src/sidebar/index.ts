import { ReactElement } from 'react';
type IVoidFun = () => void;

interface ISideBarProps {
  show: IVoidFun;
  hide: IVoidFun;
  expand: IVoidFun;
  collapse: IVoidFun;
  expandAllMenu: IVoidFun;
  hideMenuItem: (href: string) => void;
  customHeaderMenuItem: (node: ReactElement) => void;
}

/**
 * 显示sidebar
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.11.0
 * @version TCE登录页、购买页 ❌
 * @version TCS ❌
 */
export function show() {
  /* istanbul ignore next */
  window.seajs.require<ISideBarProps>('sidebar').show();
}
/**
 * 隐藏sidebar
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.11.0
 * @version TCE登录页、购买页 ❌
 * @version TCS ❌
 */
export function hide() {
  /* istanbul ignore next */
  window.seajs.require<ISideBarProps>('sidebar').hide();
}
/**
 * 展开
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.11.0
 * @version TCE登录页、购买页 ❌
 * @version TCS ❌
 */
export function expand() {
  /* istanbul ignore next */
  window.seajs.require<ISideBarProps>('sidebar').expand();
}
/**
 * 折叠sidebar
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.11.0
 * @version TCE登录页、购买页 ❌
 * @version TCS ❌
 */
export function collapse() {
  /* istanbul ignore next */
  window.seajs.require<ISideBarProps>('sidebar').collapse();
}

/**
 * 展开所有菜单
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.11.0
 * @version TCE登录页、购买页 ❌
 * @version TCS ❌
 */
export function expandAllMenu() {
  /* istanbul ignore next */
  window.seajs.require<ISideBarProps>('sidebar').expandAllMenu();
}

/**
 * 展开所有菜单
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.11.0
 * @version TCE登录页、购买页 ❌
 * @version TCS ❌
 */
export function hideMenuItem(href: string) {
  /* istanbul ignore next */
  window.seajs.require<ISideBarProps>('sidebar').hideMenuItem(href);
}

/**
 * 展开所有菜单
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.11.0
 * @version TCE登录页、购买页 ❌
 * @version TCS ❌
 */
export function customHeaderMenuItem(node: ReactElement) {
  /* istanbul ignore next */
  window.seajs.require<ISideBarProps>('sidebar').customHeaderMenuItem(node);
}
