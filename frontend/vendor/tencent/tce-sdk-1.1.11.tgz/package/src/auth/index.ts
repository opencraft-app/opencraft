import { getComponent } from '../component';

export async function getAUTH() {
  return getComponent('auth-sdk');
}
