/**
 * 获取当前环境所有的域名信息
 */

import { getGlobalConstants, isTceOcloud, isTceOcloudLogin } from '../common';

export interface TceDomain {
  /**
   * 登录域名
   */
  login?: string;
  /**
   * 主域
   */
  base?: string;
  /**
   * 租户端域名
   */
  tenantConsole?: string;
  /**
   * 官网域名
   */
  officialWebsite?: string;
  /**
   * 购买页域名
   */
  buy?: string;
  /**
   * imgcache域名
   */
  imgcache?: string;
  /**
   * cos域名
   */
  cos?: string;
  /**
   * csp域名
   */
  csp?: string;
  /**
   * qcbase域名
   */
  qcbase?: string;
  /**
   * 控制台域名
   */
  console?: string;
  /**
   * 文档域名
   */
  doc?: string;
  /**
   * 云api地址
   */
  yapiUrl?: string;
}

/**
 * 获取域名列表
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.1.0
 */
export function getDomainList(): TceDomain {
  const {
    loginHost,
    baseHost,
    officialWebsiteHost,
    imgcacheHost,
    buyHost,
    consoleHost,
    qcbaseHost,
    cosDomain,
    cspDomain,
    yapiUrl,
    tenantConsoleDomain,
  } = getGlobalConstants() || {};

  const docHost = `${isTceOcloud() || isTceOcloudLogin() ? 'document' : 'doc'}.${baseHost}`;

  return {
    login: loginHost,
    base: baseHost,
    officialWebsite: officialWebsiteHost,
    imgcache: imgcacheHost,
    buy: buyHost,
    console: consoleHost,
    qcbase: qcbaseHost,
    cos: cosDomain,
    csp: cspDomain,
    doc: docHost,
    tenantConsole: tenantConsoleDomain,
    yapiUrl,
  };
}

/**
 * 替换域名
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 ❌
 * @version TCS ❌
 */
export function replaceDomainInStr(str: string): string {
  const { innerMainDomain, baseHost } = getGlobalConstants() || {};
  if (!baseHost || !innerMainDomain) return str;
  if (innerMainDomain instanceof Array) {
    return innerMainDomain.reduce((prev, cur) => prev.replaceAll(cur, baseHost), str);
  }
  if (typeof innerMainDomain === 'string') {
    return str.replaceAll(innerMainDomain, baseHost);
  }
  return str;
}
