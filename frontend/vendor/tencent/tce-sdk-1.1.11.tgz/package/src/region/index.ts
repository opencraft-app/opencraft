import * as common from '../common';
import { getCurrentLang } from '../language';
import {
  getGlobalConstantsAsync,
  getCurrentUserInfo,
  isTceOcloud,
  isTceTcloud,
  isTcsOcloud,
  isTceTcloudBuy,
  isTcsTcloud,
} from '../common';
import { getQueryParameters } from '../utils';
import { IAPIRequest, yApiRequest } from '../api';
import { JS_COOKIE } from '../constants';
import { assets } from 'src/common/util';
import { ProvinceMap } from 'src/common/location_zh_cn';

export interface Region {
  /**
   * regionId，数字格式的
   */
  regionId: number;
  /**
   * region
   */
  region: string;
  /**
   * regionName: 根据不同语言返回的地域名称
   */
  regionName: string;
  zoneList: Zone[];
  /**
   * 地域角色(MR:主地域, SR:从地域, OR:其它地域)
   */
  regionRole?: string;
}

export interface Zone {
  zoneId: number;
  zone: string;
  zoneName: string;
}
export interface IDC {
  /**
   * 地域ID
   */
  regionId: number;
  /**
   * 可用区ID
   */
  zoneId: number;
  /**
   * IDC id
   */
  idcId: number;
  /**
   * IDC【字符串】
   */
  idc: string;
  /**
   * IDC名称【根据不同语言返回的地域名称】
   */
  idcName: string;
}

/**
 * DescribeRegionZone接口入参定义
 */
export interface DescribeRegionZoneReq {
  /**
   * TCE 产品Code
   */
  ProductId: string;
}

export interface DescribeRegionZoneResProduct {
  [key: string]: { [key: string]: { [key: string]: string[] } | null };
}

/**
 * DescribeRegionZone接口出参定义
 */
export interface DescribeRegionZoneRes {
  /**
   * 地域数量
   */
  RegionCount: number;
  /**
   * 地域信息
   */
  RegionSet: RegionEx[];
  /**
   * 产品列表
   */
  Products: DescribeRegionZoneResProduct;
}
/**
 * DescribeRegionZone 返回的 Region 描述信息
 */
export interface RegionEx {
  /**
   * 地域名称(固定为英文字符串, API使用)
   */
  Region: string;
  /**
   * 地域编号(国际化支持, 前端展示使用)
   */
  RegionID: string;
  /**
   * 地域名称
   */
  RegionName: string;
  /**
   * 地域状态(AVAILABLE/UNAVAILABLE)
   */
  RegionState: string;
  /**
   * 地域状态描述
   */
  RegionStateRemark: string;
  /**
   * 可用区数量
   */
  ZoneCount: number;
  /**
   * 可用区列表
   */
  ZoneSet: ZoneEx[];
  /**
   * 地域角色(MR:主地域, SR:从地域, OR:其它地域)
   */
  RegionRole: string;
}
/**
 * DescribeRegionZone 接口返回的 Zone 描述信息
 */
export interface ZoneEx {
  /**
   * 所属Region编号
   */
  RegionID: string;
  /**
   * 可用区名称(固定为英文字符串, API使用)
   */
  Zone: string;
  /**
   * 可用区编号
   */
  ZoneID: string;
  /**
   * 可用区名称(国际化支持, 前端展示使用)
   */
  ZoneName: string;
  /**
   * 可用区状态(AVAILABLE/UNAVAILABLE)
   */
  ZoneState: string;
  /**
   * 可用区状态(原因描述)
   */
  ZoneStateRemark: string;
  /**
   * 可用区角色（MAZ:主可用区, SAZ:从可用区, OAZ:其它可用区）
   */
  ZoneRole: string;
}

/**
 * getCountryCode返回的国家名和code
 */
export interface ICountry {
  Name: string;
  Code: string;
}

/**
 * 异步获取地域列表
 * @param productCode 产品code【非必填，不传的时候直接返回所有的地域】
 * @param subProductCode 产品code【非必填】
 */
export async function getRegionListAsync(productCode?: string, subProductCode?: string): Promise<Region[]> {
  // TCS没有部署Location服务，如果当前是TCS，则直接同步获取
  if (isTcsOcloud() || isTcsTcloud()) {
    const data = common.getRegionListSync();
    if (data.length) {
      return data.map((item) => {
        const { region, regionId, regionName, zoneList } = item;
        return {
          regionId: Number(regionId),
          regionName,
          region,
          regionRole: '',
          zoneList: zoneList.map((item) => {
            const { zone, zoneId, zoneName } = item;
            return {
              zone,
              zoneId: Number(zoneId),
              zoneName,
              zoneRole: '',
            };
          }),
        };
      });
    }
    return [];
  }

  // 如果已经获取过一次，则优先同步获取【只针对获取所以地域的场景】
  const regionList = getGlobalConstantsAsync()?.regionList ?? [];
  if (!productCode && !subProductCode && regionList.length > 0) {
    return regionList;
  }

  const data = {
    ProductId: productCode || 'SPECIAL_LOGIC_ALL_REGION_ZONE', // 如果产品code为空，则设置一个通用可以获取所有地域的产品code
  };

  // 如果有子产品code的时候
  if (subProductCode) {
    Object.assign(data, { SubProductId: subProductCode });
  }

  const reqData: IAPIRequest<DescribeRegionZoneReq> = {
    serviceType: 'location',
    action: 'DescribeRegionZone',
    version: '2019-11-28',
    region: '', // 获取地域接口不需要传入地域
    data,
  };
  const { res, err } = await yApiRequest<DescribeRegionZoneReq, DescribeRegionZoneRes>(reqData);
  if (err) {
    return [];
  }
  const resRegionList = res.RegionSet.filter((item) => item.RegionState === 'AVAILABLE').map((item) => {
    const { Region, RegionID, RegionName, ZoneSet, RegionRole } = item;
    return {
      regionId: Number(RegionID),
      regionName: RegionName,
      region: Region,
      regionRole: RegionRole,
      zoneList: ZoneSet.filter((item) => item.ZoneState === 'AVAILABLE').map((item) => {
        const { ZoneID, ZoneName, Zone, ZoneRole } = item;
        return {
          zone: Zone,
          zoneId: Number(ZoneID),
          zoneName: ZoneName,
          zoneRole: ZoneRole,
        };
      }),
    };
  });

  // 查询全量地域的时候，把获取到的地域缓存起来
  if (!productCode && !subProductCode && resRegionList.length > 0) {
    if (window.TCE_GLOBAL_CONSTANT_ASYNC) {
      window.TCE_GLOBAL_CONSTANT_ASYNC.regionList = resRegionList;
    } else {
      window.TCE_GLOBAL_CONSTANT_ASYNC = { regionList: resRegionList };
    }
  }
  return resRegionList;
}

/**
 * 异步获取当前region信息
 * 适用TCE租户端购买页
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE租户端控制台、购买页 >= 3.10.0
 * @version TCE运营端控制台 >= 3.8.0
 * @version TCE、TCS登录页 ❌
 * @version TCS控制台 >= 2.1.0
 * @param regionId 地域ID 非必填，不传的时候会从当前url中获取,都没有的情况下取列表第一个
 */
export async function getCurrentRegionAsync(regionId?: string) {
  let regRegionId = regionId;
  if (!regRegionId) {
    const query = getQueryParameters();
    const { regionId, rid } = query;
    regRegionId = regionId || rid;
  }
  const regionList = await getRegionListAsync();
  const filterRegion = regionList.filter((regionInfo) => String(regionInfo.regionId) === String(regRegionId));
  if (filterRegion.length === 0) {
    // 没有的话取第一个
    return regionList[0];
  }
  return filterRegion[0];
}

/**
 * 同步方式获取地域列表，不区分产品
 */
export const { getRegionListSync } = common;

/**
 * 获取当前region信息
 * 获取优先级  url or localStorage
 * 适用TCE租户端控制台、TCE运营端控制台、TCS控制台
 */
export const { getCurrentRegion } = common;

/**
 * 根据语言获取国家名称和代码
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.1.0
 * @param language 语言
 */
export async function getCountryCodeAsync(language: string = getCurrentLang()): Promise<ICountry[]> {
  const { imgcacheHost } = common.getGlobalConstants() ?? {};
  const langMap = {
    'en-US': 'EnName',
    'zh-CN': 'Name',
  };

  if (!imgcacheHost) {
    throw 'imgcacheHost not exist';
  }

  if (!window.country) {
    try {
      // 异步加载加密js
      await common.getSource(`${assets.getTceSdkAssetsBasePath()}/country/country.js`);
    } catch (error) {
      throw 'load country failed';
    }
  }

  return window.country._countryCode.map(({ Code, ...rest }) => ({
    Name: rest[langMap[language] || 'Name'],
    Code,
  }));
}

/**
 * 根据语言获取省市区列表
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.1.0
 * @param language 语言
 */
export async function getLocationAsync(language: string = getCurrentLang()): Promise<ProvinceMap> {
  const { imgcacheHost } = common.getGlobalConstants() ?? {};
  const langMap = {
    'en-US': 'en_us',
    'zh-CN': 'zh_cn',
  };

  if (!imgcacheHost) {
    throw 'imgcacheHost not exist';
  }

  if (!window[`provinceMap_${langMap[language]}`]) {
    try {
      // 异步加载加密js
      await common.getSource(`${assets.getTceSdkAssetsBasePath()}/location/location_${langMap[language]}.js`);
    } catch (error) {
      throw 'load country failed';
    }
  }

  return window[`provinceMap_${langMap[language]}`];
}
/**
 * 设置当前地域
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、TCE购买页 >= 3.8.0
 * @version TCE、TCS登录页 ❌
 * @version TCS ❌
 * @param {String} region 地域名称,运营端为英文如'chongqing',租户端为ID
 */
export function setRegion(region: string): void {
  if (isTceOcloud()) {
    localStorage[`${getCurrentUserInfo()!.userName}_zone_region`] = region;
  }
  if (isTceTcloud() || isTceTcloudBuy()) {
    JS_COOKIE.set('regionId', region, { domain: document.domain });
    localStorage[`${getCurrentUserInfo()!.userUin}_regionId`] = region;
  }
}

/**
 * 获取IDC列表
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE运营端控制台 >= 3.11.0
 * @version TCE、TCS登录页、TCE租户端、购买页 ❌
 * @version TCS控制台 >= 2.3.0
 * @param zoneId 可用区ID
 */
export function getIDCList(zoneId: number): IDC[] {
  const idcList: any[] = isTcsOcloud() || isTcsTcloud() ? window.TCS.idcList : window.I18N_CONFIG.idcList;
  // 获取当前语言
  const currentLang = getCurrentLang();
  return (idcList || [])
    .filter((idc) => String(idc.zone_id) === String(zoneId))
    .map((idc) => {
      const { idc_id, region_id, zone_id, idc_name, ...rest } = idc;
      return {
        regionId: region_id,
        zoneId: zone_id,
        idcId: idc_id,
        idc: idc_name,
        idcName: rest[`idc_name_${currentLang}`],
      };
    });
}
