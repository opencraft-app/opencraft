import { getDomainList } from 'src/domain';
import { isTceOcloud, isTceTcloud, isTcsOcloud, isTcsTcloud, TCESDK_ASSETS_BASE_PATH } from '../common';

/**
 * 生成带签名的字符串
 * @param data 待签名的data
 */
export function generateSignStr<T extends object>(data: T): string {
  // 对需要签名的数据的key排序
  const keys = Object.keys(data);
  keys.sort();
  // 组装待签名的字符串
  let signStr = '';
  for (const key of keys) {
    const value = data[key];
    if (value) {
      signStr += `${key}=${value}&`;
    }
  }
  signStr = signStr.substring(0, signStr.length - 1);
  return signStr;
}

/**
 * 获取当前平台类型
 */
export function getCurrentPlatformForFile() {
  if (isTceOcloud() || isTcsOcloud()) {
    return 'ocloud';
  }
  if (isTceTcloud() || isTcsTcloud()) {
    return 'tcloud';
  }
  return '';
}

/**
 * 获取不同平台file服务的地址
 * @returns url
 */
export function getFileServerUrl() {
  let url = '';
  const domains = getDomainList();
  const { base, console } = domains;
  if (isTceOcloud() || isTceTcloud()) {
    url = `//file.${base}`;
  }
  if (isTcsOcloud() || isTcsTcloud()) {
    url = `//file.${console}`;
  }
  return url;
}

/**
 * 获取crypto-js 加载地址
 * @returns url
 */
export function getCryptoJsUrl() {
  const { imgcache } = getDomainList();
  return `//${imgcache}/${TCESDK_ASSETS_BASE_PATH}/crypto-js/crypto-js.min.js`;
}
