import { AXIOS } from 'src/constants';
import { generateSignStr, getCurrentPlatformForFile, getFileServerUrl } from './helper';
import { IFileUploadParam, IFileUploadResp, IGetFileUploadUrlParam } from './type';
import { getCSRFToken } from 'src/security';
import TceSDKException from 'src/common/tce_sdk_exception';
import { uuid } from 'src/utils';

/**
 * 文件上传
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.11.0
 * @version TCE、TCS登录页 ❌
 * @version TCS控制台 >= 2.3.0
 * @param uploadParam 上传参数
 * @returns Promise<IFileUploadResp>
 */
export async function upload(uploadParam: IFileUploadParam): Promise<IFileUploadResp> {
  const { appId, module, file, fileName } = uploadParam || {};

  // 获取上传文件服务地址
  const fileUploadUrl = getUploadUrl({ appId, module, fileName });

  if (!file) {
    throw new TceSDKException('file can not empty');
  }

  // 使用axios发送请求
  const axiosInstance = AXIOS.create({
    timeout: 60000,
    withCredentials: true,
  });

  try {
    const resp = await axiosInstance.post(fileUploadUrl, file, {
      headers: {
        'Content-Type': 'multipart/form-data',
        'X-CsrfCode': getCSRFToken(),
      },
    });
    const { code, msg, requestId, data } = resp.data;
    if (String(code) !== '0') {
      const err = { code, message: msg, requestId };
      if (data) {
        Object.assign(err, { data });
      }
      return { err, res: undefined as any };
    }
    return { res: { url: data.url } };
  } catch (error: any) {
    throw new TceSDKException(error.toString());
  }
}

/**
 * 获取上传服务的链接
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.11.0
 * @version TCE、TCS登录页 ❌
 * @version TCS控制台 >= 2.3.0
 * @param param 入参
 */
export function getUploadUrl(param: IGetFileUploadUrlParam): string {
  const { appId, module, fileName } = param || {};
  if (!appId || !module) {
    throw new TceSDKException('appId、module can not empty');
  }
  // 生成时间戳，后端校验5分钟有效
  const timestamp = new Date().getTime();
  // 随机数，一次性请求字段，后端会判断是否重复请求
  const nonce = uuid();
  const platform = getCurrentPlatformForFile();
  const generateSignStrParam = { appId, module, timestamp, nonce, platform };
  if (fileName) {
    Object.assign(generateSignStrParam, { fileName });
  }
  const signStr = generateSignStr(generateSignStrParam);
  const fileServerApiUrl = getFileServerUrl();
  return `${fileServerApiUrl}/public/api/upload?${signStr}`;
}
