export default function tsm_sm2(publicKey: string, plaintext: string) {
  // @ts-ignore
  const { SM2, utils } = window.SMLib;
  // sm2做非对称加密
  const sm2 = new SM2();

  const msgByteArray = utils.stringToByteArrayInUtf8(plaintext);
  const cipher = sm2.encrypt(publicKey, msgByteArray);
  return utils.byteArrayToBase64(utils.hexToByteArray(cipher));
}
