import { str2hex } from '../../common';

// 盐
const salt = 'TCESECURITY';

export default function kms_sm2(publicKey: string, plaintext: string) {
  // @ts-ignore
  const { SM2, utils, SM3 } = window.SMLib;
  // sm2做非对称加密
  const sm2 = new SM2();
  // sm3做完整性校验
  const sm3 = new SM3();

  // 利用明文+盐生成一个hash
  const hash = sm3.hashForUTF8String(plaintext + salt);

  // 组装新的需要加密的明文【明文16进制|hash拼装】
  const newPlaintext = `${str2hex(plaintext)}|${hash}`;

  const msgByteArray = utils.stringToByteArrayInUtf8(newPlaintext);
  const cipher = sm2.encrypt(publicKey, msgByteArray);
  return utils.byteArrayToBase64(utils.hexToByteArray(cipher));
}
