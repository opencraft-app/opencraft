/**
 * 获取字符串的字节数
 * @param Str 字符串
 */
function getBytesLength(str: string) {
  let count = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charAt(i);
    // 非ASCII场景下(256个)算3个字符【utf-8】
    if (!/^[\u0000-\u00ff]/.test(char)) {
      count += 3;
    } else {
      count += 1;
    }
  }
  return count;
}

function padStart(encryptText: string) {
  return btoa(atob(encryptText).padStart(256, '\0'));
}

export default function jsencrypt(publicKey: string, plaintext: string) {
  const jsEncrypt = new window.JSEncrypt({});
  jsEncrypt.setPublicKey(window.atob(publicKey));

  // 对plaintext分段处理，rsa2048对原文长度有限制，设置最大分段为240字节
  let MAX_ENCRYPT_BLOCK = 240;
  // 获取字节数
  const charLen = getBytesLength(plaintext);
  if (charLen <= MAX_ENCRYPT_BLOCK) {
    return padStart(jsEncrypt.encrypt(plaintext) as string);
  }
  // 判断plaintext中是否包含非ASCII的字符，如果包含的话就按80个字符作为拆分
  const isIncludeNonASCII = !/^[\u0000-\u00ff]+$/.test(plaintext);
  if (isIncludeNonASCII) {
    MAX_ENCRYPT_BLOCK = 80;
  }
  const encryptText: string[] = [];
  const len = plaintext.length;
  let offset = 0;
  while (offset < len) {
    // 暂时无法触发到false的场景
    const ciphertext = padStart(
      jsEncrypt.encrypt(plaintext.substr(offset, MAX_ENCRYPT_BLOCK)) /* istanbul ignore next */ || '',
    );
    encryptText.push(window.atob(ciphertext));
    offset += MAX_ENCRYPT_BLOCK;
  }

  return window.btoa(encryptText.join(''));
}
