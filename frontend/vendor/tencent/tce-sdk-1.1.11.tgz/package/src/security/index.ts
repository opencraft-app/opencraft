import { getGlobalConstants, getSource, isTcsTcloud, tcesdkAssets } from '../common';
import { JS_COOKIE } from '../constants';
import TceSDKException from '../common/tce_sdk_exception';
import { encryptFunctionByMethod, generateEncryptText, utils } from './helper';

/**
 * 加密明文
 * @param plaintext 明文
 * @param defaultText 默认值【环境没有配置加密方式的情况下默认返回的内容】
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE >= 3.10.0
 * @version TCS ❌
 */
export async function encrypt(plaintext: string, defaultText?: string): Promise<string | false> {
  // 如果入参为空，或者为空字符串的话，则直接返回原数据
  if (!plaintext || !plaintext.trim()) {
    return plaintext;
  }

  const { transportSecret, imgcacheHost } = getGlobalConstants() || {};

  if (!transportSecret) {
    return defaultText || plaintext;
  }

  if (!imgcacheHost) {
    throw new TceSDKException('imgcacheHost not exist');
  }

  const { method, public_key } = transportSecret;
  const encryptFunction = encryptFunctionByMethod[method];

  if (!method || !public_key || !encryptFunction) {
    return defaultText || plaintext;
  }

  if (!window[encryptFunction.libraryName]) {
    try {
      // 异步加载加密js
      await getSource(utils.getEncryptLibJsUrl(method));
    } catch (error) {
      /* istanbul ignore next */
      console.log(error);
      throw new TceSDKException(`load ${encryptFunction.libraryName} failed`);
    }
  }

  const ciphertext = encryptFunction.encryptFunction(public_key, String(plaintext));

  return generateEncryptText(ciphertext, method, 'V1');
}

/**
 * 获取防CSRF串
 * @method getCSRFToken
 * @return {String} 验证串
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.1.0
 */
export function getCSRFToken(): string {
  // 优先从cookie中获取csrfCode
  let csrfCodeKey = 'csrfCode';
  if (isTcsTcloud()) {
    // 对于TCS租户端 需要取和运营端不同的key
    csrfCodeKey = 't_csrfCode';
  }
  const csrfCodeForCookie = JS_COOKIE.get(csrfCodeKey);
  if (csrfCodeForCookie) return csrfCodeForCookie;
  const { csrfCode } = getGlobalConstants() || {};
  if (csrfCode) return csrfCode;
  const skey = utils.getSessionKey();
  if (!skey) return '';
  let hash = 5381;
  for (const str of skey) {
    hash += (hash << 5) + str.charCodeAt(0);
  }
  return String(hash & 0x7fffffff);
}

/**
 * 打开水印
 * @param content 水印内容
 * @returns
 */
export async function openWaterMask(content: string): Promise<void> {
  if (!content) return;
  if (!window.watermarkjs) {
    try {
      // 异步加载加密js
      await getSource(tcesdkAssets.getWaterMarkUrl());
    } catch (error) {
      /* istanbul ignore next */
      console.log(error);
      throw new TceSDKException(`load watermark js failed`);
    }
  }
  // 文档参考https://git.woa.com/fransli/watermarkjs/blob/master/doc/classes/main.default.md
  // eslint-disable-next-line no-new
  new window.watermarkjs(content, {
    enableObserver: true,
    IGraphOptions: {
      textMaxLength: 30,
      font: '400 20px Arial',
    },
  });
}
