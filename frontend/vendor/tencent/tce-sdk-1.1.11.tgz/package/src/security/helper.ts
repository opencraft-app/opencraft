import { isTceOcloud, isTcsOcloud, str2hex } from 'src/common';
import { assets } from 'src/common/util';
import { JS_COOKIE } from 'src/constants';
import kms_sm2 from './encryptMethod/kms-sm2';
import tsm_sm2 from './encryptMethod/tsm-sm2';
import jsencrypt from './encryptMethod/rsa-2048';

interface EncryptFunctionByMethod {
  [x: string]: {
    libraryName: string;
    assetUrl: () => string;
    encryptFunction: (publicKey: string, plaintext: string) => string;
  };
}

// 密文前缀
export const ciphertextPrefix = 'TCESECURITY';

/**
 * 组装密文信息
 * @param ciphertext 密文
 * @param method 加密方式
 * @param version 版本号
 */
export function generateEncryptText(ciphertext: string, method: string, version: string): string {
  const data = [ciphertextPrefix, method, version];
  return `T${data.map((d) => str2hex(d)).join(':')}:${ciphertext}`;
}

export const encryptFunctionByMethod: EncryptFunctionByMethod = {
  'rsa-2048': {
    libraryName: 'JSEncrypt',
    assetUrl: assets.getJsencryptUrl,
    encryptFunction: jsencrypt,
  },
  'kms-sm2': {
    libraryName: 'SMLib',
    assetUrl: assets.getSMUrl,
    encryptFunction: kms_sm2,
  },
  'tsm-sm2': {
    libraryName: 'SMLib',
    assetUrl: assets.getSMUrl,
    encryptFunction: tsm_sm2,
  },
};

export const utils = {
  /**
   * 获取 skey
   */
  getSessionKey() {
    let skey = isTceOcloud() ? JS_COOKIE.get('user_skey') : JS_COOKIE.get('skey');
    if (isTcsOcloud()) {
      // TCS场景下优先从window.TCS.skey 获取，没有的话再从JS_COOKIE.get('skey')中获取
      skey = window?.TCS?.skey || JS_COOKIE.get('skey');
    }
    return skey ? decodeURIComponent(skey) : null;
  },
  /**
   * 获取加密库js地址
   * @param encryptType 加密方式
   * @returns url
   */
  getEncryptLibJsUrl(encryptType: string) {
    return encryptFunctionByMethod[encryptType].assetUrl();
  },
};
