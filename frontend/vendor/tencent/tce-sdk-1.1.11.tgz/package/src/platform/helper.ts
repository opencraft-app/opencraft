import { isTceTcloud, isTcsOcloud } from 'src/common';
import { ICurrentAccess } from 'src/common/types';
import TceSDKException from 'src/common/tce_sdk_exception';
import { AXIOS } from 'src/constants';
import { getDomainList } from 'src/domain';
import { DescribeRegionZoneResProduct } from 'src/region';

/**
 * 通用前端组件
 */
export const PLATFORM_COMMON_COMPONENT = {
  /**
   * tce-js-sdk
   */
  TCESDK: 'tcesdk',
  /**
   * 前端通用js
   */
  CORE: 'core',
  /**
   * 平台js
   */
  PLATFORM: 'platform',
};

/**
 * 组件对应version地址
 */
export const componentVersionPathMap = () => ({
  [PLATFORM_COMMON_COMPONENT.TCESDK]: `/${isTcsOcloud() ? 'tcs-' : ''}common/tcesdk/`,
  [PLATFORM_COMMON_COMPONENT.CORE]: `/${isTcsOcloud() ? 'tcs-common/' : '/'}`,
  [PLATFORM_COMMON_COMPONENT.PLATFORM]: `/${isTcsOcloud() ? 'tcs-common' : '{platformType}'}/platform/`,
});

/**
 * 组件信息
 */
export interface IComponentInfo {
  /**
   * 组件名称
   */
  productName: string;
  /**
   * git分支名
   */
  branch: string;
  /**
   * git-commitId
   */
  commitId: string;
  /**
   * 构建时间
   */
  buildTime: string;
  /**
   * 部署时间
   */
  deployTime: string;
  /**
   * 页面接入信息[通用组件没有接入信息]
   */
  pageAccessInfo?: ICurrentAccess;
}

/**
 * 异步获取version信息
 * @export
 * @param {string} versionPath
 * @returns
 */
export async function fetchVersionJson(versionPath: string) {
  const versionUrl = `${versionPath}version.json?t=${new Date().getTime()}`;
  // 获取json数据超时时间不能太长，避免阻塞页面渲染
  const axiosInstance = AXIOS.create({
    timeout: 3000,
  });
  try {
    const resp = await axiosInstance.get(versionUrl);
    const { branch, buildTime, commitId, deployTime, productName } = resp.data;
    return { branch, commitId, buildTime, deployTime, productName };
  } catch (error) {
    console.warn(new TceSDKException('load component version failed'));
    return;
  }
}

/**
 * 获取overview的version——path
 */
export function getOverviewVersionPath() {
  const imgcacheUrl = `//${getDomainList().imgcache}`;
  if (isTcsOcloud()) {
    return `${imgcacheUrl}/tcs-ocloud/overview/`;
  }
  return `${imgcacheUrl}/${isTceTcloud() ? 'tcloud' : 'ocloud'}/overview/`;
}

/**
 * 获取通用组件的version——path
 */
export function getCommonVersionPath(path: string) {
  const imgcacheUrl = `//${getDomainList().imgcache}`;
  return `${imgcacheUrl}${componentVersionPathMap()[path].replace(
    '{platformType}',
    isTceTcloud() ? 'tcloud' : 'ocloud',
  )}`;
}

// 交付产品列表缓存
let deliverProductListCache = {} as unknown as { [key: string]: DescribeRegionZoneResProduct };

export function getDeliverProductListCache(region?: string) {
  return deliverProductListCache[region || 'global'];
}

export function setDeliverProductListCache(deliverProductList: DescribeRegionZoneResProduct, region?: string) {
  Object.assign(deliverProductListCache, { [region || 'global']: deliverProductList });
}

export function clearDeliverProductListCache() {
  deliverProductListCache = {};
}
