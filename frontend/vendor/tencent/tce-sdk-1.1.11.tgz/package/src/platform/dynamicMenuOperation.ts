/**
 * 根据platformCode, 得到对应的platform, modules, menus信息
 * @param platformCode
 */
import { IAPIResponse, resHandler, yApiRequest } from '../api';
import { uuid } from '../utils';

interface IModules {
  code: string;
  id: string;
  name: string;
  icon: string;
  // 对应的platform id
  platform: string;
  order: number;
  visible: boolean;
  isCustomized?: boolean;
  modified?: boolean;
  platformCode?: string;
}

export interface IMenu {
  id: string;
  // 对应的module id
  module: string;
  // 当前展示名称
  name: string;
  // icon
  icon?: string;
  // iconActive
  iconActive?: string;
  // 链接地址
  href: string;
  // 是否在顶部菜单展示
  headline: boolean;
  // 顺序
  order: number;
  // 子菜单
  menus?: IMenu[];
  /**
   * 打开形式
   * page 新页面打开
   * category 路由形式
   */
  openType?: 'page' | 'category';
  // 默认交付
  defaultDeliver?: boolean;
  // 是否为用户自定义
  isCustomized?: boolean;
  modified?: boolean;
  // 对应platformId
  platform: string;
  platformCode: 'tab_ocloud_manager' | 'tab_ocloud_pass' | 'tab_ocloud_application' | 'tab_ocloud_user';
}

interface AddMenuProps {
  // 菜单名
  menuName: string;
  // 是否在顶部展示
  headline?: boolean;
  // 菜单路径
  href: string;
  // 菜单所属平台code
  platformCode: string;
  // 所属产品Id
  moduleId: string;
}

interface RemoveMenuProps {
  // 删除的链接
  href: string;
  // 菜单所属平台code
  platformCode: string;
  // 所属产品Id
  moduleId: string;
}

/**
 * DrawSwitches接口入参定义
 */
export interface DrawSwitchesReq {
  /**
   * input
   */
  Params: DrawSwitchesParams[];
}
/**
 * DrawSwitchesParams
 */
export interface DrawSwitchesParams {
  /**
   * key命名
   */
  Key: string;
  /**
   * value
   */
  Value: string;
  /**
   * ns
   */
  Namespace: string;
  /**
   * 描述
   */
  Description?: string;
}

/**
 * 用来配置一系列开关的接口
 * @param req 入参包体
 */
/* istanbul ignore next */
async function drawSwitches(req: DrawSwitchesReq): Promise<IAPIResponse<any>> {
  const res = await yApiRequest<DrawSwitchesReq, any>({
    serviceType: 'foyo',
    action: 'DrawSwitches',
    data: req,
    version: '2021-04-28',
  });
  return resHandler<any>({ res, serviceType: 'foyo', action: 'DrawSwitches' });
}

/* istanbul ignore next */
const updateMenu = /* istanbul ignore next */ ({ Key, Value }: { Key: string; Value: any }) =>
  drawSwitches({
    Params: [
      {
        Key,
        Description: '',
        Namespace: 'tcs-menu-info',
        Value: JSON.stringify({ Model: Value }),
      },
    ],
  });

/* istanbul ignore next */
const loadAllMenus = (platformCode: string) => {
  const getMenus = (c) => window.TCS.config.entrys.filter((x) => x.code === c);

  const menus = getMenus(platformCode);

  /* istanbul ignore next */
  const getMenuInfo = ({ menu, id, module, index }) => ({
    id,
    name: menu.name,
    module,
    icon: menu.icon,
    iconActive: menu.iconActive,
    openType: 'page',
    order: index,
    href: menu.href,
  });

  /* istanbul ignore next */
  const convert = (
    da,
  ): {
    platforms: { Value: [] };
    modules: { Value: IModules[] };
    menus: { Value: IMenu[] };
  } =>
    da.reduce(
      (previousValue, currentValue, index) => {
        const platform = { code: currentValue.code, id: currentValue.id, name: currentValue.name, order: index };
        previousValue.platforms.Value.push(platform);
        currentValue.modules.forEach((m, moduleIndex) => {
          const module = {
            code: m.code,
            id: m.id,
            name: m.name,
            platform: currentValue.id,
            sourcePlatform: m.platform ?? 'ocloud',
            order: moduleIndex,
            icon: m.icon,
            iconActive: m.iconActive,
            visible: false,
            statics: m.statics,
            customNav: m.customNav,
          };
          previousValue.modules.Value.push(module);
          m.menus.forEach((me, menuIndex) => {
            const menu = {
              id: me.id,
              name: me.name,
              module: me.module,
              // eslint-disable-next-line max-nested-callbacks
              menus: me.menus?.map((m, subMenuIndex) =>
                getMenuInfo({
                  menu: m,
                  id: m.id,
                  module: m.module,
                  index: subMenuIndex,
                }),
              ),
              icon: me.icon,
              iconActive: me.iconActive,
              openType: me.menus ? 'category' : 'page',
              order: menuIndex,
              href: me.href,
            };
            previousValue.menus.Value.push(menu);
          });
        });
        return previousValue;
      },
      {
        platforms: {
          Key: 'tcs-menu-platforms',
          Value: [],
          Description: 'platforms',
          Namespace: 'tcs-menu-info',
          Ext: {
            ValueType: 'object',
          },
        },
        modules: {
          Key: 'tcs-menu-modules',
          Value: [],
          Description: 'modules',
          Namespace: 'tcs-menu-info',
          Ext: {
            ValueType: 'object',
          },
        },
        menus: {
          Key: platformCode,
          Value: [],
          Description: 'menus',
          Namespace: 'tcs-menu-info',
          Ext: {
            ValueType: 'object',
          },
        },
      },
    );

  return convert(menus);
};

/**
 * 菜单名
 * @param menuName
 * 是否在顶部展示
 * @param headline
 * 菜单路径
 * @param href
 * 菜单所属平台code
 * @param platformCode
 * 所属产品Id
 * @param moduleId
 */
export const addMenu = ({ menuName, headline = true, href, platformCode, moduleId }: AddMenuProps) => {
  if (!menuName || !href || !platformCode || !moduleId) {
    return 'missing parameter';
  }
  const { menus, modules } = loadAllMenus(platformCode);
  /* istanbul ignore next */
  const module = modules.Value.find((m) => m.id === moduleId);
  /* istanbul ignore else */
  if (!module) {
    return 'can not find menus by moduleId';
  }
  /* istanbul ignore next */
  const menu = {
    id: uuid(),
    module: module.id,
    name: menuName,
    order: 0,
    icon: '',
    iconActive: '',
    headline,
    href,
    openType: 'page',
    isCustomized: true,
    platform: module.platform,
    platformCode,
    modified: true,
  };
  /* istanbul ignore next */
  return updateMenu({
    Key: platformCode,
    Value: [...(menus?.Value ?? []), menu],
  });
};

/**
 * 删除的链接
 * @param href
 * 菜单所属平台code
 * @param platformCode
 * 所属产品Id
 * @param moduleId
 */

export const removeMenu = ({ href, platformCode, moduleId }: RemoveMenuProps) => {
  /* istanbul ignore else */
  if (!href || !platformCode || !moduleId) {
    return 'missing parameter';
  }
  /* istanbul ignore next */
  const { menus } = loadAllMenus(platformCode);
  /* istanbul ignore next */
  const updatedMenus = menus.Value.filter((m) => !(m.href === href && m.module === moduleId));
  /* istanbul ignore next */
  return updateMenu({
    Key: platformCode,
    Value: updatedMenus,
  });
};
