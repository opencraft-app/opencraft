import {
  getGlobalConstants,
  getCurrentLang,
  isTceOcloud,
  isTceTcloud,
  isTceTcloudBuy,
  getCurrentUserInfo,
  getCurrentPlatform,
  loc,
  isTcsOcloud,
  isTcsOcloudLogin,
} from '../common';
import { toLoginPageForExpired, showPreLoginModal } from '../common/modal';
import { getDomainList } from '../domain';
import { AXIOS } from '../constants';
import { getCSRFToken } from '../security';
import { getComponentCommitId, getCurrentPageAccessInfo, getCustomizeProductConfig } from 'src/common/customize';
import TceSDKException from 'src/common/tce_sdk_exception';
import {
  fetchVersionJson,
  getCommonVersionPath,
  getDeliverProductListCache,
  getOverviewVersionPath,
  IComponentInfo,
  PLATFORM_COMMON_COMPONENT,
  setDeliverProductListCache,
} from './helper';
import { IAPIRequest, yApiRequest } from 'src/api';
import { DescribeRegionZoneReq, DescribeRegionZoneRes } from 'src/region';

/**
 * 客制化logo信息
 */
interface CustomizeLogo {
  favicon: string;
  mainLogo: string;
}

export * from './dynamicMenuOperation';

/**
 * 平台类型
 */
export { PLATFORM_TYPE } from '../common';

/**
 * 获取当前平台类型
 */
export { getCurrentPlatform, getComponentCommitId };

/**
 * 获取客制化版本
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS ❌
 */
export function getCustomizeVersion() {
  return window.customizeVersion;
}

/**
 * 退出登录
 * @version TCE控制台、购买页 >= 3.10.0
 * @version TCE登录页 ❌
 * @version TCS ❌
 */
export function logout(): void {
  const { base, console } = getDomainList();
  const axiosInstance = AXIOS.create({
    timeout: 10000,
    withCredentials: true,
  });
  const csrfCode = getCSRFToken();
  // 租户端控制台或购买页【需要调用一个异步接口退出】
  if (isTceTcloud() || isTceTcloudBuy()) {
    const { userUin } = getCurrentUserInfo()!;
    axiosInstance
      .get(`//${console}/cgi/login?action=quitLogin&t=${Date.now()}&uin=${userUin}&csrfCode=${csrfCode}`)
      .then((resp) => {
        if (String(resp?.data?.code) === '0') {
          loc.locationReload();
        } else {
          throw new TceSDKException(resp?.data?.message || 'logout failed'); // 抛出错误让业务处理
        }
      })
      .catch(() => {
        throw new TceSDKException('logout failed');
      });
  } else {
    // 运营端，直接使用cas的退出接口
    axiosInstance
      .post(`//${console}/api/login/logout`, { csrfCode })
      .then((resp) => {
        if (String(resp?.data?.code) === '0') {
          const baseUrl = `//cas.${base}/cas/v3/logout`;
          const logoutUrl = `${baseUrl}?service=${encodeURIComponent(window.location.href)}`;
          loc.setLocationHref(logoutUrl);
        } else {
          throw new TceSDKException(resp?.data?.message || 'logout failed'); // 抛出错误让业务处理
        }
      })
      .catch(() => {
        throw new TceSDKException('logout failed');
      });
  }
}

/**
 * 获取平台logo信息【浏览器favicon及控制台主logo】
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.3.4.0.0
 */
export function getCustomizeLogo(): CustomizeLogo {
  const { imgcache, console: consoleHost } = getDomainList();
  const { isCustomizeNext } = window.g_config_data || {};
  // 判断是否启用了配置迁移，迁移的话logo走新的逻辑，没有的话继续走客制化逻辑
  const configMigration = getCustomizeProductConfig('tcenter', 'common', 'configMigration')?.[0] === '1';

  const useCustomizeConsole = configMigration || isCustomizeNext || isTcsOcloud() || isTcsOcloudLogin();
  const baseUrl = useCustomizeConsole ? `//${consoleHost}` : `//${imgcache}/customize/cache/img`;
  return {
    favicon: `${baseUrl}/favicon.ico`,
    mainLogo: `${baseUrl}${useCustomizeConsole ? '/logo.png' : '/ops-cmgt-nav-logo.svg'}`,
  };
}

/**
 * 获取平台Title信息
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.3.4.0.0
 */
export function getCustomizeTitle(): string {
  const currentLang = getCurrentLang();
  let configTitle = getGlobalConstants()?.title;

  if (isTceTcloud() || isTceOcloud()) {
    configTitle = window.I18N_CONFIG?.title;
  }

  if (configTitle && typeof configTitle === 'object') {
    return configTitle[currentLang] || configTitle[`title_${currentLang}`] || '';
  }

  return configTitle || '';
}

/**
 * 获取前端组件信息
 * @export
 * @param {string} [urlPath] 默认为当前页面
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.8.0
 * @version TCE登录页 ❌
 * @version TCS ❌
 */
export async function getFrontendComponentInfo(urlPath?: string): Promise<IComponentInfo | undefined> {
  let path = urlPath || loc.getLocationPath();

  // 购买页场景下默认url的话是cvm，所以需要将path改成/cvm
  if (path === '/' && isTceTcloudBuy()) {
    path = '/cvm';
  }

  // 如果path为空的情况下，那代表是首页，获取首页的组件信息
  if (path === '/') {
    const versionPath = getOverviewVersionPath();
    return fetchVersionJson(versionPath);
  }
  if (Object.values(PLATFORM_COMMON_COMPONENT).includes(path)) {
    const versionPath = getCommonVersionPath(path);
    return fetchVersionJson(versionPath);
  }

  // 获取接入信息
  const accessInfo = getCurrentPageAccessInfo(urlPath);
  if (!accessInfo) return;
  const {
    access: { asset },
  } = accessInfo;
  if (!asset) return;
  const { js } = asset;
  const versionPath = js.replace(/(.*)\/.*\.js.*/, `$1/`);
  const componentInfo = await fetchVersionJson(versionPath);
  if (!componentInfo) return;
  return {
    ...componentInfo,
    pageAccessInfo: accessInfo,
  };
}

/**
 * 获取全局变量
 * 默认先从TCE_GLOBAL_CONSTANT中获取，获取不到再从TCS下面获取，最后再从window下获取
 */
export function getGlobalVariable(key: string) {
  const { TCE_GLOBAL_CONSTANT, TCS } = window;
  return TCE_GLOBAL_CONSTANT?.[key] || TCS?.[key] || window[key];
}

interface IProductInfo {
  productCode: string;
}
export interface DeliverProductInfo {
  productCode: string;
  subProduct: IProductInfo[];
}

/**
 * 获取交付产品列表
 * @param region region名称【比如：chongqing】
 */
export async function getDeliverProductList(region?: string): Promise<DeliverProductInfo[]> {
  let cache = getDeliverProductListCache(region);
  // 判断缓存是否存在
  if (!cache) {
    const data = {
      ProductId: '',
    };

    if (region) {
      Object.assign(data, { Regions: [region] });
    }

    const reqData: IAPIRequest<DescribeRegionZoneReq> = {
      serviceType: 'location',
      action: 'DescribeRegionZone',
      version: '2019-11-28',
      region: '', // 获取地域接口不需要传入地域
      data,
    };
    const { res, err } = await yApiRequest<DescribeRegionZoneReq, DescribeRegionZoneRes>(reqData);
    if (err) {
      return [];
    }
    const { Products } = res;
    if (!Products) return [];
    setDeliverProductListCache(Products, region);
    cache = getDeliverProductListCache(region);
  }

  const productMap = new Map<string, Map<string, boolean>>();

  for (const level1 of Object.values(cache)) {
    if (!level1) {
      continue;
    }
    for (const level2 of Object.values(level1)) {
      if (!level2) {
        continue;
      }
      for (const [productCode, subProducts] of Object.entries(level2)) {
        if (!productMap.has(productCode)) {
          productMap.set(productCode, new Map());
        }
        const subProductMap = productMap.get(productCode)!;
        for (const subProductCode of subProducts) {
          subProductMap.set(subProductCode, true);
        }
      }
    }
  }

  const result: DeliverProductInfo[] = Array.from(productMap.entries()).map(([productCode, subProductMap]) => ({
    productCode,
    subProduct: Array.from(subProductMap.keys()).map((subProductCode) => ({ productCode: subProductCode })),
  }));
  return result;
}

export interface ICheckProductDeliverParam {
  /**
   * region名称【比如：chongqing】
   */
  region?: string;
  /**
   * 产品code
   */
  productCode: string;
  /**
   * 子产品code
   */
  subProductCode?: string;
}

/**
 * 检查产品是否已经交付
 * @param param ICheckProductDeliverParam
 */
export async function checkProductDeliver(param: ICheckProductDeliverParam): Promise<boolean> {
  const { region, productCode, subProductCode } = param;
  const productList: DeliverProductInfo[] = await getDeliverProductList(region);
  const filterProduct = productList.find((p) => p.productCode.toLowerCase() === productCode.toLowerCase());
  if (!filterProduct) return false;
  if (subProductCode) {
    return Boolean(filterProduct.subProduct.find((p) => p.productCode.toLowerCase() === subProductCode.toLowerCase()));
  }
  return true;
}

export { PLATFORM_COMMON_COMPONENT, IComponentInfo, toLoginPageForExpired, showPreLoginModal };

/**
 * 判断是否开启换肤功能
 */
export function isUseCustomizeTheme() {
  return !!window.TCE_GLOBAL_CONSTANT?.themeCode;
}

/**
 * 获取静态资源路径
 */
export function getCustomizeThemePath() {
  if (isUseCustomizeTheme()) {
    const { themeAssetsPath } = window.TCE_GLOBAL_CONSTANT;
    return themeAssetsPath || '/customize/cache/other/theme';
  }
  return '';
}
