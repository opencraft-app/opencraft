import { getCurrentLang } from '../language';
import {
  TransformFirstLetterToLowerCase,
  transformFirstLetterToLowerCase,
  TransformFirstLetterToUpperCase,
  transformFirstLetterToUpperCase,
  CommonErrorCode,
} from './helper';
import { cancelToken } from './yApiAxios';
import { yApiRequest, IResHandlerParam, IAPIResponse, IAPIRequest } from './yApiRequest';

/**
 * 对接口原始出参做二次处理默认方法，默认不处理，如有需要，建议自己在项目中增加这个方法单独处理，详细参考最佳实践：https://iwiki.woa.com/pages/viewpage.action?pageId=126762873
 * @param param 接口原始出参
 * @returns 改造后出参
 */
export function resHandler<T extends object>(param: IResHandlerParam<T>): IAPIResponse<T> {
  return apiResI18nHandler(param, {});
}

/**
 *
 * 云api接口出参错误码国际化处理函数
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.10.0
 * @version TCE、TCS登录页 ❌
 * @version TCS控制台 >= 2.1.0
 * @export
 * @template T 入参泛型
 * @param {IResHandlerParam<T>} param
 * @param {{
 *     [x: string]: string;
 *   }} errCode2Message 错误码对应的国际化文本信息，例如：{ 'InternalError.ErrNoValidLicense': t('没有有效的license，请上传license文件') }
 * @param isBack boolean 非必填，判断是否从后端获取错误信息作为非中文环境下的错误提示
 * @returns {IAPIResponse<T>}
 */
export function apiResI18nHandler<T extends object>(
  param: IResHandlerParam<T>,
  errCode2Message: {
    [x: string]: string;
  },
  isBack?: boolean,
): IAPIResponse<T> {
  const { res, err, rawResponse } = param.res;
  // 判断当前语言非中文的时候，直接返回后端接口错误信息【因为后端错误信息都是英文的】
  if (isBack && getCurrentLang() !== 'zh-CN') {
    return { res, err, rawResponse };
  }
  if (err) {
    const { code, message } = err;
    err.message = errCode2Message[code] || message;
  }
  return {
    res,
    err,
    rawResponse,
  };
}

/**
 * 获取cancelToken
 * @export
 * @returns
 */
export function getCancelToken() {
  return cancelToken;
}

export {
  transformFirstLetterToLowerCase,
  transformFirstLetterToUpperCase,
  yApiRequest,
  CommonErrorCode,
  TransformFirstLetterToLowerCase,
  TransformFirstLetterToUpperCase,
  IResHandlerParam,
  IAPIResponse,
  IAPIRequest,
};
