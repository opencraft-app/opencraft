import { AxiosRequestConfig } from 'axios';
import TceSDKException from 'src/common/tce_sdk_exception';
import { getComponent } from 'src/component';
import {
  getCurrentRegion,
  getGlobalConstantsAsync,
  getRegionListSync,
  isJiGuang,
  isTceTcloudBuy,
  loc,
} from '../common';
import { JIGUANG_LOGIN_EXPIRED_RELOAD_TIME_STORAGE } from '../common/constants';
import { LANG } from '../common/lang';
import { showPreLoginModal } from '../common/modal';
import { getCurrentLang } from '../language';
import { DescribeRegionZoneReq, DescribeRegionZoneRes, Region } from '../region';
import { getQueryParameters } from '../utils';
import {
  getMessageIP,
  getQueryString,
  getYapiUrl,
  jiguangCouldReloadPage,
  printYapiErrorLog,
  yapiIsCancel,
  yunapi3ResponseHandle,
} from './helper';
import { yApiAxios } from './yApiAxios';

export interface Error<T = object> {
  code: string;
  message: string;
  requestId: string;
  data?: T;
  [x: string]: any;
}

export interface IResHandlerParam<T extends object> {
  res: IAPIResponse<T>;
  serviceType: string;
  action: string;
}

export interface IAPIResponse<T extends object> {
  /**
   * 接口返回的业务数据
   */
  res: T;
  /**
   * 接口失败返回的错误对象，err不为null表示接口失败了
   */
  err?: Error;
  /**
   * 接口的原始出参，未经处理的数据
   */
  rawResponse?: any;
}

export interface IAPIRequest<T extends object = object> {
  /**
   * 接口分类【产品】
   */
  serviceType: string;
  /**
   * 接口名
   */
  action: string;
  /**
   * 当前地域，可以不填，默认为当前地域
   */
  region?: string;
  /**
   * 当前语言，可以不填，默认为当前语言
   */
  language?: string;
  /**
   * 接口需要的业务入参，不需要入参的时候不用
   */
  data?: T;
  /**
   * V3接口需要的版本
   */
  version: string;
  /**
   * url后的query
   */
  query?: { [key: string]: string };
}

export async function getAllRegionListAsync(): Promise<Region[]> {
  // 如果已经获取过一次，则优先同步获取
  const regionList = getGlobalConstantsAsync()?.regionList ?? [];
  if (regionList.length > 0) {
    return regionList;
  }

  const data = {
    ProductId: 'SPECIAL_LOGIC_ALL_REGION_ZONE', // 设置一个通用可以获取所有地域的产品code
  };

  const reqData: IAPIRequest<DescribeRegionZoneReq> = {
    serviceType: 'location',
    action: 'DescribeRegionZone',
    version: '2019-11-28',
    region: '', // 获取地域接口不需要传入地域
    data,
  };
  const { res, err } = await yApiRequest<DescribeRegionZoneReq, DescribeRegionZoneRes>(reqData);
  if (err) {
    return [];
  }
  const resRegionList = res.RegionSet.filter((item) => item.RegionState === 'AVAILABLE').map((item) => {
    const { Region, RegionID, RegionName, ZoneSet } = item;
    return {
      regionId: Number(RegionID),
      regionName: RegionName,
      region: Region,
      zoneList: ZoneSet.filter((item) => item.ZoneState === 'AVAILABLE').map((item) => {
        const { ZoneID, ZoneName, Zone } = item;
        return {
          zone: Zone,
          zoneId: Number(ZoneID),
          zoneName: ZoneName,
        };
      }),
    };
  });

  if (window.TCE_GLOBAL_CONSTANT_ASYNC) {
    window.TCE_GLOBAL_CONSTANT_ASYNC.regionList = resRegionList;
  } else {
    window.TCE_GLOBAL_CONSTANT_ASYNC = { regionList: resRegionList };
  }
  return resRegionList;
}

export async function getCurrentRegionAsync(): Promise<Region> {
  let regRegionId = '';
  const query = getQueryParameters();
  const { regionId, rid } = query;
  regRegionId = regionId || rid;
  // 如果已经获取过一次，则优先同步获取
  const regionList = await getAllRegionListAsync();
  const filterRegion = regionList.filter((regionInfo) => String(regionInfo.regionId) === String(regRegionId));
  if (filterRegion.length === 0) {
    // 没有的话取第一个
    return regionList[0];
  }
  return filterRegion[0];
}

/**
 * 请求云api接口 【只支持V3接口】
 * @template T 入参泛型
 * @template U 出参泛型
 * @param {IAPIRequest<T>} body 入参包体
 * @param {string} body.serviceType 接口分类【产品】
 * @param {string} body.action 接口名
 * @param {string} body.version 接口版本号
 * @param {string} body.region ?当前地域，可以不填，默认为当前地域
 * @param {string} body.language ?当前语言，可以不填，默认为当前语言
 * @param {T} body.data<T> ?接口需要的业务入参，不需要入参的时候不用
 * @param {Partial<AxiosRequestConfig>} options yapi可选配置
 * @returns {Promise<IAPIResponse<U>>} {Promise<{ res: U, err: { code, message } }>}
 */

/**
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.8.0
 * @version TCE、TCS登录页 ❌
 * @version TCS控制台 >= 2.1.0
 */
// eslint-disable-next-line complexity
export async function yApiRequest<T extends object = object, U extends object = object>(
  body: IAPIRequest<T>,
  options?: Partial<AxiosRequestConfig>,
): Promise<IAPIResponse<U>> {
  const { serviceType, action, data, version, region, language, query } = body;

  const result: IAPIResponse<U> = {
    res: undefined as any,
    err: undefined as any,
    rawResponse: undefined as any,
  };

  const defaultData = {
    Version: version,
    Language: language || getCurrentLang(),
  };

  const tempData = data ? { ...data, ...defaultData } : defaultData;

  let reqRegion = region;
  // 如果没有传入region则从getCurrentRegion获取
  if (reqRegion === undefined || String(reqRegion) === '1') {
    const currentRegion = isTceTcloudBuy() ? await getCurrentRegionAsync() : getCurrentRegion();
    reqRegion = currentRegion?.region;
  } else if (reqRegion && !isNaN(Number(reqRegion))) {
    // 兼容传入的region为数字的处理
    const regionList = isTceTcloudBuy() ? await getAllRegionListAsync() : getRegionListSync();
    const regionInfo = regionList.find((item) => String(item.regionId) === String(reqRegion));
    reqRegion = regionInfo?.region || region;
  }

  let url = getYapiUrl();
  if (!url) {
    throw new TceSDKException('yapi url is empty');
  }

  try {
    url += `?i=${serviceType}/${action}`;
    url += getQueryString(query);

    const reqData = {
      serviceType,
      action,
      region: reqRegion || '',
      data: tempData,
    };
    const resp: any = await yApiAxios.post(url, reqData, options);

    // 如果接口没有返回正常信息，就打印日志
    if (resp && (resp.code !== 0 || resp.data?.Response?.Error)) {
      printYapiErrorLog(url, reqData, resp, `${serviceType}/${action}`);
      const { code, codeDesc } = resp;
      // 加载审批sdk
      if (code === 5000 && codeDesc === 'NeedApproval') {
        const approval = await getComponent('approval-sdk');
        try {
          return (await approval.showApprovalModal(resp.data.Response?.Data?.ApprovalDocID, resp.data.Response)) as any;
        } catch (error) {
          return Object.assign(result, {
            err: {
              code: '5000',
              message: LANG.t('NeedApproval'),
              requestId: '',
            },
            rawResponse: resp,
          });
        }
      }
      // 敏感操作二次认证
      if (code === 1000 && codeDesc === 'LogicError.NeedActionVerify') {
        // 加载auth-sdk
        const auth = await getComponent('auth-sdk');
        try {
          // @ts-ignore
          return (await auth.showAuthModal({ reqData: body })) as any;
        } catch {
          return Object.assign(result, {
            err: {
              code: '1000',
              message: LANG.t('SecondaryCertification'),
              requestId: '',
            },
            rawResponse: resp,
          });
        }
      }
      // MFA二次认证
      if (code === 1020 && codeDesc === 'LogicError.NeedMFACodeVerify') {
        // 加载auth-sdk
        const auth = await getComponent('auth-sdk');
        try {
          // @ts-ignore
          return (await auth.showAuthModal({ reqData: body, type: 'mfa' })) as any;
        } catch {
          return Object.assign(result, {
            err: {
              code: '1000',
              message: LANG.t('SecondaryCertification'),
              requestId: '',
            },
            rawResponse: resp,
          });
        }
      }
      // 数字证书ukey认证【如果query中已经带上了ukey_sign，则不在继续弹窗】
      if (code === 1010 && !query?.ukey_sign) {
        // 加载auth-sdk
        const authIns = await getComponent('auth-sdk');
        return authIns.showAuthDigitalCertModal({ reqData: body, signStr: JSON.stringify(reqData) }) as any;
      }
      // 登录失效
      if (code === 201 || code === 401) {
        showPreLoginModal(LANG.t('loginExpireModal.title'), LANG.t('loginExpireModal.description'));
      }
      // 极光场景登录失效
      if (isJiGuang() && (code === 400001 || code === 4001)) {
        window.jiguangPlatformMessage?.(`登录状态过期,页面将自动刷新`, 'error');
        loc.locationReload();
      }
      // 非0code直接返回err
      if (code !== 0) {
        return Object.assign(result, {
          err: {
            code,
            message: resp.message,
            requestId: '',
          },
          rawResponse: resp,
        });
      }
    }
    Object.assign(result, { res: yunapi3ResponseHandle(resp), rawResponse: resp });
  } catch (error) {
    yapiIsCancel(error) && console.log('Request canceled');
    const { Code, Message, RequestId, restError, rawResponse, ...rest } = error as any; // 不直接获取rest，因为其他地方会有其他参数传进来，只处理yunapi3ResponseHandle中暴露的restError
    // IP限制
    if (Code === 'UnauthorizedOperation.InvalidAccessIP') {
      const ip = getMessageIP(Message);
      showPreLoginModal(LANG.t('ipLimitModal.title'), LANG.t('ipLimitModal.description').replace('{{ip}}', ip));
    }
    // 极光场景iOA返回登录态失效302重定向处理
    if (
      isJiGuang() &&
      rest.code === 'ERR_NETWORK' &&
      rest.response &&
      rest.response.readyState === 4 &&
      rest.response.status === 0 &&
      jiguangCouldReloadPage() // 一个小时内只会自动刷新页面一次
    ) {
      window.sessionStorage.setItem(JIGUANG_LOGIN_EXPIRED_RELOAD_TIME_STORAGE, `${Date.now()}`);
      window.jiguangPlatformMessage?.('登录过期,页面将自动刷新', 'error');
      loc.locationReload();
      Object.assign(result, {
        err: {
          code: 30002,
          message: '登录过期,页面将自动刷新',
          requestId: RequestId,
          ...restError,
        },
        rawResponse,
      });
    } else {
      Object.assign(result, {
        err: {
          code: Code,
          message: Message,
          requestId: RequestId,
          ...restError,
          ...rest,
        },
        rawResponse,
      });
    }
  }
  return result;
}
