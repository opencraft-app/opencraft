import Axios from 'axios';
import { getCSRFToken } from '../security';

export const cancelToken = Axios.CancelToken;

export const yApiAxios = Axios.create({
  timeout: 30000, // 和后端保持一致
  withCredentials: true,
});

// 添加请求拦截器
yApiAxios.interceptors.request.use(
  (config) => {
    // @ts-ignore
    Object.assign(config.headers, { 'X-CsrfCode': getCSRFToken() });
    return config;
  },
  (error) => {
    if (!error.response) {
      return Promise.reject({
        Code: error.code,
        Message: error.message,
      });
    }
    const { status, statusText } = error.response;
    if (status >= 400) {
      return Promise.reject({
        Code: status,
        Message: statusText,
      });
    }

    return Promise.reject(error);
  },
);

// 添加响应拦截器
yApiAxios.interceptors.response.use(
  (response) => response.data,
  (err) => Promise.reject(err),
);
