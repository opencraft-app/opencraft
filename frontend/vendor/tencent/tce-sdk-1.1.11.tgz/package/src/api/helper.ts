import { isJiGuang, isTceOcloud, isTceTcloud, isTceTcloudBuy, isTcsOcloud } from 'src/common';
import { getDomainList } from 'src/domain';
import { printKeywordLog } from 'src/utils';
import { JIGUANG_LOGIN_EXPIRED_RELOAD_TIME_STORAGE } from '../common/constants';

/** 将一个对象或数组里的对象的 key 的首字母转为转为小写的泛型 */
export type TransformFirstLetterToLowerCase<T> = T extends Array<infer V>
  ? V extends object
    ? TransformFirstLetterToLowerCase<V>[]
    : V[]
  : T extends object
  ? {
      [K in keyof T as Uncapitalize<K & string>]: TransformFirstLetterToLowerCase<T[K]>;
    }
  : T;

/** 将一个对象或数组里的对象的 key 的首字母转为转为大写的泛型 */
export type TransformFirstLetterToUpperCase<T> = T extends Array<infer V>
  ? V extends object
    ? TransformFirstLetterToUpperCase<V>[]
    : V[]
  : T extends object
  ? {
      [K in keyof T as Capitalize<K & string>]: TransformFirstLetterToUpperCase<T[K]>;
    }
  : T;

/**
 * 将对象 或数组里的对象的 key 的首字母转为小写，且不侵入原对象
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.10.0
 * @version TCE登录页 ❌
 * @version TCS ❌
 * @export
 * @template T 泛型
 * @param {T} objOrArr 对象或数组对象
 * @param {boolean} [notChangeAllUppercaseField=false] field都是大写的是否选择不转换，比如「CPU」
 * @returns {TransformFirstLetterToLowerCase<T>}
 */
export function transformFirstLetterToLowerCase<T = any>(
  objOrArr: T,
  notChangeAllUppercaseField = false,
): TransformFirstLetterToLowerCase<T> {
  const isObj = (obj: T) => Object.prototype.toString.call(obj) === '[object Object]';

  if (isObj(objOrArr)) {
    // @ts-ignore
    return Object.entries(objOrArr).reduce((prev, [key, value]) => {
      let newKey = key;
      if (!notChangeAllUppercaseField || !/^[A-Z]+$/g.test(key)) {
        newKey = key.charAt(0).toLowerCase() + key.slice(1);
      }
      // eslint-disable-next-line no-param-reassign
      prev[newKey] = transformFirstLetterToLowerCase(value);
      return prev;
    }, {} as unknown as TransformFirstLetterToLowerCase<T>);
  }
  if (Array.isArray(objOrArr)) {
    return objOrArr.map((el) => transformFirstLetterToLowerCase(el)) as TransformFirstLetterToLowerCase<T>;
  }
  return objOrArr as TransformFirstLetterToLowerCase<T>;
}

/**
 * 将对象 或数组里的对象的 key 的首字母转为大写，且不侵入原对象
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.10.0
 * @version TCE登录页 ❌
 * @version TCS ❌
 * @export
 * @template T
 * @param {T} objOrArr
 * @returns {TransformFirstLetterToUpperCase<T>}
 */
export function transformFirstLetterToUpperCase<T = any>(objOrArr: T): TransformFirstLetterToUpperCase<T> {
  const isObj = (obj: T) => Object.prototype.toString.call(obj) === '[object Object]';

  if (isObj(objOrArr)) {
    // @ts-ignore
    return Object.entries(objOrArr).reduce((prev, [key, value]) => {
      const newKey = key.charAt(0).toUpperCase() + key.slice(1);
      // eslint-disable-next-line no-param-reassign
      prev[newKey] = transformFirstLetterToUpperCase(value);
      return prev;
    }, {} as unknown as TransformFirstLetterToUpperCase<T>);
  }
  if (Array.isArray(objOrArr)) {
    return objOrArr.map((el) => transformFirstLetterToUpperCase(el)) as TransformFirstLetterToUpperCase<T>;
  }
  return objOrArr as TransformFirstLetterToUpperCase<T>;
}

/**
 * 截取message中的IP
 * @export
 * @param {string} message
 * @returns
 */
export function getMessageIP(message: string) {
  let ip = '';
  if (message) {
    const temp = message.split('`');
    if (temp.length > 2) {
      // eslint-disable-next-line prefer-destructuring
      ip = temp[1];
    }
  }
  return ip;
}

// 统一处理云api3出参
export function yunapi3ResponseHandle(response: any): any {
  if (!response.data || !response.data.Response) {
    throw { ...response, rawResponse: response };
  }

  const {
    code,
    data: {
      Response: { Error, RequestId },
    },
  } = response;

  if (code === 0 && !Error) {
    return response.data.Response;
  }
  const { Code, Message, ...restError } = Error;
  throw { Code, Message: code2Message(Code, Message), RequestId, restError, rawResponse: response };
}

export function printYapiErrorLog(url, req, res, interfaceName) {
  const logDetails = [
    {
      key: 'Cloud API endpoint',
      value: url,
    },
    {
      key: 'Input Parameters',
      value: req,
    },
    {
      key: 'Output Parameters',
      value: res,
    },
  ];
  printKeywordLog(`Interface error, API Identifier: ${interfaceName}`, logDetails);
}

// 获取不同平台请求云API的地址
export function getYapiUrl() {
  let url = '';
  const domains = getDomainList();
  const { base, console, yapiUrl } = domains;
  if (yapiUrl) {
    return yapiUrl;
  }

  if (isTceOcloud()) {
    url = `//oapi.${base}/capi/v3`;
  }

  if (isTceTcloudBuy() || isTceTcloud()) {
    url = `//tapi.${base}/capi/v3`;
  }

  if (isTcsOcloud()) {
    url = `//api.${console}/capi/v3`;
  }

  if (isJiGuang()) {
    url = `//${console}/api/`;
  }

  return url;
}

// 生成url后的query
export function getQueryString(query) {
  if (query && typeof query === 'object') {
    return `&${Object.entries(query)
      .map(([key, val]) => `${key}=${val}`)
      .join('&')}`;
  }
  return '';
}

export function yapiIsCancel(value) {
  return !!value?.__CANCEL__;
}

export const CommonErrorCode = {
  /**
   * CAM没有授权
   */
  UnauthorizedOperation: 'UnauthorizedOperation',
};

export const jiguangCouldReloadPage = () => {
  const preReloadTime = Number(window.sessionStorage.getItem(JIGUANG_LOGIN_EXPIRED_RELOAD_TIME_STORAGE));
  if (!isNaN(preReloadTime)) {
    const now = Date.now();
    if (now - preReloadTime < 60 * 60 * 1000) {
      return false;
    }
  }
  return true;
};

/**
 * 根据代码格式化消息。
 * @param code 字符串形式的代码。
 * @param message 要格式化的消息。
 * @returns 格式化后的消息。
 */
export const code2Message = (code: string, message: string): string => {
  if (typeof code !== 'string') {
    return message;
  }
  const isSpecialCode = code.includes('.') || code === 'UnauthorizedOperation';
  return isSpecialCode ? message : `[${code}]:${message}`;
};
