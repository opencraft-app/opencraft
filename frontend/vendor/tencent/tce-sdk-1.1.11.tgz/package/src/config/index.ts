import { getGlobalConstants } from '../common';
import { IAPIResponse, IAPIRequest, yApiRequest } from '../api';
import {
  getCustomizeProductConfig,
  getCustomizeProductConfigMultiple,
  getCustomizeAccessTabs,
  getCustomizeAccessInfoByRouterKey,
  getCurrentPageAccessInfo,
  getProductInfoByUUID,
  getMenuInfoByUUID,
  getCustomizeProductByCode,
  getCustomizeProductList,
  getCustomizeIconUrl,
  getAllMenus,
  getCustomizeProductLoginModalConfig,
} from '../common/customize';
import * as config from '../common/config';
import { currentLang, getConfig, getConfigList } from './helper';

export {
  getCustomizeProductConfig,
  getCustomizeProductConfigMultiple,
  getCustomizeAccessInfoByRouterKey,
  getCurrentPageAccessInfo,
  getCustomizeAccessTabs,
  getCustomizeProductList,
  getProductInfoByUUID,
  getCustomizeProductByCode,
  getMenuInfoByUUID,
  getCustomizeIconUrl,
  getAllMenus,
  getCustomizeProductLoginModalConfig,
};

export interface FoyoConfig {
  Description: string;
  Key: string;
  Namespace: string;
  Value: string;
}

/**
 * 传输加密信息
 */
export interface TransportSecret {
  /**
   * 加密方式
   */
  method: string;
  /**
   * 公钥
   */
  public_key: string;
}

export interface DescribeConfigReq {
  Params: {
    /**
     * 配置分类
     */
    Namespace: string;
    /**
     * 关键字
     */
    Key: string;
  };
  /**
   * 语言
   */
  Language: string;
}

export interface DescribeConfigUpDateReq {
  Params: [
    {
      /**
       * 配置分类
       */
      Namespace: string;
      /**
       * 关键字
       */
      Key: string;
      /**
       * 关键字
       */
      Value: boolean | string | number | object | any[];
    },
  ];
  /**
   * 语言
   */
  Language: string;
}

type FoyoConfigValue = boolean | string | object | number | undefined;

interface GetConfigRes {
  /**
   * 值
   */
  Value: FoyoConfigValue | FoyoConfigValue[];
}

export interface DescribeConfigRes {
  Data: DescribeConfigItem;
}

export interface DescribeConfigListRes {
  Data: {
    PageNum: number;
    PageSize: number;
    Count: number;
    Data: DescribeConfigItem[];
  };
}

interface DescribeConfigItem {
  /**
   * ID
   */
  EntryID: number;
  /**
   * 关键字
   */
  Key: string;
  /**
   * 配置分类
   */
  Namespace: string;
  /**
   * 描述
   */
  Description: string;
  /**
   * 当前版本号
   */
  Version: number;
  /**
   * 配置时间
   */
  ModifyTime: number;
  /**
   * 来源，暂定sdk和cli
   */
  Source: string;
  /**
   * 扩展字段json
   */
  Ext: string | DescribeExt;
  /**
   * 值
   */
  Value: boolean | string | object | number | any[];
}
interface DescribeExt {
  /**
   * 当前版本号
   */
  Version: string;
  /**
   * 值类型 num bool str array obj
   */
  ValueType: 'bool' | 'str' | 'obj' | 'num' | 'array';
}

// foyo配置常量
export const FOYO_CONFIG = {
  tcenter_base: {
    name: 'tcenter_base',
    /**
     * 租户端是否展示右上角费用菜单
     */
    tcloud_show_fee_menu: 'tcloud_show_fee_menu',
    /**
     * 租户端是否打开注册功能
     */
    tcloud_allow_reg: 'tcloud_allow_reg',
    /**
     * 租户端主子账号登录是否启用图形验证码
     */
    tcloud_login_show_captcha: 'tcloud_login_show_captcha',
    /**
     * 运营端主子账号登录是否启用图形验证码
     */
    ocloud_login_show_captcha: 'ocloud_login_show_captcha',
    /**
     * 租户端所有页面统计系统的api地址
     */
    tcloud_statistics_api: 'tcloud_statistics_api',
    /**
     * 租户端会话超时时间【分钟】
     */
    tcloud_session_timeout: 'tcloud_session_timeout',
    /**
     * 租户端购买页所属项目是否必填配置
     */
    tcloud_view_project_required: 'tcloud_view_project_required',
    /**
     * 异地登录保护开关：开启后，租户端的账号发生异地登录时，平台会对用户做身份校验
     */
    tcloud_remote_login_protection: 'tcloud_remote_login_protection',
    /**
     * 金融专区白名单
     */
    fzo_whiltelist: 'fzo_whiltelist',
    /**
     * 价格展示配置
     */
    price_display_content: 'price_display_content',
  },

  tcenter_login_description: {
    name: 'tcenter_login_description',
    /**
     * 租户端登录页面左侧信息
     */
    tcloud_login_show_description: 'tcloud_login_show_description',
  },

  tcenter_privacy_agreement: {
    name: 'tcenter_privacy_agreement',
    /**
     * 租户端隐私协议
     */
    tcloud_privacy: 'tcloud_privacy',
  },

  tcenter_system_maintenance: {
    name: 'tcenter_system_maintenance',
    /**
     * 租户端系统维护页面
     */
    tcloud_system_maintenance_info: 'tcloud_system_maintenance_info',
  },

  tcenter_password_control: {
    name: 'tcenter_password_control',
    /**
     * 是否打开租户端密码控件
     */
    enable: 'enable',
    /**
     * 密码控件window下license
     */
    license_window: 'license_window',
    /**
     * 密码控件mac下license
     */
    license_mac: 'license_mac',
    /**
     * 密码控件urlPar
     */
    urlPar: 'urlPar',
  },

  tcenter_security: {
    name: 'tcenter_security',
    /**
     * 是否打开数字证书
     */
    digital_certificate: 'digital_certificate',
  },
};

// 弹性变量key常量
export const ELASTIC_CONFIG_KEY = {
  common: {
    tce_log_server: 'tce_log_server', // 日志收集服务
  },
  tcloud: {
    billing_backend_type: 'billing_backend_type', // 组件使用的是计量还是计费, 默认值为bmp: 表示计量, bmppro: 表示计费
    cos_allow_use_sm4: 'cos_allow_use_sm4', // 是否允许使用国密SM4算法进行加密存储
    vpc_multicast: 'vpc_multicast', // 是否打开私有网络组播功能
  },
  ocloud: {
    cvm_configurable: 'cvm_configurable', // cvm 配置调整操作开关
    no_vpc_options: 'no_vpc_options', // 是否没有vpc网络
  },
};

/**
 * 获取弹性变量配置
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、登录页 >= 3.10.0
 * @version TCE购买页 ❌
 * @version TCS ❌
 * @param key 配置key
 * @return string
 */
export function getElasticConfig<T>(key: string): T {
  return getGlobalConstants()?.elasticConfig?.[key];
}

/**
 * 获取客制化全局变量配置
 * @param key 配置key
 * @return string
 */
export function getCustomizeGlobalConfig(key: string): string {
  return getGlobalConstants()?.customizeGlobalConfig?.[key] ?? '';
}

/**
 * 异步获取配置中心配置
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE >= 3.10.0
 * @version TCS ❌
 * @param Namespace 配置分类
 * @param Key 关键字
 * @return  boolean | string | object | number | undefined
 */
export async function getConfigAsync(Namespace: string, Key: string): Promise<IAPIResponse<GetConfigRes>> {
  const { res, err } = await getConfig(Namespace, Key);
  return { res: { Value: res?.Data?.Value }, err };
}

/**
 * 异步获取指定ns下的配置中心配置
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE >= 3.10.12
 * @version TCS ❌
 * @param Namespace 配置分类
 * @return  DescribeConfigItem[]
 */
export async function getConfigAsyncByNs(Namespace: string): Promise<IAPIResponse<DescribeConfigItem[]>> {
  const { res, err } = await getConfigList(Namespace);
  return { res: res?.Data?.Data || [], err };
}

interface GetConfigListAsyncFilter {
  /**
   * 配置分类
   */
  namespace: string;
  /**
   * 配置key
   */
  key: string;
}

interface ConfigItem extends GetConfigListAsyncFilter {
  value: FoyoConfigValue | FoyoConfigValue[];
}

/**
 * 异步获取配置中心配置
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE >= 3.10.0
 * @version TCS ❌
 * @return  FoyoConfigValue | FoyoConfigValue[]
 */
export async function getConfigAsyncMultiple(filters: GetConfigListAsyncFilter[]): Promise<ConfigItem[]> {
  // Namespace去重
  const ns: string[] = filters.reduce(
    (prev: string[], { namespace }) => (prev.includes(namespace) ? prev : [...prev, namespace]),
    [],
  );

  // 聚合多次请求接口的返回值
  const res = (await Promise.all(ns.map((namespace) => getConfigList(namespace)))).flatMap(({ res, err }) => {
    if (err) return [];
    return res?.Data?.Data || [];
  });

  return filters.map(
    // ns和key两个才能决定一个配置项，否则key可能不同ns会重复
    (item) => {
      const { key, namespace } = item;
      return {
        ...item,
        value: res.find(({ Key, Namespace }) => Key === key && Namespace === namespace)?.Value,
      };
    },
  );
}

/**
 * 设置配置中心配置值
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE >= 3.10.0
 * @version TCS ❌
 * @param Namespace 配置分类
 * @param Key 关键字
 * @param Value 值
 */
export async function setConfig<T extends object | number | string | boolean | any[]>(
  Namespace: string,
  Key: string,
  Value: T,
): Promise<IAPIResponse<{}>> {
  const reqData: IAPIRequest<DescribeConfigUpDateReq> = {
    serviceType: 'foyo',
    action: 'DrawSwitches',
    version: '2021-04-28',
    data: {
      Params: [
        {
          Namespace,
          Key,
          Value: JSON.stringify({ Model: Value }),
        },
      ],
      Language: currentLang,
    },
  };
  return await yApiRequest<DescribeConfigUpDateReq, {}>(reqData);
}

export const { getConfigSync } = config;
