import { IAPIResponse, IAPIRequest, yApiRequest } from 'src/api';
import { getCurrentLang } from 'src/common';
import { DescribeConfigRes, DescribeConfigReq, DescribeConfigListRes } from '.';

export const currentLang = getCurrentLang();

/**
 * 异步获取配置中心配置
 * @param Namespace 配置分类
 * @param Key 关键字
 */
export async function getConfig(Namespace: string, Key: string): Promise<IAPIResponse<DescribeConfigRes>> {
  const reqData: IAPIRequest<DescribeConfigReq> = {
    serviceType: 'foyo',
    action: 'QuerySwitch',
    version: '2021-04-28',
    data: {
      Params: {
        Namespace,
        Key,
      },
      Language: currentLang,
    },
  };

  return yApiRequest<DescribeConfigReq, DescribeConfigRes>(reqData);
}

/**
 * 异步获取配置中心配置
 * @param Namespace 配置分类
 * @param Key 关键字
 */
export async function getConfigList(Namespace: string): Promise<IAPIResponse<DescribeConfigListRes>> {
  const reqData = {
    serviceType: 'foyo',
    action: 'QuerySwitchList',
    version: '2021-04-28',
    data: {
      PageNum: 1,
      PageSize: 1000,
      Params: {
        Namespace,
      },
      Language: currentLang,
    },
  };

  return yApiRequest(reqData);
}
