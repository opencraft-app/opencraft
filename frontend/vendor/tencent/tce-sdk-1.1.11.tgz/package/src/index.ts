import * as constants from './constants';
import * as api from './api';
import * as domain from './domain';
import * as utils from './utils';
import * as language from './language';
import * as security from './security';
import * as config from './config';
import * as region from './region';
import * as user from './user';
import * as platform from './platform';
import * as cam from './cam';
import * as auth from './auth';
import * as component from './component';
import * as file from './file';
import * as sidebar from './sidebar';
import * as router from './router';
import * as tips from './tips';
import * as common from './common';
const VERSION = '{{VERSION}}';

window.__sdkRouterByTce = common.getSdkRouterMap();

export {
  VERSION,
  constants,
  api,
  domain,
  utils,
  language,
  security,
  config,
  region,
  user,
  platform,
  cam,
  auth,
  component,
  file,
  sidebar,
  router,
  tips,
};
