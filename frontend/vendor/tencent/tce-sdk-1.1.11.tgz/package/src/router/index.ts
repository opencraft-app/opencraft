interface IRouterProps {
  navigate: (path: string) => void;
}

/**
 * 路由跳转
 * @param path 跳转路径
 */
export function navigate(path: string) {
  /* istanbul ignore next */
  window.seajs.require<IRouterProps>('router').navigate(path);
}
