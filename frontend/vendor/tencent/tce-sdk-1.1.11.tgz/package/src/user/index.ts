import * as common from '../common';
import { IAPIRequest, yApiRequest } from '../api';
import { maskPhoneNumber, maskMail, uuid } from '../utils';
import {
  UserInfo,
  IGetUserInfoByLoginUinRes,
  ListSelfAttachedUserAllPoliciesReq,
  ListSelfAttachedUserAllPoliciesRes,
  BaseUserInfo,
  IWhiteListResult,
  IWhiteListResp,
  IWhiteListValueType,
} from './types';
import { AXIOS } from '../constants';
import { getCSRFToken } from '../security';
import { getDomainList } from '../domain';
import { isTceTcloud, isTceTcloudBuy } from '../common';

/**
 * 获取当期登录用户信息
 */
export const { getCurrentUserInfo } = common;

/**
 * 异步获取当前用户信息
 * @version TCE控制台、购买页 >= 3.10.0
 * @version TCE登录页 ❌
 * @version TCS ❌
 * @return Promise<UserInfo | undefined>
 */
export async function getCurrentUserInfoAsync(): Promise<UserInfo | undefined> {
  let resp;
  const reqData: IAPIRequest = {
    serviceType: 'account',
    action: 'GetMaskedUserInfoByLoginUin',
    version: '2019-03-25',
  };
  if (window?.isUseGetMaskedUserInfoByLoginUin) {
    resp = await yApiRequest<any, IGetUserInfoByLoginUinRes>(reqData);
    if (resp.err) {
      resp = await yApiRequest<any, IGetUserInfoByLoginUinRes>({ ...reqData, action: 'GetUserInfoByLoginUin' });
    }
  } else {
    resp = await await yApiRequest<any, IGetUserInfoByLoginUinRes>({ ...reqData, action: 'GetUserInfoByLoginUin' });
  }

  const { err, res } = resp;
  if (err || !res) {
    return;
  }
  const { Owneruin, Uin, Name, Collname, Colltel, Collmail, CountryCode, Tel, Mail, Nickname } = res;
  const isOwner = String(Owneruin) === String(Uin);
  return {
    isOwner,
    ownerUin: String(Owneruin),
    ownerUserName: Name,
    userUin: Uin,
    userName: isOwner ? Name : Collname,
    countryCode: CountryCode,
    tel: maskPhoneNumber(isOwner ? Tel : Colltel),
    mail: maskMail(isOwner ? Mail : Collmail),
    nickName: Nickname,
    // 这种场景下getCurrentUserInfo不可能为undefined
    appId: getCurrentUserInfo()!.appId,
  };
}

/**
 * 获取当前用户已关联的策略列表
 * @export
 * @version TCE运营端控制台 >= 3.10.0
 * @version TCE租户端控制台、购买页 ❌
 * @version TCE登录页 ❌
 * @version TCS ❌
 * @returns {string[]} 返回策略列表名称
 */
export async function getCurrentUserRelatedPolicies(): Promise<string[]> {
  // 获取用户信息云API接口入参
  const reqData: IAPIRequest<ListSelfAttachedUserAllPoliciesReq> = {
    serviceType: 'account',
    action: 'ListSelfAttachedUserAllPolicies',
    version: '2022-01-21',
    data: {
      AttachType: 0,
      Page: 1,
      Rp: 200,
    },
  };
  const { res, err } = await yApiRequest<ListSelfAttachedUserAllPoliciesReq, ListSelfAttachedUserAllPoliciesRes>(
    reqData,
  );
  if (err || !res) {
    return [];
  }
  return res.PolicyList.map(({ PolicyName }) => PolicyName);
}

/**
 * 判断当前用户是否为超级管理员【也就是是否关联的（AdministratorAccess）策略】
 * @export
 * @version TCE运营端控制台 >= 3.10.0
 * @version TCE租户端控制台、购买页 ❌
 * @version TCE登录页 ❌
 * @version TCS ❌
 * @returns {boolean}
 */
export async function checkCurrentUserIsAdmin(): Promise<boolean> {
  const polices = await getCurrentUserRelatedPolicies();
  return polices.includes('AdministratorAccess');
}

/**
 * 获取当前用户关联的白名单列表
 * @version TCE租户端控制台、购买页 >= 3.11.0
 * @version TCE运营端控制台 ❌
 * @version TCE登录页 ❌
 * @version TCS ❌
 * @param whitelistKeys 白名单key
 * @param valueType 白名单值类型，默认为ownerUin【'appid' | 'uin' | 'owneruin'】
 * @returns IWhiteListResult
 */
export async function hasWhiteListForMultiKey(
  whitelistKeys: string[],
  valueType?: IWhiteListValueType,
): Promise<IWhiteListResult> {
  const domain = getDomainList();
  const axiosInstance = AXIOS.create({
    timeout: 10000,
    withCredentials: true,
  });
  const csrfCode = getCSRFToken();
  const result = {};

  // 租户端控制台或购买页才有这个能力
  if (isTceTcloud() || isTceTcloudBuy()) {
    try {
      const resp = await axiosInstance.post<IWhiteListResp>(
        `//${domain.console}/cgi/whitelist`,
        { type: valueType, whitelistKeys },
        { headers: { 'x-csrfcode': csrfCode, 'x-seqid': uuid() } },
      );
      const { code, data } = resp.data;
      if (String(code) === '0') {
        whitelistKeys.forEach((key) => {
          const value = data[key];
          result[key] = {
            result: value?.length > 0,
            oriData: value || [],
          };
        });
      }
    } catch (error) {
      /* istanbul ignore next */
      console.log(error);
    }
  }
  return result;
}

/**
 * 获取当前用户是否关联白名单
 * @version TCE租户端控制台、购买页 >= 3.11.0
 * @version TCE运营端控制台 ❌
 * @version TCE登录页 ❌
 * @version TCS ❌
 * @param whitelistKey 白名单key
 * @param valueType 白名单值类型，默认为ownerUin【'appid' | 'uin' | 'owneruin'】
 * @returns boolean
 */
export async function hasWhiteList(whitelistKey: string, valueType?: IWhiteListValueType): Promise<boolean> {
  const whitelist = await hasWhiteListForMultiKey([whitelistKey], valueType);
  return whitelist[whitelistKey]?.result ?? false;
}

export { BaseUserInfo, UserInfo };
