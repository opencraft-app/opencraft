import Cookies from 'js-cookie';
import Axios from 'axios';

declare namespace Cookies {
  interface CookieAttributes {
    expires?: number | Date | undefined;
    path?: string | undefined;
    domain?: string | undefined;
    secure?: boolean | undefined;
    sameSite?: 'strict' | 'Strict' | 'lax' | 'Lax' | 'none' | 'None' | undefined;
    [property: string]: any;
  }
  interface CookiesStatic<T extends object = object> {
    defaults: CookieAttributes;
    set(name: string, value: string | T, options?: CookieAttributes): string | undefined;
    get(name: string): string | undefined;
    get(): { [key: string]: string };
    getJSON(name: string): any;
    getJSON(): { [key: string]: any };
    remove(name: string, options?: CookieAttributes): void;
    noConflict?(): CookiesStatic<T>;
    withConverter<TConv extends object>(
      converter:
        | CookieReadConverter
        | { write?: CookieWriteConverter<TConv> | undefined; read?: CookieReadConverter | undefined },
    ): CookiesStatic<TConv>;
  }
  type CookieWriteConverter<T extends object> = (value: string | T, name: string) => string;
  type CookieReadConverter = (value: string, name: string) => string;
}

/**
 * 将js-cookie导出
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.1.0
 */
export const JS_COOKIE = Cookies as Cookies.CookiesStatic;

/**
 * 将axios导出
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.1.0
 */
export const AXIOS = Axios;
