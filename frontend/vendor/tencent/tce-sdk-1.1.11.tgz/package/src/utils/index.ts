import _storage from '@tencent/storage';
import TceSDKException from 'src/common/tce_sdk_exception';
import { assets, getSource, str2hex } from 'src/common/util';
import type * as XLSX from 'xlsx';

export declare interface StorageObject {
  local: Storage; // localStorage
  session: Storage; // sessionStorage
}

export interface LogInfo {
  /**
   * 标题
   */
  key: string;
  /**
   * 内容
   */
  value: any;
}

/**
 * 将字符传参数转变为对象，默认不传，不传将从document.location.search 获取
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.1.0
 * @param str 入参
 */
export function getQueryParameters(str?: string): { [x: string]: string } {
  return (str || document.location.search)
    .replace(/(^\?)/, '')
    .split('&')
    .reduce((accumulator: object, currentValue: string) => {
      const [key, value] = currentValue.split('=').map((value) => decodeURIComponent(value.trim()));
      if (!key) {
        return accumulator;
      }
      return {
        ...accumulator,
        [key]: value,
      };
    }, {});
}

/**
 * 将数据组装成csv文件下载
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.1.0
 * @param rows csv每行的数据，字符串二维数组
 * @param header csv文件的头，字符串数组
 * @param filename csv下载后的文件名，例如test.csv
 */
export function downloadCsv(rows: string[][], header: string[], filename: string) {
  const processRow = function (row) {
    let finalVal = '';
    for (let j = 0; j < row.length; j++) {
      let innerValue = typeof row[j] === 'undefined' || row[j] === null ? '' : row[j].toString();
      if (row[j] instanceof Date) {
        innerValue = row[j].toLocaleString();
      }
      let result = innerValue.replace(/"/g, '""');
      if (result.search(/("|,|\n)/g) >= 0) {
        result = `"${result}"`;
      }
      if (j > 0) {
        finalVal += ',';
      }
      finalVal += result;
    }
    return `${finalVal}\n`;
  };

  let csvFile = '';
  const csvArray = [`${header.join(',')}\n`];
  for (const dataInRow of rows) {
    csvArray.push(processRow(dataInRow));
  }

  csvFile += csvArray.join('');
  // 处理中文乱码
  if (csvFile.charAt(0) !== '\uFEFF') {
    csvFile = `\uFEFF${csvFile}`;
  }

  const blob = new Blob([csvFile], {
    type: 'text/csv;charset=utf-8;',
  });
  // @ts-ignore
  if (navigator.msSaveBlob) {
    // @ts-ignore
    navigator.msSaveBlob(blob, filename);
  } else {
    const link = document.createElement('a') as any;
    // if (!link.download) {
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    //  }
  }
}

/**
 * 获取xlsx库
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE >= 3.11.0
 * @version TCS >= 2.3.0
 */
export async function getXlsx(): Promise<typeof XLSX> {
  const xlsxURL = assets.getXlsxUrl();
  if (!window.XLSX) {
    try {
      await getSource(xlsxURL);
    } catch (error) {
      /* istanbul ignore next */
      console.log(error);
      throw new TceSDKException(`load xlsx.full.min.js failed`);
    }
  }
  return window.XLSX;
}

/**
 * 将数据组装成xlsx文件下载
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE >= 3.11.0
 * @version TCS >= 2.3.0
 * @param rows xlsx每行的数据，字符串二维数组
 * @param header xlsx文件的头，字符串数组
 * @param filename xlsx下载后的文件名，例如test.xlsx
 */
export async function downloadXlsx(rows: string[][], header: string[], filename: string) {
  const xlsx = await getXlsx();
  const book = xlsx.utils.book_new();
  const sheet = xlsx.utils.aoa_to_sheet([header, ...rows]);
  xlsx.utils.book_append_sheet(book, sheet);
  xlsx.writeFile(book, filename);
}

/**
 * 解析xlsx文件
 * @param file xlsx文件
 * @returns Promise<{ headers: string[]; rows: any[][] }>
 */
export async function parseXlsxFile(file: File): Promise<{ headers: string[]; rows: any[][] }> {
  const xlsx = await getXlsx();
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      /* istanbul ignore next */
      const data = e.target?.result;
      const workbook = xlsx.read(data, { type: 'binary' });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const jsonData = xlsx.utils.sheet_to_json(worksheet);
      if (jsonData.length === 0) {
        return reject('Sheet is empty');
      }
      const headers = Object.keys(jsonData[0] as string[]);
      /* istanbul ignore next */
      const rows = jsonData.map((row: any) => headers.map((header) => row[header] || ''));
      resolve({ headers, rows });
    };
    /* istanbul ignore next */
    reader.onerror = () => {
      reject('Failed to read file');
    };
    reader.readAsBinaryString(file);
  });
}

/**
 * 返回storage函数
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.1.0
 * @param namespace 命名空间，默认为tce
 */
export function storage(namespace = 'tce'): StorageObject {
  return _storage(namespace);
}

/**
 * 关键信息打印
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.1.0
 * @param title 标题
 * @param details 详细信息
 */
export function log(title: string, details?: LogInfo[]) {
  if (console.group) {
    console.group(`%c${title}`, 'color: red;font-size: 16px;');
  } else {
    console.log(`${title} [Log Start]`);
  }
  if (!(details instanceof Array)) {
    console.log(`Log Details: ${details}`);
  } else {
    details.forEach((detail) => {
      const key = detail.key || '';
      const value = detail.value || detail;
      console.log(`${key}:`, value);
    });
  }
  console.log('Current Page Menu:', window.sessionStorage.getItem('tce_current_actived_menu_name'));
  console.log('Current Page URL:', window.location.href);
  console.log('Current Time:', new Date());
  if (console.groupEnd) {
    console.groupEnd();
  } else {
    console.log(`${title} [Log End]`);
  }
}

/**
 * @deprecated 请使用log方法
 */
export const printKeywordLog = log;

/**
 * 手机号脱敏
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.1.0
 * @param phoneNumber 手机号码
 */
export function maskPhoneNumber(phoneNumber: string) {
  let phone = phoneNumber;
  if (!phoneNumber) return phoneNumber;
  if (/^\d{5,}$/.test(phoneNumber)) {
    const left = phoneNumber.slice(0, 2);
    let middle = phoneNumber.slice(2, -2);
    const right = phoneNumber.slice(-2);
    if (middle.length <= 4) {
      middle = '****'.slice(0, middle.length);
    } else {
      middle = `${middle.slice(0, Math.floor(middle.length / 2) - 2)}****${middle.slice(
        Math.floor(middle.length / 2) + 2,
      )}`;
    }
    phone = left + middle + right;
  }
  return phone;
}

/**
 * 邮箱脱敏
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.1.0
 * @param mail 邮箱
 */
export function maskMail(mail: string) {
  if (!mail) return mail;
  // 已经处理过了不再处理
  if (mail.indexOf('*') !== -1) {
    return mail;
  }
  const mailPair = mail.split('@');
  if (mailPair.length !== 2) {
    return mail;
  }
  let mailId = mailPair[0];
  const mailDomain = mailPair[1];
  if (mailId.length > 4) {
    mailId = `${mailId.slice(0, -4)}****`;
  } else {
    mailId = `${mailId.slice(0, 1)}****`;
  }
  return `${mailId}@${mailDomain}`;
}

/**
 * 生成一个uuid
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.1.0
 */
export function uuid(): string {
  function s4() {
    return Math.floor((1 + Math.random()) * 0x10000)
      .toString(16)
      .substring(1);
  }
  return `${s4() + s4()}-${s4()}-${s4()}-${s4()}-${s4()}${s4()}${s4()}`;
}

/**
 * 获取dom元素的宽高
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.10.0
 * @version TCE登录页 ❌
 * @version TCS ❌
 * @export
 * @param {string} [selector='#appArea'] 默认为控制台页面右侧内容区的宽高
 * @returns {{ clientHeight: number; clientWidth: number }}
 */
export function getElementRect(selector = '#appArea'): { clientHeight: number; clientWidth: number } {
  const element = document.querySelector(selector);
  if (!element) {
    throw new TceSDKException('can not find element');
  }
  return {
    clientHeight: element.clientHeight,
    clientWidth: element.clientWidth,
  };
}

export { str2hex };
