export type ICustomizeAccessType = 'js' | 'iframe';

/**
 * 客制化产品
 */
export interface ICustomizeProduct {
  productCode: string;
  productName: string;
  modules: ICustomizeModule[];
}

/**
 * 客制化产品接入tab【如运营端的产品运营、平台运营等】
 */
export interface ICustomizeAccessTab {
  /**
   * 接入tab代码【如tab_cmgt_all_product（产品运营）】
   */
  code: string;
  /**
   * tab名称
   */
  name?: string;
  /**
   * 平台【如tce_ocloud（运营端）】
   */
  platform: string;
  /**
   * 是否可见
   */
  visible?: boolean;
  /**
   * 分类【如运营端产品运营下面的"计算和网络"】
   */
  types: ICustomizeType[];
  /**
   * 展示的位置【left/right】-- 客制化next开始支持
   */
  display?: 'left' | 'right';
  /**
   * 超链接引用
   */
  href?: string;
  /**
   * 超链接的target
   */
  target?: '_blank' | '_self';
}

/**
 * 分类【如运营端产品运营下面的”计算和网络“】
 */
export interface ICustomizeType {
  /**
   * 分类代码【如ops_computeAndNetWork（计算和网络）】
   */
  code: string;
  /**
   * 分类名称【如计算和网络】
   */
  name: string;
  /**
   * 图标
   */
  icon: string;
  /**
   * 图标【激活态】
   */
  iconActive: string;
  /**
   * 模块【如计算和网络下面的cvm、vpc等】
   */
  modules: ICustomizeModule[];
  /**
   * 超链接引用
   */
  href?: string;
}

/**
 * 分类【如（计算和网络）分类下的（cvm、vpc等）】
 */
export interface ICustomizeModule {
  /**
   * 模块唯一ID
   */
  uuid: string;
  /**
   * 模块名称【如：云服务器(cvm)】
   */
  name: string;
  /**
   * 默认url【如：云服务器(cvm)模块默认href为（/cvm）】
   */
  href: string;
  /**
   * 超链接的target
   */
  target?: '_blank' | '_self';
  /**
   * 暂时无用，在有target的时候才有
   */
  code?: string;
  /**
   * 模块图标
   */
  icon: string;
  /**
   * 模块图标【激活态】
   */
  iconActive: string;
  /**
   * 所属产品code
   */
  productCode?: string;
  /**
   * 所属产品名称
   */
  productName?: string;
  /**
   * 所属产品分组名称
   */
  groupName?: string;
}

/**
 * 模块接入信息
 */
export interface ICustomizeAccess {
  /**
   * 接入唯一ID
   */
  uuid?: string;
  /**
   * 模块标题
   */
  title?: string;
  /**
   * 模块图标
   */
  icon?: string;
  /**
   * 模块图标【激活态】
   */
  iconActive?: string;
  /**
   * 路由key
   */
  routerKey: string;
  /**
   * 所属产品代码
   */
  productCode?: string;
  /**
   * 所属产品名称
   */
  productName?: string;
  /**
   * 是否全屏
   */
  fullscreen?: boolean;
  /**
   * 接入方式【js、iframe】
   */
  type: ICustomizeAccessType;
  /**
   * 静态资源信息【js接入的时候才有】
   */
  asset?: ICustomizeAccessAsset;
  /**
   * iframe地址【iframe接入的时候才有】
   */
  iframeUrl?: string;
  /**
   * 菜单信息【购买页场景下没有菜单信息】
   */
  menus?: ICustomizeAccessMenu[];
}

/**
 * 模块接入菜单
 */
export interface ICustomizeAccessMenu {
  /**
   * 菜单唯一ID
   */
  uuid: string;
  /**
   * 菜单名称
   */
  name: string;
  /**
   * 菜单跳转地址
   */
  href: string;
  /**
   * 菜单图标
   */
  icon: string;
  /**
   * 菜单图标【激活态】
   */
  iconActive: string;
  /**
   * 子菜单
   */
  menus?: ICustomizeAccessMenu[];
}

/**
 * 铺平的菜单信息
 */
export interface IFlatMenu {
  /**
   * 菜单唯一ID
   */
  uuid: string;
  /**
   * 菜单名称
   */
  name: string;
  /**
   * 菜单跳转地址
   */
  href: string;
  /**
   * 二级菜单标题
   */
  title?: string;
  /**
   * 产品标题
   */
  product?: string;
  /**
   * 子菜单
   */
  menu?: IFlatMenu[];
}

/**
 * 接入静态资源信息
 */
export interface ICustomizeAccessAsset {
  /**
   * js地址
   */
  js: string;
  /**
   * css地址
   */
  css: string[];
}

/**
 * 当前页面接入信息
 */
export interface ICurrentAccess {
  /**
   * 当前页面的菜单信息
   */
  menu: ICustomizeAccessMenu;
  /**
   * 当前页面所在模块的接入信息
   */
  access: ICustomizeAccess; // 接入信息
}

export interface IAccess {
  type: ICustomizeAccessType;
  asset?: ICustomizeAccessAsset;
  iframeUrl?: string;
}
