import { PLATFORM_TYPE } from './constants';
import { IAccess, ICurrentAccess, ICustomizeAccess, ICustomizeAccessTab } from './types';
import { getDomainList } from '../domain';

// TCS客制化相关的内容
function getCustomizeConfig() {
  const { entrys } = window.TCS?.config || {};
  return entrys || [];
}

function getCustomizeIcon(icon: string, type: 'type' | 'product' | 'menu', id: string): string {
  const defaultIconMap = {
    type: 'modules/default.svg',
    product: 'modules/default.svg',
    menu: 'menu/default.svg',
  };
  // eslint-disable-next-line no-template-curly-in-string
  return !icon || icon === 'null' || icon === 'undefined' ? defaultIconMap[type] : icon.replace('${id}', id);
}

function getCustomizeActiveIcon(
  icon: string,
  type: 'type' | 'product' | 'menu',
  iconActive: string,
  id: string,
): string {
  // eslint-disable-next-line no-template-curly-in-string
  return iconActive ? iconActive.replace('${id}', id) : getCustomizeIcon(icon, type, id).replace('.svg', '_act.svg');
}

/**
 * 获取产品接入tabs【控制台顶部导航】
 */
export function getCustomizeAccessTabs(): ICustomizeAccessTab[] {
  const entries = getCustomizeConfig();
  return entries
    .sort((a, b) => a.order - b.order) // 排序
    .map((entry) => {
      const { code, name, modules, hide, href } = entry;
      return {
        code,
        name,
        visible: !hide,
        platform: PLATFORM_TYPE.TCS_OCLOUD,
        href,
        types: modules
          .sort((a, b) => a.order - b.order) // 排序
          .filter((m) => !hide && !(m.visible === false)) // 过滤出可见的
          .map((m) => {
            // customNav代表为自定义那些菜单放到顶部导航中
            const { id, code, title, icon, iconActive, customNav } = m;
            const name = m.name || title;
            const menus = customNav?.length > 0 ? customNav : m.menus;
            return {
              code,
              name,
              icon: getCustomizeIcon(icon, 'type', id),
              iconActive: getCustomizeActiveIcon(icon, 'type', iconActive, id),
              modules: menus
                .sort((a, b) => a.order - b.order) // 排序
                .filter((m) => !(m.headline === false)) // 过滤出放在顶部导航为false的数据
                .map((m) => {
                  const { href, icon, iconActive, name, uuid } = m;
                  const id = m.id || uuid;
                  return {
                    uuid: id,
                    name,
                    href,
                    icon: getCustomizeIcon(icon, 'type', id),
                    iconActive: getCustomizeActiveIcon(icon, 'type', iconActive, id),
                  };
                }),
            };
          }),
      };
    });
}

/**
 * 根据路由key获取接入信息
 * @param routerKey 路由key
 */
export function getCustomizeAccessInfoByRouterKey(routerKey: string): ICustomizeAccess | undefined {
  const entries = getCustomizeConfig();
  // 拉平数据
  const allModules = entries.map((entry) => entry.modules).flat(Infinity);
  const curModule = allModules.find((m) => m.statics?.[routerKey]);
  if (!curModule) return curModule;
  const { uuid, icon, iconActive, menus, title, statics, platform, sourcePlatform } = curModule;
  // 获取平台类型，在TCS场景下可能会存在【tcloud/ocloud/mcloud】
  const staticPlatform = sourcePlatform || platform || 'ocloud';
  const id = curModule.id || uuid;
  const name = curModule.name || title;

  // 获取静态资源完整url
  const { imgcache, console } = getDomainList();
  const getAssetsUrl = (fileName: string, sourcePlatform: string) =>
    `//${imgcache}${fileName.indexOf('/') === 0 ? '' : `/tcs-${sourcePlatform}/`}${fileName}`;

  const accessInfo = (routerKey: string): IAccess => {
    // 接入方式【js/iframe】
    const { js, css, iframe } = statics[routerKey];
    const accessInfo: IAccess = { type: 'js' };
    if (!iframe) {
      const { file, type } = js;
      Object.assign(accessInfo, {
        type: 'js',
        asset: {
          js: `${getAssetsUrl(file, staticPlatform)}${type ? `#rx-app-${type}` : ''}`,
          css: css ? css.map((c) => `${getAssetsUrl(c, staticPlatform)}`) : [],
        },
      });
    } else {
      const { file } = iframe;
      Object.assign(accessInfo, {
        type: 'iframe',
        iframeUrl: file.replace('<%=tceDomain%>', console),
      });
    }
    return accessInfo;
  };

  return {
    uuid: id,
    routerKey,
    title: name,
    fullscreen: false,
    icon: getCustomizeIcon(icon, 'type', id),
    iconActive: getCustomizeActiveIcon(icon, 'type', iconActive, id),
    ...accessInfo(routerKey),
    menus: menus
      .sort((a, b) => a.order - b.order) // 排序
      .map((m) => {
        const { href, icon, iconActive, uuid, name, title } = m;
        const id = m.id || uuid;
        const curMenu = {
          uuid: id,
          name: name || title,
          href,
          icon: getCustomizeIcon(icon, 'type', id),
          iconActive: getCustomizeActiveIcon(icon, 'type', iconActive, id),
        };
        const subMenus = m.menus;
        if (subMenus) {
          Object.assign(curMenu, {
            menus: subMenus
              .sort((a, b) => a.order - b.order)
              .map((sm) => {
                const { uuid, href, icon, iconActive, name } = sm;
                const id = sm.id || uuid;
                return {
                  uuid: id,
                  name,
                  href,
                  icon: getCustomizeIcon(icon, 'type', id),
                  iconActive: getCustomizeActiveIcon(icon, 'type', iconActive, id),
                };
              }),
          });
        }
        return curMenu;
      }),
  };
}

/**
 * 根据当前页面接入信息
 * @export
 * @param {string} [urlPath] urlPath 默认为当前页面的urlPath
 * @returns {(ICurrentAccess | undefined)}
 */
export function getCurrentPageAccessInfo(urlPath: string): ICurrentAccess | undefined {
  const entries = getCustomizeConfig();
  // 拉平数据
  const allModules = entries.map((entry) => entry.modules).flat(Infinity);
  let curRouterKey;
  for (const mod of allModules) {
    const { statics } = mod;
    // 正则匹配
    const curRouterkeys = Object.keys(statics || {}).filter((key) => new RegExp(`^/${key}`).test(urlPath));
    if (curRouterkeys.length > 0) {
      // 对curRouterkeys字符串长度进行排序【因为通过正则排序的时候容易出现两条数据，这个时候需要取路由key更长的一条】
      curRouterkeys.sort((a, b) => b.length - a.length);
      [curRouterKey] = curRouterkeys;
      // 获取菜单信息
      break;
    }
  }
  if (!curRouterKey) return;
  const currentAccess = getCustomizeAccessInfoByRouterKey(curRouterKey)!;
  const { menus } = currentAccess;
  const filterMenus = menus!.filter((m) => m.href && new RegExp(`^${m.href}`).test(urlPath));
  // 对filterMenus的href字符串长度进行排序【因为通过正则排序的时候容易出现两条数据，这个时候需要取href更长的一条】
  filterMenus.sort((a, b) => b.href.length - a.href.length);
  // 匹配菜单信息
  return {
    menu: filterMenus[0],
    access: currentAccess,
  };
}
