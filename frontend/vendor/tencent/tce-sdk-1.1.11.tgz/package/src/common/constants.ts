import {
  CamProps,
  AuthProps,
  MonitorProps,
  CbsProps,
  StandAloneProps,
  UMANAGEProps,
  ANNOUNCEProps,
  ApprovalProps,
  GroupAccountProps,
  PLATFORMSDKProps,
} from '@tencent/types-tce-sdk-component';

function isTcsOcloud(): boolean {
  return window.TCE_GLOBAL_CONSTANT?.platformType === PLATFORM_TYPE.TCS_OCLOUD;
}

function isTcsTcloud(): boolean {
  return window.TCE_GLOBAL_CONSTANT?.platformType === PLATFORM_TYPE.TCS_TCLOUD;
}

function isTcsPlatform(): boolean {
  return isTcsOcloud() || isTcsTcloud();
}

function isTceOcloud(): boolean {
  return window.TCE_GLOBAL_CONSTANT?.platformType === PLATFORM_TYPE.TCE_OCLOUD;
}

function getPlatform() {
  return isTceOcloud() ? 'ocloud' : 'tcloud';
}

/**
 * tcesdk动态加载静态资源的路径
 */
export const TCESDK_ASSETS_BASE_PATH = 'common/tcesdk/assets';

/**
 * tcesdk动态加载静态资源的路径[TCS场景下，静态资源的模块是tcs-common开头的]
 */
export const TCESDK_ASSETS_BASE_PATH_FOR_TCS = 'tcs-common/tcesdk/assets';

/**
 * 语言类型
 */
export const LANGUAGE_TYPE = {
  /**
   * 中文
   */
  ZH_CN: 'zh-CN',
  /**
   * 英文
   */
  EN_US: 'en-US',
};

/**
 * 平台类型
 */
export const PLATFORM_TYPE = {
  /**
   * tce租户端控制台
   */
  TCE_TCLOUD: 'tce_tcloud',
  /**
   * tce运营端控制台
   */
  TCE_OCLOUD: 'tce_ocloud',
  /**
   * tcs运营端控制台
   */
  TCS_OCLOUD: 'tcs_ocloud',
  /**
   * tcs租户端控制台
   */
  TCS_TCLOUD: 'tcs_tcloud',
  /**
   * jiguang平台
   */
  JIGUANG: 'jiguang',
  /**
   * tce租户端购买页
   */
  TCE_TCLOUD_BUY: 'tce_tcloud_buy',
  /**
   * tce租户端登录页
   */
  TCE_TCLOUD_LOGIN: 'tce_tcloud_login',
  /**
   * tce运营端登录页
   */
  TCE_OCLOUD_LOGIN: 'tce_ocloud_login',
  /**
   * tcs运营端登录页
   */
  TCS_OCLOUD_LOGIN: 'tcs_tcloud_login',
};

/* 组件名的枚举，用于调用函数时参数的提示，新增组件时需要在这个枚举中添加其名称及类型 */
export interface ComponentType {
  'cam-sdk': CamProps;
  'auth-sdk': AuthProps;
  'tag-sdk': any;
  'sg-sdk': any;
  'tsm-sdk': any;
  'monitor-v2-sdk': any;
  'monitor-v3-sdk': any;
  'cls-sdk': any;
  'standalone-sdk': StandAloneProps;
  'monitor-sdk': any;
  'cwhistle-sdk': MonitorProps;
  'approval-sdk': ApprovalProps;
  'cbs-sdk': CbsProps;
  'platform-sdk': PLATFORMSDKProps;
  'announce-sdk': ANNOUNCEProps;
  'umanage-sdk': UMANAGEProps;
  'project-sdk': GroupAccountProps;
  'csip-sdk': any;
  'inspector-sdk': any;
  'menus-sdk': any;
  'region-sdk': any;
  'organization-sdk': any;
  'tce-monitor-sdk': any;
  'edge-vnc': any;
  'billing-sdk': any;
}

export type ComponentMap = {
  [name in keyof ComponentType]?: {
    /**
     * 组件打包出来的的library名
     */
    libraryName?: string;
    /**
     * 组件静态资源的js地址
     */
    content: string;
    /**
     * 组件静态资源的css地址
     */
    css?: string[];
    /**
     * 业务sdk中用于判断sdk类型以加载依赖
     */
    component?: string;
    /**
     * 对应的前端组件名称【可用于获取组件对应的commitId】
     */
    componentName: string;
  };
};

function getCommonPath() {
  return isTcsPlatform() ? 'tcs-common' : 'common';
}

function getTagPath() {
  return isTcsPlatform() ? 'tcs-common/tag-sdk' : 'tcloud/sdk-tag';
}

function getPathPrefix() {
  return isTcsPlatform() ? 'tcs-' : '';
}

export const getSdkRouterMap = (): ComponentMap => {
  const { imgcacheHost } = window.TCE_GLOBAL_CONSTANT || {};
  return {
    'tag-sdk': {
      content: `//${imgcacheHost}/${getTagPath()}/tce-sdk-tag._lang_.js`,
      component: 'rx-app-tea2',
      css: [`//${imgcacheHost}/${getTagPath()}/tce-sdk-tag._lang_.css`],
      componentName: isTcsPlatform()
        ? 'product-frontend-imgcache-tcs-common-tag-sdk'
        : 'product-frontend-imgcache-tcloud-sdk_tag',
    },
    'sg-sdk': {
      content: `//${imgcacheHost}/tcloud/sdk-sg/tce-sdk-sg._lang_.js`,
      component: 'rx-app-tea2',
      css: [`//${imgcacheHost}/tcloud/sdk-sg/tce-sdk-sg._lang_.css`],
      componentName: 'product-frontend-imgcache-tcloud-sdk_sg',
    },
    'tsm-sdk': {
      content: `//${imgcacheHost}/tcloud/sdk-tsm/tsm-sdk._lang_.js`,
      component: 'rx-app-tea2',
      componentName: 'product-frontend-imgcache-tcloud-sdk_tsm',
    },
    'monitor-sdk': {
      content: `//${imgcacheHost}/tcloud/monitor-sdk/monitor-sdk._lang_.js`,
      component: 'rx-app-tea1',
      css: [`//${imgcacheHost}/tcloud/monitor-sdk/monitor-sdk._lang_.css`],
      componentName: 'product-frontend-imgcache-tcloud-monitor-sdk',
    },
    'monitor-v2-sdk': {
      content: `//${imgcacheHost}/tcloud/monitor-sdk2/monitor-sdk._lang_.js`,
      component: 'rx-app-tea2',
      css: [`//${imgcacheHost}/tcloud/monitor-sdk2/monitor-sdk._lang_.css`],
      componentName: 'product-frontend-imgcache-tcloud-monitor-sdk2',
    },
    'monitor-v3-sdk': {
      content: `//${imgcacheHost}/${getCommonPath()}/monitor-sdk3/monitor-sdk._lang_.js`,
      component: 'rx-app-tea2',
      css: [`//${imgcacheHost}/${getCommonPath()}/monitor-sdk3/monitor-sdk._lang_.css`],
      componentName: isTcsPlatform()
        ? 'product-frontend-imgcache-tcs-common-monitor-sdk3'
        : 'product-frontend-imgcache-common-monitor-sdk3',
    },
    'cls-sdk': {
      content: `//${imgcacheHost}/tcloud/cls-sdk/cls._lang_.js`,
      component: 'rx-app-tea2',
      css: [`//${imgcacheHost}/tcloud/cls-sdk/cls._lang_.css`],
      componentName: 'product-frontend-imgcache-tcloud-cls-sdk',
    },
    'tce-monitor-sdk': {
      content: `//${imgcacheHost}/common/tce-monitor-sdk/monitor.js`,
      component: 'rx-app-tea2',
      componentName: '',
    },
    'cwhistle-sdk': {
      libraryName: 'CWHISTLESDK',
      content: `//${imgcacheHost}/${getCommonPath()}/cwhistle-sdk/monitor.js`,
      component: 'rx-app-tea2',
      componentName: isTcsPlatform()
        ? 'product-frontend-imgcache-tcs-common-cwhistle-sdk'
        : 'product-frontend-imgcache-common-cwhistle-sdk',
    },
    'cam-sdk': {
      libraryName: 'CAMSDK',
      component: 'rx-app-tea2',
      content: `//${imgcacheHost}/${getCommonPath()}/cam-sdk/cam.js`,
      componentName: isTcsPlatform()
        ? 'product-frontend-imgcache-tcs-common-cam-sdk'
        : 'product-frontend-imgcache-common-cam-sdk',
    },
    'auth-sdk': {
      libraryName: 'AUTHSDK',
      content: `//${imgcacheHost}/${getCommonPath()}/auth-sdk/auth.js`,
      component: 'rx-app-tea2',
      componentName: isTcsPlatform()
        ? 'product-frontend-imgcache-tcs-common-auth-sdk'
        : 'product-frontend-imgcache-common-auth-sdk',
    },
    'standalone-sdk': {
      libraryName: 'STANDALONESDK',
      content: `//${imgcacheHost}/${getCommonPath()}/standalone-sdk/standalone.js`,
      componentName: isTcsPlatform()
        ? 'product-frontend-imgcache-tcs-common-standalone-sdk'
        : 'product-frontend-imgcache-common-standalone-sdk',
    },
    'approval-sdk': {
      libraryName: 'APPROVALSDK',
      content: `//${imgcacheHost}/${getCommonPath()}/approval-sdk/approval-sdk.js`,
      componentName: isTcsPlatform()
        ? 'product-frontend-imgcache-tcs-common-approval-sdk'
        : 'product-frontend-imgcache-common-approval-sdk',
    },
    'project-sdk': {
      libraryName: 'PROJECTSDK',
      content: `//${imgcacheHost}/${getCommonPath()}/project-sdk/project-sdk.js`,
      componentName: isTcsPlatform()
        ? 'product-frontend-imgcache-tcs-common-project-sdk'
        : 'product-frontend-imgcache-common-project-sdk',
    },
    'cbs-sdk': {
      content: `//${imgcacheHost}/${getCommonPath()}/cbs-sdk/cbs-sdk.js`,
      component: 'rx-app-tea2',
      componentName: isTcsPlatform()
        ? 'product-frontend-imgcache-tcs-common-cbs-sdk'
        : 'product-frontend-imgcache-common-cbs-sdk',
    },
    'platform-sdk': {
      libraryName: 'PLATFORMSDK',
      content: `//${imgcacheHost}/${getCommonPath()}/platform/platform-sdk.js`,
      component: 'rx-app-tea2',
      componentName: isTcsPlatform()
        ? 'product-frontend-imgcache-tcs-common-platform-sdk'
        : 'product-frontend-imgcache-common-platform-sdk',
    },
    'announce-sdk': {
      libraryName: 'ANNOUNCESDK',
      content: `//${imgcacheHost}/${getPlatform()}/announce/announce-sdk.js`,
      component: 'rx-app-tea2',
      componentName: '',
    },
    'umanage-sdk': {
      libraryName: 'UMANAGESDK',
      content: `//${imgcacheHost}/${getPathPrefix()}ocloud/umanage/umanage-sdk.js`,
      component: 'rx-app-tea2',
      componentName: '',
    },
    'csip-sdk': {
      content: `//${imgcacheHost}/tcloud/csip-sdk/overviewcard-securitycenter._lang_.js`,
      component: 'rx-app-tea2',
      css: [`//${imgcacheHost}/tcloud/csip-sdk/overviewcard-securitycenter._lang_.css`],
      componentName: 'product-frontend-imgcache-tcloud-csip-sdk',
    },
    'inspector-sdk': {
      content: `//${imgcacheHost}/${getCommonPath()}/inspector-sdk/inspector_sdk.js`,
      component: 'rx-app-tea2',
      css: [`//${imgcacheHost}/${getCommonPath()}/inspector-sdk/inspector_sdk.css`],
      componentName: 'product-frontend-imgcache-common-inspector-sdk',
    },
    'menus-sdk': {
      content: `//${imgcacheHost}/${getCommonPath()}/menu-sdk/menu-sdk._lang_.js`,
      css: [`//${imgcacheHost}/${getCommonPath()}/menu-sdk/menu-sdk._lang_.css`],
      component: 'rx-app-tea2',
      componentName: 'product-frontend-imgcache-common-menu-sdk',
    },
    'region-sdk': {
      content: `//${imgcacheHost}/${getCommonPath()}/region-sdk/region-sdk._lang_.js`,
      css: [`//${imgcacheHost}/${getCommonPath()}/region-sdk/region-sdk._lang_.css`],
      component: 'rx-app-tea2',
      componentName: 'product-frontend-imgcache-common-region-sdk',
    },
    'edge-vnc': {
      content: `//${imgcacheHost}/common/edge-vnc/edge-vnc._lang_.js`,
      component: 'rx-app-tea2',
      componentName: '',
    },
    'billing-sdk': {
      content: `//${imgcacheHost}/common/billing-sdk/billing.js`,
      component: 'rx-app-tea2',
      componentName: '',
    },
    ...(window.__sdkRouterByTce || {}),
  };
};

export const JIGUANG_LOGIN_EXPIRED_RELOAD_TIME_STORAGE = 'JIGUANG_LOGIN_EXPIRED_RELOAD_TIME';
