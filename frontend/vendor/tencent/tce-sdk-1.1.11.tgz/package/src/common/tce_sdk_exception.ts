/**
 * 定义TCE sdk专属异常类
 */
export default class TceSDKException extends Error {
  // eslint-disable-next-line @typescript-eslint/no-useless-constructor
  constructor(error: string) {
    super(error);
  }

  getMessage(): string {
    return this.message;
  }

  toString(): string {
    return `${'[TceSDKException]message:'}${this.getMessage()}`;
  }

  toLocaleString(): string {
    return `${'[TceSDKException]message:'}${this.getMessage()}`;
  }
}
