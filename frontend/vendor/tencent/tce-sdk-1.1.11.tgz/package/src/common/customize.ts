import { getDomainList } from '../domain';
import { isTceTcloudBuy, isTceOcloud, isTceTcloud, getCurrentPlatform, loc, isTcsOcloud } from '../common';
import { getCustomizeActiveIcon, getCustomizeIcon, getFullAssetUrl } from './util';
import * as tcs from './customize_tcs';
import * as next from './customize_next';
import {
  ICustomizeAccessTab,
  IAccess,
  ICurrentAccess,
  ICustomizeProduct,
  ICustomizeAccess,
  ICustomizeAccessMenu,
  ICustomizeModule,
  ICustomizeType,
  IFlatMenu,
} from './types';

/**
 * 获取客制化产品的配置【TCE平台适用】
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.10.11
 * @version TCE登录页、购买页 >= 3.10.11
 * @version TCS ❌
 * @param product 产品代码
 * @param platform 平台【'tcloud', 'ocloud', 'common'】
 * @param code 配置代码
 * @return string[]
 */
export function getCustomizeProductConfig(product: string, platform: string, code: string): string[] {
  const data = window?.g_product_config_data?.[product]?.[platform] || [];
  return data.filter((item) => item.code === code)?.[0]?.values || [];
}

interface FilterConfig {
  /**
   * 产品code
   */
  product: string;
  /**
   * 平台【'tcloud', 'ocloud', 'common'】
   */
  platform: string;
  /**
   * 配置code
   */
  code: string;
}

/**
 * 将入参中的product、platform、code等信息一并返回，方便处理
 */
interface ConfigItem extends FilterConfig {
  value: string[];
}

/**
 * 获取客制化产品的配置【TCE平台适用】
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS ❌
 * @return ConfigItem[]
 */
export function getCustomizeProductConfigMultiple(filters: FilterConfig[]): ConfigItem[] {
  return filters.map((item) => {
    const { product, platform, code } = item;
    const data = window?.g_product_config_data?.[product]?.[platform] || [];
    return {
      ...item,
      value: data.find((item) => item.code === code)?.values || [],
    };
  });
}

function getCustomizeTabs() {
  const oriTabs = window.g_platform_config_platformTabs || [];
  if (isTceTcloud() || isTceTcloudBuy()) {
    return oriTabs.filter(({ platform }) => platform === 'tenant_side');
  }
  if (isTceOcloud() || isTcsOcloud()) {
    return oriTabs.filter(({ platform }) => platform === 'ops_side');
  }
  return [];
}

function getCustomizeConfig() {
  const {
    productmenu,
    submenu,
    jsRouter,
    iframeRouter,
    css_config,
    navData,
    isCustomizeNext,
    frontendComponentDeployInfo,
  } = window.g_config_data || {};
  return {
    isCustomizeNext: isCustomizeNext || false,
    navData: navData || [],
    productmenu: productmenu || {},
    submenu: submenu || {},
    jsRouter: jsRouter || {},
    iframeRouter: iframeRouter || {},
    css_config: css_config || {},
    cusTabs: getCustomizeTabs(),
    frontendComponentDeployInfo: frontendComponentDeployInfo || {},
  };
}

// 接入方式【js/iframe】
function getAccessInfo({ jsRouter, css_config, iframeRouter, routerKey }): IAccess {
  const accessInfo: IAccess = { type: 'js' };
  const { base, imgcache } = getDomainList();
  const jsUrl = getFullAssetUrl(jsRouter[routerKey], imgcache!, base!);
  const cssUrl = getFullAssetUrl(css_config[routerKey], imgcache!, base!);
  if (jsRouter[routerKey]) {
    Object.assign(accessInfo, {
      type: 'js',
      asset: {
        js: jsUrl,
        css: cssUrl,
      },
    });
  }
  if (iframeRouter[routerKey]) {
    Object.assign(accessInfo, {
      type: 'iframe',
      iframeUrl: iframeRouter[routerKey].replace('domain-placeholder.com', base), // 替换掉缺省域名
    });
  }
  return accessInfo;
}

/**
 * 获取客制化产品接入tab
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.10.0
 * @version TCE登录页 ❌
 * @version TCS >= 2.3.0
 * @export
 * @returns {ICustomizeAccessTab[]}
 */
export function getCustomizeAccessTabs(): ICustomizeAccessTab[] {
  const { productmenu, cusTabs, navData, isCustomizeNext } = getCustomizeConfig();
  // 数据存在时候走客制化next
  if (isCustomizeNext) {
    return next.getCustomizeAccessTabs(navData);
  }
  if (isTcsOcloud()) {
    return tcs.getCustomizeAccessTabs();
  }
  const currentPlatform = getCurrentPlatform() || '';

  const tabs: ICustomizeAccessTab[] = [];

  Object.keys(productmenu).forEach((key) => {
    const currentProductList = productmenu[key];
    // 分类
    const customizeTypes: ICustomizeType[] = currentProductList.map((product) => {
      const { code, menu, title, icon, iconActive } = product;
      // 模块
      const modules: ICustomizeModule[] = menu.map((m) => {
        const { name, href, attribute1, code, target, icon, iconActive } = m;
        const defaultIcon = getCustomizeIcon(icon, 'product', attribute1);
        const data = {
          uuid: attribute1,
          name,
          href,
          icon: defaultIcon,
          iconActive: getCustomizeActiveIcon(defaultIcon, iconActive),
        };
        if (code) {
          Object.assign(data, { code });
        }
        if (target) {
          Object.assign(data, { target });
        }
        return data;
      });
      const defaultIcon = getCustomizeIcon(icon, 'type', code);
      return {
        code,
        name: title,
        icon: defaultIcon,
        iconActive: getCustomizeActiveIcon(defaultIcon, iconActive),
        modules,
      };
    });
    const tab: ICustomizeAccessTab = {
      code: key,
      platform: currentPlatform,
      types: customizeTypes,
    };
    // 如果tabs为空的话，则全部显示
    if (cusTabs.length === 0) {
      tab.visible = true;
    } else {
      // 获取客制化分类的信息
      const tabInfo = cusTabs.find(({ code }) => code === key);
      if (tabInfo) {
        const { name, showOnControl } = tabInfo;
        tab.name = name;
        tab.visible = showOnControl === 'Y';
      }
    }
    tabs.push(tab);
  });
  return tabs;
}

/**
 * 根据路由key获取接入信息
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.10.0
 * @version TCE登录页 ❌
 * @version TCS >= 2.3.0
 * @export
 * @param {string} routerKey 路由key
 * @returns {ICustomizeAccess[]}
 */
export function getCustomizeAccessInfoByRouterKey(routerKey: string): ICustomizeAccess | undefined {
  const { productmenu, submenu, jsRouter, iframeRouter, css_config, isCustomizeNext } = getCustomizeConfig();

  if (!isCustomizeNext && isTcsOcloud()) {
    return tcs.getCustomizeAccessInfoByRouterKey(routerKey);
  }

  // 将submenu对象转换为数组
  const objectToArrayForSub = (sub: any) => Object.keys(sub).map((key) => ({ routerKey: key, ...sub[key] }));

  // 购买页场景下，没有submenu，需要单独处理
  if (isTceTcloudBuy()) {
    const js = jsRouter[routerKey];
    if (!js) {
      return;
    }
    // 拉平数据
    const modules = Object.values(productmenu)
      .reduce((pre: any[], cur: any) => pre.concat(cur), [])
      .map(({ menu }) => menu)
      .flat();
    const currentModule = modules.filter(({ href }) => href && new RegExp(`^/${routerKey}`).test(href));
    const { name, attribute1, icon, iconActive } = currentModule[0] || {};
    const defaultIcon = getCustomizeIcon(icon, 'product', attribute1);
    return {
      uuid: attribute1,
      icon: defaultIcon,
      iconActive: getCustomizeActiveIcon(defaultIcon, iconActive),
      routerKey,
      title: name,
      ...getAccessInfo({ jsRouter, css_config, iframeRouter, routerKey }),
      type: js,
    };
  }

  // 判断路由key是否存在
  if (!jsRouter[routerKey] && !iframeRouter[routerKey]) {
    return;
  }

  let filterSubs: any[] = [];
  // 运营端的场景下，需要将数据合并
  if (isTceOcloud() || isCustomizeNext) {
    filterSubs = Object.values(submenu);
    filterSubs = filterSubs.reduce((pre: any[], cur: any) => pre.concat(objectToArrayForSub(cur)), []);
  } else {
    filterSubs = objectToArrayForSub(submenu);
  }
  filterSubs = filterSubs.filter((sub: any) => sub.routerKey && new RegExp(`^${sub.routerKey}/`).test(`${routerKey}/`));

  // 对filterSubs的routerKey字符串长度进行排序【因为通过正则排序的时候容易出现两条数据，这个时候需要取路由key更长的一条】
  filterSubs.sort((a, b) => b.routerKey.length - a.routerKey.length);

  // 如果在submenu中没有数据的话，对应的场景就是有接入没有菜单的场景
  if (filterSubs.length === 0) {
    return {
      routerKey,
      ...getAccessInfo({ jsRouter, css_config, iframeRouter, routerKey }),
    };
  }

  const { routerKey: rk, attribute1, menu, icon, iconActive, shortCode, shortName, ...rest } = filterSubs[0];
  const defaultIcon = getCustomizeIcon(icon, 'product', attribute1);
  return {
    uuid: attribute1,
    routerKey,
    icon: defaultIcon,
    iconActive: getCustomizeActiveIcon(defaultIcon, iconActive),
    menus: menu.map(({ uuid, name, title, menu, icon, iconActive, ...rest }) => {
      const defaultIcon = getCustomizeIcon(icon, 'menu', uuid);
      if (menu) {
        return {
          uuid,
          name: title,
          icon: defaultIcon,
          iconActive: getCustomizeActiveIcon(defaultIcon, iconActive),
          menus: menu.map(({ uuid, icon, iconActive, ...rest }) => {
            const defaultIcon = getCustomizeIcon(icon, 'menu', uuid);
            return {
              uuid,
              icon: defaultIcon,
              iconActive: getCustomizeActiveIcon(defaultIcon, iconActive),
              ...rest,
            };
          }),
          ...rest,
        };
      }
      return {
        uuid,
        name,
        icon: defaultIcon,
        iconActive: getCustomizeActiveIcon(defaultIcon, iconActive),
        ...rest,
      };
    }),
    productCode: shortCode,
    productName: shortName,
    ...getAccessInfo({ jsRouter, css_config, iframeRouter, routerKey }),
    ...rest,
  };
}

/**
 * 根据当前页面接入信息
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.10.0
 * @version TCE登录页 ❌
 * @version TCS >= 2.3.0
 * @export
 * @param {string} [urlPath] urlPath 默认为当前页面的urlPath
 * @returns {(ICurrentAccess | undefined)}
 */
export function getCurrentPageAccessInfo(urlPath?: string): ICurrentAccess | undefined {
  const { productmenu, submenu, jsRouter, iframeRouter, css_config, isCustomizeNext } = getCustomizeConfig();
  let currentPath = urlPath || loc.getLocationPath();
  if (!isCustomizeNext && isTcsOcloud()) {
    return tcs.getCurrentPageAccessInfo(currentPath);
  }
  // 购买页场景下单独处理
  if (isTceTcloudBuy() && currentPath === '/') {
    currentPath = '/cvm';
  }

  // 将submenu对象转换为数组
  const objectToArrayForSub = (sub: any) => Object.keys(sub).map((key) => ({ routerKey: key, ...sub[key] }));

  // 购买页场景下，没有submenu，需要单独处理
  if (isTceTcloudBuy() && !isCustomizeNext) {
    // 拉平数据
    const modules = Object.values(productmenu)
      .reduce((pre: any[], cur: any) => pre.concat(cur), [])
      .map(({ menu }) => menu)
      .flat();
    const currentModule = modules.filter(({ href }) => href && new RegExp(`^${href}`).test(currentPath));
    // 对currentModule的href字符串长度进行排序【因为通过正则排序的时候容易出现两条数据，这个时候需要取路由key更长的一条】
    currentModule.sort((a, b) => b.href.length - a.href.length);
    const { name, attribute1, href, icon, iconActive } = currentModule[0] || {};
    if (!href) return;
    const routerKey = href.substring(1);
    const js = jsRouter[routerKey];
    const defaultIcon = getCustomizeIcon(icon, 'product', attribute1);
    return {
      menu: {
        uuid: attribute1,
        name,
        href,
        icon: defaultIcon,
        iconActive: getCustomizeActiveIcon(defaultIcon, iconActive),
      },
      access: {
        uuid: attribute1,
        routerKey,
        title: name,
        type: js,
        icon: defaultIcon,
        iconActive: getCustomizeActiveIcon(defaultIcon, iconActive),
        asset: {
          js,
          css: css_config[routerKey] || [],
        },
      },
    };
  }

  let filterSubs: any[] = [];
  // 运营端的场景下，需要将数据合并
  if (isCustomizeNext || isTceOcloud()) {
    filterSubs = Object.values(submenu);
    filterSubs = filterSubs.reduce((pre: any[], cur: any) => pre.concat(objectToArrayForSub(cur)), []);
  } else {
    filterSubs = objectToArrayForSub(submenu);
  }
  filterSubs = filterSubs.filter((sub: any) => sub.routerKey && new RegExp(`^/${sub.routerKey}`).test(currentPath));

  if (filterSubs.length === 0) {
    return;
  }

  // 对filterSubs的routerKey字符串长度进行排序【因为通过正则排序的时候容易出现两条数据，这个时候需要取路由key更长的一条】
  filterSubs.sort((a, b) => b.routerKey.length - a.routerKey.length);

  const { routerKey, attribute1, menu, icon, iconActive, shortCode, shortName, ...rest } = filterSubs[0];
  let realRouterKey = routerKey;

  // 对jsRouter中的routerKey字符串长度进行排序【因为通过正则排序的时候容易出现两条数据，这个时候需要取路由key更长的一条】
  const jsRouterArr = Object.keys(jsRouter).sort((a, b) => b.length - a.length);
  const filterRouter = jsRouterArr.filter(
    (routerKey: string) => routerKey && new RegExp(`^/${routerKey}`).test(currentPath),
  );
  if (filterRouter.length > 0) {
    [realRouterKey] = filterRouter;
  }

  // 将menu里面的一级及二级菜单全部拉平
  const flatMenu = menu
    .map(({ menu, ...rest }) => {
      if (menu) return menu;
      return rest;
    })
    .flat();
  const filterMenus = flatMenu.filter((m) => m.href && new RegExp(`^${m.href}`).test(currentPath));
  // 对filterMenus的href字符串长度进行排序【因为通过正则排序的时候容易出现两条数据，这个时候需要取href更长的一条】
  filterMenus.sort((a, b) => b.href.length - a.href.length);
  const currentMenuInfo = filterMenus[0];
  if (currentMenuInfo) {
    const { icon, uuid } = currentMenuInfo;
    const defaultIcon = getCustomizeIcon(icon, 'menu', uuid);
    Object.assign(currentMenuInfo, {
      icon: defaultIcon,
      iconActive: getCustomizeActiveIcon(defaultIcon, iconActive),
    });
  }
  const defaultIcon = getCustomizeIcon(icon, 'product', attribute1);
  return {
    menu: isTceTcloudBuy()
      ? {
          uuid: attribute1,
          name: shortName,
          href: '',
          icon: defaultIcon,
          iconActive: getCustomizeActiveIcon(defaultIcon, iconActive),
        }
      : (currentMenuInfo as ICustomizeAccessMenu),
    access: {
      uuid: attribute1,
      routerKey: realRouterKey,
      icon: defaultIcon,
      iconActive: getCustomizeActiveIcon(defaultIcon, iconActive),
      menus: menu.map(({ uuid, name, title, menu, icon, iconActive, ...rest }) => {
        const defaultIcon = getCustomizeIcon(icon, 'menu', uuid);
        if (menu) {
          return {
            uuid,
            name: title,
            menus: menu.map(({ uuid, icon, iconActive, ...rest }) => {
              const defaultIcon = getCustomizeIcon(icon, 'menu', uuid);
              return {
                uuid,
                icon: defaultIcon,
                iconActive: getCustomizeActiveIcon(defaultIcon, iconActive),
                ...rest,
              };
            }),
            icon: defaultIcon,
            iconActive: getCustomizeActiveIcon(defaultIcon, iconActive),
            ...rest,
          };
        }
        return {
          uuid,
          name,
          icon: defaultIcon,
          iconActive: getCustomizeActiveIcon(defaultIcon, iconActive),
          ...rest,
        };
      }),
      productCode: shortCode,
      productName: shortName,
      ...getAccessInfo({ jsRouter, css_config, iframeRouter, routerKey }),
      ...rest,
    },
  };
}

/**
 * 根据uuid获取产品信息
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.10.0
 * @version TCE登录页 ❌
 * @version TCS ❌
 * @param uuid 产品uuid
 * @returns ICustomizeModule | undefined
 */
export function getProductInfoByUUID(uuid: string): ICustomizeModule | undefined {
  const { submenu, isCustomizeNext } = getCustomizeConfig();

  const tabs = getCustomizeAccessTabs();
  // 获取所有产品
  const products = tabs
    .map(({ types }) => types)
    .flat()
    .map(({ modules }) => modules)
    .flat();
  const currentProduct = products.find((p) => p.uuid === uuid);
  if (currentProduct) {
    const { href } = currentProduct;
    const curAccess = getCurrentPageAccessInfo(href);
    if (curAccess) {
      const { productCode, productName } = curAccess.access;
      if (productCode && productName) {
        Object.assign(currentProduct, { productCode, productName });
      }
    }
    Object.assign(currentProduct, { icon: getCustomizeIcon(currentProduct.icon!, 'product', currentProduct.uuid!) });
  }
  // 如果已经找到或者是购买页场景下【购买页场景没有submenu的概念】，就直接返回
  if (currentProduct || isTceTcloudBuy()) return currentProduct;
  // 如果当前uuid存在submenu中，则从submenu中获取
  // 将submenu对象转换为数组
  const objectToArrayForSub = (sub: any) => Object.keys(sub).map((key) => ({ routerKey: key, ...sub[key] }));

  let filterSubs: any[] = [];
  // 运营端的场景下，需要将数据合并
  if (isTceOcloud() || isCustomizeNext) {
    filterSubs = Object.values(submenu);
    filterSubs = filterSubs.reduce((pre: any[], cur: any) => pre.concat(objectToArrayForSub(cur)), []);
  } else {
    filterSubs = objectToArrayForSub(submenu);
  }
  const currentSub = filterSubs.find((sub: any) => sub.attribute1 === uuid);
  if (!currentSub) {
    return;
  }
  const { attribute1, title, icon, iconActive, menu, shortCode, shortName } = currentSub;
  const defaultIcon = getCustomizeIcon(icon, 'product', attribute1);
  return {
    uuid: attribute1,
    name: title,
    icon: defaultIcon,
    iconActive: getCustomizeActiveIcon(defaultIcon, iconActive),
    href: (() => {
      try {
        return menu[0].href ? menu[0].href : menu[0].menu[0].href;
      } catch (error) {
        return '';
      }
    })(),
    productCode: shortCode,
    productName: shortName,
  };
}

/**
 * 根据uuid获取菜单信息
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.10.0
 * @version TCE登录页、购买页  ❌
 * @version TCS ❌
 * @param uuid 菜单的uuid
 * @returns ICustomizeAccessMenu | undefined
 */
export function getMenuInfoByUUID(uuid: string): ICustomizeAccessMenu | undefined {
  const { submenu, isCustomizeNext } = getCustomizeConfig();
  // 购买页没有菜单，直接返回undefined
  if (isTceTcloudBuy()) return;
  // 将submenu对象转换为数组
  const objectToArrayForSub = (sub: any) => Object.keys(sub).map((key) => ({ routerKey: key, ...sub[key] }));

  let allSubs: any[] = [];
  // 运营端的场景下，需要将数据合并
  if (isCustomizeNext || isTceOcloud()) {
    allSubs = Object.values(submenu);
    allSubs = allSubs.reduce((pre: any[], cur: any) => pre.concat(objectToArrayForSub(cur)), []);
  } else {
    allSubs = objectToArrayForSub(submenu);
  }
  // 将sub中所有的menu拉平
  const allMenus = allSubs.map(({ menu }) => menu).flat();
  const currentMenu = allMenus.find((menu) => menu.uuid === uuid || menu.menu?.some((menu) => menu.uuid === uuid));
  if (!currentMenu) return;
  const { menu, title, icon, iconActive, ...rest } = currentMenu;
  const defaultIcon = getCustomizeIcon(icon, 'menu', uuid);
  Object.assign(currentMenu, {
    icon: defaultIcon,
    iconActive: getCustomizeActiveIcon(defaultIcon, iconActive),
  });
  // 属于一级菜单的
  if (rest.uuid === uuid) {
    return menu
      ? {
          name: title,
          icon: defaultIcon,
          iconActive: getCustomizeActiveIcon(defaultIcon, iconActive),
          ...rest,
          menus: menu.map(({ uuid, icon, ...rest }) => {
            const defaultIcon = getCustomizeIcon(icon, 'menu', uuid);
            return {
              uuid,
              icon: defaultIcon,
              iconActive: getCustomizeActiveIcon(defaultIcon, iconActive),
              ...rest,
            };
          }),
        }
      : currentMenu;
  } // 属于二级菜单
  const secMenu = menu.find((m) => m.uuid === uuid);
  const subDefaultIcon = getCustomizeIcon(icon, 'menu', uuid);
  Object.assign(secMenu, {
    icon: subDefaultIcon,
    iconActive: getCustomizeActiveIcon(subDefaultIcon, iconActive),
  });
  return secMenu;
}

/**
 * 获取环境部署的产品列表
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.10.0
 * @version TCE登录页、购买页  ❌
 * @version TCS ❌
 * @returns ICustomizeProduc[]
 */
export function getCustomizeProductList(): ICustomizeProduct[] {
  const { productmenu, submenu, isCustomizeNext, navData } = getCustomizeConfig();
  // 只支持TCE租户端、运营端及极光next，其他端直接返回[]
  if (!isTceOcloud() && !isTceTcloud() && !isCustomizeNext) {
    return [];
  }
  // 将submenu对象转换为数组
  const objectToArrayForSub = (sub: any) => Object.keys(sub).map((key) => ({ routerKey: key, ...sub[key] }));

  let allSubs: any[] = [];
  // 运营端的场景下，需要将数据合并
  if (isTceOcloud() || isCustomizeNext) {
    allSubs = Object.values(submenu);
    allSubs = allSubs.reduce((pre: any[], cur: any) => pre.concat(objectToArrayForSub(cur)), []);
  } else {
    allSubs = objectToArrayForSub(submenu);
  }

  // 从productmenu中获取productCode和productName
  const extractProducts = (): ICustomizeProduct[] => {
    const result: ICustomizeProduct[] = [];
    const seenShortCodes = new Set<string>();

    const menuGroups = Object.values(productmenu);
    for (const groupArray of menuGroups) {
      for (const group of groupArray as any[]) {
        for (const entry of group.menu) {
          const { productShortCode, name } = entry;
          if (productShortCode && !seenShortCodes.has(productShortCode)) {
            seenShortCodes.add(productShortCode);

            const nameWithoutShortCode = name.replace(`(${productShortCode})`, '').trim();
            result.push({
              productCode: productShortCode,
              productName: nameWithoutShortCode,
              modules: [],
            });
          }
        }
      }
    }
    return result;
  };

  // 极光next从navData中获取产品
  const extractProductsForNavData = (): ICustomizeProduct[] => {
    const products: ICustomizeProduct[] = [];

    const traverse = (nodes: any[]) => {
      nodes.forEach((node) => {
        // 如果当前节点有children，则递归处理这些children
        if (node.children && node.children.length > 0) {
          traverse(node.children);
        } else {
          const { code, name } = node;
          if (code && name) {
            products.push({
              productCode: node.code,
              productName: node.name,
              modules: [],
            });
          }
        }
      });
    };

    // 从根节点开始遍历navData
    traverse(navData.filter((d) => d.visible === true));
    return products;
  };

  // 从productmenu中获取的产品
  const productListForProductMenu = isCustomizeNext ? extractProductsForNavData() : extractProducts();

  // 从submenu中获取的产品不全，需要和productmenu中获取的产品做一个合并
  const productCodeMap: { [x: string]: string[] } = {};
  for (const m of allSubs) {
    const { shortCode, shortName, attribute1 } = m;
    const temp = `${shortCode}|${shortName}`;
    if (!productCodeMap[temp]) {
      productCodeMap[temp] = [attribute1];
    } else {
      const uuidArr = productCodeMap[temp];
      if (!uuidArr.includes(attribute1)) {
        productCodeMap[temp].push(attribute1);
      }
    }
  }
  const productListForSubmenu = Object.keys(productCodeMap).map((key) => {
    const [productCode, productName] = key.split('|');
    return {
      productCode,
      productName,
      modules: productCodeMap[key].map((k) => getProductInfoByUUID(k)!),
    };
  });

  const mergeArrays = (A: ICustomizeProduct[], B: ICustomizeProduct[]): ICustomizeProduct[] => {
    const productCodeMap: { [key: string]: ICustomizeProduct } = {};

    // Populate map with products from A
    A.forEach((product) => {
      productCodeMap[product.productCode] = product;
    });

    // Check products in B and add to map if not already present
    B.forEach((product) => {
      if (!productCodeMap[product.productCode]) {
        productCodeMap[product.productCode] = product;
      }
    });

    // Convert map values back to array
    return Object.values(productCodeMap);
  };

  // 将productListForProductMenu和productListForSubmenu合并【以productListForSubmenu为主】
  return mergeArrays(productListForSubmenu, productListForProductMenu);
}

/**
 * 根据产品code获取产品信息
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.10.0
 * @version TCE登录页、购买页  ❌
 * @version TCS ❌
 * @param productCode 产品code
 * @returns ICustomizeProduc | undefined
 */
export function getCustomizeProductByCode(productCode: string): ICustomizeProduct | undefined {
  if (!productCode) {
    return;
  }
  const productList = getCustomizeProductList();
  return productList.find((product) => product.productCode.toLowerCase() === productCode.toLowerCase());
}

/**
 * 获取客制化产品及菜单icon的完整地址
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.10.0
 * @version TCE登录页、购买页  ❌
 * @version TCS >= 2.3.0
 * @param icon 客制化返回的icon信息
 * @returns url
 */
export function getCustomizeIconUrl(icon: string): string {
  const { isCustomizeNext } = getCustomizeConfig();
  function getPath() {
    if (!isCustomizeNext && isTcsOcloud()) {
      return `tcs-common/${icon.includes('default') ? 'config/img' : 'platform/vendor/icons'}`;
    }
    return 'customize/cache/img/icon';
  }

  return /^(\/\/|http:\/\/|https:\/\/|data:image)/.test(icon)
    ? icon
    : `//${getDomainList().imgcache}/${getPath()}/${icon}`;
}

/**
 * 获取前端组件CommitId
 * @param routerKey 路由key，如果没有路由key的情况，传入组件名称
 */
export function getComponentCommitId(routerKey: string): string {
  const { frontendComponentDeployInfo } = getCustomizeConfig();
  const { deployInfo } = frontendComponentDeployInfo;
  return deployInfo?.[routerKey] || '';
}

/**
 * 获取所有的菜单信息
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.10.11
 * @version TCE登录页、购买页  ❌
 * @version TCS ❌
 */
export function getAllMenus(): IFlatMenu[] {
  const { submenu, isCustomizeNext } = getCustomizeConfig();
  // 购买页没有菜单，直接返回undefined
  if (isTceTcloudBuy()) return [];
  // 将submenu对象转换为数组
  const objectToArrayForSub = (sub: any) => Object.keys(sub).map((key) => ({ routerKey: key, ...sub[key] }));

  let allSubs: any[] = [];
  // 运营端的场景下，需要将数据合并
  if (isCustomizeNext || isTceOcloud()) {
    allSubs = Object.values(submenu);
    allSubs = allSubs.reduce((pre: any[], cur: any) => pre.concat(objectToArrayForSub(cur)), []);
  } else {
    allSubs = objectToArrayForSub(submenu);
  }
  // 将sub中所有的menu拉平
  const allMenus = allSubs
    .map(({ menu, title }) =>
      menu.map((m) => ({
        ...m,
        product: title,
      })),
    )
    .flat();
  return allMenus;
}

/**
 * 获取客制化产品中的登录建模相关的配置【TCS平台适用】
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 ❌
 * @version TCE登录页、购买页 ❌
 * @version TCS控制台 >= 2.3.5.0
 * @version TCS登录页 >= 2.3.5.0
 * @param code 配置代码 相关配置项可以从window.TCE_GLOBAL_CONSTANT.loginCustomizeInfo中获取
 * @return string | string[] | null
 */
export function getCustomizeProductLoginModalConfig(code: string): string | string[] | null {
  const loginCustomizeInfoData = window.TCE_GLOBAL_CONSTANT.loginCustomizeInfo ?? {};
  const keys = Object.keys(loginCustomizeInfoData);
  for (const key of keys) {
    // 获取当前键对应的对象
    const subObj = loginCustomizeInfoData[key];
    // 检查subObj是否为对象且包含code键
    if (typeof subObj === 'object' && subObj !== null && code in subObj) {
      // 返回找到的值
      return subObj[code];
    }
  }
  // 如果没有找到匹配的键，返回null
  return null;
}
