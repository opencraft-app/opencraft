/**
 * 通用的私有方法，不对方暴露
 */

import { JS_COOKIE } from '../constants';
import { getQueryParameters } from '../utils';
import { BaseUserInfo } from '../user';
import { Language } from '../language';
import { Region } from '../region';
import { FoyoConfig, TransportSecret } from '../config';
import {
  LANGUAGE_TYPE,
  PLATFORM_TYPE,
  TCESDK_ASSETS_BASE_PATH,
  ComponentMap,
  getSdkRouterMap,
  ComponentType,
} from './constants';
import { getSource, resetSourceCache, str2hex, loc, assets as tcesdkAssets } from './util';

export interface Title {
  [x: string]: string;
}

export interface TCE_GLOBAL_CONSTANT {
  /**
   * 平台类型
   */
  platformType?: string;
  /**
   * 登录域名
   */
  loginHost?: string;
  /**
   * 主域
   */
  baseHost?: string;
  /**
   * 官网域名
   */
  officialWebsiteHost?: string;
  /**
   * 购买页域名
   */
  buyHost?: string;
  /**
   * imgcache域名
   */
  imgcacheHost?: string;
  /**
   * cos域名
   */
  cosDomain?: string;
  /**
   * csp域名
   */
  cspDomain?: string;
  /**
   * 租户端控制台域名
   */
  tenantConsoleDomain?: string;
  /**
   * qcbase域名
   */
  qcbaseHost?: string;
  /**
   * 控制塔域名
   */
  consoleHost?: string;
  /**
   * 云api地址
   */
  yapiUrl?: string;
  /**
   * 传输加密信息
   */
  transportSecret?: TransportSecret;
  /**
   * 配置中心配置
   */
  foyoConfig?: FoyoConfig[];
  /**
   * title信息
   */
  title?: Title | string;
  /**
   * 支持的语言列表
   */
  languageList?: Language[];
  /**
   * 规划中支持的语言列表
   */
  planLanguageList?: Language[];
  /**
   * 弹性变量配置列表
   */
  elasticConfig?: any;
  /**
   * 客制化全局配置
   */
  customizeGlobalConfig?: any;
  /**
   * csrfCode
   */
  csrfCode?: string;
  /**
   * 内部主域 多域名的支持
   */
  innerMainDomain?: string | string[];
  /**
   * themeCode
   */
  themeCode?: string;
  /**
   * themeAssetsPath
   */
  themeAssetsPath?: string;

  staticAssets?: {
    tcesdk?: {
      path?: string;
    };
  };
  /**
   * 登录建模数据 用于组合交付下定制登录页面
   */
  loginCustomizeInfo?: any;
}

export interface TCE_GLOBAL_CONSTANT_ASYNC {
  regionList?: Region[];
  sdk?: object;
}

/**
 * 获取平台异步获取的常量
 */
export function getGlobalConstantsAsync(): TCE_GLOBAL_CONSTANT_ASYNC {
  return window.TCE_GLOBAL_CONSTANT_ASYNC;
}

/**
 * 获取平台所有的全局常量
 */
export function getGlobalConstants(): TCE_GLOBAL_CONSTANT {
  return window.TCE_GLOBAL_CONSTANT;
}

/**
 * 判断是否为TCE运营端控制台
 */
export function isTceOcloud(): boolean {
  return getGlobalConstants()?.platformType === PLATFORM_TYPE.TCE_OCLOUD;
}

/**
 * 判断是否为TCE运营端登陆页
 */
export function isTceOcloudLogin(): boolean {
  return getGlobalConstants()?.platformType === PLATFORM_TYPE.TCE_OCLOUD_LOGIN;
}

/**
 * 判断是否为TCE租户端控制台
 */
export function isTceTcloud(): boolean {
  return getGlobalConstants()?.platformType === PLATFORM_TYPE.TCE_TCLOUD;
}

/**
 * 判断是否为TCS运营端控制台
 */
export function isTcsOcloud(): boolean {
  return getGlobalConstants()?.platformType === PLATFORM_TYPE.TCS_OCLOUD;
}

/**
 * 判断是否为TCS租户端控制台
 */
export function isTcsTcloud(): boolean {
  return getGlobalConstants()?.platformType === PLATFORM_TYPE.TCS_TCLOUD;
}

/**
 * 判断是否为TCS运营端登录
 */
export function isTcsOcloudLogin(): boolean {
  return getGlobalConstants()?.platformType === PLATFORM_TYPE.TCS_OCLOUD_LOGIN;
}

/**
 * 判断是否为jiguang
 */
export function isJiGuang(): boolean {
  return getGlobalConstants()?.platformType === PLATFORM_TYPE.JIGUANG;
}

/**
 * 判断是否为TCE购买页
 */
export function isTceTcloudBuy(): boolean {
  return getGlobalConstants()?.platformType === PLATFORM_TYPE.TCE_TCLOUD_BUY;
}

/**
 * 获取当前平台类型
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS >= 2.1.0
 */
export function getCurrentPlatform() {
  return getGlobalConstants()?.platformType;
}

function getRegionListForTce() {
  const { regionList, zoneList } = window.I18N_CONFIG || {};
  if (!regionList) return [];
  // 获取当前语言
  const currentLang = getCurrentLang();
  // 获取zone信息
  const zoneMap = {};
  if (zoneList) {
    Object.keys(zoneList).forEach((key) => {
      zoneMap[key] = Object.keys(zoneList[key]).map((zoneKey) => {
        const { zone_id, zoneId, ...rest } = zoneList[key][zoneKey];
        return {
          zoneId: zone_id,
          zone: zoneId,
          zoneName: rest[`zone_name_${currentLang}`],
        };
      });
    });
  }

  return regionList.map(({ region_id, region_name, ...rest }) => ({
    regionId: region_id,
    region: region_name,
    regionName: rest[`region_name_${currentLang}`],
    zoneList: zoneMap[String(region_id)] || [],
  }));
}

function getRegionListForTcs() {
  const { regionList, zoneList } = window.TCS || {};
  if (!regionList) return [];
  // 获取当前语言
  const currentLang = getCurrentLang();
  return regionList.map(({ region_id, region_name, ...rest }) => ({
    regionId: region_id,
    region: region_name,
    regionName: rest[`region_name_${currentLang}`],
    zoneList: zoneList
      ? zoneList
          .filter(({ region_id: regionId }) => regionId === region_id)
          .map(({ zone_id, zone_name, ...rest }) => ({
            zoneId: zone_id,
            zone: zone_name,
            zoneName: rest[`zone_name_${currentLang}`],
          }))
      : [],
  }));
}

/**
 * 获取当前环境的语言列表【会自动根据不同的端来获取不同的数据】
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE登录页、购买页 >= 3.10.0
 * @version TCS ❌
 */
export function getLangList(): Language[] {
  if (isTceOcloud() || isTceTcloud()) {
    return window.I18N_CONFIG?.langList || [];
  }
  return getGlobalConstants()?.languageList || [];
}

/**
 * 获取客户规划中的语言列表【也就是交付给客户可以支持的语言列表】
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.10.11
 * @version TCE登录页、购买页 >= 3.10.11
 * @version TCS ❌
 */
export function getPlanLangList(): Language[] {
  return getGlobalConstants()?.planLanguageList || [];
}

/**
 * 获取环境当前语言
 * 取值顺序：url,window.I18N_CONFIG.tceLanguage,cookie
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.10.0
 * @version TCE登录页、购买页 ❌
 * @version TCS ❌
 */
export function getCurrentLang(): string {
  let { Language } = getQueryParameters();
  if (Language) return Language;

  // 控制台场景
  const { tceLanguage, langList } = window.I18N_CONFIG || {};
  if (tceLanguage) return tceLanguage;

  if (langList && langList.length > 0) {
    return langList.filter((lang) => lang.default)?.[0]?.name || LANGUAGE_TYPE.ZH_CN;
  }

  // cookie的场景主要用于登录的场景
  Language = JS_COOKIE.get('tce_language') || LANGUAGE_TYPE.ZH_CN;

  const _langList = getLangList();
  if (_langList && _langList.length > 0) {
    const isBuy = isTceTcloudBuy();
    if (_langList.find(({ name, id }) => (isBuy ? [id, name].includes(Language) : Language === name))) {
      return Language;
    }
    const defaultLang = _langList.find((lang) => lang.default);
    return (isBuy ? defaultLang?.id : '') || defaultLang?.name || LANGUAGE_TYPE.ZH_CN;
  }

  return Language;
}

/**
 * 获取平台当前语言下的货币
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.10.0
 * @version TCE登录页 ❌
 * @version TCS ❌
 */
export function getCurrentCurrency(): string {
  const langList = getLangList();
  const currentLang = getCurrentLang();
  const { currency } = langList.find((config) => config.name === currentLang) || ({} as any);
  const defaultCurrency = currentLang === LANGUAGE_TYPE.ZH_CN ? '元' : 'CNY'; // 默认货币，中文环境为元，其余环境为CNY，兼容没有langList的情况

  return currency ? currency : defaultCurrency;
}

interface CurrencyInfo {
  /**
   * 符号，如“￥”
   */
  symbol: string;
  /**
   * 中文词，如“人民币”
   */
  words: string;
  /**
   * 货币代号，如“CNY”
   */
  code: string;
}

const CurrencyInfoList = [
  ['¥', '人民币', 'CNY'],
  ['$', '美元', 'USD'],
  ['€', '欧元', 'EUR'],
  ['£', '英镑', 'GBP'],
  ['¥', '日元', 'JPY'],
  ['₹', '印度卢比', 'INR'],
  ['₩', '韩元', 'KRW'],
  ['₫', '越南盾', 'VND'],
  ['₱', '菲律宾比索', 'PHP'],
  ['₽', '俄罗斯卢布', 'RUB'],
  ['CHF', '瑞士法郎', 'CHF'],
  ['฿', '泰铢', 'THB'],
  ['R$', '巴西雷亚尔', 'BRL'],
  ['₺', '土耳其里拉', 'TRY'],
  ['₪', '以色列谢克尔', 'ILS'],
];
/**
 * 获取平台当前语言下的货币信息
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.10.0
 * @version TCE登录页 ❌
 * @version TCS ❌
 */
export function getCurrentCurrencyInfo(): CurrencyInfo {
  const currency = getCurrentCurrency();
  const [symbol, words, code] = CurrencyInfoList.find((info) => info.includes(currency)) || CurrencyInfoList[0];
  return { symbol, words, code };
}

/**
 * 同步方式获取地域列表，不区分产品
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE、TCS登录页、购买页 ❌
 * @version TCS控制台 >= 2.1.0
 */
export function getRegionListSync(): Region[] {
  // 优先判断window.TCE_GLOBAL_CONSTANT_ASYNC.regionList是否存在，存在的话优先取这个
  const regionList = getGlobalConstantsAsync()?.regionList ?? [];
  if (regionList.length > 0) {
    return regionList;
  }

  if (isTceTcloud() || isTceOcloud()) {
    return getRegionListForTce();
  }
  if (isTcsOcloud() || isTcsTcloud()) {
    return getRegionListForTcs();
  }
  return [];
}

function getTceOcloudRegion() {
  let region = '';
  const query = getQueryParameters();
  const urlRegion = query.region;
  if (urlRegion) {
    region = urlRegion;
  } else {
    // 这个场景下getCurrentUserInfo不可能为undefined
    const { userName } = getCurrentUserInfo() as BaseUserInfo;
    const locRegion = localStorage[`${userName}_zone_region`];
    if (locRegion && locRegion !== 'null') {
      // 有些模块可能会把null 字符串写到localstorage里
      region = locRegion;
    }
  }
  const regionList = getRegionListSync();
  if (!region) return regionList[0];
  const filterRegion = regionList.filter((regionInfo) => regionInfo.region === region);
  if (filterRegion.length === 0) {
    // 没有的话取第一个
    return regionList[0];
  }
  return filterRegion[0];
}

function getTceTcloudRegion() {
  let regionId = '';
  const query = getQueryParameters();
  const urlRegionId = query.rid || JS_COOKIE.get('regionId');
  if (urlRegionId) {
    regionId = urlRegionId;
  } else {
    // 这个场景下getCurrentUserInfo不可能为undefined
    const { userUin } = getCurrentUserInfo() as BaseUserInfo;
    const locRegionId = localStorage[`${userUin}_regionId`];
    if (locRegionId && locRegionId !== 'null') {
      // 有些模块可能会把null 字符串写到localstorage里
      regionId = locRegionId;
    }
  }
  const regionList = getRegionListSync();
  if (!regionId) return regionList[0];
  const filterRegion = regionList.filter((regionInfo) => String(regionInfo.regionId) === String(regionId));
  if (filterRegion.length === 0) {
    // 没有的话取第一个
    return regionList[0];
  }
  return filterRegion[0];
}

/**
 * 获取当前region信息
 * 获取优先级  url or localStorage
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE、TCS登录页、TCE购买页 ❌
 * @version TCS >= 2.1.0
 */
export function getCurrentRegion(): Region | undefined {
  if (isTceOcloud()) {
    return getTceOcloudRegion();
  }
  if (isTceTcloud() || isTceTcloudBuy()) {
    return getTceTcloudRegion();
  }
  if (isTcsOcloud() || isTcsTcloud()) {
    return getRegionListSync()[0];
  }
  return;
}

/**
 * 获取当前登录用户信息
 * @version TCE控制台 >= 3.8.0
 * @version TCE购买页 >= 3.10.0
 * @version TCE、TCS登录页 ❌
 * @version TCS控制台 >= 2.1.0
 */
export function getCurrentUserInfo(): BaseUserInfo | undefined {
  if (isTceOcloud()) {
    const userUin = JS_COOKIE.get('user_uin') || '';
    const ownerUin = JS_COOKIE.get('owner_uin') || '';
    const isOwner = String(userUin) === String(ownerUin);
    return {
      userUin,
      ownerUin,
      userName: JS_COOKIE.get('user_id') || '',
      isOwner,
      appId: JS_COOKIE.get('appId') || '',
    };
  }
  if (isTceTcloud() || isTceTcloudBuy()) {
    const userUin = JS_COOKIE.get('uin')?.replace(/o/, '') || '';
    const ownerUin = JS_COOKIE.get('ownerUin')?.replace(/O/, '').replace(/G/, '') || '';
    const isOwner = String(userUin) === String(ownerUin);
    return {
      userUin,
      ownerUin,
      userName: JS_COOKIE.get(isOwner ? 'lusername' : 'camusername') || '',
      isOwner,
      appId: JS_COOKIE.get('appid') || '',
    };
  }
  if (isTcsOcloud() || isTcsTcloud()) {
    const { uin, ownerUin, collName } = window.TCS?.currentUserInfo || {};
    return {
      ...(window.TCS?.currentUserInfo || {}),
      userUin: String(uin || ''),
      ownerUin: String(ownerUin || ''),
      userName: collName,
      isOwner: String(uin) === String(ownerUin),
      appId: JS_COOKIE.get('appId') || '',
    };
  }
  return undefined;
}

export {
  TCESDK_ASSETS_BASE_PATH,
  PLATFORM_TYPE,
  LANGUAGE_TYPE,
  getSource,
  resetSourceCache,
  str2hex,
  loc,
  ComponentMap,
  ComponentType,
  getSdkRouterMap,
  tcesdkAssets,
};
