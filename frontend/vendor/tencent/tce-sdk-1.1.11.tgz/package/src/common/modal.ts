import { LANG } from './lang';
import { loc } from './util';

/*
 * 通过js方式手动编写一个modal，用于底层请求登录态及IP限制等modal使用
 */
let isModalShowed = false; // 判断modal是否已经存在
const nonce = new Date().getTime();
const modalDomId = `tceGlobalModal_${nonce}`;
const modalCssId = `tceGlobalModal_${nonce}`;

function parseDom(arg: string) {
  const objE = document.createElement('div');
  objE.innerHTML = arg;
  return objE.childNodes;
}

const $ = (selector: string): HTMLElement | null => document.querySelector(selector);

// 插入css
function insertStyle() {
  const modalCss = `
      .blur_${nonce} {
        -webkit-filter: blur(5px); /* Chrome, Opera */
          -moz-filter: blur(5px);
            -ms-filter: blur(5px);
                filter: blur(5px);
      }

      #${modalCssId} .tea-overlay {
        z-index: 2001;
        position: fixed
      }

      #${modalCssId} .tea-backdrop {
        background-color: var(--tea-color-mask-primary, #000);
        opacity: .5;
        overflow-y: auto;
        z-index: 2000;
      }

      #${modalCssId} .tea-backdrop,#${modalCssId} .tea-dialog {
          bottom: 0;
          left: 0;
          position: fixed;
          right: 0;
          top: 0
      }

      #${modalCssId} .tea-dialog {
          text-align: center;
          z-index: 2001;
          overflow: auto;
          white-space: nowrap
      }

      #${modalCssId} .tea-dialog:before {
          content: "";
          display: inline-block;
          width: 0;
          height: 100%;
          vertical-align: middle
      }

      #${modalCssId} .tea-dialog__inner {
        text-align: left;
        white-space: normal;
        display: inline-block;
        vertical-align: middle;
        min-width: 420px;
        width: 550px;
        height: 500p;
        background-color: var(--tea-color-bg-primary-default, #fff);
        padding: 25px;
        box-sizing: border-box;
        box-shadow: 1px 1.732px 20px 0 rgba(0,0,0,.2);
      }

      #${modalCssId} .tea-dialog__body:after,#${modalCssId} .tea-dialog__footer:after,#${modalCssId} .tea-dialog__header:after {
          content: "";
          display: table;
          clear: both
      }

      #${modalCssId} .tea-dialog__body {
          color: var(--tea-color-text-primary, #444);
      }

      #${modalCssId} .tea-dialog__bodytitle {
          font-size: 16px;
          font-weight: 700;
          margin-bottom: 5px;
          color: var(--tea-color-text-primary, #000);
          margin-top: 0;
          line-height: 36px
      }

      #${modalCssId} .tea-dialog__messagetitle {
          font-size: 18px;
          color: var(--tea-color-text-primary, #171d25);
          vertical-align: middle
      }

      #${modalCssId} .tea-dialog__messagetext {
          font-size: 12px;
          color: var(--tea-color-text-tertiary, #74777c);
          margin-top: 5px;
          line-height: 22px
      }

      #${modalCssId} .tea-dialog__footer {
          border-top: 0;
          position: relative;
          margin-top: 30px
      }

      #${modalCssId} .tea-dialog__btnwrap {
          text-align: center;
          position: relative;
          z-index: 0;
          font-size: 0
      }

      #${modalCssId} .tea-dialog__btnwrap .tea-btn {
          margin: 0 5px
      }

      #${modalCssId} .tea-media {
        display: -webkit-box;
        display: flex;
        -webkit-box-align: start;
        align-items: flex-start
      }

      #${modalCssId} .tea-btn {
        height: 30px;
        min-width: 24px;
        padding: 0 20px;
        background-color: var(--button-color-bg-solid-default-brand, #006eff);
        color:  var(--button-color-text-solid-default-brand, #fff);
        border: 1px solid var(--button-color-bg-solid-default-brand, #006eff);
        line-height: 30px;
        text-align: center;
        display: inline-block;
        cursor: pointer;
        outline: 0 none;
        box-sizing: border-box;
        text-decoration: none;
        font-size: 12px;
        vertical-align: middle;
        white-space: nowrap
      }

      #${modalCssId} .tea-btn:hover {
        border-color: var(--button-color-border-solid-hover-brand, #0063e5);
        background-color: var(--button-color-border-solid-hover-brand, #0063e5);
        text-decoration: none;
        -webkit-transition: all .3s ease-in-out;
        transition: all .3s ease-in-out
      }

      #${modalCssId} .tea-btn.is-loading:hover {
          border-color: var(--button-color-bg-solid-default-brand, #006eff);
          background-color: var(--button-color-bg-solid-default-brand, #006eff);
      }

      #${modalCssId} .tea-btn:active {
          border-color: var(--button-color-border-solid-active-brand, #0058cc);
          background-color: var(--button-color-bg-solid-active-brand, #0058cc);
      }

      #${modalCssId} .tea-btn:active,.tea-btn:focus {
          -webkit-transition: all .3s ease-in-out;
          transition: all .3s ease-in-out
      }

      #${modalCssId} .tea-icon {
        width: 16px;
        height: 16px;
        display: inline-block;
        vertical-align: middle;
        background-repeat: no-repeat;
        background-position: inherit;
        font-size: 0
      }

      @-webkit-keyframes modal_spin {
        0% {
            -webkit-transform: rotate(0deg)
        }

        to {
            -webkit-transform: rotate(359deg)
        }
      }

      @keyframes modal_spin {
          0% {
              -webkit-transform: rotate(0deg);
              transform: rotate(0deg)
          }

          to {
              -webkit-transform: rotate(359deg);
              transform: rotate(359deg)
          }
      }


      #${modalCssId} .tea-btn.is-loading {
        pointer-events: none;
        vertical-align: -3px;
      }

      #${modalCssId} .tea-icon-loading {
        background-image: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgZmlsbD0iI2ZmZiI+PHBhdGggZD0iTTggMTZBOCA4IDAgMSAxIDggMHYyYTYgNiAwIDEgMCA2IDZoMmE4IDggMCAwIDEtOCA4eiIgZmlsbC1ydWxlPSJldmVub2RkIi8+PC9zdmc+);
        -webkit-animation: modal_spin .6s linear infinite;
        animation: modal_spin .6s linear infinite
      }

    `;
  $('head')?.appendChild(parseDom(`<style id="${modalCssId}">${modalCss}</style>`)[0]);
}

function removeStyle() {
  $(`#${modalCssId}`)?.remove();
}

function blurPage() {
  /* istanbul ignore next */
  ['#topnav', '#sidebar', '#appArea'].forEach((sel) => $(sel)?.classList.add(`blur_${nonce}`));
}

function cancelBlurPage() {
  /* istanbul ignore next */
  ['#topnav', '#sidebar', '#appArea'].forEach((sel) => $(sel)?.classList.remove(`blur_${nonce}`));
}

export const MODAL = {
  show: (config) => {
    if (isModalShowed) {
      return;
    }
    isModalShowed = true;
    insertStyle();
    const { message, description, onConfirm } = config;
    const modalTemplete = `
        <div class="tea-overlay">
        <div class="tea-backdrop"></div>
          <div class="tea-dialog">
            <div class="tea-dialog__inner">
              <div class="tea-dialog__body">
                <div class="tea-media">
                  <div class="tea-media__body">
                    <h3 class="tea-dialog__messagetitle">
                      ${message}
                    </h3>
                    <div class="tea-dialog__messagetext">
                      ${description}
                    </div>
                  </div>
                </div>
              </div>
              <div class="tea-dialog__footer">
                <div class="tea-dialog__btnwrap">
                  <button class="tea-btn" id="${modalDomId}_confirmBtn">
                    ${LANG.t('ok')}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      `;
    // 虚化页面内容，防止内容泄密
    blurPage();
    $('body')?.append(parseDom(`<div id="${modalDomId}">${modalTemplete}</div>`)[0]);
    $(`#${modalDomId}_confirmBtn`)?.addEventListener('click', function () {
      this.classList.add('is-loading');
      this.innerHTML = '<i class="tea-icon tea-icon-loading"></i>';
      onConfirm();
    });
  },
  hide: () => {
    cancelBlurPage();
    removeStyle();
    isModalShowed = false;
    $(`#${modalDomId}`)?.remove();
  },
  showPreLoginModal: (message, description, callback) => {
    MODAL.show({
      message,
      description,
      onConfirm: () => {
        callback();
      },
    });
  },
};

/**
 * 针对iframe这种登录态过期重新回到登录页面
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 >= 3.8.0
 * @version TCE购买页 >= 3.10.0
 * @version TCE、TCS登录页 ❌
 * @version TCS控制台 >= 2.1.0
 */
export function toLoginPageForExpired() {
  loc.locationReload();
}

/**
 * 显示进入登录页面的Modal
 * @param message 标题
 * @param description 的描述信息
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、购买页 >= 3.8.0
 * @version TCE、TCS登录页 ❌
 * @version TCS控制台 >= 2.1.0
 */
export function showPreLoginModal(message: string, description: string) {
  MODAL.showPreLoginModal(message, description, toLoginPageForExpired);
}
