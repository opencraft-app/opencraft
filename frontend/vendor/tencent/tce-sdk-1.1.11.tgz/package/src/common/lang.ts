import { getCurrentLang, LANGUAGE_TYPE } from '../common';
const langMap = {
  [LANGUAGE_TYPE.ZH_CN]: {
    ok: '确定',
    loginExpireModal: {
      title: '登录态失效',
      description: '请点击确定重新登录',
    },
    ipLimitModal: {
      title: 'IP访问限制',
      description:
        '抱歉，您当前登录的IP为{{ip}}，为限制访问的IP段，如有疑问，请联系企业运营管理人员进行IP访问限制的配置变更',
    },
    SecondaryCertification: '该操作需要二次认证',
    NeedApproval: '该操作需要审批',
  },
  [LANGUAGE_TYPE.EN_US]: {
    ok: 'OK',
    loginExpireModal: {
      title: 'Login Expired',
      description: 'Please click OK to log in again.',
    },
    ipLimitModal: {
      title: 'IP Access Restriction',
      description:
        'Your login IP is {{ip}} in the restricted-access IP network segment, please use the authorized IP to log in to the system.',
    },
    SecondaryCertification: 'This operation requires secondary authentication.',
    NeedApproval: 'This operation requires need approval.',
  },
};

export const LANG = {
  t(path: string) {
    let content = langMap[getCurrentLang()];
    const pathArr = path.split('.');
    let value: any = '';

    for (let i = 0, len = pathArr.length; i < len; i++) {
      value = content[pathArr[i]];
      if (i === len - 1) {
        return value;
      }
      if (!value) {
        return '';
      }
      content = value;
    }
  },
};
