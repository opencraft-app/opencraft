/**
 * 同步获取配置中心配置
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台、登录页 >= 3.10.0
 * @version TCE购买页 ❌
 * @version TCS ❌
 * @param Namespace 配置分类
 * @param Key 关键字
 * @return  boolean | string | object | number
 */
export function getConfigSync(Namespace: string, Key: string): boolean | string | object | number | any[] | undefined {
  const windowConfigs = window.TCE_GLOBAL_CONSTANT.foyoConfig;
  const config = windowConfigs?.find((config) => config.Namespace === Namespace && config.Key === Key);
  if (!config) return undefined;
  return JSON.parse(decodeURIComponent(atob(config.Value)));
}
