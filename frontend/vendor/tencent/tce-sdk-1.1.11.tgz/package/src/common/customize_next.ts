import { ICustomizeAccessTab } from './types';
import { getCustomizeIcon, getCustomizeActiveIcon } from './util';
export function getCustomizeAccessTabs(navData: any[]): ICustomizeAccessTab[] {
  return navData
    .filter(({ visible }) => visible === true)
    .map((nav) => {
      const { name, code, platform, children, visible, display, href, target } = nav;
      return {
        name,
        code,
        platform,
        visible,
        display,
        href,
        target,
        types: children
          .filter(({ visible }) => visible === true)
          .map((child) => {
            const { name, uuid, children, icon, iconActive, href } = child;
            const defaultIcon = getCustomizeIcon(icon, 'type', uuid);
            return {
              code: uuid,
              name,
              icon: defaultIcon,
              iconActive: getCustomizeActiveIcon(defaultIcon, iconActive),
              href,
              modules: children
                .filter(({ visible }) => visible === true)
                .map((child) => {
                  const { name, href, uuid, icon, iconActive, target, groupName } = child;
                  const defaultIcon = getCustomizeIcon(icon, 'type', uuid);
                  return {
                    name,
                    uuid,
                    href,
                    icon: defaultIcon,
                    iconActive: getCustomizeActiveIcon(defaultIcon, iconActive),
                    target,
                    groupName,
                  };
                }),
            };
          }),
      };
    });
}
