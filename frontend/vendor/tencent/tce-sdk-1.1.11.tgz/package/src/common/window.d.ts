import { JSEncrypt } from 'jsencrypt';
import { CountryAttribute } from './country';
import { SeaJs } from '@tencent/types-tce-seajs';
import { ProvinceMap } from './location_zh_cn';
import watermark_js from '@tencent/watermarkjs';
declare global {
  interface Window {
    JSEncrypt: typeof JSEncrypt;
    SM2Lib: any;
    seajs: SeaJs;
    country: CountryAttribute;
    provinceMap: ProvinceMap;
    watermarkjs: typeof watermark_js;
  }
}
