import { TCESDK_ASSETS_BASE_PATH, TCESDK_ASSETS_BASE_PATH_FOR_TCS, PLATFORM_TYPE } from './constants';
import { TextEncoder } from './text_encoder';

/**
 * 异步加载js
 * @param url js的url
 */
const sourceLoadingMap = new Map<string, Promise<void>>();

export function resetSourceCache() {
  sourceLoadingMap.clear();
}

export async function getSource(url: string): Promise<void> {
  if (sourceLoadingMap.has(url)) {
    return sourceLoadingMap.get(url)!;
  }
  const promise = new Promise<void>((resolve, reject) => {
    const isCss = /\.css(?:\?|$)/i.test(url);
    const source = document.createElement(isCss ? 'link' : 'script');
    Object.assign(source, isCss ? { rel: 'stylesheet', href: url } : { type: 'text/javascript', src: url });
    isCss && source.setAttribute('data-role', 'global');
    // script.setAttribute('crossorigin', 'anonymous');
    source.onload = () => {
      resolve();
    };
    source.onerror = (e) => {
      sourceLoadingMap.delete(url);
      reject(e);
    };
    document.getElementsByTagName('head')[0].appendChild(source);
  });
  sourceLoadingMap.set(url, promise);
  return promise;
}

/**
 * 字符串转16进制
 * @param str 字符串
 */
export function str2hex(str: string): string {
  const encoder = window.TextEncoder ? new window.TextEncoder() : new TextEncoder();
  const bytes = encoder.encode(str);
  let hex = '';
  for (const byte of bytes) {
    hex += byte.toString(16).padStart(2, '0');
  }
  return hex;
}

/**
 * 包装location
 */
/* istanbul ignore next */
export const loc = {
  setLocationHref(newHref: string) {
    /* istanbul ignore next */
    window.location.href = newHref;
  },
  getLocationHref() {
    /* istanbul ignore next */
    return window.location.href;
  },
  getLocationPath() {
    /* istanbul ignore next */
    return window.location.pathname;
  },
  locationReload() {
    /* istanbul ignore next */
    window.location.reload();
  },
};

function getTceSdkAssetsBasePath() {
  const { imgcacheHost, platformType, staticAssets } = window.TCE_GLOBAL_CONSTANT || {};
  const basePath = staticAssets?.tcesdk?.path;
  if (basePath) return `//${imgcacheHost}/${basePath}`;
  const isTcs =
    platformType === PLATFORM_TYPE.TCS_OCLOUD ||
    platformType === PLATFORM_TYPE.TCS_TCLOUD ||
    platformType === PLATFORM_TYPE.TCS_OCLOUD_LOGIN;
  return `//${imgcacheHost}/${isTcs ? TCESDK_ASSETS_BASE_PATH_FOR_TCS : TCESDK_ASSETS_BASE_PATH}`;
}

/**
 * 获取tcesdk加载外部的静态资源
 */
export const assets = {
  getTceSdkAssetsBasePath,
  getXlsxUrl() {
    return `${getTceSdkAssetsBasePath()}/xlsx/xlsx.full.min.js`;
  },
  getCryptoJSUrl() {
    return `${getTceSdkAssetsBasePath()}/crypto-js/crypto-js.min.js`;
  },
  getJsencryptUrl() {
    return `${getTceSdkAssetsBasePath()}/jsencrypt/jsencrypt.min.js`;
  },
  getSMUrl() {
    return `${getTceSdkAssetsBasePath()}/smencrypt/SM.js`;
  },
  getWaterMarkUrl() {
    return `${getTceSdkAssetsBasePath()}/watermark/watermarkjs.umd.js`;
  },
};

/**
 * 获取客制化产品及菜单的icon
 * @param icon 源icon
 * @param type 'type' | 'product' | 'menu'
 * @param uuid 菜单或产品的唯一ID
 * @returns
 */
export function getCustomizeIcon(icon: string, type: 'type' | 'product' | 'menu', uuid: string): string {
  const defaultIconMap = {
    type: 'default_product_type.svg',
    product: 'default_product.svg',
    menu: 'default_menu.svg',
  };

  if (!icon || icon === 'null' || icon === 'undefined') {
    return defaultIconMap[type];
  }

  return icon === '1' ? `${uuid}.svg` : icon;
}

/**
 *  获取客制化产品及菜单的icon【激活状态】
 * @param icon 源icon
 * @param type 'type' | 'product' | 'menu'
 * @param iconActive 源激活态icon
 * @returns
 */
export function getCustomizeActiveIcon(icon: string, iconActive: string): string {
  return iconActive ? iconActive : icon.replace('.svg', '_hover.svg');
}

/**
 * 获取完整url地址
 * @param url 原始url
 * @param imgcache imgcache域名
 * @param base 主域
 * @returns
 */
export function getFullAssetUrl(url: string | string[], imgcache: string, base: string): string | string[] {
  const processUrl = (inputUrl: string) => {
    if (/^((https?:)?\/\/)/i.test(inputUrl) || !inputUrl) {
      return inputUrl;
    }
    return `//${imgcache}${inputUrl}`.replace('domain-placeholder.com', base);
  };

  if (Array.isArray(url)) {
    return url.map((singleUrl) => processUrl(singleUrl));
  }
  return processUrl(url);
}
