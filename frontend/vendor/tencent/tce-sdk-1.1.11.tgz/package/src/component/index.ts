import TceSDKException from '../common/tce_sdk_exception';
import {
  getSource,
  getGlobalConstants,
  getCurrentLang,
  getSdkRouterMap,
  isTceTcloudBuy,
  ComponentType,
  TCESDK_ASSETS_BASE_PATH,
} from '../common';
import { getComponentCommitId } from 'src/common/customize';

interface UrlConfig {
  bundles16: string[];
  tea2comopnent: string[];
  reati18next: string[];
}

function parseUrl(url: string, componentName: string) {
  const urlMapByLanguage = {
    /**
     * 中文
     */
    'zh-CN': 'zh',
    /**
     * 英文
     */
    'en-US': 'en',
  };
  const Language = getCurrentLang();
  const { imgcacheHost } = getGlobalConstants() || {};
  const commitId = getComponentCommitId(componentName);
  /* istanbul ignore next */
  return (
    (url.includes('//imgcache') ? '' : `//${imgcacheHost}`) +
    url.replace('_lang_', urlMapByLanguage[Language]) +
    (commitId ? `?${commitId}` : '')
  );
}

/* istanbul ignore next */
function loadBundle(bundle, cb) {
  window.seajs.use(bundle, () => {
    setTimeout(cb, 1);
  });
}

// 动态加载CSS
/* istanbul ignore next */
function setCssGlobal(href) {
  Array.from(document.querySelectorAll('link[rel="stylesheet"]')).forEach((dom) => {
    if (dom.getAttribute('href')?.match(href)) {
      dom.setAttribute('data-role', 'global');
      dom.removeAttribute('disabled');
    }
  });
}

/* istanbul ignore next */
async function preLoad() {
  const { imgcacheHost } = getGlobalConstants() || {};
  const urlConfig: UrlConfig = window.seajs.require('config/reactSupport');

  /* istanbul ignore next */
  const CONFIG = {
    bundles16: urlConfig?.bundles16
      ? urlConfig?.bundles16
      : [
          `//${imgcacheHost}/common/js/react/polyfill.min.js`,
          `//${imgcacheHost}/common/js/react/react-with-addons.min.js`,
          `//${imgcacheHost}/${TCESDK_ASSETS_BASE_PATH}/moment/moment.min.js`,
          `//${imgcacheHost}/common/js/react/react16.production.js`,
        ],
    reactI18next: urlConfig?.reati18next
      ? urlConfig?.reati18next
      : [`//${imgcacheHost}/common/js/i18next/i18next-lib-16.js`],
    tea2component: urlConfig?.tea2comopnent
      ? urlConfig?.tea2comopnent
      : [
          `//${imgcacheHost}/common/js/tea2/tea-component-v2.js`,
          isTceTcloudBuy() && document.querySelector("link[href$='/buy.css']") // 购买页加载了tcb样式就不加载tea
            ? undefined
            : `//${imgcacheHost}/common/css/tea2/tea-v2.min.css`,
        ],
  };

  const use = (cb) => {
    loadBundle(CONFIG.bundles16, () => {
      loadBundle(CONFIG.reactI18next, () => {
        loadBundle(CONFIG.tea2component, () => {
          setCssGlobal(/tea-.*.min.css$/);
          cb();
        });
      });
    });
  };
  await new Promise((res) => {
    use(res);
  });
}

const loadingMap = new Map<string, Promise<any>>();

export async function getComponent<T>(
  name: T extends keyof ComponentType ? T : keyof ComponentType, // 传入自定义泛型的情况下name取ComponentType的key，其他情况填入的参数赋值T去取对应的类型
): Promise<T extends keyof ComponentType ? ComponentType[T] : T> {
  const component = getSdkRouterMap()[name] || window.__sdkRouterByTce[name];
  if (!component) throw new TceSDKException('Component not found');

  const { libraryName, content, css, componentName } = component;

  const isSdk = !libraryName;

  if (!(libraryName && window[libraryName]) && !window.TCE_GLOBAL_CONSTANT_ASYNC?.sdk?.[name as keyof ComponentType]) {
    // 并发调用复用同一个加载 Promise，避免重复请求
    /* istanbul ignore next */
    if (!loadingMap.has(name as string)) {
      const loadPromise = (async () => {
        // @ts-ignore [如果已经全局加载了就不用再加载了]
        if (!window.React16 || !window.ReactDOM16 || !window.TeaComponentV2 || !window.i18next) {
          await preLoad();
        }
        await getSource(parseUrl(content, componentName));
        if (css) {
          /* istanbul ignore next */
          const cssLists = css.map(async (url) => await getSource(parseUrl(url, componentName)));
          await Promise.all(cssLists);
        }
        if (isSdk) {
          await new Promise<void>((resolve) => {
            window.seajs.use(`sdk/${name}`, (module) => {
              window.TCE_GLOBAL_CONSTANT_ASYNC = {
                ...window.TCE_GLOBAL_CONSTANT_ASYNC,
                sdk: { ...window.TCE_GLOBAL_CONSTANT_ASYNC?.sdk, [name]: module },
              };
              resolve();
            });
          });
        }
      })();
      loadingMap.set(name as string, loadPromise);
    }
    try {
      await loadingMap.get(name as string);
    } catch (error) {
      throw new TceSDKException(`load ${name} failed`);
    } finally {
      loadingMap.delete(name as string);
    }
  }

  return (libraryName && window[libraryName]) || window.TCE_GLOBAL_CONSTANT_ASYNC.sdk![name as keyof ComponentType];
}
