import { getComponent } from '../component';

export async function getCAM() {
  return getComponent('cam-sdk');
}
