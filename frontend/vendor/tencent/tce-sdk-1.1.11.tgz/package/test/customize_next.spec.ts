import * as tcesdk from '../src';
import { g_config_data } from './mock/config_next';

describe('tcesdk-config-next', () => {
  before(() => {
    window.g_config_data = g_config_data;
  });

  afterEach(() => {});

  it('tcesdk-config-getCustomizeAccessTabs', () => {
    const customizeAccessTabs = tcesdk.config.getCustomizeAccessTabs();
    expect(customizeAccessTabs.length).equal(2);
    expect(customizeAccessTabs[0].display).equal('left');
    expect(customizeAccessTabs[0].visible).equal(true);
    expect(customizeAccessTabs[0].name).equal('集群管理');
    expect(customizeAccessTabs[0].code).equal('tab_cluster_management');
    expect(customizeAccessTabs[0].types.length).equal(5);
    expect(customizeAccessTabs[0].types[0].icon).equal('default_product_type.svg');
    expect(customizeAccessTabs[0].types[0].iconActive).equal('default_product_type_hover.svg');
    expect(customizeAccessTabs[0].types[0].modules.length).equal(1);
    expect(customizeAccessTabs[0].types[0].modules[0].icon).equal('default_product_type.svg');
    expect(customizeAccessTabs[0].types[0].modules[0].iconActive).equal('default_product_type_hover.svg');
    expect(customizeAccessTabs[0].types[0].modules[0].groupName).equal('集群管理分组');
  });
});
