export const generateSignData = {
  appId: 1648748312136,
  platform: 'ocloud',
  module: 'content',
  timestamp: 1649762371584,
  nonce: '16497576842',
};

const fd = new FormData();
fd.append('file', '3214214');

export const uploadParam = {
  appId: '1648748312136',
  appKey: 'abcdefghijk',
  module: 'content',
  file: fd,
};
