import * as tcesdk from '../src';
import sinon from 'sinon';
import { generateSignStr, getCryptoJsUrl, getCurrentPlatformForFile, getFileServerUrl } from 'src/file/helper';
import * as file from './mock/file';
import { PLATFORM_TYPE } from 'src/common';
import { AXIOS } from 'src/constants';
import * as QS from 'qs';

describe('tcesdk-file', () => {
  before(() => {
    // 在本区块的所有测试用例之前执行
  });

  after(() => {
    // 在本区块的所有测试用例之后执行
  });

  beforeEach(() => {
    // 在本区块的每个测试用例之前执行
    (window as any).TCE_GLOBAL_CONSTANT = {
      baseHost: 'tet.com',
      consoleHost: 'o.test.com',
      imgcacheHost: 'imgcache.tcenter-dev-3100.tcecloud.fsphere.cn',
    };
  });

  afterEach(() => {
    // 在本区块的每个测试用例之后执行
  });

  it('file-helper-generateSignStr-参数正常', async () => {
    const data = file.generateSignData;
    const signStr = generateSignStr(data);
    expect(signStr).to.equal(
      'appId=1648748312136&module=content&nonce=16497576842&platform=ocloud&timestamp=1649762371584',
    );
  });

  it('file-helper-generateSignStr-部分key值为空', async () => {
    const data = { ...file.generateSignData, test: '' };
    const signStr = generateSignStr(data);
    expect(signStr).to.equal(
      'appId=1648748312136&module=content&nonce=16497576842&platform=ocloud&timestamp=1649762371584',
    );
  });

  it('file-helper-getCurrentPlatformForFile-ocloud', async () => {
    (window as any).TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_OCLOUD,
    };
    const currentFilePlatform = getCurrentPlatformForFile();
    expect(currentFilePlatform).to.equal('ocloud');
  });

  it('file-helper-getCurrentPlatformForFile-tcloud', async () => {
    (window as any).TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD,
    };
    const currentFilePlatform = getCurrentPlatformForFile();
    expect(currentFilePlatform).to.equal('tcloud');
  });

  it('file-helper-getCurrentPlatformForFile-tcs', async () => {
    (window as any).TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCS_OCLOUD,
    };
    const currentFilePlatform = getCurrentPlatformForFile();
    expect(currentFilePlatform).to.equal('ocloud');
  });

  it('file-helper-getCurrentPlatformForFile-空', async () => {
    const currentFilePlatform = getCurrentPlatformForFile();
    expect(currentFilePlatform).to.equal('');
  });

  it('file-helper-getFileServerUrl-空', async () => {
    const fileServerUrl = getFileServerUrl();
    expect(fileServerUrl).to.equal('');
  });

  it('file-helper-getFileServerUrl-ocloud', async () => {
    (window as any).TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_OCLOUD;
    const fileServerUrl = getFileServerUrl();
    expect(fileServerUrl).to.equal('//file.tet.com');
  });

  it('file-helper-getFileServerUrl-tcloud', async () => {
    (window as any).TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_OCLOUD;
    const fileServerUrl = getFileServerUrl();
    expect(fileServerUrl).to.equal('//file.tet.com');
  });

  it('file-helper-getCurrentPlatformForFile-tcs', () => {
    (window as any).TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCS_OCLOUD;
    const serverUrl = getFileServerUrl();
    expect(serverUrl).to.equal('//file.o.test.com');
  });

  it('file-helper-getCryptoJsUrl', async () => {
    (window as any).TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_OCLOUD;
    const cryptoJsUrl = getCryptoJsUrl();
    expect(cryptoJsUrl).to.equal(
      '//imgcache.tcenter-dev-3100.tcecloud.fsphere.cn/common/tcesdk/assets/crypto-js/crypto-js.min.js',
    );
  });

  it('file-upload-参数缺失', async () => {
    (window as any).TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_OCLOUD;
    try {
      // @ts-ignore
      await tcesdk.file.upload();
    } catch (error: any) {
      expect(error.message).to.eql('appId、module can not empty');
    }
  });

  it('file-upload-参数缺失-module', async () => {
    (window as any).TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_OCLOUD;
    try {
      // @ts-ignore
      await tcesdk.file.upload({ appId: '123' });
    } catch (error: any) {
      expect(error.message).to.eql('appId、module can not empty');
    }
  });

  it('file-upload-参数缺失-file', async () => {
    (window as any).TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_OCLOUD;
    try {
      // @ts-ignore
      await tcesdk.file.upload({
        appId: '123',
        module: '21312',
      });
    } catch (error: any) {
      expect(error.message).to.eql('file can not empty');
    }
  });

  it('file-upload-code不为0-出参不包含data', async () => {
    (window as any).TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_OCLOUD;
    const data = {
      code: 'InvalidRequest.MissingParameters',
      msg: 'file can not empty',
      requestId: '4597ad07df0e15b5524a480d133e14e2',
    };
    const postStub = sinon.stub().resolves({
      data,
    });
    // @ts-ignore
    const axiosStub = sinon.stub(AXIOS, 'create').returns({ post: postStub });
    const res = await tcesdk.file.upload(file.uploadParam);
    expect(res.err).to.deep.equal({
      code: 'InvalidRequest.MissingParameters',
      message: 'file can not empty',
      requestId: '4597ad07df0e15b5524a480d133e14e2',
    });
    axiosStub.restore();
  });

  it('file-upload-code不为0-出参包含data', async () => {
    (window as any).TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_OCLOUD;
    const data = {
      code: 'InvalidRequest.MissingParameters',
      msg: 'file can not empty',
      requestId: '4597ad07df0e15b5524a480d133e14e2',
      data: { test: '2314231423' },
    };
    const postStub = sinon.stub().resolves({
      data,
    });
    // @ts-ignore
    const axiosStub = sinon.stub(AXIOS, 'create').returns({ post: postStub });
    const res = await tcesdk.file.upload(file.uploadParam);
    expect(res.err).to.deep.equal({
      code: 'InvalidRequest.MissingParameters',
      message: 'file can not empty',
      requestId: '4597ad07df0e15b5524a480d133e14e2',
      data: { test: '2314231423' },
    });
    axiosStub.restore();
  });

  it('file-upload-code为0', async () => {
    (window as any).TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_OCLOUD;
    const data = {
      code: '0',
      msg: '',
      requestId: '4597ad07df0e15b5524a480d133e14e2',
      data: { url: '//file.test.com/a.png' },
    };
    const postStub = sinon.stub().resolves({
      data,
    });
    // @ts-ignore
    const axiosStub = sinon.stub(AXIOS, 'create').returns({ post: postStub });
    const resp = await tcesdk.file.upload(file.uploadParam);
    expect(resp.res).to.deep.equal({ url: '//file.test.com/a.png' });
    axiosStub.restore();
  });

  it('file-getUploadUrl-入参为空', async () => {
    try {
      // @ts-ignore
      tcesdk.file.getUploadUrl();
    } catch (error: any) {
      expect(error.message).to.eql('appId、module can not empty');
    }
  });

  it('file-getUploadUrl-正常返回', async () => {
    (window as any).TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_OCLOUD;
    const uploadUrl = tcesdk.file.getUploadUrl({
      appId: 'test',
      module: 'test',
    });
    const [url, queryString] = uploadUrl.split('?');
    const query = QS.parse(queryString);
    const { nonce, timestamp, ...rest } = query;
    expect(url).to.equal('//file.tet.com/public/api/upload');
    expect(query).to.be.haveOwnProperty('nonce');
    expect(query).to.be.haveOwnProperty('timestamp');
    expect(rest).to.deep.equal({
      appId: 'test',
      module: 'test',
      platform: 'ocloud',
    });
  });

  it('file-getUploadUrl-增加filename字段-正常返回', async () => {
    (window as any).TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_OCLOUD;
    const uploadUrl = tcesdk.file.getUploadUrl({
      appId: 'test',
      module: 'test',
      fileName: 'test.png',
    });
    const [url, queryString] = uploadUrl.split('?');
    const query = QS.parse(queryString);
    const { nonce, timestamp, ...rest } = query;
    expect(url).to.equal('//file.tet.com/public/api/upload');
    expect(query).to.be.haveOwnProperty('nonce');
    expect(query).to.be.haveOwnProperty('timestamp');
    expect(rest).to.deep.equal({
      appId: 'test',
      module: 'test',
      platform: 'ocloud',
      fileName: 'test.png',
    });
  });
});
