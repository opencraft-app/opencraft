import { expect } from 'chai';
import * as tcesdk from '../src';

describe('tcesdk-domain', () => {
  beforeEach(() => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud',
      loginHost: 'tcenter-dev.tcecqpoc.fsphere.cn',
      baseHost: 'tcenter-dev.tcecqpoc.fsphere.cn',
      officialWebsiteHost: 'tcenter-dev.tcecqpoc.fsphere.cn',
      buyHost: 'buy.tcenter-dev.tcecqpoc.fsphere.cn',
      imgcacheHost: 'imgcache.tcenter-dev.tcecqpoc.fsphere.cn',
      cspDomain: 'csp.tcenter-dev.tcecqpoc.fsphere.cn',
      cosDomain: 'cos.tcenter-dev.tcecqpoc.fsphere.cn',
      tenantConsoleDomain: 'console.tcenter-dev.tcecqpoc.fsphere.cn',
      qcbaseHost: 'iaas.tcenter-dev.tcecqpoc.fsphere.cn',
      consoleHost: 'console.tcenter-dev.tcecqpoc.fsphere.cn',
      yapiUrl: '//oapi.tcenter-dev.tcecqpoc.fsphere.cn/capi/v3',
    };
  });

  // 在有参数的情况下
  it('getAllDomain-params', () => {
    const allDomian = tcesdk.domain.getDomainList();
    expect(allDomian.base).equal('tcenter-dev.tcecqpoc.fsphere.cn');
    expect(allDomian.login).equal('tcenter-dev.tcecqpoc.fsphere.cn');
    expect(allDomian.officialWebsite).equal('tcenter-dev.tcecqpoc.fsphere.cn');
    expect(allDomian.buy).equal('buy.tcenter-dev.tcecqpoc.fsphere.cn');
    expect(allDomian.imgcache).equal('imgcache.tcenter-dev.tcecqpoc.fsphere.cn');
    expect(allDomian.csp).equal('csp.tcenter-dev.tcecqpoc.fsphere.cn');
    expect(allDomian.cos).equal('cos.tcenter-dev.tcecqpoc.fsphere.cn');
    expect(allDomian.tenantConsole).equal('console.tcenter-dev.tcecqpoc.fsphere.cn');
    expect(allDomian.qcbase).equal('iaas.tcenter-dev.tcecqpoc.fsphere.cn');
    expect(allDomian.console).equal('console.tcenter-dev.tcecqpoc.fsphere.cn');
    expect(allDomian.yapiUrl).equal('//oapi.tcenter-dev.tcecqpoc.fsphere.cn/capi/v3');
    expect(allDomian.doc).equal('doc.tcenter-dev.tcecqpoc.fsphere.cn');
  });

  // 在有参数的情况下
  it('getAllDomain-null', () => {
    window.TCE_GLOBAL_CONSTANT = undefined as any;
    const allDomian = tcesdk.domain.getDomainList();
    expect(allDomian.login).equal(undefined);
  });

  it('getAllDomain-运营端登陆页获取doc地址为document开头', () => {
    window.TCE_GLOBAL_CONSTANT.platformType = 'tce_ocloud_login';
    const allDomian = tcesdk.domain.getDomainList();
    expect(allDomian.doc).equal('document.tcenter-dev.tcecqpoc.fsphere.cn');
  });

  it('getAllDomain-运营端控制台获取doc地址为document开头', () => {
    window.TCE_GLOBAL_CONSTANT.platformType = 'tce_ocloud';
    const allDomian = tcesdk.domain.getDomainList();
    expect(allDomian.doc).equal('document.tcenter-dev.tcecqpoc.fsphere.cn');
  });

  it('replaceDomainInStr.都有值', () => {
    window.TCE_GLOBAL_CONSTANT.innerMainDomain = 'tcecqpoc.fsphere.cn'; // 内部
    window.TCE_GLOBAL_CONSTANT.baseHost = 'tcecqpoc-3100.fsphere.cn'; // 页面
    const allDomian = tcesdk.domain.replaceDomainInStr('tcenter-dev.tcecqpoc.fsphere.cn');
    expect(allDomian).equal('tcenter-dev.tcecqpoc-3100.fsphere.cn');
  });
  it('replaceDomainInStr.有值-innerMainDomain', () => {
    window.TCE_GLOBAL_CONSTANT.innerMainDomain = 'tcecqpoc.fsphere.cn';
    window.TCE_GLOBAL_CONSTANT.baseHost = '';
    const allDomian = tcesdk.domain.replaceDomainInStr('tcenter-dev.tcecqpoc.fsphere.cn');
    expect(allDomian).equal('tcenter-dev.tcecqpoc.fsphere.cn');
  });
  it('replaceDomainInStr.有值-baseHost', () => {
    window.TCE_GLOBAL_CONSTANT.innerMainDomain = '';
    window.TCE_GLOBAL_CONSTANT.baseHost = 'tcecqpoc-3100.fsphere.cn';
    const allDomian = tcesdk.domain.replaceDomainInStr('tcenter-dev.tcecqpoc.fsphere.cn');
    expect(allDomian).equal('tcenter-dev.tcecqpoc.fsphere.cn');
  });
  it('replaceDomainInStr.数组-innerMainDomain', () => {
    window.TCE_GLOBAL_CONSTANT.innerMainDomain = ['yf-380.tcecloud.fsphere.cn', 'yf-000.tcecloud.fsphere.cn'];
    window.TCE_GLOBAL_CONSTANT.baseHost = 'aaa';
    const allDomian = tcesdk.domain.replaceDomainInStr('yf-380.tcecloud.fsphere.cn,yf-000.tcecloud.fsphere.cn');
    expect(allDomian).equal('aaa,aaa');
  });
  it('replaceDomainInStr.有baseHost没有inner值-innerMainDomain', () => {
    window.TCE_GLOBAL_CONSTANT.innerMainDomain = undefined;
    window.TCE_GLOBAL_CONSTANT.baseHost = 'aaa';
    const allDomian = tcesdk.domain.replaceDomainInStr('tcenter-dev.tcecqpoc.fsphere.cn,tcecqpoc.fsphere.cn');
    expect(allDomian).equal('tcenter-dev.tcecqpoc.fsphere.cn,tcecqpoc.fsphere.cn');
  });
  it('replaceDomainInStr.innerMainDomain不为数字或数组', () => {
    // @ts-ignore
    window.TCE_GLOBAL_CONSTANT.innerMainDomain = 1;
    window.TCE_GLOBAL_CONSTANT.baseHost = 'aaa';
    const allDomian = tcesdk.domain.replaceDomainInStr('tcenter-dev.tcecqpoc.fsphere.cn,tcecqpoc.fsphere.cn');
    expect(allDomian).equal('tcenter-dev.tcecqpoc.fsphere.cn,tcecqpoc.fsphere.cn');
  });
  it('replaceDomainInStr.无值', () => {
    window.TCE_GLOBAL_CONSTANT = undefined as any;
    const allDomian = tcesdk.domain.replaceDomainInStr('tcenter-dev.tcecqpoc.fsphere.cn');
    expect(allDomian).equal('tcenter-dev.tcecqpoc.fsphere.cn');
  });
});
