import { expect } from 'chai';
import * as tcesdk from '../src';
import { PLATFORM_TYPE } from 'src/platform';
import sinon from 'sinon';
import { yApiAxios } from '../src/api/yApiAxios';
import {
  currentUserRelatedPolices,
  currentUserRelatedPolices_error,
  ownerUserInfo,
  subAccountUserInfo,
} from './mock/user';
import { AXIOS } from 'src/constants';

describe('tcesdk-user', () => {
  let axiosInsStub: sinon.SinonStub;

  before(() => {
    axiosInsStub = sinon.stub(yApiAxios, 'post');
    tcesdk.constants.JS_COOKIE.set('user_uin', '100500000037');
    tcesdk.constants.JS_COOKIE.set('user_id', 'yaweihuang');
    tcesdk.constants.JS_COOKIE.set('owner_uin', '909619400');
    tcesdk.constants.JS_COOKIE.set('lusername', 'strong');
    tcesdk.constants.JS_COOKIE.set('camusername', 'stronghuang');
    tcesdk.constants.JS_COOKIE.set('uin', 'o100004603012');
    tcesdk.constants.JS_COOKIE.set('ownerUin', 'O100004603012G');
    window.TCS = {
      currentUserInfo: {
        ownerUin: 909619400,
        uin: '909622052',
        account: '909619400_tceadmin',
        mail: 'tc*****@tce.com',
        name: 'TCECMGT',
        nickname: 'tceadmin',
        countryCode: '86',
        tel: '137****5775',
        collName: 'tceadmin',
        collTel: '137****5775',
        collMail: 'tce****@tce.com',
        userType: 'subaccount',
      },
    };
  });

  it('getCurrentUserInfo-ocloud', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_OCLOUD,
    };
    const userInfo = tcesdk.user.getCurrentUserInfo();
    expect(userInfo?.ownerUin).equal('909619400');
    expect(userInfo?.userUin).equal('100500000037');
    expect(userInfo?.userName).equal('yaweihuang');
  });

  it('getCurrentUserInfo-tcloud', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD,
    };
    const userInfo = tcesdk.user.getCurrentUserInfo();
    expect(userInfo?.ownerUin).equal('100004603012');
    expect(userInfo?.userUin).equal('100004603012');
    expect(userInfo?.userName).equal('strong');
  });

  it('getCurrentUserInfo-tcloud-buy', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD_BUY,
    };
    const userInfo = tcesdk.user.getCurrentUserInfo();
    expect(userInfo?.ownerUin).equal('100004603012');
    expect(userInfo?.userUin).equal('100004603012');
    expect(userInfo?.userName).equal('strong');
  });

  it('getCurrentUserInfo-tcloud-buy-sub', () => {
    tcesdk.constants.JS_COOKIE.set('uin', 'o100004603011');
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD_BUY,
    };
    const userInfo = tcesdk.user.getCurrentUserInfo();
    expect(userInfo?.ownerUin).equal('100004603012');
    expect(userInfo?.userUin).equal('100004603011');
    expect(userInfo?.userName).equal('stronghuang');
    tcesdk.constants.JS_COOKIE.set('uin', 'o100004603012');
  });

  it('getCurrentUserInfo-tcs', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCS_OCLOUD,
    };
    const userInfo = tcesdk.user.getCurrentUserInfo();
    expect(userInfo?.ownerUin).equal('909619400');
    expect(userInfo?.userUin).equal('909622052');
    expect(userInfo?.userName).equal('tceadmin');
  });

  it('getCurrentUserInfo-platform-null', () => {
    window.TCE_GLOBAL_CONSTANT = undefined as any;
    const userInfo = tcesdk.user.getCurrentUserInfo();
    expect(userInfo?.ownerUin).equal(undefined);
  });

  it('getCurrentUserInfo-cookie-null', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD,
    };
    tcesdk.constants.JS_COOKIE.remove('ownerUin');
    tcesdk.constants.JS_COOKIE.remove('uin');
    const userInfo = tcesdk.user.getCurrentUserInfo();
    expect(userInfo?.ownerUin).equal('');
  });

  it('getCurrentUserInfo-tcs-null', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCS_OCLOUD,
    };
    window.TCS = undefined;
    const userInfo = tcesdk.user.getCurrentUserInfo();
    expect(userInfo?.ownerUin).equal('');
  });

  it('getCurrentUserInfoAsync-subaccount', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD,
    };
    const axiosRes = subAccountUserInfo;
    axiosInsStub.resolves(axiosRes);
    const userInfo = await tcesdk.user.getCurrentUserInfoAsync();
    expect(userInfo?.userUin).equal('100500000183');
  });

  it('getCurrentUserInfoAsync-owner', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD,
    };
    const axiosRes = ownerUserInfo;
    axiosInsStub.resolves(axiosRes);
    const userInfo = await tcesdk.user.getCurrentUserInfoAsync();
    expect(userInfo?.userUin).equal('909619400');
  });

  it('getCurrentUserRelatedPolices-正常情况', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_OCLOUD,
    };
    const axiosRes = currentUserRelatedPolices;
    axiosInsStub.resolves(axiosRes);
    const polices = await tcesdk.user.getCurrentUserRelatedPolicies();
    expect(polices.length).equal(5);
    expect(polices[0]).equal('AdministratorAccess');
  });

  it('getCurrentUserRelatedPolices-异常情况', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_OCLOUD,
    };
    const axiosRes = currentUserRelatedPolices_error;
    axiosInsStub.resolves(axiosRes);
    const polices = await tcesdk.user.getCurrentUserRelatedPolicies();
    expect(polices.length).equal(0);
  });

  it('checkCurrentUserIsAdmin-正常情况', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_OCLOUD,
    };
    const axiosRes = currentUserRelatedPolices;
    axiosInsStub.resolves(axiosRes);
    const isAdmin = await tcesdk.user.checkCurrentUserIsAdmin();
    expect(isAdmin).equal(true);
  });

  it('checkCurrentUserIsAdmin-异常情况', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_OCLOUD,
    };
    const axiosRes = currentUserRelatedPolices_error;
    axiosInsStub.resolves(axiosRes);
    const isAdmin = await tcesdk.user.checkCurrentUserIsAdmin();
    expect(isAdmin).equal(false);
  });

  it('hasWhiteListForMultiKey-正常情况-租户端控制台', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD,
    };
    const respJson = {
      code: 0,
      msg: 'ok',
      data: { LB_SZJR_WHITELIST: ['100004603084'] },
    };
    const respStub = sinon.stub().resolves({
      data: respJson,
    });
    // @ts-ignore
    const axiosStub = sinon.stub(AXIOS, 'create').returns({ post: respStub });
    const whiteList = await tcesdk.user.hasWhiteListForMultiKey(['LB_SZJR_WHITELIST', 'LB_SZJR_WHITELIST123']);
    expect(whiteList.LB_SZJR_WHITELIST).to.deep.equal({ result: true, oriData: ['100004603084'] });
    expect(whiteList.LB_SZJR_WHITELIST123).to.deep.equal({ result: false, oriData: [] });
    axiosStub.restore();
  });

  it('hasWhiteListForMultiKey-失败情况-租户端控制台', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD,
    };
    const respJson = {
      code: -1,
      msg: 'ok',
      data: { LB_SZJR_WHITELIST: ['100004603084'] },
    };
    const respStub = sinon.stub().resolves({
      data: respJson,
    });
    // @ts-ignore
    const axiosStub = sinon.stub(AXIOS, 'create').returns({ post: respStub });
    const whiteList = await tcesdk.user.hasWhiteListForMultiKey(['LB_SZJR_WHITELIST', 'LB_SZJR_WHITELIST123']);
    expect(whiteList).to.deep.equal({});
    axiosStub.restore();
  });

  it('hasWhiteListForMultiKey-正常情况-租户端购买页', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD_BUY,
    };
    const respJson = {
      code: 0,
      msg: 'ok',
      data: { LB_SZJR_WHITELIST: ['100004603084'] },
    };
    const respStub = sinon.stub().resolves({
      data: respJson,
    });
    // @ts-ignore
    const axiosStub = sinon.stub(AXIOS, 'create').returns({ post: respStub });
    const whiteList = await tcesdk.user.hasWhiteListForMultiKey(['LB_SZJR_WHITELIST', 'LB_SZJR_WHITELIST123']);
    expect(whiteList.LB_SZJR_WHITELIST).to.deep.equal({ result: true, oriData: ['100004603084'] });
    expect(whiteList.LB_SZJR_WHITELIST123).to.deep.equal({ result: false, oriData: [] });
    axiosStub.restore();
  });

  it('hasWhiteList-正常情况-租户端控制台', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD,
    };
    const respJson = {
      code: 0,
      msg: 'ok',
      data: { LB_SZJR_WHITELIST: ['100004603084'] },
    };
    const respStub = sinon.stub().resolves({
      data: respJson,
    });
    // @ts-ignore
    const axiosStub = sinon.stub(AXIOS, 'create').returns({ post: respStub });
    const isHas = await tcesdk.user.hasWhiteList('LB_SZJR_WHITELIST');
    expect(isHas).to.equal(true);
    axiosStub.restore();
  });

  it('hasWhiteList-异常情况-租户端控制台', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_OCLOUD,
    };
    const respJson = {
      code: 0,
      msg: 'ok',
      data: { LB_SZJR_WHITELIST: ['100004603084'] },
    };
    const respStub = sinon.stub().resolves({
      data: respJson,
    });
    // @ts-ignore
    const axiosStub = sinon.stub(AXIOS, 'create').returns({ post: respStub });
    const isHas = await tcesdk.user.hasWhiteList('LB_SZJR_WHITELIST');
    expect(isHas).to.equal(false);
    axiosStub.restore();
  });
});
