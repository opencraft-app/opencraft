/* eslint-disable @typescript-eslint/no-unused-expressions */
import { expect } from 'chai';
import * as tcesdk from '../src';
import sinon from 'sinon';
// @ts-ignore
import { checkProductDeliver, getDeliverProductList, PLATFORM_TYPE, rewire$getDeliverProductList } from 'src/platform';
import { AXIOS } from 'src/constants';
import { g_config_data_tcloud, g_config_data_tcloud_buy } from './mock/config';
import { loc } from 'src/common';
// @ts-ignore
import { rewire$yApiRequest, restore } from 'src/api';
import {
  getCommonVersionPath,
  getOverviewVersionPath,
  getDeliverProductListCache,
  setDeliverProductListCache,
  clearDeliverProductListCache,
} from 'src/platform/helper';

describe('tcesdk-platform', () => {
  let setTimeoutStub: sinon.SinonStub;
  let yApiRequestStub: sinon.SinonStub;
  let getDeliverProductListStub: sinon.SinonStub;

  beforeEach(() => {
    (window as any).TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_OCLOUD,
      imgcacheHost: 'imgcache.tcenter-dev.tcecqpoc.fsphere.cn',
      consoleHost: 'console.tcenter-dev.tcecqpoc.fsphere.cn',
      title: {
        'en-US': 'TCenter_TCE380',
        'zh-CN': '公有云_TCenter_TCE380_开发环境',
      },
    };
    window.g_config_data = {
      isCustomizeNext: false,
    };
    (window as any).customizeVersion = '2';
    setTimeoutStub = sinon.stub(window, 'setTimeout');
    window.I18N_CONFIG = {
      title: {
        title: '重庆_YF_M16_350',
        'title_zh-CN': '重庆_YF_M16_350',
        'title_en-US': 'TCE',
      },
    };
  });

  afterEach(() => {
    // 清除所有的缓存，确保每个测试用例之间没有副作用
    clearDeliverProductListCache();
    setTimeoutStub.restore();
    if (yApiRequestStub && typeof yApiRequestStub.restore === 'function') {
      yApiRequestStub.restore();
    }
    if (getDeliverProductListStub && typeof getDeliverProductListStub.restore === 'function') {
      getDeliverProductListStub.restore();
    }
  });

  it('getCurrentPlatform', () => {
    const platformType = tcesdk.platform.getCurrentPlatform();
    expect(platformType).equal(PLATFORM_TYPE.TCE_OCLOUD);
  });

  it('getCurrentPlatform-null', () => {
    (window as any).TCE_GLOBAL_CONSTANT = undefined;
    const platformType = tcesdk.platform.getCurrentPlatform();
    expect(platformType).equal(undefined);
  });

  it('getCustomizeVersion', () => {
    const version = tcesdk.platform.getCustomizeVersion();
    expect(version).equal('2');
  });

  it('toLoginPageForExpired', () => {
    const reload = sinon.stub(loc, 'locationReload').returns();
    tcesdk.platform.toLoginPageForExpired();
    reload.restore();
  });

  it('logout-TceTcloud', () => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_TCLOUD;
    tcesdk.platform.logout();
  });

  // 这个测试用例也是一个卡点，源代码中是直接axios.create创建了一个axios实例来请求，所以导致无法stub其axios请求
  // 这里是stub的axios的create的返回值，再通过stub的返回值来控制后续源代码的逻辑分支
  it("logout-TceOcloud-res中code为'0'", () => {
    window.onbeforeunload = sinon.spy();
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_OCLOUD;
    const postStub = sinon.stub().resolves({ data: { code: '0' } });
    // @ts-ignore
    const axiosStub = sinon.stub(AXIOS, 'create').returns({ post: postStub });
    sinon.stub(loc, 'setLocationHref').returns();
    tcesdk.platform.logout();
    axiosStub.restore();
  });

  it('logout-TceOcloud-res中code不为0且无message', () => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_OCLOUD;
    const postStub = sinon.stub().resolves();
    // @ts-ignore
    const axiosStub = sinon.stub(AXIOS, 'create').returns({ post: postStub });
    const logoutSpy = sinon.spy(tcesdk.platform.logout);
    try {
      logoutSpy();
    } catch (err) {
      expect(logoutSpy).have.been.throw();
    }
    axiosStub.restore();
  });

  it('logout-TceOcloud-res中code不为0且有message', () => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_OCLOUD;
    const postStub = sinon.stub().resolves({ res: { data: { message: 'error' } } });
    // @ts-ignore
    const axiosStub = sinon.stub(AXIOS, 'create').returns({ post: postStub });
    const logoutSpy = sinon.spy(tcesdk.platform.logout);
    try {
      logoutSpy();
    } catch (err) {
      expect(logoutSpy).have.been.throw('error');
    }
    axiosStub.restore();
  });

  it("logout-TceTcloud-res中code为'0'", () => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_TCLOUD;
    const getStub = sinon.stub().resolves({ data: { code: '0' } });
    // @ts-ignore
    const axiosStub = sinon.stub(AXIOS, 'create').returns({ get: getStub });
    sinon.stub(loc, 'locationReload').returns();
    tcesdk.platform.logout();
    axiosStub.restore();
  });

  it('logout-TceTcloud-res中code不为0且无message', () => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_TCLOUD;
    const getStub = sinon.stub().resolves();
    // @ts-ignore
    const axiosStub = sinon.stub(AXIOS, 'create').returns({ get: getStub });
    const logoutSpy = sinon.spy(tcesdk.platform.logout);
    try {
      logoutSpy();
    } catch (err) {
      expect(logoutSpy).have.been.throw();
    }
    axiosStub.restore();
  });

  it('logout-TceTcloud-res中code不为0且有message', () => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_TCLOUD;
    const getStub = sinon.stub().resolves({ res: { data: { message: 'error' } } });
    // @ts-ignore
    const axiosStub = sinon.stub(AXIOS, 'create').returns({ get: getStub });
    const logoutSpy = sinon.spy(tcesdk.platform.logout);
    try {
      logoutSpy();
    } catch (err) {
      expect(logoutSpy).have.been.throw('error');
    }
    axiosStub.restore();
  });

  it('logout-undefined', () => {
    window.TCE_GLOBAL_CONSTANT.platformType = undefined;
    const logoutSpy = sinon.spy(tcesdk.platform.logout);
    try {
      logoutSpy();
    } catch (err) {
      expect(logoutSpy).have.throw();
    }
  });

  it('获取平台logo', () => {
    const customizeLogo = tcesdk.platform.getCustomizeLogo();
    expect(customizeLogo.favicon).equal('//imgcache.tcenter-dev.tcecqpoc.fsphere.cn/customize/cache/img/favicon.ico');
    expect(customizeLogo.mainLogo).equal(
      '//imgcache.tcenter-dev.tcecqpoc.fsphere.cn/customize/cache/img/ops-cmgt-nav-logo.svg',
    );
  });

  it('获取平台logo-tcs控制台', () => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCS_OCLOUD;
    const customizeLogo = tcesdk.platform.getCustomizeLogo();
    expect(customizeLogo.favicon).equal('//console.tcenter-dev.tcecqpoc.fsphere.cn/favicon.ico');
    expect(customizeLogo.mainLogo).equal('//console.tcenter-dev.tcecqpoc.fsphere.cn/logo.png');
  });

  it('获取平台logo-tcs登录', () => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCS_OCLOUD_LOGIN;
    const customizeLogo = tcesdk.platform.getCustomizeLogo();
    expect(customizeLogo.favicon).equal('//console.tcenter-dev.tcecqpoc.fsphere.cn/favicon.ico');
    expect(customizeLogo.mainLogo).equal('//console.tcenter-dev.tcecqpoc.fsphere.cn/logo.png');
  });

  it('获取平台logo-客制化next场景', () => {
    window.g_config_data.isCustomizeNext = true;
    const customizeLogo = tcesdk.platform.getCustomizeLogo();
    expect(customizeLogo.favicon).equal('//console.tcenter-dev.tcecqpoc.fsphere.cn/favicon.ico');
    expect(customizeLogo.mainLogo).equal('//console.tcenter-dev.tcecqpoc.fsphere.cn/logo.png');
  });

  it('获取平台logo-g_config_data为空', () => {
    window.g_config_data = undefined;
    const customizeLogo = tcesdk.platform.getCustomizeLogo();
    expect(customizeLogo.favicon).equal('//imgcache.tcenter-dev.tcecqpoc.fsphere.cn/customize/cache/img/favicon.ico');
    expect(customizeLogo.mainLogo).equal(
      '//imgcache.tcenter-dev.tcecqpoc.fsphere.cn/customize/cache/img/ops-cmgt-nav-logo.svg',
    );
  });

  it('获取平台title信息-控制台正常情况-中文', () => {
    tcesdk.constants.JS_COOKIE.set('tce_language', 'zh-CN');
    const title = tcesdk.platform.getCustomizeTitle();
    expect(title).equal('重庆_YF_M16_350');
  });

  it('获取平台title信息-控制台正常情况-英文', () => {
    tcesdk.constants.JS_COOKIE.set('tce_language', 'en-US');
    const title = tcesdk.platform.getCustomizeTitle();
    expect(title).equal('TCE');
  });

  it('获取平台title信息-其他页面正常情况-中文', () => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_TCLOUD_LOGIN;
    tcesdk.constants.JS_COOKIE.set('tce_language', 'zh-CN');
    const title = tcesdk.platform.getCustomizeTitle();
    expect(title).equal('公有云_TCenter_TCE380_开发环境');
  });

  it('获取平台title信息-其他页面正常情况-英文', () => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_TCLOUD_LOGIN;
    tcesdk.constants.JS_COOKIE.set('tce_language', 'en-US');
    const title = tcesdk.platform.getCustomizeTitle();
    expect(title).equal('TCenter_TCE380');
  });

  it('获取平台title信息-控制台异常情况-I18N_CONFIG为空', () => {
    window.I18N_CONFIG = undefined;
    const title = tcesdk.platform.getCustomizeTitle();
    expect(title).equal('');
  });

  it('获取平台title信息-控制台异常情况-I18N_CONFIG及TCE_GLOBAL_CONSTANT.title为{}', () => {
    window.I18N_CONFIG.title = { 'zh-HK': '' };
    window.TCE_GLOBAL_CONSTANT.title = {};
    const title = tcesdk.platform.getCustomizeTitle();
    expect(title).equal('');
  });

  it('获取平台title信息-控制台异常情况-I18N_CONFIG内title为空', () => {
    window.I18N_CONFIG = {
      title: undefined,
    };
    const title = tcesdk.platform.getCustomizeTitle();
    expect(title).equal('');
  });

  it('获取平台title信息-其他页面异常情况-I18N_CONFIG为空', () => {
    window.TCE_GLOBAL_CONSTANT = undefined as any;
    const title = tcesdk.platform.getCustomizeTitle();
    expect(title).equal('');
  });

  it('获取平台title信息-其他页异常情况-I18N_CONFIG内title为空', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD_LOGIN,
    };
    const title = tcesdk.platform.getCustomizeTitle();
    expect(title).equal('');
  });

  it('getFrontendComponentInfo-获取前端组件信息', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD,
    };
    window.g_config_data = g_config_data_tcloud;
    const respJson = {
      buildTime: '2021-11-04 10:46:40',
      productName: 'product-frontend-imgcache-tcloud-cam',
      commitId: '8ed95db',
      deployTime: '2021-11-04 10:48:16',
      branch: 'release/tce3.10.0',
    };
    const respStub = sinon.stub().resolves({
      data: respJson,
    });
    // @ts-ignore
    const axiosStub = sinon.stub(AXIOS, 'create').returns({ get: respStub });
    const productInfo = await tcesdk.platform.getFrontendComponentInfo('/cam/settings');
    const { pageAccessInfo, ...rest } = productInfo || {};
    expect(rest).to.be.deep.equal(respJson);
    axiosStub.restore();
  });

  it('getFrontendComponentInfo-获取前端组件信息--通用组件', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD,
    };
    window.g_config_data = g_config_data_tcloud;
    const respJson = {
      commitId: 'd222ff5',
      buildTime: '2022-03-02 15:51:13',
      deployTime: '2022-03-03 11:01:48',
      branch: 'master',
      productName: 'product-frontend-imgcache-common-tcesdk',
    };
    const respStub = sinon.stub().resolves({
      data: respJson,
    });
    // @ts-ignore
    const axiosStub = sinon.stub(AXIOS, 'create').returns({ get: respStub });
    const productInfo = await tcesdk.platform.getFrontendComponentInfo('tcesdk');
    expect(productInfo).to.be.deep.equal(respJson);
    axiosStub.restore();
  });

  it('getFrontendComponentInfo-获取前端组件信息--首页组件', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD,
    };
    window.g_config_data = g_config_data_tcloud;
    const respJson = {
      commitId: 'd222ff5',
      buildTime: '2022-03-02 15:51:13',
      deployTime: '2022-03-03 11:01:48',
      branch: 'master',
      productName: 'product-frontend-imgcache-tcloud-overview',
    };
    const respStub = sinon.stub().resolves({
      data: respJson,
    });
    // @ts-ignore
    const axiosStub = sinon.stub(AXIOS, 'create').returns({ get: respStub });
    const locStub = sinon.stub(loc, 'getLocationPath').returns('/');
    const productInfo = await tcesdk.platform.getFrontendComponentInfo();
    expect(productInfo).to.be.deep.equal(respJson);
    axiosStub.restore();
    locStub.restore();
  });

  it('getFrontendComponentInfo-获取前端组件信息--首页组件--购买页', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD_BUY,
    };
    window.g_config_data = g_config_data_tcloud_buy;
    const respJson = {
      buildTime: '2021-01-21 15:27:14',
      productName: 'product-frontend-imgcache-qcbuy-cvm',
      commitId: 'fef541e',
      deployTime: '2022-01-28 12:14:39',
      branch: 'release/tce3.8.0',
    };
    const respStub = sinon.stub().resolves({
      data: respJson,
    });
    // @ts-ignore
    const axiosStub = sinon.stub(AXIOS, 'create').returns({ get: respStub });
    const locStub = sinon.stub(loc, 'getLocationPath').returns('/');
    const productInfo = await tcesdk.platform.getFrontendComponentInfo();
    const { pageAccessInfo, ...rest } = productInfo || {};
    expect(rest).to.be.deep.equal(respJson);
    axiosStub.restore();
    locStub.restore();
  });

  it('getFrontendComponentInfo-获取前端组件信息--异常情况--无法获取version', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD,
    };
    window.g_config_data = g_config_data_tcloud;
    const productInfo = await tcesdk.platform.getFrontendComponentInfo('/cam/settings');
    expect(productInfo).equal(undefined);
  });

  it('helper-getOverviewVersionPath--获取首页overview组件path--租户端', async () => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_TCLOUD;
    const versionPath = getOverviewVersionPath();
    expect(versionPath).equal('//imgcache.tcenter-dev.tcecqpoc.fsphere.cn/tcloud/overview/');
  });

  it('helper-getOverviewVersionPath--获取首页overview组件path--TCS', async () => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCS_OCLOUD;
    const versionPath = getOverviewVersionPath();
    expect(versionPath).equal('//imgcache.tcenter-dev.tcecqpoc.fsphere.cn/tcs-ocloud/overview/');
  });

  it('helper-getOverviewVersionPath--获取首页overview组件path--运营端', async () => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_OCLOUD;
    const versionPath = getOverviewVersionPath();
    expect(versionPath).equal('//imgcache.tcenter-dev.tcecqpoc.fsphere.cn/ocloud/overview/');
  });

  it('helper-getOverviewVersionPath--获取通用组件组件path--租户端', async () => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_TCLOUD;
    const versionPath = getCommonVersionPath('platform');
    expect(versionPath).equal('//imgcache.tcenter-dev.tcecqpoc.fsphere.cn/tcloud/platform/');
  });

  it('helper-getOverviewVersionPath--获取通用组件组件path--运营端', async () => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_OCLOUD;
    const versionPath = getCommonVersionPath('platform');
    expect(versionPath).equal('//imgcache.tcenter-dev.tcecqpoc.fsphere.cn/ocloud/platform/');
  });
  it('helper-getOverviewVersionPath--获取通用组件组件path--TCS', async () => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCS_OCLOUD;
    const versionPath = getCommonVersionPath('platform');
    expect(versionPath).equal('//imgcache.tcenter-dev.tcecqpoc.fsphere.cn/tcs-common/platform/');
  });
  it('helper-getOverviewVersionPath--获取通用组件组件path--TCS-tcesdk', async () => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCS_OCLOUD;
    const versionPath = getCommonVersionPath('tcesdk');
    expect(versionPath).equal('//imgcache.tcenter-dev.tcecqpoc.fsphere.cn/tcs-common/tcesdk/');
  });

  it('should return value from TCE_GLOBAL_CONSTANT if available', () => {
    globalThis.TCE_GLOBAL_CONSTANT = {
      testKey: 'testValueFromTCE',
    };

    const result = tcesdk.platform.getGlobalVariable('testKey');
    expect(result).to.equal('testValueFromTCE');
  });

  it('should return value from TCS if key is not in TCE_GLOBAL_CONSTANT', () => {
    globalThis.TCE_GLOBAL_CONSTANT = {};
    globalThis.TCS = {
      testKey: 'testValueFromTCS',
    };

    const result = tcesdk.platform.getGlobalVariable('testKey');
    expect(result).to.equal('testValueFromTCS');
  });

  it('should return value from global object if key is not in TCE_GLOBAL_CONSTANT and TCS', () => {
    globalThis.TCE_GLOBAL_CONSTANT = {};
    globalThis.TCS = {};
    globalThis.testKey = 'testValueFromGlobal';

    const result = tcesdk.platform.getGlobalVariable('testKey');
    expect(result).to.equal('testValueFromGlobal');

    // Clean up the global object
    delete globalThis.testKey;
  });

  it('should return undefined if key is not found in any object', () => {
    globalThis.TCE_GLOBAL_CONSTANT = {};
    globalThis.TCS = {};

    const result = tcesdk.platform.getGlobalVariable('nonExistentKey');
    // eslint-disable-next-line @typescript-eslint/no-unused-expressions
    expect(result).to.be.undefined;
  });

  it('TCE_GLOBAL_CONSTANT 为undefined', () => {
    globalThis.TCE_GLOBAL_CONSTANT = undefined;
    globalThis.TCS = {};

    const result = tcesdk.platform.getGlobalVariable('nonExistentKey');
    // eslint-disable-next-line @typescript-eslint/no-unused-expressions
    expect(result).to.be.undefined;
  });

  it('TCE_GLOBAL_CONSTANT 为null', () => {
    globalThis.TCE_GLOBAL_CONSTANT = null;
    globalThis.TCS = null;

    const result = tcesdk.platform.getGlobalVariable('nonExistentKey');
    expect(result).to.be.undefined;
  });

  it('should return undefined for a new region', () => {
    expect(getDeliverProductListCache('newRegion')).to.be.undefined;
  });

  it('should return the previously set cache for a region', () => {
    const mockProductList = {
      level1: {
        level2: {
          product1: ['subProduct1', 'subProduct2'],
          product2: ['subProduct3'],
        },
      },
    };
    setDeliverProductListCache(mockProductList, 'existingRegion');
    expect(getDeliverProductListCache('existingRegion')).to.deep.equal(mockProductList);
  });

  it('should return the previously set global cache when no region is specified', () => {
    const mockProductList = {
      level1: {
        level2: {
          product1: ['subProduct1', 'subProduct2'],
          product2: ['subProduct3'],
        },
      },
    };
    setDeliverProductListCache(mockProductList);
    expect(getDeliverProductListCache()).to.deep.equal(mockProductList);
  });

  it('should set the cache for a specific region', () => {
    const mockProductList = {
      level1: {
        level2: {
          product1: ['subProduct1', 'subProduct2'],
          product2: ['subProduct3'],
        },
      },
    };
    setDeliverProductListCache(mockProductList, 'existingRegion');
    expect(getDeliverProductListCache('existingRegion')).to.deep.equal(mockProductList);
  });

  it('should set the global cache when no region is specified', () => {
    const mockProductList = {
      level1: {
        level2: {
          product1: ['subProduct1', 'subProduct2'],
          product2: ['subProduct3'],
        },
      },
    };
    setDeliverProductListCache(mockProductList);
    expect(getDeliverProductListCache()).to.deep.equal(mockProductList);
  });

  it('should return an empty array if yApiRequest fails', async () => {
    yApiRequestStub = sinon.stub().resolves({ res: null, err: {} });
    rewire$yApiRequest(yApiRequestStub);
    const result = await getDeliverProductList('test region');
    expect(result).to.be.an('array').that.is.empty;
    restore();
  });

  it('should return an empty array if Products is not in the response', async () => {
    yApiRequestStub = sinon.stub().resolves({ res: {}, err: null });
    rewire$yApiRequest(yApiRequestStub);
    const result = await getDeliverProductList('test region');
    expect(result).to.be.an('array').that.is.empty;
    restore();
  });

  it('should not modify data if region is not provided', async () => {
    yApiRequestStub = sinon.stub().resolves({ res: {}, err: null });
    rewire$yApiRequest(yApiRequestStub);
    await getDeliverProductList();
    expect(yApiRequestStub.firstCall.args[0].data).to.deep.equal({
      ProductId: '',
    });
    restore();
  });

  it('should return a correctly formatted array if Products is in the response', async () => {
    const mockResponse = {
      res: {
        Products: {
          level1: {
            level2: {
              product1: ['subProduct1', 'subProduct2'],
              product2: ['subProduct3'],
            },
          },
        },
      },
      err: null,
    };
    yApiRequestStub = sinon.stub().resolves(mockResponse);
    rewire$yApiRequest(yApiRequestStub);
    const result = await getDeliverProductList('test region');
    expect(result).to.deep.equal([
      {
        productCode: 'product1',
        subProduct: [{ productCode: 'subProduct1' }, { productCode: 'subProduct2' }],
      },
      { productCode: 'product2', subProduct: [{ productCode: 'subProduct3' }] },
    ]);
    restore();
  });

  it('should handle duplicate product codes correctly', async () => {
    const mockResponse = {
      res: {
        Products: {
          level1: {
            level2: {
              product1: ['subProduct1'],
            },
          },
          level2: {
            level3: {
              product1: ['subProduct2'],
            },
          },
        },
      },
      err: null,
    };
    yApiRequestStub = sinon.stub().resolves(mockResponse);
    rewire$yApiRequest(yApiRequestStub);
    const result = await getDeliverProductList('test region');
    expect(result).to.deep.equal([
      {
        productCode: 'product1',
        subProduct: [{ productCode: 'subProduct1' }, { productCode: 'subProduct2' }],
      },
    ]);
    restore();
  });

  it('should return products from cache if available', async () => {
    const mockProductList = {
      level1: {
        level2: {
          product1: ['subProduct1'],
        },
      },
    };
    setDeliverProductListCache(mockProductList, 'level1');
    const productList = await getDeliverProductList('level1');
    expect(productList).to.deep.equal([{ productCode: 'product1', subProduct: [{ productCode: 'subProduct1' }] }]);
  });

  it('should use global cache if region is not specified', async () => {
    const mockProductList = {
      level1: {
        level2: {
          product1: ['subProduct1'],
        },
      },
      level2: {
        level3: {
          product1: ['subProduct2'],
        },
      },
    };
    setDeliverProductListCache(mockProductList);
    const productList = await getDeliverProductList();
    expect(productList).to.deep.equal([
      { productCode: 'product1', subProduct: [{ productCode: 'subProduct1' }, { productCode: 'subProduct2' }] },
    ]);
  });

  it('products is null', async () => {
    const mockProductList = {
      level1: {
        level2: {
          product1: ['subProduct1'],
        },
      },
      level2: {
        level3: null,
      },
    };
    setDeliverProductListCache(mockProductList);
    const productList = await getDeliverProductList();
    expect(productList).to.deep.equal([{ productCode: 'product1', subProduct: [{ productCode: 'subProduct1' }] }]);
  });

  it('should return true if productCode found and no subProductCode provided', async () => {
    getDeliverProductListStub = sinon.stub().resolves([{ productCode: 'TEST', subProduct: [] }]);
    rewire$getDeliverProductList(getDeliverProductListStub);
    const result = await checkProductDeliver({
      region: 'TEST_REGION',
      productCode: 'TEST',
    });
    expect(result).to.be.true;
  });

  it('should return false if productCode not found', async () => {
    getDeliverProductListStub = sinon.stub().resolves([{ productCode: 'OTHER_TEST', subProduct: [] }]);
    rewire$getDeliverProductList(getDeliverProductListStub);
    const result = await checkProductDeliver({
      region: 'TEST_REGION',
      productCode: 'TEST',
    });
    expect(result).to.be.false;
  });

  it('should return true if productCode and subProductCode found', async () => {
    getDeliverProductListStub = sinon
      .stub()
      .resolves([{ productCode: 'TEST', subProduct: [{ productCode: 'SUB_TEST' }] }]);
    rewire$getDeliverProductList(getDeliverProductListStub);
    const result = await checkProductDeliver({
      region: 'TEST_REGION',
      productCode: 'TEST',
      subProductCode: 'SUB_TEST',
    });
    expect(result).to.be.true;
  });

  it('should return false if subProductCode not found', async () => {
    getDeliverProductListStub = sinon.stub().resolves([
      {
        productCode: 'TEST',
        subProduct: [{ productCode: 'SUB_OTHER_TEST' }],
      },
    ]);
    rewire$getDeliverProductList(getDeliverProductListStub);
    const result = await checkProductDeliver({
      region: 'TEST_REGION',
      productCode: 'TEST',
      subProductCode: 'SUB_TEST',
    });
    expect(result).to.be.false;
  });

  it('should return true if themeCode provided', () => {
    globalThis.TCE_GLOBAL_CONSTANT = {
      themeCode: 'testCode',
    };
    const result = tcesdk.platform.isUseCustomizeTheme();
    expect(result).to.be.true;
  });

  it('should return false if themeCode not provided', () => {
    globalThis.TCE_GLOBAL_CONSTANT = {
      themeCode: '',
    };
    const result = tcesdk.platform.isUseCustomizeTheme();
    expect(result).to.be.false;
  });

  it('should return false if themeCode not found', () => {
    globalThis.TCE_GLOBAL_CONSTANT = {};
    const result = tcesdk.platform.isUseCustomizeTheme();
    expect(result).to.be.false;
  });

  it('should return value if themeCode provided', () => {
    globalThis.TCE_GLOBAL_CONSTANT = {
      themeCode: 'testCode',
    };
    const result = tcesdk.platform.getCustomizeThemePath();
    expect(result).to.equal('/customize/cache/other/theme');
  });

  it('should return null if themeCode not provided', () => {
    globalThis.TCE_GLOBAL_CONSTANT = {
      themeCode: '',
    };
    const result = tcesdk.platform.getCustomizeThemePath();
    expect(result).to.equal('');
  });

  it('should return null if themeCode not found', () => {
    globalThis.TCE_GLOBAL_CONSTANT = {};
    const result = tcesdk.platform.getCustomizeThemePath();
    expect(result).to.equal('');
  });

  it('should return themeAssetsPath if provided', () => {
    globalThis.TCE_GLOBAL_CONSTANT = {
      themeCode: 'testCode',
      themeAssetsPath: '/custom/theme/path',
    };
    const result = tcesdk.platform.getCustomizeThemePath();
    expect(result).to.equal('/custom/theme/path');
  });
});
