/* eslint-disable @typescript-eslint/no-unused-expressions */
import chai from 'chai';
import * as tcesdk from '../src';
import { JS_COOKIE } from 'src/constants';
import { PLATFORM_TYPE } from 'src/platform';
import sinon from 'sinon';
import { utils } from 'src/security/helper';
import chaiAsPromised from 'chai-as-promised';
// @ts-ignore
import { tcesdkAssets, rewire$getSource, resetSourceCache } from '../src/common';
import * as security from '../src/security';
chai.use(chaiAsPromised);
const { expect } = chai;

const { openWaterMask } = security;

describe('tcesdk-security', () => {
  let getSourceStub;
  let watermarkjsSpy;
  beforeEach(() => {
    resetSourceCache();
  });
  // 初始化TCE_GLOBAL_CONSTANT下面的公钥数据
  before(() => {
    watermarkjsSpy = sinon.spy();
    Object.defineProperty(global.window, 'watermarkjs', {
      value: watermarkjsSpy,
      writable: true,
    });
  });

  afterEach(() => {
    JS_COOKIE.set('csrfCode', '');
    sinon.restore();
  });

  it('getCSRFToken-TCE_GLOBAL_CONSTANT不存在', () => {
    // @ts-ignore
    window.TCE_GLOBAL_CONSTANT = undefined;
    JS_COOKIE.set('user_skey', '0c7518d36i4mDM+lsfD549toKwQJ1hGSxX0jwrMaxAOJRN6gHJZ7HLOKTR7vE0TLC+lkmk9ByQ');
    const csrfToken = tcesdk.security.getCSRFToken();
    expect(csrfToken).equal('');
  });

  it('getCSRFToken', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_OCLOUD,
    };
    JS_COOKIE.set('user_skey', '0c7518d36i4mDM+lsfD549toKwQJ1hGSxX0jwrMaxAOJRN6gHJZ7HLOKTR7vE0TLC+lkmk9ByQ');
    const csrfToken = tcesdk.security.getCSRFToken();
    expect(csrfToken).equal('987919817');
  });

  it('获取csrfCode-从cookie中获取', () => {
    window.TCE_GLOBAL_CONSTANT = { platformType: 'tcs_tcloud' };
    JS_COOKIE.set('t_csrfCode', '987919817');
    const csrfToken = tcesdk.security.getCSRFToken();
    expect(csrfToken).equal('987919817');
  });

  it('获取csrfCode-从cookie中获取', () => {
    window.TCE_GLOBAL_CONSTANT = {};
    JS_COOKIE.set('csrfCode', '987919817');
    const csrfToken = tcesdk.security.getCSRFToken();
    expect(csrfToken).equal('987919817');
  });

  it('获取csrfCode-从window.TCE_GLOBAL_CONSTANT中获取', () => {
    window.TCE_GLOBAL_CONSTANT = {
      csrfCode: '123456',
    };
    const csrfToken = tcesdk.security.getCSRFToken();
    expect(csrfToken).equal('123456');
  });

  it('getCSRFToken-notOCLOUD-skeyNull', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD,
    };
    const csrfToken = tcesdk.security.getCSRFToken();
    expect(csrfToken).equal('');
  });

  it('getCSRFToken-notOCLOUD', () => {
    JS_COOKIE.set('skey', '91ae479ad/RC1kDNbvZDb7kle981GtPpM0nyWeAzl9SDURLb8YPhWyoJOlAwdejK0TE5vWw8eg');
    const csrfToken = tcesdk.security.getCSRFToken();
    expect(csrfToken).equal('1917586189');
  });

  it('getCSRFToken-TCS_OCLOUD情况下从tcs全局变量获取skey', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCS_OCLOUD,
    };
    window.TCS = {
      skey: '91ae479ad/RC1kDNbvZDb7kle981GtPpM0nyWeAzl9SDURLb8YPhWyoJOlAwdejK0TE5vWw8eg',
    };
    const csrfToken = tcesdk.security.getCSRFToken();
    expect(csrfToken).equal('1917586189');
  });

  it('getCSRFToken-TCS_OCLOUD情况下没有TCS的skey属性从cookie获取skey', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCS_OCLOUD,
    };
    window.TCS = { skey: undefined };
    JS_COOKIE.set('skey', '91ae479ad/RC1kDNbvZDb7kle981GtPpM0nyWeAzl9SDURLb8YPhWyoJOlAwdejK0TE5vWw8eg');
    const csrfToken = tcesdk.security.getCSRFToken();
    expect(csrfToken).equal('1917586189');
  });

  it('getCSRFToken-TCS_OCLOUD情况下window.TCS = {}', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCS_OCLOUD,
    };
    window.TCS = {};
    JS_COOKIE.set('skey', '91ae479ad/RC1kDNbvZDb7kle981GtPpM0nyWeAzl9SDURLb8YPhWyoJOlAwdejK0TE5vWw8eg');
    const csrfToken = tcesdk.security.getCSRFToken();
    expect(csrfToken).equal('1917586189');
  });

  it('getCSRFToken-TCS_OCLOUD情况下没有TCS属性从cookie获取skey', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCS_OCLOUD,
    };
    window.TCS = undefined;
    JS_COOKIE.set('skey', '91ae479ad/RC1kDNbvZDb7kle981GtPpM0nyWeAzl9SDURLb8YPhWyoJOlAwdejK0TE5vWw8eg');
    const csrfToken = tcesdk.security.getCSRFToken();
    expect(csrfToken).equal('1917586189');
  });

  it('helper-getEncryptLibJsUrl', () => {
    window.TCE_GLOBAL_CONSTANT = { imgcacheHost: 'imgcache.test.com' };
    const rsaJsUrl = utils.getEncryptLibJsUrl('rsa-2048');
    const kmsJsUrl = utils.getEncryptLibJsUrl('kms-sm2');
    const tsmJsUrl = utils.getEncryptLibJsUrl('tsm-sm2');
    expect(rsaJsUrl).to.equal('//imgcache.test.com/common/tcesdk/assets/jsencrypt/jsencrypt.min.js');
    expect(kmsJsUrl).to.equal('//imgcache.test.com/common/tcesdk/assets/smencrypt/SM.js');
    expect(tsmJsUrl).to.equal('//imgcache.test.com/common/tcesdk/assets/smencrypt/SM.js');
  });

  it('security-plaintext不存在', async () => {
    // @ts-ignore
    const result = await tcesdk.security.encrypt();
    expect(result).to.equal(undefined);
  });

  it('security-plaintext为空', async () => {
    // @ts-ignore
    const result = await tcesdk.security.encrypt('');
    expect(result).to.equal('');
  });

  it('security-plaintext为多个空字符串', async () => {
    // @ts-ignore
    const result = await tcesdk.security.encrypt('    ');
    expect(result).to.equal('    ');
  });

  it('rsa-2048', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_OCLOUD,
      imgcacheHost: 'imgcache.test.com',
      transportSecret: {
        method: 'rsa-2048',
        public_key:
          'LS0tLS1CRUdJTiBQVUJMSUMgS0VZLS0tLS0KTUlJQklqQU5CZ2txaGtpRzl3MEJBUUVGQUFPQ0FROEFNSUlCQ2dLQ0FRRUE2R1ByWVh0Y1V4UStCQTY3WG80UwpWNXloWTBGcFJPTWxGbGhEeUhZS1loeDVhQlBYYTZneDhmOTRpc09rRzlrT2cvYkZhQVpYTkdlMklDZE1ob2ViCk9Yb1F0MFZrSzlPTzFzclR3U1U3RVJRUk8wUE4vdGw4UWtJZUQ4RHRaK0dCSGgxZzFFM3kyQUtKdkFxOWY5VWgKYkxlbUFSY01QY05XUTR3VHU0OVdjeENZYnVPckJlVzBXdWcySXdtTkt3Q25MWU13QTJpY0p2QlgrOVNMVTBRVwo1K3p4S0tJMWFmUVdyUnY1QjdLbXpZMTREWG9EeGhIcVowdWMwWGU3V2ovQ01zU2NhbTFZWU0vV29sQzNYdW8rCjRBWVNwRzFwL2M5QmJ4TW5lM1lDZnNkRWRwUFBUcGxjbUdWK2ttUVV0NjBuS0J1TGZMeVlTRm5paU83bWkwYkgKc1FJREFRQUIKLS0tLS1FTkQgUFVCTElDIEtFWS0tLS0tCg==',
      },
    };
    const plaintext = '123456';
    const commonUtilAssetsStub = sinon
      .stub(utils, 'getEncryptLibJsUrl')
      .returns('/base/assets/jsencrypt/jsencrypt.min.js');
    const result = await tcesdk.security.encrypt(plaintext);
    expect(Boolean(result)).to.equal(true);
    expect((result as string).includes('T5443455345435552495459:7273612d32303438:5631:')).to.equal(true);
    commonUtilAssetsStub.restore();
  });

  it('rsa-2048--明文大于240字节--普通字符', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_OCLOUD,
      imgcacheHost: 'imgcache.test.com',
      transportSecret: {
        method: 'rsa-2048',
        public_key:
          'LS0tLS1CRUdJTiBQVUJMSUMgS0VZLS0tLS0KTUlJQklqQU5CZ2txaGtpRzl3MEJBUUVGQUFPQ0FROEFNSUlCQ2dLQ0FRRUE2R1ByWVh0Y1V4UStCQTY3WG80UwpWNXloWTBGcFJPTWxGbGhEeUhZS1loeDVhQlBYYTZneDhmOTRpc09rRzlrT2cvYkZhQVpYTkdlMklDZE1ob2ViCk9Yb1F0MFZrSzlPTzFzclR3U1U3RVJRUk8wUE4vdGw4UWtJZUQ4RHRaK0dCSGgxZzFFM3kyQUtKdkFxOWY5VWgKYkxlbUFSY01QY05XUTR3VHU0OVdjeENZYnVPckJlVzBXdWcySXdtTkt3Q25MWU13QTJpY0p2QlgrOVNMVTBRVwo1K3p4S0tJMWFmUVdyUnY1QjdLbXpZMTREWG9EeGhIcVowdWMwWGU3V2ovQ01zU2NhbTFZWU0vV29sQzNYdW8rCjRBWVNwRzFwL2M5QmJ4TW5lM1lDZnNkRWRwUFBUcGxjbUdWK2ttUVV0NjBuS0J1TGZMeVlTRm5paU83bWkwYkgKc1FJREFRQUIKLS0tLS1FTkQgUFVCTElDIEtFWS0tLS0tCg==',
      },
    };
    const plaintext =
      'LS0tLS1CRUdJTiBQVUJMSUMgS0VZLS0tLS0KTUlJQklqQU5CZ2txaGtpRzl3MEJBUUVGQUFPQ0FROEFNSUlCQ2dLQ0FRRUE2R1ByWVh0Y1V4UStCQTY3WG80UwpWNXloWTBGcFJPTWxGbGhEeUhZS1loeDVhQlBYYTZneDhmOTRpc09rRzlrT2cvYkZhQVpYTkdlMklDZE1ob2ViCk9Yb1F0MFZrSzlPTzFzclR3U1U3RVJRUk8wUE4vdGw4UWtJZUQ4RHRaK0dCSGgxZzFFM3kyQUtKdkFxOWY5VWgKYkxlbUFSY01QY05XUTR3VHU0OVdjeENZYnVPckJlVzBXdWcySXdtTkt3Q25MWU13QTJpY0p2QlgrOVNMVTBRVwo1K3p4S0tJMWFmUVdyUnY1QjdLbXpZMTREWG9EeGhIcVowdWMwWGU3V2ovQ01zU2NhbTFZWU0vV29sQzNYdW8rCjRBWVNwRzFwL2M5QmJ4TW5lM1lDZnNkRWRwUFBUcGxjbUdWK2ttUVV0NjBuS0J1TGZMeVlTRm5paU83bWkwYkgKc1FJREFRQUIKLS0tLS1FTkQgUFVCTElDIEtFWS0tLS0tCg==';
    const commonUtilAssetsStub = sinon
      .stub(utils, 'getEncryptLibJsUrl')
      .returns('/base/assets/jsencrypt/jsencrypt.min.js');
    const result = await tcesdk.security.encrypt(plaintext);
    expect(Boolean(result)).to.equal(true);
    expect((result as string).includes('T5443455345435552495459:7273612d32303438:5631:')).to.equal(true);
    commonUtilAssetsStub.restore();
  });

  it('rsa-2048--明文大于240字节--中文场景', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_OCLOUD,
      imgcacheHost: 'imgcache.test.com',
      transportSecret: {
        method: 'rsa-2048',
        public_key:
          'LS0tLS1CRUdJTiBQVUJMSUMgS0VZLS0tLS0KTUlJQklqQU5CZ2txaGtpRzl3MEJBUUVGQUFPQ0FROEFNSUlCQ2dLQ0FRRUE2R1ByWVh0Y1V4UStCQTY3WG80UwpWNXloWTBGcFJPTWxGbGhEeUhZS1loeDVhQlBYYTZneDhmOTRpc09rRzlrT2cvYkZhQVpYTkdlMklDZE1ob2ViCk9Yb1F0MFZrSzlPTzFzclR3U1U3RVJRUk8wUE4vdGw4UWtJZUQ4RHRaK0dCSGgxZzFFM3kyQUtKdkFxOWY5VWgKYkxlbUFSY01QY05XUTR3VHU0OVdjeENZYnVPckJlVzBXdWcySXdtTkt3Q25MWU13QTJpY0p2QlgrOVNMVTBRVwo1K3p4S0tJMWFmUVdyUnY1QjdLbXpZMTREWG9EeGhIcVowdWMwWGU3V2ovQ01zU2NhbTFZWU0vV29sQzNYdW8rCjRBWVNwRzFwL2M5QmJ4TW5lM1lDZnNkRWRwUFBUcGxjbUdWK2ttUVV0NjBuS0J1TGZMeVlTRm5paU83bWkwYkgKc1FJREFRQUIKLS0tLS1FTkQgUFVCTElDIEtFWS0tLS0tCg==',
      },
    };
    const plaintext =
      'aa云计算为IT 乃至整个商业市场带来的变革早已不是空谈。传统企业在云时代得以根本意义上的转型，大企业在云端获得源源不断的生命力，中小企业通过云，更快地面向市场获得机遇与发展。未来，会有更多的企业将加入云的世界，腾讯云将致力于打造最高质量、最佳生态的公有云服务平台。让企业更专注业务，而将基础建设放心地交给腾讯云';
    const commonUtilAssetsStub = sinon
      .stub(utils, 'getEncryptLibJsUrl')
      .returns('/base/assets/jsencrypt/jsencrypt.min.js');
    const result = await tcesdk.security.encrypt(plaintext);
    expect(Boolean(result)).to.equal(true);
    expect((result as string).includes('T5443455345435552495459:7273612d32303438:5631:')).to.equal(true);
    commonUtilAssetsStub.restore();
  });

  it('kms-sm2', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_OCLOUD,
      imgcacheHost: 'imgcache.test.com',
      transportSecret: {
        method: 'kms-sm2',
        public_key:
          '04468bf0bd7470f396284074a4aeab8b091a4da7f3fe5c34b2a7d108947d72a04c852d2c7d056744d9a6fe902f605645471352ca5bd812ea8d31b2fc86b33b6f88',
      },
    };
    const plaintext = '123456';
    const commonUtilAssetsStub = sinon.stub(utils, 'getEncryptLibJsUrl').returns('/base/assets/smencrypt/SM.js');
    const result = await tcesdk.security.encrypt(plaintext);
    commonUtilAssetsStub.restore();
    expect(Boolean(result)).to.equal(true);
    expect((result as string).includes('T5443455345435552495459:6b6d732d736d32:5631:')).to.equal(true);
  });

  it('tsm-sm2', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_OCLOUD,
      imgcacheHost: 'imgcache.test.com',
      transportSecret: {
        method: 'tsm-sm2',
        public_key:
          '04468bf0bd7470f396284074a4aeab8b091a4da7f3fe5c34b2a7d108947d72a04c852d2c7d056744d9a6fe902f605645471352ca5bd812ea8d31b2fc86b33b6f88',
      },
    };
    const plaintext = '123456';
    const commonUtilAssetsStub = sinon.stub(utils, 'getEncryptLibJsUrl').returns('/base/assets/smencrypt/SM.js');
    const result = await tcesdk.security.encrypt(plaintext);
    expect(Boolean(result)).to.equal(true);
    expect((result as string).includes('T5443455345435552495459:74736d2d736d32:5631:')).to.equal(true);
    commonUtilAssetsStub.restore();
  });

  it('getGlobalConstants为空', async () => {
    // @ts-ignore
    window.TCE_GLOBAL_CONSTANT = undefined;
    const plaintext = '123456';
    const result = await tcesdk.security.encrypt(plaintext);
    expect(result).to.equal(plaintext);
  });

  it('getGlobalConstants为空--default有值', async () => {
    // @ts-ignore
    window.TCE_GLOBAL_CONSTANT = undefined;
    const plaintext = '123456';
    const result = await tcesdk.security.encrypt(plaintext, '4567');
    expect(result).to.equal('4567');
  });

  it('getGlobalConstants为空--transportSecret为空', async () => {
    // @ts-ignore
    window.TCE_GLOBAL_CONSTANT = { transportSecret: {}, imgcacheHost: 'imgcache.test.com' };
    const plaintext = '123456';
    const result = await tcesdk.security.encrypt(plaintext);
    expect(result).to.equal(plaintext);
  });

  it('getGlobalConstants--imgcacheHost为空', async () => {
    // @ts-ignore
    window.TCE_GLOBAL_CONSTANT = { transportSecret: {} };
    const plaintext = '123456';
    expect(tcesdk.security.encrypt(plaintext)).to.eventually.be.rejectedWith('imgcacheHost not exist');
  });
  it('openWaterMask--getWaterMarkUrl', async () => {
    window.TCE_GLOBAL_CONSTANT = { imgcacheHost: 'imgcache.test.com' };
    const watermarkUrl = tcesdkAssets.getWaterMarkUrl();
    expect(watermarkUrl).to.equal('//imgcache.test.com/common/tcesdk/assets/watermark/watermarkjs.umd.js');
  });

  it('should return early if content is empty', async () => {
    await openWaterMask('');
    expect(watermarkjsSpy.called).to.be.false;
  });

  it('should not call getSource if watermarkjs already exists', async () => {
    getSourceStub = sinon.stub().resolves();
    rewire$getSource(getSourceStub);
    await openWaterMask('test content');
    expect(getSourceStub.called).to.be.false;
  });

  it('should call getSource if watermarkjs does not exist', async () => {
    global.window.watermarkjs = undefined;
    getSourceStub = sinon.stub().resolves();
    rewire$getSource(getSourceStub);
    try {
      await openWaterMask('test content');
    } catch (e) {}
    expect(getSourceStub.called).to.be.true;
  });

  it('should throw an error if getSource fails', async () => {
    global.window.watermarkjs = undefined;
    getSourceStub = sinon.stub().rejects(new Error('Test error'));
    rewire$getSource(getSourceStub);
    try {
      await openWaterMask('test content');
      expect.fail('openWaterMask should have thrown an error');
    } catch (e: any) {
      expect(e.message).to.equal('load watermark js failed');
    }
  });

  it('should call watermarkjs constructor with correct arguments', async () => {
    getSourceStub = sinon.stub().resolves((global.window.watermarkjs = () => {}));
    rewire$getSource(getSourceStub);
    await openWaterMask('test content');
    expect(watermarkjsSpy.calledWithNew()).to.be.true;
    expect(watermarkjsSpy.firstCall.args[0]).to.equal('test content');
    expect(watermarkjsSpy.firstCall.args[1]).to.deep.equal({
      enableObserver: true,
      IGraphOptions: {
        textMaxLength: 30,
        font: '400 20px Arial',
      },
    });
  });
});
