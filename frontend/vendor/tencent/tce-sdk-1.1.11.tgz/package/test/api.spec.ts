/* eslint-disable @typescript-eslint/no-unused-expressions */
import * as tcesdk from '../src';
import sinon from 'sinon';
import { PLATFORM_TYPE } from 'src/platform';
import chai from 'chai';
import chaiAsPromised from 'chai-as-promised';
import { MODAL } from '../src/common/modal';
import { yApiAxios } from '../src/api/yApiAxios';
// @ts-ignore
import { rewire$getComponent, restore } from '../src/component';
import { getYapiUrl } from '../src/api/helper';
import { loc } from 'src/common/util';
import { JIGUANG_LOGIN_EXPIRED_RELOAD_TIME_STORAGE } from '../src/common/constants';
chai.use(chaiAsPromised);
const { expect } = chai;

describe('tcesdk-api', () => {
  let axiosInsStub: sinon.SinonStub;
  const AXIOSINS = yApiAxios;

  let reload: sinon.SinonStub;

  before(() => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_OCLOUD,
      baseHost: 'localhost',
      consoleHost: 'consoleHost',
    };
    // @ts-ignore
    window.jiguangPlatformMessage = (str, type) => type;
    reload = sinon.stub(loc, 'locationReload').returns();
  });
  after(() => {
    reload?.restore();
  });
  beforeEach(() => {
    axiosInsStub = sinon.stub(yApiAxios, 'post');
  });
  afterEach(() => {
    axiosInsStub.restore();
  });

  it('yApiRequest-测试axios', async () => {
    const res = { code: 0, data: { Response: { data: 1 } } };
    axiosInsStub.resolves(res);
    const result = await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });
    expect(result).to.be.deep.equal({ res: { data: 1 }, err: undefined, rawResponse: res });
  });

  it('yApiRequest-测试axios.interceptors.response.fulfilled', () => {
    // @ts-ignore
    expect(AXIOSINS.interceptors.response.handlers[0].fulfilled({ data: 'foo' })).equal('foo');
  });

  it('yApiRequest-测试axios.interceptors.response.rejected', () => {
    // @ts-ignore
    expect(AXIOSINS.interceptors.response.handlers[0].rejected('err')).rejectedWith('err');
  });

  it('yApiRequest-测试axios.interceptors.request.fulfilled', () => {
    expect(
      // @ts-ignore
      AXIOSINS.interceptors.request.handlers[0].fulfilled({ data: 'foo', headers: {} }).headers,
    ).have.property('X-CsrfCode');
  });

  it('yApiRequest-测试axios.interceptors.request.rejected无response字段', () => {
    expect(
      // @ts-ignore
      AXIOSINS.interceptors.request.handlers[0].rejected({ code: 100, message: 'err' }),
    ).eventually.be.rejected.and.have.keys(['Code', 'Message']);
  });

  it('yApiRequest-测试axios.interceptors.request.rejected有response字段且status大于400', () => {
    expect(
      // @ts-ignore
      AXIOSINS.interceptors.request.handlers[0].rejected({
        response: { status: 401, statusText: 'err' },
      }),
    ).eventually.be.rejected.and.have.keys(['Code', 'Message']);
  });

  it('yApiRequest-测试axios.interceptors.request.rejected有response字段且status小于400', () => {
    const err = {
      response: { status: 200, statusText: 'err' },
    };
    expect(
      // @ts-ignore
      AXIOSINS.interceptors.request.handlers[0].rejected(err),
    ).eventually.be.rejected.and.deep.equal(err);
  });

  it('yApiRequest-测试axios响应没有response字段', async () => {
    const res = { code: 0, data: { data: 1 } };
    axiosInsStub.resolves(res);
    const result = await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });
    console.log('result---->', JSON.stringify(result));
    expect(result).to.be.deep.equal({
      res: undefined,
      err: { code: 0, message: undefined, requestId: undefined, data: { data: 1 } },
      rawResponse: res,
    });
  });

  it('yApiRequest-测试axios响应code不为0', async () => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_TCLOUD;
    const res = {
      code: 201,
      data: { Response: { Code: 201, Error: { Code: 201, Message: 'err' } } },
    };
    axiosInsStub.resolves(res);
    const modalStub = sinon.stub(MODAL, 'showPreLoginModal');
    await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });
    expect(modalStub.calledOnce);
    modalStub.restore();
  });

  it('yApiRequest-极光环境-测试axios响应code为400001', async () => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.JIGUANG;
    const res = {
      code: 400001,
      data: { Response: { Code: 400001, Error: { Code: 400001, Message: 'err' } } },
    };
    axiosInsStub.resolves(res);
    // @ts-ignore
    const modalStub = sinon.stub(window, 'jiguangPlatformMessage');
    await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });
    expect(modalStub.calledOnce);
    modalStub.restore();
  });

  it('yApiRequest-测试暴露其余报错信息', async () => {
    const res = {
      code: 0,
      codeDesc: 'success',
      data: {
        Response: {
          Error: {
            Code: 'CGI_ERROR',
            Message:
              '[ObjectLocked] The object is locked, you are not allowd to put/delete object or modify the metadata via copy object.',
            Headers: {
              'content-type': 'application/xml',
              'x-cos-request-id': 'NjM3MjI3YmFfODgwMDEzMGFfNGIzMl9hYQ==',
            },
            StatusCode: 409,
            ErrorCode: 'ObjectLocked',
          },
          RequestId: '71230cce-44aa-4d06-8ba6-51bea15292d7',
        },
      },
      message: 'success',
    };
    axiosInsStub.resolves(res);
    const result = await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });
    expect(result).to.be.deep.equal({
      res: undefined,
      err: {
        code: 'CGI_ERROR',
        message:
          '[CGI_ERROR]:[ObjectLocked] The object is locked, you are not allowd to put/delete object or modify the metadata via copy object.',
        requestId: '71230cce-44aa-4d06-8ba6-51bea15292d7',
        Headers: {
          'content-type': 'application/xml',
          'x-cos-request-id': 'NjM3MjI3YmFfODgwMDEzMGFfNGIzMl9hYQ==',
        },
        StatusCode: 409,
        ErrorCode: 'ObjectLocked',
      },
      rawResponse: res,
    });
  });

  it('yApiRequest-测试axios响应报错InvalidAccessIP', async () => {
    const res = {
      code: 1,
      data: {
        Response: {
          Code: 1,
          Error: { Code: 'UnauthorizedOperation.InvalidAccessIP', Message: 'err' },
        },
      },
    };
    axiosInsStub.resolves(res);
    const modalStub = sinon.stub(MODAL, 'showPreLoginModal');
    await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });
    expect(modalStub.calledOnce);
    modalStub.restore();
  });

  it('yApiRequest-测试axios响应报错InvalidAccessIP-没有Message', async () => {
    const res = {
      code: 1,
      data: {
        Response: {
          Code: 1,
          Error: { Code: 'UnauthorizedOperation.InvalidAccessIP', Message: '' },
        },
      },
    };
    axiosInsStub.resolves(res);
    const modalStub = sinon.stub(MODAL, 'showPreLoginModal');

    await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });
    expect(modalStub.calledOnce);
    modalStub.restore();
  });

  it('yApiRequest-测试axios响应报错InvalidAccessIP-ip获取', async () => {
    const res = {
      code: 1,
      data: {
        Response: {
          Code: 1,
          Error: { Code: 'UnauthorizedOperation.InvalidAccessIP', Message: '`1`2`' },
        },
      },
    };
    axiosInsStub.resolves(res);
    const modalStub = sinon.stub(MODAL, 'showPreLoginModal');
    await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });
    expect(modalStub.calledOnce);
    modalStub.restore();
  });

  it('yApiRequest-取消请求', async () => {
    const res = { code: 0, __CANCEL__: true };
    axiosInsStub.resolves(res);
    await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });
  });

  // 这里是rewire获取组件的功能和mock获取到的组件的结合实例
  it('yApiRequest-测试axios请求报错弹出二次认证', async () => {
    const res = {
      code: 1000,
      codeDesc: 'LogicError.NeedActionVerify',
      data: {
        Response: {
          Code: 1000,
          Error: {
            Code: 'UnauthorizedOperation.InvalidAccessIP',
            Message: '`1`2`',
          },
        },
      },
    };
    axiosInsStub.resolves(res);
    const showStub = sinon.stub().returns(() => {});
    const componentStub = sinon.stub().resolves({ showAuthModal: showStub });
    rewire$getComponent(componentStub);

    await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });
    // eslint-disable-next-line @typescript-eslint/no-unused-expressions
    expect(showStub.calledOnce).to.be.true;
    restore();
  });

  // 这里是rewire获取组件的功能和mock获取到的组件的结合实例
  it('yApiRequest-测试axios请求报错弹出MFA二次认证', async () => {
    const res = {
      code: 1020,
      codeDesc: 'LogicError.NeedMFACodeVerify',
      data: {
        Response: {
          Code: 1020,
          Error: {
            Code: 'UnauthorizedOperation.InvalidAccessIP',
            Message: '`1`2`',
          },
        },
      },
    };
    axiosInsStub.resolves(res);
    const showStub = sinon.stub().returns(() => {});
    const componentStub = sinon.stub().resolves({ showAuthModal: showStub });
    rewire$getComponent(componentStub);

    await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });
    // eslint-disable-next-line @typescript-eslint/no-unused-expressions
    expect(showStub.calledOnce).to.be.true;
    restore();
  });

  // 这里是rewire获取组件的功能和mock获取到的组件的结合实例
  it('yApiRequest-测试axios请求报错弹出数字证书校验-query包含ukey-sign', async () => {
    const res = {
      code: 1010,
      codeDesc: 'LogicError.NeedActionVerify',
      data: {
        Response: {
          Code: 1000,
          Error: {
            Code: 'UnauthorizedOperation.InvalidAccessIP',
            Message: '`1`2`',
          },
        },
      },
    };
    axiosInsStub.resolves(res);
    const showStub = sinon.stub().returns(() => {});
    const componentStub = sinon.stub().resolves({ showAuthDigitalCertModal: showStub });
    rewire$getComponent(componentStub);

    await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
      query: {
        ukey_sign: '211312',
      },
    });
    // eslint-disable-next-line @typescript-eslint/no-unused-expressions
    expect(showStub.calledOnce).to.be.false;
    restore();
  });

  it('yApiRequest-测试axios请求报错弹出二次认证但获取组件出错', async () => {
    const res = {
      code: 1000,
      codeDesc: 'LogicError.NeedActionVerify',
      data: {
        Response: {
          Code: 1000,
          Error: {
            Code: 'UnauthorizedOperation.InvalidAccessIP',
            Message: '`1`2`',
          },
        },
      },
    };
    axiosInsStub.resolves(res);
    const showStub = sinon.stub().rejects();
    const componentStub = sinon.stub().resolves({ showAuthModal: showStub });
    rewire$getComponent(componentStub);

    const apiRes = await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });

    expect(apiRes).to.deep.eq({
      res: undefined,
      err: {
        code: '1000',
        message: '该操作需要二次认证',
        requestId: '',
      },
      rawResponse: res,
    });

    restore();
  });

  it('yApiRequest-非0code且不为特殊code直接返回err且有message', async () => {
    const res = {
      code: '1',
      codeDesc: 'LogicError.NeedActionVerify',
      message: 'errorMessage',
      data: {
        Response: {
          Code: 1000,
          Error: {
            Code: 'UnauthorizedOperation.InvalidAccessIP',
            Message: '`1`2`',
          },
        },
      },
    };
    axiosInsStub.resolves(res);

    const apiRes = await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });

    expect(apiRes).to.deep.eq({
      res: undefined,
      err: {
        code: '1',
        message: 'errorMessage',
        requestId: '',
      },
      rawResponse: res,
    });
  });

  it('yApiRequest-非0code且不为特殊code直接返回err且无message', async () => {
    const res = {
      code: '1',
      codeDesc: 'LogicError.NeedActionVerify',
      data: {
        Response: {
          Code: 1000,
          Error: {
            Code: 'UnauthorizedOperation.InvalidAccessIP',
            Message: '`1`2`',
          },
        },
      },
    };
    axiosInsStub.resolves(res);

    const apiRes = await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });

    expect(apiRes).to.deep.eq({
      res: undefined,
      err: {
        code: '1',
        message: undefined,
        requestId: '',
      },
      rawResponse: res,
    });
  });

  it('yApiRequest-code为0但有Error', async () => {
    const res = {
      code: 0,
      codeDesc: 'LogicError.NeedActionVerify',
      data: {
        Response: {
          Code: 1000,
          Error: {
            Code: 'UnauthorizedOperation.InvalidAccessIP',
            Message: '`1`2`',
          },
        },
      },
    };
    axiosInsStub.resolves(res);

    const apiRes = await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });

    expect(apiRes).eql({
      res: undefined,
      err: {
        code: 'UnauthorizedOperation.InvalidAccessIP',
        message: '`1`2`',
        requestId: undefined,
      },
      rawResponse: res,
    });
  });

  it('yApiRequest-code为0但有Error但没Code和Message', async () => {
    const res = {
      code: 0,
      codeDesc: 'LogicError.NeedActionVerify',
      data: {
        Response: {
          Code: 1000,
          Error: {},
        },
      },
    };
    axiosInsStub.resolves(res);

    const apiRes = await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });

    expect(apiRes).eql({
      res: undefined,
      err: {
        code: undefined,
        message: undefined,
        requestId: undefined,
      },
      rawResponse: res,
    });
  });

  it('yApiRequest-axios请求失败进入catch阶段', async () => {
    const res = {
      Code: 'UnauthorizedOperation.InvalidAccessIP',
      Message: '`1`2`',
    };
    axiosInsStub.rejects(res);
    const modalStub = sinon.stub(MODAL, 'showPreLoginModal');

    const apiRes = await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });

    expect(apiRes).eql({
      res: undefined,
      err: {
        code: 'UnauthorizedOperation.InvalidAccessIP',
        message: '`1`2`',
        requestId: undefined,
      },
      rawResponse: undefined,
    });

    expect(modalStub.calledWith('ipLimitModal.title', 'ipLimitModal.description', '1'));
    modalStub.restore();
  });

  it('yApiRequest-axios请求失败进入catch阶段且无message', async () => {
    const res = {
      Code: 'UnauthorizedOperation.InvalidAccessIP',
      Message: '',
    };
    axiosInsStub.rejects(res);
    const modalStub = sinon.stub(MODAL, 'showPreLoginModal');

    await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });

    expect(modalStub.calledWith('ipLimitModal.title', 'ipLimitModal.description', ''));
    modalStub.restore();
  });

  it('yApiRequest-axios请求失败进入catch阶段且message分割后length不大于2', async () => {
    const res = {
      Code: 'UnauthorizedOperation.InvalidAccessIP',
      Message: '`1',
    };
    axiosInsStub.rejects(res);
    const modalStub = sinon.stub(MODAL, 'showPreLoginModal');

    await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });

    expect(modalStub.calledWith('ipLimitModal.title', 'ipLimitModal.description', '`1'));
    modalStub.restore();
  });

  it('yApiRequest-极光环境-axios请求结果是ERR_NETWORK但无法判断是不是302', async () => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.JIGUANG;
    const res = {
      code: 'ERR_NETWORK',
    };
    axiosInsStub.rejects(res);
    // @ts-ignore
    const modalStub = sinon.stub(window, 'jiguangPlatformMessage');
    await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });
    expect(modalStub.notCalled);
    modalStub.restore();
  });

  it('yApiRequest-极光环境-axios请求结果302', async () => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.JIGUANG;
    const res = {
      code: 'ERR_NETWORK',
      response: {
        readyState: 4,
        status: 0,
      },
    };
    axiosInsStub.rejects(res);
    // @ts-ignore
    const modalStub = sinon.stub(window, 'jiguangPlatformMessage');
    await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });
    expect(modalStub.calledWith('登录过期,页面将自动刷新', 'error'));
    modalStub.restore();
  });

  it('yApiRequest-极光环境-axios请求结果302一个小时内不再刷新页面的时间戳为异常数据', async () => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.JIGUANG;
    sessionStorage[JIGUANG_LOGIN_EXPIRED_RELOAD_TIME_STORAGE] = '{}';
    const res = {
      code: 'ERR_NETWORK',
      response: {
        readyState: 4,
        status: 0,
      },
    };
    axiosInsStub.rejects(res);
    // @ts-ignore
    const modalStub = sinon.stub(window, 'jiguangPlatformMessage');
    await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });
    expect(modalStub.calledOnce);
    modalStub.restore();
  });

  it('yApiRequest-极光环境-axios请求结果302一个小时内不再刷新页面', async () => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.JIGUANG;
    sessionStorage[JIGUANG_LOGIN_EXPIRED_RELOAD_TIME_STORAGE] = Date.now();
    const res = {
      code: 'ERR_NETWORK',
      response: {
        readyState: 4,
        status: 0,
      },
    };
    axiosInsStub.rejects(res);
    // @ts-ignore
    const modalStub = sinon.stub(window, 'jiguangPlatformMessage');
    await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });
    expect(modalStub.notCalled);
    modalStub.restore();
  });

  it('yApiRequest-getCurrentRegion-未缓存regionList', async () => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_TCLOUD_BUY;
    // @ts-ignore
    window.TCE_GLOBAL_CONSTANT_ASYNC = undefined;

    const { href } = window.location;
    history.pushState({}, '', `${href}?regionId=11`);

    axiosInsStub.resolves({
      code: 0,
      data: {
        Response: {
          RegionSet: [
            {
              RegionState: 'AVAILABLE',
              Region: 'chongqing',
              RegionID: '11',
              RegionName: '重庆',
              ZoneSet: [{ ZoneState: 'AVAILABLE', ZoneID: '111', ZoneName: '海淀区', Zone: 'haidian' }],
            },
          ],
        },
      },
    });

    await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });

    history.pushState({}, '', href);

    expect(window.TCE_GLOBAL_CONSTANT_ASYNC).have.property('regionList');
  });

  it('yApiRequest-getCurrentRegion-已缓存regionList', async () => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_TCLOUD_BUY;

    window.TCE_GLOBAL_CONSTANT_ASYNC = {
      regionList: [
        {
          regionId: 11,
          regionName: '重庆',
          region: 'chongqing',
          zoneList: [
            {
              zone: 'haidian',
              zoneId: 111,
              zoneName: '海淀区',
            },
          ],
        },
      ],
    };

    const { href } = window.location;
    history.pushState({}, '', `${href}?regionId=11`);

    const reqData = {
      serviceType: '1',
      action: 'action',
      region: 'chongqing',
      version: '2',
      data: { test: 'regionTest', Version: '2', Language: 'zh-CN' },
    };

    await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      data: { test: 'regionTest' },
    });

    history.pushState({}, '', href);
    window.TCE_GLOBAL_CONSTANT_ASYNC = {};
    // @ts-ignore
    delete reqData.version; // 【发起请求的时候入参里面没有version】
    expect(axiosInsStub.calledWith('//tapi.localhost/capi/v3?i=1/action', reqData)).to.be.true;
  });

  it('yApiRequest-平台为TCE_OCLOUD', (done) => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_OCLOUD;
    const reqData = {
      serviceType: '1',
      action: 'action',
      region: '',
      version: '2',
      data: { Version: '2', Language: 'zh-cn' },
    };

    tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });
    // @ts-ignore
    delete reqData.version; // 【发起请求的时候入参里面没有version】
    // eslint-disable-next-line @typescript-eslint/no-unused-expressions
    expect(axiosInsStub.calledWith('//oapi.localhost/capi/v3?i=1/action', reqData)).to.be.true;
    done();
  });

  it('yApiRequest-平台为TCE_TCLOUD_BUY', async () => {
    (window as any).TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_TCLOUD_BUY;
    const reqData = {
      serviceType: '1',
      action: 'action',
      region: '',
      version: '2',
      data: { Version: '2', Language: 'zh-cn' },
    };

    await tcesdk.api.yApiRequest({ serviceType: '1', action: 'action', version: '2', region: '', language: 'zh-cn' });
    // @ts-ignore
    delete reqData.version; // 【发起请求的时候入参里面没有version】
    // eslint-disable-next-line @typescript-eslint/no-unused-expressions
    expect(axiosInsStub.calledWith('//tapi.localhost/capi/v3?i=1/action', reqData)).to.be.true;
  });

  it('yApiRequest-平台为TCE_TCLOUD', () => {
    (window as any).TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_TCLOUD;
    const reqData = {
      serviceType: '1',
      action: 'action',
      region: '',
      version: '2',
      data: { Version: '2', Language: 'zh-cn' },
    };

    tcesdk.api.yApiRequest({ serviceType: '1', action: 'action', version: '2', language: 'zh-cn' });
    // @ts-ignore
    delete reqData.version; // 【发起请求的时候入参里面没有version】
    // eslint-disable-next-line @typescript-eslint/no-unused-expressions
    expect(axiosInsStub.calledWith('//tapi.localhost/capi/v3?i=1/action', reqData)).to.be.true;
  });

  it('yApiRequest-平台为JiGuang', () => {
    (window as any).TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.JIGUANG;
    expect(getYapiUrl()).equal('//consoleHost/api/');
  });

  it('yApiRequest-平台为TCS_OCLOUD', () => {
    (window as any).TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCS_OCLOUD;
    const reqData = {
      serviceType: '1',
      action: 'action',
      region: '',
      version: '2',
      data: { Version: '2', Language: 'zh-cn' },
    };
    // @ts-ignore
    delete reqData.version; // 【发起请求的时候入参里面没有version】
    tcesdk.api.yApiRequest({ serviceType: '1', action: 'action', version: '2', language: 'zh-cn' });
    expect(axiosInsStub.calledWith('//api.consoleHost/capi/v3?i=1/action', reqData)).to.be.true;
  });

  it('yApiRequest-入参有data参数', () => {
    const reqData = {
      serviceType: '1',
      action: 'action',
      region: '',
      version: '2',
      data: { Version: '2', Language: 'zh-CN', test: 'test' },
    };

    tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      data: { test: 'test' },
    });
    // @ts-ignore
    delete reqData.version; // 【发起请求的时候入参里面没有version】
    expect(axiosInsStub.calledWith('//api.consoleHost/capi/v3?i=1/action', reqData)).to.be.true;
  });

  it('yApiRequest-有query参数', () => {
    const reqData = {
      serviceType: '1',
      action: 'action',
      region: '',
      version: '2',
      data: { Version: '2', Language: 'zh-cn' },
    };

    tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
      query: {
        regionId: '11',
      },
    });
    // @ts-ignore
    delete reqData.version; // 【发起请求的时候入参里面没有version】
    expect(axiosInsStub.calledWith('//api.consoleHost/capi/v3?i=1/action&regionId=11', reqData)).to.be.true;
  });

  it('yApiRequest-入参有cancelToken', () => {
    const reqData = {
      serviceType: '1',
      action: 'action',
      region: '',
      version: '2',
      data: { Version: '2', Language: 'zh-CN', test: 'test' },
    };

    const cancelToken = tcesdk.api.getCancelToken();
    const source = cancelToken.source();
    tcesdk.api.yApiRequest(
      {
        serviceType: '1',
        action: 'action',
        version: '2',
        data: { test: 'test' },
      },
      { cancelToken: source.token },
    );
    // @ts-ignore
    delete reqData.version; // 【发起请求的时候入参里面没有version】
    expect(
      axiosInsStub.calledWith('//api.consoleHost/capi/v3?i=1/action', reqData, {
        cancelToken: source.token,
      }),
    ).to.be.true;
  });

  it('yApiRequest-平台为TCE_TCLOUD_BUY-region-undefined', async () => {
    (window as any).TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_TCLOUD_BUY;

    const axiosRes = {
      code: 0,
      data: {
        Response: {
          RegionSet: [
            {
              RegionState: 'AVAILABLE',
              Region: 'chongqing',
              RegionID: '11',
              RegionName: '重庆',
              ZoneSet: [{ ZoneState: 'AVAILABLE', ZoneID: '111', ZoneName: '海淀区', Zone: 'haidian' }],
            },
          ],
        },
      },
    };
    axiosInsStub.resolves(axiosRes);
    const resp = await tcesdk.api.yApiRequest({ serviceType: '1', action: 'action', version: '2', language: 'zh-cn' });
    expect(resp.res).to.be.deep.equal(axiosRes.data.Response);
  });

  it('yApiRequest-有region参数', () => {
    (window as any).TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_TCLOUD;
    window.I18N_CONFIG = {
      regionList: [
        {
          region_name: 'chongqing',
          region_id: 50000001,
          area: '重庆',
          code: 'chongqing',
          regionId: 'chongqing',
          value: 50000001,
          default: true,
          name: '重庆',
          'region_name_zh-CN': '重庆',
        },
      ],
    };
    const reqData = {
      serviceType: '1',
      action: 'action',
      region: 'chongqing',
      version: '2',
      data: { Version: '2', Language: 'zh-cn' },
    };
    // @ts-ignore
    delete reqData.version; // 【发起请求的时候入参里面没有version】
    tcesdk.api.yApiRequest({ serviceType: '1', action: 'action', version: '2', language: 'zh-cn' });
    expect(axiosInsStub.calledWith('//tapi.localhost/capi/v3?i=1/action', reqData)).to.be.true;
  });

  it('yApiRequest-有region参数且为数字', async () => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_TCLOUD_BUY;
    window.TCE_GLOBAL_CONSTANT_ASYNC = {
      regionList: [
        {
          regionId: 11,
          regionName: '重庆',
          region: 'chongqing',
          zoneList: [
            {
              zone: 'haidian',
              zoneId: 111,
              zoneName: '海淀区',
            },
          ],
        },
      ],
    };
    const reqData = {
      serviceType: '1',
      action: 'action',
      region: 'chongqing',
      version: '2',
      data: { test: 'regionTest', Version: '2', Language: 'zh-CN' },
    };

    await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      data: { test: 'regionTest' },
      region: '11',
    });

    // @ts-ignore
    delete reqData.version; // 【发起请求的时候入参里面没有version】
    window.TCE_GLOBAL_CONSTANT_ASYNC = {};
    expect(axiosInsStub.calledWith('//tapi.localhost/capi/v3?i=1/action', reqData)).to.be.true;
  });

  it('yApiRequest-有region参数且为数字没有regionList', async () => {
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_TCLOUD_BUY;
    window.TCE_GLOBAL_CONSTANT_ASYNC = {
      regionList: [
        {
          regionId: 12,
          regionName: '重庆',
          region: 'chongqing',
          zoneList: [
            {
              zone: 'haidian',
              zoneId: 111,
              zoneName: '海淀区',
            },
          ],
        },
      ],
    };

    const reqData = {
      serviceType: '1',
      action: 'action',
      region: '11',
      version: '2',
      data: { test: 'regionTest', Version: '2', Language: 'zh-CN' },
    };

    await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      data: { test: 'regionTest' },
      region: '11',
    });

    // @ts-ignore
    delete reqData.version; // 【发起请求的时候入参里面没有version】
    expect(axiosInsStub.calledWith('//tapi.localhost/capi/v3?i=1/action', reqData)).to.be.true;
  });

  it('api-获取通用错误码常量', () => {
    const { CommonErrorCode } = tcesdk.api;
    expect(CommonErrorCode.UnauthorizedOperation).equal('UnauthorizedOperation');
  });

  it('getCancelToken', () => {
    expect(tcesdk.api.getCancelToken()).haveOwnProperty('source');
  });

  it('apiResI18nHandler-当语言不为中文', () => {
    (window as any).I18N_CONFIG = {
      langList: [
        {
          default: true,
          name: 'en-US',
        },
      ],
    };

    const handlerResult = tcesdk.api.apiResI18nHandler(
      {
        res: { res: {}, err: { code: 'us', message: 'us', requestId: 'us' }, rawResponse: {} },
        serviceType: 'action',
        action: 'action',
      },
      { us: 'US' },
      true,
    );

    expect(handlerResult).eql({ res: {}, err: { code: 'us', message: 'us', requestId: 'us' }, rawResponse: {} });
  });

  it('apiResI18nHandler-当语言为中文', () => {
    (window as any).I18N_CONFIG = undefined;
    const handlerResult = tcesdk.api.apiResI18nHandler(
      {
        res: { res: {}, err: { code: 'us', message: 'us', requestId: 'us' }, rawResponse: {} },
        serviceType: 'action',
        action: 'action',
      },
      { us: 'US' },
      true,
    );

    expect(handlerResult).eql({ res: {}, err: { code: 'us', message: 'US', requestId: 'us' }, rawResponse: {} });
  });

  it('apiResI18nHandler-当语言为中文且没有对照表', () => {
    const handlerResult = tcesdk.api.apiResI18nHandler(
      {
        res: { res: {}, err: { code: 'us', message: 'us', requestId: 'us' }, rawResponse: {} },
        serviceType: 'action',
        action: 'action',
      },
      { uss: 'US' },
      true,
    );

    expect(handlerResult).eql({ res: {}, err: { code: 'us', message: 'us', requestId: 'us' }, rawResponse: {} });
  });

  it('apiResI18nHandler-当语言为中文且没有err', () => {
    const handlerResult = tcesdk.api.apiResI18nHandler(
      {
        res: { res: {}, err: undefined, rawResponse: {} },
        serviceType: 'action',
        action: 'action',
      },
      { uss: 'US' },
      true,
    );
    expect(handlerResult).eql({ res: {}, err: undefined, rawResponse: {} });
  });

  it('resHandler', () => {
    const handlerResult = tcesdk.api.resHandler({
      res: { res: {}, err: undefined, rawResponse: {} },
      serviceType: 'action',
      action: 'action',
    });
    expect(handlerResult).eql({ res: {}, err: undefined, rawResponse: {} });
  });

  it('transformFirstLetterToLowerCase-正常情况', () => {
    const object = {
      Hello: 'test1',
      World: 'test2',
    };
    const result = tcesdk.api.transformFirstLetterToLowerCase(object);
    expect(result).eql({ hello: 'test1', world: 'test2' });
  });

  it('transformFirstLetterToLowerCase-正常情况-全是大写', () => {
    const object = {
      HELLO: 'test1',
    };
    const result = tcesdk.api.transformFirstLetterToLowerCase(object);
    expect(result).eql({ hELLO: 'test1' });
  });

  it('transformFirstLetterToLowerCase-正常情况-全是大写-不转换', () => {
    const object = {
      HELLO: 'test1',
    };
    const result = tcesdk.api.transformFirstLetterToLowerCase(object, true);
    expect(result).eql({ HELLO: 'test1' });
  });

  it('transformFirstLetterToLowerCase-正常情况-数组', () => {
    const object = [
      {
        Hello: 'test1',
        World: 'test2',
      },
    ];
    const result = tcesdk.api.transformFirstLetterToLowerCase(object);
    expect(result).eql([{ hello: 'test1', world: 'test2' }]);
  });

  it('transformFirstLetterToLowerCase-异常情况-不是对象', () => {
    const result = tcesdk.api.transformFirstLetterToLowerCase(123);
    expect(result).eql(123);
  });

  it('transformFirstLetterToUpperCase-正常情况', () => {
    const object = {
      hello: 'test1',
      world: 'test2',
    };
    const result = tcesdk.api.transformFirstLetterToUpperCase(object);
    expect(result).eql({ Hello: 'test1', World: 'test2' });
  });

  it('transformFirstLetterToUpperCase-正常情况-数组对象', () => {
    const object = [
      {
        hello: 'test1',
        world: 'test2',
      },
    ];
    const result = tcesdk.api.transformFirstLetterToUpperCase(object);
    expect(result).eql([{ Hello: 'test1', World: 'test2' }]);
  });

  it('transformFirstLetterToUpperCase-异常情况-不是对象', () => {
    const result = tcesdk.api.transformFirstLetterToUpperCase(123);
    expect(result).eql(123);
  });

  it('yApiRequest-配置yapiUrl', () => {
    (window as any).TCE_GLOBAL_CONSTANT.yapiUrl = '//api.consoleHost/capi/v3';
    expect(getYapiUrl()).equal('//api.consoleHost/capi/v3');
  });

  it('yApiRequest-非0code且codeDesc为NeedApproval,没有response', async () => {
    const res = {
      code: 5000,
      codeDesc: 'NeedApproval',
      data: {},
    };
    axiosInsStub.resolves(res);
    const showStub = sinon.stub().returns(() => res);
    const componentStub = sinon.stub().resolves({ showApprovalModal: showStub });
    rewire$getComponent(componentStub);
    await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });
    expect(showStub.calledWith()).to.be.true;
    restore();
  });
  it('yApiRequest-非0code且codeDesc为NeedApproval', async () => {
    const res = {
      code: 5000,
      codeDesc: 'NeedApproval',
      data: {
        Response: {
          Data: {
            ApprovalDocID: 12,
          },
        },
      },
    };
    axiosInsStub.resolves(res);
    const showStub = sinon.stub().returns(() => res);
    const componentStub = sinon.stub().resolves({ showApprovalModal: showStub });
    rewire$getComponent(componentStub);
    await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });
    expect(
      showStub.calledWithMatch(12, {
        Data: {
          ApprovalDocID: 12,
        },
      }),
    ).to.be.true;
    expect(showStub.calledOnce).to.be.true;
    restore();
  });
  it('yApiRequest-非0code且codeDesc为NeedApproval没有返回ApprovalDocID', async () => {
    const res = {
      code: 5000,
      codeDesc: 'NeedApproval',
      data: {
        Response: {
          Code: 5000,
        },
      },
    };
    axiosInsStub.resolves(res);
    const showStub = sinon.stub().returns(() => res);
    const componentStub = sinon.stub().resolves({ showApprovalModal: showStub });
    rewire$getComponent(componentStub);
    await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });
    expect(showStub.calledOnce).to.be.true;
    restore();
  });
  it('yApiRequest-非0code且codeDesc为NeedApproval没有返回Response', async () => {
    const res = {
      code: 5000,
      codeDesc: 'NeedApproval',
      data: {},
    };
    axiosInsStub.resolves(res);
    const showStub = sinon.stub().returns(() => res);
    const componentStub = sinon.stub().resolves({ showApprovalModal: showStub });
    rewire$getComponent(componentStub);
    await tcesdk.api.yApiRequest({
      serviceType: '1',
      action: 'action',
      version: '2',
      language: 'zh-cn',
    });
    expect(showStub.calledOnce).to.be.true;
    restore();
  });
});
