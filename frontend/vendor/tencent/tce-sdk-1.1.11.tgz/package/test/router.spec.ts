import * as tcesdk from '../src';

describe('tcesdk-router', () => {
  it('router-navigate', () => {
    try {
      tcesdk.router.navigate('path');
    } catch (error) {}
  });
});
