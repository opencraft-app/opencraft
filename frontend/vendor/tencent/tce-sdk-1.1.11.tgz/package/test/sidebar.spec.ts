import * as tcesdk from '../src';

describe('tcesdk-sidebar', () => {
  it('sidebar-show', () => {
    try {
      tcesdk.sidebar.show();
    } catch (error) {}
  });
  it('sidebar-hide', () => {
    try {
      tcesdk.sidebar.hide();
    } catch (error) {}
  });
  it('sidebar-collapse', () => {
    try {
      tcesdk.sidebar.collapse();
    } catch (error) {}
  });
  it('sidebar-expand', () => {
    try {
      tcesdk.sidebar.expand();
    } catch (error) {}
  });
  it('sidebar-expandAllMenu', () => {
    try {
      tcesdk.sidebar.expandAllMenu();
    } catch (error) {}
  });
  it('sidebar-hideMenuItem', () => {
    try {
      tcesdk.sidebar.hideMenuItem('');
    } catch (error) {}
  });
  it('sidebar-customHeaderMenuItem', () => {
    try {
      tcesdk.sidebar.customHeaderMenuItem('' as any);
    } catch (error) {}
  });
});
