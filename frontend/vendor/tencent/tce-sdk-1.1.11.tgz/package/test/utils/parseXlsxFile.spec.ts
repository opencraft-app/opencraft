/* eslint-disable @typescript-eslint/no-unused-expressions */
import chai from 'chai';
import * as tcesdk from '../../src';
import sinon from 'sinon';
// @ts-ignore
import { rewire$getXlsx } from 'src/utils';
import chaiAsPromised from 'chai-as-promised';

chai.use(chaiAsPromised);
const { expect } = chai;

describe('tcesdk-util', () => {
  let fakeXlsxInstance;
  beforeEach(() => {
    // 创建假的 xlsx 实例
    fakeXlsxInstance = {
      read: sinon.stub(),
      utils: {
        sheet_to_json: sinon.stub(),
      },
    };
    const stubFunc = sinon.stub().resolves(fakeXlsxInstance);
    rewire$getXlsx(stubFunc);
  });

  afterEach(() => {
    sinon.restore();
  });

  it('should resolve with headers and rows when sheet is not empty', async () => {
    // 设置假数据和预期输出
    const fakeWorkbook = {
      SheetNames: ['Sheet1'],
      Sheets: {
        Sheet1: {},
      },
    };
    const fakeData = [
      { col1: 'data1', col2: 'data2' },
      { col1: 'data3', col2: 'data4' },
    ];
    const expectedHeaders = ['col1', 'col2'];
    const expectedRows = [
      ['data1', 'data2'],
      ['data3', 'data4'],
    ];

    // 配置假的方法
    fakeXlsxInstance.read.returns(fakeWorkbook);
    fakeXlsxInstance.utils.sheet_to_json.returns(fakeData);

    // 执行函数
    const file = new Blob([], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const result = await tcesdk.utils.parseXlsxFile(file as File);

    // 断言
    expect(result).to.deep.equal({
      headers: expectedHeaders,
      rows: expectedRows,
    });
  });

  it('should reject with "Sheet is empty" when sheet is empty', async () => {
    // 设置假数据
    const fakeWorkbook = {
      SheetNames: ['Sheet1'],
      Sheets: {
        Sheet1: {},
      },
    };
    const fakeData = [];

    // 配置假的方法
    fakeXlsxInstance.read.returns(fakeWorkbook);
    fakeXlsxInstance.utils.sheet_to_json.returns(fakeData);

    // 执行函数
    const file = new Blob([], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    try {
      await tcesdk.utils.parseXlsxFile(file as File);
      expect.fail('Expected function to reject');
    } catch (error) {
      expect(error).to.equal('Sheet is empty');
    }
  });
});
