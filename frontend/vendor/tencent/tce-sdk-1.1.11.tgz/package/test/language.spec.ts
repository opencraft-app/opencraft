import { expect } from 'chai';
import * as tcesdk from '../src';
// @ts-ignore
import { rewire$getConfigSync } from '../src/common/config';
import sinon from 'sinon';

describe('tcesdk-language', () => {
  beforeEach(() => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud',
      languageList: [
        {
          default: true,
          name: 'zh-CN',
        },
        {
          default: false,
          name: 'en-US',
        },
      ],
      planLanguageList: [
        {
          default: true,
          name: 'zh-CN',
        },
        {
          default: false,
          name: 'zh-HK',
        },
        {
          default: false,
          name: 'en-US',
        },
      ],
    };
    window.I18N_CONFIG = {
      langList: [
        {
          default: true,
          name: 'zh-CN',
        },
        {
          default: false,
          name: 'en-US',
        },
      ],
      tceLanguage: 'zh-CN',
    };
  });

  it('获取语言列表-控制台', () => {
    const langList = tcesdk.language.getLangList();
    expect(langList.length).equal(2);
    expect(langList[0].name).equal('zh-CN');
  });

  it('获取语言列表-其他页面', () => {
    window.TCE_GLOBAL_CONSTANT.platformType = 'tce_tcloud_login';
    const langList = tcesdk.language.getLangList();
    expect(langList.length).equal(2);
    expect(langList[0].name).equal('zh-CN');
  });

  it('获取语言列表-其他页面-为空的时候', () => {
    window.TCE_GLOBAL_CONSTANT = undefined as any;
    const langList = tcesdk.language.getLangList();
    expect(langList.length).equal(0);
  });

  it('getLangList--null', () => {
    (window as any).I18N_CONFIG = undefined;
    const langList = tcesdk.language.getLangList();
    expect(langList.length).equal(0);
  });

  it('获取规划的语言列表', () => {
    const langList = tcesdk.language.getPlanLangList();
    expect(langList.length).equal(3);
    expect(langList[1].name).equal('zh-HK');
  });

  it('获取规划的语言列表--为空', () => {
    window.TCE_GLOBAL_CONSTANT = undefined as any;
    const langList = tcesdk.language.getPlanLangList();
    expect(langList.length).equal(0);
  });

  it('getCurrentLang', () => {
    const lang = tcesdk.language.getCurrentLang();
    expect(lang).equal('zh-CN');
  });

  it('getCurrentLang-1', () => {
    const { href } = window.location;
    history.pushState({}, '', `${window.location.href}?Language=en-US`);
    const lang = tcesdk.language.getCurrentLang();
    expect(lang).equal('en-US');
    history.pushState({}, '', `${href}`);
  });

  it('getCurrentLang_2', () => {
    (window as any).I18N_CONFIG = undefined;
    const lang = tcesdk.language.getCurrentLang();
    expect(lang).equal('zh-CN');
  });

  it('getCurrentLang_2_login', () => {
    (window as any).I18N_CONFIG = undefined;
    window.TCE_GLOBAL_CONSTANT.platformType = 'tce_tcloud_login';
    const lang = tcesdk.language.getCurrentLang();
    expect(lang).equal('zh-CN');
  });

  it('getCurrentLang_2_login_null', () => {
    (window as any).I18N_CONFIG = undefined;
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud_login',
      languageList: [
        {
          default: false,
          name: 'zh-CN',
        },
        {
          default: false,
          name: 'en-US',
        },
      ],
    };
    const lang = tcesdk.language.getCurrentLang();
    expect(lang).equal('zh-CN');
  });

  it('getCurrentLang_3', () => {
    (window as any).I18N_CONFIG = {
      langList: [
        {
          default: false,
          name: 'zh-CN',
        },
        {
          default: true,
          name: 'en-US',
        },
      ],
    };
    const lang = tcesdk.language.getCurrentLang();
    expect(lang).equal('en-US');
  });
  it('getCurrentLang_4', () => {
    (window as any).I18N_CONFIG = {
      langList: [
        {
          default: false,
          name: 'en-US',
        },
      ],
    };
    const lang = tcesdk.language.getCurrentLang();
    expect(lang).equal('zh-CN');
  });
  it('getCurrentLang_5', () => {
    (window as any).I18N_CONFIG = undefined;
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud_login',
      languageList: [
        {
          default: true,
          name: 'zh-CN',
        },
        {
          default: false,
          name: 'en-US',
        },
      ],
    };
    tcesdk.constants.JS_COOKIE.set('tce_language', 'en-US');
    const lang = tcesdk.language.getCurrentLang();
    expect(lang).equal('en-US');
  });
  it('getCurrentLang_6', () => {
    (window as any).I18N_CONFIG = undefined;
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud_login',
      languageList: [
        {
          default: true,
          name: 'zh-CN',
        },
      ],
    };
    tcesdk.constants.JS_COOKIE.set('tce_language', 'en-US');
    const lang = tcesdk.language.getCurrentLang();
    expect(lang).equal('zh-CN');
  });
  it('getCurrentLang_7', () => {
    (window as any).I18N_CONFIG = undefined;
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud_login',
      languageList: [],
    };
    tcesdk.constants.JS_COOKIE.set('tce_language', 'en-US');
    const lang = tcesdk.language.getCurrentLang();
    expect(lang).equal('en-US');
  });
  it('getCurrentLang_8', () => {
    (window as any).I18N_CONFIG = undefined;
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud_login',
      languageList: [],
    };
    tcesdk.constants.JS_COOKIE.set('tce_language', '');
    const lang = tcesdk.language.getCurrentLang();
    expect(lang).equal('zh-CN');
  });
  it('getCurrentLang_9', () => {
    (window as any).I18N_CONFIG = undefined;
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud_login',
      languageList: [
        {
          default: false,
          name: 'zh-CN',
        },
        {
          default: false,
          name: 'en-US',
        },
      ],
    };
    tcesdk.constants.JS_COOKIE.set('tce_language', 'abc');
    const lang = tcesdk.language.getCurrentLang();
    expect(lang).equal('zh-CN');
  });

  it('getCurrentLang-兼容购买页380前的代码', () => {
    (window as any).I18N_CONFIG = undefined;
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud_buy',
      languageList: [
        { default: true, id: 'zh-CN', name: '中文' },
        { default: false, id: 'en-US', name: 'English' },
      ],
    };
    tcesdk.constants.JS_COOKIE.set('tce_language', 'abc');
    const lang = tcesdk.language.getCurrentLang();
    expect(lang).equal('zh-CN');
  });

  it('getCurrentLang-兼容购买页380前的代码', () => {
    (window as any).I18N_CONFIG = undefined;
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud_buy',
      languageList: [
        { default: false, id: 'zh-CN', name: '中文' },
        { default: false, id: 'en-US', name: 'English' },
      ],
    };
    tcesdk.constants.JS_COOKIE.set('tce_language', 'abc');
    const lang = tcesdk.language.getCurrentLang();
    expect(lang).equal('zh-CN');
  });

  it('getCurrentCurrency-正常情况下获取默认货币', () => {
    (window as any).I18N_CONFIG = {
      langList: [
        {
          default: true,
          name: 'zh-CN',
          currency: '元',
        },
        {
          default: false,
          name: 'en-US',
          currency: 'CNY',
        },
      ],
    };
    const currency = tcesdk.language.getCurrentCurrency();
    expect(currency).equal('元');
  });
  it('getCurrentCurrency-正常情况下英文环境下获取默认货币', () => {
    (window as any).I18N_CONFIG.tceLanguage = 'en-US';
    const currency = tcesdk.language.getCurrentCurrency();
    expect(currency).equal('CNY');
  });
  it('getCurrentCurrency-正常情况下其他语言环境下获取默认货币', () => {
    (window as any).I18N_CONFIG.tceLanguage = 'other';
    const currency = tcesdk.language.getCurrentCurrency();
    expect(currency).equal('CNY');
  });
  it('getCurrentCurrency-没有Currency字段的情况下在中文环境获取默认货币', () => {
    (window as any).I18N_CONFIG = {
      langList: [
        {
          default: true,
          name: 'zh-CN',
        },
        {
          default: false,
          name: 'en-US',
        },
      ],
    };
    const currency = tcesdk.language.getCurrentCurrency();
    expect(currency).equal('元');
  });
  it('getCurrentCurrency-没有Currency字段的情况下在英文环境获取默认货币', () => {
    (window as any).I18N_CONFIG = {
      langList: [
        {
          default: true,
          name: 'zh-CN',
        },
        {
          default: false,
          name: 'en-US',
        },
      ],
      tceLanguage: 'en-US',
    };
    const currency = tcesdk.language.getCurrentCurrency();
    expect(currency).equal('CNY');
  });
  it('getCurrentCurrency-没有langList的情况下获取默认货币', () => {
    (window as any).I18N_CONFIG = { tceLanguage: 'zh-CN' };
    const currency = tcesdk.language.getCurrentCurrency();
    expect(currency).equal('元');
  });
  it('getCurrentCurrency-没有langList的情况下英文环境获取默认货币', () => {
    (window as any).I18N_CONFIG = { tceLanguage: 'en-US' };
    const currency = tcesdk.language.getCurrentCurrency();
    expect(currency).equal('CNY');
  });

  it('getTcloudLangList-没有langList的情况下英文环境获取默认货币', () => {
    (window as any).I18N_CONFIG = { tceLanguage: 'en-US' };
    const currency = tcesdk.language.getCurrentCurrency();
    expect(currency).equal('CNY');
  });

  it('getCurrentCurrencyInfo-获取默认货币信息', () => {
    (window as any).I18N_CONFIG = {
      langList: [
        {
          default: true,
          name: 'zh-CN',
          currency: '元',
        },
        {
          default: false,
          name: 'en-US',
          currency: 'CNY',
        },
      ],
    };
    const { symbol, code, words } = tcesdk.language.getCurrentCurrencyInfo();
    expect(symbol).equal('¥');
    expect(code).equal('CNY');
    expect(words).equal('人民币');
  });

  it('getCurrentCurrencyInfo-获取默认英文情况下的货币信息', () => {
    (window as any).I18N_CONFIG.tceLanguage = 'en-US';
    const { symbol, code, words } = tcesdk.language.getCurrentCurrencyInfo();
    expect(symbol).equal('¥');
    expect(code).equal('CNY');
    expect(words).equal('人民币');
  });

  it('getCurrentCurrencyInfo-获取其他货币信息', () => {
    (window as any).I18N_CONFIG = {
      langList: [
        {
          default: true,
          name: 'zh-CN',
          currency: '美元',
        },
        {
          default: false,
          name: 'en-US',
          currency: 'USD',
        },
      ],
    };
    const { symbol, code, words } = tcesdk.language.getCurrentCurrencyInfo();
    expect(symbol).equal('$');
    expect(words).equal('美元');
    expect(code).equal('USD');
  });

  it('should return languages from config when available', () => {
    const expectedLangs = ['en', 'fr', 'de'];
    const configStub = sinon.stub().returns({ defaultLang: 'en', langList: expectedLangs });
    rewire$getConfigSync(configStub);

    const result = tcesdk.language.getTcloudLangList();

    expect(result).to.deep.equal([
      { default: true, name: 'en' },
      { default: false, name: 'fr' },
      { default: false, name: 'de' },
    ]);
  });

  it('should return default language as specified', () => {
    const expectedLangs = ['en', 'fr', 'de'];
    const configStub = sinon.stub().returns({ defaultLang: 'fr', langList: expectedLangs });
    rewire$getConfigSync(configStub);

    const result = tcesdk.language.getTcloudLangList();

    expect(result.find((lang) => lang.default)).to.deep.equal({ default: true, name: 'fr' });
  });

  it('should call getPlanLangList when langList is empty', () => {
    const configStub = sinon.stub().returns({ defaultLang: 'en', langList: [] });
    rewire$getConfigSync(configStub);
    const result = tcesdk.language.getTcloudLangList();

    expect(result).to.deep.equal(tcesdk.language.getPlanLangList());
  });

  it('should handle undefined config gracefully', () => {
    const configStub = sinon.stub().returns(undefined);
    rewire$getConfigSync(configStub);

    const result = tcesdk.language.getTcloudLangList();

    expect(result).to.deep.equal(tcesdk.language.getPlanLangList());
  });
});
