import { str2hex } from 'src/common';
/* eslint-disable @typescript-eslint/no-unused-expressions */
import sinon from 'sinon';
import chai from 'chai';
import chaiAsPromised from 'chai-as-promised';
import { LANG } from '../src/common/lang';
import { getSource, isJiGuang, isTcsOcloudLogin } from '../src/common/index';
import { MODAL } from '../src/common/modal';
// @ts-ignore
import { restore, toLoginPageForExpired, rewire$toLoginPageForExpired } from 'src/platform';
import TceSDKException from 'src/common/tce_sdk_exception';
import { assets, loc, getCustomizeIcon, getFullAssetUrl } from 'src/common/util';
import { getSdkRouterMap } from 'src/common/constants';
chai.use(chaiAsPromised);
const { expect } = chai;

describe('tcesdk-common', () => {
  const imgcache = 'imgcache.example.com';
  const base = 'example.com';
  let reload;
  before(() => {
    reload = sinon.stub(loc, 'locationReload').returns();
  });
  after(() => {
    reload?.restore();
  });
  afterEach(() => {
    // @ts-ignore
    window.TCE_GLOBAL_CONSTANT = undefined;
  });
  it('lang-循环返回空字符', () => {
    const langResult = LANG.t('.');
    expect(langResult).equal('');
  });

  it('getSource-throwErr', async () => {
    const getSourceSpy = sinon.spy(getSource);
    expect(getSourceSpy('')).eventually.be.rejected;
  });

  it('getSource-css-throwErr', async () => {
    const getSourceSpy = sinon.spy(getSource);
    expect(getSourceSpy('//imgcache.yfm6.tcepoc.fsphere.cn/tcloud/sdk-tag/tce-sdk-tag.zh.css')).eventually.be.rejected;
    document.head.removeChild(document.getElementsByTagName('link')[0]);
  });

  it('modal', async () => {
    const logoutSpy = sinon.spy();
    rewire$toLoginPageForExpired(logoutSpy);
    const modalStub = sinon.spy(MODAL, 'showPreLoginModal');
    modalStub(
      LANG.t('ipLimitModal.title'),
      LANG.t('ipLimitModal.description').replace('{{ip}}', 1),
      toLoginPageForExpired,
    );
    document.getElementsByTagName('button')[0].click();
    expect(logoutSpy.calledOnce);
    modalStub.restore();
    restore();
  });

  it('modal-close', async () => {
    const modalStub = sinon.spy(MODAL, 'showPreLoginModal');
    modalStub(
      LANG.t('ipLimitModal.title'),
      LANG.t('ipLimitModal.description').replace('{{ip}}', 1),
      toLoginPageForExpired,
    );
    MODAL.hide();
    expect(modalStub.calledOnce);
    modalStub.restore();
  });

  it('tce_sdk_exception--toLocaleString', async () => {
    const error = new TceSDKException('toLocaleString');
    expect(error.toLocaleString()).to.equal('[TceSDKException]message:toLocaleString');
  });

  it('util-getXlsxUrl', async () => {
    window.TCE_GLOBAL_CONSTANT = { imgcacheHost: 'imgcache.yfm18.tcepoc.fsphere.cn' };
    const xlsxUrl = assets.getXlsxUrl();
    expect(xlsxUrl).to.equal('//imgcache.yfm18.tcepoc.fsphere.cn/common/tcesdk/assets/xlsx/xlsx.full.min.js');
  });

  it('util-getXlsxUrl-staticAssets中tcesdk为空', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      imgcacheHost: 'imgcache.yfm18.tcepoc.fsphere.cn',
      staticAssets: {
        tcesdk: undefined,
      },
    };
    const xlsxUrl = assets.getXlsxUrl();
    expect(xlsxUrl).to.equal('//imgcache.yfm18.tcepoc.fsphere.cn/common/tcesdk/assets/xlsx/xlsx.full.min.js');
  });

  it('util-getXlsxUrl-staticAssets中tcesdk不为空', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      imgcacheHost: 'imgcache.yfm18.tcepoc.fsphere.cn',
      staticAssets: {
        tcesdk: {
          path: 'test/sdk',
        },
      },
    };
    const xlsxUrl = assets.getXlsxUrl();
    expect(xlsxUrl).to.equal('//imgcache.yfm18.tcepoc.fsphere.cn/test/sdk/xlsx/xlsx.full.min.js');
  });

  it('util-getXlsxUrl--tcs场景下', async () => {
    window.TCE_GLOBAL_CONSTANT = { imgcacheHost: 'imgcache.yfm18.tcepoc.fsphere.cn', platformType: 'tcs_ocloud' };
    const xlsxUrl = assets.getXlsxUrl();
    expect(xlsxUrl).to.equal('//imgcache.yfm18.tcepoc.fsphere.cn/tcs-common/tcesdk/assets/xlsx/xlsx.full.min.js');
  });

  it('util-getXlsxUrl-TCE_GLOBAL_CONSTANt为空', async () => {
    // @ts-ignore
    window.TCE_GLOBAL_CONSTANT = undefined;
    const xlsxUrl = assets.getXlsxUrl();
    expect(xlsxUrl).to.equal('//undefined/common/tcesdk/assets/xlsx/xlsx.full.min.js');
  });

  it('util-getCryptoJSUrl', async () => {
    window.TCE_GLOBAL_CONSTANT = { imgcacheHost: 'imgcache.yfm18.tcepoc.fsphere.cn' };
    const xlsxUrl = assets.getCryptoJSUrl();
    expect(xlsxUrl).to.equal('//imgcache.yfm18.tcepoc.fsphere.cn/common/tcesdk/assets/crypto-js/crypto-js.min.js');
  });

  it('util-getCryptoJSUrl-TCE_GLOBAL_CONSTANt为空', async () => {
    // @ts-ignore
    window.TCE_GLOBAL_CONSTANT = undefined;
    const xlsxUrl = assets.getCryptoJSUrl();
    expect(xlsxUrl).to.equal('//undefined/common/tcesdk/assets/crypto-js/crypto-js.min.js');
  });

  it('util-getJsencryptUrl', async () => {
    window.TCE_GLOBAL_CONSTANT = { imgcacheHost: 'imgcache.yfm18.tcepoc.fsphere.cn' };
    const xlsxUrl = assets.getJsencryptUrl();
    expect(xlsxUrl).to.equal('//imgcache.yfm18.tcepoc.fsphere.cn/common/tcesdk/assets/jsencrypt/jsencrypt.min.js');
  });

  it('util-getJsencryptUrl-TCE_GLOBAL_CONSTANt为空', async () => {
    // @ts-ignore
    window.TCE_GLOBAL_CONSTANT = undefined;
    const xlsxUrl = assets.getJsencryptUrl();
    expect(xlsxUrl).to.equal('//undefined/common/tcesdk/assets/jsencrypt/jsencrypt.min.js');
  });

  it('util-getSMUrl', async () => {
    window.TCE_GLOBAL_CONSTANT = { imgcacheHost: 'imgcache.yfm18.tcepoc.fsphere.cn' };
    const xlsxUrl = assets.getSMUrl();
    expect(xlsxUrl).to.equal('//imgcache.yfm18.tcepoc.fsphere.cn/common/tcesdk/assets/smencrypt/SM.js');
  });

  it('util-getSMUrl-TCE_GLOBAL_CONSTANt为空', async () => {
    // @ts-ignore
    window.TCE_GLOBAL_CONSTANT = undefined;
    const xlsxUrl = assets.getSMUrl();
    expect(xlsxUrl).to.equal('//undefined/common/tcesdk/assets/smencrypt/SM.js');
  });

  it('common-is-not-jiguang', async () => {
    // window.TCE_GLOBAL_CONSTANT = { platformType: PLATFORM_TYPE.JIGUANG };
    expect(isJiGuang()).to.be.false;
  });

  it('getSdkRouterMap-返回的对象值全都带上imgcacheHost', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      imgcacheHost: 'imgcache.yfm6.tcepoc.fsphere.cn',
    };
    window.__sdkRouterByTce = {
      // @ts-ignore
      'EDGE VNC': {
        content: '//imgcache.yfm6.tcepoc.fsphere.cn/common/edge-vnc/edge-vnc._lang_.js',
        component: 'rx-app-tea2',
      },
    };

    const values = Object.values(getSdkRouterMap()).reduce(
      (prev, item) => [...prev, item?.content, ...(item?.css || [])],
      [] as any[],
    );
    console.log(values, 'sdkRouterValues');
    expect(values.every((item) => item.includes(window.TCE_GLOBAL_CONSTANT.imgcacheHost))).to.be.true;
  });

  it('getCustomizeIcon-产品icon', () => {
    const icon = getCustomizeIcon('xxxxx.svg', 'product', '2143214321');
    expect(icon).to.equal('xxxxx.svg');
  });
  it('getCustomizeIcon-产品icon-1', () => {
    const icon = getCustomizeIcon('1', 'product', 'abcdefg');
    expect(icon).to.equal('abcdefg.svg');
  });
  it('getCustomizeIcon-产品icon-默认值', () => {
    const icon = getCustomizeIcon('', 'product', 'sdafsdaf');
    expect(icon).to.equal('default_product.svg');
  });

  it('getCustomizeIcon-产品icon-默认值-null', () => {
    const icon = getCustomizeIcon('null', 'product', 'sdfafsdaf');
    expect(icon).to.equal('default_product.svg');
  });
  it('getCustomizeIcon-产品icon-默认值-undefined', () => {
    const icon = getCustomizeIcon('undefined', 'product', 'dfwafwe');
    expect(icon).to.equal('default_product.svg');
  });
  it('getCustomizeIcon-菜单icon', () => {
    const icon = getCustomizeIcon('xxxxx.svg', 'menu', 'dasfsafdsaf');
    expect(icon).to.equal('xxxxx.svg');
  });
  it('getCustomizeIcon-菜单icon--默认', () => {
    const icon = getCustomizeIcon('', 'menu', 'dsafdsaf');
    expect(icon).to.equal('default_menu.svg');
  });
  it('getCustomizeIcon-tab分类icon', () => {
    const icon = getCustomizeIcon('xxxxx.svg', 'type', 'dsafdsaf');
    expect(icon).to.equal('xxxxx.svg');
  });
  it('getCustomizeIcon-tab分类icon--默认', () => {
    const icon = getCustomizeIcon('', 'type', 'dsafdsaf');
    expect(icon).to.equal('default_product_type.svg');
  });
  it('should return the same URL for absolute URLs', () => {
    const url = 'https://absolute.example.com/path/to/file';
    expect(getFullAssetUrl(url, imgcache, base)).to.equal(url);
  });

  it('should return the same URL for empty or missing URLs', () => {
    expect(getFullAssetUrl('', imgcache, base)).to.equal('');
  });

  it('should replace domain-placeholder.com with base and prepend imgcache', () => {
    const url = '/path/to/file';
    const expectedUrl = `//${imgcache}/path/to/file`.replace('domain-placeholder.com', base);
    expect(getFullAssetUrl(url, imgcache, base)).to.equal(expectedUrl);
  });

  it('should process an array of URLs', () => {
    const urls = ['https://absolute.example.com/path/to/file', '/path/to/file'];
    const expectedUrls = [
      'https://absolute.example.com/path/to/file',
      `//${imgcache}/path/to/file`.replace('domain-placeholder.com', base),
    ];
    expect(getFullAssetUrl(urls, imgcache, base)).to.deep.equal(expectedUrls);
  });

  it('isTcsOcloudLogin', () => {
    // @ts-ignore
    window.TCE_GLOBAL_CONSTANT = undefined;
    const isTCSLogin = isTcsOcloudLogin();
    expect(isTCSLogin).equal(false);
  });

  it('str2hex-字符串转16进制', () => {
    const hex = str2hex('123456789');
    expect(hex).equal('313233343536373839');
  });

  it('str2hex-字符串转16进制-换行场景', () => {
    const hex = str2hex(`-----BEGIN RSA PRIVATE KEY-----
    MIIEpQIBAAKCAQEAqGjAzhA/fxVvE8boTdZ44soUWE7/lEDBKw4UtYAfVM03d1O3
    tNBuc7l5rxrXg9OMDEe6TdsFPWS/s0I+XOo3i3s5zNfWkDva8XO5uWYvtm+TgKzK
    992wf8ECgYEA3exmww42BTVbZkYomR8DczsnSp1N5CoLIYV/ROO8fY2NhhXXV/4I
    re9RDiuRPjfu8ByXjjKgjFTPEB+a7Ry2Rd+uhNCx7Ka2A4CAcuvnWwjrUpE8GH5w
    grpmZn1YQzRhhe4zeITEMsMzuSa4g3InoYvClgy0e/9WselgCvcibn8=
    -----END RSA PRIVATE KEY-----`);
    expect(hex).equal(
      '2d2d2d2d2d424547494e205253412050524956415445204b45592d2d2d2d2d0a202020204d4949457051494241414b434151454171476a417a68412f667856764538626f54645a3434736f555745372f6c4544424b77345574594166564d303364314f330a20202020744e427563376c357278725867394f4d44456536546473465057532f7330492b584f6f33693373357a4e66576b44766138584f3575575976746d2b54674b7a4b0a202020203939327766384543675945413365786d77773432425456625a6b596f6d523844637a736e5370314e35436f4c4959562f524f4f386659324e68685858562f34490a202020207265395244697552506a6675384279586a6a4b676a46545045422b613752793252642b75684e4378374b6132413443416375766e57776a7255704538474835770a202020206772706d5a6e3159517a52686865347a654954454d734d7a755361346733496e6f5976436c677930652f395773656c6743766369626e383d0a202020202d2d2d2d2d454e44205253412050524956415445204b45592d2d2d2d2d',
    );
  });

  it('str2hex-字符串转16进制-中文场景', () => {
    const hex = str2hex(`1你好`);
    expect(hex).equal('31e4bda0e5a5bd');
  });

  it('str2hex-字符串转16进制-特殊字符', () => {
    const hex = str2hex('¿'); // 其 Unicode 码点在 0x0080 到 0x07FF 之间
    expect(hex).equal('c2bf');
  });

  it('str2hex-字符串转16进制-特殊字符', () => {
    const hex = str2hex('😀'); // 其 Unicode 码点在 0x10000 到 0x10FFFF 之间
    expect(hex).equal('f09f9880');
  });

  it('str2hex-字符串转16进制-低版本浏览器', () => {
    window.TextEncoder = null as any;
    const hex = str2hex('123456789');
    expect(hex).equal('313233343536373839');
  });

  it('str2hex-字符串转16进制-换行场景-低版本浏览器', () => {
    window.TextEncoder = null as any;
    const hex = str2hex(`-----BEGIN RSA PRIVATE KEY-----
    MIIEpQIBAAKCAQEAqGjAzhA/fxVvE8boTdZ44soUWE7/lEDBKw4UtYAfVM03d1O3
    tNBuc7l5rxrXg9OMDEe6TdsFPWS/s0I+XOo3i3s5zNfWkDva8XO5uWYvtm+TgKzK
    992wf8ECgYEA3exmww42BTVbZkYomR8DczsnSp1N5CoLIYV/ROO8fY2NhhXXV/4I
    re9RDiuRPjfu8ByXjjKgjFTPEB+a7Ry2Rd+uhNCx7Ka2A4CAcuvnWwjrUpE8GH5w
    grpmZn1YQzRhhe4zeITEMsMzuSa4g3InoYvClgy0e/9WselgCvcibn8=
    -----END RSA PRIVATE KEY-----`);
    expect(hex).equal(
      '2d2d2d2d2d424547494e205253412050524956415445204b45592d2d2d2d2d0a202020204d4949457051494241414b434151454171476a417a68412f667856764538626f54645a3434736f555745372f6c4544424b77345574594166564d303364314f330a20202020744e427563376c357278725867394f4d44456536546473465057532f7330492b584f6f33693373357a4e66576b44766138584f3575575976746d2b54674b7a4b0a202020203939327766384543675945413365786d77773432425456625a6b596f6d523844637a736e5370314e35436f4c4959562f524f4f386659324e68685858562f34490a202020207265395244697552506a6675384279586a6a4b676a46545045422b613752793252642b75684e4378374b6132413443416375766e57776a7255704538474835770a202020206772706d5a6e3159517a52686865347a654954454d734d7a755361346733496e6f5976436c677930652f395773656c6743766369626e383d0a202020202d2d2d2d2d454e44205253412050524956415445204b45592d2d2d2d2d',
    );
  });

  it('str2hex-字符串转16进制-中文场景-低版本浏览器', () => {
    window.TextEncoder = null as any;
    const hex = str2hex(`1你好`);
    expect(hex).equal('31e4bda0e5a5bd');
  });

  it('str2hex-字符串转16进制-特殊字符-低版本浏览器', () => {
    window.TextEncoder = null as any;
    const hex = str2hex('¿'); // 其 Unicode 码点在 0x0080 到 0x07FF 之间
    expect(hex).equal('c2bf');
  });

  it('str2hex-字符串转16进制-特殊字符-低版本浏览器', () => {
    window.TextEncoder = null as any;
    const hex = str2hex('😀'); // 其 Unicode 码点在 0x10000 到 0x10FFFF 之间
    expect(hex).equal('f09f9880');
  });
});
