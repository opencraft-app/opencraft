/* eslint-disable @typescript-eslint/no-unused-expressions */
import sinon from 'sinon';
import * as tcesdk from '../src';
import chai from 'chai';
import chaiAsPromised from 'chai-as-promised';
import {
  g_config_data_ocloud,
  g_config_data_tcloud,
  g_config_data_tcloud_buy,
  g_config_data_tcloud_buy_next,
  g_config_data_tcloud_buy_productmenu_null,
  g_platform_config_platformTabs,
  g_product_config_data,
} from './mock/config';
import { TCS_CONFIG_ENTRIES } from './mock/config_tcs';
// @ts-ignore
import { rewire$yApiRequest, restore } from '../src/api';
import { loc } from 'src/common';
import { getComponentCommitId } from 'src/common/customize';
import { g_config_data } from './mock/config_next';
chai.use(chaiAsPromised);
const { expect } = chai;

describe('tcesdk-config', () => {
  const getConfigRes = {
    Data: {
      Description: '  租户端是否打开注册功能  ',
      EntryID: 5,
      Ext: { ValueType: 'str', Version: '1.0' },
      Key: 'tcloud_allow_reg',
      ModifyTime: 1622103537,
      Namespace: 'tcenter_base',
      RawValue: 'true',
      Source: '',
      Value: 'val',
      Version: 1,
    },
  };
  before(() => {
    window.g_product_config_data = g_product_config_data;
  });

  afterEach(() => {
    restore();
  });

  it('getCustomizeProductConfig', () => {
    const config = tcesdk.config.getCustomizeProductConfig('barad', 'ocloud', 'IS_OPEN_ALRAM_NOTIFY');
    expect(config[0]).equal('N');
  });

  it('getCustomizeProductConfigMultiple', () => {
    const config = tcesdk.config.getCustomizeProductConfigMultiple([
      { product: 'barad', platform: 'ocloud', code: 'IS_OPEN_ALRAM_NOTIFY' },
      { product: 'bmp', platform: 'tcloud', code: 'usePayMode' },
      { product: 'barad1', platform: 'tcloud', code: 'usePayMode' },
    ]);
    expect(config).deep.equal([
      { product: 'barad', platform: 'ocloud', code: 'IS_OPEN_ALRAM_NOTIFY', value: ['N'] },
      { product: 'bmp', platform: 'tcloud', code: 'usePayMode', value: ['0'] },
      { product: 'barad1', platform: 'tcloud', code: 'usePayMode', value: [] },
    ]);
  });

  it('getCustomizeProductConfig_1', () => {
    const config = tcesdk.config.getCustomizeProductConfig('barad1', 'ocloud', 'IS_OPEN_ALRAM_NOTIFY');
    expect(config.toString()).equal([].toString());
  });

  it('getCustomizeProductConfig_2', () => {
    window.g_product_config_data = undefined;
    const config = tcesdk.config.getCustomizeProductConfig('barad1', 'ocloud', 'IS_OPEN_ALRAM_NOTIFY');
    expect(config.toString()).equal([].toString());
  });

  it('getConfigAsync-格式为string', async () => {
    const yApiRes = sinon.stub().resolves({ res: getConfigRes, err: undefined });
    rewire$yApiRequest(yApiRes);
    const res = await tcesdk.config.getConfigAsync('Namespace', 'key');
    expect(res.res.Value).equal('val');
  });

  it('getConfigAsync-格式为boolean-value为true', async () => {
    const yApiRes = sinon.stub().resolves({
      res: {
        Data: {
          ...getConfigRes,
          Value: true,
          Ext: { ...getConfigRes.Data.Ext, ValueType: 'boolean' },
        },
      },
      err: undefined,
    });
    rewire$yApiRequest(yApiRes);
    const res = await tcesdk.config.getConfigAsync('Namespace', 'key');
    expect(res.res.Value).equal(true);
  });

  it('getConfigAsync-格式为boolean-value为false', async () => {
    const yApiRes = sinon.stub().resolves({
      res: {
        Data: {
          ...getConfigRes,
          Value: false,
          Ext: { ...getConfigRes.Data.Ext, ValueType: 'boolean' },
        },
      },
      err: undefined,
    });
    rewire$yApiRequest(yApiRes);
    const res = await tcesdk.config.getConfigAsync('Namespace', 'key');
    expect(res.res.Value).equal(false);
  });

  it('getConfigAsync-格式为json', async () => {
    const obj = {
      test: 'test',
      key: 'key',
    };
    const yApiRes = sinon.stub().resolves({
      res: {
        Data: {
          ...getConfigRes.Data,
          Value: obj,
          Ext: { ...getConfigRes.Data.Ext, ValueType: 'obj' },
        },
      },
      err: undefined,
    });
    rewire$yApiRequest(yApiRes);
    const res = await tcesdk.config.getConfigAsync('Namespace', 'key');
    expect(res.res.Value).deep.equal(obj);
  });

  it('getConfigAsync-格式为number', async () => {
    const yApiRes = sinon.stub().resolves({
      res: {
        Data: {
          ...getConfigRes,
          Value: 12,
          Ext: { ...getConfigRes.Data.Ext, ValueType: 'num' },
        },
      },
      err: undefined,
    });
    rewire$yApiRequest(yApiRes);
    expect((await tcesdk.config.getConfigAsync('Namespace', 'key')).res.Value).equal(12);
  });

  it('getConfigAsync-异常情况-res为undefined', async () => {
    const yApiRes = sinon.stub().resolves({
      res: undefined,
      err: undefined,
    });
    rewire$yApiRequest(yApiRes);
    expect((await tcesdk.config.getConfigAsync('Namespace', 'key')).res.Value).equal(undefined);
  });

  it('getConfigAsync-异常情况-res.Data为undefined', async () => {
    const yApiRes = sinon.stub().resolves({
      res: { Data: undefined },
      err: undefined,
    });
    rewire$yApiRequest(yApiRes);
    expect((await tcesdk.config.getConfigAsync('Namespace', 'key')).res.Value).equal(undefined);
  });

  it('getConfigAsync-异常情况-res.Data.Value为undefined', async () => {
    const yApiRes = sinon.stub().resolves({
      res: { Data: { Value: undefined } },
      err: undefined,
    });
    rewire$yApiRequest(yApiRes);
    expect((await tcesdk.config.getConfigAsync('Namespace', 'key')).res.Value).equal(undefined);
  });

  it('getConfigAsyncByNs', async () => {
    const data = [
      {
        EntryID: 10067,
        Key: 'clb_bandwidth_default',
        RawValue: '234',
        Value: 234,
        Namespace: 'clb',
        Description: 'CLB默认初始带宽配置值。默认初始带宽配置值必须在CLB带宽上限规格配置的范围内',
        Version: 18,
        ModifyTime: 1709609808,
        Source: '',
        Ext: {
          Label: {
            'en-US': 'CLB default initial bandwidth',
            'zh-CN': 'CLB默认初始带宽配置值',
          },
          ValueType: 'num',
          Version: '1.0',
        },
      },
      {
        EntryID: 10066,
        Key: 'clb_bandwidth',
        RawValue: '[123,1234]',
        Value: [123, 1234],
        Namespace: 'clb',
        Description: 'CLB带宽上限规格。数组第一个值为带宽下限，第二个值为带宽上限,单位是Mbps',
        Version: 17,
        ModifyTime: 1709609623,
        Source: '',
        Ext: {
          Label: {
            'en-US': 'CLB bandwidth config',
            'zh-CN': 'CLB带宽上限规格',
          },
          ValueType: 'obj',
          Version: '1.0',
        },
      },
    ];
    const yApiRes = sinon.stub().resolves({
      res: {
        Data: {
          Data: data,
        },
      },
      err: undefined,
    });
    rewire$yApiRequest(yApiRes);
    expect(await tcesdk.config.getConfigAsyncByNs('clb')).deep.equal({
      res: data,
      err: undefined,
    });
  });

  it('getConfigAsyncByNs-异常情况-有err', async () => {
    const resp = {
      res: undefined,
      err: {
        code: 100,
      },
    };
    const yApiRes = sinon.stub().resolves(resp);
    rewire$yApiRequest(yApiRes);
    expect(await tcesdk.config.getConfigAsyncByNs('clb')).deep.equal({
      res: [],
      err: {
        code: 100,
      },
    });
  });

  it('getConfigAsyncByNs-异常情况-res为undefined', async () => {
    const yApiRes = sinon.stub().resolves({
      res: undefined,
      err: undefined,
    });
    rewire$yApiRequest(yApiRes);
    expect(await tcesdk.config.getConfigAsyncByNs('clb')).deep.equal({
      res: [],
      err: undefined,
    });
  });

  it('getConfigAsyncByNs-异常情况-res.Data为undefined', async () => {
    const yApiRes = sinon.stub().resolves({
      res: { Data: undefined },
      err: undefined,
    });
    rewire$yApiRequest(yApiRes);
    expect(await tcesdk.config.getConfigAsyncByNs('clb')).deep.equal({
      res: [],
      err: undefined,
    });
  });

  it('getConfigAsyncByNs-异常情况-res.Data.Value为undefined', async () => {
    const yApiRes = sinon.stub().resolves({
      res: { Data: { Data: undefined } },
      err: undefined,
    });
    rewire$yApiRequest(yApiRes);
    expect(await tcesdk.config.getConfigAsyncByNs('clb')).deep.equal({
      res: [],
      err: undefined,
    });
  });

  it('getConfigAsyncMultiple', async () => {
    const yApiRes = sinon.stub().resolves({
      res: {
        Data: {
          Data: [
            {
              EntryID: 10067,
              Key: 'clb_bandwidth_default',
              RawValue: '234',
              Value: 234,
              Namespace: 'clb',
              Description: 'CLB默认初始带宽配置值。默认初始带宽配置值必须在CLB带宽上限规格配置的范围内',
              Version: 18,
              ModifyTime: 1709609808,
              Source: '',
              Ext: {
                Label: {
                  'en-US': 'CLB default initial bandwidth',
                  'zh-CN': 'CLB默认初始带宽配置值',
                },
                ValueType: 'num',
                Version: '1.0',
              },
            },
            {
              EntryID: 10066,
              Key: 'clb_bandwidth',
              RawValue: '[123,1234]',
              Value: [123, 1234],
              Namespace: 'clb',
              Description: 'CLB带宽上限规格。数组第一个值为带宽下限，第二个值为带宽上限,单位是Mbps',
              Version: 17,
              ModifyTime: 1709609623,
              Source: '',
              Ext: {
                Label: {
                  'en-US': 'CLB bandwidth config',
                  'zh-CN': 'CLB带宽上限规格',
                },
                ValueType: 'obj',
                Version: '1.0',
              },
            },
          ],
        },
      },
      err: undefined,
    });
    rewire$yApiRequest(yApiRes);
    expect(
      await tcesdk.config.getConfigAsyncMultiple([
        { namespace: 'clb', key: 'clb_bandwidth_default' },
        { namespace: 'clb', key: 'clb_bandwidth' },
      ]),
    ).deep.equal([
      { namespace: 'clb', key: 'clb_bandwidth_default', value: 234 },
      { namespace: 'clb', key: 'clb_bandwidth', value: [123, 1234] },
    ]);
  });

  it('getConfigAsyncMultiple-异常情况-有err', async () => {
    const yApiRes = sinon.stub().resolves({
      res: undefined,
      err: {
        code: 100,
      },
    });
    rewire$yApiRequest(yApiRes);
    expect(
      await tcesdk.config.getConfigAsyncMultiple([
        { namespace: 'clb', key: 'clb_bandwidth_default' },
        { namespace: 'clb', key: 'clb_bandwidth' },
      ]),
    ).deep.equal([
      { namespace: 'clb', key: 'clb_bandwidth_default', value: undefined },
      { namespace: 'clb', key: 'clb_bandwidth', value: undefined },
    ]);
  });

  it('getConfigAsyncMultiple-异常情况-res为undefined', async () => {
    const yApiRes = sinon.stub().resolves({
      res: undefined,
      err: undefined,
    });
    rewire$yApiRequest(yApiRes);
    expect(
      await tcesdk.config.getConfigAsyncMultiple([
        { namespace: 'clb', key: 'clb_bandwidth_default' },
        { namespace: 'clb', key: 'clb_bandwidth' },
      ]),
    ).deep.equal([
      { namespace: 'clb', key: 'clb_bandwidth_default', value: undefined },
      { namespace: 'clb', key: 'clb_bandwidth', value: undefined },
    ]);
  });

  it('getConfigAsyncMultiple-异常情况-res.Data为undefined', async () => {
    const yApiRes = sinon.stub().resolves({
      res: { Data: undefined },
      err: undefined,
    });
    rewire$yApiRequest(yApiRes);
    expect(
      await tcesdk.config.getConfigAsyncMultiple([
        { namespace: 'clb', key: 'clb_bandwidth_default' },
        { namespace: 'clb', key: 'clb_bandwidth' },
      ]),
    ).deep.equal([
      { namespace: 'clb', key: 'clb_bandwidth_default', value: undefined },
      { namespace: 'clb', key: 'clb_bandwidth', value: undefined },
    ]);
  });

  it('getConfigAsyncMultiple-异常情况-res.Data.Value为undefined', async () => {
    const yApiRes = sinon.stub().resolves({
      res: { Data: { Value: undefined } },
      err: undefined,
    });
    rewire$yApiRequest(yApiRes);
    expect(
      await tcesdk.config.getConfigAsyncMultiple([
        { namespace: 'clb', key: 'clb_bandwidth_default' },
        { namespace: 'clb', key: 'clb_bandwidth' },
      ]),
    ).deep.equal([
      { namespace: 'clb', key: 'clb_bandwidth_default', value: undefined },
      { namespace: 'clb', key: 'clb_bandwidth', value: undefined },
    ]);
  });

  it('setConfig-格式为boolean', async () => {
    const yApiRes = sinon.stub().resolves({
      res: {
        Data: {
          ...getConfigRes,
          Value: true,
          Ext: { ...getConfigRes.Data.Ext, ValueType: 'bool' },
        },
      },
      err: undefined,
    });
    rewire$yApiRequest(yApiRes);
    await tcesdk.config.setConfig('Namespace', 'key', true);
    expect(
      yApiRes.calledWith({
        serviceType: 'foyo',
        action: 'DrawSwitches',
        version: '2021-04-28',
        data: {
          Params: [
            {
              Namespace: 'Namespace',
              Key: 'key',
              Value: JSON.stringify({ Model: true }),
            },
          ],
          Language: 'zh-CN',
        },
      }),
    ).to.be.true;
  });

  it('setConfig-格式为number', async () => {
    const yApiRes = sinon.stub().resolves({
      res: {
        Data: {
          ...getConfigRes,
          Value: 'true',
          Ext: { ...getConfigRes.Data.Ext, ValueType: 'num' },
        },
      },
      err: undefined,
    });
    rewire$yApiRequest(yApiRes);
    await tcesdk.config.setConfig('Namespace', 'key', 12);
    expect(
      yApiRes.calledWith({
        serviceType: 'foyo',
        action: 'DrawSwitches',
        version: '2021-04-28',
        data: {
          Params: [
            {
              Namespace: 'Namespace',
              Key: 'key',
              Value: JSON.stringify({ Model: 12 }),
            },
          ],
          Language: 'zh-CN',
        },
      }),
    ).to.be.true;
  });

  it('setConfig-格式为arr', async () => {
    const yApiRes = sinon.stub().resolves({
      res: {
        Data: {
          ...getConfigRes,
          Value: ['true'],
          Ext: { ...getConfigRes.Data.Ext, ValueType: 'arr' },
        },
      },
      err: undefined,
    });
    rewire$yApiRequest(yApiRes);
    await tcesdk.config.setConfig('Namespace', 'key', ['true']);
    expect(
      yApiRes.calledWith({
        serviceType: 'foyo',
        action: 'DrawSwitches',
        version: '2021-04-28',
        data: {
          Params: [
            {
              Namespace: 'Namespace',
              Key: 'key',
              Value: JSON.stringify({ Model: ['true'] }),
            },
          ],
          Language: 'zh-CN',
        },
      }),
    ).to.be.true;
  });

  it('getConfigSync-string', async () => {
    window.TCE_GLOBAL_CONSTANT = {};
    window.TCE_GLOBAL_CONSTANT.foyoConfig = [
      {
        Description: '密码控件mac下license',
        Key: 'license-mac',
        Namespace: 'tcenter-password-control',
        Value: 'InRlc3QwMDIi',
      },
    ];
    const val = tcesdk.config.getConfigSync('tcenter-password-control', 'license-mac');
    expect(val).to.be.equal('test002');
  });

  it('getConfigSync-boolean', async () => {
    window.TCE_GLOBAL_CONSTANT.foyoConfig = [
      {
        Description: '租户端是否展示右上角费用菜单',
        Key: 'tcloud-show-fee-menu',
        Namespace: 'tcenter',
        Value: 'dHJ1ZQ==',
      },
    ];
    const val = tcesdk.config.getConfigSync('tcenter', 'tcloud-show-fee-menu');
    expect(val).to.be.equal(true);
  });

  it('getConfigSync-boolean', async () => {
    window.TCE_GLOBAL_CONSTANT.foyoConfig = [
      {
        Description: 'test_array',
        Key: 'tcloud-statistics-array2',
        Namespace: 'tcenter',
        Value: 'WzEyLDIzLDMzNF0=',
      },
    ];
    const val = tcesdk.config.getConfigSync('tcenter', 'tcloud-statistics-array2');
    expect(val).to.be.deep.equal([12, 23, 334]);
  });

  it('getConfigSync-异常-window.TCE_GLOBAL_CONSTANT.foyoConfig为undefined', async () => {
    window.TCE_GLOBAL_CONSTANT.foyoConfig = undefined;
    const val = tcesdk.config.getConfigSync('tcenter', 'tcloud-statistics-array2');
    expect(val).equal(undefined);
  });

  it('getConfigSync-没找到指定的config', async () => {
    const getConfigSpy = sinon.spy(tcesdk.config.getConfigSync);
    try {
      tcesdk.config.getConfigSync('tcenter', 'tcloud-show-fee-menu');
    } catch {
      expect(getConfigSpy).to.have.throw();
    }
  });

  it('getElasticConfig-ok', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      elasticConfig: {
        tce_log_server: 'http://tets.com',
      },
      customizeGlobalConfig: {
        test: '123456',
      },
    };
    const tce_log_server = tcesdk.config.getElasticConfig('tce_log_server');
    expect(tce_log_server).equal('http://tets.com');
  });

  it('getCustomizeGlobalConfig-ok', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      elasticConfig: {
        tce_log_server: 'http://tets.com',
      },
      customizeGlobalConfig: {
        test: '123456',
      },
    };
    const test = tcesdk.config.getCustomizeGlobalConfig('test');
    expect(test).equal('123456');
  });

  it('getElasticConfig-elasticConfig-null', async () => {
    window.TCE_GLOBAL_CONSTANT = {};
    const tce_log_server = tcesdk.config.getElasticConfig('tce_log_server');
    expect(tce_log_server).equal(undefined);
  });

  it('getElasticConfig-异常情况--TCE_GLOBAL_CONSTANT为undefined', async () => {
    window.TCE_GLOBAL_CONSTANT = undefined as any;
    const tce_log_server = tcesdk.config.getElasticConfig('tce_log_server');
    expect(tce_log_server).equal(undefined);
  });

  it('getCustomizeGlobalConfig-customizeGlobalConfig-null', async () => {
    window.TCE_GLOBAL_CONSTANT = {};
    const test = tcesdk.config.getCustomizeGlobalConfig('test');
    expect(test).equal('');
  });

  it('getCustomizeGlobalConfig-异常情况--TCE_GLOBAL_CONSTANT为undefined', async () => {
    window.TCE_GLOBAL_CONSTANT = undefined as any;
    const test = tcesdk.config.getCustomizeGlobalConfig('test');
    expect(test).equal('');
  });

  it('getElasticConfig-key-null', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      elasticConfig: {},
    };
    const tce_log_server = tcesdk.config.getElasticConfig('tce_log_server');
    expect(tce_log_server).equal(undefined);
  });

  it('getCustomizeGlobalConfig-key-null', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      customizeGlobalConfig: {},
    };
    const test = tcesdk.config.getCustomizeGlobalConfig('test');
    expect(test).equal('');
  });

  it('getCustomizeAccessTabs-获取客制化接入tabs信息-运营端', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_ocloud',
    };
    window.g_config_data = g_config_data_ocloud;
    const customizeAccesses = tcesdk.config.getCustomizeAccessTabs();
    expect(customizeAccesses.length).equal(3);
  });

  it('getCustomizeAccessTabs-获取客制化接入tabs信息-运营端--异常情况--gConfigData为空', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_ocloud',
    };
    window.g_config_data = undefined;
    const customizeAccesses = tcesdk.config.getCustomizeAccessTabs();
    expect(customizeAccesses.length).equal(0);
  });

  it('getCustomizeAccessTabs-获取客制化接入tabs信息-运营端--异常情况--platformType为空', () => {
    window.TCE_GLOBAL_CONSTANT = {};
    window.g_config_data = g_config_data_ocloud;
    const customizeAccesses = tcesdk.config.getCustomizeAccessTabs();
    expect(customizeAccesses.length).equal(3);
    expect(customizeAccesses[0].platform).equal('');
  });

  it('getCustomizeAccessTabs-获取客制化接入tabs信息-租户端', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud',
    };
    window.g_config_data = g_config_data_tcloud;
    window.g_platform_config_platformTabs = g_platform_config_platformTabs;
    const customizeAccesses = tcesdk.config.getCustomizeAccessTabs();
    expect(customizeAccesses.length).equal(1);
  });

  it('getCustomizeAccessTabs-获取客制化接入tabs信息-购买页', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud_buy',
    };
    window.g_config_data = g_config_data_tcloud_buy;
    const customizeAccesses = tcesdk.config.getCustomizeAccessTabs();
    expect(customizeAccesses.length).equal(1);
  });

  it('getCustomizeAccessTabs-获取客制化接入tabs信息-TCS', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tcs_ocloud',
    };
    window.TCS = {
      config: {
        entrys: TCS_CONFIG_ENTRIES,
      },
    };
    const customizeAccesses = tcesdk.config.getCustomizeAccessTabs();
    const { types, ...rest } = customizeAccesses[0];
    expect(rest).to.be.deep.equal({
      code: 'tab_ocloud_manager',
      name: '平台管理',
      platform: 'tcs_ocloud',
      href: undefined,
      visible: true,
    });
    expect(customizeAccesses.length).equal(3);
  });

  it('getCustomizeAccessTabs-获取客制化接入tabs信息-TCS-customNav场景', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tcs_ocloud',
    };
    window.TCS = {
      config: {
        entrys: TCS_CONFIG_ENTRIES,
      },
    };
    const customizeAccesses = tcesdk.config.getCustomizeAccessTabs();
    const { modules, name } = customizeAccesses[1]?.types.find(({ code }) => code === 'tsf-manager') || {};
    expect(name).equal('微服务平台(TSF)');
    expect(modules?.length).equal(2);
    expect(modules?.[0].name).equal('微服务控制台');
    expect(modules?.[0].href).equal('/tsf/index');
    expect(modules?.[1].uuid).equal('x78KiXWX');
  });

  it('getCustomizeAccessTabs-获取客制化接入tabs信息-TCS-config不存在', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tcs_ocloud',
    };
    window.TCS = {};
    const customizeAccesses = tcesdk.config.getCustomizeAccessTabs();
    expect(customizeAccesses.length).equal(0);
  });

  it('getCustomizeAccessTabs-获取客制化接入tabs信息-TCS-常量不存在', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tcs_ocloud',
    };
    window.TCS = undefined;
    const customizeAccesses = tcesdk.config.getCustomizeAccessTabs();
    expect(customizeAccesses.length).equal(0);
  });

  it('getCustomizeAccessInfoByRouterKey-根据路由key获取接入信息-TCS-不存在', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tcs_ocloud',
      consoleHost: 'o.cas.3tcs221.tcecloud.fsphere.cn',
      imgcacheHost: 'imgcache.cas.3tcs221.tcecloud.fsphere.cn',
    };
    window.TCS = {
      config: {
        entrys: TCS_CONFIG_ENTRIES,
      },
    };
    const customizeAccessInfo = tcesdk.config.getCustomizeAccessInfoByRouterKey('vpcdns');
    expect(customizeAccessInfo).to.be.deep.equal(undefined);
  });

  it('getCustomizeAccessInfoByRouterKey-根据路由key获取接入信息-TCS-js接入', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tcs_ocloud',
      consoleHost: 'o.cas.3tcs221.tcecloud.fsphere.cn',
      imgcacheHost: 'imgcache.cas.3tcs221.tcecloud.fsphere.cn',
    };
    window.TCS = {
      config: {
        entrys: TCS_CONFIG_ENTRIES,
      },
    };
    const customizeAccessInfo = tcesdk.config.getCustomizeAccessInfoByRouterKey('info');
    const { menus, ...rest } = customizeAccessInfo!;
    expect(menus!.length).to.equal(4);
    expect(rest).to.be.deep.equal({
      uuid: 'C_GLK3JJ',
      routerKey: 'info',
      title: '消息查询',
      fullscreen: false,
      icon: 'C_GLK3JJ.svg',
      iconActive: 'C_GLK3JJ_act.svg',
      type: 'js',
      asset: {
        js: '//imgcache.cas.3tcs221.tcecloud.fsphere.cn/tcs-ocloud/info/info.js#rx-app-tea2',
        css: [],
      },
    });
    const tagCustomizeAccessInfo = tcesdk.config.getCustomizeAccessInfoByRouterKey('tag-web');
    expect(tagCustomizeAccessInfo?.asset?.js).equal(
      '//imgcache.cas.3tcs221.tcecloud.fsphere.cn/tcs-mcloud/tag/tag-web.js#rx-app-tea2',
    );
    expect(tagCustomizeAccessInfo?.uuid).equal('Lzf8p0Lb');
    expect(tagCustomizeAccessInfo?.title).equal('标签');
    const { uuid } = tagCustomizeAccessInfo?.menus?.[0] || {};
    expect(uuid).equal('4vK2Jl55');
    const { menus: submenus } = tagCustomizeAccessInfo?.menus?.[1] || {};
    expect(submenus?.[0].uuid).equal('4vK2Jl5512');
    const resCustomizeAccessInfo = tcesdk.config.getCustomizeAccessInfoByRouterKey('resource-mgmt');
    expect(resCustomizeAccessInfo?.asset?.js).equal(
      '//imgcache.cas.3tcs221.tcecloud.fsphere.cn/tcs-ocloud/resource-mgmt/resource-ocloud.js#rx-app-tea2',
    );
  });

  it('getCustomizeAccessInfoByRouterKey-根据路由key获取接入信息-TCS-有二级菜单-取title', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tcs_ocloud',
      consoleHost: 'o.cas.3tcs221.tcecloud.fsphere.cn',
      imgcacheHost: 'imgcache.cas.3tcs221.tcecloud.fsphere.cn',
    };
    window.TCS = {
      config: {
        entrys: TCS_CONFIG_ENTRIES,
      },
    };
    const customizeAccessInfo = tcesdk.config.getCustomizeAccessInfoByRouterKey('logs');
    const { menus } = customizeAccessInfo!;
    expect(menus!.length).to.equal(6);
    expect(menus?.[5].name).to.equal('日志投递');
  });

  it('getCustomizeAccessInfoByRouterKey-根据路由key获取接入信息-TCS-js接入-静态资源绝对路径', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tcs_ocloud',
      consoleHost: 'o.cas.3tcs221.tcecloud.fsphere.cn',
      imgcacheHost: 'imgcache.cas.3tcs221.tcecloud.fsphere.cn',
    };
    window.TCS = {
      config: {
        entrys: TCS_CONFIG_ENTRIES,
      },
    };
    const customizeAccessInfo = tcesdk.config.getCustomizeAccessInfoByRouterKey('ckafka');
    const { menus, ...rest } = customizeAccessInfo!;
    expect(menus!.length).to.equal(3);
    expect(rest).to.be.deep.equal({
      uuid: 'RwkJ1b9W',
      routerKey: 'ckafka',
      title: '消息队列(CKafka)',
      fullscreen: false,
      icon: 'RwkJ1b9W.svg',
      iconActive: 'RwkJ1b9W_act.svg',
      type: 'js',
      asset: {
        js: '//imgcache.cas.3tcs221.tcecloud.fsphere.cn/tcs-ocloud/ckafka/ckafka.zh.js#rx-app-tea2',
        css: [
          '//imgcache.cas.3tcs221.tcecloud.fsphere.cn/tcs-common/monitor-sdk/monitor-sdk.css',
          '//imgcache.cas.3tcs221.tcecloud.fsphere.cn/tcs-ocloud/ckafka/ckafka.zh.css',
        ],
      },
    });
  });

  it('getCustomizeAccessInfoByRouterKey-根据路由key获取接入信息-TCS-js接入-非tea2', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tcs_ocloud',
      consoleHost: 'o.cas.3tcs221.tcecloud.fsphere.cn',
      imgcacheHost: 'imgcache.cas.3tcs221.tcecloud.fsphere.cn',
    };
    window.TCS = {
      config: {
        entrys: TCS_CONFIG_ENTRIES,
      },
    };
    const customizeAccessInfo = tcesdk.config.getCustomizeAccessInfoByRouterKey('strong');
    const { menus, ...rest } = customizeAccessInfo!;
    expect(menus!.length).to.equal(0);
    expect(rest).to.be.deep.equal({
      uuid: '6345169c437bb655c6e3dacd',
      routerKey: 'strong',
      title: '非tea2测试',
      fullscreen: false,
      icon: '6345169c437bb655c6e3dacd.svg',
      iconActive: '6345169c437bb655c6e3dacd_act.svg',
      type: 'js',
      asset: {
        js: '//imgcache.cas.3tcs221.tcecloud.fsphere.cn/tcs-ocloud/devops/devops.js',
        css: [],
      },
    });
  });

  it('getCustomizeAccessInfoByRouterKey-根据路由key获取接入信息-TCS-iframe接入', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tcs_ocloud',
      consoleHost: 'o.cas.3tcs221.tcecloud.fsphere.cn',
      imgcacheHost: 'imgcache.cas.3tcs221.tcecloud.fsphere.cn',
    };
    window.TCS = {
      config: {
        entrys: TCS_CONFIG_ENTRIES,
      },
    };
    const customizeAccessInfo = tcesdk.config.getCustomizeAccessInfoByRouterKey('chitu');
    const { menus, ...rest } = customizeAccessInfo!;
    expect(menus!.length).to.equal(1);
    expect(rest).to.be.deep.equal({
      uuid: 'qnyLkise',
      routerKey: 'chitu',
      title: 'TDSQL',
      fullscreen: false,
      icon: 'qnyLkise.svg',
      iconActive: 'qnyLkise_act.svg',
      type: 'iframe',
      iframeUrl: '//tdsql.o.cas.3tcs221.tcecloud.fsphere.cn/tdsqlpcloud',
    });
  });

  it('getCustomizeAccessInfoByRouterKey-根据路由key获取接入信息-运营端', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_ocloud',
    };
    window.g_config_data = g_config_data_ocloud;
    const customizeAccessInfo = tcesdk.config.getCustomizeAccessInfoByRouterKey('vpcdns');
    expect(customizeAccessInfo?.title).equal('VPCDNS');
  });

  it('getCustomizeAccessInfoByRouterKey-根据路由key获取接入信息-运营端--iframe接入', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_ocloud',
    };
    window.g_config_data = g_config_data_ocloud;
    const customizeAccessInfo = tcesdk.config.getCustomizeAccessInfoByRouterKey('cos/alert-configure');
    expect(customizeAccessInfo?.title).equal('对象存储(COS)');
  });

  it('getCustomizeAccessInfoByRouterKey-根据路由key获取接入信息-运营端--异常情况', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_ocloud',
    };
    window.g_config_data = undefined;
    const customizeAccessInfo = tcesdk.config.getCustomizeAccessInfoByRouterKey('vpcdns');
    expect(customizeAccessInfo?.title ?? '').equal('');
  });

  it('getCustomizeAccessInfoByRouterKey-根据路由key获取接入信息-租户端', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud',
    };
    window.g_config_data = g_config_data_tcloud;
    const customizeAccessInfo = tcesdk.config.getCustomizeAccessInfoByRouterKey('cvm');
    expect(customizeAccessInfo?.title).equal('云服务器(CVM)');
  });

  it('getCustomizeAccessInfoByRouterKey-根据路由key获取接入信息-租户端-路由key排序', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud',
    };
    window.g_config_data = g_config_data_tcloud;
    const customizeAccessInfo = tcesdk.config.getCustomizeAccessInfoByRouterKey('cvm/snapshot');
    expect(customizeAccessInfo?.title).equal('云服务器(CVM)1');
  });

  it('getCustomizeAccessInfoByRouterKey-根据路由key获取接入信息-租户端-二级', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud',
    };
    window.g_config_data = g_config_data_tcloud;
    const customizeAccessInfo = tcesdk.config.getCustomizeAccessInfoByRouterKey('cvm/cbs');
    expect(customizeAccessInfo?.title).equal('云服务器(CVM)');
  });

  it('getCustomizeAccessInfoByRouterKey-根据路由key获取接入信息-租户端-路由key不存在', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud',
    };
    window.g_config_data = g_config_data_tcloud;
    const customizeAccessInfo = tcesdk.config.getCustomizeAccessInfoByRouterKey('cvm111');
    expect(customizeAccessInfo).to.equal(undefined);
  });

  it('getCustomizeAccessInfoByRouterKey-根据路由key获取接入信息-租户端-submenu不存在', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud',
    };
    window.g_config_data = g_config_data_tcloud;
    const customizeAccessInfo = tcesdk.config.getCustomizeAccessInfoByRouterKey('cvm1');
    expect(customizeAccessInfo).to.be.deep.equal({
      routerKey: 'cvm1',
      type: 'js',
      asset: { js: '//imgcache.tcenter-dev.tcecqpoc.fsphere.cn/tcloud/cvm/cvm.js#rx-app-tea2', css: undefined },
    });
  });

  it('getCustomizeAccessInfoByRouterKey-根据路由key获取接入信息-购买页', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud_buy',
    };
    window.g_config_data = g_config_data_tcloud_buy;
    const customizeAccessInfo = tcesdk.config.getCustomizeAccessInfoByRouterKey('cvm');
    expect(customizeAccessInfo?.title).equal('云服务器');
  });

  it('getCustomizeAccessInfoByRouterKey-根据路由key获取接入信息-购买页-异常情况-路由key不存在', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud_buy',
    };
    window.g_config_data = g_config_data_tcloud_buy;
    const customizeAccessInfo = tcesdk.config.getCustomizeAccessInfoByRouterKey('hello');
    expect(customizeAccessInfo).equal(undefined);
  });

  it('getCustomizeAccessInfoByRouterKey-根据路由key获取接入信息-购买页-异常情况-productmenu不存在', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud_buy',
    };
    window.g_config_data = g_config_data_tcloud_buy_productmenu_null;
    const customizeAccessInfo = tcesdk.config.getCustomizeAccessInfoByRouterKey('cvm');
    expect(customizeAccessInfo?.routerKey).equal('cvm');
  });

  it('getCurrentPageAccessInfo-获取当前页面接入信息-tcs', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tcs_ocloud',
      consoleHost: 'o.cas.3tcs221.tcecloud.fsphere.cn',
      imgcacheHost: 'imgcache.cas.3tcs221.tcecloud.fsphere.cn',
    };
    window.TCS = {
      config: {
        entrys: TCS_CONFIG_ENTRIES,
      },
    };
    window.g_config_data = g_config_data_ocloud;
    const customizeAccessInfo = tcesdk.config.getCurrentPageAccessInfo('/config-management/menus');
    expect(customizeAccessInfo!.menu).to.be.deep.equal({
      uuid: 'aQ047kOq',
      name: '菜单列表',
      href: '/config-management/menus',
      icon: 'aQ047kOq.svg',
      iconActive: 'aQ047kOq.active.svg',
    });
    const { menus, ...rest } = customizeAccessInfo!.access;
    expect(menus!.length).to.equal(3);
    expect(rest).to.be.deep.equal({
      uuid: 'BllmXaDb',
      routerKey: 'config-management',
      title: '平台偏好设置',
      fullscreen: false,
      icon: 'BllmXaDb.svg',
      iconActive: 'BllmXaDb_act.svg',
      type: 'js',
      asset: {
        js: '//imgcache.cas.3tcs221.tcecloud.fsphere.cn/tcs-ocloud/config-management/config-management.js#rx-app-tea2',
        css: [],
      },
    });
  });

  it('getCurrentPageAccessInfo-获取当前页面接入信息-tcs-菜单不存在', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tcs_ocloud',
      consoleHost: 'o.cas.3tcs221.tcecloud.fsphere.cn',
      imgcacheHost: 'imgcache.cas.3tcs221.tcecloud.fsphere.cn',
    };
    window.TCS = {
      config: {
        entrys: TCS_CONFIG_ENTRIES,
      },
    };
    window.g_config_data = g_config_data_ocloud;
    const customizeAccessInfo = tcesdk.config.getCurrentPageAccessInfo('/dsfaa');
    expect(customizeAccessInfo).to.be.deep.equal(undefined);
  });

  it('getCurrentPageAccessInfo-获取当前页面接入信息-tcs-路由存在两个', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tcs_ocloud',
      consoleHost: 'o.cas.3tcs221.tcecloud.fsphere.cn',
      imgcacheHost: 'imgcache.cas.3tcs221.tcecloud.fsphere.cn',
    };
    window.TCS = {
      config: {
        entrys: TCS_CONFIG_ENTRIES,
      },
    };
    window.g_config_data = g_config_data_ocloud;
    const customizeAccessInfo = tcesdk.config.getCurrentPageAccessInfo('/strong/test');
    expect(customizeAccessInfo?.menu).to.be.deep.equal(undefined);
  });

  it('getCurrentPageAccessInfo-获取当前页面接入信息-tcs-菜单取更长的', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tcs_ocloud',
      consoleHost: 'o.cas.3tcs221.tcecloud.fsphere.cn',
      imgcacheHost: 'imgcache.cas.3tcs221.tcecloud.fsphere.cn',
    };
    window.TCS = {
      config: {
        entrys: TCS_CONFIG_ENTRIES,
      },
    };
    window.g_config_data = g_config_data_ocloud;
    const customizeAccessInfo = tcesdk.config.getCurrentPageAccessInfo('/taskter/test/href');
    expect(customizeAccessInfo?.menu.href).to.equal('/taskter/test/href');
  });

  it('getCurrentPageAccessInfo-获取当前页面接入信息-运营端-二级菜单场景', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_ocloud',
    };
    window.g_config_data = g_config_data_ocloud;
    const customizeAccessInfo = tcesdk.config.getCurrentPageAccessInfo('/vpc/route-manage');
    expect(customizeAccessInfo?.menu).to.be.deep.equal({
      name: '路由表',
      href: '/vpc/route-manage',
      uuid: 'cda079bcca22733c8d44ffdaa25da388',
      icon: 'default_menu.svg',
      iconActive: 'default_menu_hover.svg',
    });
  });

  it('getCurrentPageAccessInfo-获取当前页面接入信息-运营端-一级菜单场景', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_ocloud',
    };
    window.g_config_data = g_config_data_ocloud;
    const customizeAccessInfo = tcesdk.config.getCurrentPageAccessInfo('/user/capi');
    expect(customizeAccessInfo?.menu?.name).equal('云API密钥');
  });

  it('getCurrentPageAccessInfo-获取当前页面接入信息-运营端-取location.pathname', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_ocloud',
    };
    window.g_config_data = g_config_data_ocloud;
    const locStub = sinon.stub(loc, 'getLocationPath').returns('/user/capi');
    const customizeAccessInfo = tcesdk.config.getCurrentPageAccessInfo();
    expect(customizeAccessInfo?.menu?.name).equal('云API密钥');
    locStub.restore();
  });

  it('getCurrentPageAccessInfo-获取当前页面接入信息-运营端--iframe场景', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_ocloud',
    };
    window.g_config_data = g_config_data_ocloud;
    const customizeAccessInfo = tcesdk.config.getCurrentPageAccessInfo('/cos/alert-configure');
    expect(customizeAccessInfo?.menu?.name).equal('告警配置');
  });

  it('getCurrentPageAccessInfo-获取当前页面接入信息-运营端-多个路由key匹配的场景', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_ocloud',
    };
    window.g_config_data = g_config_data_ocloud;
    const customizeAccessInfo = tcesdk.config.getCurrentPageAccessInfo('/mongodb/instance_list');
    expect(customizeAccessInfo?.menu?.name).equal('副本实例管理');
  });

  it('getCurrentPageAccessInfo-获取当前页面接入信息-运营端-异常情况', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_ocloud',
    };
    window.g_config_data = undefined;
    const customizeAccessInfo = tcesdk.config.getCurrentPageAccessInfo('/vpc/route-manage');
    expect(customizeAccessInfo?.menu?.name ?? '').equal('');
  });

  it('getCurrentPageAccessInfo-获取当前页面接入信息-租户端', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud',
    };
    window.g_config_data = g_config_data_tcloud;
    const customizeAccessInfo = tcesdk.config.getCurrentPageAccessInfo('/cam/settings');
    expect(customizeAccessInfo?.menu?.name).equal('用户设置');
  });

  it('getCurrentPageAccessInfo-获取当前页面接入信息-购买页', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud_buy',
    };
    window.g_config_data = g_config_data_tcloud_buy;
    const customizeAccessInfo = tcesdk.config.getCurrentPageAccessInfo('/lb');
    expect(customizeAccessInfo?.menu?.name).equal('负载均衡');
  });

  it('getCurrentPageAccessInfo-获取当前页面接入信息-购买页', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud_buy',
    };
    window.g_config_data = g_config_data_tcloud_buy_next;
    const customizeAccessInfo = tcesdk.config.getCurrentPageAccessInfo('/lb');
    expect(customizeAccessInfo?.menu?.name).equal('负载均衡');
  });

  it('getCurrentPageAccessInfo-获取当前页面接入信息-购买页-异常情况-productmenu不存在', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud_buy',
    };
    window.g_config_data = g_config_data_tcloud_buy_productmenu_null;
    const customizeAccessInfo = tcesdk.config.getCurrentPageAccessInfo('/lb');
    expect(customizeAccessInfo).equal(undefined);
  });

  it('getCurrentPageAccessInfo-获取当前页面接入信息-购买页-urlPath为/', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud_buy',
    };
    window.g_config_data = g_config_data_tcloud_buy;
    const customizeAccessInfo = tcesdk.config.getCurrentPageAccessInfo('/');
    expect(customizeAccessInfo?.menu?.name ?? '').equal('云服务器');
  });

  it('getCurrentPageAccessInfo-获取当前页面接入信息-购买页-取location.pathname，去长度更长的href', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud_buy',
    };
    window.g_config_data = g_config_data_tcloud_buy;
    const locStub = sinon.stub(loc, 'getLocationPath').returns('/dsauditsaas');
    const customizeAccessInfo = tcesdk.config.getCurrentPageAccessInfo();
    expect(customizeAccessInfo?.menu?.name).equal('数据安全审计-sass低版本');
    locStub.restore();
  });

  it('getProductInfoByUUID-获取当前产品信息-运营端', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_ocloud',
    };
    window.g_config_data = g_config_data_ocloud;
    const currentProduct = tcesdk.config.getProductInfoByUUID('e13cde79b51c77b8e7198e7a5c28a06b');
    expect(currentProduct).to.deep.equal({
      name: '裸金属服务器',
      href: '/bms-operation/modelMgt',
      uuid: 'e13cde79b51c77b8e7198e7a5c28a06b',
      icon: 'e13cde79b51c77b8e7198e7a5c28a06b.svg',
      iconActive: 'e13cde79b51c77b8e7198e7a5c28a06b_hover.svg',
      productCode: 'BMS',
      productName: '裸金属服务器',
    });
  });

  it('getProductInfoByUUID-获取当前产品信息-运营端--不在product中，在submenu中，二级菜单', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_ocloud',
    };
    window.g_config_data = g_config_data_ocloud;
    const currentProduct = tcesdk.config.getProductInfoByUUID('f1f9882769a6982034679b62a76745ec');
    expect(currentProduct).to.deep.equal({
      name: '用户与权限',
      href: '/user',
      uuid: 'f1f9882769a6982034679b62a76745ec',
      icon: 'default_product.svg',
      iconActive: 'default_product_hover.svg',
      productCode: 'TCenter',
      productName: '基础平台',
    });
  });

  it('getProductInfoByUUID-获取当前产品信息-运营端--不在product中，在submenu中，一级菜单', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_ocloud',
    };
    window.g_config_data = g_config_data_ocloud;
    const currentProduct = tcesdk.config.getProductInfoByUUID('48e377181f1b7356b4e1451fc5037019');
    expect(currentProduct).to.deep.equal({
      name: '系统设置',
      href: '/system',
      uuid: '48e377181f1b7356b4e1451fc5037019',
      icon: 'default_product.svg',
      iconActive: 'default_product_hover.svg',
      productCode: 'TCenter',
      productName: '基础平台',
    });
  });

  it('getProductInfoByUUID-获取当前产品信息-运营端--不存在', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_ocloud',
    };
    window.g_config_data = g_config_data_ocloud;
    const currentProduct = tcesdk.config.getProductInfoByUUID('f1f9882769a6982034679b62a76745ec12312');
    expect(currentProduct).to.deep.equal(undefined);
  });

  it('getProductInfoByUUID-获取当前产品信息-租户端', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud',
    };
    window.g_config_data = g_config_data_tcloud;
    const currentProduct = tcesdk.config.getProductInfoByUUID('d57241266018d674850c4e41e303071f');
    expect(currentProduct).to.deep.equal({
      name: '消息中心',
      href: '/message/site',
      uuid: 'd57241266018d674850c4e41e303071f',
      icon: 'default_product.svg',
      iconActive: 'default_product_hover.svg',
      productCode: 'TCenter',
      productName: '基础平台',
    });
  });

  it('getProductInfoByUUID-获取当前产品信息-购买页', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud_buy',
    };
    window.g_config_data = g_config_data_tcloud_buy;
    const currentProduct = tcesdk.config.getProductInfoByUUID('0eac631e39af9280defaebe655fa8148');
    expect(currentProduct).to.deep.equal({
      name: '云服务器',
      href: '/cvm',
      uuid: '0eac631e39af9280defaebe655fa8148',
      icon: 'default_product.svg',
      iconActive: 'default_product_hover.svg',
    });
  });

  it('getMenuInfoByUUID-获取当前菜单信息-运营端', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_ocloud',
    };
    window.g_config_data = g_config_data_ocloud;
    const currentProduct = tcesdk.config.getMenuInfoByUUID('d32b57d91e96eabb56cbb0b4237916b9');
    expect(currentProduct).to.deep.equal({
      name: '客户总览',
      href: '/cloudadvisor/overview',
      uuid: 'd32b57d91e96eabb56cbb0b4237916b9',
      icon: 'default_menu.svg',
      iconActive: 'default_menu_hover.svg',
    });
  });

  it('getMenuInfoByUUID-获取当前菜单信息-运营端-一级菜单包括二级', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_ocloud',
    };
    window.g_config_data = g_config_data_ocloud;
    const currentProduct = tcesdk.config.getMenuInfoByUUID('3188897eceb9ddef13da9042d2ecfe41');
    expect(currentProduct).to.deep.equal({
      name: '售卖管理',
      uuid: '3188897eceb9ddef13da9042d2ecfe41',
      icon: 'default_menu.svg',
      iconActive: 'default_menu_hover.svg',
      menus: [
        {
          name: '售卖可用区管理',
          href: '/tdmysql/sale-zone',
          uuid: '105f2dd4aa04dee5675fd9e0efcc9dff',
          icon: '105f2dd4aa04dee5675fd9e0efcc9dff.svg',
          iconActive: '105f2dd4aa04dee5675fd9e0efcc9dff_hover.svg',
        },
        {
          name: '售卖规格管理',
          href: '/tdmysql/sale-spec',
          uuid: '80612e7a725f143dfe7635295285184e',
          icon: 'default_menu.svg',
          iconActive: 'default_menu_hover.svg',
        },
        {
          name: '售卖版本管理',
          href: '/tdmysql/sale-version',
          uuid: '29da1bcd5495ec808b721728673bc0ef',
          icon: 'default_menu.svg',
          iconActive: 'default_menu_hover.svg',
        },
      ],
    });
  });

  it('getMenuInfoByUUID-获取当前菜单信息-运营端-二级菜单', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_ocloud',
    };
    window.g_config_data = g_config_data_ocloud;
    const currentProduct = tcesdk.config.getMenuInfoByUUID('105f2dd4aa04dee5675fd9e0efcc9dff');
    expect(currentProduct).to.deep.equal({
      name: '售卖可用区管理',
      href: '/tdmysql/sale-zone',
      uuid: '105f2dd4aa04dee5675fd9e0efcc9dff',
      icon: 'default_menu.svg',
      iconActive: 'default_menu_hover.svg',
    });
  });

  it('getMenuInfoByUUID-获取当前菜单信息-运营端-无数据', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_ocloud',
    };
    window.g_config_data = g_config_data_ocloud;
    const currentProduct = tcesdk.config.getMenuInfoByUUID('32143214231423');
    expect(currentProduct).to.deep.equal(undefined);
  });

  it('getMenuInfoByUUID-获取当前菜单信息-租户端', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud',
    };
    window.g_config_data = g_config_data_tcloud;
    const currentProduct = tcesdk.config.getMenuInfoByUUID('7dffdc6a12905ea41a5bb3483f4a5f38');
    expect(currentProduct).to.deep.equal({
      name: '概览',
      href: '/cloudadvisor',
      uuid: '7dffdc6a12905ea41a5bb3483f4a5f38',
      icon: 'default_menu.svg',
      iconActive: 'default_menu_hover.svg',
    });
  });

  it('getMenuInfoByUUID-获取当前菜单信息-购买页', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud_buy',
    };
    window.g_config_data = g_config_data_tcloud_buy;
    const currentProduct = tcesdk.config.getMenuInfoByUUID('d32b57d91e96eabb56cbb0b4237916b9');
    expect(currentProduct).to.deep.equal(undefined);
  });

  it('getAllMenus-获取全部菜单信息-购买页', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud_buy',
    };
    window.g_config_data = g_config_data_tcloud_buy;
    const allMenus = tcesdk.config.getAllMenus();
    expect(allMenus).to.deep.equal([]);
  });

  it('getAllMenus-获取全部菜单信息-租户端', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud',
    };
    window.g_config_data = g_config_data_tcloud;
    const allMenus = tcesdk.config.getAllMenus();
    const filterMenu = allMenus?.find((m) => m.uuid === 'de0b0b372377e853adfc21b23aee2e55');
    expect(filterMenu).to.deep.equal({
      name: '安全概览',
      uuid: 'de0b0b372377e853adfc21b23aee2e55',
      href: '/cwp',
      product: '主机安全',
    });
  });

  it('getAllMenus-获取全部菜单信息-运营端', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_ocloud',
    };
    window.g_config_data = g_config_data_ocloud;
    const allMenus = tcesdk.config.getAllMenus();
    const filterMenu = allMenus?.find((m) => m.uuid === 'd60ab8396000593375b15d652c60edce');
    expect(filterMenu).to.deep.equal({
      name: '实例管理',
      uuid: 'd60ab8396000593375b15d652c60edce',
      href: '/tdmysql',
      product: 'TDSQL_MYSQL版租户运维',
    });
  });

  it('getCustomizeProductList-获取环境产品列表-购买页', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud_buy',
    };
    window.g_config_data = g_config_data_tcloud_buy;
    const productList = tcesdk.config.getCustomizeProductList();
    expect(productList).to.deep.equal([]);
  });

  it('getCustomizeProductList-获取环境产品列表-租户端', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud',
    };
    window.g_config_data = g_config_data_tcloud;
    const productList = tcesdk.config.getCustomizeProductList();
    expect(productList.length).gt(0);
    const filterProduct = productList.find((p) => p.productCode === 'CloudAdvisor');
    expect(filterProduct).to.deep.equal({
      productCode: 'CloudAdvisor',
      productName: '云顾问CloudAdvisor',
      modules: [
        {
          uuid: 'a6ab2d3e9e682687ba2483a22011794c',
          name: '云顾问',
          href: '/cloudadvisor',
          icon: 'default_product.svg',
          iconActive: 'default_product_hover.svg',
          productCode: 'CloudAdvisor',
          productName: '云顾问CloudAdvisor',
        },
      ],
    });
  });

  it('getCustomizeProductList-获取环境产品列表-极光next', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud',
    };
    window.g_config_data = g_config_data;
    const productList = tcesdk.config.getCustomizeProductList();
    expect(productList.length).gt(0);
    const filterProduct = productList.find((p) => p.productCode === 'CBS');
    expect(filterProduct).to.deep.equal({
      productCode: 'CBS',
      productName: '云硬盘(CBS)',
      modules: [],
    });
  });

  it('getCustomizeProductList-获取环境产品列表-运营端', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_ocloud',
    };
    window.g_config_data = g_config_data_ocloud;
    const productList = tcesdk.config.getCustomizeProductList();
    expect(productList.length).gt(0);
    const filterProduct = productList.find((p) => p.productCode === 'CloudAdvisor');
    expect(filterProduct).to.deep.equal({
      productCode: 'CloudAdvisor',
      productName: '云顾问CloudAdvisor',
      modules: [
        {
          uuid: '29c8deff847697fe81ad171704fafbc1',
          name: '云顾问',
          href: '/cloudadvisor',
          icon: 'default_product.svg',
          iconActive: 'default_product_hover.svg',
          productCode: 'CloudAdvisor',
          productName: '云顾问CloudAdvisor',
        },
      ],
    });
  });

  it('getCustomizeProductByCode-获取产品信息-入参为空', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud',
    };
    window.g_config_data = g_config_data_tcloud;
    // @ts-ignore
    const product = tcesdk.config.getCustomizeProductByCode();
    expect(product).to.to.deep.equal(undefined);
  });

  it('getCustomizeProductByCode-获取产品信息', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud',
    };
    window.g_config_data = g_config_data_tcloud;
    const product = tcesdk.config.getCustomizeProductByCode('CloudAdvisor');
    expect(product).to.to.deep.equal({
      productCode: 'CloudAdvisor',
      productName: '云顾问CloudAdvisor',
      modules: [
        {
          uuid: 'a6ab2d3e9e682687ba2483a22011794c',
          name: '云顾问',
          href: '/cloudadvisor',
          icon: 'default_product.svg',
          iconActive: 'default_product_hover.svg',
          productCode: 'CloudAdvisor',
          productName: '云顾问CloudAdvisor',
        },
      ],
    });
  });

  it('getCustomizeIcon-获取客制化ICON的完整地址', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud',
      imgcacheHost: 'imgcache.tcenter-dev.tcecqpoc.fsphere.cn',
    };
    const iconUrl = tcesdk.config.getCustomizeIconUrl('default_product.svg');
    expect(iconUrl).to.equal('//imgcache.tcenter-dev.tcecqpoc.fsphere.cn/customize/cache/img/icon/default_product.svg');
  });

  it('getCustomizeIcon-获取客制化ICON的完整地址-tcs-默认icon', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tcs_ocloud',
      imgcacheHost: 'imgcache.tcenter-dev.tcecqpoc.fsphere.cn',
    };
    const iconUrl = tcesdk.config.getCustomizeIconUrl('default_product.svg');
    expect(iconUrl).to.equal('//imgcache.tcenter-dev.tcecqpoc.fsphere.cn/tcs-common/config/img/default_product.svg');
  });

  it('getCustomizeIcon-获取客制化ICON的完整地址-tcs-非默认icon', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tcs_ocloud',
      imgcacheHost: 'imgcache.tcenter-dev.tcecqpoc.fsphere.cn',
    };
    const iconUrl = tcesdk.config.getCustomizeIconUrl('1232131.svg');
    expect(iconUrl).to.equal('//imgcache.tcenter-dev.tcecqpoc.fsphere.cn/tcs-common/platform/vendor/icons/1232131.svg');
  });

  it('getCustomizeIcon-获取客制化ICON的完整地址--icon已经是url地址', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud',
      imgcacheHost: 'imgcache.tcenter-dev.tcecqpoc.fsphere.cn',
    };
    const iconUrl = tcesdk.config.getCustomizeIconUrl(
      '//imgcache.m18.tcecqpoc.fsphere.cn/customize/cache/img/icon/default_product.svg',
    );
    expect(iconUrl).to.equal('//imgcache.m18.tcecqpoc.fsphere.cn/customize/cache/img/icon/default_product.svg');
  });

  it('getCustomizeIcon-获取客制化ICON的完整地址--icon已经是url地址--https', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud',
      imgcacheHost: 'imgcache.tcenter-dev.tcecqpoc.fsphere.cn',
    };
    const iconUrl = tcesdk.config.getCustomizeIconUrl(
      'https://imgcache.m18.tcecqpoc.fsphere.cn/customize/cache/img/icon/default_product.svg',
    );
    expect(iconUrl).to.equal('https://imgcache.m18.tcecqpoc.fsphere.cn/customize/cache/img/icon/default_product.svg');
  });

  it('getCustomizeIcon-获取客制化ICON的完整地址--icon已经是url地址--http', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: 'tce_tcloud',
      imgcacheHost: 'imgcache.tcenter-dev.tcecqpoc.fsphere.cn',
    };
    const iconUrl = tcesdk.config.getCustomizeIconUrl(
      'http://imgcache.m18.tcecqpoc.fsphere.cn/customize/cache/img/icon/default_product.svg',
    );
    expect(iconUrl).to.equal('http://imgcache.m18.tcecqpoc.fsphere.cn/customize/cache/img/icon/default_product.svg');
  });

  it('应当返回正确的CommitId', () => {
    // 假设getCustomizeConfig返回的配置对象
    window.g_config_data.frontendComponentDeployInfo = {
      deployInfo: { testKey: 'testCommitId' },
      staticResourceCache: true,
    };

    const commitId = getComponentCommitId('testKey');
    // 使用chai的expect API进行断言
    expect(commitId).to.equal('testCommitId');
  });

  it('getCustomizeProductLoginModalConfig', () => {
    window.TCE_GLOBAL_CONSTANT = {
      loginCustomizeInfo: {
        loginSetting: {
          loginTitle: 'TencentTCS',
        },
      },
    };
    const config = tcesdk.config.getCustomizeProductLoginModalConfig('loginTitle');
    expect(config).equal('TencentTCS');
  });

  it('getCustomizeProductLoginModalConfig-should return null when loginCustomizeInfo is undefined', () => {
    window.TCE_GLOBAL_CONSTANT = {};
    const config = tcesdk.config.getCustomizeProductLoginModalConfig('loginTitle');
    expect(config).equal(null);
  });

  it('getCustomizeProductLoginModalConfig-should return null when code is not found', () => {
    window.TCE_GLOBAL_CONSTANT = {
      loginCustomizeInfo: {
        key1: {
          code1: 'value1',
        },
        key2: {
          code2: 'value2',
        },
      },
    };
    const config = tcesdk.config.getCustomizeProductLoginModalConfig('code3');
    expect(config).equal(null);
  });
});
