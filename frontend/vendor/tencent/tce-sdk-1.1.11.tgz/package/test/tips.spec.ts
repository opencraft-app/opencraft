import * as tcesdk from '../src';

describe('tcesdk-tips', () => {
  it('tips-showLoading', () => {
    try {
      tcesdk.tips.showLoading();
    } catch (error) {}
  });
  it('tips-hideLoading', () => {
    try {
      tcesdk.tips.hideLoading();
    } catch (error) {}
  });
  it('tips-success', () => {
    try {
      tcesdk.tips.success('操作成功');
    } catch (error) {}
  });
  it('tips-error', () => {
    try {
      tcesdk.tips.error('操作失败');
    } catch (error) {}
  });
  it('tips-success-dur', () => {
    try {
      tcesdk.tips.success('操作成功', 1000);
    } catch (error) {}
  });
  it('tips-error-dur', () => {
    try {
      tcesdk.tips.error('操作失败', 1000);
    } catch (error) {}
  });
});
