/* eslint-disable @typescript-eslint/no-unused-expressions */
import { expect } from 'chai';
import sinon from 'sinon';
import { getComponent } from '../src/component';
// @ts-ignore
import { rewire$getSource, restore } from '../src/common';
import { resetSourceCache } from '../src/common';
import { PLATFORM_TYPE } from 'src/platform';

describe('tcesdk-component', () => {
  beforeEach(() => {
    resetSourceCache();
  });
  before(() => {
    window.__sdkRouterByTce = {
      'tag-sdk': {
        content: '/tcloud/sdk-tag/tce-sdk-tag._lang_.js',
        component: 'rx-app-tea2',
        css: ['/tcloud/sdk-tag/tce-sdk-tag._lang_.css'],
      },
    };
    window.TCE_GLOBAL_CONSTANT = {
      imgcacheHost: 'imgcache.yfm6.tcepoc.fsphere.cn',
      platformType: 'tce_ocloud',
    };
    window.TCE_GLOBAL_CONSTANT_ASYNC = {
      regionList: [],
    };
    // @ts-ignore
    window.seajs = {
      use: (id, cb) => cb(),
      require: (str) => str,
    };
  });

  it('资源地址格式化正确', async () => {
    const stubFunc = sinon.stub().resolves();
    rewire$getSource(stubFunc);
    try {
      await getComponent('tag-sdk');
    } catch (error) {}
    expect(stubFunc.calledWith('//imgcache.yfm6.tcepoc.fsphere.cn/tcloud/sdk-tag/tce-sdk-tag.zh.js')).to.be.true;
    restore();
  });

  it('资源地址格式化正确menus-sdk', async () => {
    const stubFunc = sinon.stub().resolves();
    rewire$getSource(stubFunc);
    try {
      await getComponent('menus-sdk');
    } catch (error) {}
    expect(stubFunc.calledWith('//imgcache.yfm6.tcepoc.fsphere.cn/common/menu-sdk/menu-sdk.zh.js')).to.be.true;
    restore();
  });

  it('资源地址格式化正确announce-sdk', async () => {
    const stubFunc = sinon.stub().resolves();
    rewire$getSource(stubFunc);
    try {
      await getComponent('announce-sdk');
    } catch (error) {}
    expect(stubFunc.calledWith('//imgcache.yfm6.tcepoc.fsphere.cn/ocloud/announce/announce-sdk.js')).to.be.true;
    restore();
    delete window.TCE_GLOBAL_CONSTANT.platformType;
  });

  it('资源地址格式化正确', async () => {
    window.__sdkRouterByTce = {
      'tag-sdk': {
        content: '//imgcache.yfm6.tcepoc.fsphere.cn/tcloud/sdk-tag/tce-sdk-tag._lang_.js',
        component: 'rx-app-tea2',
        css: ['//imgcache.yfm6.tcepoc.fsphere.cn/tcloud/sdk-tag/tce-sdk-tag._lang_.css'],
      },
    };
    const stubFunc = sinon.stub().resolves();
    rewire$getSource(stubFunc);
    try {
      await getComponent('tag-sdk');
    } catch (error) {}
    expect(stubFunc.calledWith('//imgcache.yfm6.tcepoc.fsphere.cn/tcloud/sdk-tag/tce-sdk-tag.zh.js')).to.be.true;
    restore();
  });

  it('没有ReactDom16且为购买页则预加载Tea和buy.css', async () => {
    // @ts-ignore
    window.React16 = {};
    window.TCE_GLOBAL_CONSTANT.platformType = PLATFORM_TYPE.TCE_TCLOUD_BUY;
    // @ts-ignore
    const useStub = sinon.stub(window.seajs, 'use').callsFake((id, cb) => cb());
    const stubFunc = sinon.stub().resolves();
    rewire$getSource(stubFunc);
    try {
      await getComponent('tag-sdk');
    } catch (error) {}
    expect(
      useStub.calledWith([
        '//imgcache.yfm6.tcepoc.fsphere.cn/common/js/tea2/tea-component-v2.js',
        '//imgcache.yfm6.tcepoc.fsphere.cn/common/css/tea2/tea-v2.min.css',
      ]),
    ).to.be.true;
    useStub.restore();
    restore();
  });

  it('没有TEA2则预加载', async () => {
    // @ts-ignore
    window.ReactDOM16 = {};
    const stubFunc = sinon.stub().resolves();
    rewire$getSource(stubFunc);
    try {
      await getComponent('tag-sdk');
    } catch (error) {}
    expect(stubFunc.calledWith('//imgcache.yfm6.tcepoc.fsphere.cn/tcloud/sdk-tag/tce-sdk-tag.zh.js')).to.be.true;
    restore();
  });

  it('没有i18next则预加载', async () => {
    // @ts-ignore
    window.TeaComponentV2 = {};
    const stubFunc = sinon.stub().resolves();
    rewire$getSource(stubFunc);
    try {
      await getComponent('tag-sdk');
    } catch (error) {}
    expect(stubFunc.calledWith('//imgcache.yfm6.tcepoc.fsphere.cn/tcloud/sdk-tag/tce-sdk-tag.zh.js')).to.be.true;
    restore();
  });

  it('资源地址格式化正确', async () => {
    // @ts-ignore
    window.TCE_GLOBAL_CONSTANT_ASYNC = undefined;
    const stubFunc = sinon.stub().resolves();
    rewire$getSource(stubFunc);
    try {
      await getComponent('tag-sdk');
    } catch (error) {}
    expect(stubFunc.calledWith('//imgcache.yfm6.tcepoc.fsphere.cn/tcloud/sdk-tag/tce-sdk-tag.zh.js')).to.be.true;
    restore();
  });

  it('资源地址格式化正确', async () => {
    // @ts-ignore
    window.TCE_GLOBAL_CONSTANT_ASYNC = {
      regionList: [],
      sdk: { a: '', b: '' },
    };
    const stubFunc = sinon.stub().resolves();
    rewire$getSource(stubFunc);
    try {
      await getComponent('tag-sdk');
    } catch (error) {}
    expect(stubFunc.calledWith('//imgcache.yfm6.tcepoc.fsphere.cn/tcloud/sdk-tag/tce-sdk-tag.zh.js')).to.be.true;
    restore();
  });

  it('读取环境Config', async () => {
    // @ts-ignore
    window.seajs = {
      // @ts-ignore
      ...window.seajs,
      require: () => ({
        imgcacheUrl: '//imgcache.tcenter-dev-3100.tcecloud.fsphere.cn',
        bundles: [
          '//imgcache.tcenter-dev-3100.tcecloud.fsphere.cn/common/js/react/polyfill.min.js',
          '//imgcache.tcenter-dev-3100.tcecloud.fsphere.cn/common/js/react/react-with-addons.min.js',
        ],
        bundles16: [
          '//imgcache.tcenter-dev-3100.tcecloud.fsphere.cn/common/js/react/polyfill.min.js',
          '//imgcache.tcenter-dev-3100.tcecloud.fsphere.cn/common/js/react/react-with-addons.min.js',
          '//imgcache.tcenter-dev-3100.tcecloud.fsphere.cn/common/tcesdk/assets/moment/moment.min.js',
          '//imgcache.tcenter-dev-3100.tcecloud.fsphere.cn/common/js/react/react16.production.js',
        ],
        reati18next: ['//imgcache.tcenter-dev-3100.tcecloud.fsphere.cn/common/js/i18next/i18next-lib-16.js'],
        tea2comopnent: [
          '//imgcache.tcenter-dev-3100.tcecloud.fsphere.cn/common/js/tea2/tea-component-v2.js',
          '//imgcache.tcenter-dev-3100.tcecloud.fsphere.cn/common/css/tea2/tea-v2.min.css',
        ],
        ANTD_APP_BUNDLE: [
          '//imgcache.tcenter-dev-3100.tcecloud.fsphere.cn/common/js/antd/babel-polyfill.js',
          '//imgcache.tcenter-dev-3100.tcecloud.fsphere.cn/common/js/antd/react-with-addons.js',
          '//imgcache.tcenter-dev-3100.tcecloud.fsphere.cn/common/js/antd/react-dom.js',
          '//imgcache.tcenter-dev-3100.tcecloud.fsphere.cn/common/js/antd/antd.js',
        ],
      }),
    };
    const stubFunc = sinon.stub().resolves();
    rewire$getSource(stubFunc);
    try {
      await getComponent('tag-sdk');
    } catch (error) {}
    expect(stubFunc.calledWith('//imgcache.yfm6.tcepoc.fsphere.cn/tcloud/sdk-tag/tce-sdk-tag.zh.js')).to.be.true;
    restore();
  });

  it('sdk中组件获取正常', async () => {
    const stubFunc = sinon.stub().resolves();
    rewire$getSource(stubFunc);
    try {
      await getComponent('cam-sdk');
    } catch (error) {}
    expect(stubFunc.calledWith('//imgcache.yfm6.tcepoc.fsphere.cn/common/cam-sdk/cam.js')).to.be.true;
    restore();
  });

  it('sdk中组件获取正常-tcs', async () => {
    window.TCE_GLOBAL_CONSTANT.platformType = 'tcs_ocloud';
    const stubFunc = sinon.stub().resolves();
    rewire$getSource(stubFunc);
    try {
      await getComponent('standalone-sdk');
    } catch (error) {}
    expect(stubFunc.calledWith('//imgcache.yfm6.tcepoc.fsphere.cn/tcs-common/standalone-sdk/standalone.js')).to.be.true;
    restore();
    delete window.TCE_GLOBAL_CONSTANT.platformType;
  });

  it('seajs.use回调执行', async () => {
    const stubFunc = sinon.stub().resolves();
    const cbStub = sinon.stub();
    rewire$getSource(stubFunc);
    // @ts-ignore
    window.seajs = {
      use: (id, cb) => cb(cbStub()),
      require: (str) => str,
    };
    try {
      await getComponent('tag-sdk');
    } catch (error) {}
    expect(cbStub.called).to.be.true;
    restore();
  });

  it('没有镜像地址', async () => {
    const stubFunc = sinon.stub().resolves();
    rewire$getSource(stubFunc);
    window.TCE_GLOBAL_CONSTANT = undefined as any;
    try {
      await getComponent('cam-sdk');
    } catch (error) {}
    expect(stubFunc.calledWith('//undefined//undefined/common/cam-sdk/cam.js')).to.be.true;
    restore();
  });

  it('没有对应的组件', async () => {
    window.TCE_GLOBAL_CONSTANT = undefined as any;
    let errorTex;
    try {
      // @ts-ignore
      await getComponent('CAM1');
    } catch (error) {
      // @ts-ignore
      errorTex = error.toString();
    }
    expect(errorTex).equal('[TceSDKException]message:Component not found');
  });
});
