/* eslint-disable @typescript-eslint/no-unused-expressions */
import { expect } from 'chai';
import sinon from 'sinon';
import { getCAM } from '../src/cam';
// @ts-ignore
import { rewire$getComponent, restore } from '../src/component';

describe('tcesdk-cam', () => {
  it('getComponent入参正确', async () => {
    const stub = sinon.stub();
    rewire$getComponent(stub);
    getCAM();
    expect(stub.calledWith('cam-sdk')).true;
    restore();
  });
});
