const tests = require.context('./', true, /\.spec\.ts$/);

tests.keys().forEach(tests);

const sources = require.context('../src', true, /\.ts$/);

sources.keys().forEach(sources);
