import * as tcesdk from '../src';
import { JS_COOKIE } from 'src/constants';
import { PLATFORM_TYPE } from 'src/platform';
import { getCurrentUserInfo } from 'src/user';
import sinon from 'sinon';
import chai from 'chai';
import chaiAsPromised from 'chai-as-promised';
import { yApiAxios } from '../src/api/yApiAxios';
import { LANGUAGE_TYPE } from 'src/common';
chai.use(chaiAsPromised);
const { expect } = chai;

describe('tcesdk-region', () => {
  let axiosInsStub: sinon.SinonStub;

  beforeEach(() => {
    axiosInsStub = sinon.stub(yApiAxios, 'post');
    window.TCE_GLOBAL_CONSTANT_ASYNC = {};
    window.I18N_CONFIG = {
      langList: [
        {
          default: true,
          name: 'zh-CN',
        },
      ],
      zoneList: {
        '50000001': {
          '50010001': {
            'zone_name_zh-CN': 'tcenter开发',
            zone_id: 50010001,
            id: 50010001,
            name: 'tcenter开发',
            default: true,
            zoneId: 'tcenterdev',
          },
        },
      },
      regionList: [
        {
          region_name: 'chongqing',
          region_id: 50000001,
          area: '重庆',
          code: 'chongqing',
          regionId: 'chongqing',
          value: 50000001,
          default: true,
          name: '重庆',
          'region_name_zh-CN': '重庆',
        },
        {
          region_name: 'chongqing1',
          region_id: 50000002,
          area: '重庆1',
          code: 'chongqing1',
          regionId: 'chongqing1',
          value: 50000002,
          default: true,
          name: '重庆1',
          'region_name_zh-CN': '重庆1',
        },
      ],
      tceLanguage: 'zh-CN',
      title: {
        title: '公有云_TCenter_TCE380_开发环境',
        'title_zh-CN': '公有云_TCenter_TCE380_开发环境',
        'title_en-US': '公有云_TCenter_TCE380_开发环境',
      },
    };
    window.TCS = {
      regionList: [
        {
          main_zone_name: 'zj1',
          region_area: '浙江',
          'region_area_en-US': 'southeast',
          'region_area_zh-CN': '东南',
          region_city: '浙江',
          region_id: 50000001,
          region_name: 'zhejiang',
          'region_name_en-US': 'zhejiang',
          region_name_long: 'zhejiang',
          region_name_upper: 'ZHEJIANG',
          region_name_zh: '浙江',
          'region_name_zh-CN': '浙江',
          xgw_bgp_as: '0',
        },
      ],
      currentUserInfo: {
        ownerUin: 909619400,
        uin: '909622052',
        account: '909619400_tceadmin',
        mail: 'tc*****@tce.com',
        name: 'TCECMGT',
        nickname: 'tceadmin',
        countryCode: '86',
        tel: '137****5775',
        collName: 'tceadmin',
        collTel: '137****5775',
        collMail: 'tce****@tce.com',
        userType: 'subaccount',
      },
    };

    tcesdk.constants.JS_COOKIE.set('user_uin', '100500000037');
    tcesdk.constants.JS_COOKIE.set('user_id', 'yaweihuang');
    tcesdk.constants.JS_COOKIE.set('owner_uin', '909619400');
    tcesdk.constants.JS_COOKIE.set('lusername', 'strong');
    tcesdk.constants.JS_COOKIE.set('uin', 'o100004603012');
    tcesdk.constants.JS_COOKIE.set('ownerUin', 'O100004603012G');
  });

  afterEach(() => {
    axiosInsStub.restore();
  });

  it('getRegionListSync_ocloud', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_OCLOUD,
    };
    const regionList = tcesdk.region.getRegionListSync();
    expect(regionList[0].region).equal('chongqing');
    expect(regionList[0].regionId).equal(50000001);
    expect(regionList[0].regionName).equal('重庆');
    expect(regionList[0].zoneList.length).equal(1);
    expect(regionList[0].zoneList[0].zone).equal('tcenterdev');
    expect(regionList[0].zoneList[0].zoneId).equal(50010001);
    expect(regionList[0].zoneList[0].zoneName).equal('tcenter开发');
  });

  it('getRegionListSync_tcloud', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD,
    };
    const regionList = tcesdk.region.getRegionListSync();
    expect(regionList[0].region).equal('chongqing');
    expect(regionList[0].regionId).equal(50000001);
    expect(regionList[0].regionName).equal('重庆');
    expect(regionList[0].zoneList.length).equal(1);
    expect(regionList[0].zoneList[0].zone).equal('tcenterdev');
    expect(regionList[0].zoneList[0].zoneId).equal(50010001);
    expect(regionList[0].zoneList[0].zoneName).equal('tcenter开发');
  });

  it('getRegionListSync_tcs', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCS_OCLOUD,
    };
    const regionList = tcesdk.region.getRegionListSync();
    expect(regionList[0].region).equal('zhejiang');
    expect(regionList[0].regionId).equal(50000001);
    expect(regionList[0].regionName).equal('浙江');
    expect(regionList[0].zoneList.length).equal(0);
  });

  it('getRegionListSync_tcs_zone', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCS_OCLOUD,
    };
    window.TCS.zoneList = [
      {
        region_id: 50000001,
        zone_id: 50010001,
        zone_name: 'zj1',
        'zone_name_en-US': 'zj1',
        zone_name_zh: '浙江一区',
        'zone_name_zh-CN': '浙江一区',
      },
    ];
    const regionList = tcesdk.region.getRegionListSync();
    expect(regionList[0].region).equal('zhejiang');
    expect(regionList[0].regionId).equal(50000001);
    expect(regionList[0].regionName).equal('浙江');
    expect(regionList[0].zoneList.length).equal(1);
    expect(regionList[0].zoneList[0].zone).equal('zj1');
    expect(regionList[0].zoneList[0].zoneId).equal(50010001);
    expect(regionList[0].zoneList[0].zoneName).equal('浙江一区');
  });

  it('getRegionListSync_tcs_null', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCS_OCLOUD,
    };
    window.TCS = undefined;
    const regionList = tcesdk.region.getRegionListSync();
    expect(regionList.length).equal(0);
  });

  it('getRegionListSync_I18N_CONFIG_null', () => {
    window.I18N_CONFIG = undefined;
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD,
    };
    const regionList = tcesdk.region.getRegionListSync();
    expect(regionList.length).equal(0);
  });

  it('getRegionListSync_reginList_null', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD,
    };
    window.I18N_CONFIG = {};
    const regionList = tcesdk.region.getRegionListSync();
    expect(regionList.length).equal(0);
  });

  it('getRegionListSync_null', () => {
    window.TCE_GLOBAL_CONSTANT = undefined as any;
    const regionList = tcesdk.region.getRegionListSync();
    expect(regionList.length).equal(0);
  });

  it('getRegionListSync_zonelist_null', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD,
    };
    window.I18N_CONFIG = {
      langList: [
        {
          default: true,
          name: 'zh-CN',
        },
      ],
      regionList: [
        {
          region_name: 'chongqing',
          region_id: 50000001,
          area: '重庆',
          code: 'chongqing',
          regionId: 'chongqing',
          value: 50000001,
          default: true,
          name: '重庆',
          'region_name_zh-CN': '重庆',
        },
      ],
      tceLanguage: 'zh-CN',
    };
    const regionList = tcesdk.region.getRegionListSync();
    expect(regionList[0].region).equal('chongqing');
    expect(regionList[0].regionId).equal(50000001);
    expect(regionList[0].regionName).equal('重庆');
    expect(regionList[0].zoneList.length).equal(0);
  });

  it('getCurrentRegion_ocloud', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_OCLOUD,
    };
    const region = tcesdk.region.getCurrentRegion();
    expect(region?.region).equal('chongqing');
    expect(region?.regionId).equal(50000001);
    expect(region?.regionName).equal('重庆');
  });

  it('getCurrentRegion_tcloud', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD,
    };
    const region = tcesdk.region.getCurrentRegion();
    expect(region?.region).equal('chongqing');
    expect(region?.regionId).equal(50000001);
    expect(region?.regionName).equal('重庆');
  });

  it('getCurrentRegion_tcs', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCS_OCLOUD,
    };
    const region = tcesdk.region.getCurrentRegion();
    expect(region?.region).equal('zhejiang');
    expect(region?.regionId).equal(50000001);
    expect(region?.regionName).equal('浙江');
  });

  it('getCurrentRegion_ocloud_local', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_OCLOUD,
    };
    const { userName } = getCurrentUserInfo() || {};
    localStorage[`${userName}_zone_region`] = 'chongqing1';
    const region = tcesdk.region.getCurrentRegion();
    expect(region?.region).equal('chongqing1');
    expect(region?.regionId).equal(50000002);
    expect(region?.regionName).equal('重庆1');
  });

  it('getCurrentRegion_tcloud_cookie', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD,
    };
    JS_COOKIE.set('regionId', '50000002');
    const region = tcesdk.region.getCurrentRegion();
    expect(region?.region).equal('chongqing1');
    expect(region?.regionId).equal(50000002);
    expect(region?.regionName).equal('重庆1');
  });

  it('getCurrentRegion_tcloud_local', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD,
    };
    const { userUin } = getCurrentUserInfo() || {};
    JS_COOKIE.remove('regionId');
    localStorage[`${userUin || ''}_regionId`] = '50000002';
    const region = tcesdk.region.getCurrentRegion();
    expect(region?.region).equal('chongqing1');
    expect(region?.regionId).equal(50000002);
    expect(region?.regionName).equal('重庆1');
  });

  it('getCurrentRegion_tcloud_local_2', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD,
    };
    const { userUin } = getCurrentUserInfo() || {};
    localStorage.clear();
    JS_COOKIE.remove('regionId');
    localStorage[`${userUin}_regionId`] = '500000031';
    const region = tcesdk.region.getCurrentRegion();
    expect(region?.region).equal('chongqing');
    expect(region?.regionId).equal(50000001);
    expect(region?.regionName).equal('重庆');
  });

  it('getCurrentRegion_tcloud_local_3', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD,
    };
    const { userUin } = getCurrentUserInfo() || {};
    localStorage.clear();
    JS_COOKIE.remove('regionId');
    localStorage[`${userUin}_regionId`] = 'null';
    const region = tcesdk.region.getCurrentRegion();
    expect(region?.region).equal('chongqing');
    expect(region?.regionId).equal(50000001);
    expect(region?.regionName).equal('重庆');
  });

  it('getCurrentRegion_ocloud_local_2', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_OCLOUD,
    };
    const { userName } = getCurrentUserInfo() || {};
    localStorage.clear();
    localStorage[`${userName}_zone_region`] = 'chongqing3';
    const region = tcesdk.region.getCurrentRegion();
    expect(region?.region).equal('chongqing');
    expect(region?.regionId).equal(50000001);
    expect(region?.regionName).equal('重庆');
  });

  it('getCurrentRegion_ocloud_local_3', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_OCLOUD,
    };
    const { userName } = getCurrentUserInfo() || {};
    localStorage.clear();
    localStorage[`${userName}_zone_region`] = 'null';
    const region = tcesdk.region.getCurrentRegion();
    expect(region?.region).equal('chongqing');
    expect(region?.regionId).equal(50000001);
    expect(region?.regionName).equal('重庆');
  });

  it('getCurrentRegion_ocloud_url', () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_OCLOUD,
    };
    const { href } = window.location;
    history.pushState({}, '', `${window.location.href}?region=chongqing`);
    const region = tcesdk.region.getCurrentRegion();
    expect(region?.region).equal('chongqing');
    expect(region?.regionId).equal(50000001);
    expect(region?.regionName).equal('重庆');
    history.pushState({}, '', `${href}`);
  });

  it('getCurrentRegion_other', () => {
    window.TCE_GLOBAL_CONSTANT = undefined as any;
    const region = tcesdk.region.getCurrentRegion();
    expect(region).equal(undefined);
  });

  it('getRegionListAsync_tcs_olocud', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCS_OCLOUD,
    };
    window.TCS.zoneList = [
      {
        region_id: 50000001,
        zone_id: 50010001,
        zone_name: 'zj1',
        'zone_name_en-US': 'zj1',
        zone_name_zh: '浙江一区',
        'zone_name_zh-CN': '浙江一区',
      },
    ];

    const regionList = await tcesdk.region.getRegionListAsync();

    expect(regionList).eql([
      {
        regionId: 50000001,
        regionName: '浙江',
        region: 'zhejiang',
        regionRole: '',
        zoneList: [
          {
            zone: 'zj1',
            zoneId: 50010001,
            zoneRole: '',
            zoneName: '浙江一区',
          },
        ],
      },
    ]);
  });

  it('getRegionListAsync_tcs_tlocud', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCS_TCLOUD,
    };
    window.TCS.zoneList = [
      {
        region_id: 50000001,
        zone_id: 50010001,
        zone_name: 'zj1',
        'zone_name_en-US': 'zj1',
        zone_name_zh: '浙江一区',
        'zone_name_zh-CN': '浙江一区',
      },
    ];

    const regionList = await tcesdk.region.getRegionListAsync();
    expect(regionList).eql([
      {
        regionId: 50000001,
        regionName: '浙江',
        region: 'zhejiang',
        regionRole: '',
        zoneList: [
          {
            zone: 'zj1',
            zoneId: 50010001,
            zoneRole: '',
            zoneName: '浙江一区',
          },
        ],
      },
    ]);
  });

  it('getRegionListAsync_tcs_tlocud without zoneList', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCS_OCLOUD,
    };
    window.TCS.zoneList = undefined;

    const regionList = await tcesdk.region.getRegionListAsync();
    expect(regionList).eql([
      {
        regionId: 50000001,
        regionName: '浙江',
        region: 'zhejiang',
        regionRole: '',
        zoneList: [],
      },
    ]);
  });

  it('getRegionListAsync', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_OCLOUD,
      baseHost: 'localhost',
      consoleHost: 'consoleHost',
    };
    const axiosRes = {
      code: 0,
      data: {
        Response: {
          RegionSet: [
            {
              RegionState: 'AVAILABLE',
              Region: 'chongqing',
              RegionID: '11',
              RegionName: '重庆',
              RegionRole: 'OR',
              ZoneSet: [
                {
                  ZoneState: 'AVAILABLE',
                  ZoneID: '111',
                  ZoneName: '海淀区',
                  ZoneRole: 'MAZ',
                  Zone: 'haidian',
                },
              ],
            },
          ],
        },
      },
    };
    axiosInsStub.resolves(axiosRes);
    const regionList = await tcesdk.region.getRegionListAsync();
    expect(regionList).eql([
      {
        regionId: 11,
        regionName: '重庆',
        region: 'chongqing',
        regionRole: 'OR',
        zoneList: [
          {
            zone: 'haidian',
            zoneId: 111,
            zoneRole: 'MAZ',
            zoneName: '海淀区',
          },
        ],
      },
    ]);
  });

  it('getRegionListAsync-没有TCE_GLOBAL_CONSTANT_ASYNC', async () => {
    // @ts-ignore
    window.TCE_GLOBAL_CONSTANT_ASYNC = undefined;
    const axiosRes = {
      code: 0,
      data: {
        Response: {
          RegionSet: [
            {
              RegionState: 'AVAILABLE',
              Region: 'chongqing',
              RegionID: '11',
              RegionName: '重庆',
              RegionRole: 'OR',
              ZoneSet: [
                {
                  ZoneState: 'AVAILABLE',
                  ZoneID: '111',
                  ZoneName: '海淀区',
                  ZoneRole: 'MAZ',
                  Zone: 'haidian',
                },
              ],
            },
          ],
        },
      },
    };
    axiosInsStub.resolves(axiosRes);
    await tcesdk.region.getRegionListAsync();
    expect(window.TCE_GLOBAL_CONSTANT_ASYNC.regionList).eql([
      {
        regionId: 11,
        regionName: '重庆',
        region: 'chongqing',
        regionRole: 'OR',
        zoneList: [
          {
            zone: 'haidian',
            zoneId: 111,
            zoneRole: 'MAZ',
            zoneName: '海淀区',
          },
        ],
      },
    ]);
  });

  it('getRegionListAsync-返回list为空数组', async () => {
    const axiosRes = {
      code: 0,
      data: {
        Response: {
          RegionSet: [],
        },
      },
    };
    axiosInsStub.resolves(axiosRes);
    const regionList = await tcesdk.region.getRegionListAsync();
    expect(regionList.length).equal(0);
  });

  it('getRegionListAsync3-TCE_GLOBAL_CONSTANT_ASYNC不存在', async () => {
    // @ts-ignore
    window.TCE_GLOBAL_CONSTANT_ASYNC = undefined;
    const reginList = await tcesdk.region.getRegionListAsync();
    expect(reginList.length).equal(0);
  });

  it('getRegionListAsync3-TCE_GLOBAL_CONSTANT_ASYNC存在', async () => {
    window.TCE_GLOBAL_CONSTANT_ASYNC = { regionList: [] };
    const reginList = await tcesdk.region.getRegionListAsync();
    expect(reginList.length).equal(0);
  });

  it('getRegionListAsync3', async () => {
    await tcesdk.region.getRegionListAsync('SPECIAL_LOGIC_ALL_REGION_ZONE');
    expect(axiosInsStub.calledOnce);
  });

  it('getRegionListAsync3-subProductCode', async () => {
    await tcesdk.region.getRegionListAsync('SPECIAL_LOGIC_ALL_REGION_ZONE', 'CLB');
    expect(axiosInsStub.calledOnce);
  });

  it('getCountryCodeAsync-没有imgcacheHost', async () => {
    // @ts-ignore
    window.TCE_GLOBAL_CONSTANT = null;
    // @ts-ignore
    window.country = {
      _countryCode: [
        {
          EnName: 'Albania',
          Name: '阿尔巴尼亚',
          IOS2: 'AL',
          IOS3: 'ALB',
          Code: '355',
        },
        {
          EnName: 'Algeria',
          Name: '阿尔及利亚',
          IOS2: 'DZ',
          IOS3: 'DZA',
          Code: '213',
        },
      ],
    };
    const codeMapSpy = sinon.spy(tcesdk.region.getCountryCodeAsync);
    try {
      await codeMapSpy();
    } catch (err) {
      expect(err).to.equal('imgcacheHost not exist');
    }
  });

  it('getCountryCodeAsync-参数错误', async () => {
    window.TCE_GLOBAL_CONSTANT = { imgcacheHost: 'http://localhost:9876/' };
    const codeMap = await tcesdk.region.getCountryCodeAsync('test');
    expect(codeMap[0].Name).equal('阿尔巴尼亚');
  });

  it('getCountryCodeAsync-默认参数', async () => {
    const codeMap = await tcesdk.region.getCountryCodeAsync();
    expect(codeMap[0].Name).equal('阿尔巴尼亚');
  });

  it('getLocationAsync-没有imgcacheHost', async () => {
    // @ts-ignore
    window.TCE_GLOBAL_CONSTANT = null;
    // @ts-ignore
    window.provinceMap_zh_cn = [
      { name: '', sub: [{ name: '' }], type: 0 },
      {
        name: '北京',
        sub: [
          { name: '' },
          { name: '东城区' },
          { name: '西城区' },
          { name: '崇文区' },
          { name: '宣武区' },
          { name: '朝阳区' },
          { name: '海淀区' },
          { name: '丰台区' },
          { name: '石景山区' },
          { name: '房山区' },
          { name: '通州区' },
          { name: '顺义区' },
          { name: '昌平区' },
          { name: '大兴区' },
          { name: '怀柔区' },
          { name: '平谷区' },
          { name: '门头沟区' },
          { name: '密云县' },
          { name: '延庆县' },
          { name: '其他' },
        ],
        type: 0,
      },
    ];
    const codeMapSpy = sinon.spy(tcesdk.region.getLocationAsync);
    try {
      await codeMapSpy();
    } catch (err) {
      expect(err).to.equal('imgcacheHost not exist');
    }
  });

  it('getLocationAsync-默认参数', async () => {
    window.TCE_GLOBAL_CONSTANT = { imgcacheHost: 'http://localhost:9876/' };
    const codeMap = await tcesdk.region.getLocationAsync();
    expect(codeMap[1].name).equal('北京');
  });

  it('getLocationAsync-指定参数', async () => {
    window.TCE_GLOBAL_CONSTANT = { imgcacheHost: 'http://localhost:9876/' };
    const codeMap = await tcesdk.region.getLocationAsync('zh-CN');
    expect(codeMap[1].name).equal('北京');
  });

  it('getCurrentRegionAync', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD_BUY,
      baseHost: 'localhost',
      consoleHost: 'consoleHost',
    };
    const axiosRes = {
      code: 0,
      data: {
        Response: {
          RegionSet: [
            {
              RegionState: 'AVAILABLE',
              Region: 'chongqing',
              RegionID: '11',
              RegionName: '重庆',
              ZoneSet: [
                {
                  ZoneState: 'AVAILABLE',
                  ZoneID: '111',
                  ZoneName: '海淀区',
                  Zone: 'haidian',
                },
              ],
            },
          ],
        },
      },
    };
    axiosInsStub.resolves(axiosRes);
    const region = await tcesdk.region.getCurrentRegionAsync();
    expect(region.region).equal('chongqing');
    expect(axiosInsStub.calledOnce);
  });

  it('getCurrentRegionAync-传入regionID', async () => {
    window.TCE_GLOBAL_CONSTANT = {
      platformType: PLATFORM_TYPE.TCE_TCLOUD_BUY,
      baseHost: 'localhost',
      consoleHost: 'consoleHost',
    };
    const axiosRes = {
      code: 0,
      data: {
        Response: {
          RegionSet: [
            {
              RegionState: 'AVAILABLE',
              Region: 'chongqing',
              RegionID: '11',
              RegionName: '重庆',
              ZoneSet: [
                {
                  ZoneState: 'AVAILABLE',
                  ZoneID: '111',
                  ZoneName: '海淀区',
                  Zone: 'haidian',
                },
              ],
            },
          ],
        },
      },
    };
    axiosInsStub.resolves(axiosRes);
    const region = await tcesdk.region.getCurrentRegionAsync('11');
    expect(region.region).equal('chongqing');
    expect(axiosInsStub.calledOnce);
  });

  it('setRegion 租户端正常set', () => {
    window.TCE_GLOBAL_CONSTANT = { platformType: PLATFORM_TYPE.TCE_TCLOUD };
    tcesdk.region.setRegion('chongqing');
    expect(JS_COOKIE.get('regionId')).equal('chongqing');
    expect(localStorage['100004603012_regionId']).equal('chongqing');
  });

  it('setRegion 运营端正常set', () => {
    window.TCE_GLOBAL_CONSTANT = { platformType: PLATFORM_TYPE.TCE_OCLOUD };
    tcesdk.region.setRegion('chongqing');
    expect(localStorage.yaweihuang_zone_region).equal('chongqing');
  });

  it('getIDCList--正常获取idc数据--tce', () => {
    window.TCE_GLOBAL_CONSTANT = { platformType: PLATFORM_TYPE.TCE_OCLOUD };
    JS_COOKIE.set('tce_language', LANGUAGE_TYPE.ZH_CN);
    window.I18N_CONFIG = {
      idcList: [
        {
          region_id: 50000001,
          zone_id: 50010001,
          idc_id: 50010101,
          idc_name: 'yfdb',
          'idc_name_en-US': 'yfdb',
          'idc_name_zh-CN': '云福db',
        },
      ],
    };
    const idcList = tcesdk.region.getIDCList(50010001);
    expect(idcList.length).to.equal(1);
    console.log(idcList[0]);
    expect(idcList[0]).to.deep.equal({
      regionId: 50000001,
      zoneId: 50010001,
      idcId: 50010101,
      idc: 'yfdb',
      idcName: '云福db',
    });
  });

  it('getIDCList--正常获取idc数据--tcs', () => {
    window.TCE_GLOBAL_CONSTANT = { platformType: PLATFORM_TYPE.TCS_OCLOUD };
    window.TCS = {
      idcList: [
        {
          region_id: 50000001,
          zone_id: 50010001,
          idc_id: 50010101,
          idc_name: 'yfdb',
          'idc_name_en-US': 'yfdb',
          'idc_name_zh-CN': '云福db',
        },
      ],
    };
    const idcList = tcesdk.region.getIDCList(50010001);
    expect(idcList.length).to.equal(1);
    expect(idcList[0]).to.deep.equal({
      regionId: 50000001,
      zoneId: 50010001,
      idcId: 50010101,
      idc: 'yfdb',
      idcName: '云福db',
    });
  });

  it('getIDCList--正常获取idc数据--数据为空', () => {
    window.TCE_GLOBAL_CONSTANT = { platformType: PLATFORM_TYPE.TCS_OCLOUD };
    window.TCS = {};
    const idcList = tcesdk.region.getIDCList(50010001);
    expect(idcList.length).to.equal(0);
  });
});
