/* eslint-disable @typescript-eslint/no-unused-expressions */
import { expect } from 'chai';
import * as tcesdk from '../src';
import sinon from 'sinon';
import { mockRandom, resetMockRandom } from 'jest-mock-random';
import TceSDKException from 'src/common/tce_sdk_exception';
import { assets } from 'src/common/util';

describe('tcesdk-util', () => {
  // 在有参数的情况下
  it('getQueryParameters-params', () => {
    const searchParams = '?a=1&b=2';
    const query = tcesdk.utils.getQueryParameters(searchParams);
    expect(JSON.stringify(query)).equal(JSON.stringify({ a: '1', b: '2' }));
  });
  // 无参数的时候，直接取document.location.search
  it('getQueryParameters-noparams', () => {
    const query = tcesdk.utils.getQueryParameters();
    expect(JSON.stringify(query)).equal(JSON.stringify({}));
  });

  it('storage-默认参数', () => {
    const storageStub = sinon.spy(tcesdk.utils.storage);
    tcesdk.utils.storage();
    expect(storageStub.calledWith('tce'));
  });

  it('storage-带参数', () => {
    const storageStub = sinon.spy(tcesdk.utils.storage);
    tcesdk.utils.storage('tcs');
    expect(storageStub.calledWith('tcs'));
  });

  it('printKeywordLog', () => {
    const consoleLog = sinon.stub(console, 'log');
    const consoleGroup = sinon.stub(console, 'group');
    tcesdk.utils.printKeywordLog('test');
    expect(consoleLog.calledWith('Current Page URL:', window.location.href)).to.be.true;
    expect(consoleGroup.calledWith('%ctest', 'color: red;font-size: 16px;')).to.be.true;
    consoleLog.restore();
    consoleGroup.restore();
  });

  it('printKeywordLog-console无group属性', () => {
    const consoleLog = sinon.stub(console, 'log');
    const consoleGroup = sinon.stub(console, 'group');
    consoleGroup.value(undefined);
    tcesdk.utils.printKeywordLog('test');
    expect(consoleLog.calledWith('test [Log Start]')).to.be.true;
    consoleLog.restore();
    consoleGroup.restore();
  });

  it('printKeywordLog-console无group属性', () => {
    const consoleLog = sinon.stub(console, 'log');
    const consoleGroup = sinon.stub(console, 'group');
    consoleGroup.value(undefined);
    tcesdk.utils.printKeywordLog('test');
    expect(consoleLog.calledWith('test [Log Start]')).to.be.true;
    consoleLog.restore();
    consoleGroup.restore();
  });

  it('printKeywordLog-console无groupEnd属性', () => {
    const consoleLog = sinon.stub(console, 'log');
    const consoleGroup = sinon.stub(console, 'group');
    const consoleGroupEndStub = sinon.stub(console, 'groupEnd');
    consoleGroupEndStub.value(undefined);
    tcesdk.utils.printKeywordLog('test');
    expect(consoleLog.calledWith('test [Log End]')).to.be.true;
    consoleGroupEndStub.restore();
    consoleLog.restore();
    consoleGroup.restore();
  });

  it('printKeywordLog-有detail参数', () => {
    const consoleLog = sinon.stub(console, 'log');
    const consoleGroup = sinon.stub(console, 'group');
    tcesdk.utils.printKeywordLog('test', [
      { key: 'testKey', value: 'test' },
      { key: '', value: undefined },
    ]);
    expect(consoleLog.calledWith('testKey:', 'test')).to.be.true;
    consoleLog.restore();
    consoleGroup.restore();
  });

  it('downloadCsv', () => {
    const downloadSpy = sinon.spy(tcesdk.utils.downloadCsv);
    const createObjectURLStub = sinon.stub(URL, 'createObjectURL');
    downloadSpy([['testRow']], ['testHeader'], 'testFile');
    expect(createObjectURLStub.calledOnce).to.be.true;
    createObjectURLStub.restore();
  });

  it('downloadXlsx', async () => {
    const commonUtilAssetsStub = sinon.stub(assets, 'getXlsxUrl').returns('/base/assets/xlsx/xlsx.full.min.js');
    await tcesdk.utils.downloadXlsx([['testRow']], ['testHeader'], 'testFile.xlsx');
    // @ts-ignore
    expect(Boolean(window.XLSX)).to.be.true;
    commonUtilAssetsStub.restore();
  });

  it('downloadCsv-userAgent判断', () => {
    const downloadSpy = sinon.spy(tcesdk.utils.downloadCsv);
    const userAgentStub = sinon.stub(navigator, 'userAgent').value('1MSIE 9.0');
    try {
      downloadSpy([['testRow']], ['中文', 'testHeader'], 'testFile');
    } catch {
      expect(downloadSpy).to.have.throw();
    }
    userAgentStub.restore();
  });

  it('downloadCsv-参数特殊值', () => {
    const downloadSpy = sinon.spy(tcesdk.utils.downloadCsv);
    const createObjectURLStub = sinon.stub(URL, 'createObjectURL');
    downloadSpy(
      // @ts-ignore
      [[new Date()], [null, ',']],
      ['中文', 'testHeader'],
      'testFile',
    );
    expect(createObjectURLStub.calledOnce).to.be.true;
    createObjectURLStub.restore();
  });

  it('downloadCsv-中文乱码问题', () => {
    const downloadSpy = sinon.spy(tcesdk.utils.downloadCsv);
    const createObjectURLStub = sinon.stub(URL, 'createObjectURL');
    const stringCharAt = sinon.stub(String.prototype, 'charAt').returns('\uFEFF');
    // @ts-ignore
    downloadSpy([['testRow']], ['testHeader'], 'testFile');
    expect(createObjectURLStub.calledOnce).to.be.true;
    stringCharAt.restore();
    createObjectURLStub.restore();
  });

  it('downloadCsv-navigator存在属性msSaveBlob', () => {
    const downloadSpy = sinon.spy(tcesdk.utils.downloadCsv);
    // @ts-ignore
    navigator.msSaveBlob = () => true;
    // @ts-ignore
    const navigatorStub = sinon.stub(navigator, 'msSaveBlob');
    downloadSpy(
      // @ts-ignore
      [[new Date()], [null, ',']],
      ['中文', 'testHeader'],
      'testFile',
    );
    expect(navigatorStub.calledOnce).to.be.true;
    navigatorStub.restore();
  });

  it('utils-maskPhoneNumber-ok', () => {
    const mskPhone = tcesdk.utils.maskPhoneNumber('18520201212');
    expect(mskPhone).equal('185****1212');
  });

  it('utils-maskPhoneNumber-length<11', () => {
    const mskPhone = tcesdk.utils.maskPhoneNumber('185201212');
    expect(mskPhone).equal('18****212');
  });

  it('utils-maskPhoneNumber-middle<4', () => {
    const mskPhone = tcesdk.utils.maskPhoneNumber('18520');
    expect(mskPhone).equal('18*20');
  });

  it('utils-maskPhoneNumber-length<5', () => {
    const mskPhone = tcesdk.utils.maskPhoneNumber('1852');
    expect(mskPhone).equal('1852');
  });

  it('utils-maskPhoneNumber-fail', () => {
    const mskPhone = tcesdk.utils.maskPhoneNumber('');
    expect(mskPhone).equal('');
  });

  it('utils-maskMail-ok', () => {
    const maskMail = tcesdk.utils.maskMail('1234556@qq.com');
    expect(maskMail).equal('123****@qq.com');
  });

  it('utils-maskMail-middel<4', () => {
    const maskMail = tcesdk.utils.maskMail('123@qq.com');
    expect(maskMail).equal('1****@qq.com');
  });

  it('utils-maskMail-fail', () => {
    const maskMail = tcesdk.utils.maskMail('');
    expect(maskMail).equal('');
  });

  it('utils-maskMail-include-*', () => {
    const maskMail = tcesdk.utils.maskMail('123***@qq.com');
    expect(maskMail).equal('123***@qq.com');
  });

  it('utils-maskMail-exclude-@', () => {
    const maskMail = tcesdk.utils.maskMail('12qq.com');
    expect(maskMail).equal('12qq.com');
  });

  it('uuid', () => {
    mockRandom([0.12, 0.21, 0.34, 0.43, 0.53, 0.66, 0.73, 0.82]);
    const uuid = tcesdk.utils.uuid();
    expect(uuid).equal('1eb835c2-570a-6e14-87ae-a8f5bae1d1eb');
    resetMockRandom();
  });

  it('getElementRect-获取dom元素宽高-异常情况-没有dom', () => {
    const result = tcesdk.utils.getElementRect('body');
    expect(result.clientHeight).equal(0);
  });

  it('getElementRect-获取dom元素宽高-异常情况-没有dom', () => {
    try {
      tcesdk.utils.getElementRect('test');
    } catch (error) {
      expect((error as TceSDKException).getMessage()).equal('can not find element');
    }
  });

  it('getElementRect-获取dom元素宽高-异常情况-没有dom', () => {
    try {
      tcesdk.utils.getElementRect();
    } catch (error) {
      expect((error as TceSDKException).getMessage()).equal('can not find element');
    }
  });
});
