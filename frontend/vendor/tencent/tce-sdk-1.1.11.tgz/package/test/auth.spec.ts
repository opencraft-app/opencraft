import { expect } from 'chai';
import sinon from 'sinon';
import { getAUTH } from '../src/auth';
// @ts-ignore
import { rewire$getComponent, restore } from '../src/component';

describe('tcesdk-auth', () => {
  it('getComponent入参正确', async () => {
    const stub = sinon.stub();
    rewire$getComponent(stub);
    getAUTH();
    // eslint-disable-next-line @typescript-eslint/no-unused-expressions
    expect(stub.calledWith('auth-sdk')).true;
    restore();
  });
});
