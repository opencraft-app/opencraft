/* eslint-disable no-inner-declarations */
/* eslint-disable no-var */
import { TCE_GLOBAL_CONSTANT, TCE_GLOBAL_CONSTANT_ASYNC, ComponentMap } from 'src/common';
declare global {
  interface Window {
    expect: Chai.ExpectStatic;
    TCE_GLOBAL_CONSTANT: TCE_GLOBAL_CONSTANT;
    TCE_GLOBAL_CONSTANT_ASYNC: TCE_GLOBAL_CONSTANT_ASYNC;
    g_product_config_data: any;
    g_platform_config_platformTabs: any;
    g_config_data: any; // 客制化产品接入配置信息
    I18N_CONFIG: any;
    TCS: any;
    __sdkRouterByTce: ComponentMap;
    watermarkjs: any;
  }
  var expect: Chai.ExpectStatic;
}
