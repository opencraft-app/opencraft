# TCE 统一 JSSDK

## 技术栈

- 语言：typescript
- 打包：gulp + rollup
- 单元测试：karma + mocha + chai
- 文档编写：vuepress

## 目录规范

> src 目录里面一个文件夹代表一类功能的 SDK
> test 目录为单元测试的文件的目录
> docs 目录为每个 API 需要提供的文档

## 开发调试

- tnpm install [安装依赖]
- tnpm run dev-esbuild [启动 dev 模式]
- tnpm run build【启动生产模式】
- tnpm run test [单元测试]
- tnpm run docs:dev [文档开发]
- tnpm run docs:build [文档生产]

## 发布到 tnpm 中

- tnpm run build [build]
- tnpm version [更新版本号]

```sh
tnpm version major [更新大版本---出现接口不兼容的时候使用]
tnpm version minor [更新小版本---增加接口使用这个]
tnpm version patch [更新bug版本---修复接口（兼容修改）使用这个]
```

## 代码提交

> 为了保证代码提交的 msg 规范，请使用 git cz 进行 commit 提交，详细说明参考：http://www.ruanyifeng.com/blog/2016/01/commit_message_change_log.html

- git add .
- git cz 【交互式编辑 git message 然后提交】

## 更新 changelog

> 根据代码提交的 commit 生成

```
tnpm run changelog
```

## 其他链接

[详细使用文档](http://dragon.tce.oa.com/page/devDocument/tce-sdk)

[Changelog](https://git.woa.com/tce-tools/tce-sdk/blob/master/CHANGELOG.md)

[单测报告](http://dragon.tce.oa.com/config/tce-sdk/coverage/)
