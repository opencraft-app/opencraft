# 安全

::: tip 说明
安全模块主要是提供平台通用的安全相关的 SDK，下面的使用只介绍通过 npm 安装方式的使用，其他方式的使用请参考 [介绍使用](/introduction/) 里面的用法
:::

## 密码明文加密

::: tip 加密细节
[明文传输加密逻辑细节](https://iwiki.woa.com/pages/viewpage.action?pageId=882617386)
:::

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.9.0   |   >= 3.9.0   |   >= 3.9.0   |   >= 3.9.0   |   >= 3.9.0   |

**TCS**:

| 登录页 | 控制台 |
| :----: | :----: |
|  :x:   |  :x:   |

> 使用示列【加密的过程是异步的】

```ts
import { security } from '@tencent/tce-sdk';
// 返回密文
const ciphertext = await security.encrypt('明文');
```

> 出入参情况

```ts
/**
 * 加密明文
 * @param plaintext 明文
 * @param defaultText 默认值【环境没有配置加密方式的情况下默认返回的内容】
 */
export declare function encrypt(plaintext: string，defaultText?: string): Promise<string | false>;
```

::: warning 注意
上面的加密方法`encrypt`目前是采用 RSA2048 公钥加密，后端对应的 SDK 也会对应使用 RSA2048 私钥解密，加密方式随着时间变化会改变，比如增加国密 SM2 的非对称加密，使用方不需要关心
:::

## 获取防 CSRF 串

::: tip 逻辑细节
[csrfCode生成细节](https://iwiki.woa.com/pages/viewpage.action?pageId=1393786019#id-%E6%8E%A7%E5%88%B6%E5%8F%B0skey%E8%AE%BE%E7%BD%AE%E4%B8%BAhttponly-2%E3%80%81csrfCode%E9%80%9A%E8%BF%87%E5%90%8E%E7%AB%AF%E6%9D%A5%E7%94%9F%E6%88%90)
:::

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.9.0   |   >= 3.8.0   |   >= 3.9.0   |   >= 3.9.0   |   >= 3.8.0   |

**TCS**:

| 登录页  | 控制台  |
| :-----: | :-----: |
| >=2.1.0 | >=2.1.0 |

> 使用示列

```ts
import { security } from '@tencent/tce-sdk';
const csrfToken = security.getCSRFToken();
```

> 出入参情况

```ts
/**
 * 获取防CSRF串
 * @method getCSRFToken
 * @return {String} 验证串
 */
export declare function getCSRFToken(): string;
```
