# 用户

::: tip 说明
用户模块主要是提供平台获取用户相关的通用方法，下面的使用只介绍通过 npm 安装方式的使用，其他方式的使用请参考 [介绍使用](/introduction/) 里面的用法
:::

## 获取当前登录用户信息【同步】

::: tip 说明
由于是同步获取，所以只能获取一些用户固定不变的内容，例如用户 uin 及 ownerUin 等
:::

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   >= 3.8.0   |   >= 3.9.0   |     :x:      |   >= 3.8.0   |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | >= 2.1.0 |

> 使用实例

```ts
import { user } from "@tencent/tce-sdk";
// 不需要入参
const userInfo = user.getCurrentUserInfo();
// 结果实例
{
  "isOwner": false,
  "ownerUin": "909619400",
  "userUin": "909622052",
  "userName": "tceadmin",
  "appId": "1"
}
```

> 出入参说明

```ts
export interface BaseUserInfo {
  /**
   * 是否为主账号
   */
  isOwner: boolean;
  /**
   * 用户uin
   */
  userUin: string;
  /**
   * 主账号uin
   */
  ownerUin: string;
  /**
   * 用户名称
   */
  userName: string;
}
/**
 * 获取当期登录用户信息
 */
export declare function getCurrentUserInfo(): BaseUserInfo | undefined;
```

## 获取当前登录用户信息【异步】

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   >= 3.9.0   |   >= 3.9.0   |     :x:      |   >= 3.9.0   |

**TCS**:

| 登录页 | 控制台 |
| :----: | :----: |
|  :x:   |  :x:   |

> 使用实例

```ts
import { user } from "@tencent/tce-sdk";
// 不需要入参
const userInfo = await user.getCurrentUserInfoAsync();
// 结果实例
{
  "isOwner": true,
  "ownerUin": "100004603012",
  "ownerUserName": "yaweihuang",
  "userUin": "100004603012",
  "userName": "yaweihuang",
  "countryCode": "86",
  "tel": "185****2048",
  "mail": "yawe******@tencent.com",
  "nickName": "yaweihuang",
  "appId": "1255000288"
}
```

> 出入参说明

```ts
export interface BaseUserInfo {
  /**
   * 用户uin
   */
  userUin: string;
  /**
   * 主账号uin
   */
  ownerUin: string;
  /**
   * 用户名称
   */
  userName: string;
  /**
   * appId
   */
  appId: string;
}
export interface UserInfo extends BaseUserInfo {
  /**
   * 主账号UIN
   */
  ownerUin: string;
  /**
   * 主账号用户名
   */
  ownerUserName: string;
  /**
   * 用户uin
   */
  userUin: string;
  /**
   * 用户名称
   */
  userName: string;
  /**
   * 用户昵称
   */
  nickName: string;
  /**
   * 是否为主账号
   */
  isOwner: boolean;
  /**
   * 电话国家码
   */
  countryCode: string;
  /**
   * 电话
   */
  tel: string;
  /**
   * 邮箱
   */
  mail: string;
}
/**
 * 异步获取当前用户信息
 * @return Promise<UserInfo | undefined>
 */
export declare async function getCurrentUserInfoAsync(): Promise<
  UserInfo | undefined
>;
```

## 获取当前用户关联的策略名称列表

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   :x:   |   :x:   |     :x:      |   >= 3.10.0   |

**TCS**:

| 登录页 | 控制台 |
| :----: | :----: |
|  :x:   |  :x:   |

> 使用实例

```ts
import { user } from "@tencent/tce-sdk";
const policies = await user.getCurrentUserRelatedPolicies();
// 结果实例
["AdministratorAccess"]
```

> 出入参说明

```ts
/**
 * 获取当前用户已关联的策略列表
 * @export
 * @returns {string[]} 返回策略列表名称
 */
export declare function getCurrentUserRelatedPolicies(): Promise<string[]>;
```

## 判断当前用户是否为超级管理员

::: tip 温馨提示
判断用户是否为超级管理员，其实就是判断当前用户是否关联了预设策略`AdministratorAccess`
:::

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   :x:   |   :x:   |     :x:      |   >= 3.10.0   |

**TCS**:

| 登录页 | 控制台 |
| :----: | :----: |
|  :x:   |  :x:   |

> 使用实例

```ts
import { user } from "@tencent/tce-sdk";
const policies = await user.checkCurrentUserIsAdmin();
// 结果实例
true
```

> 出入参说明

```ts
/**
 * 判断当前用户是否为超级管理员【也就是是否关联的（AdministratorAccess）策略】
 * @export
 * @returns {boolean}
 */
export declare function checkCurrentUserIsAdmin(): Promise<boolean>;
```

## 判断当前用户是否存在白名单Key中

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   >= 3.11.0    |   >= 3.11.0   |     :x:      |   :x:    |

**TCS**:

| 登录页 | 控制台 |
| :----: | :----: |
|  :x:   |  :x:   |

> 使用实例

```ts
import { user } from "@tencent/tce-sdk";
const isHas = await user.hasWhiteList('test');
// 结果实例
true
```

> 出入参说明

```ts
/**
 * 获取当前用户是否关联白名单
 * @param whitelistKey 白名单key
 * @param valueType 白名单值类型，默认为ownerUin【'appid' | 'uin' | 'owneruin'】
 * @returns boolean
 */
export declare function hasWhiteList(whitelistKey: string, valueType?: IWhiteListValueType): Promise<boolean>;
export declare type IWhiteListValueType = 'appid' | 'uin' | 'owneruin';
```

## 获取当前用户白名单列表

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   >= 3.11.0    |   >= 3.11.0   |     :x:      |   :x:    |

**TCS**:

| 登录页 | 控制台 |
| :----: | :----: |
|  :x:   |  :x:   |

> 使用实例

```ts
import { user } from "@tencent/tce-sdk";
const isHas = await user.hasWhiteListForMultiKey(['test', 'test2', 'test3']);
// 结果实例
{
  test: { result: true, oriData: ["100012321"] },
  test2: { result: false, oriData: [] },
  test3: { result: false, oriData: [] }
}
```

> 出入参说明

```ts
/**
 * 获取当前用户关联的白名单列表
 * @param whiteListKeys 白名单key
 * @param valueType 白名单值类型，默认为ownerUin【'appid' | 'uin' | 'owneruin'】
 * @returns IWhiteListResult
 */
export declare function hasWhiteListForMultiKey(whiteListKeys: string[], valueType?: IWhiteListValueType): Promise<IWhiteListResult>;
export declare type IWhiteListValueType = 'appid' | 'uin' | 'owneruin';
export interface IWhiteListResult {
    [x: string]: {
        result: boolean;
        oriData: string[]; // 接口返回的原始数据
    };
}
```