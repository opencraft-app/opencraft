# 介绍使用

::: tip 前言说明
由于 TCE-SDK 部分依赖平台环境，目前从 TCE3.9.0 及 TCS2.1.0 版本上开始支持，具体每个sdk的方法支持的版本，参考每个方法的版本支持情况。
:::

[![version](https://mirrors.tencent.com/mirrors/api/npm/package/badge?package_name=@tencent/tce-sdk)](https://mirrors.tencent.com/#/private/npm/detail?repo_id=537&project_name=%40tencent%2Ftce-sdk) 
[![coverage](./coverage-badge.svg)](http://dragon.tce.woa.com/config/tce-sdk/coverage/) 
[版本发布日志](https://git.woa.com/tce-tools/tce-sdk/blob/master/CHANGELOG.md) 
[反馈](https://git.woa.com/tce-tools/tce-sdk/issues)

## npm 安装使用

> 通过 npm 安装的方式使用可以使用 TS

1、在项目中安装`@tencent/tce-sdk`

```bash
tnpm install @tencent/tce-sdk
```

2、使用

```ts
import { domain, language } from '@tencent/tce-sdk';

const domain = domain.getDomainList();
const currentLang = language.getCurrentLanguage();
```

或者

```ts
import * as tcesdk from '@tencent/tce-sdk';

const domain = tcesdk.domain.getDomainList();
const currentLang = tcesdk.language.getCurrentLanguage();
```

::: tip 优化说明
由于 tce-sdk 已经在 TCE 及 TCS 控制台全局加载，所以在在项目中可以通过在`webpack`的`externals`中将`tce-sdk`出去，避免重复加载多余的包

```js
externals: {
  '@tencent/tce-sdk': "window.tcesdk"
}
```

PS: 【使用`tce-cli`的项目升级最新的`tce-cli`【1.1.54 以上版本】就好，不需要加上上面的内容，`tce-cli`里面已经默认加上了】
:::

## 按需加载场景

> 非 TCE 及 TCS 控制台场景下（比如租户端及运营端登录相关场景下）可以考虑按需加载的方式，避免全部加载导致包压缩过大【在TCE及TCS控制台里面不要这样使用】

比如：我只需要使用到密码 rsa 公钥加密的场景

```ts
import { encrypt } from '@tencent/tcs-sdk/lib/security';
const ciphertext = await encrypt('123456');
```

如果觉得`@tencent/tce-sdk/lib/security`写起来太长了，也可以通过在 tsconfig paths 中设置 alias，这样方便在项目中简写

tsconfig patshs 中增加下面的 alias

```json
"@tce/sdk/*": ["./node_modules/@tencent/tce-sdk/lib/*"],
```

项目中引用

```ts
import { encrypt } from '@tce/sdk/security';
const ciphertext = await encrypt('123456');
```

## 全局使用

> tcesdk 默认会在 TCE 运营端、租户端控制台及 TCS 控制台默认加载，如果不在项目中通过 tnpm 安装的话，也可以通过`window.tcesdk`方式使用【针对因为网络无法使用 tnpm 源及传统前端工程情况下使用】

```ts
const domain = window.tcesdk.domain.getDomainList();
const currentLang = window.tcesdk.language.getCurrentLanguage();
```

## iframe 接入使用

> 针对 iframe 接入的场景，因为跨域原因不能使用父页面的 tcesdk，这个时候需要在自己的项目中设置下【前提是 iframe 接入的时候，iframe 的主域和当前控制台的主域相同】

```ts
document.domain = 'tce主域';
```

设置`document.domain`后就可以通过下面的方式全局使用`tcesdk`

```ts
const tcesdk = window.parent.tcesdk;
```

::: tip 温馨提示
如果因为一些原因，需要通过`window.tcesdk`或 `window.parent.tcesdk`使用tcesdk的话，但又希望有tcesdk的TS声明，可以在项目中使用 `@tencent/types-tcesdk`

> 在自己的TS项目中的global.d.ts中声明tcesdk，这样就可以很方便的使用了tcesdk的TS定义

```ts
import * as tcesdk from '@tencent/types-tcesdk';
declare global {
  interface Window {
    tcesdk: typeof tcesdk;
  }
}
```
:::

## 注意事项【必看】

::: warning 温馨提示
由于 tce-sdk 已经在 TCE 及 TCS 控制台全局加载，所以在TCE或TCS场景下最好通过在`webpack`的`externals`中将`tce-sdk`出去，避免后续因为一些需求或bug的修复导致自己的项目需要重新更新package.json里面tce-sdk的版本
```js
// 普通场景下使用webpack方式
externals: {
  '@tencent/tce-sdk': "window.tcesdk"
}
```

```js
// tea场景下的配置方式
webpack: config => {
  // ...
  config.externals = {
    ...config.externals,
    '@tencent/tce-sdk': "window.tcesdk"
  }
  return config
},
```
PS: 【使用tce-cli的项目升级最新的tce-cli【1.1.54 以上版本】就好，不需要加上上面的内容，tce-cli里面已经默认加上了】
:::

