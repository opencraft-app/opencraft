module.exports = {
  base: '/config/tce-sdk/docs/',
  title: 'TCE-JSSDK',
  description: 'TCE前端统一SDK',
  plugins: {
    '@snowdog/vuepress-plugin-pdf-export': {
      puppeteerLaunchOptions: {
        // args: ['--no-sandbox', '--disable-setuid-sandbox']
      },
      outputFileName: 'TCE-JSSDK.pdf',
      sorter: (item) => (item.title === '介绍使用' ? -1 : 0) // 将介绍页放到生成的pdf中的第一页
    }
  },
  themeConfig: {
    lastUpdated: 'Last Updated',
    nav: [
      {
        text: '更多',
        items: [
/*           {
            text: 'pdf 版文档下载',
            link: 'http://dragon.tce.woa.com/config/tce-sdk/docs/assets/TCE-JSSDK.pdf'
          }, */
          {
            text: 'ts 定义 d.ts 文件下载',
            link: 'http://dragon.tce.woa.com/config/tce-sdk/docs/assets/types/index.d.ts'
          },
          {
            text: '单元测试-覆盖率报告查看',
            link: 'http://dragon.tce.woa.com/config/tce-sdk/coverage/'
          },
          {
            text: '反馈',
            link: 'https://git.woa.com/tce-tools/tce-sdk/issues'
          },
          {
            text: "Changelog",
            link: 'https://git.woa.com/tce-tools/tce-sdk/blob/master/CHANGELOG.md'
          }
        ]
      }
    ],
    sidebar: [
      {
        title: '指南', // 必要的
        collapsable: false, // 可选的, 默认值是 true,
        sidebarDepth: 1, // 可选的, 默认值是 1
        children: [
          ['/introduction/', '介绍使用[必看]'],
        ]
      },
      {
        title: '基础SDK', // 必要的
        collapsable: false, // 可选的, 默认值是 true,
        sidebarDepth: 1, // 可选的, 默认值是 1
        children: [
          ['/platform/', '平台'],
          ['/user/', '用户'],
          ['/domain/', '域名'],
          ['/language/', '语言'],
          ['/security/', '安全'],
          ['/config/', '配置'],
          ['/region/', '地域'],
          ['/customize/', '客制化'],
          ['/api/', '云API'],
          ['/file/', '文件服务'],
          ['/sidebar/', '左侧菜单'],
          ['/tips/', '顶部提示'],
          ['/utils/', '工具']
        ]
      },
      {
        title: '业务SDK', // 必要的
        collapsable: false, // 可选的, 默认值是 true,
        sidebarDepth: 1, // 可选的, 默认值是 1
        children: [
          ['/business/introduction/', '使用说明'],
          ['/business/cam/', 'cam-sdk(CAM权限)'],
          ['/business/auth/', 'auth-sdk(二次认证)'],
          ['/business/tag/', 'tag-sdk(标签)'],
          ['/business/sg/', 'sg-sdk（租户端安全组）'],
          ['/business/cls/', 'cls-sdk（日志服务）'],
          ['/business/tsm/', 'tsm-sdk(容器监控模块)'],
          ['/business/monitor/', 'monitor-v2-sdk(监控)'],
          ['/business/cwhistle/', 'cwhistle-sdk(云哨)'],
          ['/business/project/', 'project-sdk（项目）'],
          ['/business/umanage/', 'umanage-sdk（客户管理）'],
          ['/business/announce/', 'announce-sdk（公告）'],
        ]
      }
    ]
  }
};
