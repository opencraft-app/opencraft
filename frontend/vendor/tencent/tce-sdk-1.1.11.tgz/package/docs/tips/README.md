# 顶部提示

::: tip 说明
主要用于前端发送请求的时候，用于显示及隐藏loading，以及显示成功或者失败的tips，下面的使用只介绍通过 npm 安装方式的使用，其他方式的使用请参考 [介绍使用](/introduction/) 里面的用法
:::

## 显示loading

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |  >= 3.10.0   |  :x:   |     :x:      |  >= 3.10.0   |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | >=2.3.0 |

> 使用示列

```ts
import { tips } from '@tencent/tce-sdk';
tips.showLoading()
```

> 效果示例

![tips.showLoading](./loading.png)


> 出入参说明
```ts
/**
 * 显示loading
 * @param text loading文本
 */
export declare function showLoading(text?: string): void;
```

## 隐藏loading

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |  >= 3.10.0   |  :x:   |     :x:      |  >= 3.10.0   |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | >=2.3.0 |

> 使用示列

```ts
import { tips } from '@tencent/tce-sdk';
tips.hideLoading()
```

> 出入参说明
```ts
/**
 * 隐藏loading
 */
export declare function hideLoading(): void;
```

## 成功提示

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |  >= 3.10.0   |  :x:   |     :x:      |  >= 3.10.0   |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | >=2.3.0 |

> 使用示列

```ts
import { tips } from '@tencent/tce-sdk';
tips.success('操作成功')
```

> 效果示例

![tips.showLoading](./success.png)

> 出入参说明
```ts
/**
 * 成功提示
 * @param text 提示内容
 * @param duration 持续时间，默认为5秒
 */
export declare function success(text: string, duration?: number): void;
```

## 失败提示

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |  >= 3.10.0   |  :x:   |     :x:      |  >= 3.10.0   |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | >=2.3.0 |

> 使用示列

```ts
import { tips } from '@tencent/tce-sdk';
tips.error('操作失败')
```

> 效果示例

![tips.showLoading](./error.png)

> 出入参说明
```ts
/**
 * 失败提示
 * @param text 提示内容
 * @param duration 持续时间，默认为5秒
 */
export declare function success(text: string, duration?: number): void;
```
