# 文件服务

::: tip 说明
文件服务模块主要是提供平台通用的文件上传和下载 SDK，下面的使用只介绍通过 npm 安装方式的使用，其他方式的使用请参考 [介绍使用](/introduction/) 里面的用法
:::

::: warning 注意
在使用文件服务的时候需要先找 TCE 平台同学申请接入，会根据不同的业务分配上传文件需要的`appId`，TCE 联系`yaweihuang`,TCS 联系`binxiong`，[接入指引](https://iwiki.woa.com/pages/viewpage.action?pageId=1655173678)
:::

## 上传单个文件

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |  >= 3.11.0   |  >= 3.11.0   |     :x:      |  >= 3.11.0   |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | >= 2.3.0 |

> 使用示列

```ts
import { file } from '@tencent/tce-sdk';
// 组装参数
const fd = new FormData();
fd.append('file', document.querySelector('#fileInput').files[0]); // 获取上传文件放入fomData里面
const param = {
  appId: '123143', // 应用ID【平台分配】
  module: 'content', // 应用模块【接入时协商确认】
  file: fd // FormData类型
}
const resp = await file.upload(param);
// 出参示例【正常情况】
{
    "res": {
        "url": "//file.tcenter-dev-3100.tcecloud.fsphere.cn/public/assets/announce/content/ocloud/77d00c83e3bdd0b02dda1f8599f05d35.svg"
    }
}
// 出参示例【错误情况】,有err的时候说明就是报错了
{
    "err": {
      "code": "InvalidRequest.CheckLoginStatusFailed",
      "message": "check login status failed"
    },
    "res": undefined
}
```

> 出入参情况

```ts
/**
 * 文件上传
 * @param uploadParam 上传参数
 * @returns Promise<IFileUploadResp>
 */
export declare function upload(
  uploadParam: IFileUploadParam
): Promise<IFileUploadResp>;
export interface IFileUploadParam {
  /**
   * 接入的应用ID
   */
  appId: string;
  /**
   * 上传的模块名称
   */
  module: string;
  /**
   * 上传的文件
   */
  file: FormData;
}
interface IFileUploadRespData {
  url: string;
}
export declare type IFileUploadResp = IAPIResponse<IFileUploadRespData>;
export interface Error {
  code: string;
  message: string;
  requestId: string;
}
export interface IAPIResponse<T extends object> {
  /**
   * 接口返回的业务数据
   */
  res: T;
  /**
   * 接口失败返回的错误对象，err不为null表示接口失败了
   */
  err?: Error;
}
```

## 获取上传地址

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |  >= 3.11.0   |  >= 3.11.0   |     :x:      |  >= 3.11.0   |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | >= 2.3.0 |

> 使用示列

```ts
import { file } from "@tencent/tce-sdk";
// 组装参数
const fd = new FormData();
const param = {
  appId: "123143", // 应用ID【平台分配】
  module: "content", // 应用模块【接入时协商确认】
};
const uploadUrl = file.getUploadUrl(param);
// 出参示例
"//file.tet.com/public/api/upload?appId=test&module=test&nonce=1652237231840&platform=ocloud&timestamp=1652237231840"
```

> 出入参情况

```ts
/**
 * 获取上传服务的链接
 * @param param 入参
 */
export declare function getUploadUrl(param: IGetFileUploadUrlParam): string;
export interface IGetFileUploadUrlParam {
  /**
   * 接入的应用ID
   */
  appId: string;
  /**
   * 上传的模块名称
   */
  module: string;
}
```
