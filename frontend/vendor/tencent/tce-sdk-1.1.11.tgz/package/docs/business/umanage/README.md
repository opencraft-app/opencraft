# umanage-sdk（客户管理）

::: tip 说明
提供给appId一个bubble组件，可以获取appid对应租户的信息
:::

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   :x:   |   >= 3.10.0   |     :x:      |    >= 3.10.0   |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | :x: |

> 入参
```ts
declare const UMANAGE: {
  getComponent: () => typeof AppIdBubble;
};

interface IProps extends StyledProps {
  AppId?: number;
  Uin?: number;
  children ?: React.ReactNode
}
declare const AppIdBubble: ({ AppId, Uin, ...rest }: IProps) => JSX.Element;

```


> 使用示例

```ts
import { component } from '@tencent/tce-sdk';


export const Demo = ()=>{
    const getCmp = useRef(null);
    useEffect(() => {
        component.getComponent('umanage-sdk').then((res) => {
          getCmp.current = res;
        });
    }, []);
    const columns = [
        {
            key: 'AppId',
            header: 'AppId',
            render:({ AppId })=>{
                const WrappedAppid =  getCmp.current?.getComponent();
                return WrappedAppid ? <WrappedAppid AppId={AppId}> : <span>{AppId}</span>
            }
        }
    ]
}

```