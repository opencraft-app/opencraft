## 基本能力介绍

云哨SDK，主要输出云哨一些公共能力，主要包括以下能力：

1. 渲染云哨数据源的监控图表：支持直接渲染和抽屉渲染。
    1. 直接渲染：`<MonitorChart />`
    2. 在抽屉中打开: `showMonitorChartInDrawer`
2. 工具方法输出
    1. `getUnits`: 获取全部单位列表（仅支持230,310以后版本）。
    2. `valueProcessor`:单位与值转换能力（仅支持230,310以后版本）。 用法参考[文档](./src/utils/value-processor/README.md).

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   >= 3.10.0   |   >= 3.10.0   |     :x:      |   >= 3.10.0    |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | >= 2.3.0  |

## 如何使用

具体参考 tce sdk [文档](http://dragon.tce.woa.com/page/devDocument/tce-sdk)的业务 SDK 部分.

``` typescript
import { component } from '@tencent/tce-sdk';
const cwhistleSdk = await component.getComponent('cwhistle-sdk');
const { MonitorChart, showMonitorChartInDrawer, utils: { getUnits, valueProcessor } } = cwhistleSdk;
```

工具方法挂载在 utils 下面.

## API 介绍

### MonitorChart

| 属性|描述|默认值|类型|
| --- | ---|---|---|
| categories | 图表的配置分类，包括指标名 | null | Category[] |
| dimensions | 维度信息，例如 { ip: 10.2.3.45 }，最好传入 tcs_product 以及 tcs_type，分别对应云哨的云产品和模块信息，以获得更好的渲染效果 | null | object |
| showLegend | 是否展示图例，如果提供了tcs_type，则会按云哨的格式展示图例，如果监控对象超过4个，不展示图例 | false | boolean |
| legendLabels | 自定义图例和tooltip中展示的label | null | string[] |
| period | 查询时序数据的时间段，通过from to传入起始时间，可以为时间戳字符串或者 Period | { from: 'now-30m', to: 'now' } | { from: Period | string; to: Period | string; } |

复杂类型的定义：

``` typescript
export type Period = 'now-30m' | 'now-1h' | 'now-24h' | 'now-7d';

export interface Category {
  // 指标分类
  type: string;

  // 分类名
  name: string;

  // 指标配置
  metrics: MetricConfig[];
}

export interface MetricConfig {
  // 指标名，例如 cpu_load_usage
  metricName: string;
  /*
  * 指标别名
  */
  metricAlias: string;
  /*
   * 指标的labels
   */
  labels?: string[];
  /*
   * 空数据提示
   */
  emptyText?: string;

  /*
   * query是promql，如果提供了query，就不会使用dimensions和metricName进行拼接
   */
  query?: string;
  /*
   * 传入标准化的单位以获得单位和阈值的转换能力，参考
   * https://doc.weixin.qq.com/sheet/e3_AKIAKAbSAK4lSMu6bPBQg68kvW1kL?scode=AJEAIQdfAAo2XXsZ0FAKIAKAbSAK4&amp;tab=BB08J2
   * 建议传入
   */
  unit?: string;
}

```

### getUnits

获取云哨体系下的所有单位列表，按需使用。

### valueProcessor

使用 `valueProcessor` 处理阈值。使用示例：

```typescript
const result = valueProcessor({
    unit: 'kb/s', 
    value: 3800, // required, 当前的阈值
    unitCatalogs: [],
    asPrefix: false, // 是否把单位左右前缀来展示，例如: 个100, 默认展示为后缀
    needFormat: true, 
})
```

参数介绍：

1. unit: required, 当前指标的单位Id，必须是 https://doc.weixin.qq.com/sheet/e3_AKIAKAbSAK4lSMu6bPBQg68kvW1kL?scode=AJEAIQdfAAo2XXsZ0FAKIAKAbSAK4&amp;tab=BB08J2 中的标准数据，也可以在 getUnits 中获得
2. value: required, 当前的阈值
3. unitCatalogs: 第1步拿到 catalogs，可不传，最好传入，传入时使用云哨数据转换单位，不传则按Grafana方案转换
4. asPrefix: 是否把单位作为前缀来展示，例如: 个 100, 默认展示为后缀
5. needFormat: 是否需要格式化为字符串，默认true，如果false，则返回如下结构体：

```typescript
result = {
    text: value, // 转换为的阈值
    prefix: unit, // 转换后的单位，asPrefix 为 true 返回
    suffix: unit, // 转换后的单位，asPrefix 为 false 返回
}
```
