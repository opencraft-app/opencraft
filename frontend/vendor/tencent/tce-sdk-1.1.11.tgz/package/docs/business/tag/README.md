# tag-sdk(标签)

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |  >= 3.10.0   |  >= 3.10.0   |     :x:      |     :x:      |

**TCS**:

| 登录页 | 控制台 |
| :----: | :----: |
|  :x:   |  :x:   |

## 批量编辑标签(batchEditTag)

![showEditTag](./images/showEditTag.png)

```ts
import { component } from '@tencent/tce-sdk';

async function showEditTag() {
  let params = {
    resourceIds: ['ins-jcao7lza'], //资源id（数组）
    resourcePrefix: 'instance', //资源前缀
    serviceType: 'cvm', //业务名称
    forbidCreateTagValue: false, // 是否禁止 sdk 创建新的标签值，若为 true，则标签的下拉框会变为带搜索框的 select 框。
    region: 'ap-guangzhou', //地域
    callback: function (action, updateData) {
      //点击确认按钮（或请求完成）后执行的业务函数
      // action=taskBoxClose代表任务未完成用户提前关闭任务框, action=complete代表任务完成
    },
  };
  try {
    const { batchEditTag } = await component.getComponent('tag-sdk');
    batchEditTag(params);
  } catch (e) {
    return app.tips.error(t('加载sdk失败'));
  }
}
```

## 显示标签 table(showTagTable)

![showTagTable](./images/showTagTable.png)

```ts
import { component } from '@tencent/tce-sdk';

const tagSDK = await component.getComponent('tag-sdk');
 tagSDK.showTagTable({
       tagType: 'add',
       node: window.$('#tag_table')[0]
       callback: function(data) {
        console.log(data);
      }
    });
```

## 跨资源类型批量编辑标签组件(batchEditTagForMultiType)

> ( serviceType, region, resourcePrefix 任一字段不一致即为跨资源类型 )

```ts
/**
 * @typedef {{ resourceId: string; resource: string; replaceTags: {}[]; deleteTags: {}[] }} CommitData
 * @typedef {{
 *  region: string; // 地域
 *  serviceType: string; // 业务名称
 *  resourcePrefix: string; // 资源前缀
 *  resourceId: string; // 资源id
 * }} ResourceItem
 * @typedef {{
 *  resources: ResourceItem[];
 *  onCancel?: () => void; // 取消的回调函数
 *  onOk?: (commitData?: CommitData[], event?: 'onOk' | 'onClose') => void; // 修改完成的回调函数
 *  max?: number; // 默认值为 50，可设置标签个数最大上限, 支持 1~50
 *  autoCommit?: boolean; // 是否自动提交，默认为 true
 * }} BatchTagEditOption
 */
import { component } from '@tencent/tce-sdk';
async function onClickEditTag() {
  try {
    const { batchEditTagForMultiType } = await component.getComponent('tag-sdk');
    batchEditTagForMultiType({
      resources: [
        {
          region: 'ap-guangzhou',
          serviceType: 'cvm',
          resourcePrefix: 'instance',
          resourceId: 'ins-bg52vucg',
        },
      ],
      onOk: (commitData, event) => {},
      onCancel: () => {},
      max: 50, // 限制所选标签对个数，默认为 50, 可设置 1~50 范围的 值
    });
  } catch (e) {
    return app.tips.error(t('加载sdk失败'));
  }
}
```

## 标签选择组件(TagSelectPanel)

![selectTag](./images/selectTag.png)

```ts
import React, { useState, useEffect, useCallback } from 'react';
import { component } from '@tencent/tce-sdk';
import { t } from '@tce/app/i18n';
import { Card, LoadingTip, Form } from '@tencent/tea-component';
function Demo() {
  const [TagComponents, setTagComponents] = useState({
    InfoTip: null,
    TagSelectPanel: null,
  });
  const loadComponent = useCallback(async () => {
    try {
      const tagSDK = await component.getComponent('tag-sdk'); // 加载 SDK
      const { InfoTip, TagSelectPanel } = tagSDK.components; // 加载完成后从 components 属性上取出组件
      setTagComponents({
        InfoTip, // 提示组件
        TagSelectPanel, // 标签选择组件
      });
    } catch (error) {
      /** handle error */
    }
  }, []);
  useEffect(() => {
    loadComponent();
  }, []);
  const { InfoTip, TagSelectPanel } = TagComponents;
  return (
    <Card>
      <Card.Body>
        <Form>
          <Form.Item
            label={
              <>
                {t('标签（选填）')}
                {InfoTip && <InfoTip></InfoTip>} {/* 提示 */}
              </>
            }
            align="top"
          >
            {TagSelectPanel ? (
              <TagSelectPanel max={5} onChange={console.log}></TagSelectPanel>
            ) : (
              <LoadingTip></LoadingTip>
            )}
          </Form.Item>
        </Form>
      </Card.Body>
    </Card>
  );
}

export default Demo;
```

## 标签选择过滤组件(TagSelectPanelWithConfirm)

![filterTag](./images/filterTag.png)

```ts
import React, { useState, useMemo, useEffect, useCallback, useRef } from 'react';
import { component } from '@tencent/tce-sdk';
import { t } from '@tce/app/i18n';
import { Card, LoadingTip, TagSearchBox } from '@tencent/tea-component';
function Demo() {
  const tagConstantsRef = useRef({
    TAG_VALUE_ALL: '',
    TAG_VALUE_UNSET: '',
    TAG_KEY_VALUE_SEP: '',
  });
  const [TagComponents, setTagComponents] = useState({
    TagSelectPanelWithConfirm: null,
  });
  const [tags, setTags] = useState([]);
  const loadComponent = useCallback(async () => {
    try {
      const tagSDK = await component.getComponent('tag-sdk');
      const { TagSelectPanelWithConfirm } = tagSDK.components;
      tagConstantsRef.current = tagSDK.constants;
      setTagComponents({ TagSelectPanelWithConfirm });
    } catch (error) {
      /** handle error */
    }
  }, []);
  useEffect(() => {
    loadComponent();
  }, []);
  useEffect(() => {
    console.log(tags);
  }, [tags]);
  const { TagSelectPanelWithConfirm } = TagComponents;
  /** @type {any} */
  const attributes = useMemo(
    () => [
      {
        type: 'render',
        key: 'tag',
        name: t('标签'),
        reusable: true,
        render: ({ inputValue, onSelect, onCancel }) => (
          <>
            {TagSelectPanelWithConfirm ? (
              <TagSelectPanelWithConfirm
                asFilter
                disableUnset={false}
                max={5} // 限制最多选择 5 对标签键值
                allowDuplicatedKey
                defaultValue={String(inputValue)
                  .split('|')
                  .map((tagPair) => {
                    const [tagKey, tagValue] = String(tagPair).trim().split(tagConstantsRef.current.TAG_KEY_VALUE_SEP);
                    return { tagKey, tagValue };
                  })}
                style={{ padding: 16 }}
                bordered={false}
                onOk={(tagList) => {
                  onSelect(
                    tagList.map(({ tagKey, tagValue }) => ({
                      key: `${tagKey}${tagConstantsRef.current.TAG_KEY_VALUE_SEP}${tagValue}`,
                      name: `${tagKey}${tagConstantsRef.current.TAG_KEY_VALUE_SEP}${tagValue}`, // 因为冒号是合法的标签键值内容，这里使用了特殊的分隔符
                    })),
                  );
                }}
                onCancel={onCancel}
              />
            ) : (
              <LoadingTip />
            )}
          </>
        ),
      },
    ],
    [TagSelectPanelWithConfirm],
  );
  return (
    <Card>
      <Card.Body>
        <h3>{t('筛选标签')}</h3>
        <div>
          <TagSearchBox
            attributes={attributes}
            minWidth={420}
            value={tags}
            onChange={(tags) => {
              setTags(tags);
              console.log(tags);
            }}
          />
        </div>
      </Card.Body>
    </Card>
  );
}

export default Demo;
```

## 表格头标签筛选插件/标签 Icon 展示组件(tagFilterable/TagDisplayIcon)

![headFilterTag](./images/headFilterTag.png)

```ts
import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { component } from '@tencent/tce-sdk';
import { t } from '@tce/app/i18n';
import { Card, Icon, LoadingTip, Button, Table } from '@tencent/tea-component';
const defaultRecords = [
  {
    fnName: 'tencentcloud_sdk_nodejs',
    monitor: '_nodejs',
    env: 'Node 12.18.4',
    tags: [
      { tagKey: '运营产品', tagValue: '云上加州' },
      { tagKey: '运营平台', tagValue: '公有云' },
    ],
  },
  {
    fnName: 'tencentcloud_sdk_python3',
    monitor: '_python3',
    env: 'Python 3.6',
    tags: [
      { tagKey: '运营产品', tagValue: '云上加州' },
      { tagKey: '运营平台', tagValue: '私有云' },
      { tagKey: '企业组织', tagValue: 'CSIG云与智慧产业事业群/云产品部/平台产品中心/官网业务组/前台研发组' },
    ],
  },
  {
    fnName: 'tencentcloud_sdk_golang',
    monitor: '_golang',
    env: 'Golang 1.9',
    tags: [],
  },
];
function Demo() {
  const tagConstantsRef = useRef({
    TAG_VALUE_ALL: '',
    TAG_VALUE_UNSET: '',
    TAG_KEY_VALUE_SEP: '',
  });
  const [tagTableAddons, setTagTableAddons] = useState({
    tagFilterable: null,
  });
  const [tagComponents, setTagComponents] = useState({
    TagDisplayIcon: null,
  });
  const [filteringTags, setFilteringTags] = useState([{}]);
  const loadTableAddons = useCallback(async () => {
    try {
      const tagSDK = await component.getComponent('tag-sdk');
      const { tagFilterable } = tagSDK.tableAddons;
      tagConstantsRef.current = tagSDK.constants;
      setTagTableAddons({ tagFilterable });
      setTagComponents({ TagDisplayIcon });
    } catch (error) {
      /** handle error */
    }
  }, []);
  useEffect(() => {
    loadTableAddons();
  }, []);
  useEffect(() => {
    console.log(filteringTags);
    // TODO: trigger loading data filter by tags
  }, [filteringTags]);
  const { tagFilterable } = tagTableAddons;
  const { TagDisplayIcon } = tagComponents;
  const columns = useMemo(
    () => [
      { header: '函数名', key: 'fnName' },
      {
        header: '监控',
        key: 'monitor',
        render: () => <Icon type="chart-column" />,
      },
      { header: '运行环境', key: 'env' },
      {
        header: '标签',
        key: 'tags',
        render: ({ tags }) => (TagDisplayIcon ? <TagDisplayIcon tags={tags} /> : <LoadingTip />),
      },
      {
        header: '操作',
        key: '',
        render: () => (
          <div>
            <Button type="link">配置函数</Button>
            <Button type="link">删除</Button>
          </div>
        ),
      },
    ],
    [TagDisplayIcon],
  );
  return (
    <Card>
      <Card.Body>
        <h3>{t('表格头标签筛选')}</h3>
        <div>
          <Table
            records={defaultRecords}
            columns={columns}
            addons={[
              ...(tagFilterable
                ? [
                    tagFilterable({
                      column: 'tags',
                      value: filteringTags,
                      onChange: (tags) => setFilteringTags(tags),
                      max: 3,
                      asFilter: true,
                      disableUnset: true,
                    }),
                  ]
                : []),
            ]}
          />
        </div>
      </Card.Body>
    </Card>
  );
}

export default Demo;
```

## 标签展示组件(TagDisplayCollapse)

![readonly](./images/readonly.png)

```ts
import React, { useState, useEffect, useCallback } from 'react';
import { component } from '@tencent/tce-sdk';
import { t } from '@tce/app/i18n';
import { Card, Form, LoadingTip } from '@tencent/tea-component';
function Demo() {
  const [TagComponents, setTagComponents] = useState({
    TagDisplayCollapse: null,
  });
  const loadComponent = useCallback(async () => {
    try {
      const tagSDK = await component.getComponent('tag-sdk');
      const { TagDisplayCollapse } = tagSDK.components;
      setTagComponents({
        TagDisplayCollapse,
      });
    } catch (error) {
      /** handle error */
    }
  }, []);
  useEffect(() => {
    loadComponent();
  }, []);
  const tags = [
    {
      tagKey: '企业组织',
      tagValue:
        'CSIG云与智慧产业事业群/云产品部/平台产品中心/官网业务组/前台研发组/CSIG云与智慧产业事业群/云产品部/平台产品中心/官网业务组/前台研发组/CSIG云与智慧产业事业群/云产品部/平台产品中心/官网业务组/前台研发组',
    },
    { tagKey: '运营产品', tagValue: '云上加州' },
    {
      tagKey: '企业组织',
      tagValue: 'CSIG云与智慧产业事业群/云产品部/平台产品中心/官网业务组/前台研发组',
    },
    { tagKey: '运营产品', tagValue: '云上加州' },
    { tagKey: '运营平台', tagValue: '私有云' },
    { tagKey: '运营平台', tagValue: '' },
    {
      tagKey: '企业组织',
      tagValue: 'CSIG云与智慧产业事业群/云产品部/平台产品中心/官网业务组/前台研发组',
    },
  ];
  const { TagDisplayCollapse } = TagComponents;
  return (
    <Card>
      <Card.Body>
        <h3>{t('标签展示组件')}</h3>
        <div style={{ padding: 32, backgroundColor: '#f1f1f1' }}>
          <Card>
            <Card.Body title={t('基础信息')}>
              <Form readonly>
                <Form.Item label="触发方式">
                  <Form.Text>{t('测试使用_test_01')}</Form.Text>
                </Form.Item>
                <Form.Item label={t('运行环境')}>
                  <Form.Text>Nodejs 8.11</Form.Text>
                </Form.Item>
                <Form.Item label={t('内存')}>
                  <Form.Text>128 MB</Form.Text>
                </Form.Item>
                <Form.Item label={t('描述')}>
                  <Form.Text>
                    <pre>qcs::uin/20121232321:ap-guangzhou:scf-iot:device/ins-12uids9p</pre>
                  </Form.Text>
                </Form.Item>
                <Form.Item label={t('标签')}>
                  {TagDisplayCollapse ? (
                    <TagDisplayCollapse tags={tags} showEdit onEdit={() => console.log('$OnClickEdit')} />
                  ) : (
                    <LoadingTip />
                  )}
                </Form.Item>
              </Form>
            </Card.Body>
          </Card>
        </div>
      </Card.Body>
    </Card>
  );
}
export default Demo;
```
