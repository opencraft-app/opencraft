# announce-sdk（客户管理）

::: tip 说明
为租户端和运营端提供顶部公告导航
:::

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   >= 3.10.0   |   >= 3.10.0   |     :x:      |    >= 3.10.0   |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | :x: |

> 使用示例

```ts
import { component } from '@tencent/tce-sdk';

const { render } = await component.getComponent('announce-sdk') || {}
 // MOUNTID为dom挂载点
render('MOUNTID')

```

> 效果展示

![showBreakTips](./images/break_tips.png)