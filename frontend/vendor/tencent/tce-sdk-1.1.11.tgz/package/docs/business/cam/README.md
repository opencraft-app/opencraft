# cam-sdk(CAM 权限)

::: tip 说明
CAM 模块主要是提供平台通用的无权限拦截组件，下面的使用只介绍通过 npm 安装方式的使用，其他方式的使用请参考 [介绍使用](/introduction/) 里面的用法
:::

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   >= 3.9.0   |   >= 3.9.0   |     :x:      |   >= 3.9.0   |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | >= 2.1.0 |

## 显示弹窗(showBreakModal)

> 入参

```ts
export interface CamBreakWithDetailProps {
  /**
   * operation 信息
   */
  operation: string;

  /**
   * resource 信息
   */
  resource: string;

  /**
   * requestId
   */
  requestId?: string;
}

export interface CamBreakWithMessageProps {
  /**
   * 失败信息
   */
  message: string;
}

export type CamBreakProps = CamBreakWithMessageProps | CamBreakWithDetailProps;

// 以弹窗方式显示
export function showBreakModal(options: CamBreakProps & { onClose?: () => void }); // onClose为modal关闭时的回调
```

> 使用示例

```ts
import { cam } from '@tencent/tce-sdk';
const CAM = await cam.getCAM();

CAM.showBreakModal({
  message:
    '[request id:e41eefff-b7be-4a99-acfa-92d6f82d1f19]you are not authorized to perform operation (cvm:DescribeInstances) resource (qcs::cvm:bj:uin/370723235:instance/*) has no permission (e41eefff)',
});
```

> 效果展示

![showBreakModal](./images/break_modal.png)

## 显示 message(showBreakTips)

> 入参

```ts
export interface CamBreakWithDetailProps {
  /**
   * operation 信息
   */
  operation: string;

  /**
   * resource 信息
   */
  resource: string;

  /**
   * requestId
   */
  requestId?: string;
}

export interface CamBreakWithMessageProps {
  /**
   * 失败信息
   */
  message: string;
}

export type CamBreakProps = CamBreakWithMessageProps | CamBreakWithDetailProps;

// 以message方式显示
export function showBreakTips(props: CamBreakProps);
```

> 使用示例

```ts
import { cam } from '@tencent/tce-sdk'
const CAM = await cam.getCAM();

CAM.showBreakTips({
  operation: "cvm:DescribeInstances",
  resource: "qcs::cvm:bj:uin/370723235:instance/*",
}),
```

> 效果展示

![showBreakTips](./images/break_tips.png)

## 通过异步获取 React 组件渲染界面(CAMBreak)

> 入参

```ts
export interface CamBreakWithDetailProps {
  /**
   * operation 信息
   */
  operation: string;

  /**
   * resource 信息
   */
  resource: string;

  /**
   * requestId
   */
  requestId?: string;
}

export interface CamBreakWithMessageProps {
  /**
   * 失败信息
   */
  message: string;
}

export type CamBreakProps = CamBreakWithMessageProps | CamBreakWithDetailProps;

// 在传入的node节点下渲染界面
export function CAMBreak(options: CamBreakProps);
```

> 使用示例

```ts
import { cam } from '@tencent/tce-sdk';
const CAM = await cam.getCAM();

function CAMBreak() {
  const [CAMComponent, setCAMComponent] = useState(() => <p>loading</p>);
  React.useEffect(() => {
    (async () => {
      try {
        const { CAMBreak } = await cam.getCAM();
        setCAMComponent(() => <CAMBreak />);
      } catch {
        setCAMComponent(() => <p>error</p>);
      }
    })();
  }, []);
  return CAMComponent;
} // 使用时自行封装异步请求组件的过程

<CAMBreak />;
```

> 效果展示

![addCamBreak](./images/add_break_modal.png)

## 通过传入节点渲染界面(addCamBreak)

> 入参

```ts
export interface CamBreakWithDetailProps {
  /**
   * operation 信息
   */
  operation: string;

  /**
   * resource 信息
   */
  resource: string;

  /**
   * requestId
   */
  requestId?: string;
}

export interface CamBreakWithMessageProps {
  /**
   * 失败信息
   */
  message: string;
}

export type CamBreakProps = CamBreakWithMessageProps | CamBreakWithDetailProps;
export type AddBreakOptions = CamBreakProps & { node: HTMLElement }; // 在失败信息的参数外多了个node参数，为渲染组件的挂载

// 在传入的node节点下渲染界面
export function addCamBreak(options: AddBreakOptions);
```

> 使用示例

```ts
import { cam } from '@tencent/tce-sdk'
const CAM = await cam.getCAM();

CAM.addCamBreak({
  node:document.body
  message: "[request id:e41eefff-b7be-4a99-acfa-92d6f82d1f19]you are not authorized to perform operation (cvm:DescribeInstances) resource (qcs::cvm:bj:uin/370723235:instance/*) has no permission (e41eefff)"
})
```

> 效果展示

![addCamBreak](./images/add_break_modal.png)

## 渲染 icon(addCamBreakIcon)

> 入参

```ts
export interface CamBreakWithDetailProps {
  /**
   * operation 信息
   */
  operation: string;

  /**
   * resource 信息
   */
  resource: string;

  /**
   * requestId
   */
  requestId?: string;
}

export interface CamBreakWithMessageProps {
  /**
   * 失败信息
   */
  message: string;
}

export type CamBreakProps = CamBreakWithMessageProps | CamBreakWithDetailProps;
export type AddBreakOptions = CamBreakProps & { node: HTMLElement }; // 在失败信息的参数外多了个node参数，为渲染组件的挂载

// 在传入的node节点下渲染带有提示界面bubble的alert-icon
export function addCamBreakIcon(options: AddBreakOptions);
```

> 使用示例

```ts
import { cam } from '@tencent/tce-sdk'
const CAM = await cam.getCAM();

CAM.addCamBreakIcon({
  node:document.body
  operation: "cvm:DescribeInstances",
  resource: "qcs::cvm:bj:uin/370723235:instance/*",
}),
```

> 效果展示

![addCamBreakIcon](./images/add_break_icon.png)

## 检查角色(haveRole)

> 入参

```ts
export interface GetRoleReq {
  /**
   * 角色 ID，用于指定角色，入参 RoleId 与 RoleName 二选一
   */
  roleId?: string;
  /**
   * 角色名，用于指定角色，入参 RoleId 与 RoleName 二选一
   */
  roleName?: string;
}

export interface CamGetRoleRes {
  code: number; // 0: 正常 -1: 没有角色 -2: GetRole无权限 -3: 其它错误
  message?: string;
}
// 检查角色
export async function haveRole(req: GetRoleReq): Promise<CamGetRoleRes>;
```

> 使用示例

```ts
import { cam } from '@tencent/tce-sdk';
const CAM = await cam.getCAM();

// 检查角色
const roleResult = await CAM.haveRole({ roleName: 'TKE_QCSRole' });
```

## 检查策略(havePolicies)

> 入参

```ts
export interface HavePoliciesParam {
  roleName: string;
  policies: string | string[];
}

export interface CamGetRoleRes {
  code: number; // 0: 正常 -1: 没有角色 -2: GetRole无权限 -3: 其它错误
  message?: string;
}

export interface CamListAttachedRolePoliciesRes extends CamGetRoleRes {
  data?: {
    attachQueue: string[]; // 匹配的policies的列表
    notAttachQueue: string[]; // 未匹配的policies的列表
  }; //如果返回的policies包含所有入参的policies则返回该data展示未包含的policies
}

// 检查策略
export async function havePolicies(req: HavePoliciesParam): Promise<CamListAttachedRolePoliciesRes>;
```

> 使用示例

```ts
import { cam } from '@tencent/tce-sdk';
const CAM = await cam.getCAM();

// 检查策略
const policyResult = await CAM.havePolicies({
  roleName: 'TKE_QCSRole',
  policies: ['QcloudCOSAccessForCkafkaRole'],
});
```

## 显示授权弹窗(showRoleGrantDialog)

> 入参

```ts
export interface ShowRoleGrantDialogProps {
  /**
   * 关联完角色后，回跳到的业务地址
   */
  s_url: string;
  /**
   * 服务类型
   */
  serviceType: string;
  /**
   * 角色名
   */
  roleName: string;
  /**
   * 策略名列表，字符串，逗号分隔
   */
  policyName: string;
  /**
   * 功能描述
   */
  functionDesc: string;
  /**
   * 默认值为'blank'，填入其他值则在当前页面直接跳转
   */
  target?: string;
}

export function showRoleGrantDialog(options: ShowRoleGrantDialogProps): Promise<unknown>;
```

> 使用示例

```ts
import { cam } from '@tencent/tce-sdk';
const CAM = await cam.getCAM();

CAM.sowRoleGrantDialog({
  roleName: 'BK_QcsRole',
  serviceType: 'tsf',
  policyName: 'QcloudAccessForBKRole',
  s_url: 'http://test.com',
  functionDesc: '',
});
```

> 效果展示

![showBreakModal](./images/grant_dialog.png)
