# project-sdk（项目）

::: tip 说明
为 计量计费提供获取项目列表，项目目录列表功能
:::

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   >= 3.10.0   |   >= 3.10.0   |     :x:      |   :x:   |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | :x: |

> 使用示例

```ts
import { component } from '@tencent/tce-sdk';
// 项目选择
async function getProject () {
  const { renderProjectSelect } = await component.getComponent('project-sdk');
  renderProjectSelect({
    onChange: (value)=> {
      console.log('value',value) // 获取选择的值
    }
  })
}
// 项目目录选择
async function getProject () {
  const { renderProjectTreeSelect } = await component.getComponent('project-sdk');
  renderProjectTreeSelect({
    onChange: (value)=> {
      console.log('value',value) // 获取选择的值
    }
  })
}
```