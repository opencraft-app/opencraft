# cls-sdk（日志服务）

::: tip 说明
为腾讯云控制台业务业务提供 CLS 能力
日志检索页渲染
仪表盘页面渲染
日志采集配置编辑
:::

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |  >= 3.10.0   |  >= 3.10.0   |     :x:      |     :x:      |

**TCS**:

| 登录页 | 控制台 |
| :----: | :----: |
|  :x:   |  :x:   |

## 类型定义

```shell
npm i @tencent/tea-sdk-cls-types --registry=http://r.tnpm.oa.com --proxy=http://127.0.0.1:12639
```

```ts
import { ISdkApi as IClsSdkApi } from '@tencent/tea-sdk-cls-types';
```

## 仪表盘组件(DashboardPageComponent)

> 获取 ReactComponent，在 React 组件中调用，使用 Ref 获取控制器。仅适用于在 React 组件中进行调用

```tsx
import { component } from '@tencent/tce-sdk';

const clsSdk = await component.getComponent('cls-sdk');
const DashboardPageComponent = clsSdk?.DashboardPage?.DashboardPageComponent;
const dashboardControlRef = useRef<ISdkDashboardPageControl>(null);

return DashboardPageComponent ? (
  <DashboardPageComponent
    // 指定云产品模板与数据源变量值 （云产品接入推荐方式）
    pageParams={{
      templateId: 'tke-audit-overview',
      'var-ds': `${region},${TopicId}`, // ap-chongqing,d12a9fe4-4997-4762-a083-d387ec79f077
    }}
    // 指定仪表盘ID
    pageParams={{
      id: dashboardId,
    }}
    hideParams={hideComponentParams}
    controlRef={dashboardControlRef}
  />
) : (
  <div />
);
```

## 检索页组件(SearchPageComponent)

> 获取 ReactComponent，在 React 组件中调用，使用 Ref 获取控制器。仅适用于在 React 组件中进行调用

```tsx
import { component } from '@tencent/tce-sdk';

const clsSdk = await component.getComponent('cls-sdk');
const SearchPageComponent = clsSdk?.SearchPage?.SearchPageComponent;
const searchControlRef = useRef<ISdkSearchPageControl>(null);

return SearchPageComponent ? (
  <SearchPageComponent
    pageParams={{
      region: REGIONIDMAP[searchPageTabData.regionId],
      // logsetId: searchPageTabData.logsetId,
      topicId: searchPageTabData.topicIds?.[0],
    }}
    hideParams={hideComponentParams}
    controlRef={searchControlRef}
  />
) : (
  <div />
);
```

## 采集配置编辑组件(LogParsingModeComponent)

业务调用后通过 onChange 函数获取当前表单的内容结果。 表单结果的类型为 IExtractConfig，其中 isValid 表示表单输入状态的合法性。

```tsx
// 此处为CLS业务自身调用方式样例。defaultValue类型采用即将发布的APIv3格式
import { ISdkApi as IClsSdkApi, IExtractConfig } from '@tencent/tea-sdk-cls-types';
import { component } from '@tencent/tce-sdk';

const clsSdk = await component.getComponent('cls-sdk');
const LogParsingModeComponent = clsSdk?.LogParsingMode?.LogParsingModeComponent;
const agentUpdateConfig = function (topicId, regionId) {
  clsSdk?.LogParsingMode?.LoadLogParsingModeConfig(topicId, regionId).then((v) => {
    controlRef?.current?.updateConfig(v);
  });
};

return LogParsingModeComponent ? (
  <LogParsingModeComponent
    controlRef={controlRef}
    indexRuleInfo={indexStatus ? rule : null}
    defaultValue={compactExtractInfo}
    onChange={handlers.setExtractInfo}
    hideValidateInfo={!hasSubmitted}
    disableAgentPaths={true}
  />
) : (
  <div />
);

async function submit(extractInfo: IExtractConfig, ...otherParam) {
  await ModifyTopic({ body: topicParam }, TopicInfo.regionId);
  const clsSDK: IClsSdkApi = await component.getComponent('cls-sdk');
  // 重要！！！业务侧应当在调用修改采集配置成功后，应主动调用logParsingModeSubmitCallback接口，以保障下次的编辑体验。
  await clsSDK?.LogParsingMode?.logParsingModeSubmitCallback?.(TopicInfo.topic_id, TopicInfo.regionId, extractInfo);
}
```
