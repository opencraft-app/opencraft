# sg-sdk（租户端安全组）

::: tip 说明
为 CVM、CLB、ENI 提供安全组展示与编辑功能
:::

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   >= 3.10.0   |   >= 3.10.0   |     :x:      |   :x:   |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | :x: |

> 入参

```ts
// SecurityGroup / renderSecurityGroup
interface Props {
  instanceId: string;
  type?: 'cvm' | 'clb' | 'eni'; // 默认cvm
  canBindDfw?: boolean; // 默认true
  mustBindDfw?: boolean; // 默认true
  isMultiple?: boolean; // 默认true
  disabledTips?: any;
  modalSortable?: boolean; // 编辑对话框是否可排序，默认false，380开始支持
}

// useBindSecurityGroupModal / openBindSGModal
interface ModalProps {
  type: 'cvm' | 'clb' | 'eni';
  vpcId?: string; // 供ENI使用
  instanceId: string;
  onSubmit?: () => void; // 修改成功的回调
  boundSgIdList: string[]; // 已绑定的安全组id
  modalSortable?: boolean;
}
```

> 使用示例

```ts
import { component } from '@tencent/tce-sdk';
component.getComponent('sg-sdk').then((sdk) => {
  // 直接渲染安全组面板
  const sgView = sdk.renderSecurityGroup(props);

  // 使用安全组组件自己渲染
  const SecurityGroup = sdk.SecurityGroup;
  const sgView = <SecurityGroup {...props} />;

  // 以下仅在380及以后可用
  // 仅打开编辑对话框，该方法渲染的对话框会脱离文档流，但已经用ConfigProvider覆盖，并保证在关闭时卸载
  sdk.openBindSGModal(props);

  // 用hooks方式自己渲染编辑对话框
  const useBindSecurityGroupModal = sdk.useBindSecurityGroupModal;
  const [modalEl, setVisible] = useBindSecurityGroupModal(props);
});
```