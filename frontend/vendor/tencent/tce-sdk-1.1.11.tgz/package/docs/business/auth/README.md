# auth-sdk(二次认证)

::: tip 说明
AUTH 模块主要是提供平台通用的敏感操作二次认证组件，下面的使用只介绍通过 npm 安装方式的使用，其他方式的使用请参考 [介绍使用](/introduction/) 里面的用法
:::

## 短信二次验证(showAuthModal)

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   >= 3.6.0   |   >= 3.6.0   |     :x:      |   :x:   |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | :x: |

> 入参

```ts
export interface IProps {
  /**
   * 验证code的回调函数，会将用户输入的code传入其中，不填则会走yapi再次发送相同请求的同时验证身份
   */
  cb: Function;
  /**
   * 发送的请求的参数
   */
  reqData: any;
}

declare function showAuthModal({ cb, reqData }: IProps): Promise<unknown>;
```

> 使用示例

```ts
import { auth } from '@tencent/tce-sdk';
import { axios } from 'axios';

const res = await axios.post('url', reqData);

if (resp && (resp.code !== 0 || resp.data?.Response?.Error)) {
  const { code, codeDesc } = resp;
  if (code === 1000 && codeDesc === 'LogicError.NeedActionVerify') {
    const AUTH = await auth.getAUTH();
    try {
      return await AUTH.showAuthModal({ reqData }); //返回的是真正业务调用接口的返回
    } catch (err) {
      return err;
    }
  }
}
```

> 效果展示

- `showAuthModal`【显示弹窗】

![showAuthModal](./images/auth_modal.png)

## 数字证书二次验证(showAuthDigitalCertModal)

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   >= 3.8.0   |   >= 3.8.0   |     :x:      |   :x:   |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | :x: |

> 使用示例

```ts
import { auth } from '@tencent/tce-sdk';
import { axios } from 'axios';

const res = await axios.post('url', body);

if (resp && (resp.code !== 0 || resp.data?.Response?.Error)) {
  const { code, codeDesc } = resp;
  // 数字证书ukey认证【如果query中已经带上了ukey_sign，则不在继续弹窗】
  if (code === 1010 && !query?.ukey_sign) {
    // 加载auth-sdk
    const authIns: typeof AUTH = await getComponent('auth-sdk');
    return authIns.showAuthDigitalCertModal({ reqData: body, signStr: JSON.stringify(reqData) }) as any;
  }
}
```

> 入参

```ts
export interface IPromiseStatusFun {
	resolve: (value: unknown) => void;
	reject: (reason?: any) => void;
}
export interface IShowAuthDigitalCertModalConfirmData extends IPromiseStatusFun {
	sign: string;
	uKeySn: string;
}
export interface IShowAuthDigitalCertModalProps {
	/**
	 * modal的标题
	 */
	title?: string;
	/**
	 * modal的描述信息
	 */
	description?: string;
	/**
	 * Ukey序列号[如果当前用户已经绑定了，需要传入用于检验]
	 */
	userBindSN?: string;
	/**
	 * 签名字符串【不传入签名字符串则不签名】
	 */
	signStr?: string;
	/**
	 * 确认回调
	 */
	confirm?: (data: IShowAuthDigitalCertModalConfirmData) => Promise<boolean>;
	/**
	 * 取消回调
	 */
	cancel?: (data: IPromiseStatusFun) => void;
	/**
	 * 云API请求原始入参
	 */
	reqData?: any;
}
declare function showAuthDigitalCertModal(props: IShowAuthDigitalCertModalProps): Promise<unknown>;
```

> 效果展示

- `showAuthDigitalCertModal`【显示数字证书弹窗】

![showAuthDigitalCertModal](./images/auth_cert_modal.png)
