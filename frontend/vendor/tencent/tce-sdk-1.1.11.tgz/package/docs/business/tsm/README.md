# tsm-sdk(容器监控模块)

::: tip 说明
本 SDK 为腾讯云控制台业务业务提供 TSM-CHART 能力。
业务方使用 TSM-CHART, 配置拉取的数据 namespace，过滤条件，聚合维度，指标列表，即可展示对应的图表。
:::

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   >= 3.10.0   |   >= 3.10.0   |     :x:      |  :x:   |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | :x: |

## 组件渲染

> 使用示例

```tsx
import { component } from '@tencent/tce-sdk';

const [SdkComponent, setSdkComponent] = useState();

const loadComponent = useCallback(async () => {
  try {
    const tsmSdk = await component.getComponent('tsm-sdk'); // 加载 SDK
    setSdkComponent(tsmSdk);
  } catch (error) {
    /** handle error */
  }
}, []);

useEffect(() => {
  loadComponent();
}, []);

return(
  SdkComponent && <SdkComponent.ChartPanel
  tables={[
    {
      table: 'k8s_cluster',
      conditions: [['tke_cluster_instance_id', '=', 'test']],
      fields: [
        {
          expr: 'avg(k8s_cluster_cpu_core_used)',
          alias: 'CPU使用量',
          unit: '核',
        },
      ],
    },
  ]}
  groupBy={['clusterId']}
/>;
)

```