# monitor-v2-sdk(监控)

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   >= 3.10.0   |   >= 3.10.0   |     :x:      |   :x:   |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | :x: |


## monitorV2.MonitorDetailBuilder.build

```tsx
import { component } from '@tencent/tce-sdk';

const monitorV2 = await component.getComponent('monitor-v2-sdk');
    monitorV2.MonitorDetailBuilder.build({
      // 指标对应的命名空间，例如: qcm/cvm
      namespace: string;
      //对应的地域， 广州地域对应的id为1
      regionId: string | number;
      // dashboard策略Id，可以在接入系统(admin2.barad.oa.com/alarm)中找到对应的策略，然后在云监控配置中单击查看，找到对应的id
      // 如何查询configId， 见指导文档 ：https://iwiki.woa.com/pages/viewpage.action?pageId=491719080
      configId: string;
      // 告警策略简称。可以在接入系统(admin2.barad.oa.com/alarm)中找到对应的策略，然后表格中有一列是告警策略简称
      // 如何查询告警策略简称policyViewName？ 指引文档：https://iwiki.woa.com/pages/viewpage.action?pageId=491721381
      policyViewName:string;
      // 卡片是否展示阴影，`true` 为不展示阴影
      cardBorder: boolean;
      // 返回实例的信息，包含实例的维度和实例的值，用于查询该实例的监控数据
      getData: async function(index = 0) {
        // set instances
        return {
          // 监控页面的标题，一般返回实例ID
          title: string,
          // 监控页面的标题，一般返回实例描述
          subTitle: string,
          // 查询监控数据的维度。支持返回多个实例
          instances: [{InstanceId: "cdb-bwieva60"}, {InstanceId: "cdb-bwieva70"}],
          // 云监控dashboard实例回填，对应接入系统中idkey，唯一确定一个实例。
          instanceConditions: [{unInstanceId: "cdb-bwieva60"}, {unInstanceId: "cdb-bwieva70"}],
        }
      }
   }, dom)
```

## monitorV2.MonitorPanelBuilder.build

```tsx
import { component } from '@tencent/tce-sdk';

const monitorV2 = await component.getComponent('monitor-v2-sdk');
    monitorV2.MonitorPanelBuilder.build({
      // 指标对应的命名空间，例如: qce/cvm
      namespace: string;
      //对应的地域， 广州地域对应的id为1
      regionId: string | number;
      // dashboard策略Id，可以在接入系统(admin2.barad.oa.com/alarm)中找到对应的策略，然后在云监控配置中单击查看，找到对应的id
      // 如何查询configId， 见指导文档 ：https://iwiki.woa.com/pages/viewpage.action?pageId=491719080
      configId: string;
      // 告警策略简称。可以在接入系统(admin2.barad.oa.com/alarm)中找到对应的策略，然后表格中有一列是告警策略简称
      // 如何查询告警策略简称policyViewName？ 指引文档：https://iwiki.woa.com/pages/viewpage.action?pageId=491721381
      policyViewName:string;
      // 返回实例的信息，包含实例的维度和实例的值，用于查询该实例的监控数据
      getData: async function(index = 0) {
        // set instances
        return {
          // 监控页面的标题，一般返回实例ID
          title: string,
          // 监控页面的标题，一般返回实例描述
          subTitle: string,
          // 查询监控数据的维度。支持返回多个实例
          instances: [{InstanceId: "cdb-bwieva60"}, {InstanceId: "cdb-bwieva70"}],
          // 云监控dashboard实例回填，对应接入系统中idkey，唯一确定一个实例。
          instanceConditions: [{unInstanceId: "cdb-bwieva60"}, {unInstanceId: "cdb-bwieva70"}],
        }
      }
   })
```

## 支持的其他参数

在 build 的方法中还支持如下参数，业务可以根据自己的业务需要进行配置。

1. 隐藏某些 API 指标 hiddenMetrics
2. 把多个指标在一个图表中展示 groups

```ts
metricExtend:{
        // 该分组与接入配置的category不同，是用于把多个指标显示在一个图表中
  groups:[{
          // 用于显示图表的标题
    groupName: t('内网出入带宽'),
          // 唯一确定一个分组。这里是任意规则，只要保持唯一就好
    groupId:'LanOuttraffic_LanIntraffic',
    //该分组包含的指标，配置指标的名称
    metrics:['LanOuttraffic', 'LanIntraffic']
  }],
        // 这里配置mini-dashboard不需要展示的指标
  hiddenMetrics:['WanIntraffic', 'WanOuttraffic', 'WanOutpkg', 'WanInpkg', 'AccOuttraffic'],
         // 指定显示哪些指标，配置showMetrics后，hiddenMetrics参数不再生效。
  showMetrics:['WanIntraffic', 'WanOuttraffic', 'WanOutpkg', 'WanInpkg', 'AccOuttraffic']
},
```

3. 支持定制查询的时间范围。用于记录查询的时间，在多个实例切换的时候使用同一时间进行查

```ts
timeRange:{
    // 开始时间
    beginTime:1606240968000,
    // 结束时间
    endTime:1606254828000,
        // 时间调整后的回调，用于记录上次调整的时间
    callback:(beginTime, endTime)=>{
      //记录变化后的时间
    }
  };
```

4. 定制页面中每行展示图表的数量 columnCount

```ts
// 用于定制一行展示多少个表格。该参数可选，如果不传，高分辨率显示4个，低分辨率显示3个。
columnCount: number;
```

5. 如果监控页面嵌入的比较深，导致 mini-dashboard 无法正确获取到滚动条所在 dev。可以 MonitorDetailBuilder.build 参数中增加 scrollDiv

```ts
// scrollDiv 用于指定滚动条所在的dev，图表懒加载的时候使用。
scrollDiv?:HTMLElement
```

6. 类似"容器(TKE)"复杂维度的场景，getData 支持返回 dimensions 字段。 包含 dimensions 字段，instances 字段将不再生效。

```ts
// scrollDiv 用于指定滚动条所在的dev，图表懒加载的时候使用。
getData: async function (index = 0) {
    // set instances
    return {
      // 监控页面的标题，一般返回实例ID
      title: cluster.clusterId,
      // 监控页面的标题，一般返回实例描述
      subTitle: cluster.clusterName,
      // 支持返回多个实例, 返回实例的 维度 + value
      dimensions: [
        {
          Key: 'region',
          Value: ['ap-guangzhou']
        },
        {
          Key: 'tke_cluster_instance_id',
          Value: ['cls-2rx0qhb0', 'cls-2rx0qhb1']
        }
      ]
    };
  }
```