# 使用说明

::: tip 说明
业务SDK模块主要在tce-sdk上去异步加载业务相关的SDK，tce-sdk作为统一SDK的出口，下面的使用只介绍通过 npm 安装方式的使用，其他方式的使用请参考 [介绍使用](/introduction/) 里面的用法
:::

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |  >= 3.10.0   |  >= 3.10.0   |     :x:      |  >= 3.10.0   |

**TCS**:

| 登录页 | 控制台 |
| :----: | :----: |
|  :x:   |  :x:   |

> 目前已支持的业务 SDK

```ts
enum ComponentNames {
  'cam-sdk',
  'auth-sdk',
  'tag-sdk',
  'sg-sdk',
  'tsm-sdk',
  'monitor-v2-sdk',
  'cls-sdk',
}
```

> 使用示例【推荐使用】

```ts
import { component } from '@tencent/tce-sdk';
const tagSdk = await component.getComponent('tag-sdk');
```

::: tip 温馨提示
针对在`tea-app`及`tce-app`开发的应用场景下，还是可以继续通过下面的方式加载不同业务的SDK，推荐使用上面`tce-sdk`的方式来使用
```ts
import { app } from '@tce/app';

async function () {
  const tag = await app.sdk.use('tag-sdk');
  // 通过 tag 调用 API
  console.log(tag.hello());
}
```
:::