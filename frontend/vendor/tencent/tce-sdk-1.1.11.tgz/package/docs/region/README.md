# 地域

::: tip 说明
地域模块主要是提供平台通用获取对应地域内容获取的 SDK，下面的使用只介绍通过 npm 安装方式的使用，其他方式的使用请参考 [介绍使用](/introduction/) 里面的用法
:::

## 同步获取平台所有地域列表

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   >= 3.8.0   |     :x:      |     :x:      |   >= 3.8.0   |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | >= 2.1.0 |

> 使用实例【这个方法获取到的地域不区分产品，获取全量的】

```ts
import { region } from '@tencent/tce-sdk';
const regionList = region.getRegionListSync();
```

> 出入参说明

```ts
export interface Region {
  /**
   * regionId，数字格式的
   */
  regionId: number;
  /**
   * region
   */
  region: string;
  /**
   * regionName: 根据不同语言返回的地域名称
   */
  regionName: string;
  /**
   * 地域角色(MR:主地域, SR:从地域, OR:其它地域)
   */
  regionRole?: string;
  zoneList: Zone[];
}
export interface Zone {
  /**
   * 地区ID
   */
  zoneId: number;
  /**
   * 地区【字符串类型】
   */
  zone: string;
  /**
   * 地区名称【根据不同语言返回的地域名称】
   */
  zoneName: string;
}
/**
 * 同步方式获取地域列表，不区分产品
 */
export declare function getRegionListSync(): Region[];
```

> 结果实例

```json
[
  {
    "regionId": 500001,
    "region": "chognqing",
    "regionName": "重庆",
    "zoneList": [
      {
        "zoneId": 5000001,
        "zone": "chongqing",
        "zoneName": "重庆一区"
      }
    ]
  }
]
```

## 同步获取IDC列表

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   :x:   |     :x:      |     :x:      |   >= 3.11.0   |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | >= 2.3.0 |

> 使用实例【这个方法获取到的地域不区分产品，获取全量的】

```ts
import { region } from '@tencent/tce-sdk';
const idcList = region.getIDCList(50010001);
```

> 出入参说明

```ts
export interface IDC {
  /**
   * 地域ID
   */
  regionId: number;
  /**
   * 可用区ID
   */
  zoneId: number;
  /**
   * IDC id
   */
  idcId: number;
  /**
   * IDC【字符串】
   */
  idc: string;
  /**
   * IDC名称【根据不同语言返回的地域名称】
   */
  idcName: string;
}
/**
 * 获取IDC列表
 * @param zoneId 可用区ID
 */
export declare function getIDCList(zoneId: number): IDC[];
```

> 结果实例

```json
[
  {
    "regionId": 50000001,
    "zoneId": 50010001,
    "idcId": 50010101,
    "idc": "yfdb",
    "idcName": "云福db",
  }
]
```

## 设置当前地域

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   >= 3.8.0   |     :x:      |     :x:      |   >= 3.8.0   |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | >= 2.1.0 |

> 使用示列

```ts
import { region } from '@tencent/tce-sdk';
region.setRegion('chongqing');
```

> 出入参说明

```ts
/**
 * 设置当前地域
 * @param {String} region 地域名称,运营端为英文如'chongqing',租户端为regionId
 */
export declare function setRegion(region: string): void;
```

## 同步获取平台当前 region

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   >= 3.8.0   |     :x:      |     :x:      |   >= 3.8.0   |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | >= 2.1.0 |

> 使用示列

```ts
import { region } from '@tencent/tce-sdk';
const curRegion = region.getCurrentRegion();
```

> 出入参说明

```ts
/**
 * 获取当前region信息
 * 获取优先级  url or localStorage
 * 适用TCE租户端控制台、TCE运营端控制台、TCS控制台
 */
export declare function getCurrentRegion(): Region | undefined;
```

> 结果实例

```json
[
  {
    "regionId": 500001,
    "region": "chognqing",
    "regionName": "重庆",
    "zoneList": [
      {
        "zoneId": 5000001,
        "zone": "chongqing",
        "zoneName": "重庆一区"
      }
    ]
  }
]
```

## 异步获取平台当前 region

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |     :x:      |   >= 3.9.0   |     :x:      |     :x:      |

**TCS**:

| 登录页 | 控制台 |
| :----: | :----: |
|  :x:   |  :x:   |

> 使用示列

```ts
import { region } from '@tencent/tce-sdk';
const curRegion = region.getCurrentRegionAsync();
```

> 出入参说明

```ts
/**
 * 异步获取当前region信息
 * @param regionId 地域ID 非必填，不传的时候会从当前url中获取,都没有的情况下取列表第一个
 */
export declare function getCurrentRegionAsync(regionId?: string): Promise<Region>;
```

> 结果实例

```json
[
  {
    "regionId": 500001,
    "region": "chognqing",
    "regionName": "重庆",
    "zoneList": [
      {
        "zoneId": 5000001,
        "zone": "chongqing",
        "zoneName": "重庆一区"
      }
    ]
  }
]
```

## 异步获取地域列表

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   >= 3.9.0   |   >= 3.9.0   |     :x:      |   >= 3.8.0   |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | >= 2.1.0 |

> 使用示例

1、获取某个产品可用的地域

```ts
import { region } from '@tencent/tce-sdk';
const regionList = await region.getRegionListAsync('CVM');
```

2、获取所有地域列表【当已经异步请求过数据后，下次调用会从缓存中获取，不会再次发起请求，刷新页面会重新异步获取】

```ts
import { region } from '@tencent/tce-sdk';
const regionList = await region.getRegionListAsync();
```

3、获取某个产品中子产品可用的地域【TCE3.10.0 版本开始支持】

```ts
import { region } from '@tencent/tce-sdk';
const regionList = await region.getRegionListAsync('VPC', 'VPCGW');
```

> 出入参说明

```ts
/**
 * 异步获取地域列表
 * @param productCode 产品code【非必填，不传的时候直接返回所有的地域】
 * @param subProductCode 产品code【非必填，TCE3.10.0版本开始才支持】
 */
export declare function getRegionListAsync(productCode?: string, subProductCode?: string): Promise<Region[]>;
```

## 异步获取指定语言下所有的国家名及其 code

> 在各个项目中有需要用到选择多个国家电话号码的都用这个方式获取数据，避免不同项目重复提交翻译

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.9.0   |   >= 3.8.0   |   >= 3.9.0   |   >= 3.9.0   |   >= 3.8.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| >= 2.1.0 | >= 2.1.0 |

> 使用示例

1、获取指定语言下所有的国家名及其 code

```ts
import { region } from '@tencent/tce-sdk';
const regionList = await region.getCountryCodeAsync('en-US');
```

2、根据当前环境语言返回对应的所有国家名及其 code

```ts
import { region } from '@tencent/tce-sdk';
const regionList = await region.getCountryCodeAsync();
```

> 出入参说明

```ts
/**
 * 异步获取地域列表
 * @param language "en-US"|"zh-CN" 【非必填，默认值为当前环境下的语言】
 */
export async function getCountryCodeAsync(language: string = getCurrentLang()): Promise<ICountry[]>;
```

> 返回示例

```js
[
  {
    Name: "中国",
    Code: "86"
  },
  ...
]
```

## 异步获取指定语言下所有的省市区名称和type

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.9.0   |   >= 3.8.0   |   >= 3.9.0   |   >= 3.9.0   |   >= 3.8.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| >= 2.1.0 | >= 2.1.0 |

> 使用示例

1、获取指定语言下所有的国家名及其 code

```ts
import { region } from '@tencent/tce-sdk';
const regionList = await region.getLocationAsync('en-US');
```

2、根据当前环境语言返回对应的所有国家名及其 code

```ts
import { region } from '@tencent/tce-sdk';
const regionList = await region.getLocationAsync();
```

> 出入参说明

```ts
/**
 * 异步获取省市区列表
 * @param language "en-US"|"zh-CN" 【非必填，默认值为当前环境下的语言】
 */
export async function getLocationAsync(language: string = getCurrentLang()): Promise<ProvinceMap[]>;
```

> 返回示例

```js
[
   {
    name: '北京',
    sub: [
      { name: '' },
    ],
    type: 0,
  },
  ...
]
```