# 配置

::: tip 说明
配置模块主要是提供平台通用的获取配置开关的方法，下面的使用只介绍通过 npm 安装方式的使用，其他方式的使用请参考 [介绍使用](/introduction/) 里面的用法
:::
## 获取弹性变量配置

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.10.0   |   >= 3.10.0   |   :x:   |   >= 3.10.0   |   >= 3.10.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| :x: | :x: |

::: tip 说明
目前可用的弹性变量key常量参考 [附录-弹性变量配置key](/config/#弹性变量)
:::

> 使用示列如下

```ts
import { config } from '@tencent/tce-sdk';
// 是否允许使用国密SM4算法进行加密存储
const configValue = config.getElasticConfig<boolean>(config.ELASTIC_CONFIG_KEY.tcloud.cos_allow_use_sm4);

// 结果
true
```

> 出入参说明

```ts
/**
 * 获取弹性变量配置
 * @param key 配置key
 * @return T
 */
export declare function getElasticConfig<T>(key: string): T;
```

## 异步获取配置中心配置

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.9.0   |   >= 3.9.0   |   >= 3.9.0   |   >= 3.9.0   |   >= 3.9.0   |

**TCS**:

| 登录页 | 控制台 |
| :----: | :----: |
|  :x:   |  :x:   |

::: tip 说明
目前可用的配置常量参考 [附录-配置中心配置常量](/config/#配置中心-namespace-及-key-常量)
:::

> 使用示列如下

```ts
// 从常量中获取已经支持的配置
import { config } from '@tencent/tce-sdk';
const FOYO_CONFIG = config.FOYO_CONFIG;
const { tcenter_base } = FOYO_CONFIG;
// 获取租户端是否启用注册功能
const configValue = await config.getConfigAsync(tcenter_base.name， tcenter_base.tcloud_allow_reg);

// 结果如下：
{
    "res": {
        "Value": true
    },
    "err": undefined // err不为空的时候，则表示获取配置失败了
}
```

> 出入参说明

```ts
/**
 * 异步获取配置中心配置-转换value
 * @param Namespace 配置分类
 * @param Key 关键字
 * @return  boolean | string | object | number
 */
export declare async function getConfigAsync(
  Namespace: string,
  Key: string
): Promise<IAPIResponse<GetConfigRes>>;

export interface IAPIResponse<T extends object> {
  /**
   * 接口返回的业务数据
   */
  res: T;
  /**
   * 接口失败返回的错误对象，err不为null表示接口失败了
   */
  err?: Error;
}

interface GetConfigRes {
  /**
   * 值
   */
  Value: boolean | string | object | number | any[];
}
```
::: warning 温馨提示
为了避免配置 namespace 和 key 更新及魔法字符串导致的问题，sdk 中提供了 FOYO_CONFIG 常量（具体见附录）匹配入参 namespace 和 key,同时使用 jsdoc 提供 key 的描述信息，后续配置名称有更新会直接更新常量，使用示例如下：

```js
import { config } from '@tencent/tce-sdk';
const FOYO_CONFIG = config.FOYO_CONFIG;
const configValue = config.getConfigAsync(
// FOYO_CONFIG一级对象name属性值为对应namespace的值
FOYO_CONFIG.tcenter_base.name，// namespace为'tcenter_base'的名称
// FOYO_CONFIG二级对象为namespace下对应key的值
FOYO_CONFIG.tcenter_base.tcloud_allow_reg //namespace为'tcenter'下的'tcloud_allow_reg'的名称
);
```
:::

## 异步获取指定ns下的配置中心配置

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   :x:   |   >= 3.10.12   |   >= 3.10.12   |   :x:   |   >= 3.10.12   |

**TCS**:

| 登录页 | 控制台 |
| :----: | :----: |
|  :x:   |  :x:   |


> 使用示列如下

```ts
// 从常量中获取已经支持的配置
import { config } from '@tencent/tce-sdk';
const configValue = await config.getConfigAsyncByNs('tcenter')

// 结果如下
{
    "res": [
        {
            "EntryID": 10157,
            "Key": "safety_tips",
            "RawValue": "\"\"",
            "Value": "",
            "Namespace": "tcenter",
            "Description": "保密提示语",
            "Version": 0,
            "ModifyTime": 1750132090,
            "Source": "",
            "Ext": {
                "Label": {
                    "en-US": "",
                    "zh-CN": "保密提示语"
                },
                "Placeholder": {
                    "en-US": "",
                    "zh-CN": "请输入保密提示语"
                },
                "ValueType": "str",
                "Version": "1.0"
            }
        }
    ],
    "err":undefined
}
```

> 出入参说明

```ts
interface DescribeConfigItem {
  /**
   * ID
   */
  EntryID: number;
  /**
   * 关键字
   */
  Key: string;
  /**
   * 配置分类
   */
  Namespace: string;
  /**
   * 描述
   */
  Description: string;
  /**
   * 当前版本号
   */
  Version: number;
  /**
   * 配置时间
   */
  ModifyTime: number;
  /**
   * 来源，暂定sdk和cli
   */
  Source: string;
  /**
   * 扩展字段json
   */
  Ext: string | DescribeExt;
  /**
   * 值
   */
  Value: boolean | string | object | number | any[];
}

/**
 * 异步批量获取配置中心配置-转换value
 * @param Namespace 配置分类
 * @param Key 关键字
 * @return  FoyoConfigValue | FoyoConfigValue[]
 */
export async function getConfigAsyncByNs(Namespace: string): Promise<IAPIResponse<DescribeConfigItem[]>>
```

## 异步批量获取配置中心配置

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.10.12   |   >= 3.10.12   |   >= 3.10.12   |   >= 3.10.12   |   >= 3.10.12   |

**TCS**:

| 登录页 | 控制台 |
| :----: | :----: |
|  :x:   |  :x:   |


> 使用示列如下

```ts
// 从常量中获取已经支持的配置
import { config } from '@tencent/tce-sdk';
const FOYO_CONFIG = config.FOYO_CONFIG;
const { tcenter_base } = FOYO_CONFIG;

const configValue = await config.getConfigAsyncMultiple([{namespace:tcenter_base.name,key:tcenter_base.tcloud_allow_reg},{namespace:tcenter_base.name,key:tcenter_base.tcloud_show_fee_menu}])

// 结果如下：（返回值是在保留入参的情况下，新增一个value属性，将值注入其中）
[{namespace:tcenter_base.name,key:tcenter_base.tcloud_allow_reg,value:true},{namespace:tcenter_base.name,key:tcenter_base.tcloud_show_fee_menu,value:true}]
```

> 出入参说明

```ts
interface GetConfigListAsyncFilter {
  /**
   * 配置分类
   */
  namespace: string;
  /**
   * 配置key
   */
  key: string;
}

type FoyoConfigValue = boolean | string | object | number | undefined;

interface ConfigItem extends GetConfigListAsyncFilter {
  value: FoyoConfigValue | FoyoConfigValue[];
}

/**
 * 异步批量获取配置中心配置-转换value
 * @param Namespace 配置分类
 * @param Key 关键字
 * @return  FoyoConfigValue | FoyoConfigValue[]
 */
export async function getConfigAsyncMultiple(filters: GetConfigListAsyncFilter[]): Promise<ConfigItem[]>
```

## 同步获取配置中心配置

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.9.0   |   >= 3.9.0   |     :x:      |   >= 3.9.0   |   >= 3.9.0   |

**TCS**:

| 登录页 | 控制台 |
| :----: | :----: |
|  :x:   |  :x:   |

::: tip 说明
目前可用的配置常量参考 [附录-配置中心配置常量](/config/#配置中心-namespace-及-key-常量)【注意，不是所有的配置都支持同步获取，只有基础配置`tcenter_base`才支持】
:::

> 使用示列如下

```ts
import { config } from '@tencent/tce-sdk';
// 从常量中获取已经支持的配置
const FOYO_CONFIG = config.FOYO_CONFIG;
const { tcenter_base } = FOYO_CONFIG;
// 获取租户端是否启用注册功能
const configValue = config.getConfigSync(tcenter_base.name， tcenter_base.tcloud_allow_reg);
// 结果如下：
true
```

> 出入参说明

```ts
/**
 * 同步获取配置中心配置-转换value
 * @param Namespace 配置分类
 * @param Key 关键字
 * @return  boolean | string | object | number
 */
export declare async function getConfigSync(
  Namespace: string,
  Key: string
): boolean | string | object | number | any[] | undefined;
```

## 更新配置中心配置

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.9.0   |   >= 3.9.0   |   >= 3.9.0   |   >= 3.9.0   |   >= 3.9.0   |

**TCS**:

| 登录页 | 控制台 |
| :----: | :----: |
|  :x:   |  :x:   |

::: tip 说明
目前可用的配置常量参考 [附录-配置中心配置常量](/config/#配置中心-namespace-及-key-常量)
:::

> 使用示列如下

```ts
import { config } from '@tencent/tce-sdk';
const configValue = config.setConfig('tcenter'， 'ocloud', 'demo');
```

> 出入参说明

```ts
/**
 * 设置配置中心配置值
 * @param Namespace 配置分类
 * @param Key 关键字
 * @param Value 值
 */
export async function setConfig<
  T extends object | number | string | boolean | any[]
>(Namespace: string, Key: string, Value: T): Promise<IAPIResponse<{}>>;
```

## 附录

### 配置中心 namespace 及 key 常量

> 目前SDK提供的可用的配置中心配置常量如下

```js
export const FOYO_CONFIG = {
  tcenter_base: { // 支持同步获取
    name: "tcenter_base",
    /**
     * 租户端是否展示右上角费用菜单
     */
    tcloud_show_fee_menu: "tcloud_show_fee_menu",
    /**
     * 租户端是否打开注册功能
     */
    tcloud_allow_reg: "tcloud_allow_reg",
    /**
     * 租户端主子账号登录是否启用图形验证码
     */
    tcloud_login_show_captcha: "tcloud_login_show_captcha",
    /**
     * 租户端所有页面统计系统的api地址
     */
    tcloud_statistics_api: "tcloud_statistics_api",
    /**
     * 租户端会话超时时间【分钟】
     */
    tcloud_session_timeout: "tcloud_session_timeout",
    /**
     * 租户端购买页所属项目是否必填配置
     */
    tcloud_view_project_required: "tcloud_view_project_required",
    /**
     * 异地登录保护开关:开启后，租户端的账号发生异地登录时，平台会对用户做身份校验
     */
    tcloud_remote_login_protection: "tcloud_remote_login_protection",
    /**
     * 金融专区白名单
     */
    fzo_whiltelist: 'fzo_whiltelist',
    /**
     * 价格展示配置
     */
    price_display_content: 'price_display_content',
  },

  tcenter_login_description: {
    name: "tcenter_login_description",
    /**
     * 租户端登录页面左侧信息
     */
    tcloud_login_show_description: "tcloud_login_show_description",
  },

  tcenter_privacy_agreement: {
    name: "tcenter_privacy_agreement",
    /**
     * 租户端隐私协议
     */
    tcloud_privacy: "tcloud_privacy",
  },

  tcenter_system_maintenance: {
    name: "tcenter_system_maintenance",
    /**
     * 租户端系统维护页面
     */
    tcloud_system_maintenance_info: "tcloud_system_maintenance_info",
  },

  tcenter_password_control: {
    name: "tcenter_password_control",
    /**
     * 是否打开租户端密码控件
     */
    enable: "enable",
    /**
     * 密码控件window下license
     */
    license_window: "license_window",
    /**
     * 密码控件mac下license
     */
    license_mac: "license_mac",
    /**
     * 密码控件urlPar
     */
    urlPar: "urlPar",
  },
};
// 使用方式
import { config } from '@tencent/tce-sdk';
console.log(platform.FOYO_CONFIG)
```

### 弹性变量

> 目前SDK提供的可用的弹性变量配置如下

```js
export const ELASTIC_CONFIG_KEY = {
  common: {
    tce_log_server: 'tce_log_server', // 日志收集服务【string】
  },
  tcloud: {
    billing_backend_type: 'billing_backend_type', // 组件使用的是计量还是计费, 默认值为bmp: 表示计量, bmppro: 表示计费【string】
    cos_allow_use_sm4: 'cos_allow_use_sm4', // 是否允许使用国密SM4算法进行加密存储【boolean】
    vpc_multicast: 'vpc_multicast', // 是否打开私有网络组播功能【boolean】
  },
  ocloud: {
    cvm_configurable: 'cvm_configurable', // cvm 配置调整操作开关【boolean】
    no_vpc_options: 'no_vpc_options', // 是否没有vpc网络【boolean】
  },
};
// 使用方式
import { config } from '@tencent/tce-sdk';
console.log(config.ELASTIC_CONFIG_KEY)
```