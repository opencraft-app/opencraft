# API

::: tip 温馨提示
API 模板主要是提供一些调用平台通用 api 的方法，下面的使用只介绍通过 npm 安装方式的使用，其他方式的使用请参考 [介绍使用](/introduction/) 里面的用法


> 提升效率tips

在TS的项目中，请求云API的前端TS代码可以通过前端提供的自动生成代码的工具来自动生成代码（主要是云API接口的出入参定义及请求方法），生成代码系统地址[专有云研发平台--云API](http://dragon.tce.woa.com/page/yapi/)
:::


## 云 API 接口请求

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   >= 3.8.0   |   >= 3.8.0   |     :x:      |   >= 3.8.0   |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | >= 2.1.0 |

> 使用示列

```ts
import { api } from '@tencent/tce-sdk';

const params = {
  serviceType: 'location',
  action: 'DescribeRegionZone',
  data: {
    ProductId: 'CVM'
  },
  region: "chongqing", // 非必填，会自动从平台地域列表中取第一个，如果存在多region切换的场景，在切换地域后需要传入切换后的region
  version: '2019-11-28'
};

const { res, err } = await api.yApiRequest(params);
```

::: warning 温馨提示
> 1、对齐capi超时时间，API设置的超时时间为30秒，如果有特殊场景需要修改超时实现，可以在`api.yApiRequest`第二个可选参数`options`中透传

> 2、在`api.yApiRequest`中内置了很多通用逻辑，`api.yApiRequest`内部会根据响应的错误码做出响应的处理；以下的场景，业务使用方可以不用再次处理

（1）登录态失效【SDK会弹出登录态失效的对话框，提示用户需要重新登录】

（2）IP黑白名单限制（当出现`UnauthorizedOperation.InvalidAccessIP`错误码的时候）【SDK会弹出IP访问限制对话框，提示用户】[查看黑白名单限制详细逻辑](https://iwiki.woa.com/pages/viewpage.action?pageId=372683164)

（3）敏感操作（有些接口属于敏感操作的接口，在触发的时候需要二次确认）【SDK会根据错误码弹出二次认证的对话框，让用户输入二次认证的验证码，通过后SDK会再次触发业务接口】[查看敏感操作详细逻辑](https://iwiki.woa.com/pages/viewpage.action?pageId=802312866)

> 3、针对接口返回cam没有授权的场景【错误码为：'UnauthorizedOperation'】,使用SDK内部提供的 [通用错误码](/api/#api通用错误码常量) 常量`api.CommonErrorCode.UnauthorizedOperation`及`tcesdk`提供的（CAM(权限)SDK），CAM sdk提供了4中不同方式的错误提示方式，具体参考 [CAM(权限)文档](/cam/)

```js
import { api, cam } from '@tencent/tce-sdk';
const { res, err } = await api.yApiRequest(params);
if (err) {
  const { code, message } = err;
  if (code === api.CommonErrorCode.UnauthorizedOperation) {
    const CAM = await cam.getCAM();
    // 这是一种弹窗显示cam相关的错误信息
    CAM.showBreakModal({
    message: "[request id:e41eefff-b7be-4a99-acfa-92d6f82d1f19]you are not authorized to perform operation (cvm:DescribeInstances) resource (qcs::cvm:bj:uin/370723235:instance/*) has no permission (e41eefff)"
    })
    return;
  }
}
```
> 4、目前yapi已支持传入axios相关的配置，针对需要取消请求的场景，可以根据axios官方用法使用，示例如下

```js
import { api } from '@tencent/tce-sdk';

const cancelToken = api.getCancelToken()
const source = cancelToken.source()

const { res, err } = await api.yApiRequest(params,{cancelToken:source.token});

source.cancel();
```
> 5、目前yapi已支持传入axios相关的配置，如果有需要转换后端bigInt为字符串的话，可以根据axios官方用法使用，示例如下

```js
import { api } from '@tencent/tce-sdk';
// 将bigInt转换为字符串，详细参考:https://www.npmjs.com/package/json-bigint
import JSONBig from 'json-bigint';

const transformResponse = (data) => {
  try {
    return JSONBig({ storeAsString: true }).parse(data);
  } catch (error) {
    console.log(error);
  }
  return data;
};

const { res, err } = await api.yApiRequest(params, { transformResponse: [ transformResponse ] });
```
:::

> 出入参及函数定义说明

```ts
export interface Error {
  code: string;
  message: string;
  requestId: string;
  [x:string]: string;// 其他错误参数也会暴露出来
}
export interface IAPIResponse<T extends object> {
  /**
   * 接口返回的业务数据
   */
  res: T;
  /**
   * 接口失败返回的错误对象，err不为null表示接口失败了
   */
  err?: Error;
}
export interface IAPIRequest<T extends object> {
  /**
   * 接口分类【产品】
   */
  serviceType: string;
  /**
   * 接口名
   */
  action: string;
  /**
   * 当前地域，可以不填，默认为当前地域
   */
  region?: string;
  /**
   * 当前语言，可以不填，默认为当前语言
   */
  language?: string;
  /**
   * 接口需要的业务入参，不需要入参的时候不用
   */
  data?: T;
  /**
   * V3接口需要的版本
   */
  version: string;
}

/**
 * 请求云api接口 【只支持V3接口】
 * @template T 入参泛型
 * @template U 出参泛型
 * @param {IAPIRequest<T>} body 入参包体
 * @param {string} body.serviceType 接口分类【产品】
 * @param {string} body.action 接口名
 * @param {string} body.version 接口版本号
 * @param {string} body.region ?当前地域，可以不填，默认为当前地域
 * @param {string} body.language ?当前语言，可以不填，默认为当前语言
 * @param {T} body.data<T> ?接口需要的业务入参，不需要入参的时候不用
 * @param {Partial<AxiosRequestConfig>} options ?yapi可选设置
 * @returns {Promise<IAPIResponse<U>>} {Promise<{ res: U, err: { code, message } }>}
 */
export declare function yApiRequest<T extends object, U extends object>(
  body: IAPIRequest<T>,
  options?: Partial<AxiosRequestConfig>,
): Promise<IAPIResponse<U>>;
```

> 请求示例

接口正常的时候

```json
{
  "res": {
    "RegionCount": 1,
    "RegionSet": [
      {
        "Region": "chongqing",
        "RegionID": "50000001",
        "RegionName": "重庆",
        "RegionState": "AVAILABLE",
        "RegionStateRemark": "",
        "ZoneCount": 1,
        "ZoneSet": [
          {
            "RegionID": "50000001",
            "Zone": "haiguang",
            "ZoneID": "50010001",
            "ZoneName": "海光",
            "ZoneState": "AVAILABLE",
            "ZoneStateRemark": ""
          }
        ]
      }
    ],
    "RequestId": "36d4c366-c9d7-484c-a670-5ab0ad6cded7"
  }
}
```

接口失败的情况

```json
{
  "err": {
    "code": "NoSuchVersion",
    "message": "The specified api version=`2019-11-18` does not exist in service=`location`,
    "requestId": "8cb2bc08-8935-482c-a419-ccb1940d1ed1"
  }
}
```

## 国际化处理工具方法

> 平台及版本支持情况
> **TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   >= 3.9.0   |   >= 3.9.0   |     :x:      |   >= 3.9.0   |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | >= 2.1.0 |

> 使用示列

```ts
import { api } from '@tencent/tce-sdk';

// 错误码对应的错误描述，国际化需要在前端翻译
const errCode2Message = {
  'InvalidParameter.ProductIdIsNull': t('ProductId参数为空'),
};

const params = {
  serviceType: 'location',
  action: 'DescribeRegionZone',
  data: {
    ProductId: 'CVM'
  },
  version: '2019-11-28'
};

const apiResp = await api.yApiRequest(params);

// 可以将请求获取到的出参通过这个方式转换下，如果接口报错的话，返回的错误信息就是根据当前环境的语言显示不同语言错误信息
const { res, err } = api.apiResI18nHandler(apiResp, errCode2Message);

// 示例，在中文环境下
err: {
  code: 'InvalidParameter.ProductIdIsNull',
  message: 'ProductId参数为空'
}

// 英文情况下【前提是翻译了】
err: {
  code: 'InvalidParameter.ProductIdIsNull',
  message: 'ProductId is null'
}

```

## 首字母大写转换为小写

> 平台及版本支持情况
> **TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   >= 3.10.0   |   >= 3.10.0   |     :x:      |   >= 3.10.0   |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | :x: |

> 使用示列

```ts
import { api } from '@tencent/tce-sdk';

// 默认全部转换
const resp = {
  Name: "strong"
}
const apiResp = await api.transformFirstLetterToLowerCase(resp);
// 结果实例
{
  name: "strong"
}

// 字段全部为大写的不转换
const resp = {
  Name: "strong",
  CPU: "test"
}
const apiResp = await api.transformFirstLetterToLowerCase(resp, true);
// 结果实例
{
  name: "strong",
  CPU: "test"
}

```

> 出入参定义

```ts
/**
 * 将对象 或数组里的对象的 key 的首字母转为小写，且不侵入原对象
 * @export
 * @template T 泛型
 * @param {T} objOrArr 对象或数组对象
 * @param {boolean} [notChangeAllUppercaseField=false] field都是大写的是否选择不转换，比如「CPU」
 * @returns {TransformFirstLetterToLowerCase<T>}
 */
export declare function transformFirstLetterToLowerCase<T = any>(objOrArr: T, notChangeAllUppercaseField?: boolean): TransformFirstLetterToLowerCase<T>;
```

## 首字母小写转换为大写

> 平台及版本支持情况
> **TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   >= 3.10.0   |   >= 3.10.0   |     :x:      |   >= 3.10.0   |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | :x: |

> 使用示列

```ts
import { api } from '@tencent/tce-sdk';

const req = {
  name: "strong"
}
const apiResp = await api.transformFirstLetterToUpperCase(resp);
// 结果实例
{
  Name: "strong"
}

```

> 出入参定义

```ts
/**
 * 将对象 或数组里的对象的 key 的首字母转为大写，且不侵入原对象
 * @export
 * @template T
 * @param {T} objOrArr
 * @returns {TransformFirstLetterToUpperCase<T>}
 */
export declare function transformFirstLetterToUpperCase<T = any>(objOrArr: T): TransformFirstLetterToUpperCase<T>;
```


## 附录

### API通用错误码常量

> 目前SDK提供的通用错误码常量

```js
export const CommonErrorCode = {
  /**
   * CAM没有授权
   */
  UnauthorizedOperation: 'UnauthorizedOperation',
};
// 使用方式
import { api } from '@tencent/tce-sdk';
console.log(api.CommonErrorCode.UnauthorizedOperation)
```