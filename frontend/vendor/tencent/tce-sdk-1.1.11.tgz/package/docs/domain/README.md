# 域名

::: tip 说明
域名模块主要是提供平台通用域名相关的内容，下面的使用只介绍通过 npm 安装方式的使用，其他方式的使用请参考 [介绍使用](/introduction/) 里面的用法
:::

## 获取域名列表

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.9.0   |   >= 3.8.0   |   >= 3.9.0   |   >= 3.9.0   |   >= 3.8.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| >= 2.1.0 | >= 2.1.0 |

> 使用示列

```ts
import { domain } from '@tencent/tce-sdk';
const { base, imgcache } = domain.getDomainList();
```

> 出入参情况

```ts
/**
 * 获取当前环境所有的域名信息
 */
export interface TceDomain {
  /**
   * 登录域名
   */
  login?: string;
  /**
   * 主域
   */
  base?: string;
  /**
   * 官网域名
   */
  officialWebsite?: string;
  /**
   * 购买页域名
   */
  buy?: string;
  /**
   * imgcache域名
   */
  imgcache?: string;
  /**
   * cos域名
   */
  cos?: string;
  /**
   * csp域名
   */
  csp?: string;
  /**
   * qcbase域名
   */
  qcbase?: string;
  /**
   * 控制台域名
   */
  console?: string;
  /**
   * 文档域名
   */
  doc?: string;
}
/**
 * 获取域名列表
 */
export declare function getDomainList(): TceDomain;
```

::: warning 注意
上面的`getDomainList`接口返回的数据，并不是每个字段在不同的平台上都有的，这个需要注意下
:::


## 替换域名

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   :x:   |   >= 3.8.0   |   :x:   |   :x:   |   >= 3.8.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| :x: | :x:  |

> 使用示列

```ts
import { domain } from '@tencent/tce-sdk';
//替换为当前浏览器主域 如：console.yfm18.tcepoc.fsphere.cn
const resultStr =  domain.replaceDomainInStr('console.yfm18-3100.tcepoc.fsphere.cn');
```


> 结果实例

```text
console.yfm18.tcepoc.fsphere.cn
```