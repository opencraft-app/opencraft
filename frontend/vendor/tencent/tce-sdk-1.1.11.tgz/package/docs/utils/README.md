# 工具

::: tip 说明
工具模块主要是提供平台通用的 util 方法，下面的使用只介绍通过 npm 安装方式的使用，其他方式的使用请参考 [介绍使用](/introduction/) 里面的用法
:::

## locationSearch 转换为 Object

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.9.0   |   >= 3.8.0   |   >= 3.9.0   |   >= 3.9.0   |   >= 3.8.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| >= 2.1.0 | >= 2.1.0 |

> 将 url 后面的参数或将类 url 参数的字符串转换为对象，使用示列如下

```ts
import { utils } from "@tencent/tce-sdk";
// 当不传参数的时候，将直接去当前页面url后端的参数【document.location.search】
const urlPara = utils.getQueryParameters();

// 传入参数的时候，可以直接传入下面的参数
const urlPara = utils.getQueryParameters("?a=1&b=2");
```

> 出入参说明

```ts
/**
 * 将字符传参数转变为对象，默认不传，不传将从document.location.search 获取
 * @param str 入参
 */
export declare function getQueryParameters(str?: string): {
  [x: string]: string;
};
```

> 结果示例【返回一个对象】

```json
{
  "a": "1",
  "b": "2"
}
```

## 生成 csv 文件并下载

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.9.0   |   >= 3.8.0   |   >= 3.9.0   |   >= 3.9.0   |   >= 3.8.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| >= 2.1.0 | >= 2.1.0 |

> 将前端 table 中的数据通过组装成 csv 文件下载，示例如下：

```ts
import { utils } from "@tencent/tce-sdk";
const header = ["ID", "名称", "状态", "进度", "创建时间", "迁入到"];
const rows = [
  [
    "job_26",
    "anotheronejob",
    "等待中",
    "20 %",
    "2018-05-16 10:40:58",
    "disk-r9qbv885",
  ],
  [
    "job_25",
    "anotheronejob",
    "等待中",
    "30 %",
    "2018-05-16 10:40:58",
    "ins-9gezlgj0",
  ],
];
utils.downloadCsv(rows, header, "csm.csv");
```

## 异步获取xlsx库

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.11.0   |   >= 3.11.0   |   >= 3.11.0   |   >= 3.11.0   |   >= 3.11.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| >= 2.3.0 | >= 2.3.0 |

> 异步获取xlsx库，示例如下：

```ts
import { utils } from "@tencent/tce-sdk";

// 注意，因为需要异步下载xlsx.js库，所以getXlsx方法是异步的
const xlsx = await utils.getXlsx();
```

> 函数定义及入参

```ts
/**
 * 获取xlsx库
 */
export declare function getXlsx(): Promise<typeof XLSX>;
```

## 生成 xlsx 文件并下载

> 平台及版本支持情况【TCE3100及TCS2.3.0版本需要支持的话，需要回合一些组件，使用的时候请联系TCE同学】

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.10.0   |   >= 3.10.0   |   >= 3.10.0   |   >= 3.10.0   |   >= 3.10.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| >= 2.3.0 | >= 2.3.0 |

> 将前端 table 中的数据通过组装成 xlsx 文件下载，示例如下：

```ts
import { utils } from "@tencent/tce-sdk";
const header = ["ID", "名称", "状态", "进度", "创建时间", "迁入到"];
const rows = [
  [
    "job_26",
    "anotheronejob",
    "等待中",
    "20 %",
    "2018-05-16 10:40:58",
    "disk-r9qbv885",
  ],
  [
    "job_25",
    "anotheronejob",
    "等待中",
    "30 %",
    "2018-05-16 10:40:58",
    "ins-9gezlgj0",
  ],
];
// 注意，因为需要异步下载xlsx.js库，所以downloadXlsx方法是异步的
await utils.downloadXlsx(rows, header, "csm.xlsx");
```

> 函数定义及入参

```ts
/**
 * 将数据组装成xlsx文件下载
 * @param rows xlsx每行的数据，字符串二维数组
 * @param header xlsx文件的头，字符串数组
 * @param filename xlsx下载后的文件名，例如test.xlsx
 */
export declare function downloadXlsx(rows: string[][], header: string[], filename: string): Promise<void>;
```

## 解析 xlsx 文件

> 平台及版本支持情况【TCE3100版本需要支持的话，需要回合一些组件，使用的时候请联系TCE同学】

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.10.0   |   >= 3.10.0   |   >= 3.10.0   |   >= 3.10.0   |   >= 3.10.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| :x: | :x: |

> 将 xlsx 文件解析成数组（用于导入的场景），示例如下：

```ts
import { utils } from "@tencent/tce-sdk";

// 文件上传处理
document.getElementById('file-input').addEventListener('change', async function(e) {
  const file = (e.target as HTMLInputElement).files?.[0];
  if (!file) {
    return;
  }
  try {
    const { headers, rows } = await utils.parseXlsxFile(file);
    console.log('Headers:', headers);
    console.log('Rows:', rows);
  } catch (e) {
    console.error('Error:', e);
  }
});

// headers
["ID", "名称", "状态", "进度", "创建时间", "迁入到"]
// rows
[
  [
    "job_26",
    "anotheronejob",
    "等待中",
    "20 %",
    "2018-05-16 10:40:58",
    "disk-r9qbv885",
  ],
  [
    "job_25",
    "anotheronejob",
    "等待中",
    "30 %",
    "2018-05-16 10:40:58",
    "ins-9gezlgj0",
  ],
]
```

> 函数定义及入参

```ts
/**
 * 解析xlsx文件
 * @param file xlsx文件
 * @returns Promise<{ headers: string[]; rows: any[][] }>
 */
export declare function parseXlsxFile(file: File): Promise<{ headers: string[]; rows: any[][] }>
```

## 本地存储【storage】

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.9.0   |   >= 3.8.0   |   >= 3.9.0   |   >= 3.9.0   |   >= 3.8.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| >= 2.1.0 | >= 2.1.0 |

::: tip 说明
对浏览器中的 localStorage 及 sessionStorage 的扩充，支持以下特性<br>
（1）使用过程中传入`namespace`命名控件，防止不同 js 接入的产品出现`key`冲突的情况<br>
（2）支持增加过期时间，可以给存储增加过期时间<br>
（3）支持遍历等方法
:::

> 接口描述

```ts
interface StorageObject {
  local: Storage; // localStorage
  session: Storage; // sessionStorage
}

interface Storage {
  get(key: string, optionalDefaultValue?: any): any;
  set(key: string, value: any, expires?: number): any;
  remove(key: string): void;
  each(callback: (val: any, namespacedKey: string) => void): void;
  clearAll(): void;
}
```

> 使用的过程中需要先出传入一个`namespace`进行初始化，`namespace`最好以自己产品命名，比如`cvm`

```ts
// 可以统一在一个通用的模块中进行初始化，比如在`src/commom.ts`
import { utils } from "@tencent/tce-sdk";
// 将初始化后的storage导出
export const storage = utils.storage("cvm");
```

> 具体业务使用

```ts
import { storage } from 'src/common'
const { local, session } = storage;

// 设置值
local.set('user', { name:'Marcus' })
// 设置值得有效期
local.set('foo', 'bar', new Date().getTime() + 3000)
// 获取值
local.get('user')
// 清除值
local.remove('user')
// 清除所有的值
local.clearAll()
// 循环遍历值
local.each(function(value, key) {
    console.log(key, '==', value)
})
```

## 打印关键信息到控制台

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.9.0   |   >= 3.8.0   |   >= 3.9.0   |   >= 3.9.0   |   >= 3.8.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| >= 2.1.0 | >= 2.1.0 |

::: tip 备注
如果只是为了打印云 API 接口报错的信息的话，不需要调用，平台默认在云 API 请求出错的时候打印出来
:::

> 可以在项目中一些关键的地方打印日志，使用说明如下

```ts
import { utils } from '@tencent/tce-sdk';
utils.log('这是关键日志信息的标题', [
  {
    key: '错误原因'
    value: '后端数据格式有误',
  },
  {
    key: '后端返回',
    value: {
      code: -1
    }
  }
]);
```

> 出入参说明

```ts
export interface LogInfo {
  /**
   * 标题
   */
  key: string;
  /**
   * 内容
   */
  value: any;
}

/**
 * 关键信息打印
 * @param title 标题
 * @param details 详细信息
 */
export declare function log(
  title: string,
  details?: LogInfo[]
): void;
```

> 控制台显示示例

![控制台打印示例 image](./printKeywordLog.png)

## 手机号码脱敏

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.9.0   |   >= 3.8.0   |   >= 3.9.0   |   >= 3.9.0   |   >= 3.8.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| >= 2.1.0 | >= 2.1.0 |

> 使用示例

```ts
import { utils } from '@tencent/tce-sdk';
const phone = utils.maskPhoneNumber('18512345678');
// 结果
185****5678
```

> 出入参定义

```ts
/**
 * 手机号脱敏
 * @param phoneNumber 手机号码
 */
export declare function maskPhoneNumber(phoneNumber: string): string;
```

## 邮箱脱敏

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.9.0   |   >= 3.8.0   |   >= 3.9.0   |   >= 3.9.0   |   >= 3.8.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| >= 2.1.0 | >= 2.1.0 |

> 使用示例

```ts
import { utils } from '@tencent/tce-sdk';
const phone = utils.maskMail('12345678@qq.com');
// 结果
1234****@qq.com
```

> 出入参定义

```ts
/**
 * 邮箱脱敏
 * @param mail 邮箱
 */
export declare function maskMail(mail: string): string;
```

## 生成 uuid

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.9.0   |   >= 3.8.0   |   >= 3.9.0   |   >= 3.9.0   |   >= 3.8.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| >= 2.1.0 | >= 2.1.0 |

> 使用示例

```ts
import { utils } from '@tencent/tce-sdk';
const phone = utils.uuid();
// 结果
e3c3d83d-e4d1-8246-1d53-494e4a5c1222
```

> 出入参定义

```ts
/**
 * 生成一个uuid
 */
export declare function uuid(): string;
```

## js-cookie

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.9.0   |   >= 3.8.0   |   >= 3.9.0   |   >= 3.9.0   |   >= 3.8.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| >= 2.1.0 | >= 2.1.0 |

> 使用示例

```ts
import { constants } from '@tencent/tce-sdk';
const cookie = constants.JS_COOKIE;
cookie.get('test')
```

::: tip 温馨提示
`tcesdk`只是包装了下js-cookie，详细的使用方式和js-cookie一样，[使用文档](https://www.npmjs.com/package/js-cookie)
:::

## axios

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.9.0   |   >= 3.8.0   |   >= 3.9.0   |   >= 3.9.0   |   >= 3.8.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| >= 2.1.0 | >= 2.1.0 |

> 使用示例

```ts
import { constants } from '@tencent/tce-sdk';
const axios = constants.AXIOS;
axios.get('http://xxxx');
```

::: tip 温馨提示
`tcesdk`只是包装了下axios，详细的使用方式和axios一样，[使用文档](https://www.npmjs.com/package/axios)
:::

## 获取dom元素的宽高

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   :x:   |   >= 3.10.0   |   >= 3.10.0   |   :x:    |   >= 3.10.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| :x:  | :x:  |

> 使用示例

```ts
import { utils } from '@tencent/tce-sdk';
// 默认为控制台页面右侧内容区的宽高
const { clientHeight, clientWidth } = utils.getElementRect();
```

> 出入参定义

```ts
/**
 * 获取dom元素的宽高
 * @export
 * @param {string} [selector='#appArea'] 默认为控制台页面右侧内容区的宽高
 * @returns {{ clientHeight: number; clientWidth: number }}
 */
export declare function getElementRect(selector?: string): {
    clientHeight: number;
    clientWidth: number;
};
```

::: tip 最佳实践
在使用`TablePage`的时候为了保证整个table在当前页面一页显示，可以通过`getElementRect`获取当前内容区域的高度，然后来设置`Table`的高度
:::

## 将utf-8字符串转换为16进制

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   :x:   |   >= 3.10.0   |   >= 3.10.0   |   :x:    |   >= 3.10.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| :x:  | :x:  |

> 使用示例

```ts
import { utils } from '@tencent/tce-sdk';
const hex = utils.str2hex('test');
```

> 出入参定义

```ts
/**
 * 字符串转16进制
 * @param str 字符串
 */
export declare function str2hex(str: string): string;
```

