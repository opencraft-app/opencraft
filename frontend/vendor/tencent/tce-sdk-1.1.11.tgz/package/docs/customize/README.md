# 客制化

::: tip 说明
客制化模块主要是提供获取客户接入的产品信息方法，下面的使用只介绍通过 npm 安装方式的使用，其他方式的使用请参考 [介绍使用](/introduction/) 里面的用法
:::

## 获取获取客制化版本

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.9.0   |   >= 3.8.0   |   >= 3.9.0   |   >= 3.9.0   |   >= 3.8.0   |

**TCS**:

| 登录页 | 控制台 |
| :----: | :----: |
|  :x:   |  :x:   |

> 使用示列

```ts
import { platform } from '@tencent/tce-sdk';
const customizeVersion = platform.getCustomizeVersion();
```

> 出入参情况

```ts
/**
 * 获取客制化版本
 */
export declare function getCustomizeVersion(): string | undefined;
```

## 获取客制化产品配置

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.9.0   |   >= 3.8.0   |   >= 3.9.0   |   >= 3.9.0   |   >= 3.8.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| :x: | :x: |

> 使用示列如下

```ts
import { config } from '@tencent/tce-sdk';
const configValue = config.getCustomizeProductConfig('tcenter'， 'ocloud', 'enableEnterpriseCreateAccount');
```

> 出入参说明

```ts
/**
 * 获取客制化产品的配置【TCE平台适用】
 * @param product 产品代码
 * @param platform 平台【'tcloud', 'ocloud', 'common'】
 * @param code 配置代码
 * @return string[]
 */
export declare function getCustomizeProductConfig(
  product: string,
  platform: string,
  code: string
): string[];
```

## 批量获取客制化产品配置

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.10.12   |   >= 3.10.12   |   >= 3.10.12   |   >= 3.10.12   |   >= 3.10.12   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| :x: | :x: |

> 使用示列如下

```ts
import { config } from '@tencent/tce-sdk';
const configValue = config.getCustomizeProductConfigMultiple([{ product: 'barad', platform: 'ocloud', code: 'IS_OPEN_ALRAM_NOTIFY' }]);

// 返回值是在保留入参的情况下，新增一个value属性，将值注入其中    
[{ product: 'barad', platform: 'ocloud', code: 'IS_OPEN_ALRAM_NOTIFY', value: ['N'] }]
```

> 出入参说明

```ts
interface FilterConfig {
  /**
   * 产品code
   */
  product: string;
  /**
   * 平台【'tcloud', 'ocloud', 'common'】
   */
  platform: string;
  /**
   * 配置code
   */
  code: string;
}

/**
 * 将入参中的product、platform、code等信息一并返回，方便处理
 */
interface ConfigItem extends FilterConfig {
  value: string[];
}


/**
 * 批量获取客制化产品的配置【TCE平台适用】
 * @param product 产品代码
 * @param platform 平台【'tcloud', 'ocloud', 'common'】
 * @param code 配置代码
 * @return string[][]
 */
export function getCustomizeProductConfigMultiple(filters: FilterConfig[]): ConfigItem[]
```

## 获取客制化产品列表

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   :x:  |   >= 3.10.0   |   :x:   |   :x:   |   >= 3.10.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| :x: | :x: |

> 使用示列如下

```ts
import { config } from '@tencent/tce-sdk';
// 可以用来获取当前环境部署的产品列表信息
const productList = config.getCustomizeProductList();
```

> 返回值示例

![getCustomizeProductList](./getCustomizeProductList.png)

> 出入参说明

```ts
/**
 * 获取环境部署的产品列表
 * @returns ICustomizeProduc[]
 */
export declare function getCustomizeProductList(): ICustomizeProduct[];
```

`ICustomizeProduct`详细说明查看[附录](/customize/#附录)

## 根据产品code获取产品信息

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   :x:  |   >= 3.10.0   |   :x:   |   :x:   |   >= 3.10.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| :x: | :x: |

> 使用示列如下

```ts
import { config } from '@tencent/tce-sdk';
// 可以用来获取产品接入信息以及判断某个产品是否在当前环境部署了
const productInfo = config.getCustomizeProductByCode();
```

> 返回值示例

![getCustomizeProductByCode](./getCustomizeProductByCode.png)

> 出入参说明

```ts
/**
 * 根据产品code获取产品信息
 * @param productCode 产品code
 * @returns ICustomizeProduc | undefined
 */
export declare function getCustomizeProductByCode(productCode: string): ICustomizeProduct | undefined;
```

`ICustomizeProduct`详细说明查看[附录](/customize/#附录)

## 获取客制化产品模块分类tabs

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   :x:  |   >= 3.10.0   |   >= 3.10.0   |   :x:   |   >= 3.10.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| :x: | :x: |

> 使用示列如下

```ts
import { config } from '@tencent/tce-sdk';
// 这个主要是可以用来生成控制台顶部导航tab
const customizeAccessTabs = config.getCustomizeAccessTabs();
```

> 返回值示例

![getCustomizeAccessTabs](./getCustomizeAccessTabs.jpg)

> 出入参说明

```ts
/**
 * 获取客制化产品模块分类tabs
 * @export
 * @returns {ICustomizeAccessTab[]}
 */
export declare function getCustomizeAccessTabs(): ICustomizeAccessTab[];
```

`ICustomizeAccessTab`详细说明查看[附录](/customize/#附录)

## 根据路由key获取客制化接入信息

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   :x:  |   >= 3.10.0   |   >= 3.10.0   |   :x:   |   >= 3.10.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| :x: | :x: |

> 使用示列如下

```ts
import { config } from '@tencent/tce-sdk';
const customizeAccessTabs = config.getCustomizeAccessInfoByRouterKey('user');
```

> 返回值示例

![getCustomizeAccessInfoByRouterKey](./getCustomizeAccessInfoByRouterKey.jpg)

> 出入参说明

```ts
/**
 * 根据路由key获取接入信息
 * @export
 * @param {string} routerKey 路由key
 * @returns {ICustomizeAccess[]}
 */
export declare function getCustomizeAccessInfoByRouterKey(routerKey: string): ICustomizeAccess | undefined;
```

`ICustomizeAccess`详细说明查看[附录](/customize/#附录)

## 获取当前页面菜单及接入信息

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   :x:  |   >= 3.10.0   |   >= 3.10.0   |   :x:   |   >= 3.10.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| :x: | :x: |

> 使用示列如下

```ts
import { config } from '@tencent/tce-sdk';
const customizeAccessTabs = config.getCurrentPageAccessInfo();
```

> 返回值示例

![getCurrentPageAccessInfo](./getCurrentPageAccessInfo.jpg)

> 出入参说明

```ts
/**
 * 根据当前页面接入信息
 * @export
 * @param {string} [urlPath] urlPath 默认为当前页面的urlPath
 * @returns {(ICurrentAccess | undefined)}
 */
export declare function getCurrentPageAccessInfo(urlPath?: string): ICurrentAccess | undefined;
```

`ICurrentAccess`详细说明查看[附录](/customize/#附录)

::: tip 最佳实践
针对控制台页面的标题需要和菜单保持一致的场景下，在代码中页面标题的部分通过`getCurrentPageAccessInfo`获取当前页面的菜单名称，这样保证在后续修改菜单名后不需要修改业务代码。
![getCurrentPageAccessInfo_tips](./getCurrentPageAccessInfo_tips.jpg)
:::

## 根据uuid获取产品模块信息

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   :x:  |   >= 3.10.0   |   >= 3.10.0   |   :x:   |   >= 3.10.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| :x: | :x: |

> 使用示列如下

```ts
import { config } from '@tencent/tce-sdk';
const customizeAccessTabs = config.getProductInfoByUUID('e13cde79b51c77b8e7198e7a5c28a06b');
```

> 返回值示例

![getProductInfoByUUID](./getProductInfoByUUID.png)

> 出入参说明

```ts
/**
 * 根据uuid获取产品模块信息
 * @param uuid 产品模块uuid
 * @returns ICustomizeModule | undefined
 */
export declare function getProductInfoByUUID(uuid: string): ICustomizeModule | undefined;
```

`ICustomizeModule`详细说明查看[附录](/customize/#附录)

::: tip 最佳实践
主要用于一些保存了产品模块的uuid的场景【比如总览页面的最新访问】，再还原数据的时候，可以通过这个方法获取产品相关的信息
:::

## 根据菜单uuid获取菜单信息

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   :x:  |   >= 3.10.0   |   :x:   |   :x:   |   >= 3.10.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| :x: | :x: |

> 使用示例如下

```ts
import { config } from '@tencent/tce-sdk';
const customizeAccessTabs = config.getMenuInfoByUUID('e13cde79b51c77b8e7198e7a5c28a06b');
```

> 返回值示例

![getMenuInfoByUUID](./getMenuInfoByUUID.png)

> 出入参说明

```ts
/**
 * 根据uuid获取菜单信息
 * @param uuid 菜单的uuid
 * @returns ICustomizeAccessMenu | undefined
 */
export declare function getMenuInfoByUUID(uuid: string): ICustomizeAccessMenu | undefined;
```


## 获取全部菜单信息

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   :x:  |   >= 3.10.11   |   :x:   |   :x:   |   >= 3.10.11   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| :x: | :x: |

> 使用示例如下

```ts
import { config } from '@tencent/tce-sdk';
const allMenus = config.getAllMenus();
```

> 出入参说明

```ts
/**
 * 获取所有的菜单信息
 * @returns IFlatMenu | undefined
 */
export function getAllMenus(): IFlatMenu[] | [] {
```

`IFlatMenu`详细说明查看[附录](/customize/#附录)

::: tip 最佳实践
主要用于一些保存了菜单的uuid的场景【比如运营端的菜单鉴权】，再还原数据的时候，可以通过这个方法获取菜单相关的信息
:::

## 获取客制化产品及菜单icon地址

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   :x:  |   >= 3.10.0   |   :x:   |   :x:   |   >= 3.10.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| :x: | :x: |

> 使用示列如下

```ts
import { config } from '@tencent/tce-sdk';
// 根据客制化中返回的icon文件名，返回可访问的imgcache地址；如果客制化返回的icon本身就是url地址，则直接返回
const iconUrl = config.getCustomizeIconUrl('xxxx.svg');
```

> 返回值示例

![getCustomizeIconUrl](./getCustomizeIconUrl.png)

> 出入参说明

```ts
/**
 * 获取客制化产品及菜单icon的完整地址
 * @param icon
 * @returns url
 */
export declare function getCustomizeIconUrl(icon: string): string;
```

## 动态添加云产品菜单

> 平台及版本支持情况

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| :x: | >= 2.3.0 |

> 使用示例如下

```typescript
import { platform } from '@tencent@tce-sdk';
const result = platform.addMenu({
    /*
     * 需要新增菜单名称
     */
    menuName: '部署应用',
    /*
     * 是否在顶部菜单显示，默认为true
     */
    headline: true,
    /*
     * 菜单路由
     */
    href: '/appcenter/deploy',
    /*
     * 菜单所属平台code
     * 可以在 window.TCS.config.entrys下面获取
     */
    platformCode: 'tab_ocloud_application',
    /*
     * 要修改的产品的 Id
     * 可以在 window.TCS.config.entrys 下获取
     */
    moduleId: 'bUKe_MeS'
})
```

> 出参说明

```typescript
interface AddMenuProps {
  // 菜单名
  menuName: string;
  // 是否在顶部展示
  headline?: boolean;
  // 菜单路径
  href: string;
  // 菜单所属平台code
  platformCode: string;
  // 所属产品Id
  moduleId: string;
}
```

## 动态删除云产品菜单

> 平台及版本支持情况

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| :x: | >= 2.3.0 |

> 使用示例如下

```typescript
import { platform } from '@tencent@tce-sdk';
const result = platform.removeMenu({
    /*
     * 菜单路由
     */
    href: '/appcenter/deploy',
    /*
     * 菜单所属平台code
     * 可以在 window.TCS.config.entrys下面获取
     */
    platformCode: 'tab_ocloud_application',
    /*
     * 要修改的产品的 Id
     * 可以在 window.TCS.config.entrys 下获取
     */
    moduleId: 'bUKe_MeS'
})
```

> 出参说明

```typescript
interface RemoveMenuProps {
  // 删除的链接
  href: string;
  // 菜单所属平台code
  platformCode: string;
  // 所属产品Id
  moduleId: string;
}
```



## 获取客制化登录建模配置

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   :x:   |   :x:   |   :x:    |   :x:    |  :x:    |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| >= 2.3.5.0 | >= 2.3.5.0 |

> 使用示列如下

```ts
import { config } from '@tencent/tce-sdk';
const configValue = config.getCustomizeProductLoginModalConfig('loginTitle');
```

> 出入参说明

```ts
/**
 * 获取客制化产品中的登录建模相关的配置【TCS平台适用】
 * @version http://dragon.tce.woa.com/page/devDocument/tce-sdk
 * @version TCE控制台 ❌
 * @version TCE登录页、购买页 ❌
 * @version TCS控制台 >= 2.3.5.0
 * @version TCS登录页 >= 2.3.5.0
 * @param code 配置代码 相关配置项可以从window.TCE_GLOBAL_CONSTANT.loginCustomizeInfo中获取
 * @return string | string[] | null;
 */
export declare function getCustomizeProductLoginModalConfig(
  code: string
): string | string[] | null;
```

## 附录

```ts
/**
 * 客制化产品
 */
interface ICustomizeProduct {
    productCode: string;
    productName: string;
    modules: ICustomizeModule[];
}
/**
 * 客制化产品接入tab【如运营端的产品运营、平台运营等】
 */
export interface ICustomizeAccessTab {
  /**
   * 接入tab代码【如tab_cmgt_all_product（产品运营）】
   */
  code: string;
  /**
   * tab名称
   */
  name?: string;
  /**
   * 平台【如tce_ocloud（运营端）】
   */
  platform: string;
  /**
   * 是否可见
   */
  visible?: boolean;
  /**
   * 分类【如运营端产品运营下面的"计算和网络"】
   */
  types: ICustomizeType[];
  /**
   * 展示的位置【left/right】-- 客制化next开始支持【tcs2.3.4/tce3.10.11】
   */
  display?: 'left' | 'right';
  /**
   * 超链接引用
   */
  href?: string;
  /**
   * 超链接的target
   */
  target?: '_blank' | '_self';
}
/**
 * 分类【如运营端产品运营下面的”计算和网络“】
 */
interface ICustomizeType {
    /**
     * 分类代码【如ops_computeAndNetWork（计算和网络）】
     */
    code: string;
    /**
     * 分类名称【如计算和网络】
     */
    name: string;
    /**
     * 图标
     */
    icon: string;
    /**
     * 模块【如计算和网络下面的cvm、vpc等】
     */
    modules: ICustomizeModule[];
}
/**
 * 分类【如（计算和网络）分类下的（cvm、vpc等）】
 */
interface ICustomizeModule {
    /**
     * 模块唯一ID
     */
    uuid: string;
    /**
     * 模块名称【如：云服务器(cvm)】
     */
    name: string;
    /**
     * 默认url【如：云服务器(cvm)模块默认href为（/cvm）】
     */
    href: string;
    /**
     * 超链接的target
     */
    target?: '_blank' | '_self';
    /**
     * 暂时无用，在有target的时候才有
     */
    code?: string;
    /**
     * 菜单图标
     */
    icon: string;
    /**
     * 所属产品code
     */
    productCode?: string;
    /**
     * 所属产品名称
     */
    productName?: string;
}
/**
 * 模块接入信息
 */
interface ICustomizeAccess {
    /**
     * 接入唯一ID
     */
    uuid: string;
    /**
     * 模块标题
     */
    title: string;
    /**
     * 图标
     */
    icon: string;
    /**
     * 路由key
     */
    routerKey: string;
    /**
     * 所属产品代码
     */
    productCode?: string;
    /**
     * 所属产品名称
     */
    productName?: string;
    /**
     * 是否全屏
     */
    fullscreen?: boolean;
    /**
     * 接入方式【js、iframe】
     */
    type: ICustomizeAccessType;
    /**
     * 静态资源信息【js接入的时候才有】
     */
    asset?: ICustomizeAccessAsset;
    /**
     * iframe地址【iframe接入的时候才有】
     */
    iframeUrl?: string;
    /**
     * 菜单信息【购买页场景下没有菜单信息】
     */
    menus?: ICustomizeAccessMenu[];
}
/**
 * 模块接入菜单
 */
interface ICustomizeAccessMenu {
    /**
     * 菜单唯一ID
     */
    uuid: string;
    /**
     * 菜单名称
     */
    name: string;
    /**
     * 菜单跳转地址
     */
    href: string;
    /**
     * 菜单icon
     */
    icon: string;
    /**
     * 子菜单
     */
    menus?: ICustomizeAccessMenu[];
}
/**
 * 接入静态资源信息
 */
interface ICustomizeAccessAsset {
    /**
     * js地址
     */
    js: string;
    /**
     * css地址
     */
    css: string[];
}
/**
 * 当前页面接入信息
 */
export interface ICurrentAccess {
    /**
     * 当前页面的菜单信息
     */
    menu: ICustomizeAccessMenu;
    /**
     * 当前页面所在模块的接入信息
     */
    access: ICustomizeAccess;
}

/**
 * 菜单信息
 */
export interface IFlatMenu {
  /**
   * 菜单唯一ID
   */
  uuid: string;
  /**
   * 菜单名称
   */
  name: string;
  /**
   * 菜单跳转地址
   */
  href: string;
  /**
   * 二级菜单标题
   */
  title?: string;
   /**
   * 产品标题
   */
  product?: string;
  /**
   * 子菜单
   */
  menu?: IFlatMenu[];
}
```
