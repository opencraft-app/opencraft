# 语言

::: tip 说明
语言模块主要是提供平台通用获取对应语言相关的内容，下面的使用只介绍通过 npm 安装方式的使用，其他方式的使用请参考 [介绍使用](/introduction/) 里面的用法
:::

## 获取平台可用语言列表

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.9.0   |   >= 3.8.0   |   >= 3.9.0   |   >= 3.9.0   |   >= 3.8.0   |

**TCS**:

| 登录页 | 控制台 |
| :----: | :----: |
|  :x:   |  :x:   |

> 使用示列

```ts
import { language } from '@tencent/tce-sdk';
const languageList = language.getLangList();
```

> 出入参说明

```ts
export interface Language {
  /**
   * 是否为默认语言
   */
  default: boolean;
  /**
   * 语言名称
   */
  name: string;
}
/**
 * 获取当前环境的语言列表
 */
export declare function getLangList(): Language[];
```

> 结果实例

```json
[
  {
    "default": true,
    "name": "zh-CN"
  }
]
```

## 获取平台当前语言

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   > 3.9.0    |     :x:      |     :x:      |   > 3.9.0    |

**TCS**:

| 登录页 | 控制台 |
| :----: | :----: |
|  :x:   |  :x:   |

> 使用示列

```ts
import { language } from '@tencent/tce-sdk';
const currentLang = language.getCurrentLang();
```

> 出入参说明

```ts
/**
 * 获取环境当前语言
 * 取值顺序：url,window.I18N_CONFIG.tceLanguage,cookie
 */
export declare function getCurrentLang(): string;
```

> 结果实例

```text
zh-CN
```

## 获取平台当前语言下的货币

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   >= 3.10.0    |     >= 3.10.0      |     :x:      |   >= 3.10.0    |

**TCS**:

| 登录页 | 控制台 |
| :----: | :----: |
|  :x:   |  :x:   |

> 使用示列

```ts
import { language } from '@tencent/tce-sdk';
const currentCurrency = language.getCurrentCurrency();
```

> 出入参说明

```ts
/**
 * 获取环境当前语言
 * 取值顺序：url,window.I18N_CONFIG.tceLanguage,cookie
 */
export declare function getCurrentCurrency(): string;
```

> 结果实例

```text
元
```

## 获取平台当前语言下的货币相关信息

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   >= 3.10.0    |     >= 3.10.0      |     :x:      |   >= 3.10.0    |

**TCS**:

| 登录页 | 控制台 |
| :----: | :----: |
|  :x:   |  :x:   |

> 使用示列

```ts
import { language } from '@tencent/tce-sdk';
const currentCurrencyInfo = language.getCurrentCurrencyInfo();
```

> 出入参说明

```ts
interface CurrencyInfo {
  /**
   * 符号，如“￥”
   */
  symbol: string;
  /**
   * 中文词，如“人民币”
   */
  words: string;
  /**
   * 货币代号，如“CNY”
   */
  code: string;
}
/**
 * 获取环境当前语言
 * 取值顺序：url,window.I18N_CONFIG.tceLanguage,cookie
 */
export declare function getCurrentCurrencyInfo(): CurrencyInfo;
```

> 结果实例

```text
{
  symbol:"¥",
  words:"人民币",
  code:"CNY"
}
```