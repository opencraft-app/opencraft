# 平台

::: tip 说明
平台模块主要是提供平台通用的一些 SDK，下面的使用只介绍通过 npm 安装方式的使用，其他方式的使用请参考 [介绍使用](/introduction/) 里面的用法
:::

## 获取当前平台类型

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.9.0   |   >= 3.8.0   |   >= 3.9.0   |   >= 3.9.0   |   >= 3.8.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| >= 2.1.0 | >= 2.1.0 |

> 使用示列

```ts
import { platform } from '@tencent/tce-sdk';
const platformType = platform.getCurrentPlatform();
```

> 出入参情况

```ts
/**
 * 获取当前平台类型
 */
export declare function getCurrentPlatform(): string | undefined;
```

## 异步获取前端组件部署信息

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |  >= 3.10.0   |  >= 3.10.0   |     :x:      |  >= 3.10.0   |

**TCS**:

| 登录页 | 控制台 |
| :----: | :----: |
|  :x:   |  >=2.3.0   |

> 使用示列

```ts
import { platform } from "@tencent/tce-sdk";
// 不传入参的时候会获取当前页面的组件版本，也可以传入具体页面的urlPath，例如：/cvm
const componentInfo = await platform.getFrontendComponentInfo();

// 结果示例
{
  "branch": "release/tce3.8.0",
  "commitId": "8eb98e2",
  "buildTime": "2021-01-14 19:57:17",
  "deployTime": "2021-03-10 16:52:15",
  "productName": "product-frontend-imgcache-tcloud-overview"
}
```

::: tip 最佳实践
`getFrontendComponentInfo`除了获取当前页面及传入对应页面的 urlPath 获取组件信息，还可以获取平台一些通用组件的信息，在使用的时候传入通用组件的 urlPath 就可以，目前可获取的通用组件的 urlPath 有：[附录-平台通用组件常量](/platform/#平台通用组件常量)

> 使用示例【获取前端 tcesdk 组件的版本信息】

```ts
import { platform } from '@tencent/tce-sdk';
const { getFrontendComponentInfo, PLATFORM_COMMON_COMPONENT } = platform;
const componentInfo = await getFrontendComponentInfo(PLATFORM_COMMON_COMPONENT.TCESDK);
```

:::

> 出入参情况

```ts
/**
 * 获取前端组件信息
 * @export
 * @param {string} [urlPath] 默认为当前页面
 */
export declare function getFrontendComponentInfo(urlPath?: string): Promise<IComponentInfo | undefined>;

/**
 * 组件信息
 */
export interface IComponentInfo {
  /**
   * 组件名称
   */
  productName: string;
  /**
   * git分支名
   */
  branch: string;
  /**
   * git-commitId
   */
  commitId: string;
  /**
   * 构建时间
   */
  buildTime: string;
  /**
   * 部署时间
   */
  deployTime: string;
  /**
   * 页面接入信息[通用组件没有接入信息]
   */
  pageAccessInfo?: ICurrentAccess;
}
```

::: tip ICurrentAccess
`ICurrentAccess`为当前页面客制化接入信息，详细说明查看[附录-客制化产品接入 SDK 相关出参定义](/config/#客制化产品接入SDK相关出参定义)
:::

## 同步获取前端组件commitId
::: tip
获取前端组件的commitId主要用于在请求前端静态资源的时候加上，用于刷新静态资源缓存
:::

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |  >= 3.10.11   |  >= 3.10.11   |     :x:      |  >= 3.10.11   |

**TCS**:

| 登录页 | 控制台 |
| :----: | :----: |
|  :x:   |  >=2.3.4.0   |

> 使用示列

```ts
import { platform } from "@tencent/tce-sdk";
// 传入路由key，如果没有路由key的情况，传入组件名称
const componentInfo = await platform.getComponentCommitId('customize-next');

// 结果示例
8eb98e2
```

> 出入参情况

```ts
/**
 * 获取前端组件CommitId
 * @param routerKey 路由key，如果没有路由key的情况，传入组件名称
 */
export declare function getComponentCommitId(routerKey: string): string;
```

## 获取平台 title 信息

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.9.0   |   >= 3.8.0   |   >= 3.9.0   |   >= 3.9.0   |   >= 3.8.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| >= 2.1.0 | >= 2.1.0 |

> 使用示列【已做国际化】

```ts
import { platform } from '@tencent/tce-sdk';
const customizeVersion = platform.getCustomizeTitle();
```

> 出入参情况

```ts
/**
 * 获取平台Title信息
 */
export declare function getCustomizeTitle(): string | undefined;
```

## 获取平台 logo 信息

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.9.0   |   >= 3.8.0   |   >= 3.9.0   |   >= 3.9.0   |   >= 3.8.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| >= 2.3.4.0 | >= 2.3.4.0 |

> 使用示列

```ts
import { platform } from '@tencent/tce-sdk';
const { favicon, mainLogo } = platform.getCustomizeLogo();
```

> 出入参情况

```ts
/**
 * 客制化logo信息
 */
interface CustomizeLogo {
  favicon: string;
  mainLogo: string;
}
/**
 * 获取平台logo信息【浏览器favicon及控制台主logo】
 */
export declare function getCustomizeLogo(): CustomizeLogo;
```

## 获取平台全局变量

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   >= 3.10.11   |   >= 3.10.11   |   >= 3.10.11   |   >= 3.10.11  |   >= 3.10.11   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| >= 2.3.4.0 | >= 2.3.4.0 |

> 使用示列

```ts
import { platform } from '@tencent/tce-sdk';
// 默认先从TCE_GLOBAL_CONSTANT中获取，获取不到再从TCS下面获取，最后再从window下获取
const isOpenIOA = platform.getGlobalVariable('isOpenIOA');
```

> 出入参情况

```ts
/**
 * 获取全局变量
 * 默认先从TCE_GLOBAL_CONSTANT中获取，获取不到再从TCS下面获取，最后再从window下获取
 */
export declare function getGlobalVariable(key: string): any;
```

## 获取交付产品列表

> 平台及版本支持情况【TCE3100版本需要支持的话，需要回合一些组件，使用的时候请联系TCE同学】

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   :x:   |   >= 3.10.0   |   >= 3.10.0   |   :x:  |   >= 3.10.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| :x: | :x: |

> 使用示列

```ts
import { platform } from '@tencent/tce-sdk';
// 传入region则查询当前region下部署的产品，不传则查询所有region下的产品
const productList = await platform.getDeliverProductList('chongqing');
```

> 出入参情况

```ts
/**
 * 获取交付产品列表
 * @param region region名称【比如：chongqing】
 */
export declare function getDeliverProductList(region?: string): Promise<DeliverProductInfo[]>;
interface IProductInfo {
  productCode: string;
}
interface DeliverProductInfo {
  productCode: string;
  subProduct: IProductInfo[];
}
```

## 检查产品是否交付

> 平台及版本支持情况【TCE3100版本需要支持的话，需要回合一些组件，使用的时候请联系TCE同学】

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|   :x:   |   >= 3.10.0   |   >= 3.10.0   |   :x:  |   >= 3.10.0   |

**TCS**:

|  登录页  |  控制台  |
| :------: | :------: |
| :x: | :x: |

> 使用示列

```ts
import { platform } from '@tencent/tce-sdk';
const isDeliver = await tcesdk.platform.checkProductDeliver({ "productCode": "cvm" });
```

> 出入参情况

```ts
/**
 * 检查产品是否已经交付
 * @param param ICheckProductDeliverParam
 */
export declare function checkProductDeliver(param: ICheckProductDeliverParam): Promise<boolean>;
interface ICheckProductDeliverParam {
  /**
   * region名称【比如：chongqing】
   */
  region?: string;
  /**
   * 产品code
   */
  productCode: string;
  /**
   * 子产品code
   */
  subProductCode?: string;
}
```

## 登录态失效跳转登录页面

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   >= 3.8.0   |   >= 3.9.0   |     :x:      |   >= 3.8.0   |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | >= 2.1.0 |

> 使用示列

```ts
import { platform } from '@tencent/tce-sdk';
platform.toLoginPageForExpired();
```

> 出入参情况

```ts
/**
 * 针对iframe这种登录态过期重新回到登录页面
 */
export declare function toLoginPageForExpired(): void;
```

## 退出登录

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |  >= 3.10.0   |  >= 3.10.0   |     :x:      |  >= 3.10.0   |

**TCS**:

| 登录页 | 控制台 |
| :----: | :----: |
|  :x:   |  >= 2.3.0   |

> 使用示列

```ts
import { platform } from '@tencent/tce-sdk';
platform.logout();
```

> 出入参情况

```ts
/**
 * 退出登录
 */
export declare function logout(): void;
```

## 显示退出登录前的 model

> 平台及版本支持情况

**TCE**:

| 租户端登录页 | 租户端控制台 | 租户端购买页 | 运营端登录页 | 运营端控制台 |
| :----------: | :----------: | :----------: | :----------: | :----------: |
|     :x:      |   >= 3.8.0   |   >= 3.8.0   |     :x:      |   >= 3.8.0   |

**TCS**:

| 登录页 |  控制台  |
| :----: | :------: |
|  :x:   | >= 2.1.0 |

> 使用示列

```ts
import { platform } from '@tencent/tce-sdk';
platform.showPreLoginModal('登录态失效', '请点击确定重新登录');
```

> 出入参情况

```ts
/**
 * 显示进入登录页面的Modal
 * @param message 标题
 * @param description 的描述信息
 */
export declare function showPreLoginModal(message: string, description: string): void;
```

## 附录

### 平台类型常量

> 目前 SDK 提供的平台类型常量

```js
/**
 * 平台类型
 */
export const PLATFORM_TYPE = {
  /**
   * tce租户端控制台
   */
  TCE_TCLOUD: 'tce_tcloud',
  /**
   * tce运营端控制台
   */
  TCE_OCLOUD: 'tce_ocloud',
  /**
   * tcs运营端控制台
   */
  TCS_OCLOUD: 'tcs_ocloud',
  /**
   * tce租户端购买页
   */
  TCE_TCLOUD_BUY: 'tce_tcloud_buy',
  /**
   * tce租户端登录页
   */
  TCE_TCLOUD_LOGIN: 'tce_tcloud_login',
  /**
   * tce运营端登录页
   */
  TCE_OCLOUD_LOGIN: 'tce_ocloud_login',
  /**
   * tcs运营端登录页
   */
  TCS_OCLOUD_LOGIN: 'tcs_tcloud_login',
};
// 使用方式
import { platform } from '@tencent/tce-sdk';
console.log(platform.PLATFORM_TYPE.TCE_TCLOUD);
```

### 平台通用组件常量

```ts
/**
 * 通用前端组件
 */
export const PLATFORM_COMMON_COMPONENT = {
  /**
   * tce-js-sdk
   */
  TCESDK: 'tcesdk',
  /**
   * 前端通用js
   */
  CORE: 'core',
  /**
   * 平台js
   */
  PLATFORM: 'platform',
};
```
